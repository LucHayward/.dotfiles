// ==UserScript==
// @name         SIM Ticketing Monitors
// @namespace    marclab/simticketingmonitor
// @version      2.5.8
// @description  Display alarm status and link in SIM ticket queue and ticket overview
// @author       marclab@, maintained by grablair@, dmmelico@ S3OL hack: adambene@, wolickim@, isengard AWS regex fixed by fajetm@
// @include      https://t.corp.amazon.com/*
// @grant        GM_addStyle
// @grant        GM_xmlhttpRequest
// @require      http://code.jquery.com/jquery-2.2.4.min.js#sha256=BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=
// @require      https://sdk.amazonaws.com/js/aws-sdk-2.865.0.min.js
// @downloadURL  https://drive.corp.amazon.com/view/grablair@/Greasemonkey/sim_ticketing_monitors.user.js?download=true
// @updateURL    https://drive.corp.amazon.com/view/grablair@/Greasemonkey/sim_ticketing_monitors.user.js?download=true

// ==/UserScript==

/*
    Modification of TT Ticket Monitor script https://improvement-ninjas.amazon.com/gmget.cgi/TicketMonitors.user.js
*/

const MONITOR_STYLES = `

.title-wrapper {
	  display: flex;
		justify-content: space-between;
}

.carnaval-status {
    font-size: x-small;
    padding: 1px 2px;
    font-weight: bold;
    text-align: center;
    width: 10em;
		display: inline-block;
}

.carnaval-status-link:hover {
  	text-decoration: none !important;
}

.carnaval-status:hover {
		opacity: 0.7;
}

#sim-title .carnaval-status {
		font-size: medium;
    line-height: normal;
    margin-left: 1em;
		padding: .3em 0;
}

#sim-issueListContent .carnaval-status-link {
		display: block;
		margin-left: 5px;
}

#sim-issueListContent .carnaval-status {
		display: block;
		top: 50%;
		height: 2.5em;
		position: relative;
		transform: translateY(-50%);
}

.ALERT, .ALARM {
	border: 1px solid red;
	background-color: #ffbbbb;
	color: red;
	}

.OK {
	color: #669966;
	border: 1px solid green;
	background-color: #bbffbb;
	}

.SUPPRESSED, .AUTO_SUPPRESSED {
	border: 1px dashed red;
	background-color: #ffbbbb;
	color: red;
	}

.AT_RISK {
	border: 1px dashed green;
	color: #669966;
	background-color: #bbffbb;
	}

.UNKNOWN {
    border: 1px solid black;
    color: black;
    background-color: lightgray;
}

.NO_HISTORY {
		border: 1px solid black;
		color: black;
	  background: linear-gradient(90deg, #bbffbb 50%, #ffbbbb 50%);
}

/**
 * Tooltip Styles
 */

/* Base styles for the element that has a tooltip */
[data-tooltip],
.tooltip {
  position: relative;
  cursor: pointer;
}

/* Base styles for the entire tooltip */
[data-tooltip]:before,
[data-tooltip]:after,
.tooltip:before,
.tooltip:after {
  position: absolute;
  visibility: hidden;
  -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
  filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=0);
  opacity: 0;
  -webkit-transition:
      opacity 0.2s ease-in-out,
        visibility 0.2s ease-in-out,
        -webkit-transform 0.2s cubic-bezier(0.71, 1.7, 0.77, 1.24);
    -moz-transition:
        opacity 0.2s ease-in-out,
        visibility 0.2s ease-in-out,
        -moz-transform 0.2s cubic-bezier(0.71, 1.7, 0.77, 1.24);
    transition:
        opacity 0.2s ease-in-out,
        visibility 0.2s ease-in-out,
        transform 0.2s cubic-bezier(0.71, 1.7, 0.77, 1.24);
  -webkit-transform: translate3d(0, 0, 0);
  -moz-transform:    translate3d(0, 0, 0);
  transform:         translate3d(0, 0, 0);
  pointer-events: none;
}

/* Show the entire tooltip on hover and focus */
[data-tooltip]:hover:before,
[data-tooltip]:hover:after,
[data-tooltip]:focus:before,
[data-tooltip]:focus:after,
.tooltip:hover:before,
.tooltip:hover:after,
.tooltip:focus:before,
.tooltip:focus:after {
  visibility: visible;
  -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";
  filter: progid:DXImageTransform.Microsoft.Alpha(Opacity=100);
  opacity: 1;
}

/* Base styles for the tooltip's directional arrow */
.tooltip:before,
[data-tooltip]:before {
  z-index: 1001;
  border: 6px solid transparent;
  background: transparent;
  content: "";
}

/* Base styles for the tooltip's content area */
.tooltip:after,
[data-tooltip]:after {
  z-index: 1000;
  padding: 8px;
  width: 160px;
  background-color: #000;
  background-color: hsla(0, 0%, 20%, 0.9);
  color: #fff;
  content: attr(data-tooltip);
  font-size: 14px;
  line-height: 1.2;
}

/* Directions */

/* Top (default) */
[data-tooltip]:before,
[data-tooltip]:after,
.tooltip:before,
.tooltip:after,
.tooltip-top:before,
.tooltip-top:after {
  bottom: 100%;
  left: 50%;
}

[data-tooltip]:before,
.tooltip:before,
.tooltip-top:before {
  margin-left: -6px;
  margin-bottom: -12px;
  border-top-color: #000;
  border-top-color: hsla(0, 0%, 20%, 0.9);
}

/* Horizontally align top/bottom tooltips */
[data-tooltip]:after,
.tooltip:after,
.tooltip-top:after {
  margin-left: -80px;
}

[data-tooltip]:hover:before,
[data-tooltip]:hover:after,
[data-tooltip]:focus:before,
[data-tooltip]:focus:after,
.tooltip:hover:before,
.tooltip:hover:after,
.tooltip:focus:before,
.tooltip:focus:after,
.tooltip-top:hover:before,
.tooltip-top:hover:after,
.tooltip-top:focus:before,
.tooltip-top:focus:after {
  -webkit-transform: translateY(-12px);
  -moz-transform:    translateY(-12px);
  transform:         translateY(-12px);
}

/* Left */
.tooltip-left:before,
.tooltip-left:after {
  right: 100%;
  bottom: 50%;
  left: auto;
}

.tooltip-left:before {
  margin-left: 0;
  margin-right: -12px;
  margin-bottom: 0;
  border-top-color: transparent;
  border-left-color: #000;
  border-left-color: hsla(0, 0%, 20%, 0.9);
}

.tooltip-left:hover:before,
.tooltip-left:hover:after,
.tooltip-left:focus:before,
.tooltip-left:focus:after {
  -webkit-transform: translateX(-12px);
  -moz-transform:    translateX(-12px);
  transform:         translateX(-12px);
}

/* Bottom */
.tooltip-bottom:before,
.tooltip-bottom:after {
  top: 100%;
  bottom: auto;
  left: 50%;
}

.tooltip-bottom:before {
  margin-top: -12px;
  margin-bottom: 0;
  border-top-color: transparent;
  border-bottom-color: #000;
  border-bottom-color: hsla(0, 0%, 20%, 0.9);
}

.tooltip-bottom:hover:before,
.tooltip-bottom:hover:after,
.tooltip-bottom:focus:before,
.tooltip-bottom:focus:after {
  -webkit-transform: translateY(12px);
  -moz-transform:    translateY(12px);
  transform:         translateY(12px);
}

/* Right */
.tooltip-right:before,
.tooltip-right:after {
  bottom: 50%;
  left: 100%;
}

.tooltip-right:before {
  margin-bottom: 0;
  margin-left: -12px;
  border-top-color: transparent;
  border-right-color: #000;
  border-right-color: hsla(0, 0%, 20%, 0.9);
}

.tooltip-right:hover:before,
.tooltip-right:hover:after,
.tooltip-right:focus:before,
.tooltip-right:focus:after {
  -webkit-transform: translateX(12px);
  -moz-transform:    translateX(12px);
  transform:         translateX(12px);
}

/* Move directional arrows down a bit for left/right tooltips */
.tooltip-left:before,
.tooltip-right:before {
  top: 3px;
}

/* Vertically center tooltip content for left/right tooltips */
.tooltip-left:after,
.tooltip-right:after {
  margin-left: 0;
  margin-bottom: -16px;
}
`;
const GOV_CLOUD_REGIONS = ['us-gov-east-1', 'us-gov-west-1'];

(async function () {
  GM_addStyle(MONITOR_STYLES);

	var $ = window.jQuery;

	watchAndHandleTicketLoaded();
	watchAndHandleTicketListLoaded();
	watchAndHandleSpinnerLoaded();

	function watchAndHandleTicketLoaded() {
		waitForKeyElements(".issue-detail-content .issue-title", onTicketLoaded);
	}

	function watchAndHandleTicketListLoaded() {
		waitForKeyElements("#sim-issueListContent table tbody tr:first-child td:nth-child(3) a", onTicketListLoaded, false);
	}

	function watchAndHandleSpinnerLoaded() {
		waitForKeyElements("#sim-issueListContent .awsui-spinner", function() {
			$('#monitor-status-header, .issue-list-carnaval').remove();
		}, false);
	}

	function onTicketListLoaded() {
		// create the new column
		//if (!$('#monitor-status-header').length) {
		//	$('.issue-list table thead th:nth-child(4)').after($('<th></th>').attr('id', 'monitor-status-header').attr('min-width', '10em').text("Monitor Status"));
		//}
		//$('.issue-list table tbody td:nth-child(4)').after($('<td></td>').addClass('issue-list-carnaval').attr('min-width', '10em'));

		var $ticketLinks = $("#sim-issueListContent td:nth-child(3) a");
		var ticketDatas = $.map($ticketLinks, function (ticketLink, i) {
			return {
				id: $(ticketLink).attr("href").split("/")[1],
				node: $(`#sim-issueListContent table tbody tr:nth-child(${i+1}) td:nth-child(4) .title-wrapper`),
				tooltipDirection: "left"
			};
		});

		processtickets(ticketDatas);
	}

	function onTicketLoaded() {
		var ticketDatas = [{
			id: window.location.pathname.split("/")[1],
			node: $(".issue-detail-content .issue-title"),
			tooltipDirection: "bottom"
		}];
		processtickets(ticketDatas);
	}

  var groupBy = function (arr, f) {
      return arr.reduce(function (obj, item) {
          var key = f(item);

          if (!obj.hasOwnProperty(key)) {
              obj[key] = [];
          }

          obj[key].push(item);
          return obj;
      }, {});
  };

  function processtickets(ticketDatas) {
    var queryData = {};
    $.each(ticketDatas, function(i, ticketData) {
      queryData[`id.${i+1}`] = ticketData.id;
    });

    GM_xmlhttpRequest({
      method: 'GET',
      url: `https://maxis-service-prod-pdx.amazon.com/issues?${$.param(queryData)}`,
      onload: async function (result) {
        var data = JSON.parse(result.response);
        var cloudWatchTickets = []

        $.each(data.documents, function (i, item) {
          if("tryCloudWatch" === processTicket(item.description, ticketDatas[i].node, ticketDatas[i].tooltipDirection, 0)){
            var ticketDescription = item.description
            var accounts = new RegExp("- AWS Account: ([^\r\n]*)").exec(ticketDescription)
            var name = new RegExp("- Name: ([^\r\n]*)").exec(ticketDescription)
            var region = new RegExp("- AWS Region: ([^\r\n]*)").exec(ticketDescription)
            var isenLink = new RegExp("- Isengard( \\(AWS only\\))?: (https://[^\r\n]*)").exec(ticketDescription)
            var conduitLink = new RegExp("- Conduit( \\(Retail only\\))?: (https://[^\r\n]*)").exec(ticketDescription)

            if(accounts && name && region && isenLink) {
                cloudWatchTickets.push({
                    ticketLink: `https://t.corp.amazon.com/${ticketDatas[i].id}`,
                    account : accounts[1],
                    alarmName : name[1],
                    region : region[1],
                    isenLink : isenLink[isenLink.length - 1] || "",
                    conduitLink : conduitLink[conduitLink.length - 1] || "",
                    indicatorNodeSibling : ticketDatas[i].node,
                    severity : item.extensions.tt.impact
                })
            }
          }
        });

       const cloudWatchTicketsByRegionAndAccount = groupBy(cloudWatchTickets, x => [x.region, x.account])

        for (var x in cloudWatchTicketsByRegionAndAccount) {
            var tickets = cloudWatchTicketsByRegionAndAccount[x]
            var region = tickets[0].region
            var account = tickets[0].account
            await tryProcessCloudWatchTicket(account, region, tickets)
        }

      }
    });
  }

  function generateCarnavalApiRequestURL(alarmName) {
      return "http://carnaval-api.amazon.com/?AlarmName=" + alarmName + "&HistoryType=StateUpdate&MaxRecords=1&Operation=DescribeAlarmHistory&Version=2010-10-16&ContentType=JSON";
  }

  var carnavalMonitorNameRegex = /[?&]name=([^&]+)/;

  async function callIsengard(region, api, body, headers = {}) {
      return new Promise(async (resolve, reject) => {
          GM_xmlhttpRequest({
              method: 'POST',
              url: getIsengardEndpoint(region),
              data: JSON.stringify(body),
              headers: {
                  'User-agent': 'Mozilla/4.0 (compatible) Greasemonkey',
                  "content-type": "application/json; charset=UTF-8",
                  "x-amz-target": `com.amazon.isengard.coral.IsengardService.${api}`,
                  "Content-Encoding": "amz-1.0",
                  ...headers
              },
              onloadend: async (response) => {
                  resolve(JSON.parse(response.response));
              },
              onabort: (error) => {
                  reject(error);
              },
              onerror: (error) => {
                  reject(error);
              },
              ontimeout: (error) => {
                  reject(error);
              }
          });
      });
  }

    async function getCredentialsFromIibs(account) {
        return new Promise(async (resolve, reject) => {
            GM.xmlHttpRequest({
                url: 'https://iibs-midway.corp.amazon.com/GetSecurityTokenByAccount',
                method: 'POST',
                data: JSON.stringify({
                    awsAccountId: account,
                    awsPartition: "aws",
                    duration: 900,
                    readOnly: true,
                }),
                onload: async (response) => {
                    var resp = JSON.parse(response.responseText)
                    if (resp.accessKeyId) {
                        resolve({ source: "iibs", accessKeyId: resp.accessKeyId, secretAccessKey: resp.secretAccessKey, sessionToken: resp.sessionToken });
                    } else {
                        // no access :-(
                        resolve(undefined);
                    }
                },
                onabort: (error) => {
                    reject(undefined);
                },
                onerror: (error) => {
                    reject(undefined);
                },
                ontimeout: (error) => {
                    reject(undefined);
                }
            });
        });
    }

  async function tryProcessCloudWatchTicket(account, region, tickets) {
        var alarms = groupBy(tickets, x => x.alarmName)
        var alarmNames = tickets.map(x=>x.alarmName)
        // Get the lowest severity ticket (lowest severity number = highest impact). If there are sev2 and sev4 tickets, we want the sev2 ticket for Isengard CAZ.
        var lowestSeverityTicket = tickets.sort((left, right) => left.severity - right.severity)[0];
        var credentials = undefined;

        // Try Isengard
        var getContingentAuthTokenResponse = await callIsengard(region, 'GetContingentAuthorizationToken', {
            AWSAccountID: account,
            Justifications: [
                {
                    SIM: {
                        Link: lowestSeverityTicket.ticketLink
                    }
                }
            ]
        });
        if (getContingentAuthTokenResponse.ContingentAuthorizationToken) {
            var getAssumeRoleCredsResponse = await callIsengard(region, 'GetAssumeRoleCredentials', {
                AWSAccountID: account,
                IAMRoleName: 'ReadOnly'
            }, {
              // https://code.amazon.com/packages/IsengardService/blobs/3723fcd6a15a413b41bd16a3aeb812a1af58b98b/--/src/com/amazon/isengard/security/ContingentAuthorizationHandler.java#L11
              'X-ISENGARD-AUTHORIZATION-TOKEN': getContingentAuthTokenResponse.ContingentAuthorizationToken
            });

            if (getAssumeRoleCredsResponse.AssumeRoleResult) {
                var assumeRoleResult = $.parseJSON(getAssumeRoleCredsResponse.AssumeRoleResult);
                credentials = {source: "isengard", accessKeyId: assumeRoleResult.credentials.accessKeyId, secretAccessKey: assumeRoleResult.credentials.secretAccessKey, sessionToken: assumeRoleResult.credentials.sessionToken}
            }
        }

        // If no credentials found, try IIBS (Conduit)
        if (!credentials) {
            credentials = await getCredentialsFromIibs(account)
        }

        // Did we find credentials?  Awesome!  Let's get the alarm info from CloudWatch.
        if (credentials) {
            var cnf = {...credentials, region: region}

            var cloudwatch = new AWS.CloudWatch(cnf);
            var params = {
                AlarmNames: alarmNames,
                AlarmTypes: ['CompositeAlarm', 'MetricAlarm']
            };
            cloudwatch.describeAlarms(params, function(err, data) {
                if (err) console.log(err, err.stack); // an error occurred
                else {
                    [].concat(data.MetricAlarms, data.CompositeAlarms).forEach(metricAlarm =>{
                        alarms[metricAlarm.AlarmName].forEach(ticket => {
                            var $monitorIcon = $("<div></div>")
                            .addClass('carnaval-status')
                            .addClass(metricAlarm.StateValue === "OK" ? 'OK' : 'ALERT')
                            .text(metricAlarm.StateValue)

                            var $monitorAnchor = $("<a></a>")
                            .attr("href", credentials.source === "iibs" ? ticket.conduitLink : ticket.isenLink)
                            .addClass('carnaval-status-link')
                            .attr('title', metricAlarm.StateReason)

                            $(ticket.indicatorNodeSibling).append($monitorAnchor.append($monitorIcon));
                        })})
                }
            });
        }
  }

	function processTicket(ticketDescription, indicatorNodeSibling, tooltipDirection, attempt) {
		var regExp = new RegExp("(http\\S+carnaval.amazon.com/v1/viewObject.do\\S+)");
		var monitorLinks = regExp.exec(ticketDescription);
		if (!monitorLinks) {

            //tryProcessCloudWatchTicket(ticketDescription, indicatorNodeSibling, tooltipDirection, attempt)
			return "tryCloudWatch";
		}

		var monitorUrl = monitorLinks[0];
        var monitorName = carnavalMonitorNameRegex.exec(monitorUrl)[1];
        var monitorApiUrl = generateCarnavalApiRequestURL(monitorName);
		GM_xmlhttpRequest({
			method: "GET",
			url: monitorApiUrl,
			headers: {
				"User-Agent": "Mozilla/5.0 (compatible) Greasemonkey/TicketMonitors.user.js",
				"Accept": "text/xml"
			},
			onload: function (rawResponse) {
        var response = $.parseJSON(rawResponse.responseText);
        if (response.Error && attempt < 15) { // If there is an error, try once a second for no more than 15 times
          setTimeout( function(){ processTicket(ticketDescription, indicatorNodeSibling, tooltipDirection, attempt + 1) }, 1000);
        } else {
          var alarmHistoryItems = response.DescribeAlarmHistoryResponse.DescribeAlarmHistoryResult.AlarmHistoryItems;

          var $monitorIcon = $("<div></div>")
              .addClass('carnaval-status');
          var $monitorAnchor = $("<a></a>")
              .attr("href", monitorUrl)
              .addClass('carnaval-status-link');

          if (alarmHistoryItems.length) {
            var historyData = $.parseJSON(alarmHistoryItems[0].HistoryData);
            var effectiveAlarm = historyData.effectiveAlarm == "true";
            var effectiveSuppression = historyData.effectiveSuppression == "true";

            var carnavalState = retrieveCarnavalAlarmState(effectiveAlarm, effectiveSuppression)
            $monitorIcon.addClass(carnavalState)
                .text(carnavalState);

            $monitorAnchor
                .addClass(`tooltip-${tooltipDirection}`)
                .attr('data-tooltip', `Entered state ${timeConverter(alarmHistoryItems[0].Timestamp)}`);
          } else {
            $monitorIcon
                .addClass('UNKNOWN')
                .text('NO HISTORY');

            $monitorAnchor
                .addClass(`tooltip-${tooltipDirection}`)
                .attr('data-tooltip', "This alarm hasn't changed state in over four weeks. " +
                    "Carnaval's API only allows non-SigV4 authenticated callers to access four weeks of monitor history, not the current state.");
          }

          $(indicatorNodeSibling).append($monitorAnchor.append($monitorIcon));
        }
      },
			onerror: function () {
				var $monitorIcon = $("<div></div>")
						.addClass('carnaval-status')
						.addClass('UNKNOWN')
						.text('UNKNOWN');
        var $monitorAnchor = $("<a></a>")
  					.attr("href", monitorUrl)
						.addClass('carnaval-status-link');

				$(indicatorNodeSibling).append($monitorAnchor.append($monitorIcon));
			}
		});
	}

  function retrieveCarnavalAlarmState(effectiveAlarm, effectiveSuppression) {
      if (!effectiveSuppression) {
          if (effectiveAlarm) {
              return "ALERT";
          } else {
              return "OK";
          }
      } else {
          if (effectiveAlarm) {
              return "SUPPRESSED";
          } else {
              return "AT_RISK";
          }
      }
  }

	function formatUnixTimestamp(timestamp) {
		var a = new Date(timestamp * 1000);
	  var year = a.getFullYear();
	  var month = (a.getMonth() + 1).toString().padStart(2, '0');
	  var date = a.getDate().toString().padStart(2, '0');
	  var hour = a.getHours().toString().padStart(2, '0');
	  var min = a.getMinutes().toString().padStart(2, '0');
	  var time = `${year}-${month}-${date} at ${hour}:${min} PST`;
	  return time;
	}

	function timeConverter(t) {
        var a = new Date(t * 1000);
        var today = new Date();
        var yesterday = new Date(Date.now() - 86400000);
        var year = a.getFullYear();
        var month = (a.getMonth() + 1).toString().padStart(2, '0');
        var date = a.getDate().toString().padStart(2, '0');
        var hour = a.getHours().toString().padStart(2, '0');
				var min = a.getMinutes().toString().padStart(2, '0');
				var sec = a.getSeconds().toString().padStart(2, '0');
        if (a.setHours(0,0,0,0) == today.setHours(0,0,0,0))
            return 'today, at ' + hour + ':' + min + ':' + sec;
        else if (a.setHours(0,0,0,0) == yesterday.setHours(0,0,0,0))
            return 'yesterday, at ' + hour + ':' + min + ':' + sec;
        else
            return `${year}-${month}-${date} ${hour}:${min}:${sec}`;
  }

  function getIsengardEndpoint(region) {
    var classic_endpoint = "https://isengard-service.amazon.com/";
    var gc_endpoint = "https://isengard-service-us-gov-west-1.amazon.com/";
    if (GOV_CLOUD_REGIONS.includes(region)) {
      return gc_endpoint;
    }

    return classic_endpoint;
  }
})();


// Create functions which are known to be
// missing from Chrome's Greasemonkey API
if (typeof GM_getValue == 'undefined') {
	GM_getValue = function (name, defaultValue) {
		var value = localStorage.getItem(name);
		if (!value) {
			return defaultValue;
		}
		var type = value[0];
		value = value.substring(1);
		switch (type) {
			case 'b':
				return value == 'true';
			case 'n':
				return Number(value);
			default:
				return value;
		}
	};
}

if (typeof GM_setValue == 'undefined') {
	GM_setValue = function (name, value) {
		value = (typeof value)[0] + value;
		localStorage.setItem(name, value);
	};
}

if (typeof GM_log == 'undefined') {
	GM_log = function (message) {
		console.log(message);
	};
}

var NinjaAutoUpdate = {};
NinjaAutoUpdate.version = "0.3.3";
NinjaAutoUpdate.delta = 60 * 60 * 24 * 3; //3 days (?)

NinjaAutoUpdate.getEpoch = function () {
	return Math.round((new Date()).getTime() / 1000);
};

NinjaAutoUpdate.init = function () {
	// check new version
	// compute current time
	var now = NinjaAutoUpdate.getEpoch();
	var updateAt = GM_getValue("NinjaAutoUpdate_LAST_CHECK", 0) + NinjaAutoUpdate.delta;

	if (updateAt > now) return; // dont do anything

	// do a check
	GM_xmlhttpRequest({
		method: 'GET',
		url: 'https://improvement-ninjas.amazon.com/gmget.cgi?check=TicketMonitors.user.js',
		headers: {
			'User-agent': 'Mozilla/4.0 (compatible) Greasemonkey',
			'Accept': 'application/atom+xml,application/xml,text/xml',
		},
		onload: NinjaAutoUpdate.callback
	});
	// record time of last check
	GM_setValue("NinjaAutoUpdate_LAST_CHECK", NinjaAutoUpdate.getEpoch());
};

NinjaAutoUpdate.callback = function (response) {
	if (!Number(response.responseText)) {
		// ERROR!? What can be done now? Not a lot i reckon...
		return;
	}
	if (NinjaAutoUpdate.version != Number(response.responseText)) {
		NinjaAutoUpdate.createAlert();
	}
};

NinjaAutoUpdate.ignore = function (event) {
	GM_setValue("NinjaAutoUpdate_LAST_CHECK", NinjaAutoUpdate.getEpoch());
	NinjaAutoUpdate.cancelAlert();
	if (typeof event === "object" && typeof event.stopPropagation === "function") {
		event.stopPropagation();
	}
};

NinjaAutoUpdate.install = function () {
	window.open('https://improvement-ninjas.amazon.com/gmget.cgi?get=TicketMonitors.user.js');
	NinjaAutoUpdate.cancelAlert();
	GM_setValue("NinjaAutoUpdate_LAST_CHECK", NinjaAutoUpdate.getEpoch());
	if (typeof event === "object" && typeof event.stopPropagation === "function") {
		event.stopPropagation();
	}
};

NinjaAutoUpdate.createAlert = function () {
	NinjaAutoUpdate.alert = document.createElement('div');
	NinjaAutoUpdate.alert.setAttribute('class', 'NinjaAutoUpdateOverlay');
	NinjaAutoUpdate.alert.innerHTML = "<style>.NinjaAutoUpdateOverlay {  font-size: 11px;  position: relative;  margin: 0 0 0 0;  padding: 4px 10px;  text-align: left;  z-index: 1000;  cursor: pointer;  background-color: #FFFFD5;  border-bottom:1px solid #E47911;  color: #990000;}.NinjaAutoUpdateOverlay a {  padding: 0px 4px;}.NinjaAutoUpdateOverlay .nau-right {  float: right;}</style><div>    <span style='font-size:larger'>    A new version of <strong>'TicketMonitors.user.js'</strong> is available!    </span>  <a href='#' id='NinjaAutoUpdateInstall-TicketMonitors.user.js'>    Get the new one!  </a>  <a href='#' id='NinjaAutoUpdateIgnore-TicketMonitors.user.js' class='nau-right'>    Ignore for a few days  </a></div>";
	var first = document.body.firstChild;
	document.body.insertBefore(NinjaAutoUpdate.alert, first);
	document.getElementById("NinjaAutoUpdateInstall-TicketMonitors.user.js").addEventListener("click", NinjaAutoUpdate.install, false);
	document.getElementById("NinjaAutoUpdateIgnore-TicketMonitors.user.js").addEventListener("click", NinjaAutoUpdate.ignore, false);
};

NinjaAutoUpdate.cancelAlert = function () {
	if (typeof NinjaAutoUpdate.alert === "object") {
		NinjaAutoUpdate.alert.parentNode.removeChild(NinjaAutoUpdate.alert);
		NinjaAutoUpdate.alert = undefined;
	}
};

// Init without waiting for load event, this code
// doesnt depend on any loaded DOM elements
NinjaAutoUpdate.init();







// Below is an external snippet, copied over so that it doesn't change underneath us (which would be untrusted)

/*--- waitForKeyElements():  A utility function, for Greasemonkey scripts,
    that detects and handles AJAXed content.

    Usage example:

        waitForKeyElements (
            "div.comments"
            , commentCallbackFunction
        );

        //--- Page-specific function to do what we want when the node is found.
        function commentCallbackFunction (jNode) {
            jNode.text ("This comment changed by waitForKeyElements().");
        }

    IMPORTANT: This function requires your script to have loaded jQuery.
*/
function waitForKeyElements (
    selectorTxt,    /* Required: The jQuery selector string that
                        specifies the desired element(s).
                    */
    actionFunction, /* Required: The code to run when elements are
                        found. It is passed a jNode to the matched
                        element.
                    */
    bWaitOnce,      /* Optional: If false, will continue to scan for
                        new elements even after the first match is
                        found.
                    */
    iframeSelector  /* Optional: If set, identifies the iframe to
                        search.
                    */
) {
    var targetNodes, btargetsFound;

    if (typeof iframeSelector == "undefined")
        targetNodes     = $(selectorTxt);
    else
        targetNodes     = $(iframeSelector).contents ()
                                           .find (selectorTxt);

    if (targetNodes  &&  targetNodes.length > 0) {
        btargetsFound   = true;
        /*--- Found target node(s).  Go through each and act if they
            are new.
        */
        targetNodes.each ( function () {
            var jThis        = $(this);
            var alreadyFound = jThis.data ('alreadyFound')  ||  false;

            if (!alreadyFound) {
                //--- Call the payload function.
                var cancelFound     = actionFunction (jThis);
                if (cancelFound)
                    btargetsFound   = false;
                else
                    jThis.data ('alreadyFound', true);
            }
        } );
    }
    else {
        btargetsFound   = false;
    }

    //--- Get the timer-control variable for this selector.
    var controlObj      = waitForKeyElements.controlObj  ||  {};
    var controlKey      = selectorTxt.replace (/[^\w]/g, "_");
    var timeControl     = controlObj [controlKey];

    //--- Now set or clear the timer as appropriate.
    if (btargetsFound  &&  bWaitOnce  &&  timeControl) {
        //--- The only condition where we need to clear the timer.
        clearInterval (timeControl);
        delete controlObj [controlKey]
    }
    else {
        //--- Set a timer, if needed.
        if ( ! timeControl) {
            timeControl = setInterval ( function () {
                    waitForKeyElements (    selectorTxt,
                                            actionFunction,
                                            bWaitOnce,
                                            iframeSelector
                                        );
                },
                300
            );
            controlObj [controlKey] = timeControl;
        }
    }
    waitForKeyElements.controlObj   = controlObj;
}
