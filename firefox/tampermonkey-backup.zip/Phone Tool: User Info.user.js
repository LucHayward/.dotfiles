// ==UserScript==
// @version         0.21
// @downloadURL     https://axzile.corp.amazon.com/-/carthamus/download_script/phone-tool:-user-info.user.js
// @name            Phone Tool: User Info
// @namespace       http://amazon.com
// @description     Updated phone tool - supporting the new redesigned phone tool (Dec 14th, 2017)
// @include         https://phonetool.amazon.com/people/*
// @include         https://phonetool.amazon.com/users/*
// @include         https://connect.amazon.com/people/*
// @include         https://connect.amazon.com/users/*
// @run-at          document-end
// @grant           GM.xmlHttpRequest
// @grant           GM_xmlhttpRequest
// @grant           GM.setClipboard
// @grant           GM_setClipboard
// ==/UserScript==

/*
REVISION HISTORY:
0.7  - 2018-01-08 - lepine@ - Fix information for non-blue-badges
0.8  - 2018-03-23 - lepine@ - Change way to get user information from url and regex to react JSON data
0.9  - 2019-09-16 - lepine@ - Add manager name and alias to the user's information, and avoid duplicating Hire Date 
0.10 - 2020-03-07 - lepine@ - Fix erroneous version number in script information
0.11 - 2020-05-11 - lepine@ - Add one-click copy of alias
0.12 - 2020-06-02 - lepine@ - Add support for alternate Phone Tool URL (connect.amazon.com)
0.13 - 2020-06-03 - lepine@ - Add mutually exclusive execution of scripts
0.14 - 2020-12-17 - lepine@ - Add deprecation notice for SAPP
0.15 - 2020-12-17 - lepine@ - New default version post SAPP
0.16 - 2020-12-17 - lepine@ - Allow SAPP autoupdate
0.17 - 2021-01-22 - lepine@ - Add Org Size computation, add manager alias copy
0.18 - 2021-02-11 - lepine@ - Hide Org size computation for now / Get current time for employee
0.19 - 2022-02-18 - lepine@ - Remove JQuery dependency / mark as deprecated and redirect to Carthamus
0.20 - 2022-04-15 - lepine@ - For boomerangs / re-hires, display total tenure and current tenure
0.21 - 2022-04-15 - lepine@ - Add alias and copy function for Executive Assistants
*/

'use strict';

function userInfoScript() {
    function GetUserInfoUri(login) {
        return "https://phonetool.amazon.com/users/" + encodeURIComponent(login) + ".json";
    }

    function getReadableDate(when) {
        try
        {
            const year = when.getUTCFullYear();
            const month = when.getUTCMonth();
            const day = when.getUTCDate();
            const weekday = when.getUTCDay();
            let result = [ "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" ][weekday] + ", ";
            result += [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ][month] + " ";
            result += day;
            if(day >= 10 && day <= 20) {
                result += "th";
            } else if((day % 10) == 1) {
                result += "st";
            } else if((day % 10) == 2) {
                result += "nd";
            } else if((day % 10) == 3) {
                result += "rd";
            } else {
                result += "th";
            }
            result += ", " + year;
            return result;
        } catch(e) {
            console.error("Unable to format date", dateStr, e);
            return "now";
        }
    }

    function newLine(className, title, content) {
        const props = document.createElement('span');
        props.classList.add('optional-wrapper');
        props.innerHTML = `<div class="TableRow ${className}"><div class="TableProperty">${title}:</div><div class="TableValue">${content}</div></div>`;
        document.querySelector(".UserDetailsTable .dl-horizontal").before(props);
        return props.querySelector(":scope > div.TableRow > div.TableValue");
    }

    function displayEmpInfo() {
        const copy = typeof(GM_setClipboard) == "function" ? GM_setClipboard : GM.setClipboard;

        const targetUser = JSON.parse(document.querySelector("div[data-react-class='UserDetails']").getAttribute("data-react-props")).targetUser;
        const login = targetUser.targetUserLogin;
        const employeeId = targetUser.targetUserEmployeeID;

        let empIdCell = document.querySelector(".UserDetailsTable .EmployeeIDRow .TableValue");
        if(empIdCell === null) {
            empIdCell = newLine('EmployeeIDRow', 'Employee Id', '');
        }
        empIdCell.innerHTML = `<span>${employeeId}</span> <a href="#" title="click to copy the employee id to the clipboard">(copy id)</a>`
        empIdCell.querySelector(":scope a").addEventListener('click', function (event) {
            event.preventDefault();
            copy(employeeId);
        });

        let aliasCell = document.querySelector(".UserDetailsTable .LoginRow .TableValue");
        if(aliasCell === null) {
            aliasCell = newLine('LoginRow', 'Alias', '');
        }
        aliasCell.innerHTML = `<span>${login}</span> <a href="#" title="click to copy the alias to the clipboard">(copy alias)</a>`
        aliasCell.querySelector(":scope a").addEventListener('click', function (event) {
            event.preventDefault();
            copy(login);
        });

        let assistantCell = document.querySelector(".UserDetailsTable .AssistantRow .TableValue");
        if(assistantCell !== null) {
            const assistantLogin = targetUser.targetUserAssistant.login;
            const assistantName = targetUser.targetUserAssistant.name;
            assistantCell.innerHTML = `<a href="/users/${assistantLogin}" title="Go to their Phone Tool page">Loading...</a><br/><span>${assistantLogin}</span> <a href="#" title="click to copy the alias to the clipboard">(copy alias)</a>`
            assistantCell.querySelectorAll(":scope a")[0].innerText = assistantName;
            assistantCell.querySelectorAll(":scope a")[1].addEventListener('click', function (event) {
                event.preventDefault();
                copy(assistantLogin);
            });
        }

        const utcText = document.querySelector(".UserDetailsTable .LocationRow .TableValue span.UTCText");
        if(utcText !== null) {
            // Compute time in local timezone
            const analysis = utcText.innerText.match(/^.*\(UTC \+?(?<hours>-?[0-9]+):(?<minutes>[0-9]+)\).*$/);

            if(analysis !== null) {
                const [hours,minutes] = [analysis.groups['hours'], analysis.groups['minutes']].map((v) => parseInt(v));
                const timeDiv = document.createElement('div');
                timeDiv.classList.add("muted");
                const timeCell = document.createElement('span');
                timeDiv.classList.add("LocalTime");
                timeDiv.append(timeCell);
                document.querySelector(".UserDetailsTable .LocationRow .TableValue").append(timeDiv);

                const computeTime = () => {
                    let timeSuffix = ', today';
                    const now = new Date();
                    const localDate = new Date(now.valueOf());
                    localDate.setMinutes(localDate.getMinutes() + localDate.getTimezoneOffset()); // In UTC
                        if(hours >= 0) {
                        localDate.setMinutes(localDate.getMinutes() + hours*60 + minutes);
                        if(localDate.getDate() !== now.getDate()) {
                            timeSuffix = ', tomorrow';
                        }
                    } else {
                        localDate.setMinutes(localDate.getMinutes() + hours*60 - minutes);
                        if(localDate.getDate() !== now.getDate()) {
                            timeSuffix = ', yesterday';
                        }
                    }
                    const timeString = `${localDate.getHours()}`.padStart(2, '0') + ':' + `${localDate.getMinutes()}`.padStart(2, '0');
                    timeCell.innerText = `Local time: ${timeString}${timeSuffix}`;
                    now.setSeconds(0);
                    now.setMinutes(now.getMinutes()+1);
                    let nextTick = now - new Date();
                    if (nextTick <= 0) {
                        nextTick = 1000; // Try in one second, to realign
                    }
                    setTimeout(() => computeTime(), nextTick);
                };
                computeTime();
            }
        }

        let hireDateCell = document.querySelector(".UserDetailsTable .HireDateRow .TableValue");
        if(hireDateCell === null) {
            hireDateCell = newLine('HireDateRow', 'Latest Hire Date', `${targetUser.targetUserHireDateString}`);
        }

        let tenureCell = document.querySelector(".UserDetailsTable .TenureRow .TableValue");
        if(tenureCell === null) {
            tenureCell = newLine('TenureRow', 'Tenure', `${targetUser.targetUserTenure}`);
        }

        const managerCell = newLine('ManagerRow', 'Manager', '<a href="#" title="Go to their Phone Tool page">Loading...</a><br/><span></span> <a href="#" title="click to copy the alias to the clipboard"></a>');
        const levelCell = newLine('LevelRow', 'Level', 'Loading...');
        const orgSizeCell = newLine('OrgSizeRow', 'Org Size', 'Loading...');
        const barRaiserCell = newLine('BarRaiserRow', 'Bar raiser', 'Loading...');

        const url = GetUserInfoUri(login);
        const req = typeof(GM_xmlhttpRequest) == "function" ? GM_xmlhttpRequest : GM.xmlHttpRequest;
        req({
            url: url,
            method: "GET",
            onload: function(response) {
                try {
                    var data = JSON.parse(response.responseText)
                    if(data.hire_date_iso !== null) {
                        const when = new Date(data.hire_date_iso + "T00:00:00Z");
                        hireDateCell.innerText = getReadableDate(when);
                    }
                    if((data.job_level !== null) && (data.job_level != 99)) {
                        levelCell.innerText = data.job_level + (data.is_manager === true ? ' (Mgr)': ' (IC)');
                    }
                    if(Array.isArray(data.direct_reports) && (data.direct_reports.length > 0)) {
                        orgSizeCell.innerText = `${data.direct_reports.length} direct reports`;
                    } else {
                        document.querySelector(".UserDetailsTable .OrgSizeRow").style.display = 'none';
                    }
                    if((data.badge_type == "blue") && (data.bar_raiser !== null)) {
                        barRaiserCell.innerText = data.bar_raiser ? "Yes" : "No";
                    } else {
                        barRaiserCell.innerText = "N/A";
                    }
                    if((data.total_tenure_formatted !== null) && (data.total_tenure_formatted !== "") && (data.total_tenure_formatted !== targetUser.targetUserTenure)) {
                        tenureCell.innerText = `${data.total_tenure_formatted} total\nCurrent: ${targetUser.targetUserTenure}`;
                    }

                    if(data.manager && data.manager.login) {
                        const managerUrl = GetUserInfoUri(data.manager.login);
                        req({
                            url: managerUrl,
                            method: "GET",
                            onload: function(managerResponse) {
                                try {
                                    var managerData = JSON.parse(managerResponse.responseText);
                                    if((managerData.login !== null) && (managerData.name !== null)) {
                                        const links = managerCell.querySelectorAll(':scope a');
                                        const pageLink = links[0];
                                        pageLink.setAttribute("href", '/users/' + managerData.login);
                                        pageLink.innerText = managerData.name;
                                        const aliasSpan = managerCell.querySelector(':scope span');
                                        aliasSpan.innerText = `${managerData.login}`;
                                        const copyLink = links[1];
                                        copyLink.innerText = `(copy alias)`;
                                        copyLink.addEventListener('click', function (event) {
                                            event.preventDefault();
                                            copy(managerData.login);
                                        });
                                    } else {
                                        document.querySelector(".UserDetailsTable .ManagerRow").style.display = 'none';
                                    }
                                } catch(e) {
                                    console.error("An error occured processing response: ", e, data);
                                }
                            },
                            onerror: function(response) {
                                console.error("An error occured calling resource: ", response);
                            }
                        });
                    } else {
                        document.querySelector(".UserDetailsTable .ManagerRow").style.display = 'none';
                    }
                } catch(e) {
                    console.error("An error occured processing response: ", e, data);
                }
            },
            onerror: function(response) {
                console.error("An error occured calling resource: ", response);
            }
        });
    }

    window.addEventListener('load', displayEmpInfo);
};

if (typeof(window.customPhoneToolScripts) !== 'object') {
    window.customPhoneToolScripts = {};
}
if (window.customPhoneToolScripts.userInfo !== true) {
    window.customPhoneToolScripts.userInfo = true;
    userInfoScript();
}
