// ==UserScript==
// @name         Copy Code Review Name and URL
// @downloadURL https://improvement-ninjas.amazon.com/GreaseMonkey/cr-copy-name-and-url.user.js
// @updateURL https://improvement-ninjas.amazon.com/GreaseMonkey/cr-copy-name-and-url.user.js
// @version      0.3
// @description  Adds a button to copy the code review name and URL to clipboard
// @author       @niebloom
// @match        https://code.amazon.com/reviews/*
// ==/UserScript==

(function() {
    'use strict';

    // Function to copy text to clipboard
    function copyToClipboard(text) {
        const dummy = document.createElement('textarea');
        document.body.appendChild(dummy);
        dummy.value = text;
        dummy.select();
        document.execCommand('copy');
        document.body.removeChild(dummy);
    }

    // Function to get the code review name and URL
    function getCodeReviewNameAndURL() {
        const crNameElement = document.querySelector('.cr-name span');
        const crURLElement = document.querySelector('copy-to-clipboard-wrapper[entity-name="CR URL"] span.content a');

        if (crNameElement && crURLElement) {
            const crName = crNameElement.textContent.trim();
            const crURL = crURLElement.href;
            return `${crName}\n${crURL}`;
        }

        alert("Failed to copy");
    }

    // Create the button
    function createCopyButton() {
        const copyButton = document.createElement('button');
        copyButton.textContent = 'Copy Code Review Name and URL';
        copyButton.style.marginLeft = '10px';
        copyButton.addEventListener('click', () => {
            const codeReviewNameAndURL = getCodeReviewNameAndURL();
            copyToClipboard(codeReviewNameAndURL);
        });
        return copyButton;
    }

    // Add the button to the page
    function addButtonToPage() {
        const crTitleActions = document.querySelector('.cr-title-actions');
        if (crTitleActions) {
            const copyButton = createCopyButton();
            crTitleActions.appendChild(copyButton);
        } else {
            // Check for the button again after a short delay
            setTimeout(addButtonToPage, 500);
        }
    }

    addButtonToPage();
})();