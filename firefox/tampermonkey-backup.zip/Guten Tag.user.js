// ==UserScript==
// @name         Guten Tag
// @namespace    w.amazon.com
// @version      0.3
// @description  [Add tagging and folder re-allocation shortcuts to sim]
// @author       damgene
// @match        https://sim.amazon.com/*
// @match        https://issues.amazon.com/*
// @match        https://i.amazon.com/*
// @include        https://sim.amazon.com/*
// @include        https://issues.amazon.com/*
// @include        https://i.amazon.com/*
// @downloadURL    https://code.amazon.com/packages/GutenTag/blobs/mainline/--/GutenTag.user.js?raw=1
// @updateURL      https://code.amazon.com/packages/GutenTag/blobs/mainline/--/GutenTag.user.js?raw=1
// @grant          GM_xmlhttpRequest
// @grant          GM.xmlHttpRequest
// @grant          GM_addStyle
// @connect        maxis-service-prod-dub.amazon.com
// ==/UserScript==

(function() {
    // =============
    // Configuration helpers
    // =============

    const wrapOnClick = (doAction) => (event) => {
        startWorking(event.target)
        doAction()
            .then(() => {
                stopWorking(event.target)
                flashCheckMark(event.target)
            })
            .catch((error) => {
                stopWorking(event.target)
                flashCrossMark(event.target)
                console.error(error)
            })
    }

    const tagButton = (tag) => ({
        label: `Tag: <b>${tag.Name}</b>`,
        onclick: wrapOnClick(() =>
            getCurrentSimId()
                .then((currentSimId) => {
                    var name = tag.Name
                    return makeTagRequest({currentSimId, name})
                }))
    })

    const folderButton = (folder) => ({
        label: `Folder: <b>${folder.Name}</b>`,
        onclick: wrapOnClick(() =>
            getCurrentSimId()
                .then((currentSimId) => {
                    var folderId = folder.Id
                    console.info(`before ${folderId}`)
                    return makeMoveRequest({currentSimId, folderId})
                }))
    })

    // =============
    // Configuration
    // =============

    const TAG_BUTTONS = [
        ...[{Name: "Root Cause: Arbalest"}, {Name: "Root Cause: MF Org"}, {Name: "Root Cause: External Team"}].map(tagButton),
    ]

    const FOLDER_BUTTONS = [
        ...[{Name: "Stormbow", Id: "5f6decb5-7d25-4041-b081-e21827c87306"}, {Name: "Arbalest", Id: "6c356a5e-78e2-46bd-876c-8a998a445c1b"}].map(folderButton),
    ]

    var buttonsArray = [TAG_BUTTONS, FOLDER_BUTTONS]

    const SHORTCUT_BUTTONS = [].concat(...buttonsArray);


    // ==============
    // Styles
    // ==============

    GM_addStyle(`
        .shortcuts-for-sim-button {
            display: inline-block;
        }

        .shortcuts-for-sim-check-mark {
            display: none;
        }

        .shortcuts-for-sim-show-check-mark .shortcuts-for-sim-check-mark {
            display: inline;
            opacity: 100%;
            animation: shortcutsFadeIn linear 1s;
        }

        .shortcuts-for-sim-cross-mark {
            display: none;
        }

        .shortcuts-for-sim-show-cross-mark .shortcuts-for-sim-cross-mark {
            display: inline;
            opacity: 100%;
            animation: shortcutsFadeIn linear 1s;
        }

        .shortcuts-for-sim-working {
            display: none;
        }

        .shortcuts-for-sim-show-working .shortcuts-for-sim-working {
            display: inline;
        }

        @keyframes shortcutsFadeIn {
            0% {opacity:1;}
            100% {opacity:0;}
        }
    `)

    // ==================
    // Helper methods
    // ==================

    // not the cleanest, but it does its job simply (it will fail when reach year 10000!!!)
    const getDateString = (date) => date.toISOString().slice(0, 10)

    // ==================
    // Request handling
    // ==================

    const getCurrentOrigin = () => new URL(document.URL).origin

    const getSimEditURL = (simId) => `https://maxis-service-prod-dub.amazon.com/issues/${simId}/edits`

    const makeMoveRequest = ({currentSimId, folderId}) => makeEditRequest({currentSimId, data: folderId, path: '/assignedFolder'})

    const makeEstimateRequest = ({currentSimId, estimate}) => {
        const now = new Date()
        const todayString = getDateString(now)

        return makeEditRequest({
            currentSimId,
            data: {
                effort: estimate,
                effortLoggedDate: now.toISOString(),
                id: todayString,
                unit: 'Points',
            },
            path: `/extensions/effort/expandedEffortEstimated/${todayString}`,
        })
    }

    const makeTagRequest = ({currentSimId, name}) => makeEditRequest({currentSimId, data: {"id": name}, path: '/tags/'+name})

    const makeEditRequest = ({currentSimId, data, path}) => {
        return new Promise((resolve, reject) => {
            GM.xmlHttpRequest({
                method: 'POST',
                url: getSimEditURL(currentSimId),
                headers: {
                    'Content-Type': 'application/json',
                    'Origin': getCurrentOrigin(),
                },
                data: JSON.stringify({pathEdits: [
                    {
                        data,
                        editAction: 'PUT',
                        path,
                    }
                ]}),
                onload: (res) => res.status >= 200 && res.status < 300 ? resolve(JSON.parse(res.responseText)) : reject(res),
                onerror: reject,
            })
        })
    }

    // =================
    // DOM manipulation
    // =================

    const SHORTCUT_BUTTON_ID = 'shortcuts-for-sim-button'

    const getButtonId = (i) => `${SHORTCUT_BUTTON_ID}-${i}`

    const addTemporaryClassName = (element, className) => {
        element.classList.add(className)
        setTimeout(() => element.classList.remove(className), 1000)
    }

    const startWorking = (element) => {
        element.classList.add('shortcuts-for-sim-show-working')
    }

    const stopWorking = (element) => {
        element.classList.remove('shortcuts-for-sim-show-working')
    }

    const flashCheckMark = (e) => {
        addTemporaryClassName(e, 'shortcuts-for-sim-show-check-mark')
    }

    const flashCrossMark = (e) => {
        addTemporaryClassName(e, 'shortcuts-for-sim-show-cross-mark')
    }

    const getCurrentSimId = () => {
        return new Promise((resolve, reject) => {
            const documentIdsContainer = document.getElementsByClassName('document-ids-container').item(0)
            if (documentIdsContainer) {
                const navigationLinks = [...documentIdsContainer.getElementsByClassName('navigation-link')]
                const [longIssueLink] = navigationLinks.filter(({dataset}) => dataset?.name === 'long-issue-id')
                const currentSimId = longIssueLink?.innerHTML
                if (currentSimId) {
                    resolve(currentSimId)
                } else {
                    reject('No SIM id found.')
                }
            }
            reject('No SIM id found.')
        })
    }

    const enhanceDocumentWithButtons = () => {
        const actionsPane = document.getElementById('issue-overview-data')

        FOLDER_BUTTONS.reverse() // we need to reverse the buttons, to keep their order in the UI (they are injected one by one always to the start of the element)
        TAG_BUTTONS.reverse() // we need to reverse the buttons, to keep their order in the UI (they are injected one by one always to the start of the element)

        TAG_BUTTONS.forEach(({label, onclick}, i) => {
            const buttonId = getButtonId(i)

            actionsPane.insertAdjacentText('afterbegin', ' ')
            actionsPane.insertAdjacentHTML('afterbegin', `
            <div class="shortcuts-for-sim-button">
                <button class="btn" id="${buttonId}">${label}<span class="shortcuts-for-sim-check-mark"> ✅</span><span class="shortcuts-for-sim-cross-mark"> ❌</span><span class="shortcuts-for-sim-working"> 🏗️</span></button>
            </div>
            `)

            const shortcutButton = document.getElementById(buttonId)
            shortcutButton.onclick = onclick
        })

        FOLDER_BUTTONS.forEach(({label, onclick}, i) => {
            const buttonId = getButtonId(i)

            actionsPane.insertAdjacentText('afterbegin', ' ')
            actionsPane.insertAdjacentHTML('afterbegin', `
            <div class="shortcuts-for-sim-button">
                <button class="btn" id="${buttonId}">${label}<span class="shortcuts-for-sim-check-mark"> ✅</span><span class="shortcuts-for-sim-cross-mark"> ❌</span><span class="shortcuts-for-sim-working"> 🏗️</span></button>
            </div>
            `)

            const shortcutButton = document.getElementById(buttonId)
            shortcutButton.onclick = onclick
        })
    }

    const waitForDocumentThen = (fn, retries = 20) => () => {
        if (retries <= 0) {
            console.error('No action buttons, ignoring "Shortcuts for SIM" script...')
            return
        }
        if (document.getElementById('issue-overview-data') === null) {
            console.info(`Waiting for document details to show up (${retries})...`)
            setTimeout(waitForDocumentThen(fn, retries - 1), 1000)
        } else {
            fn()
        }
    }

    if (window.top != window.self) return //-- Don't run on frames or iframes
    waitForDocumentThen(enhanceDocumentWithButtons)()
})();

