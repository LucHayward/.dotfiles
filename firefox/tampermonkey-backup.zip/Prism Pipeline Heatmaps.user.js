// ==UserScript==
// @name         Prism Pipeline Heatmaps
// @namespace    http://aws.amazon.com/
// @version      2026.3.0
// @description  Embedded deployment heatmaps and VSR diffs for pipelines
// @author       David Worth (davworth@)
// @include      /^https://pipelines.amazon.com\/pipelines\/[\w-]+\/?(\?.*)?$/
// @include      /^https://pipelines.amazon.dev\/pipelines-wip\/[\w-]+\/?(\?.*)?$/
// @icon         https://davworth-tampermonkey-assets.s3.us-east-1.amazonaws.com/diff-icon.png
// @connect      brazil-metadata-sso.corp.amazon.com
// @connect      code.amazon.com
// @connect      service.davworth.people.aws.dev
// @connect      us-west-2.prod.pipelines-api.builder-tools.aws.dev
// @grant        GM_xmlhttpRequest
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_registerMenuCommand
// @updateURL    https://code.amazon.com/packages/DavworthTamperScripts/blobs/mainline/--/pipelines/prism.user.js?raw=1
// @downloadURL  https://code.amazon.com/packages/DavworthTamperScripts/blobs/mainline/--/pipelines/prism.user.js?raw=1
// @run-at       document-start
// ==/UserScript==

/************************ IMPORTANT ************************
* This file is generated automatically by rollup.
* Do not modify this file directly. Instead, modify the component files
* located at {PkgRoot}/pipelines/prism
*
* After making your modifications, you can run `npm run build` to compile
* your changes into an update.
*
* Additionally, don't forget to update the version number in the above banner
* otherwise TamperMonkey won't automatically update users.
***********************************************************/
(function () {
    'use strict';

    const _CSS = ".heatmap-diff-window{position:fixed;top:0;left:0;width:100dvw;height:100dvh;z-index:999;display:flex;justify-content:center;align-items:center;background:#fff5;font-family:Helvetica,Arial,sans-serif;}.heatmap-diff-window .diff-wrapper{width:650px;max-height:75dvh;border-radius:10px;box-shadow:1px 1px 4px 3px #0003;background:#f2f2f2;color:#111;overflow:hidden;transition-duration:0.15s;transform:scale(0.8) translateY(50px);opacity:0;}.heatmap-diff-window.visible .diff-wrapper{transform:scale(1) translateY(0);opacity:1;}.heatmap-diff-window .diff-wrapper .diff-header{padding:8px 12px;background:#232f3e;color:white;font-size:20px;display:flex;flex-direction:row;justify-content:flex-start;align-items:center;position:relative;}.heatmap-diff-window .diff-wrapper .diff-header .vsr{--bar-width:8px;padding:2px 4px 2px;padding-left:calc(var(--bar-width) + 8px);display:block;border:2px solid;border-radius:4px;background:#464f6c;margin:0 var(--bar-width);position:relative;color:white;}.heatmap-diff-window .diff-wrapper .diff-header .vsr:link,.heatmap-diff-window .diff-wrapper .diff-header .vsr:visited{color:white;}.heatmap-diff-window .diff-wrapper .diff-header .vsr .bar{position:absolute;top:0;left:0;bottom:0;width:var(--bar-width);}.heatmap-diff-window .diff-wrapper .diff-header .close{position:absolute;top:12px;right:12px;aspect-ratio:1;height:24px;cursor:pointer;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAABhGlDQ1BJQ0MgcHJvZmlsZQAAKJF9kT1Iw0AcxV9TpVorDnYQcchQnezgB+JYq1CECqFWaNXB5PoJTRqSFBdHwbXg4Mdi1cHFWVcHV0EQ/ABxdnBSdJES/5cUWsR4cNyPd/ced+8AoVFhqtkVA1TNMlKJuJjJroqBV/ShF0FMYFZmpj4nSUl4jq97+Ph6F+VZ3uf+HP25vMkAn0gcY7phEW8Qz2xaOud94jAryTnic+Jxgy5I/Mh1xeU3zkWHBZ4ZNtKpeeIwsVjsYKWDWclQiaeJIzlVo3wh43KO8xZntVJjrXvyF4by2soy12mOIIFFLEGCCAU1lFGBhSitGikmUrQf9/APO36JXAq5ymDkWEAVKmTHD/4Hv7s1C1OTblIoDnS/2PbHKBDYBZp12/4+tu3mCeB/Bq60tr/aAGY/Sa+3tcgRMLANXFy3NWUPuNwBhp502ZAdyU9TKBSA9zP6piwweAsE19zeWvs4fQDS1FXyBjg4BMaKlL3u8e6ezt7+PdPq7wfurnLYawAlzQAAAAZiS0dEAAAAAAAA+UO7fwAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAAd0SU1FB+gLDgYIISHxk4kAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAABM0lEQVRo3t2azQ6CMBCEp4SIj2d8GY545Hk0MXr06COZmIwXSEzESqE/O+6ZMt/Qv+0W4F+DZC3LQvJA8kJyawB+Q/JIsg+BH6OoiTf4MfoQ+KImJuD9Jr7AFzHhgZ82QbImeaY/ziSbDPDNTJY61HXynljNUNJENO0SJqJr5jSRTCuHieQaKQWy9XIKoezzLKZgsZUuhnDxvWYNgIWNcjGIGfglQObgFyRdJpLENT1h68tHNGHiyLrUhB34wDkRfcxXMT0AeM7UdNa+vu4Qkp7E0suo9EYmnUpIJ3PS6bT0gUb6SCl9qJcuq0gXtqRLi9LFXenyuvQFh/IVUwUAzrkngJvnvVcAe+fcI7WBQWMH4OR57D4wf7hvBa5Zu18NW8MX3d3chq3BXw260Ia6P3soxQuvvM6gFbfUbwAAAABJRU5ErkJggg==);background-size:contain;}.heatmap-diff-window .diff-wrapper .diff-header .close:hover{opacity:0.6;}.heatmap-diff-window .diff-wrapper .diff-header .button{font-size:14px;margin-left:10px;border-radius:6px;line-height:1.5em;background:#d4d484 url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAJCAYAAADzRkbkAAAAMElEQVQIW2P4/fv6f4Zfv07+Z/j58zCIdfo/w9evc6DEmzdT/zPcv9/1n+HKlZb/AOVvH+NbD9dYAAAAAElFTkSuQmCC);background-size:auto;background-repeat:repeat-x;border:1px solid;border-top-color:#959567;border-left-color:#898958;border-right-color:#898958;border-bottom-color:#7c7c4d;padding:0px 6px;color:black;font-family:Lucida Sans Unicode,Lucida Grande,Verdana,Arial,sans-serif;cursor:pointer;}.heatmap-diff-window .diff-wrapper .diff-header .button:hover{text-decoration:none;}.heatmap-diff-window .diff-wrapper .diff-changes{padding:16px;max-height:calc(75vh - 64px);overflow:auto;}.heatmap-diff-window .diff-wrapper .diff-changes .diff-section{padding-bottom:10px;}.heatmap-diff-window .diff-wrapper .diff-changes .diff-section h2{margin:6px 0 2px;font-size:18px;display:block;font-family:Verdana,Helvetica,Arial,sans-serif;line-height:21.6px;}.heatmap-diff-window .diff-wrapper .diff-changes .diff-section h3{margin:0;font-size:14px;display:block;}.heatmap-diff-window .diff-wrapper .diff-changes .diff-section h3 .branch-change{font-size:80%;padding-left:12px;color:#a30;}.heatmap-diff-window .diff-wrapper .diff-changes .diff-section .diff-item{display:flex;flex-direction:row;align-items:flex-start;flex-wrap:wrap;padding-top:5px;}.heatmap-diff-window .diff-wrapper .diff-changes .diff-section .diff-item span{display:inline-block;font-size:11px;vertical-align:baseline;width:11%;}.heatmap-diff-window .diff-wrapper .diff-changes .diff-section .diff-item .message{width:75%;font-size:12px;flex:1;}.heatmap-diff-window .diff-wrapper .diff-changes .diff-section .diff-item .message a:link,.heatmap-diff-window .diff-wrapper .diff-changes .diff-section .diff-item .message a:visited{color:#111;}.heatmap-diff-window .diff-wrapper .diff-changes .diff-section .diff-item .date{color:#777;width:23%;text-align:right;}.heatmap-diff-window a:link,.heatmap-diff-window a:visited{text-decoration:none;}.heatmap-diff-window a:link:hover,.heatmap-diff-window a:visited:hover{text-decoration:underline;}:root{--heatmap-glow-color:rgb(0,145,198);}li.workflow_step:has(.status-succeeded){border-bottom:none;border-radius:4px;background-color:#e6f4e6 !important;padding:8px;margin-left:-8px;}li.workflow_step:has(.status-failed){border-bottom:none;border-radius:4px;background-color:#fbdfdf !important;padding:8px;margin-left:-8px;}li.workflow_step:has(.status-in-progress){border-bottom:none;border-radius:4px;background-color:#fff2db !important;padding:8px;margin-left:-8px;}li.workflow_step:has(.status-canceled){border-bottom:none;border-radius:4px;background-color:#ededed !important;padding:8px;margin-left:-8px;}.prism-install-milestone{position:fixed;top:50px;right:25px;background:white;border:3px solid #0064ff;border-radius:5px;padding:12px;width:320px;}.prism-install-milestone .close{height:24px;aspect-ratio:1;float:right;margin-left:20px;cursor:pointer;}.prism-install-milestone div{text-align:center;}.prism-install-milestone h1{margin:0;padding:8px 0;text-align:center;font-size:40px;font-weight:bold;}.prism-install-milestone h1 i{margin-right:20px;}.prism-install-milestone p{margin:0;padding:10px 0 0;text-align:center;font-size:12px;}#confetti-canvas{position:fixed;top:0;left:0;width:100vw;height:100vh;pointer-events:none;z-index:999;}#prism-minimap{position:fixed;top:54px;left:50%;transform:translateX(-50%);background-color:rgba(255,255,255,0.95);border:2px solid #ccc;border-radius:8px;padding:4px;z-index:9998;display:flex;flex-wrap:wrap;max-width:98vw;max-height:30px;overflow:hidden;opacity:0.8;transition:max-height 0.3s ease,opacity 0.3s ease;box-shadow:0 4px 12px rgba(0,0,0,0.15);}#prism-minimap:hover{max-height:80vh;overflow-y:auto;opacity:1.0;}.prism-mm-stage{display:flex;flex-direction:column;align-items:center;margin:1.4px;padding:2.8px;border:1px solid #ddd;border-radius:2.8px;background-color:#f8f9fa;}.prism-mm-title{font-weight:bold;font-size:7.7px;margin-bottom:2.8px;text-align:center;color:#333;cursor:pointer;}.prism-mm-title:hover{color:#0073bb;text-decoration:underline;}.prism-mm-targets{display:flex;flex-direction:row;gap:1.4px;}.prism-mm-col{display:flex;flex-direction:column;gap:1.4px;}.prism-mm-box{width:14px;height:14px;border-radius:2.1px;cursor:pointer;transition:transform 0.2s ease;display:flex;align-items:center;justify-content:center;font-size:7px;font-weight:bold;color:white;text-shadow:0 0 1.4px rgba(0,0,0,0.5);}.prism-mm-box:hover{transform:scale(1.2);z-index:1;}.awsui-polaris-dark-mode #prism-minimap{background-color:rgba(35,47,62,0.95);border-color:#545b64;}.awsui-polaris-dark-mode .prism-mm-stage{background-color:#2a3642;border-color:#414d5c;}.awsui-polaris-dark-mode .prism-mm-title{color:#d5dbdb;}.awsui-polaris-dark-mode .prism-mm-title:hover{color:#539fe5;}.prism-release-window{position:absolute;bottom:20px;right:20px;width:500px;max-height:300px;overflow:auto;padding:12px;border-radius:5px;background:#e2ebfa;border:2px solid #0064ff;color:black;font-family:Arial,Helvetica,sans-serif;font-size:12px;z-index:9998;line-height:1.4;}.prism-release-window .close{height:24px;aspect-ratio:1;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IB2cksfwAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAAd0SU1FB+kMFwgMOQgC9HEAAAFKSURBVGje3Zo5DoMwEEWHRSGHQZa4CqVLLpEyKXOeFCg3Q0axSYWEEpBZvMzHNTDv2x57FojOOrTWOSyLlPJRluW767prbPi+7y9VVb3qun6uhieigYiG2CJG+JHHKmIKH1vEL7xVxBx8LBFL8IsitNa5EKJdeoGIBiFEq5QqfMMrpYo1LH+ObVMdYiUOM8QU4cx2DBHObYYU4c1WCBHebfg0EGyVfRgK7mcuDUY76VwYjn7XHAHgcFHuBmEDvweIHfzWoItLkLh7JdjNvCsRXFLWXSJYwW/xCR97PnX1oSRJhizLPrbnjDGpMSZhNfvQWwjaiaGPUeiLDDqUgA7moMNp6IQGOqWETuqhyyrQhS3o0iJ0cRe6vA7d4DhFi6lpmhuBNPmklPfZF+dEcGuzLsLPieDW6LbCT0Vw+9VgNfzUsbkUDTixOB9f6Dt6lZYi8HIAAAAASUVORK5CYII=);background-size:contain;cursor:pointer;float:right;}.prism-release-window .close:hover{opacity:0.5;}.prism-release-window h1{font-size:20px;margin-bottom:10px;}.prism-release-window h2{font-size:16px;}.prism-settings{position:fixed;top:0;right:0;bottom:0;width:650px;max-width:100%;border-left:1px solid #cccccc;background:#f9f9f9;color:#222;display:flex;flex-direction:row;z-index:9999;}.prism-settings .sidebar{display:flex;flex-direction:column;width:200px;background:#eee;border-right:1px solid #ccc;}.prism-settings .sidebar .title{background:#00327d;color:white;padding:10px 0;display:flex;flex-direction:row;justify-content:center;align-items:center;}.prism-settings .sidebar .title img{height:24px;margin-right:12px;}.prism-settings .sidebar ul{list-style:none;margin:0;padding:0;}.prism-settings .sidebar ul li{display:block;padding:6px 10px;font-size:16px;text-align:left;cursor:pointer;border-bottom:1px solid #ccc;}.prism-settings .panel{width:350px;flex-grow:1;padding:15px;}.prism-settings h1,.prism-settings h2,.prism-settings h3{display:block;margin:0 0 4px;}.prism-settings h1{margin:0 0 10px;}.prism-settings p{font-size:14px;line-height:18px;margin:0 0 4px;}.prism-settings select{font-size:16px;}.prism-settings .color-ramp{width:100%;height:36px;border:1px solid #dfdfdf;border-radius:5px;box-sizing:border-box;position:relative;}.prism-settings .color-ramp > div{position:absolute;height:100%;top:0;bottom:0;left:0;}.prism-settings .close{height:24px;aspect-ratio:1;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAAAXNSR0IB2cksfwAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAAd0SU1FB+kMFwgMOQgC9HEAAAFKSURBVGje3Zo5DoMwEEWHRSGHQZa4CqVLLpEyKXOeFCg3Q0axSYWEEpBZvMzHNTDv2x57FojOOrTWOSyLlPJRluW767prbPi+7y9VVb3qun6uhieigYiG2CJG+JHHKmIKH1vEL7xVxBx8LBFL8IsitNa5EKJdeoGIBiFEq5QqfMMrpYo1LH+ObVMdYiUOM8QU4cx2DBHObYYU4c1WCBHebfg0EGyVfRgK7mcuDUY76VwYjn7XHAHgcFHuBmEDvweIHfzWoItLkLh7JdjNvCsRXFLWXSJYwW/xCR97PnX1oSRJhizLPrbnjDGpMSZhNfvQWwjaiaGPUeiLDDqUgA7moMNp6IQGOqWETuqhyyrQhS3o0iJ0cRe6vA7d4DhFi6lpmhuBNPmklPfZF+dEcGuzLsLPieDW6LbCT0Vw+9VgNfzUsbkUDTixOB9f6Dt6lZYi8HIAAAAASUVORK5CYII=);background-size:contain;margin-left:20px;cursor:pointer;position:absolute;top:8px;right:8px;}.prism-settings .close:hover{opacity:0.5;}.prism-window{position:fixed;bottom:0;right:25px;width:450px;display:none;border-radius:5px 5px 0 0;border:2px solid #0064ff;flex-direction:row;justify-content:left;align-items:stretch;cursor:pointer;}.prism-window.active{display:flex;width:70px;}.prism-window.active.expanded{width:450px;}.prism-window.active.expanded .sub{display:none;}.prism-window > .title{background:#cef;display:flex;align-items:center;}.prism-window > .title .icon{aspect-ratio:1;width:24px;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAABhGlDQ1BJQ0MgcHJvZmlsZQAAKJF9kT1Iw0AcxV9TpVorDnYQcchQnezgB+JYq1CECqFWaNXB5PoJTRqSFBdHwbXg4Mdi1cHFWVcHV0EQ/ABxdnBSdJES/5cUWsR4cNyPd/ced+8AoVFhqtkVA1TNMlKJuJjJroqBV/ShF0FMYFZmpj4nSUl4jq97+Ph6F+VZ3uf+HP25vMkAn0gcY7phEW8Qz2xaOud94jAryTnic+Jxgy5I/Mh1xeU3zkWHBZ4ZNtKpeeIwsVjsYKWDWclQiaeJIzlVo3wh43KO8xZntVJjrXvyF4by2soy12mOIIFFLEGCCAU1lFGBhSitGikmUrQf9/APO36JXAq5ymDkWEAVKmTHD/4Hv7s1C1OTblIoDnS/2PbHKBDYBZp12/4+tu3mCeB/Bq60tr/aAGY/Sa+3tcgRMLANXFy3NWUPuNwBhp502ZAdyU9TKBSA9zP6piwweAsE19zeWvs4fQDS1FXyBjg4BMaKlL3u8e6ezt7+PdPq7wfurnLYawAlzQAAAAZiS0dEAAAAAAAA+UO7fwAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAAd0SU1FB+gLDhY5Kxtf3lUAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAADXElEQVR42uWaz2oTURTGf5lqslARShH/YHZil+3ClXTpZFUpWCjSCXVkQCiudFd8BPEl4hsMXUxeQEoquHXRTUCEKNqGENOM6bhI/9g0mTSZczN3JgcCydzM3HO/+5073/1mIM5wgkVMbyHOFAziDfv4E1tkYpz9LPCNatkA7lIuHE4bA1aAOWAWeDqNJWAP+D4FADjBPeDJf0cKmN79aWLABjDTk4c1TQAU+5aE6WXSD4ATLAHzfVoeAI+ngQH2mG0pAMAJrgGrIf9Yw/RupJkBa0DYAIcBlHgAbKH/JBAAJ7jsIreE6c2nkQH2CHuPYroAcIJRhc4GpjeTJgYUgFGkbq9UTjwA9oTO0RAAJxh3u7uC6c2lgQEWkBvjvCzwPA0A2DGdqwEATrAIRDE9lZumhsazPxEWGApnX6qGLUwvl0QGnJieUUOpaWpoTn/lZWAoor+0klNmmqpiQK/pKZGnlSQAikpKSoFpaiig/yDTM2ooMU0NJTOVjIVVAQDDTc+oIW6aGuIJhpueUUMcYCNB9FfShyFI/0k92RE1TQ3hmZnUs72iXgCMbnpGF1pCpqkUA0Y1PaOGmNSWASAIXjHxkOkzI0D/WaA2tvavlsftuQPcplz4GS8DOv5b4Y3PZWOGo79vNCiBzGtii+h9RwegcfAJP4ZX/Do+tJo7US9zJXIireYqreYu2dxDrt+Eqzn1A//TBL+9BzyLnwFuvgGs0z5s86sGv2soYUTHh8YB1PfBb/vAOhWrrsdt0M1/Bt4B0D5EFIjzAz85ukXF2pFIXVIKvwe2T39FBaL/wAHKwAexZVSUpsvVW8AX4M6FtmyOvmtErw44q/F+PdSABSrWdz23w26+BrwAji60DWPE4Bk/lX7AS8nBq/ADwM2HU/QUiB9dIDo+NPbDBn5WYhVrWzpdVa7wFhC+SLVbXSDq++D7w653tsgmAgA3371NQV3gao3jW147OQB0QdgDJGTyJhXrq6o01T4ed/MloBThCiUqVkllipN4Q2QTGGcGpRgUMwAnUhlGqWExqasDA85L5cveRYSkrh4A9JPKg0NU6uoDgJvvKjkIU3JdJVmxjtIHwDCprEjq6gVAuFRWInX1A6C/VFYmdfUE4LxUVip19Y7lapFHH4txpvAPHBMjMDzXvQgAAAAASUVORK5CYII=);background-size:contain;background-position:center center;background-repeat:no-repeat;}.prism-window > .title h1{margin:0;padding:0;font-size:16px;margin-left:15px;font-weight:bold;color:black;}.prism-window .body{display:none;background:#fff;flex-grow:1;max-height:120px;overflow:auto;}.prism-window.active.expanded .body{display:block;}.prism-window .body .entry{display:flex;flex-direction:row;align-items:center;padding:2px 12px;transition-duration:1s;opacity:1;}.prism-window .body .entry.success{opacity:0;}.prism-window .body .entry:nth-child(2n){background:#0002;}.prism-window .sub{display:flex;align-items:center;justify-content:center;background:white;flex-grow:1;}.prism-window .status{margin-right:8px;width:16px;aspect-ratio:1;}.prism-window .status.pending{border:2px solid #c0c0c0;border-bottom-color:#ff3d00;border-radius:100%;display:inline-block;box-sizing:border-box;animation:rotation 1s linear infinite;}.prism-window .status.success{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAABhGlDQ1BJQ0MgcHJvZmlsZQAAKJF9kT1Iw0AcxV9TRZGKgh1EHCJUXeyiIo61CkWoEGqFVh1MLv2CJg1Jiouj4Fpw8GOx6uDirKuDqyAIfoA4OzgpukiJ/0sKLWI8OO7Hu3uPu3eAUC8zzeqIAZpum6lEXMxkV8WuV4TQjzDGMSIzy5iTpCR8x9c9Any9i/Is/3N/jl41ZzEgIBLHmGHaxBvEM5u2wXmfOMyKskp8Tjxh0gWJH7muePzGueCywDPDZjo1TxwmFgttrLQxK5oa8TRxRNV0yhcyHquctzhr5Spr3pO/MJTTV5a5TnMYCSxiCRJEKKiihDJsRGnVSbGQov24j3/I9UvkUshVAiPHAirQILt+8D/43a2Vn5r0kkJxoPPFcT5Gga5doFFznO9jx2mcAMFn4Epv+St1YPaT9FpLixwBfdvAxXVLU/aAyx1g8MmQTdmVgjSFfB54P6NvygIDt0DPmtdbcx+nD0CaukreAAeHwFiBstd93t3d3tu/Z5r9/QDJoXLJ220ZJwAAAAZiS0dEAAAAAAAA+UO7fwAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAAd0SU1FB+gMEBQpOjpPxCQAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAAGVUlEQVRYw8WXTWxVxxXHf+fe92VDMIZgGxc9XAdIQiFUVXCELNR8rLpoRVtBqUS7CmaRgIsiJJsVq2DJCsXOym02bTdOqka0UoXaiEZKJNwoOKpwUVrJdcEK+ZCS+IMYeH7vzunizp2Z+0xXXfRJ9715c+ecM+d//nPOGeEBnw1nSj8ADgEHgB38b59ZYAq4tDy6+mbzS2ky/AxwBvhOy3ZDqdNQaFOiFkXVL1YrqM0KsvcKIoK5D42liNpnwv1bEcBlYHR5dPXtbG0cGP8JcKG81fQ99ERCpcdQWKdQAFRSa2p3nY0VRCXYnB8rEBUgalXKHYbSFkXrsjP5Sg6W++OF2tXkutuA9fxCy9dNb+uuhPgh9QYVMIF75oHgodk6u0k1AUIqSAWKmwyotDcWZV+5P56pXU1uRlb+TLlTe1t6EqSkqEk9VpN6pCopCgYUSZXb+XQsSDZnBKw8BjSxu1OIStDSk1DuNL021Igl3O/a+hoU2o33TDSF1/voI6+SxkEBEeul2rXy3+koqWxjQVh6vwDwwwg4VPmaobBRg1grJIKqemiN9TbwNEPAGLUogRq1a6ysfV7b+RZzzymv7XyLuM1Q7jYAhyLgQPFh9YJJpjz9T2KdNp50jhfGbw5j4Sd7n83BC5tHeHb7cwDprwqlLQpwoADsiNcH3ktGNHGMUvVRMA5JRTK4rTgKiiIijowvdoxwfPcJF4X5xVuogWidAuwoAEhJPbs1/PGKJAhvCq14SiDBLsUPgcOP/IgNlTYAlu8v8dvZ11NCFtNFhexoqcsyVpms5V3AyPxcRkjEEQ2Uk50jVDdudyK/nJng1c+GnIjbgGqoXN3LjEChQJgFM6OiitpfeyQ42THC8b156Mc/GXJQqjYhQN65NHl4FgQwCxruBs2vsTs+vKsJ+n++HmRTD2WhObtlatLpgGiBITIOZFKSIZBOn+oaodruof/F3yYY/2TIR1XEaXMhEMd2+zKIpTpWZ4yUHGE9Wspg1wjHvxlAvzDP+O3h/HLU6bAIZDtSHise5PHWvQB8uDLDPxrvBlBbPIzmMqYG7D/82FEP/b0l3vhw0nFFQ4x1TQjSBS89OswzO54F4O3Zv/D89XeteuulQyaz78eD3SNU26se+ukJxj4ezrFLJTxWEKUhUJfpdm3eRSkuUYpLfLv3aQa3jqTr7UMiuSppbJY8tfU8A98KoP9ynrHbw/4kZbyxGVMt76IsBFm6nb49zWpjFYBKscKxJ37K0y1HXFrVLC3b/2JT9ZHdR9nQEkB/Y9LLGJBAJswnKQI2b6Nw+sZRxqcuUk/qAHRt6GJw30u5ouSM2wMx2H2e6qYA+vcnuDg/7I2pL+GEehwCtnJliy7OD/OHmUtO4ZPVJxl7fDLoDzwSP+s+z8D+APov5rk4f9YZc2gF49QBDRHwKKQlVjg1c5Rrt645xd/be4jT215Og+6UCkf2NEE/M4maNJuqK+PqEHYNTo4DWQ/gym/K0rHpV/h06VMAinGRgadOcHrbeUek09tepro5gP6vE/z81jCoYIz4uuIImD3qeBCX++NzhTZFIptg1DcX/67dYN3dLezp2kO5WKFcrNC76RFmP/qI73ceY+DACcrFioP++fe+62QzJ9Lj5lN01hiZmlBfiIjL/fGxuFU3SVGams00bUwtXqF0ZyP7q33EUcz6ynqqLT30VZ+io60zhf7uEr+e/hVTi1dyOcLpcv2F35C5C4070Wxc7o/3g+yL19u4qWeu2AZjavEKvbKH3d3fAKC7vZu21jZn5tV3xrlw82zKdlc5JVdl87qh/kWEWZU/RsClxrJgViTHUkzWD6ZxO/nBj7k2d21Nnzn/+TyvzJ21rZxnvj+C6hORnTMrQuOOAFyK7HXpcv1LQevBXUDFElKc8Nh7F1i5v+KM1+o13vhgMjAWGHbHTXIJSFeF+oIAXF4eXX0zBij3xx9rXQ5ipF2K6hqbsFkR4F+1G+wt9dHzcA+JSfjzzJ8Y/vtArnlZ8wSFRxvQWIhIVmQOGKpdTW5K09XsXNyivYWNSlQOC2hWLcXVtFzzKKy5Pdjeyn6n98T6kmDuyRxwbnl09Te5u2HtanK93B/PaEM6kq9kp9bXkvkB5oO7hATNiw1dXTH3hMZSeuS0IZeBoeXR1d8/+IL3f7ie/wf/T9xR731/PQAAAABJRU5ErkJggg==);background-size:contain;background-position:center center;background-repeat:no-repeat;}.prism-window .status.failure{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAABhGlDQ1BJQ0MgcHJvZmlsZQAAKJF9kT1Iw0AcxV9TRZGKgh1EHCJUXeyiIo61CkWoEGqFVh1MLv2CJg1Jiouj4Fpw8GOx6uDirKuDqyAIfoA4OzgpukiJ/0sKLWI8OO7Hu3uPu3eAUC8zzeqIAZpum6lEXMxkV8WuV4TQjzDGMSIzy5iTpCR8x9c9Any9i/Is/3N/jl41ZzEgIBLHmGHaxBvEM5u2wXmfOMyKskp8Tjxh0gWJH7muePzGueCywDPDZjo1TxwmFgttrLQxK5oa8TRxRNV0yhcyHquctzhr5Spr3pO/MJTTV5a5TnMYCSxiCRJEKKiihDJsRGnVSbGQov24j3/I9UvkUshVAiPHAirQILt+8D/43a2Vn5r0kkJxoPPFcT5Gga5doFFznO9jx2mcAMFn4Epv+St1YPaT9FpLixwBfdvAxXVLU/aAyx1g8MmQTdmVgjSFfB54P6NvygIDt0DPmtdbcx+nD0CaukreAAeHwFiBstd93t3d3tu/Z5r9/QDJoXLJ220ZJwAAAAZiS0dEAAAAAAAA+UO7fwAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAAd0SU1FB+gMEBQrO39+ljAAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAAEnElEQVRYw72XMU8kNxTHf55lWQILu+RAyumURCclQqmuuioSirArqrRJk4L7ADTpUlxx1aXhA4QmEpc2FYoUG0VIaUK1HUh34pIUQSKwy7KzLLA7TmHP4J2dVTZ3UixZM7af/f/7vefnZ8GExcA9YB1YBR4BD4FFP9wEjoEGsA/sSjibZF0xAfBj4Anw5TRUl4E6MAfMeJkeEAMt4BS4gQ7wAvhOwsEbETCwDHwNbNahfB/XUQJsboGwnXgSfzlCt8AW8K103ZMRMPAZ8M00yA+B+wFQOMHmFgnHE+AE+N1pxADPJPzyrwQMfA48fRcevQ8s8HalDfzhnKQBPJXw41gCfudbyx78nTEqswWqz2sh/F4BfzrTNIDNUBMiZ/Mf6iAfArMbG0Rra06de3sk29tjwUbpgNjYQKytIfz8eHub184vDPDFiE8YeL4P9gRsDPZ6Z8cmvZ611tr+4aGNfX8MNhYMt8HGiKF2//DQWmtt0uvZ650dG/u198EaeJ7iRsFR23wAVL0DWUBUKgCUVlaY0pokHbNuPAmqxWb/Za0praw4TVQqmewc8MDhbnpMRwB4UoXyEjDw4P29PfpHR5mGpqVkWushYJtW4eal4GUps3n9oyP6e3uZ7BIwD2UfW1yEM3D5CmyroPa0tmHpaV0gJ/6DLPaVM8OlgXsRsD4F1RqM7C4BukrRMybbUUVKKjlNJFgqWlMJdt4zhiulcmZy3zow5ay9HgGrNUAghoRCFXeV4iogMROQsMCM1swE4FfG0PXgNqjpugA191kVBn77AB7XJwgqs1ozGwB1Pal8X1epkTidP6gtF6AOhIHTj2GpMhRABNaL58/8XI5EWLrGECs1FKLzQSv97wEv4e8IWCx5T85MIOyoOfx4WyniwBxpiY3hUqnsFOXtnn7T8ZKbtjiVXhwi0I+wd3bLWI9RZXgxJaG2BCRj5oRrR0DzJucsg+xfZO10F1WtqRaYoCol8z5YWWBg85oQQ0554xOZCDjujUS1u+MVTprPgbeN4TIwR1VKFrTONhB+E+9V6WZ6bspxBDS6OQJFdUFr5nPgLaVoKUU7IDEvJbVAE0mhTwi6TrwRAftxTs1J7uzWtGYhAL8whqb39gRoKsVFQGIhJSFyzp1pxBI70f0I2B1ApzOGcV1ragF4yxjOfZAZBHLnStEKSNSkpP6zJrGj63bc3A6wG/ns9UU7t6D14PUAvGkMZ8HOh8KxEJwpRTMgUZeSenCLprXthl9IOBPBdfzrIpSrQZLxkU1GwIuynnzfktYsBsRfCpEdu45Lz26BTyUcRAA+dd668N6Zeu253825MZwGF8t45/JZsVJDc5Mg+l04Hltpuj6SklVA1txtVRhOxZi0vDhA3enn1qv+OpeSpQkJvuPZNTTaPlAMe25xrBj4Y5UUnB4XRyw3wKUDb/j0PMsHSyHf7+H1V3DSh0/68F7kGdqCt4AtCMX4yBnK3Hi7X9+l5T9N/DCJQM7m0vOim21cuQJ8kJv8YVL0NJuC8gwwHUwYBh9uXXuH67/p02zc41RAddo7aMmbR3g/GDjA1Hfe/nH6fz3P/wHru+vRSKV9ngAAAABJRU5ErkJggg==);background-size:contain;background-position:center center;background-repeat:no-repeat;}.prism-window .body .entry .title{font-size:14px;}.heatmap-wrapper{border-radius:5px;border:2px solid;margin:3px 0;cursor:pointer;transition-duration:0.2s;}.heatmap-wrapper.v2{margin-bottom:0;border-bottom:none;border-radius:5px 5px 0 0;}.heatmap-target{border:2px solid;border-top:none;border-radius:0 0 5px 5px;margin-bottom:10px;padding:4px 7px 1px;position:relative;}.heatmap-wrapper.v2 + .heatmap-target .revision-idx-container{display:none;}.heatmap-wrapper.v2 + .heatmap-target .target-details{padding:0;}.heatmap-wrapper:hover{}.reduced-animations .heatmap-wrapper:hover{transform:none;}.heatmap-wrapper.active{box-shadow:0 0 5px 2px var(--heatmap-glow-color);}.heatmap-wrapper.inactive{opacity:0.6;}.heatmap-wrapper .topline{font-size:12px;font-weight:700;display:flex;flex-direction:row;text-align:center;padding-bottom:2px;}.heatmap-wrapper .topline .vfi{text-shadow:1px 1px 3px #0008;}.heatmap-wrapper .topline .index{width:30px;background-color:#0007;border-radius:4px 0 0 0;padding:4px 0;}.heatmap-wrapper .topline .vfi{flex-grow:1;padding:4px 0;font-size:12px;}.heatmap-wrapper .topline .diff{padding:1px 6px;color:blue;background:#fffffff2;border-radius:0 4px 0 0;display:flex;align-items:center;}.heatmap-wrapper .topline .diff.loading{background:#0000;width:auto;}.heatmap-wrapper .topline .diff:hover{color:orange;text-decoration:underline;}.heatmap-wrapper.no-diff .topline .diff{opacity:0;}.heatmap-wrapper .topline .diff .loader{width:16px;aspect-ratio:1;border:2px solid #fff;border-bottom-color:#ff3d00;border-radius:100%;display:inline-block;box-sizing:border-box;animation:rotation 1s linear infinite;}@keyframes rotation{0%{transform:rotate(0deg);}100%{transform:rotate(360deg);}}.heatmap-wrapper .inner{position:relative;padding:4px 7px 1px;}.heatmap-wrapper:not(.recent) .inner .recent-deployment{display:none;}.heatmap-wrapper.recent .inner .recent-deployment{display:block;font-size:9px !important;color:white;padding:3px;text-align:center;border-radius:4px;position:absolute;top:2px;right:2px;animation:flash-recent 1s infinite ease-in-out;}.heatmap-wrapper.recent .inner .recent-deployment.no-animation{animation:none;background:#f60f;}.heatmap-target:not(.recent) .recent-deployment{display:none;}.heatmap-target.recent .recent-deployment{display:block;font-size:9px !important;color:white;padding:3px;text-align:center;border-radius:4px;position:absolute;top:2px;right:2px;animation:flash-recent 1s infinite ease-in-out;}.heatmap-target.recent .recent-deployment.no-animation{animation:none;background:#f60f;}@keyframes flash-recent{0%,100%{background:#f60f;}50%{background:#f605;}}.heatmap-wrapper .rev{display:flex;flex-direction:row;justify-content:center;background:#0002;padding:2px 6px;font-size:12px;}.heatmap-wrapper .rev .author{flex-grow:1;font-weight:bold;}.heatmap-wrapper .rev .date{font-weight:normal;}.heatmap-wrapper .target-wrapper-container{margin-bottom:0;border:0;}.heatmap-wrapper .target-wrapper-container .revision-idx-container{display:none;}.heatmap-wrapper .target-wrapper-container .target-details{padding:0;}.heatmap-wrapper a:link,.heatmap-wrapper a:visited{color:blue;text-decoration:none;}.awsui-polaris-dark-mode .heatmap-wrapper a:link,.awsui-polaris-dark-mode .heatmap-wrapper a:visited{color:rgb(66,180,255);}.heatmap-wrapper a:link:hover,.heatmap-wrapper a:visited:hover{color:orange;text-decoration:underline;}";

    function clamp(a, b, c) {
        return a < b
            ? b : a > c
                ? c : a;
    }

    function urlBuilder(baseUrl, params = {}) {
        if (Object.keys(params).length == 0) {
            return baseUrl;
        }

        let out = `${baseUrl}?`;
        for (let [key, value] of Object.entries(params)) {
            out += `${key}=${value}&`;
        }

        return out.substring(0, out.length - 1);
    }

    function xFetch(url, options = {}) {
        return new Promise((resolve, reject) => {
            GM_xmlhttpRequest({
                url,
                ...options,
                onload(response) { options.onload ? resolve(options.onload(response)) : resolve(response); },
                onabort(error) { options.onabort ? reject(options.onabort(error)) : reject(error); },
                onerror(error) { options.onerror ? reject(options.onerror(error)) : reject(error); }
            });
        })
    }

    const retry = async (block = (resolve, reject) => {}, maxTries = -1, onFail = () => {}) => {
        do {
            try {
                return await new Promise(block);
            } catch (e) {
                console.log("Retrying");
                console.error(e);
            }
        } while(--maxTries != 0)

        if (maxTries == 0) {
            onFail();
            throw new Error();
        }
    };

    function weightedRange(revisionCount, index) {
        if (revisionCount <= 1) {
            return 0;
        }

        let weight = Math.min(revisionCount * 0.2, 1);
        return (index / (revisionCount - 1)) * weight;
    }

    class Color {
        constructor(r, g, b) {
            this.r = clamp(Math.round(r), 0, 255);
            this.g = clamp(Math.round(g), 0, 255);
            this.b = clamp(Math.round(b), 0, 255);
        }

        static fromHex = (str) => new Color(
            Number.parseInt(str.substring(1, 3), 16),
            Number.parseInt(str.substring(3, 5), 16),
            Number.parseInt(str.substring(5, 7), 16)
        );

        static fromRgb = (str) => {
            str = str.extract("(", ")");
            let comps = str.split(",").map(e => parseInt(e));
            return new Color(comps[0], comps[1], comps[2]);
        }

        hex() {
            return `#${this.r.toString(16).padStart(2, "0")}` +
                `${this.g.toString(16).padStart(2, "0")}` +
                `${this.b.toString(16).padStart(2, "0")}`;
        }

        mix(color, percentage = 0.5) {
            percentage = clamp(percentage, 0, 1);
            return new Color(
                ((this.r * (1 - percentage)) + (color.r * percentage)),
                ((this.g * (1 - percentage)) + (color.g * percentage)),
                ((this.b * (1 - percentage)) + (color.b * percentage))
            )
        }

        brightness() {
            return this.g / 255;
        }

        static highVis(colorHex) {
            if (Color.fromHex(colorHex).brightness() > 0.85) {
                return "#000";
            }
            return "#FFF";
        }
    }

    class ColorRange {
        static Stop = class {
            constructor(color, x) {
                this.color = color;
                this.x = x;
            }
        }

        static DEFAULT = new ColorRange([
            new ColorRange.Stop(new Color(0, 100, 255), 0),
            new ColorRange.Stop(new Color(0, 200, 0), 0.4),
            new ColorRange.Stop(new Color(255, 200, 0), 0.67),
            new ColorRange.Stop(new Color(255, 100, 0), 0.85),
            new ColorRange.Stop(new Color(255, 0, 0), 1)
        ]);

        static MIDNIGHT = new ColorRange([
            new ColorRange.Stop(Color.fromHex("#000070"), 0),
            new ColorRange.Stop(Color.fromHex("#4300a8"), 0.3),
            new ColorRange.Stop(Color.fromHex("#41006a"), 0.5),
            new ColorRange.Stop(Color.fromHex("#c1042a"), 0.8),
            new ColorRange.Stop(Color.fromHex("#920000"), 1)
        ])

        /**
         * Protanopia is a red-green vision deficiency, often characterized
         * by a spectrum between yellow and blue.
         */
        static PROTANOPIA = new ColorRange([
            new ColorRange.Stop(new Color(13, 43, 81), 0),
            new ColorRange.Stop(new Color(90, 115, 184), 0.25),
            new ColorRange.Stop(new Color(214, 201, 55), 0.75),
            new ColorRange.Stop(new Color(134, 124, 60), 1)
        ]);

        /**
         * Deuteranopia is a green vision deficiency, characterized by
         * a spectrum between orange and blue
         */
        static DEUTERANOPIA = new ColorRange([
            new ColorRange.Stop(new Color(13, 43, 81), 0),
            new ColorRange.Stop(new Color(90, 115, 184), 0.25),
            new ColorRange.Stop(new Color(245, 184, 52), 0.75),
            new ColorRange.Stop(new Color(140, 104, 40), 1)
        ]);

        /**
         * Tritanopia is a blue vision deficiency, characterized by
         * a spectrum between red and teal
         */
        static TRITANOPIA = new ColorRange([
            new ColorRange.Stop(new Color(8, 70, 73), 0),
            new ColorRange.Stop(new Color(118, 174, 185), 0.3),
            new ColorRange.Stop(new Color(255, 180, 180), 0.5),
            new ColorRange.Stop(new Color(237, 133, 143), 0.7),
            new ColorRange.Stop(new Color(190, 32, 44), 1)
        ]);

        static GRAYSCALE = new ColorRange([
            new ColorRange.Stop(new Color(200, 200, 200), 0),
            new ColorRange.Stop(new Color(0, 0, 0), 1)
        ]);

        constructor(stops) {
            this.stops = stops.sort((a, b) => a.x - b.x);
        }

        at(x) {
            if (this.stops.length == 0) {
                return "#FFF";
            }

            if (this.stops.length == 1) {
                return this.stops[0].color.hex();
            }

            let a, b;
            for (let stop of this.stops) {
                if (stop.x <= x) {
                    a = stop;
                } else if (stop.x > x && typeof(b) == "undefined") {
                    b = stop;
                } else {
                    break;
                }
            }

            if (typeof(a) == "undefined") {
                return this.stops[0].color.hex();
            }

            if (typeof(b) == "undefined") {
                return a.color.hex();
            }

            let lerp = (x - a.x) / (b.x - a.x);
            return a.color.mix(b.color, lerp).hex();
        }

        static weightedRange(revisionCount, index) {
            if (revisionCount <= 1) {
                return 0;
            }
            let weight = Math.min(revisionCount * 0.2, 1);
            return (index / (revisionCount - 1)) * weight;
        }
    }

    class Preferences {
        static Keys = class {
            static COLOR_MODE = "colorblind_mode";
            static PACKAGE_FILTER_REGEX = "package_filter_regex";
            static RECENT_DEPLOYMENTS_ANIMATIONS = "recent_deployments_animation";
            static SHOW_RECENT_DEPLOYMENTS = "show_recent_deployments";
            static SHOW_MINIMAP = "show_minimap";
        };

        static colors() {
            switch (this.getColorKey()) {
                case "default":
                default:
                    return ColorRange.DEFAULT;
                case "midnight":
                    return ColorRange.MIDNIGHT;
                case "protan":
                    return ColorRange.PROTANOPIA;
                case "deuter":
                    return ColorRange.DEUTERANOPIA;
                case "tritan":
                    return ColorRange.TRITANOPIA;
                case "grayscale":
                    return ColorRange.GRAYSCALE;
            }
        }

        static getColorKey() {
            return GM_getValue(Preferences.Keys.COLOR_MODE, "default");
        }

        static saveColorKey(value) {
            GM_setValue(Preferences.Keys.COLOR_MODE, value);
        }

        static getPackageFilterRegex() {
            return GM_getValue(Preferences.Keys.PACKAGE_FILTER_REGEX, "");
        }

        static savePackageFilterRegex(value) {
            GM_setValue(Preferences.Keys.PACKAGE_FILTER_REGEX, value);
        }

        static getRecentDeploymentsAnimation() {
            return GM_getValue(Preferences.Keys.RECENT_DEPLOYMENTS_ANIMATIONS, true);
        }

        static saveRecentDeploymentsAnimation(value) {
            GM_setValue(Preferences.Keys.RECENT_DEPLOYMENTS_ANIMATIONS, value);
        }

        static getShowRecentDeployments() {
            return GM_getValue(Preferences.Keys.SHOW_RECENT_DEPLOYMENTS, true);
        }

        static saveShowRecentDeployments(value) {
            GM_setValue(Preferences.Keys.SHOW_RECENT_DEPLOYMENTS, value);
        }

        static getShowMinimap() {
            return GM_getValue(Preferences.Keys.SHOW_MINIMAP, true);
        }

        static saveShowMinimap(value) {
            GM_setValue(Preferences.Keys.SHOW_MINIMAP, value);
        }

        static isValidRegex(pattern) {
            if (!pattern) return true;
            try {
                new RegExp(pattern);
                return true;
            } catch (e) {
                return false;
            }
        }
    }

    var diffWindow = "<div class=\"diff-wrapper\">\n    <div class=\"diff-header\">\n        <span>Diff Version</span>\n        <a target=\"_blank\" class=\"vsr first\">\n            <div class=\"bar\"></div>\n            <span></span>\n        </a>\n        <span>&larr;</span>\n        <a target=\"_blank\" class=\"vsr second\">\n            <div class=\"bar\"></div>\n            <span></span>\n        </a>\n        <a target=\"_blank\" class=\"button fullDiff\">Full Diff</a>\n        <a class=\"button\" id=\"copy-button\">Copy</a>\n        <span class=\"close\"></span>\n    </div>\n    <div class=\"diff-changes\"></div>\n</div>";

    var releaseNotes = "<div class=\"close\"></div>\n<div class=\"prism-release-notes\">\n    <h1>Prism 2026.1.6 Release Notes</h1>\n    <br>\n    <h2>Changes:</h2>\n    <ul>\n        <li>Added: Stages where a deployment was completed within the last 24 hours now show an orange 24H badge in the top right corner. This can be disabled in the Prism settings under your Tampermonkey menu.</li>\n    </ul>\n    <p>We found it difficult sometimes to distinguish when a deployment has happened recently in a wave with multiple regions, especially if only one stage was previously blocked by an ED. This change should help make it easier to spot new deployments (and prevent future COEs 😉).</p>\n    <br><br>\n    <p>Thanks for using Prism! <br>❤️ davworth@</p>\n</div>";

    var settingsWindow = "<div class=\"prism-settings\">\n    <div class=\"close\"></div>\n    <div class=\"sidebar\">\n        <div class=\"title\">\n            <img src=\"https://davworth-tampermonkey-assets.s3.us-east-1.amazonaws.com/diff-icon.png\">Prism Settings\n        </div>\n        <ul>\n            <li data-panel=\"appearance\">Appearance</li>\n            <li data-panel=\"package-diff\">Package Diff</li>\n        </ul>\n    </div>\n    <div class=\"panel\">\n        <div class=\"subpanel\" data-id=\"appearance\">\n            <h1>Appearance</h1>\n            <h2>Colors</h2>\n            <p>Change the colors Prism uses for its heatmap.</p>\n            <select name=\"colors\">\n                <option value=\"default\">Prism Default</option>\n                <option value=\"midnight\">Prism Midnight</option>\n                <option value=\"protan\">Protanopia</option>\n                <option value=\"deuter\">Deuteranopia</option>\n                <option value=\"tritan\">Tritanopia</option>\n                <option value=\"grayscale\">Grayscale</option>\n            </select>\n\n            <hr>\n            <h2>Show recent deployments</h2>\n            <p>When enabled, an orange 24H badge is shown on all deployments made within the last 24 hours.</p>\n            <p>\n                <input type=\"checkbox\" data-id=\"recent-deployments\"/> Show Recent Deployments <br>\n                <input type=\"checkbox\" data-id=\"recent-deployments-animations\"> Enable Animation\n            </p>\n            <br>\n            <span style=\"font-size: 12px\">*Refresh to apply this setting.</span>\n\n            <hr>\n            <h2>Minimap</h2>\n            <p>Show a compact pipeline overview at the top of the page.</p>\n            <p><input type=\"checkbox\" data-id=\"show-minimap\"/> Show Minimap</p>\n            <br>\n            <span style=\"font-size: 12px\">*Refresh to apply this setting.</span>\n        </div>\n        <div class=\"subpanel\" data-id=\"package-diff\" style=\"display: none;\">\n            <h1>Package Diff</h1>\n            <h2>Package Filter</h2>\n            <p>Add extra packages to diffs by regex pattern. Packages matching this pattern will be shown in addition to autobuild/target packages.</p>\n            <input type=\"text\" name=\"packageFilterRegex\" placeholder=\"e.g. MyService.*|CommonLib\" style=\"width: 100%; padding: 8px; font-family: monospace;\">\n            <p class=\"regex-error\" style=\"color: #e74c3c; font-size: 12px; margin-top: 4px; display: none;\">Invalid regex pattern</p>\n            <p style=\"font-size: 12px; color: #888; margin-top: 4px;\">Refresh the page after changing to recompute diffs.</p>\n        </div>\n    </div>\n</div>";

    var statusWindow = "<div class=\"title\">\n    <div class=\"icon\"></div>\n</div>\n<div class=\"sub\">\n    <div class=\"status pending\"></div>\n</div>\n<div class=\"body\"></div>";

    var wrapperBase = "<div class=\"heatmap-wrapper\">\n    <div class=\"topline\">\n        <div class=\"index\"></div>\n        <div class=\"vfi\"></div>\n        <div class=\"diff loading\"><span class=\"loader\"></span></div>\n    </div>\n    <div class=\"inner\">\n        <div class=\"recent-deployment\" title=\"This deployment was made in the last 24 hours\">24H</div>\n    </div>\n</div>\n";

    var wrapperVs = "<div class=\"heatmap-wrapper standalone\">\n    <div class=\"topline\">\n        <div class=\"index\"></div>\n        <div class=\"vfi\"></div>\n        <div class=\"diff loading\"><span class=\"loader\"></span></div>\n    </div>\n    <div class=\"rev\">\n        <div class=\"author\"><a target=\"_blank\">Loading Revision Info...</a></div>\n        <div class=\"date\"><a target=\"_blank\"></a></div>\n    </div>\n</div>";

    const htmlTemplates = {
        diffWindow,
        releaseNotes,
        settingsWindow,
        statusWindow,
        wrapperBase,
        wrapperVs,
    };

    class HeatMapWrapper {
        constructor(vsr, color, index) {
            this.vsr = vsr;
            this.color = color;
            this.index = index;
        }

        versionSet() {
            let element = document.createElement("div");
            element.innerHTML = htmlTemplates.wrapperVs;
            let wrapper = element.querySelector(".heatmap-wrapper");
            this.style(wrapper);
            return element;
        }

        /**
         * Original wrap method used by v1: wraps the element inside the
         * heatmap-wrapper by moving it into .inner.
         */
        wrap(elm, classes) {
            let element = document.createElement("div");
            element.innerHTML = htmlTemplates.wrapperBase;
            let wrapper = element.querySelector(".heatmap-wrapper");
            wrapper.setAttribute("data-rangeValue", this.rangeValue);
            if (classes != undefined) {
                classes.forEach(klass => wrapper.classList.add(klass));
            }
            this.style(wrapper);

            if (!Preferences.getRecentDeploymentsAnimation()) {
                element.querySelector(".recent-deployment").classList.add("no-animation");
            }

            elm.after(element);
            elm.remove();
            element.querySelector(".inner").appendChild(elm);
        }

        /**
         * Sibling-based wrap used by v2: places the heatmap-wrapper as a
         * preceding sibling rather than wrapping the element. This preserves
         * the element as a direct child of its parent so the pipeline website
         * can still locate it, while visually appearing to surround it via CSS.
         */
        wrapSibling(elm, classes) {
            let element = document.createElement("div");
            element.innerHTML = htmlTemplates.wrapperBase;
            let wrapper = element.querySelector(".heatmap-wrapper");
            wrapper.setAttribute("data-rangeValue", this.rangeValue);
            if (classes != undefined) {
                classes.forEach(klass => wrapper.classList.add(klass));
            }
            this.style(wrapper);

            let recentDeployment = element.querySelector(".recent-deployment");
            if (!Preferences.getRecentDeploymentsAnimation()) {
                recentDeployment.classList.add("no-animation");
            }

            // Insert the wrapper as a sibling before the element instead of
            // wrapping it, so the pipeline website can still find the element
            // as a direct child of its parent.
            elm.before(element);
            elm.classList.add("heatmap-target");
            elm.style.borderColor = this.color;
            elm.style.backgroundColor = `${this.color}22`;

            // Move the recent-deployment badge into the target element so it
            // overlays correctly as an absolute-positioned child.
            recentDeployment.remove();
            elm.appendChild(recentDeployment);

            // Apply the recent class to the target element itself so CSS can
            // style the badge without relying on sibling selectors (the wrapper
            // is inside a container div, not a direct sibling).
            if (classes && classes.includes("recent")) {
                elm.classList.add("recent");
            }
        }

        style(wrapper) {
            wrapper.setAttribute("data-vsr", `${this.vsr.revision}`);

            wrapper.style.borderColor = this.color;
            let innerOrRev = wrapper.querySelector(".rev, .inner");
            if (innerOrRev) {
                innerOrRev.style.backgroundColor = `${this.color}22`;
            }

            let topline = wrapper.querySelector(".topline");
            topline.style.backgroundColor = this.color;
            topline.style.color = Color.highVis(this.color);

            wrapper.querySelector(".index").innerHTML = `${this.vsr.versionSet.startsWith("PatchDeploymentService") ? "◆" : ""}${this.index}`;
            wrapper.querySelector(".vfi").innerHTML = this.vsr.revision;
        }

        /**
         * Re-applies color and label styling to an already-in-DOM wrapper element.
         * Used during in-place refresh updates to avoid removing/re-inserting DOM nodes.
         */
        updateStyle(wrapper) {
            wrapper.setAttribute("data-rangeValue", this.rangeValue);
            this.style(wrapper);
        }
    }

    class DisplayV1 {
        static apply(pipeline) {
            let versionSetWrapper = document.querySelector("div.stage.contains-vs");
            let versionSetTargets = versionSetWrapper.querySelector("ul.targets");
            let versionSetDetails = versionSetTargets.querySelector("div.target-details");

            let wrappers = {};

            for (let i = 0; i < pipeline.vfis.length; i++) {
                let range = weightedRange(pipeline.vfis.length, i);
                let wrapper = new HeatMapWrapper(pipeline.vfis[i], Preferences.colors().at(range), i);
                wrapper.rangeValue = range;
                let vsWrapper = wrapper.versionSet();
                vsWrapper.querySelector(".heatmap-wrapper").setAttribute("data-rangeValue", range);
                versionSetDetails.appendChild(vsWrapper);
                wrapper.versionSetWrapper = vsWrapper;
                wrappers[`${pipeline.vfis[i].versionSet}@${pipeline.vfis[i].revision}`] = wrapper;
            }

            let targets = Array.from(document.querySelectorAll(".stage:not(.contains-vs):not(.contains-pkg) .targets .target-wrapper-container"));
            targets.forEach(elm => {
                let targetName = elm.querySelector(".name[data-targetname]").getAttribute("data-targetname");
                let deploymentTime = new Date((pipeline.targetDeploymentTimes[targetName] ?? 0) * 1000);
                let isRecentDeployment = deploymentTime > new Date(new Date() - 86_400_000);
                if (!Preferences.getShowRecentDeployments()) {
                    isRecentDeployment = false;
                }

                let vsr = elm.getAttribute("data-vsr");
                if (vsr == null) {
                    vsr = "None@None";
                } else {
                    vsr = vsr.replace("@B", "@");
                    if (wrappers[vsr] == null) {
                        for (let vfi of Object.keys(wrappers)) {
                            if (vsr.indexOf(vfi) > -1) {
                                vsr = vfi;
                                break;
                            }
                        }
                    }
                }

                const wrapperClasses = ["v1"];
                if (isRecentDeployment) {
                    wrapperClasses.push("recent");
                }

                if (wrappers[vsr] != null) {
                    wrappers[vsr].wrap(elm, wrapperClasses);
                }
            });

            return wrappers;
        }
    }

    class DisplayV2 {
        static async apply(pipeline) {
            await this.awaitLoadCompletion();
            
            let versionSetWrapper = document.querySelector(".stage.main_vs");
            let versionSetDetails = versionSetWrapper.querySelector(".release-info");
            let artifactInfo = versionSetDetails.querySelector(".artifact-info");

            let wrappers = {};

            for (let i = 0; i < pipeline.vfis.length; i++) {
                let range = weightedRange(pipeline.vfis.length, i);
                let wrapper = new HeatMapWrapper(pipeline.vfis[i], Preferences.colors().at(range), i);
                wrapper.rangeValue = range;
                let vsWrapper = wrapper.versionSet();
                vsWrapper.querySelector(".heatmap-wrapper").setAttribute("data-rangeValue", range);
                artifactInfo.before(vsWrapper);
                wrapper.versionSetWrapper = vsWrapper;
                wrappers[`${pipeline.vfis[i].versionSet}@${pipeline.vfis[i].revision}`] = wrapper;
            }

            versionSetWrapper.querySelectorAll(".artifact-label:not(.failed-event)").forEach(e => e.style.outline = "");
            versionSetWrapper.querySelectorAll(".artifact-label:not(.failed-event) .artifact-order-id").forEach(e => e.remove());

            let targets = Array.from(document.querySelectorAll(".stage:not(.main_vs):not(.main_pkg):not(.packages):not(.consumable_envs) .targets .target-wrapper-container"));
            targets.forEach(elm => {
                let targetName = elm.getAttribute("data-testid");
                let deploymentTime = new Date((pipeline.targetDeploymentTimes[targetName] ?? 0) * 1000);
                let isRecentDeployment = deploymentTime > new Date(new Date() - 86_400_000);
                if (!Preferences.getShowRecentDeployments()) {
                    isRecentDeployment = false;
                }

                let artifact = elm.querySelector(".latest-revision .artifact-info");
                let vsr;
                if (artifact != null) {
                    let latestRevision = artifact.getAttribute("title").split(" ");
                    vsr = latestRevision[latestRevision.length - 1];
                }

                if (vsr == null || vsr == "N/A") {
                    vsr = "None@None";
                } else {
                    vsr = vsr.replace("@B", "@");
                    if (wrappers[vsr] == null) {
                        for (let vfi of Object.keys(wrappers)) {
                            if (vsr.indexOf(vfi) > -1) {
                                vsr = vfi;
                                break;
                            }
                        }
                    }
                }

                const wrapperClasses = ["v2"];
                if (isRecentDeployment) {
                    wrapperClasses.push("recent");
                }

                if (wrappers[vsr] != null) {
                    wrappers[vsr].wrapSibling(elm, wrapperClasses);
                }

                elm.querySelectorAll(".artifact-label:not(.failed-event)").forEach(e => e.style.outline = "");
                elm.querySelectorAll(".artifact-label:not(.failed-event) .artifact-order-id").forEach(e => e.remove());
            });

            return wrappers; 
        }

        /**
         * In-place update: re-apply colors and labels to all existing Prism
         * wrapper elements without removing or re-inserting any DOM nodes.
         * Called after the page auto-refreshes so wrappers remain visible
         * throughout the update instead of briefly disappearing.
         *
         * - VS revision cards: add newly-appeared VFIs, remove gone ones,
         *   recolor all survivors (the whole spectrum may shift).
         * - Target wrappers: recolor each based on the VSR it now holds.
         *
         * Returns a new wrappers map keyed by "versionSet@revision".
         */
        static update(pipeline) {
            // Build new HeatMapWrapper instances with freshly-computed colors.
            const newWrappers = {};
            for (let i = 0; i < pipeline.vfis.length; i++) {
                const range = weightedRange(pipeline.vfis.length, i);
                const wrapper = new HeatMapWrapper(pipeline.vfis[i], Preferences.colors().at(range), i);
                wrapper.rangeValue = range;
                newWrappers[`${pipeline.vfis[i].versionSet}@${pipeline.vfis[i].revision}`] = wrapper;
            }

            // --- Pass 1: VS revision cards ---
            const versionSetWrapper = document.querySelector(".stage.main_vs");
            const artifactInfo = versionSetWrapper
                ?.querySelector(".release-info .artifact-info");

            // Recolor existing cards; remove cards whose VFI is no longer present.
            document.querySelectorAll(".heatmap-wrapper.standalone").forEach(el => {
                const vsr = el.getAttribute("data-vsr");
                // Find the matching key in newWrappers by revision
                const key = Object.keys(newWrappers).find(k => k.endsWith(`@${vsr}`));
                if (key) {
                    const hw = newWrappers[key];
                    hw.versionSetWrapper = el.parentElement ?? el;
                    hw.updateStyle(el);
                } else {
                    // This VFI is no longer in the pipeline — remove its card.
                    (el.parentElement ?? el).remove();
                }
            });

            // Add cards for VFIs that don't have a card yet.
            for (const [key, hw] of Object.entries(newWrappers)) {
                const rev = pipeline.vfis.find(v => `${v.versionSet}@${v.revision}` === key)?.revision;
                const existing = document.querySelector(`.heatmap-wrapper.standalone[data-vsr="${rev}"]`);
                if (!existing && artifactInfo) {
                    const vsWrapper = hw.versionSet();
                    vsWrapper.querySelector(".heatmap-wrapper").setAttribute("data-rangeValue", hw.rangeValue);
                    artifactInfo.before(vsWrapper);
                    hw.versionSetWrapper = vsWrapper;
                }
            }

            // --- Pass 2: Target wrappers ---
            // The wrapper is now a sibling placed before the target element,
            // so we find the target via nextElementSibling instead of .inner.
            document.querySelectorAll(".heatmap-wrapper:not(.standalone)").forEach(wrapperEl => {
                const targetEl = wrapperEl.nextElementSibling;
                const artifact = targetEl?.querySelector(".latest-revision .artifact-info");
                let vsr;
                if (artifact != null) {
                    const parts = artifact.getAttribute("title").split(" ");
                    vsr = parts[parts.length - 1].replace("@B", "@");
                        // Try exact match first, then substring match.
                    if (!newWrappers[vsr]) {
                        for (const k of Object.keys(newWrappers)) {
                            if (vsr.indexOf(k) > -1) { vsr = k; break; }
                        }
                    }
                }
                const hw = vsr ? newWrappers[vsr] : null;
                if (hw) {
                    hw.updateStyle(wrapperEl);
                    targetEl.style.borderColor = hw.color;
                    targetEl.style.backgroundColor = `${hw.color}22`;
                }
            });

            return newWrappers;
        }

        /**
         * The v2 pipelines website loads stages asynchronously,
         * so we have to wait for them to finish loading before
         * we can inject prism's wrappers into the page.
         */
        static async awaitLoadCompletion() {
            return new Promise((resolve) => {
                let lastComputedTargetCount = 0;
                let interval = setInterval(() => {
                    let computedTargetCount = document.querySelectorAll(".latest-event-info, .latest-revision").length;
                    if (computedTargetCount != 0 && computedTargetCount == lastComputedTargetCount) {
                        resolve();
                        clearInterval(interval);
                    } else {
                        lastComputedTargetCount = computedTargetCount;
                    }
                }, 100);
            });
        }
    }

    /**
     * Template class for per-pipeline cache. You shouldn't use
     * this class directly since the list and data keys are empty.
     * Create a subclass with unique list and data keys.
     */
    class Cache {
        save(pipeline, key, data, lifetime = this.lifetime()) {
            data = this.transform(data);
            data._prism_lifetime = new Date().getTime() + lifetime;
            let keyList = GM_getValue(this.listKey(pipeline), []);
            if (!keyList.includes(key)) {
                keyList.push(key);
            }
            GM_setValue(this.listKey(pipeline), keyList);
            GM_setValue(this.dataKey(pipeline, key), data);
        }

        transform(data) {
            return data;
        }

        load(pipeline, key) {
            let keyList = GM_getValue(this.listKey(pipeline), []);
            if (!keyList.includes(key)) {
                return null;
            } else {
                let value = GM_getValue(this.dataKey(pipeline, key), null);
                if (value._prism_lifetime < new Date().getTime()) {
                    // Value is expired. Defer delete until the next purge
                    // but still return null;
                    return null;
                }
                return value;
            }
        }

        clean(pipeline, retainKeys) {
            let keyList = GM_getValue(this.listKey(pipeline), []);
            keyList
                .filter(key => !retainKeys.includes(key))
                .forEach(key => {
                    GM_deleteValue(this.dataKey(pipeline, key));
                });
            GM_setValue(this.listKey(pipeline), retainKeys.filter(key => keyList.includes(key)));
        }

        lifetime() {
            return 30_153_600_000_000; // 1000 years
        }
        listKey(pipeline) {}
        dataKey(pipeline, key) {}
    }

    const _path = window.location.pathname.replace(/\/+$/, "");
    const PIPELINE_NAME = _path.substring(_path.lastIndexOf("/") + 1);
    const PIPELINES_API_ENDPOINT = "https://us-west-2.prod.pipelines-api.builder-tools.aws.dev";

    class PipelinesApi {
        static async fetchOverviewInfo() {
            return new Promise(resolve => {
                xFetch(PIPELINES_API_ENDPOINT, {
                    method: "POST",
                    headers: {
                        'Content-Encoding': 'amz-1.0',
                        'Content-Type': 'application/json',
                        'X-Amz-Target': 'com.amazon.pipelinesapinativeservice.PipelinesAPINativeService.GetPipelineOverviewPageInfo',
                    },
                    data: JSON.stringify({
                        pipelineName: PIPELINE_NAME,
                    })
                }).then(response => {
                    resolve(JSON.parse(response.response));
                });
            });
        }
    }

    class VSR {
        constructor (versionSet, revision) {
            this.versionSet = versionSet;
            this.revision = revision;
        }

        name() {
            return `${this.versionSet}@${this.revision}`;
        }
    }

    class PrettyTime {
        static YEAR = 31_536_000_000;
        static MONTH = 2_592_000_000;
        static DAY = 86_400_000;
        static HOUR = 3_600_000;
        static MINUTE = 60_000;

        static one(ms) {
            let now = new Date().getTime();
            let diff = now - ms;

            let y = diff / this.YEAR;
            if (y >= 1) return `${Math.floor(y)}y ago`;

            let m = (diff % this.YEAR) / this.MONTH;
            if (m >= 1) return `${Math.floor(m)}mo ago`;
            
            let d = (diff % this.MONTH) / this.DAY;
            if (d >= 1) return `${Math.floor(d)}d ago`;

            let h = (diff % this.DAY) / this.HOUR;
            if (h >= 1) return `${Math.floor(h)}h ago`;

            let i = (diff % this.HOUR) / this.MINUTE;
            if (i >= 1) return `${Math.floor(i)}m ago`;

            return `${Math.floor((diff % this.MINUTE) / 1_000)}s ago`;
        }   
        
        static unit(x, unit) {
            return `${x} ${unit}${x != 1 ? "s" : ""} ago`
        }
    }

    class StatusWindow {
        static VALUE_PENDING = 0;
        static VALUE_SUCCESS = 1;
        static VALUE_FAILURE = -1;

        constructor() {
            this.window = document.createElement("div");
            this.window.innerHTML = htmlTemplates.statusWindow;
            this.window.classList.add("prism-window");
            this.window.addEventListener("click", () => {
                this.window.classList.toggle("expanded");
            });
            this.body = this.window.querySelector(".body");

            document.body.appendChild(this.window);
            this.ACTIONS = {};
        }

        static add(title, key) {
            this.INSTANCE.add(title, key);
        }

        add(title, key) {
            let entry = document.createElement("div");
            entry.classList.add("entry");
            entry.innerHTML = `
            <div class="status pending"></div>
            <div class="title">${title}</div>
        `;
            this.body.appendChild(entry);
            this.enable();

            this.ACTIONS[key] = {
                status: StatusWindow.VALUE_PENDING,
                entry: entry
            };
        }

        enable() {
            this.window.classList.add("active");
            this.window.querySelector(".sub .status").classList.add("pending");
            this.window.querySelector(".sub .status").classList.remove("failure", "success");
        }

        disable() {
            this.window.querySelector(".sub .status").classList.add("success");
            this.window.querySelector(".sub .status").classList.remove("failure", "pending");
            this.window.classList.remove("active");
        }

        static update(key, success) {
            this.INSTANCE.update(key, success);
        }

        update(key, success) {
            this.ACTIONS[key].status = success ? StatusWindow.VALUE_SUCCESS : StatusWindow.VALUE_FAILURE;
            let status = this.ACTIONS[key].entry.querySelector(".status");
            status.classList.remove("pending");
            if (success) {
                this.ACTIONS[key].entry.classList.add("success");
                status.classList.add("success");
                setTimeout(() => {
                    this.ACTIONS[key].entry.remove();
                    delete this.ACTIONS[key];

                    if (Object.keys(this.ACTIONS).length == 0) {
                        this.disable();
                    }
                }, 600);
            } else {
                status.classList.add("failure");
                this.window.querySelector(".sub .status").classList.add("failure");
                this.window.querySelector(".sub .status").classList.remove("pending");
            }
        }
    }

    class DiffCommon {
        static async getRawDiff(fromVsr, toVsr) {
            const vfiDiffKey = `${toVsr.name()}::${fromVsr.name()}`;
            StatusWindow.add(`Diff: ${toVsr.name()}`, vfiDiffKey);

            let vfiDiffUrl = `https://code.amazon.com/version-sets/${toVsr.versionSet}/revisions/${toVsr.revision}?previous=${fromVsr.revision}&previous_vs=${encodeURIComponent(fromVsr.versionSet)}`;
            
            return new Promise((resolve, reject) => {
                xFetch(vfiDiffUrl)
                    .then(response => {
                        let processedDiff = DiffCommon.processRawDiff(response.response);
                        StatusWindow.update(vfiDiffKey, true);
                        resolve(processedDiff);
                    })
                    .catch((reason) => {
                        StatusWindow.update(vfiDiffKey, false);
                        reject(reason);
                    });
            });
        }

        static processRawDiff(raw) {
            let dom = document.createElement("div");
            dom.innerHTML = raw;
            let packageChanges = [];
            Array.from(dom.querySelectorAll("tr.source-change, tr.branch-change")).forEach(e => {
                packageChanges.push({
                    packageName: e.querySelector("td:nth-child(1) a").innerText,
                    fromCommit: e.querySelector("td:nth-child(2) a").getAttribute("href").extract("commits/"),
                    toCommit: e.querySelector("td:nth-child(4) a").getAttribute("href").extract("commits/"),
                    branchChange: e.classList.contains("branch-change") ? e.querySelector("td:nth-child(7)").innerHTML : null,
                    branch: e.querySelector("td:nth-child(7)").innerText.trim(), 
                });
            });

            return packageChanges;
        }
    }

    /**
     * Central repository for the computed revision history
     * of all packages used in diffs for the pipeline.
     */
    class PackageHistoryRepo {
        static INSTANCE = new PackageHistoryRepo();

        constructor() {
            this.packages = {};
        }

        compute(packageName, branchName) {
            let key = this.key(packageName, branchName);
            if (this.packages[key] === undefined) {
                this.packages[this.key(packageName, branchName)] = new PackageHistory(packageName, branchName);
            }
        }

        get(packageName, branchName) {
            return this.packages[this.key(packageName, branchName)];
        }

        key(packageName, branchName) {
            return `${packageName}::${branchName}`;
        }
    }

    class PackageHistory {
        constructor(packageName, branchName) {
            this.packageName = packageName;
            this.branchName = branchName;
            this.ready = false;
            this.buildHistory();
        }

        async buildHistory() {
            const statusWindowKey = `history_${this.packageName}`;
            StatusWindow.add(`Git fetch: ${this.packageName}`, statusWindowKey);
            retry(async (resolve) => {
                let url = `https://code.amazon.com/packages/${this.packageName}/logs/heads/${this.branchName}?format=rss`;
                let rawXml = await new Promise((resolve, reject) => {
                    xFetch(url)
                    .then(response => {
                        resolve(response.response);
                    });
                });

                let xml = new DOMParser().parseFromString(rawXml, 'text/xml');
                this.history = [];
                this.historyMap = {};

                let i = 0;
                xml.querySelectorAll("channel > item").forEach(e => {
                    let entry = {
                        hash: e.querySelector("link").innerHTML.extract("commits/"),
                        date: new Date(e.querySelector("pubDate").innerHTML),
                        message: e.querySelector("title").innerHTML.extract(" "),
                        author: e.querySelector("description").innerHTML.extract("<th>Author:</th>", "</td>").extract("(", "@"),
                        index: i++
                    };
                    this.history.push(entry);
                    this.historyMap[entry.hash] = entry;
                });
                StatusWindow.update(statusWindowKey, true);
                resolve(true);
                this.ready = true;
            }, 5, () => {
                StatusWindow.update(statusWindowKey, false);
            });
        }

        changes(fromCommit, toCommit) {
            let from = this.historyMap[fromCommit];
            let to = this.historyMap[toCommit];

            if (from == undefined || to == undefined) {
                return [];
            }

            if (this.history.length < to.index) {
                return [];
            }

            if (this.history.length < from.index) {
                return this.history.slice(to.index);
            }

            return this.history.slice(to.index, from.index);
        }
    }

    class DiffCache extends Cache {
        static INSTANCE = new DiffCache();

        transform(changes) {
            changes = changes.map((e) => {
                return {
                    ...e,
                    items: e.items.map((item) => {
                        return {
                            ...item,
                            date: item.date.toISOString(),
                        };
                    }),
                };
            });
            return changes;
        }

        listKey(pipeline) {
            return `VFI_DIFF_CACHE::KEYS::${pipeline}`;
        }

        dataKey(pipeline, key) {
            return `DIFF_${pipeline}_${key}`;
        }
    }

    class ShallowDiffer {
        static async compute(fromVsr, toVsr, packages, skipCache = false) {
            if (!skipCache) {
                let cachedDiff = DiffCache.INSTANCE.load(
                    PIPELINE_NAME,
                    `${fromVsr.name()}::${toVsr.name()}`
                );
                if (cachedDiff != null) {
                    cachedDiff.forEach((e) => {
                        e.items.forEach((item) => {
                            item.date = new Date(item.date);
                        });
                    });
                    return cachedDiff;
                }
            }

            let rawDiff = await DiffCommon.getRawDiff(fromVsr, toVsr);

            rawDiff = rawDiff.filter((pkg) => {
                const inAutobuildOrTargets =
                    packages.autobuild.some((e) => e[0] == pkg.packageName) ||
                    packages.targets.some((e) => e[0] == pkg.packageName);

                if (inAutobuildOrTargets) return true;

                const regexPattern = Preferences.getPackageFilterRegex();
                if (regexPattern && Preferences.isValidRegex(regexPattern)) {
                    const regex = new RegExp(regexPattern);
                    return regex.test(pkg.packageName);
                }

                return false;
            });

            await new Promise((resolve) => {
                let interval = setInterval(() => {
                    for (let pkg of rawDiff) {
                        let history = PackageHistoryRepo.INSTANCE.get(
                            pkg.packageName,
                            pkg.branch
                        );
                        if (history == null) {
                            PackageHistoryRepo.INSTANCE.compute(
                                pkg.packageName,
                                pkg.branch
                            );
                            return;
                        }
                        if (!history.ready) {
                            return;
                        }
                    }
                    resolve();
                    clearInterval(interval);
                }, 100);
            });

            let changes = rawDiff.map((pkg) => {
                let history = PackageHistoryRepo.INSTANCE.get(
                    pkg.packageName,
                    pkg.branch
                );
                return {
                    ...pkg,
                    items: history.changes(pkg.fromCommit, pkg.toCommit),
                };
            });

            DiffCache.INSTANCE.save(
                PIPELINE_NAME,
                `${fromVsr.name()}::${toVsr.name()}`,
                changes
            );
            return changes;
        }
    }

    class DiffWindow {
        static show(changes, fromVsr, toVsr) {
            let diffWindow = document.createElement("div");
            diffWindow.classList.add("heatmap-diff-window");
            diffWindow.innerHTML = htmlTemplates.diffWindow;

            let fullDiffUrl = `https://pipelines.amazon.com/diff/?new_name=${toVsr.versionSet}&new_revision=${toVsr.revision}&new_type=VS&old_name=${fromVsr.versionSet}&old_revision=${fromVsr.revision}&old_type=VS&requestedBy=Prism`;
            diffWindow.querySelector(".button.fullDiff").setAttribute("href", fullDiffUrl);

            let vsrFirst = diffWindow.querySelector(".diff-header .vsr.first");
            let vsrSecond = diffWindow.querySelector(".diff-header .vsr.second");

            let toColor = Color.fromRgb(
                document.querySelector(`.heatmap-wrapper[data-vsr='${toVsr.revision}'] .topline`).style.backgroundColor
            ).hex();
            let fromColor = Color.fromRgb(
                document.querySelector(`.heatmap-wrapper[data-vsr='${fromVsr.revision}'] .topline`).style.backgroundColor
            ).hex();

            vsrFirst.style.borderColor = toColor;
            vsrFirst.style.backgroundColor = `${toColor}33`;
            vsrFirst.querySelector(".bar").style.backgroundColor = toColor;
            vsrFirst.querySelector("span").innerHTML = toVsr.revision;
            vsrFirst.setAttribute("href", `https://code.amazon.com/version-sets/${toVsr.versionSet}@${toVsr.revision}`);

            vsrSecond.style.borderColor = fromColor;
            vsrSecond.style.backgroundColor = `${fromColor}33`;
            vsrSecond.querySelector(".bar").style.backgroundColor = fromColor;
            vsrSecond.querySelector("span").innerHTML = fromVsr.revision;
            vsrSecond.setAttribute("href", `https://code.amazon.com/version-sets/${fromVsr.versionSet}@${fromVsr.revision}`);

            diffWindow.addEventListener("click", (event) => {
                if (event.target.is(".heatmap-diff-window") || event.target.is(".close")) {
                    diffWindow.remove();
                }
            });

            let copyButton = diffWindow.querySelector('#copy-button');
            copyButton.addEventListener('click', () => {
                navigator.clipboard.writeText(this.generateMarkdownDiff(changes, fromVsr, toVsr)).then(() => {
                    copyButton.textContent = 'Copied!';
                    setTimeout(() => copyButton.textContent = 'Copy', 2000);
                });
            });

            let changesWrapper = diffWindow.querySelector(".diff-changes");
            let commitUrl = (pkg, hash) => `https://code.amazon.com/packages/${pkg}/commits/${hash}`;

            let renderDiffChanges = (pkg) => {
                let section = document.createElement("div");
                section.classList.add("diff-section");

                section.innerHTML = `
            <h2>${pkg.packageName}</h2>
            <h3>
                <a href="${commitUrl(pkg.packageName, pkg.toCommit)}" target="_blank">${pkg.toCommit.substring(0, 8)}</a> 
                &larr;
                <a href="${commitUrl(pkg.packageName, pkg.fromCommit)}" target="_blank">${pkg.fromCommit.substring(0, 8)}</a>
            </h3>
            <div class="items"></div>
            `;

                if (pkg.branchChange != null) {
                    section.querySelector("h3").innerHTML += `
                <span class="branch-change">Changed Branch: ${pkg.branchChange}</span>
                `;
                }
                
                let itemsContainer = section.querySelector(".items");
                let renderDiffItem = (entry) => {
                    let item = document.createElement("div");
                    item.classList.add("diff-item");
                    item.innerHTML = `
                    <span class="hash">[<a href="${commitUrl(pkg.packageName, entry.hash)}" target="_blank">${entry.hash.substring(0, 8)}</a>]</span>
                    <span class="author">&lt;<a href="https://code.amazon.com/users/${entry.author}/activity" target="_blank">${entry.author}</a>&gt;</span>
                    <span class="message"><a href="${commitUrl(pkg.packageName, entry.hash)}" target="_blank">${entry.message}</a></span>
                    <span class="date">${entry.date.toISOString()}</span>
                `;
                    itemsContainer.appendChild(item);
                };

                pkg.items.forEach(renderDiffItem);
                changesWrapper.appendChild(section);
            };

            changes.forEach(renderDiffChanges);
            if (changes.length == 0) {
                changesWrapper.innerHTML += `<h3>No changes found for autobuild packages</h3><p>This was probably a merge from live.</p>`;
            }

            document.body.appendChild(diffWindow);
            setTimeout(() => {
                diffWindow.classList.add("visible");
            }, 10);
        }

        static generateMarkdownDiff(changes, fromVsr, toVsr) {
            let fullDiffUrl = `https://pipelines.amazon.com/diff/?new_name=${toVsr.versionSet}&new_revision=${toVsr.revision}&new_type=VS&old_name=${fromVsr.versionSet}&old_revision=${fromVsr.revision}&old_type=VS`;

            let markdown = `# ${Controller.defaultVersionSet}\n\n`;
            markdown += `### Diff: [${toVsr.revision} ← ${fromVsr.revision}](${fullDiffUrl})\n\n`;

            changes.forEach(pkg => {
                markdown += `## ${pkg.packageName}\n`;
                markdown += `Commit: **[${pkg.toCommit.substring(0, 8)}](https://code.amazon.com/packages/${pkg.packageName}/commits/${pkg.toCommit})** ← **[${pkg.fromCommit.substring(0, 8)}](https://code.amazon.com/packages/${pkg.packageName}/commits/${pkg.fromCommit})**\n\n`;
                if (pkg.branchChange) markdown += `*Branch Change: ${pkg.branchChange}*\n\n`;
                markdown += `| Commit | Author | Message |\n`;
                markdown += `|--------|--------|---------|\n`;
                pkg.items.forEach(item => {
                    markdown += `| [${item.hash.substring(0, 8)}](https://code.amazon.com/packages/${pkg.packageName}/commits/${item.hash}) | ${item.author} | ${item.message} |\n`;
                });
                markdown += '\n';
            });
            if (changes.length === 0) {
                markdown += 'No changes found for autobuild packages\n\nThis was probably a merge from live.\n';
            }
            return markdown;
        }
    }

    class MetadataCache extends Cache {
        static INSTANCE = new MetadataCache();

        listKey(pipeline) {
            return `VFI_META_CACHE::KEYS::${pipeline}`;
        }

        dataKey(pipeline, key) {
            return `META_${pipeline}_${key}`;
        }
    }

    class Pipeline {
        constructor(overviewInfo) {
            this.stages = {};
            this.vfis = {};
            this.targetDeploymentTimes = {};

            const invalidTargetEnvironments = ["PKG", "VS"];
            overviewInfo.stages.forEach(stage => {
                if (stage.name == "VersionSet") {
                    this.stages.versionSet = stage;

                    stage.targetsWithRevisions.forEach(target => {
                        if (target.latestRevision != undefined) {
                            this.vfis[`${target.target.name}@B${target.latestRevision.revision}`] = "";
                        }
                    });
                } else if (!invalidTargetEnvironments.includes(stage.containsTargetType) && stage.name != "ConsumedEnvs") {
                    stage.targetsWithRevisions.forEach(target => {
                        if (target.latestRevision == undefined) {
                            this.vfis["None@BNone"] = "";
                        } else {
                            this.vfis[target.latestRevision.description] = "";
                            this.targetDeploymentTimes[target.latestRevision.target.name] = target.latestRevision.revisionTime;
                        }
                    });
                }
            });

            this.vfis = Object.keys(this.vfis).map(name => {
                let comps = name.split("@B");
                return new VSR(comps[0], comps[1].replace(/-[A-Z].*$/, ''));
            });

            this.vfis.sort((a, b) => {
                if (a.versionSet == "None") {
                    return 1;
                } else if (b.versionSet == "None") {
                    return -1;
                }

                return parseInt(b.revision) - parseInt(a.revision);
            });
        }

        updateMetadata() {
            for (let vfi of this.vfis) {
                if (vfi.versionSet == "None") {
                    let wrapper = document.querySelector(`.heatmap-wrapper[data-vsr=None]`);
                    wrapper.querySelector(".rev").remove();
                    wrapper.querySelector(".topline").style.paddingBottom = "0"; 
                    continue;
                }

                let wrapper = this.wrappers[vfi.name()].versionSetWrapper;

                let cachedMetadata = MetadataCache.INSTANCE.load(PIPELINE_NAME, vfi.name());
                if (cachedMetadata != null) {
                    let authorUi = wrapper.querySelector(".author a");
                    authorUi.innerText = cachedMetadata.author;
                    authorUi.setAttribute("href", `https://code.amazon.com/users/${cachedMetadata.author}/activity`);

                    let dateUi = wrapper.querySelector(".date a");
                    dateUi.innerHTML = PrettyTime.one(new Date(cachedMetadata.date).getTime());
                    dateUi.setAttribute("href", `https://code.amazon.com/version-sets/${vfi.versionSet}@${vfi.revision}`);
                    continue;
                }

                this.fetchMetadata(vfi, wrapper);
            }
        }

        async fetchMetadata(vfi, wrapper) {
            const metaStatusKey = `meta_${vfi.name()}`;
            StatusWindow.add(`Fetching Metadata: ${vfi.versionSet}@${vfi.revision}`, metaStatusKey);
            try {
                let raw = await retry((resolve, reject) => {
                    let url = `https://code.amazon.com/version-sets/${vfi.versionSet}/revisions/${vfi.revision}`;
                    xFetch(url)
                        .then(response => {
                            resolve(response.response);
                        })
                        .catch(reason => {
                            reject(reason);
                        });
                }, 5, () => {
                    StatusWindow.update(metaStatusKey, false);
                });

                let dom = document.createElement("div");
                dom.innerHTML = raw;
                let date = new Date(dom.querySelector("span.absolute-time").innerText);
                let author = dom.querySelector("a[href^='/users/']").innerText;

                let authorUi = wrapper.querySelector(".author a");
                authorUi.innerText = author;
                authorUi.setAttribute("href", `https://code.amazon.com/users/${author}/activity`);

                let dateUi = wrapper.querySelector(".date a");
                dateUi.innerHTML = PrettyTime.one(new Date(date).getTime());
                dateUi.setAttribute("href", `https://code.amazon.com/version-sets/${vfi.versionSet}@${vfi.revision}`);

                MetadataCache.INSTANCE.save(PIPELINE_NAME, vfi.name(), {
                    author: author,
                    date: date.toISOString()
                });

                StatusWindow.update(metaStatusKey, true);
            } catch (e) {
                console.error(e);
            }
        }

        displayV1() {
            this.wrappers = DisplayV1.apply(this);
        }

        async displayV2() {
            this.wrappers = await DisplayV2.apply(this);
        }

        async computeShallowDiffs(packages) {
            let maxIndex = this.vfis.length - 1;
            if (this.vfis[maxIndex].versionSet == "None") {
                this.wrappers[this.vfis[maxIndex].name()].versionSetWrapper.querySelector(".diff").innerHTML = "";
                maxIndex--;
            }
            this.wrappers[this.vfis[maxIndex].name()].versionSetWrapper.querySelector(".diff").innerHTML = "";
            document.querySelectorAll(`.heatmap-wrapper[data-vsr='${this.vfis[maxIndex].revision}'],.heatmap-wrapper[data-vsr='None']`).forEach(e => {
                e.querySelector(".diff").innerHTML = "";
            });

            this.shallowDiffs = {};
            let diffKeys = [];
            for (let i = 0; i < maxIndex; i++) {
                let a = this.vfis[i];
                let b = this.vfis[i+1];

                this.shallowDiffs[a.revision] = await ShallowDiffer.compute(b, a, packages);
                document.querySelectorAll(`.heatmap-wrapper[data-vsr='${a.revision}'] .diff.loading`).forEach(e => {
                    e.classList.remove("loading");
                    e.innerHTML = "diff";
                    e.addEventListener("click", () => {
                        this.showDiff(a, b);
                    });
                });

                diffKeys.push(`${b.name()}::${a.name()}`);
            }

            this.tryFinishCacheUpdate(diffKeys);
        }

        tryFinishCacheUpdate(diffKeys) {
            MetadataCache.INSTANCE.clean(PIPELINE_NAME, this.vfis.map(e => e.name()));
            DiffCache.INSTANCE.clean(PIPELINE_NAME, diffKeys);
        }

        showDiff(toVsr, fromVsr) {
            DiffWindow.show(this.shallowDiffs[toVsr.revision], fromVsr, toVsr);
        }
    }

    class BMDS {
        static async getPackageVersionsByVersionSet(versionSet) {
            return new Promise(resolve => {
                xFetch(urlBuilder("https://brazil-metadata-sso.corp.amazon.com", {
                    Operation: "getPackageVersionsByVersionSet",
                    versionSet: versionSet,
                    ContentType: "JSON"
                })).then(response => {
                    resolve(JSON.parse(response.response));
                });
            });
        }
    }

    class MiniMap {
        static STAGE_ABBREV = {
            Packages: "PCK", VersionSet: "VS", PipelineUpdate: "PU", Packaging: "PKG",
            alpha: "ALP", beta: "BET", gamma: "GAM",
            "wave1-gamma": "W1G", "wave1-gamma-stability": "W1GS",
            "wave2-gamma": "W2G", "wave2-gamma-stability": "W2GS",
            "wave1-prod": "W1P", "wave1-prod-stability": "W1PS",
            "wave2-prod": "W2P", "wave2-prod-stability": "W2PS",
            "wave3-prod": "W3P", "wave3-prod-stability": "W3PS",
            "wave4-prod": "W4P", "wave4-prod-stability": "W4PS",
        };

        static remove() {
            document.getElementById("prism-minimap")?.remove();
        }

        static render(pipeline) {
            this.remove();
            if (!Preferences.getShowMinimap()) return;

            const wrappers = pipeline.wrappers || {};
            const container = document.createElement("div");
            container.id = "prism-minimap";

            const stages = document.querySelectorAll(".stage-info-and-promotion-arrow-container");
            stages.forEach(stage => {
                const stageInfo = stage.querySelector("[data-testid='stage-info']");
                if (!stageInfo) return;
                const stageEl = stageInfo.querySelector("[data-testid^='stage-']:not([data-testid='stage-info'])");
                const stageName = stageEl?.getAttribute("data-testid")?.replace("stage-", "") || "";
                const abbrev = this.STAGE_ABBREV[stageName] || stageName.substring(0, 3).toUpperCase();

                const targets = stageInfo.querySelectorAll(".target-details[data-testid='target-details']");
                if (targets.length === 0) return;

                const stageDiv = document.createElement("div");
                stageDiv.className = "prism-mm-stage";

                const title = document.createElement("div");
                title.className = "prism-mm-title";
                title.textContent = abbrev;
                title.addEventListener("click", () => stage.scrollIntoView({ behavior: "smooth", block: "center" }));
                stageDiv.appendChild(title);

                const targetsDiv = document.createElement("div");
                targetsDiv.className = "prism-mm-targets";

                let col = document.createElement("div");
                col.className = "prism-mm-col";
                let count = 0;

                targets.forEach(target => {
                    const twc = target.closest(".target-wrapper-container");
                    if (!twc) return;

                    // Look up color and index from pipeline.wrappers via the target's VSR
                    let color = "#ccc";
                    let num = "";
                    const artifact = twc.querySelector(".latest-revision .artifact-info");
                    if (artifact) {
                        const parts = (artifact.getAttribute("title") || "").split(" ");
                        let vsr = parts[parts.length - 1] || "";
                        vsr = vsr.replace("@B", "@");
                        let wrapper = wrappers[vsr];
                        if (!wrapper) {
                            for (const k of Object.keys(wrappers)) {
                                if (vsr.indexOf(k) > -1) { wrapper = wrappers[k]; break; }
                            }
                        }
                        if (wrapper) {
                            color = wrapper.color;
                            num = String(wrapper.index);
                        }
                    }

                    const box = document.createElement("div");
                    box.className = "prism-mm-box";
                    box.style.backgroundColor = color;
                    box.textContent = num;
                    box.addEventListener("click", () => twc.scrollIntoView({ behavior: "smooth", block: "center" }));

                    col.appendChild(box);
                    count++;
                    if (count >= 40) {
                        targetsDiv.appendChild(col);
                        col = document.createElement("div");
                        col.className = "prism-mm-col";
                        count = 0;
                    }
                });

                if (col.children.length > 0) targetsDiv.appendChild(col);
                stageDiv.appendChild(targetsDiv);
                container.appendChild(stageDiv);
            });

            document.body.appendChild(container);
        }
    }

    class Controller {
        static IS_V2 = window.location.hostname == "pipelines.amazon.dev";

        constructor() {
            this.packages = {
                autobuild: [],
                targets: [],
                all: [],
            };

            this.init();
        }

        async init() {
            /**
             * Initialize Pipeline
             * Start by fetching the pipeline overview info from the Pipelines API. 
             * This is the heaviest operation we will invoke on the Pipelines API and
             * should only ever be run once.
             */
            this.overviewJson = await PipelinesApi.fetchOverviewInfo();
            this.overviewJson = this.overviewJson.overviewPageInfo;

            Controller.defaultVersionSet = this.overviewJson.stages.filter(stage => stage.name == "VersionSet")[0]
                .targetsWithRevisions[0]
                .target
                .name;

            let autobuildTarget = this.overviewJson.stages.filter(stage => stage.name == "Packages");
            if (autobuildTarget.length > 0) {
                let autobuildPackages = autobuildTarget[0].targetsWithRevisions;
                autobuildPackages.forEach(p => this.packages.autobuild.push(p.target.name.split("/")));
            }

            /**
             * Fetch a list of all packages built into this version-set. We can create
             * the list of autobuild packages from the overview info, but for a complete
             * list of all packages in the VS, we must use BMDS. This can be a slow operation (5-10s),
             * so we'll do this asynchronously, but we need this data before we can compute diffs.
             */
            this.fetchPackageList();

            /**
             * Begin computing package history for autobuild packages.
             */
            this.packages.autobuild.forEach(p => {
                let [packageName, branchName] = p;
                PackageHistoryRepo.INSTANCE.compute(packageName, branchName);
            });
            this.packages.targets.forEach(p => {
                let [packageName, branchName] = p;
                PackageHistoryRepo.INSTANCE.compute(packageName, branchName);
            });

            /**
             * Determine all VFIs currently in the pipeline
             */
            this.pipeline = new Pipeline(this.overviewJson);
            if (Controller.IS_V2) {
                await this.pipeline.displayV2();
            } else {
                this.pipeline.displayV1();
            }
            this.pipeline.updateMetadata();

            /**
             * Compute shallow diff for all VFIs
             */
            this.pipeline.computeShallowDiffs(this.packages);

            if (Controller.IS_V2) {
                MiniMap.render(this.pipeline);
            }

            /**
             * Watch for dynamic page updates (React re-renders) and re-apply
             * Prism's display whenever the pipeline content changes.
             * Only the v2 site auto-refreshes its content dynamically.
             */
            if (Controller.IS_V2) {
                this.setupMutationObserver();
            }
        }

        /**
         * Set up a MutationObserver scoped only to the refresh button's
         * timestamp element ("[data-testid="timestamp-inner-content"]" inside
         * "[data-testid="refresh-button"]"). The text cycles like
         * "<1m ago" → "2m ago" → … and resets back to "<1m ago" each time
         * the page auto-refreshes its pipeline data. When the numeric minute
         * value drops (i.e. the timer resets), that is our signal to
         * re-apply Prism's display against the newly-fetched DOM.
         */
        setupMutationObserver() {
            const timeEl = document.querySelector(
                '[data-testid="refresh-button"] [data-testid="timestamp-inner-content"]'
            );
            if (!timeEl) return;

            let lastMinutes = this.parseRefreshMinutes(timeEl.textContent);

            this.observer = new MutationObserver(() => {
                const currentMinutes = this.parseRefreshMinutes(timeEl.textContent);
                if (currentMinutes < lastMinutes) {
                    // Timer reset — the page just fetched fresh pipeline data.
                    this.reinitDisplay();
                }
                lastMinutes = currentMinutes;
            });

            this.observer.observe(timeEl, {
                subtree: true,
                childList: true,
                characterData: true,
            });
        }

        /**
         * Parse the refresh button timestamp text into a numeric minute value.
         * "<1m ago" → 0, "2m ago" → 2, "10m ago" → 10
         */
        parseRefreshMinutes(text) {
            if (!text || text.trimStart().startsWith("<")) return 0;
            const match = text.match(/(\d+)/);
            return match ? parseInt(match[1], 10) : 0;
        }

        /**
         * In-place refresh: fetch new pipeline data and update all existing
         * Prism wrapper elements without removing them from the DOM.
         * Wrappers remain visible throughout so there is no visual flash.
         *
         * Guards against concurrent invocations (the MutationObserver can fire
         * multiple times in quick succession) and wraps the body in a try/catch
         * so a transient network failure leaves pipeline state intact and the
         * next timer-reset can retry cleanly.
         */
        async reinitDisplay() {
            if (!Controller.IS_V2) return;

            // Re-entrancy guard: ignore a second call while one is still in flight.
            if (this._refreshing) return;
            this._refreshing = true;

            try {
                // Re-fetch fresh overview data.
                let overviewJson = await PipelinesApi.fetchOverviewInfo();
                overviewJson = overviewJson.overviewPageInfo;

                // Build a new Pipeline object with the updated VFI list and colors.
                const pipeline = new Pipeline(overviewJson);

                // In-place update: recolor existing wrappers, add/remove VS cards.
                const newWrappers = DisplayV2.update(pipeline);

                // Commit state only after all display work succeeds so a mid-flight
                // error cannot leave this.pipeline in an inconsistent state.
                pipeline.wrappers = newWrappers;
                pipeline.updateMetadata();
                pipeline.computeShallowDiffs(this.packages);
                this.pipeline = pipeline;
                MiniMap.render(this.pipeline);
            } catch (err) {
                console.error("[Prism] reinitDisplay failed; will retry on next refresh:", err);
            } finally {
                this._refreshing = false;
            }
        }

        async fetchPackageList() {
            let packageData = await BMDS.getPackageVersionsByVersionSet(Controller.defaultVersionSet);
            packageData = packageData.getPackageVersionsByVersionSetResponse
                .getPackageVersionsByVersionSetResult;
            
            packageData.packageVersions.forEach(p => {
                this.packages.all.push([p.packageName, p.branchName]);
                let majorVersion = `${p.packageName}-${p.majorVersion}`;
                if (packageData.targets.includes(majorVersion)) {
                    this.packages.targets.push([p.packageName, p.branchName]);
                }
            });
        }
    }

    class Request {
        constructor() {

        }
        method() {
            throw new Error("Request is an abstract class.");
        }
        postBody() {
            return {};
        }
    }

    class GetInstallsRequest extends Request {
        constructor() {
            super();
        }

        method() {
            return "get-install-count:prism";
        }
    }

    class RegisterRequest extends Request {
        constructor() {
            super();
        }

        method() {
            return "register:prism";
        }
    }

    class DavworthAppsService {
        static async send(request) {
            const body = {
                ...request.postBody(),
                operation: request.method(),
            };
            return await xFetch("https://service.davworth.people.aws.dev", {
                method: "POST",
                data: JSON.stringify(body),
            });
        }
    }

    function registerUser() {
        const USER_UUID_KEY = "_prism_uuid";
        if (GM_getValue(USER_UUID_KEY, false) === false) {
            (async() => {
                let request = new RegisterRequest();
                let result = await DavworthAppsService.send(request);

                try {
                    let response = JSON.parse(result.response);
                    if (response.success) {
                        GM_setValue(USER_UUID_KEY, response.uuid);
                    }
                } catch (e) {
                    console.error(e);
                }
            })();
        }
    }

    function checkForInstallMilestone() {
        //Perform this check only once per day
        const INSTALL_MILESTONE_KEY = "_prism_install_milestone";
        const LAST_MILESTONE_CHECK_KEY = "_prism_install_milestone_check";
        let currentMilestone = GM_getValue(INSTALL_MILESTONE_KEY, 0);
        let lastCheck = GM_getValue(LAST_MILESTONE_CHECK_KEY, 0);
        let now = new Date().getTime();
        if (now - lastCheck < 86400000) {
            return;
        }

        GM_setValue(LAST_MILESTONE_CHECK_KEY, now);

        (async () => {
            let request = new GetInstallsRequest();
            let result = await DavworthAppsService.send(request);
            try {
                let json = JSON.parse(result.response);
                if (json.success) {
                    let count = json.count;
                    let nextMilestone = getNextInstallMilestone(currentMilestone);
                    if (count > nextMilestone) {
                        //Show milestone
                        showMilestone(getPreviousInstallMilestone(count));
                        let nextMilestone = getPreviousInstallMilestone(count);
                        GM_setValue(INSTALL_MILESTONE_KEY, nextMilestone);
                    }
                }
            } catch (e) {
                console.error(e);
            }
        })();
    }

    function showMilestone(count) {
        let element = document.createElement("div");
        element.classList.add("prism-install-milestone");
        element.innerHTML = `
        <span class="close awsui_icon_vjswe_14xxj_585 awsui_icon-left_vjswe_14xxj_585 awsui_icon_h11ix_npnzo_189 awsui_size-medium-mapped-height_h11ix_npnzo_267 awsui_size-medium_h11ix_npnzo_263 awsui_variant-normal_h11ix_npnzo_320"><svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" focusable="false" aria-hidden="true"><path d="m2 1.71 12 12M2 13.71l12-12" class="stroke-linejoin-round"></path></svg></span>
        <div>Prism Pipelines has been installed by over</div>
        <h1><i>🎉</i><span>${count}</span></h1>
        <div>Amazonians!</div>
        <p>Thanks for using Prism!</p>
        <canvas id="confetti-canvas"></canvas>
    `;
        element.querySelector(".close").addEventListener("click", () => {
            element.remove();
        });
        document.body.appendChild(element);

        let particles = [];
        function randomColor() {
            const colors = ["#ffc700", "#ff0000", "#2e3191", "#41bbc7", "#7cfc00", "#ff69b4"];
            return colors[Math.floor(Math.random() * colors.length)];
        }

        function confetti(x, y, count) {
            for (let i = 0; i < count; i++) {
                particles.push({
                    x: x,
                    y: y,
                    radius: Math.random() * 6 + 4,
                    distance: Math.random() * 80 + 40,
                    color: randomColor(),
                    tilt: Math.floor(Math.random() * 10 - 10),
                    tiltAngle: 0,
                    angle: Math.random() * 2 * Math.PI,
                    speed: Math.random() * 2 + 2,
                    gravity: 1 + Math.random(),
                    alpha: 1
                });
            }
        }

        function draw() {
            const ctx = document.getElementById("confetti-canvas").getContext("2d");
            ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
            for (let i = 0; i < particles.length; i++) {
                ctx.save();
                ctx.globalAlpha = particles[i].alpha;
                ctx.fillStyle = particles[i].color;
                ctx.beginPath();
                ctx.ellipse(particles[i].x, particles[i].y, particles[i].radius, particles[i].radius / 2, particles[i].tilt, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();

                particles[i].x += Math.cos(particles[i].angle) * particles[i].speed;
                particles[i].y += Math.sin(particles[i].angle) * particles[i].speed + particles[i].gravity;
                particles[i].tilt += 0.05;
                particles[i].alpha -= 0.0035;

                if (particles[i].y > ctx.canvas.height || particles[i].alpha <= 0) {
                    particles.splice(i, 1);
                    i--;
                }
            }
            requestAnimationFrame(draw);
        }

        window.addEventListener("resize", () => {
            let canvas = document.getElementById("confetti-canvas");
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        });

        let canvas = document.getElementById("confetti-canvas");
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        setTimeout(() => {
            let x = element.offsetLeft + (element.offsetWidth / 2);
            let y = element.offsetTop + (element.offsetHeight / 2);
            confetti(x, y, 100);
        }, 10);
        draw();
    }

    function getPreviousInstallMilestone(current) {
        let prefix = parseInt(current.toString().substring(0, 2));
        if (prefix < 25) {
            let output = "1";
            while (output.length < current.toString().length) {
                output += "0";
            }
            return parseInt(output);
        } else if (prefix < 50) {
            let output = "25";
            while (output.length < current.toString().length) {
                output += "0";
            }
            return parseInt(output);
        } else {
            let output = "5";
            while (output.length < current.toString().length) {
                output += "0";
            }
            return parseInt(output);
        }
    }

    function getNextInstallMilestone(current) {
        //Get the next milestone number. These are the nearest 1XX, 25X or 5XX numbers.
        //Read first two digits. If <=24, the next milestone is 25X. If < 50, the next milestone is 5XX.
        //Otherwise, the next milestone is 1XX.
        let prefix = parseInt(current.toString().substring(0, 2));
        if (prefix < 25) {
            let output = "25";
            while (output.length < current.toString().length) {
                output += "0";
            }
            return parseInt(output);
        } else if (prefix < 50) {
            let output = "5";
            while (output.length < current.toString().length) {
                output += "0";
            }
            return parseInt(output);
        } else {
            let output = "1";
            while (output.length <= current.toString().length) {
                output += "0";
            }
            return parseInt(output);
        }
    }

    String.prototype.extract = function(start, end = null) {
        let startIndex = this.indexOf(start) + start.length;
        if (end != null) {
            return this.substring(startIndex, this.indexOf(end, startIndex));
        } else {
            return this.substring(startIndex);
        }
    };

    HTMLElement.prototype.outerTagHTML = function() {
        return this.outerHTML.replace(this.innerHTML, "");
    };

    HTMLElement.prototype.is = function(selector) {
        let wrapper = document.createElement("div");
        wrapper.innerHTML = this.outerTagHTML();
        return wrapper.querySelector(selector) != null;
    };

    HTMLElement.prototype.queryParents = function(selector){
        if (this.parentElement == null) {
            return null;
        }

        let node = this.parentElement;
        do {
            if (node.is(selector)) {
                return node;
            }

            node = node.parentElement;
        }
        while (node.parentElement != null);

        return null;
    };

    HTMLElement.prototype.queryParentsAll = function(selector) {
        if (this.parentElement == null) {
            return [];
        }

        let node = this.parentElement;
        let output = [];
        do {
            if (node.is(selector)) {
                output.add(node);
            }

            node = node.parentElement;
        }
        while (node.parentElement != null);

        return output;
    };

    class SettingsWindow {
        static INSTANCE = new SettingsWindow();

        constructor() {
            this.element = document.createElement("div");
            this.element.innerHTML = htmlTemplates.settingsWindow;
            this.element.style.display = "none";
            document.body.appendChild(this.element);

            this.element.querySelector(".close").addEventListener("click", () => {
                this.element.style.display = "none";
            });

            // Tab switching
            this.element.querySelectorAll(".sidebar ul li").forEach((tab) => {
                tab.addEventListener("click", () => {
                    const panelId = tab.getAttribute("data-panel");
                    this.element.querySelectorAll(".subpanel").forEach((p) => {
                        p.style.display =
                            p.getAttribute("data-id") === panelId
                                ? "block"
                                : "none";
                    });
                });
            });

            this.element
                .querySelector("select")
                .addEventListener("change", function (evt) {
                    let value = this.value;
                    Preferences.saveColorKey(value);
                    SettingsWindow.recolorWrappers(Preferences.colors());
                });
            this.element.querySelector("select").value = Preferences.getColorKey();

            let showRecentDeploymentsCheckbox = this.element.querySelector("input[data-id='recent-deployments']");
            showRecentDeploymentsCheckbox.checked = Preferences.getShowRecentDeployments();
            showRecentDeploymentsCheckbox.addEventListener("change", function (evt) {
                let value = this.checked;
                Preferences.saveShowRecentDeployments(value);
            });

            let recentDeploymentsAnimationCheckbox = this.element.querySelector("input[data-id='recent-deployments-animations']");
            recentDeploymentsAnimationCheckbox.checked = Preferences.getRecentDeploymentsAnimation();
            recentDeploymentsAnimationCheckbox.addEventListener("change", function (evt) {
                let value = this.checked;
                Preferences.saveRecentDeploymentsAnimation(value);
            });

            let showMinimapCheckbox = this.element.querySelector("input[data-id='show-minimap']");
            showMinimapCheckbox.checked = Preferences.getShowMinimap();
            showMinimapCheckbox.addEventListener("change", function (evt) {
                Preferences.saveShowMinimap(this.checked);
            });

            const regexInput = this.element.querySelector(
                "input[name='packageFilterRegex']"
            );
            const regexError = this.element.querySelector(".regex-error");
            regexInput.value = Preferences.getPackageFilterRegex();
            regexInput.addEventListener("input", function () {
                const value = this.value;
                if (Preferences.isValidRegex(value)) {
                    regexError.style.display = "none";
                    Preferences.savePackageFilterRegex(value);
                } else {
                    regexError.style.display = "block";
                }
            });
        }

        static show() {
            this.INSTANCE.element.style.display = "block";
        }

        static recolorWrappers(colors) {
            document.querySelectorAll(".heatmap-wrapper").forEach((wrapper) => {
                let rangeValue = parseFloat(
                    wrapper.getAttribute("data-rangeValue")
                );
                let color = colors.at(rangeValue);
                wrapper.style.borderColor = color;
                let inner = wrapper.querySelector(".rev, .inner");
                if (inner != null) {
                    inner.style.backgroundColor = `${color}22`;
                }
                let topline = wrapper.querySelector(".topline");
                topline.style.backgroundColor = color;
                topline.style.color = Color.highVis(color);
            });
        }
    }

    const version = "2026.1.6";

    function init() {
        StatusWindow.INSTANCE = new StatusWindow();

        new Controller();

        let style = document.createElement("style");
        style.innerHTML = _CSS;
        document.body.appendChild(style);

        registerUser();
        checkForInstallMilestone();

        if (GM_getValue("PRISM_LAST_RELEASE", "") != version) {
            let releaseWindow = document.createElement("div");
            releaseWindow.classList.add("prism-release-window");
            releaseWindow.innerHTML = htmlTemplates.releaseNotes;
            releaseWindow.querySelector(".close").addEventListener("click", () => {
                releaseWindow.remove();
            });
            document.body.appendChild(releaseWindow);
            GM_setValue("PRISM_LAST_RELEASE", version);
        }
    }

    window.addEventListener("load", () => {
        init();
    });

    GM_registerMenuCommand(`Prism Settings`, () => {
        SettingsWindow.show();
    });

    GM_registerMenuCommand(`Join the Prism Slack Channel`, () => {
        window.open(`https://amazon.enterprise.slack.com/archives/C09PL85J9LH`);
    });

})();
