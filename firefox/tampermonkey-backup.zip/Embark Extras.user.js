// ==UserScript==
// @name         Embark Extras
// @namespace    http://amazon.com/
// @version      5.2
// @description  Updated for latest version of Embark. Now with Peccy & Jargon of the Day. UI tweaks to Embark to make it easier to view outstanding tasks (autoswitch to Activities tab on page load, and show outstanding tasks in a compact list).
// @author       sunsanju@
// @credits      behm@
// @match        https://embark.talent.a2z.com/launch_plans/*
// @match        https://embark.corp.amazon.com/launch_plans/*
// @updateURL    https://axzile.corp.amazon.com/-/carthamus/download_script/embark-extras.user.js
// @downloadURL  https://axzile.corp.amazon.com/-/carthamus/download_script/embark-extras.user.js
// @icon         https://www.google.com/s2/favicons?domain=amazon.com
// @grant        none
// @run-at document-end
// ==/UserScript==

window.eeMain = async () => {
    'use strict';

   console.log("Embark Extras initialized.");
   await window.elementReady("#StencilTabPanel-launch-plan-tabs-activities-panel");
   console.log("READY TO EMBARK");
   document.getElementById("StencilTabPanel-launch-plan-tabs-activities").click();

    // Extract data from page
    let eeTasks = null;
    try {
        if(!window._launchPlanData) {
            console.log("EMBARK EXTRAS: Could not access plan data");
            return;
        }
        const jsonData = window._launchPlanData;
        eeTasks = jsonData.launchPlan.launchPlanContents
            .filter(x => x.content.topic === "task" || x.content.topic === "training")
            .map(x => {
                return {
                    "completed": x.completedAt != null,
                    "topic": x.content.topic,
                    "hidden": x.hidden,
                    "duration": x.content.engagementTime,
                    "category": x.content.category,
                    "org": x.content.org,
                    "dueDate": x.dueDate.replace("_"," "),
                    "dueDateOrder": eeGetDueDateOrder(x.dueDate),
                    "order": x.order,
                    "topic": x.content.topic,
                    "fromManager": x.content.active == null,
                    "title": x.content.localized['en-us'].title
                };
            })
            .sort((a,b) => {
                if(a.dueDateOrder < b.dueDateOrder) return -1;
                if(a.dueDateOrder > b.dueDateOrder) return 1;

                if(a.topic == "training" && b.topic == "task") return -1;
                if(a.topic == "task" && b.topic == "training") return 1;

                return a.order-b.order;
            })
            .map((x,index) => { return {...x,id:index};} );
    } catch(ex) {
        console.error("Error initializing Embark Extras", ex);
    };

    if(eeTasks == null) return;

    // Inject css styles
    eeAddStyles();

    // Get stored preferences
    // Toggle Embark Extras functionality
    const prefCompactStr = localStorage.getItem('embarkPreferences_compact') !== "false" ? "completed" : "";
    // Toggle Focus Mode
    const prefFocusStr = localStorage.getItem('embarkPreferences_focus') === "true" ? "completed" : "";

    // Create and inject the containers to hold our custom UI
    let cntStr = `<div id="extRoot" style="display:flex;"><div id="extRoot_main" style="flex-basis: 0;"></div><div id="extRoot_sidebar" style="flex-grow: 1;max-width:240px;"></div></div>`;
    
    document.getElementById("StencilTabPanel-launch-plan-tabs-activities-panel").prepend(eeHtmlToElement(cntStr));

    // Create and inject the button to toggle features on/off
    const btnCompactList = eeHtmlToElement(`<button id="btnCompactList" title="Enable/disable the Embark Extras features" class="${prefCompactStr} btn btn-outline-secondary small d-flex align-items-center"><i class="i-menu" aria-hidden="true"></i><span class="mr-1">Embark Extras</span></button>`);
    // document.querySelector(".launch-plan-header button").before(btnCompactList);
    document.querySelector("h3").parentElement.querySelector("button").before(btnCompactList);
    btnCompactList.parentNode.style.display = "flex";

    btnCompactList.addEventListener('click', () => {
        if (btnCompactList.classList.contains("completed")) {
            btnCompactList.classList.remove("completed");
            localStorage.setItem('embarkPreferences_compact', false);
            location.reload();
        }
        else {
            btnCompactList.classList.add("completed");
            localStorage.setItem('embarkPreferences_compact', true);
            location.reload();
        }
    });

    if (prefCompactStr === "completed")
        eeRenderCompactListView(eeTasks);
    else return;

    // Create and inject the button to toggle features on/off
    const btnFocusMode = eeHtmlToElement(`<button id="btnFocusMode" title="Hide page headers and focus on tasks" class="${prefFocusStr} btn btn-outline-secondary small d-flex align-items-center"><i class="i-focus" aria-hidden="true"></i><span class="mr-1">Focus Mode</span></button>`);
    document.querySelector("h3").parentElement.querySelector("button").before(btnFocusMode);
    btnFocusMode.parentNode.style.display = "flex";

    btnFocusMode.addEventListener('click', () => {
        if (btnFocusMode.classList.contains("completed")) {
            btnFocusMode.classList.remove("completed");
            localStorage.setItem('embarkPreferences_focus', false);
            eeToggleFocusView(false);
        }
        else {
            btnFocusMode.classList.add("completed");
            localStorage.setItem('embarkPreferences_focus', true);
            eeToggleFocusView(true);
        }
    });

    if (prefFocusStr === "completed") {
        eeToggleFocusView(true);
    }

};

async function eeRenderCompactListView(tasks) {
    
    // Filter active tasks
    const activeTasks = tasks.filter(x => x.completed == false);
    let taskElements = null;
    const sectionToggles = document.querySelectorAll(".launch-plan-content > :not(.launch-plan-print-view) [data-test-component=StencilTriggerButton]");

    // Render the table
    let elTable = document.createElement('table');
    elTable.id = "tblActivities";
    document.getElementById("extRoot_main").append(elTable);
    let htmlStr = "";
    let prevDueDate = "";

    for(let i=0;i<activeTasks.length;i++) {
        // check if we are crossing over between sections
        let timeSwitch = false;
        let x = activeTasks[i];
        if(x.dueDate != prevDueDate) {
            timeSwitch = true;
            prevDueDate = x.dueDate;
        }
        htmlStr += `
        <tr class='${timeSwitch?'actTimeSwitch':''}'>
            <td class='fldActHeader'>${timeSwitch?x.dueDate:''}</td>
            <td><a href="#" data-title="${x.title}" class='activityScroll'>${x.title}</a></td>
            <td><div style='display:${x.fromManager?'block':'none'}' class='fldActSrc' title="Content provided by your Manager">Manager</div></td>
            <td class='fldActType'>${x.topic}</td>
            <td class='fldActDuration'>${x.duration?eeGetFriendlyDuration(x.duration):''}</td>
        </tr>
        `;
    };

    elTable.innerHTML = htmlStr;

    // TODO: Run without timeout
    setTimeout(() => {
        // Expand the activities accordion
        eeToggleSections(true);
    }, "500")


    // Add scroll handlers
    document.querySelectorAll('a.activityScroll')
    .forEach(trigger => {
        trigger.onclick = (e) => {
            e.preventDefault();

            console.log(trigger.dataset);
            let result = document.evaluate("//h5[contains(., '" + trigger.dataset.title + "')]", document, null, XPathResult.ANY_TYPE, null );
            result.iterateNext(); // ignore first result which is the Print version
            let dest = result.iterateNext();
            let offsetPosition = dest.getBoundingClientRect().top + window.pageYOffset - 50;
                console.log("--",dest.style.display, dest,offsetPosition);
                window.scrollTo({
                    top: offsetPosition,
                    behavior: "smooth"
                });
            }
    });

    eeRenderPeccy();
    eeRenderScrollToTop();
};

function eeToggleSections(makeVisible) {
    if(makeVisible)
        document.querySelectorAll(".launch-plan-content > :not(.launch-plan-print-view) [data-test-component=StencilTriggerButton][aria-expanded=false]").forEach(x=>x.click());
    else
        document.querySelectorAll(".launch-plan-content > :not(.launch-plan-print-view) [data-test-component=StencilTriggerButton][aria-expanded=true]").forEach(x=>x.click());
};

function eeToggleFocusView(state) {
    if(state) {
        document.body.classList.add("ee-focus-mode");
    }
    else {
        document.body.classList.remove("ee-focus-mode");
    }
};

// Inject css styles
function eeAddStyles() {
    // Inject necessary styles
    const addGlobalStyle=(css)=>{let head,style;head=document.getElementsByTagName('head')[0];if(!head){return}style=document.createElement('style');style.type='text/css';style.innerHTML=css;head.appendChild(style)};

    addGlobalStyle(`
    div#jargonBox p {font-size: 0.8rem;line-height: 1.4;margin: 0;}
    div#jargonBox h4 {font-size: 0.9rem;}
    #jargonBox {position: fixed;right: 32px;bottom: 48px;width: 240px;transform:rotate(358deg);}
    #jargonBoxInner {background-color: #ebf5fd;padding: 1rem;}
    .dark #jargonBoxInner {color: #161e2d;}
    .dark #jargonBoxInner h4 {color: #161e2d;}
    #jargonBox::before {content: "";background-color: #d1e4f3;position: absolute;transform: rotate(16deg);top: 10px;left: 120px;right: -10px;bottom: -10px;z-index: -1;}
    #peccy {position:fixed;right: 16px;bottom: 0px;width: 64px;height: 64px;}
    #btnCompactList, #btnFocusMode {margin-right: 0.5rem;}
    body.ee-focus-mode header,body.ee-focus-mode nav.menu, body.ee-focus-mode nav.breadcrumbs-nav, body.ee-focus-mode .launch-plan-header .ml-2, body.ee-focus-mode .launch-plan-header button:not(#btnFocusMode) {display:none !important;}
    body.ee-focus-mode .launch-plan-header h1 {margin-bottom:8px !important;}
    #tblActivities {margin-bottom: 2rem;}
    #tblActivities td {padding: 0.3rem 0.8rem;}
    #tblActivities a {text-decoration: none;min-width:480px;display:block;;padding-right:32px;}
    #tblActivities .fldActHeader {text-transform: uppercase;font-size: 0.7rem;font-weight:normal;white-space: nowrap;}
    #tblActivities .fldActDuration {padding-left:2rem;text-transform: uppercase;font-size: 0.8rem;white-space: nowrap;}
    #tblActivities .fldActSrc {text-transform: uppercase;font-size: 0.6rem;text-align:center;background-color:#ebf5fd;color:#42638a;padding:0px 8px;}
    .dark #tblActivities .fldActSrc {color:#ebf5fd;background-color:#42638a;}
    #tblActivities .fldActType {text-transform: uppercase;font-size: 0.7rem;text-align:center;padding-left:32px;}
    #tblActivities tr.actTimeSwitch:not(:first-child) td {border-top: solid 0.5px #dedede;}
    .dark #tblActivities tr.actTimeSwitch:not(:first-child) td {border-top: solid 0.5px #394451;}
    #tblPeople {background-color: #f4f4f4;padding: 1rem 1.5rem; margin-left: 3rem;}
    #tblPeople a {margin-right: 8px;margin-bottom: 8px;display:inline-block;}
    #tblPeople img {width:64px;height:64px;object-fit: cover;border-radius:8px;}
    .m-fadeOut {visibility: hidden !important;opacity: 0 !important;transition: visibility 0s linear 500ms, opacity 500ms !important;}
    .m-fadeIn {visibility: visible !important;opacity: 1 !important;transition: visibility 0s linear 0s, opacity 500ms !important;}
    #btnScrollTop {position: fixed;bottom: 0;right: 80px;text-transform: uppercase;text-decoration: none;font-size: 12px;background-color: white;padding: 4px 16px;visibility: hidden;}
    .dark #btnScrollTop {background-color: #00bbff; color: white;}
    `);
};

// Create a DOM element from an HTML string
function eeHtmlToElement(htmlStr) {
    let tmpEl = document.createElement('div');
    tmpEl.innerHTML = htmlStr;
    return tmpEl.firstChild;
};

function eeRenderPeccy() {
 // from https://w.amazon.com/bin/view/Behm/AmazonJargonOfTheDay  credits to behm@
    // TODO: Move to external resource
    const db = ["2>0. Around 2007 or so, Brian Valentine was the SVP of the Consumer Website organization, which was...",
"OP1. OP1 stands for Operational Planning - Round 1. There are a ton of misconceptions around this p...",
"CDO. Acronym for Consumer/Digital/Other. It essentially means the parts of Amazon that aren't AWS....",
"Entitlement. You'll hear entitlement used in several contexts, but they're all around how to unders...",
"Breakage. Breakage is the amount of something a customer pays for and does not use. Historically, th...",
"The Field. It took me an embarrassingly long time to understand what people were talking about when...",
"Flywheel. Outside Amazon, a flywheel is a rotating device that is used to store rotational energy. I...",
"Watermelon Goals. They're green on the outside and red on the inside! This is used to refer to a goa...",
"Fulfillment Center. Most companies call these Distribution Centers or DCs. Because of Amazon's uniq...",
"Gatekeepers. Jeff tells us in his 2012 shareholder letter even well-meaning gatekeepers slow innovat...",
"Proxies. Jeff tells us in his 2016 shareholder letter As companies get larger and more complex, ther...",
"PFR. Literally: Product Feature Request. PFRs are how the field give input into our product roadmap...",
"Working Backwards. At Amazon, we really pride ourselves on working backwards from the customer. Thi...",
"6-page narrative. Also deeply embedded in our culture is the six-page narrative, which is one partic...",
"Top-Down/Bottoms-Up. This is a way of organizing the different sources of information in a hierarchi...",
"2x2 or Two by Two. Amazon uses written narratives for decision-making, but we do use some slide-like...",
"EBC. The EBC is the 'Executive Briefing Center' which is technically a place in the Kumo building, b...",
"RTM. A specific type of EBC is the Roadmap Transparency Meeting (RTM), where the customer explains w...",
"CAB. The Customer Advisory Board is like the union of a bunch of RTMs all happening in one room. We ...",
"SI/ISV. This is industry parlance, but it was requested so here you go. These refer to types of comp...",
"Solution. When used as a noun, a solution is something that solves a problem. In our software jargon...",
"Break glass. This is an analogy to fire alarms whose switch is covered by glass to prevent accident...",
"MVP. No, not Minimum Viable Product, that's industry-wide jargon! Within Amazon, MVP refers to our ...",
"Paper cuts. A paper cut is a defect in user experience that is individually fairly minor and could b...",
"Andon Cord. The Andon Cord is a physical cord strung overhead along assembly lines in Toyota product...",
"Poison Pill. A poison pill is a data input into a system that causes it to fail. It's the suggestion...",
"Canaries. A canary generates synthetic load against our services and validates any expected outcomes...",
"Control-plane vs data-plane. We stole this terminology from the networking field. High-speed networ...",
"Static Stability. Static stability is a customer-facing concept we introduced to explain how to buil...",
"Pets vs Cattle. This refers to a mindset shift required for our human brains to interact with things...",
"Technical Debt. Engineers use this term to describe everything from critical security or availabilit...",
"Blast radius. We improve system reliability by reducing the impact of events across different axes: ...",
"Tier 1. Tier 1 is Amazon shorthand for if it breaks, it will immediately impact customers. This is ...",
"KTLO. Literally: Keeping the lights on. This is a term that we use to describe the work required to...",
"Brazil. In its early days, a lot of Amazon projects had codenames related to the Amazon river, or in...",
"Metrics Pyramid. This is an operational-readiness concept to ensure we're measuring and alarming on ...",
"AAA. This is actually pretty broad industry jargon; it's an acronym for Authentication, Authorizatio...",
"Percentiles. This is more statistics jargon than Amazon-specific, but it's so embedded in the way we...",
"Gift of Fear. The Gift of Fear is a book that was on the STeam reading club a few years back. The gi...",
"Root Cause vs Proximate Cause. Root cause analysis is about finding the systematic failures that ...",
"Black Days. Over the years AWS has had some self-inflicted injuries from deployments that happened a...",
"Call Leader. The Call Leader program is a type of bar-raiser program where people with significant o...",
"Droplet. In AWS, 'droplet' is the name for an actual physical computer that underpins EC2 or other c...",
"dom0. This was originally terminology from the open-source Xen hypervisor, but it's taken on its own...",
"Gunpowder. Gunpowder was the codename for the effort to move the dom0 configuration and control soft...",
"Dongle. The dongle was AWS' first custom network adapter that put the VPC encapsulation/decapsulatio...",
"Blackfoot. Blackfoot is a computer that plays the role of a network router, the first router that su...",
"Frupid. A portmanteau of Frugal and Stupid. The way Frugality is meant to be applied is outline...",
"Customers. Most tech companies talk about (and measure) their users. Amazon talks about its custom...",
"Bee-watcher-watcher. This is a reference to a Dr. Seuss book which contains a fun story about someon...",
"Day 1 and Day 2. Jeff always says It's still Day 1. He wants to remind us that the big important pr...",
"Bar Raiser. The original BR program was around hiring, where some expensive mistakes in the company'...",
"WALLET. This was a famous internal reply-all storm. In true Amazon fashion, there were several hilar...",
"Bikeshedding. The act of wasting time on trivial details while important matters are not appropriate...",
"Accolade. Here's a relatively new one! Way back in the day, your phone tool page included a link to ...",
"Unicorn (verb). Here's a blast from that distant past when large numbers of Amazonians worked togeth...",
"IHAC. Acronym for I have a customer... You'll often see this preamble to a technical question about...",
"Inside Baseball. This isn't unique to Amazon, Wikipedia says it refers to the minutiae and detailed ..."];
    let jargon = db[Math.floor(Math.random() * (db.length-1))];
    let jIndex = jargon.indexOf(".");

    // render and animate Peccy
    const svgEl = eeHtmlToElement(`<div id="peccyBox"><div id="jargonBox"><div id="jargonBoxInner">
    <h4>${jargon.substring(0,jIndex)}</h4><p>${jargon.substring(jIndex+1,jargon.length-1)}<a style="text-decoration:none;" target="_blank" href="https://w.amazon.com/bin/view/Behm/AmazonJargonOfTheDay">more jargon</a></p>
    </div></div>
    <a id="btnScrollTop" href="#" onclick="document.documentElement.scrollTop = 0;return false;"><i class="i-chevron-up" aria-hidden="true"></i>Back to top<i class="i-chevron-up" aria-hidden="true"></i></a>
    <a href="https://w.amazon.com/bin/view/PeculiarWays/PeccyCollection" target="_blank"><svg viewBox="0 0 30.508 36.293" height="536.29333" width="450.79999" id="peccy" version="1.1" xmlns="http://www.w3.org/2000/svg">
  <defs id="defs6"></defs>
  <g transform="matrix(0.090233, 0, 0, -0.090233, 0, 36.293259)" id="g10" style="">
    <path id="path14" style="fill:#f68d11;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 299.106 189.458 L 299.106 253.81 C 299.106 297.977 302.223 338.52 269.701 368.92 C 244.049 393.543 201.507 402.217 168.975 402.217 C 136.443 402.217 93.9 393.543 68.248 368.92 C 35.726 338.52 38.843 297.977 38.843 253.81 L 38.843 189.421 C 16.883 183.904 0 170.945 0 142.584 C 0 120.847 11.277 106.168 30.527 106.168 C 33.066 106.168 35.558 106.461 37.987 107.007 L 37.987 11.191 C 37.987 5.01 42.998 0 49.178 0 C 49.178 0 109.485 0 116.323 0 C 123.161 0 125.303 2.849 127.337 7.078 C 133.195 19.259 130.311 42.898 167.614 42.898 C 204.917 42.898 203.635 18.768 210.039 6.703 C 212.173 2.681 216.108 0 221.704 0 C 227.299 0 287.916 0 287.916 0 C 294.095 0 299.107 5.01 299.107 11.191 L 299.107 107.26 C 301.853 106.555 304.683 106.168 307.577 106.168 C 326.826 106.168 338.104 120.847 338.104 142.584 C 338.104 171.011 321.141 183.963 299.106 189.458"></path>
    <g id="mouth">
      <path id="path16" style="fill:#100f0d;fill-opacity:1;fill-rule:evenodd;stroke:none" d="M 255.694 207.201 C 232.521 190.101 198.926 181.007 169.998 181.007 C 129.454 181.007 92.944 195.994 65.316 220.94 C 63.146 222.9 65.081 225.575 67.689 224.058 C 97.497 206.713 134.36 196.266 172.432 196.266 C 198.115 196.266 226.347 201.596 252.326 212.616 C 256.242 214.277 259.527 210.035 255.694 207.201"></path>
      <path id="path18" style="fill:#100f0d;fill-opacity:1;fill-rule:evenodd;stroke:none" d="M 265.337 218.211 C 262.372 222.005 245.746 220.009 238.275 219.114 C 236.012 218.842 235.661 220.82 237.7 222.252 C 250.966 231.568 272.699 228.879 275.226 225.759 C 277.77 222.613 274.557 200.822 262.127 190.423 C 260.215 188.825 258.396 189.677 259.244 191.789 C 262.042 198.774 268.304 214.413 265.337 218.211"></path>
    </g>
    <path id="path20" style="fill: rgb(255, 255, 255); fill-opacity: 1; fill-rule: evenodd; stroke: rgb(0, 0, 0); stroke-width: 5.25px;" d="M 104.184 346.596 C 126.837 346.596 139.087 327.143 139.087 302.418 C 139.087 278.519 125.556 259.558 104.184 259.558 C 81.957 259.558 69.846 279.014 69.846 303.243 C 69.846 327.64 82.098 346.596 104.184 346.596"></path>
    <path id="path26" style="fill: rgb(255, 255, 255); fill-opacity: 1; fill-rule: evenodd; stroke-width: 5.25px; stroke: rgb(0, 0, 0);" d="M 232.345 346.596 C 254.998 346.596 267.248 327.143 267.248 302.418 C 267.248 278.519 253.717 259.558 232.345 259.558 C 210.119 259.558 198.007 279.014 198.007 303.243 C 198.007 327.64 210.26 346.596 232.345 346.596"></path>
    <g id="eyes">
      <path id="path30" style="fill:#100f0d;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 232.628 347.531 C 221.315 347.531 212.111 335.399 212.111 320.486 C 212.111 305.574 221.315 293.442 232.628 293.442 C 243.941 293.442 253.144 305.574 253.144 320.486 C 253.144 335.399 243.941 347.531 232.628 347.531"></path>
      <path id="path24" style="fill:#100f0d;fill-opacity:1;fill-rule:nonzero;stroke:none" d="M 104.467 347.531 C 93.154 347.531 83.95 335.399 83.95 320.486 C 83.95 305.574 93.154 293.442 104.467 293.442 C 115.78 293.442 124.983 305.574 124.983 320.486 C 124.983 335.399 115.78 347.531 104.467 347.531"></path>
    </g>
  </g>
</svg></a></div>`);

    document.body.append(svgEl);
};

function eeRenderScrollToTop() {
    document.addEventListener('mousemove', (e) => {
        let x = -Math.round(((window.innerWidth/2 - e.clientX)/window.innerWidth)*15);
        let y = Math.round(((window.innerHeight/2 - e.clientY)/window.innerHeight)*30);
        document.getElementById("eyes").style.transform = `translate(${x}px,${y}px)`;
        document.getElementById("mouth").style.transform = `rotate(${x/5}deg)`;
    });
    document.addEventListener('scroll', (e) => {
        if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
            document.getElementById("jargonBox").classList.add("m-fadeOut");
            document.getElementById("btnScrollTop").classList.add("m-fadeIn");
        } else {
            document.getElementById("jargonBox").classList.remove("m-fadeOut");
            document.getElementById("btnScrollTop").classList.remove("m-fadeIn");
        }
    });
};

function eeGetDueDateOrder(dueDate) {
    switch(dueDate) {
        case 'day_1': return 0;
        case 'week_1': return 1;
        case 'week_2': return 2;
        case 'week_3': return 3;
        case 'month_1': return 4;
        case 'month_2': return 5;
        case 'month_3': return 6;
    }
    return 10;
};

function eeGetFriendlyDuration(secs) {
    let mins = secs/60;
    if(mins < 60)
        return mins + ' mins';
    else {
        let hrs = mins/60;
        if(eeCountDecimals(hrs)>1) hrs = hrs.toFixed(1);
        return hrs + ((hrs>1)?' hrs':' hr');
    }
};

function eeCountDecimals(value) {
    if (Math.floor(value) === value) return 0;
    return value.toString().split(".")[1].length || 0;
};

window.sleep = async (seconds) => {
return new Promise((resolve) =>setTimeout(resolve, seconds * 1000));
};


window.addEventListener('load', async (event) => {
    //What was this for!?
    //await window.sleep(2);
    //document.getElementById("StencilTabPanel-launch-plan-tabs-activities").click();
    //window.eeMain();
});

// Detect when HTML elements have been rendered by React so we can add on to the UI
window.elementReady = async (selector) => {
  return new Promise((resolve, reject) => {
    let el = document.querySelector(selector);
    if (el) {
      resolve(el);
      return
    }
    new MutationObserver((mutationRecords, observer) => {
      // Query for elements matching the specified selector
      Array.from(document.querySelectorAll(selector)).forEach((element) => {
        resolve(element);
        //Once we have resolved we don't need the observer anymore.
        observer.disconnect();
      });
    })
      .observe(document.documentElement, {
        childList: true,
        subtree: true
      });
  });
}

// Intercept Embark API call and grab a copy of the plan data
const { fetch: originalFetch } = window;
window.fetch = async (...args) => {
    let [resource, config ] = args;
    // request interceptor here
    const response = await originalFetch(resource, config);

    if(resource && resource.url && resource.url.indexOf('v1/launch_plans')>0) {
        const clone = response.clone();
        const data = await clone.json();
        console.log("INTERCEPT:",resource.url, data);
        window._launchPlanData = data;
        window.eeMain();
    }

    // response interceptor here
    return response;
};
