// ==UserScript==
// @name         TicketFlipper
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  Flip t.corp.amazon tickets to other teams with ease
// @author       Prakash Maria Liju Paulraj
// @match        https://t.corp.amazon.com/*
// @connect      maxis-service-prod-pdx.amazon.com
// @connect      drive.corp.amazon.com
// @connect      document-versions-production.s3.us-west-2.amazonaws.com
// @icon         https://www.google.com/s2/favicons?domain=amazon.com
// @grant        GM_xmlhttpRequest
// @downloadURL  https://drive.corp.amazon.com/view/pliju@/TicketFlipper/TicketFlipper.user.js?download=true
// @updateURL    https://drive.corp.amazon.com/view/pliju@/TicketFlipper/TicketFlipper.user.js?download=true
// ==/UserScript==

(function () {
    if (window.top != window.self){
        return;
    }
    const poll = (predicate) => new Promise((res) => {
        const check = () => {
            if (predicate()) { res(predicate()); } else {
                setTimeout(check, 100);
            }
        };
        check();
    });
    var oldHref = document.location.href;
    function addPageChangeEventListener() {
        var bodyList = document.querySelector("body")
        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (oldHref != document.location.href) {
                    oldHref = document.location.href;
                    loadMain();
                }
            });
        });
        var config = {
            childList: true,
            subtree: true
        };
        observer.observe(bodyList, config);
    }
    function ajax(options) {
        const xhrPromise = new Promise((resolve, reject) => {
            GM_xmlhttpRequest({
                onload: (response) => { resolve(response); },
                onerror: (response) => { reject(response); },
                ...options,
            });
        });

        return xhrPromise;
    }
    let alias=null;
    async function get_alias()
    {
        if(alias!=null){
            return alias;
        }
        let id_url="https://maxis-service-prod-pdx.amazon.com/users/whoami";
        let id_response=await ajax({url: id_url});
        let id_response_json=JSON.parse(id_response.responseText);
        if("email" in id_response_json){
            return id_response_json.email.split('@')[0];
        }
        else{
            return null;
        }
    }
    async function get_assignee_details(resolver_group)
    {
        //Returns folder id and 1st assignee in support order, of the destination resolver group
        let encoded_resolver_group=encodeURIComponent('"'+resolver_group+'"');
        let end_point=`https://maxis-service-prod-pdx.amazon.com/groups?q=${encoded_resolver_group}`;
        let folder_id_response=await ajax({url: end_point});
        let group_json=JSON.parse(folder_id_response.responseText);
        let folder_id=group_json.documents[0].defaultTicketingFolder;
        let assignee='email-alias:nobody';
        if("rotationList" in group_json.documents[0] && group_json.documents[0].rotationList.length>0)
        {
            assignee=group_json.documents[0].rotationList[0].id;
        }
        /*for(const i in group_json.documents[0].rotationList){
            let member=group_json.documents[0].rotationList[i];
            if(member.supportOrder<support_order){ //Only <. NOT ==, else firstone will be replaced, if more than one assigned with same s.order.
                support_order=member.supportOrder;
                assignee=member.id;
            }
        }*/
        return [folder_id, assignee];
    }
    let custom_cti_backup=null
    async function get_custom_cti_json(useralias)
    {
        //having backup, so no need to fetch again, if new ticket updated in same page instead of redirecting.
        //(which generally t.corp does in search queue clicks)
        if(custom_cti_backup!=null)
        {
            return custom_cti_backup;
        }
        //let custom_cti_url=`https://drive.corp.amazon.com/view/pliju@/TicketFlipper/user_cti/${useralias}.txt`;
        let custom_cti_url=`https://drive.corp.amazon.com/view/pliju@/TicketFlipper/user_cti/${useralias}.txt?download=true`;
        let cti_response=await ajax({url: custom_cti_url});
        if(cti_response.status==200)
        {
            //Take a backup.
            custom_cti_backup=JSON.parse(cti_response.responseText.replaceAll("'",'"'));
            return custom_cti_backup;
        }
        else{
            return {};
        }
    }
    let current_ticket=null;
    async function get_ticket_id()
    {
        if(String(window.location).match("https://t.corp.amazon.com(?:/issues)?/([A-Z]\\d{1,10}).*")!==null){
            current_ticket=String(window.location).match("https://t.corp.amazon.com(?:/issues)?/([A-Z]\\d{1,10}).*")[1];
        }
        else{
            current_ticket=null;
        }
        return current_ticket;
    }
    async function call_maxis(request)
    {
        //let tt = await poll(() =>document.querySelector(`.ticket-id`));
        let ticket=await get_ticket_id();
        let maxis_url=`https://maxis-service-prod-pdx.amazon.com/issues/${ticket}/edits`;
        let maxis_response=await ajax({ method: "POST", url: maxis_url, data: JSON.stringify(request), headers:{ "Content-Type": "application/json" } });
        return maxis_response;
    }
    async function get_request(c,t,i,g)
    {
        let [f,a]=await get_assignee_details(g);
        return {
            "pathEdits":
            [
                {
                    "editAction": "PUT",
                    "path": "/extensions/tt/category",
                    "data":c
                },
                {
                    "editAction": "PUT",
                    "path": "/extensions/tt/type",
                    "data":t
                },
                {
                    "editAction": "PUT",
                    "path": "/extensions/tt/item",
                    "data":i
                },
                {
                    "editAction": "PUT",
                    "path": "/extensions/tt/assignedGroup",
                    "data":g
                },
                {
                    "editAction": "PUT",
                    "path": "/assignedFolder",
                    "data":f
                },
                {
                    "editAction": "PUT",
                    "path": "/assigneeIdentity",
                    "data":a
                },
                {
                    "path": "/next_step/action",
                    "editAction": "PUT",
                    "data": "Comment"
                }
            ]
        };
    }
    async function getAllEdits() {
        let audit_url=`https://maxis-service-prod-pdx.amazon.com/issues/${await get_ticket_id()}/edits`;
        let audit_response=await ajax({url: audit_url});
        if(audit_response.status==200)
        {
            return JSON.parse(audit_response.responseText).edits;
        }
        else{
            return [];
        }
    }
    const extensions_attributes = [
        'category',
        'type',
        'item',
        'assignedGroup',
        'impact'
    ];
    const assignee_attribute = 'assigneeIdentity';
    async function getCTIEdits(){
        const edits = await getAllEdits();
        let CTIEdits = [];

        for (let edit of edits) {
            const createDate = edit.effectiveCreateDate;
            const creater = edit.effectiveOriginator;

            if (creater.includes("TT-Migration-User")) {
                continue;
            }

            const pathEdits = edit.pathEdits;

            const result = {};

            for (let pathEdit of pathEdits) {
                const path = pathEdit.path;
                const data = pathEdit.data;
                if (path == "/") {
                    if (data[assignee_attribute]) {
                        result[assignee_attribute] = data[assignee_attribute];
                    }
                    const ticketInfo = data.extensions.tt;
                    for (let attribute of extensions_attributes) {
                        if (ticketInfo[attribute]) {
                            result[attribute] = ticketInfo[attribute];
                        }
                    }
                    break;
                } else {
                    if (path == `/${assignee_attribute}`) {
                        result[assignee_attribute] = data;
                    } else {
                        for (let attribute of extensions_attributes) {
                            if (path == `/extensions/tt/${attribute}`) {
                                result[attribute] = data;
                            }
                        }
                    }
                }
            }
            if (Object.keys(result).length > 0) {
                result.creater = creater;
                result.date = createDate;
                CTIEdits.push(JSON.parse(JSON.stringify(result)));
            }
        }
        return CTIEdits;
    }
    async function get_cti_history()
    {
        let cti_his={};
        let edits= await getCTIEdits();
        edits.reverse(); //make latest change in the top
        for(var x in edits)
        {
            if("assignedGroup" in edits[x])
            {
                cti_his[edits[x].assignedGroup]={"c":edits[x].category,"t":edits[x].type,"i":edits[x].item,"g":edits[x].assignedGroup};
            }
        }
        return cti_his;
    }
    let cti_list=[];
    let dropdown_id="TicketFlipperDropdown";
    async function flipit(){
        //let dd = await poll(() =>document.querySelector(`#${dropdown_id`));
        let current_selection=document.getElementById(dropdown_id).value;
        //Remove the prefix we added for uniqueness among history and custom list
        let list_number=Number(current_selection.split("_")[0]);
        current_selection=current_selection.substring(current_selection.indexOf("_")+1);
        if(current_selection in cti_list[list_number])
        {
            let cti=cti_list[list_number][current_selection];
            let c=cti.c;
            let t=cti.t;
            let i=cti.i;
            let g=cti.g;
            let response=await call_maxis(await get_request(c,t,i,g));
            if([200,201].indexOf(response.status)!=-1){
                document.querySelector(".header-text .category .info-value").innerText=c;
                document.querySelector(".header-text .type .info-value").innerText=t;
                document.querySelector(".header-text .item .info-value").innerText=i;
                document.querySelector(".header-text .group .info-value").innerText=g;
                console.log("TicketFlipper: [INFO] Maxis call succeeded");
            }
            else
            {
                console.log("TicketFlipper: [ERROR] MAXIS CALL FAILED");
            }
        }
        else{
            //Do nothing.
        }
    }
    function get_option(key,value)
    {
        let option=document.createElement('option');
        option.text=key;
        option.value=value;
        return option;
    }
    async function get_dropdown()
    {
        alias=await get_alias();
        let custom_cti_list={};
        if(alias!=null){
            custom_cti_list= await get_custom_cti_json(alias);
        }
        //This order is important
        cti_list=[];
        cti_list.push(custom_cti_list);
        cti_list.push(await get_cti_history());
        let dropdown=document.createElement('select');
        dropdown.id=dropdown_id;
        dropdown.appendChild(get_option("Flip this to ?",''));

        for(var i in cti_list)
        {
            if(i==1&&Object.keys(cti_list[i]).length>0)
            {
                let op=get_option("--History--",'');
                op.disabled="true";
                dropdown.appendChild(op);
            }
            for (const [key, value] of Object.entries(cti_list[i]))
            {
                dropdown.appendChild(get_option(key,i+"_"+key));
            }
        }
        dropdown.addEventListener('change',flipit);
        return dropdown;
    }
    async function loadMain()
    {
        //Consider reloading dropdown, everytime the page url changes.
        let old_ticket=current_ticket;
        let new_ticket=null;
        new_ticket=await get_ticket_id();
        if(new_ticket!==null && new_ticket!==old_ticket)
        {
            await main();
        }
    }
    function get_css(d_id){
        let css_text=`#${d_id}
    {
    width: 100%;
    background: #fff;
    border: solid #545b64 1px;
    color: #545b64;
    font-size:14px;
    font-weight: 700;
    padding-top: 4px;
    padding-bottom: 4px;
    padding-left: 20px;
    padding-right: 20px;
    cursor: pointer;
    border-top-left-radius: 2px;
    border-top-right-radius: 2px;
    }
    #${d_id}:hover
    {
    background: #f2f3f3;
    }
    #${d_id}:focus{
    background: #fff;
    color: #16191f;
    }
    #${d_id} + .edit-content-cti{
    border-bottom: solid #545b64 1px;
    border-left: solid #545b64 1px;
    border-right: solid #545b64 1px;
    border-bottom-left-radius: 2px;
    border-bottom-right-radius: 2px;
    }`;
        return css_text;
    }
    async function main(){
        //Preparing dropdown in first because, it will fetch drive even before the page loaded and get history later.
        //this makes it fast to showup.
        let dropdown=await get_dropdown();
        let left_cti_panel = await poll(() =>document.querySelector(".issue-summary-cti"));
        left_cti_panel.prepend(dropdown);
        //Adding necessary style to dom.
        var style = document.createElement('style');
        style.type = 'text/css';
        style.innerHTML = get_css(dropdown_id);
        document.getElementsByTagName('head')[0].appendChild(style);
    }
    loadMain();
    addPageChangeEventListener();
}());