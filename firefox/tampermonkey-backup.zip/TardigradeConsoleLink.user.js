// ==UserScript==
// @name        TardigradeConsoleLink
// @version     2.2.3
// @author      L7 Console and Connectivity team
// @namespace   Tardigrade
// @description Conveniently adds links to Tardigrade in the AWS Console and handle redirects.
// @downloadURL https://axzile.corp.amazon.com/-/carthamus/download_script/tardigrade-console-link.user.js
// @updateURL   https://axzile.corp.amazon.com/-/carthamus/download_script/tardigrade-console-link.user.js
// @source      https://code.amazon.com/packages/L7ConsoleTools/blobs/mainline/--/misc/tardigrade-console-link/TardigradeConsoleLink.user.js
// @website     https://w.amazon.com/bin/view/L7Console/Tardigrade/UserScripts/#HTardigradeConsoleLink
// @grant       GM_setClipboard
// @grant       GM_xmlhttpRequest
// @grant       GM_getValue
// @grant       GM_setValue
// @include     https://*.console.amazonaws-us-gov.com/*
// @include     https://console.amazonaws-us-gov.com/*
// @include     https://*.console.aws.amazon.com/*
// @include     https://console.aws.amazon.com/*
// @include     https://*.console.amazonaws.cn/*
// @include     https://console.amazonaws.cn/*
// @include     https://*.console.c2shome.ic.gov/*
// @include     https://console.c2shome.ic.gov/*
// @include     https://*.console.sc2shome.sgov.gov/*
// @include     https://console.sc2shome.sgov.gov/*
// ==/UserScript==

const USER_INFO = JSON.parse(getCookies()['aws-userInfo']);
const ACCOUNT_ID = USER_INFO.arn.split(':')[4];
const CURRENT_ROLE = USER_INFO.arn.split('/')[1];
const ACCOUNT_ALIAS = USER_INFO.alias;


/**
 * This RegExp creates 4 capturing groups:
 *  1. AWS Region (optional).
 *  2. Base domain, which could be the production, gamma or beta one.
 *  3. Pre-production stage (optional).
 *  4. Third level domain (aws or corp).
 * @type {RegExp}
 */
const DOMAIN_REGEX = /^(?:([a-z]{2}-[-a-z]{4,}-\d+)\.)?(?:console)?\.((aws|corp)\.amazon\.com|amazonaws.cn|amazonaws-us-gov.com|c2shome.ic.gov|sc2shome.sgov.gov)$/;


/**
 * Reads a param from window.location.search
 * @param {string} param to read from the query
 * @returns {string} being either the value or empty string
 */
function getParamFromQuery(param) {
  const q = window.location.search;
  if (!q || q[0] !== '?') return '';
  const params = new URLSearchParams(q.substring(1));
  return params.get(param) || '';
}

/**
 * The region will be extracted from the console endpoint
 * (ex. us-east-2.tardigradeconsole-gamma.aws.amazon.com -> us-east-2)
 * (ex. ap-southeast-2.tardigrade.aws.amazon.com  -> ap-southeast-2).
 *
 * @returns {null|string} AWS Region in the format of: us-east-1
 */
function getAWSRegionFromFQDN() {
  const match = DOMAIN_REGEX.exec(window.location.hostname);
  if (!match) return '';

  // match[1] contains the region part, that could be undefined if it not explicit
  return match[1] || '';
}

/**
 * Obtains the current AWS Region.
 * @returns {string} AWS Region in the format of: us-east-1
 */
function getAWSRegion() {
  return getAWSRegionFromFQDN() || getParamFromQuery('region') || '';
}

/**
 * Changes a domain to point to a given region.
 * If it is not a standard domain, it doesn't get changed (ie: dev domain use cases)
 *
 * @param {string} regionCode In the format of "eu-west-1"
 * @param {string} hostname Formatted as <region-code>.tardigradeconsole.aws.amazon.com
 * @returns {string}
 */
function regionDomain(regionCode, hostname = '') {
  // note: the $2 represents the base domain (the second regex capturing group)
  let template = `tardigrade${ACCOUNT_ALIAS.includes('gamma') ? '-gamma' : ''}.$2`;
  if (regionCode) template = `${regionCode}.${template}`;
  return hostname.replace(DOMAIN_REGEX, template);
}

/**
 * Creates the piece of URL query to point to a given region.
 * @param {string} regionCode In the format of "eu-west-1"
 * @returns {string}
 */
function regionQuery(regionCode) {
  return `region=${regionCode}`;
}

function regionUrl(regionCode) {
  const location = typeof window !== 'undefined' ? window.location : {};
  const domain = regionDomain(regionCode, location.hostname);
  const query = regionQuery(regionCode);
  const port = location.port ? `:${location.port}` : '';
  const path = '/tardigrade/home';
  return `https://${domain}${port}${path}?${query}`;
}

/**
 * Parses document.cookie into key/value pairs
 * @returns {Object} defining the cookie names and their values
 */
function getCookies() {
    return document.cookie.split(/;\s*/)
        .map(s => s.split('=').map(decodeURIComponent))
        .reduce((obj, [k, v]) =>
            Object.assign(obj, {[k]: v}), {});
}

function createLink (href) {
  const tardigradeConsoleLink = document.createElement('div');
  tardigradeConsoleLink.className = 'service-list-item row-1-1-79 border-1-1-81';
  tardigradeConsoleLink.innerHTML = `
    <div class="wrapper-1-1-82">
      <i class="serviceIcon-tc ico-compute service-group-icon serviceIcon-1-1-74 serviceIcon-1-1-83"></i>
      <a href="${href}" target="_blank" class="link-external">
        <span>Tardigrade</span>
      </a>
    </div>
  `;

  return tardigradeConsoleLink;
}

function getServiceListEc2Node () {
  return [
    '#awsgnav', // current console
    '#ref_1>[class*=awsui_content] [class*=grid]>[class*=row]', // new console
    '#all-services-item-ec2', // legacy console
  ].map(selector => document.querySelector(selector)).find(e => e);
}

function addLink(href, delayMilliSeconds = 0) {
  const serviceListEc2Node = getServiceListEc2Node();
  // the console may still be loading, in which case we retry later
  if (!serviceListEc2Node) return setTimeout(
    () => addLink(href, delayMilliSeconds + 100), delayMilliSeconds);

  const tardigradeConsoleLink = createLink(href);
  serviceListEc2Node.parentNode.insertBefore(tardigradeConsoleLink, serviceListEc2Node);
}

function handleTardigradeConsoleRedirect (href) {
  const redirect = location.hash.match(/^#tardigrade\/(.*)/);
  if (redirect) window.location = `${href}#${redirect[1]}`;
}

function initAwsConsole () {
  const region = getAWSRegion();
  const href = regionUrl(getAWSRegion());
  console.log('TardigradeConsoleLink', region, href);

  handleTardigradeConsoleRedirect(href);
  addLink(href);
}

if (window.location.pathname === '/console/home') {
  // only initialises the Tardigrade console link if it is on its home page
  initAwsConsole();
}

// Create functions which are known to be
// missing from Chrome's Greasemonkey API
if (typeof GM_getValue == 'undefined') {
    GM_getValue = function(name, defaultValue) {
        var value = localStorage.getItem(name);
        if (!value)
            return defaultValue;
        var type = value[0];
        value = value.substring(1);
        switch (type) {
            case 'b':
                return value == 'true';
            case 'n':
                return Number(value);
            default:
                return value;
        }
    }
}

if (typeof GM_setValue == 'undefined') {
    GM_setValue = function(name, value) {
        value = (typeof value)[0] + value;
        localStorage.setItem(name, value);
    }
}

if (typeof GM_log == 'undefined') {
    GM_log = function(message) {
        console.log(message);
    }
}
