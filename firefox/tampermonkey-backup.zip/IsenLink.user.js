
// ==UserScript==
// @name        IsenLink
// @downloadURL https://improvement-ninjas.amazon.com/GreaseMonkey/isenLink.user.js
// @updateURL https://improvement-ninjas.amazon.com/GreaseMonkey/isenLink.user.js
// @namespace   IsenLink
// @grant       GM_setClipboard
// @grant       GM.setClipboard
// @grant       GM_xmlhttpRequest
// @grant       GM.xmlHttpRequest
// @grant       GM_getValue
// @grant       GM.getValue
// @grant       GM_setValue
// @grant       GM.setValue
// @grant       GM_openInTab
// @grant       GM.openInTab
// @description Generate tiny url'd links to aws console pages through isengard deep link feature here: https://w.amazon.com/bin/view/AWS_IT_Security/Isengard/Isengard_FAQ/#HHowcanIuseIsengard27sdeeplinkingfeature3F
// @include     https://*.console.amazonaws-us-gov.com/*
// @include     https://console.amazonaws-us-gov.com/*
// @include     https://*.console.aws.amazon.com/*
// @include     https://console.aws.amazon.com/*
// @exclude     https://global.console.aws.amazon.com/*
// @include     https://*.console.amazonaws.cn/*
// @include     https://console.amazonaws.cn/*
// @include     https://*.console.c2shome.ic.gov/*
// @include     https://console.c2shome.ic.gov/*
// @include     https://*.console.sc2shome.sgov.gov/*
// @include     https://console.sc2shome.sgov.gov/*
// @include     https://*.console.csphome.adc-e.uk/*
// @include     https://console.csphome.adc-e.uk/*
// @include     https://*.console.csphome.hci.ic.gov/*
// @include     https://console.csphome.hci.ic.gov/*
// @include     https://*.console.amazonaws-eusc.eu/*
// @include     https://console.amazonaws-eusc.eu/*
// @include     https://*.console.aws-dev.amazon.com/*
// @include     https://console.aws-dev.amazon.com/*
// @include     https://awsc-integ.aws.amazon.com/*
// @include     https://*.awsc-integ.aws.amazon.com/*
// @include     https://awsc-preprod.aws.amazon.com/*
// @include     https://*.awsc-preprod.aws.amazon.com/*
// @require     https://improvement-ninjas.amazon.com/GreaseMonkey/gm4-polyfill.js
// @sandbox     JavaScript
// @version     1.40
// ==/UserScript==

const SESSION_ARN = getSessionArn();
const PARTITION = SESSION_ARN.split(':')[1];
const ACCOUNT_ID = SESSION_ARN.split(':')[4];
const CURRENT_ROLE = SESSION_ARN.split('/')[1];
const ROLE_CACHE_KEY = 'isenlink-roles';
const SESSION_DIFFERENTIATOR = getSessionDifferentiator();

/**
 * Returns true if the current page is an aws-dev console URL
 * @returns {Boolean}
 */
function isAwsDev() {
    return top.location.hostname.endsWith('.console.aws-dev.amazon.com') ||
           top.location.hostname === 'console.aws-dev.amazon.com';
}

/**
 * Returns true if the current page is a non-prod console URL (integ or preprod),
 * including subdomain-based variants like <id>.<region>.awsc-preprod.aws.amazon.com
 * @returns {Boolean}
 */
function isAwsNonProd() {
    const hostname = top.location.hostname;
    return hostname === 'awsc-integ.aws.amazon.com' ||
           hostname === 'awsc-preprod.aws.amazon.com' ||
           hostname.endsWith('.awsc-integ.aws.amazon.com') ||
           hostname.endsWith('.awsc-preprod.aws.amazon.com');
}

function gmRequest(details) {
    return new Promise((resolve, reject) => {
        GM.xmlHttpRequest({
            ...details,
            onload: resolve,
            onerror: reject,
            ontimeout: reject,
            onabort: reject,
        });
    });
}

function getRedirectURIHostFromAuthorizeUrlIfItExists(authorizeUrl) {
    try {
        const url = new URL(authorizeUrl);
        const parsedRedirectURI = url.searchParams.get("redirect_uri");
        if (!parsedRedirectURI) {
            return null;
        }
        return new URL(parsedRedirectURI).host;
    } catch (e) {
        console.error(e);
        return null;
    }
}

function isExpectedTinyAuthorizeRedirect(authorizeUrl, expectedTinyHost) {
    try {
        const url = new URL(authorizeUrl);
        if (url.pathname !== "/SSO/redirect") {
            return false;
        }

        const redirectUri = url.searchParams.get("redirect_uri");
        if (!redirectUri) {
            return false;
        }

        const redirectUrl = new URL(redirectUri);
        return (
            redirectUrl.host === expectedTinyHost &&
            redirectUrl.pathname === "/submit/url"
        );
    } catch (e) {
        return false;
    }
}

/**
 * Extracts session ARN either from awsc-session-data meta tag or deprecated aws-userInfo cookie
 * @returns {String} session ARN
 */
function getSessionArn() {
    const sessionMetaTag = document.querySelector('meta[name="awsc-session-data"]');
    if(sessionMetaTag) {
        return JSON.parse(sessionMetaTag.content).sessionARN;
    }

    const legacyUserInfoCookie = getCookies()['aws-userInfo'];
    if(legacyUserInfoCookie) {
        return JSON.parse(legacyUserInfoCookie).arn;
    }

    throw new Error("IsenLink was not able to extract user session");
}

/**
 * Extracts session differentiator for multi-session Prism mode
 * @returns {String} session differentiator, if present
 */
function getSessionDifferentiator() {
    const sessionMetaTag = document.querySelector('meta[name="awsc-session-data"]');
    if(sessionMetaTag) {
        return JSON.parse(sessionMetaTag.content).sessionDifferentiator;
    }
    return "";
}

/**
 * Parses document.cookie into key/value pairs
 * @returns {Object} defining the cookie names and their values
 */
function getCookies() {
    return document.cookie.split(/;\s*/)
        .map(s => s.split('=').map(decodeURIComponent))
        .reduce((obj, [k, v]) =>
            Object.assign(obj, {[k]: v}), {});
}

/**
 * Converts object to query string
 * @param {Object} params - query string params as key/value pairs in object
 * @returns {String} Encoded query string of params
 */
function serialize_querystring(params) {
    return Object.entries(params)
        .map(pair => pair.map(encodeURIComponent).join('='))
        .join('&');
}

/**
 * Checks if account is managed by isengard
 * @returns {Boolean}
 */
function isManagedByIsengard() {
    return SESSION_ARN.endsWith('-Isengard');
}

function isNewNav() {
    let mezzMetaTag = document.head.querySelector("meta[id^='awsc-widget-']");
    if (mezzMetaTag) {
        let content = mezzMetaTag.getAttribute('content');
        return content && content === "1"
    }
    return false;
}

/**
 * Normalizes a non-prod console URL (aws-dev, integ, preprod) to its equivalent
 * standard aws console URL.
 *
 * aws-dev example:
 *   https://009703923026-xecdvtof--478310124331-elephant.us-west-2.console.aws-dev.amazon.com/rds/home#foo
 *   -> https://us-west-2.console.aws.amazon.com/rds/home#foo
 *
 * preprod/integ subdomain example:
 *   https://767770409551-axuhq7pa.us-west-2.awsc-preprod.aws.amazon.com/rds/home?region=us-west-2#
 *   -> https://us-west-2.console.aws.amazon.com/rds/home?region=us-west-2#
 *
 * preprod/integ flat example:
 *   https://awsc-preprod.aws.amazon.com/rds/home#foo
 *   -> https://console.aws.amazon.com/rds/home#foo
 *
 * @param {String} url
 * @returns {String} normalized URL
 */
function normalizeNonProdUrl(url) {
    // Normalize aws-dev URLs: https://<anything>.<region>.console.aws-dev.amazon.com/<path>
    if (isAwsDev()) {
        const replaced = url.replace(
            /^https:\/\/[^.]+\.([a-z0-9-]+)\.console\.aws-dev\.amazon\.com\//,
            'https://$1.console.aws.amazon.com/'
        );
        if (replaced !== url) return replaced;

        // Flat aws-dev URL fallback: https://console.aws-dev.amazon.com/<path>
        return url.replace(
            /^https:\/\/console\.aws-dev\.amazon\.com\//,
            'https://console.aws.amazon.com/'
        );
    }

    if (isAwsNonProd()) {
        // Normalize subdomain-based integ/preprod URLs:
        // https://<id>.<region>.awsc-integ.aws.amazon.com/<path>
        // https://<id>.<region>.awsc-preprod.aws.amazon.com/<path>
        const subdomainMatch = url.match(
            /^https:\/\/[^.]+\.([a-z0-9-]+)\.awsc-(?:integ|preprod)\.aws\.amazon\.com\//
        );
        if (subdomainMatch) {
            const region = subdomainMatch[1];
            return url.replace(
                subdomainMatch[0],
                `https://${region}.console.aws.amazon.com/`
            );
        }

        // Normalize flat integ/preprod URLs:
        // https://awsc-integ.aws.amazon.com/<path>
        // https://awsc-preprod.aws.amazon.com/<path>
        return url.replace(
            /^https:\/\/awsc-(?:integ|preprod)\.aws\.amazon\.com\//,
            'https://console.aws.amazon.com/'
        );
    }

    return url;
}

/**
 * Builds isengard federated url for current AWS page
 * @param {String} role [current role] - the role to use in the federated url
 * @returns {String} The federated url
 */
function getFederatedUrl(role=CURRENT_ROLE) {
    let destination = top.location.href;

    // Normalize non-prod URLs (aws-dev, integ, preprod) to standard console URLs
    // before passing to Isengard
    if (isAwsDev() || isAwsNonProd()) {
        destination = normalizeNonProdUrl(destination);
    } else {
        // The destination URL cannot contain Prism session differentiator (or SignIn returns 400)
        destination = destination.replace(`https://${SESSION_DIFFERENTIATOR}.`, "https://");
    }

    // Add support for long CloudWatch URLs - https://t.corp.amazon.com/V275457976.
    destination = destination.replace(/\.com\/cloudwatch\/home/, '.com/cloudwatch/deeplink.js');

    let domain = 'isengard.amazon.com';

    // Set Isengard domain for non-Classic partitions
    if (PARTITION === 'aws-cn') {
        domain = 'isengard.cn-northwest-1.amazonaws.com.cn';
    } else if (PARTITION === 'aws-us-gov') {
        domain = 'isengard.pdt.aws-border.com';
    } else if (PARTITION === 'aws-iso') {
        domain = 'isengard.dca.c2s-border.ic.gov';
    } else if (PARTITION === 'aws-iso-b') {
        domain = 'isengard.sc2s.sgov.gov';
    } else if (PARTITION === 'aws-iso-e') {
        domain = 'isengard.ncl.aws-border.adc-e.uk';
    } else if (PARTITION === 'aws-iso-f') {
        domain = 'isengard.ale.aws-border.hci.ic.gov';
    } else if (PARTITION === 'aws-eusc') {
        domain = 'isengard.eusc-de-east-1.amazonaws.eu';
    }

    return `https://${domain}/federate?` + serialize_querystring({
        account: ACCOUNT_ID,
        role: role,
        destination: destination,
    });
}

/**
 * Gets tiny url for current AWS page, federated through isengard
 * @returns {Promise} The resulting url
 */
async function getTinyLink() {
    // Disable Tiny URL for THF (aws-eusc) as the deep links might contain
    // CCM (Customer Created Metadata)
    if (PARTITION === 'aws-eusc') {
        return Promise.resolve(getFederatedUrl());
    }

    let domain = 'tiny.amazon.com';

    // Set Tiny domain in non-Classic partitions
    if (PARTITION === 'aws-iso') {
        domain = 'y.dca.c2s-border.ic.gov';
    } else if (PARTITION === 'aws-iso-b') {
        domain = 'y.lck.aws-border.sgov.gov';
    } else if (PARTITION === 'aws-iso-e') {
        domain = 'tiny.a2z.adc-e.uk';
    } else if (PARTITION === 'aws-iso-f') {
        domain = 'tiny.a2z.hci.ic.gov';
    }

    const thisUrl = `https://${domain}/submit/url?` + serialize_querystring({
        name: getFederatedUrl(),
        comment: 'IsenLink',
    });

    const requestDetails = {
        method: 'GET',
        url: thisUrl,
        headers: { 'Accept': 'application/json' },
    };

    let response = await gmRequest(requestDetails);

    if (
        response.status === 403 &&
        typeof response.finalUrl === 'string' &&
        isExpectedTinyAuthorizeRedirect(response.finalUrl, domain)
    ) {
        console.warn('Tiny request hit MCS; authorizing exact Midway URL from page context', response.finalUrl);

        await callAuthorize(response.finalUrl);

        // Retry exactly once after authorization succeeds.
        response = await gmRequest(requestDetails);
    }

    if (response.status === 401) {
        // Off VPN, AEA is used to auth against tiny, in Firefox w/ Containers, the midway cookie isn't available,
        // so a workaround is to open a new tab to get the tiny url.
        GM.openInTab(thisUrl, false);
        return getFederatedUrl();
    }

    if (response.status >= 400) {
        throw new Error(`Tiny request failed with status ${response.status} (${response.finalUrl || thisUrl})`);
    }

    const data = JSON.parse(response.responseText);
    return data.short_url;
}

/**
 * Gets roles for current account
 * Caches most recent account's roles to minimize requests to isengard.
 * @returns {String[]} List of roles for current account
 */
async function getRolesForAccount() {
    const raw_data = await GM.getValue(ROLE_CACHE_KEY);
    if (raw_data) {
        const cachedInfo = JSON.parse(raw_data);
        if (cachedInfo.accountId == ACCOUNT_ID) {
            return cachedInfo.roles;
        }
    }
    let domain = 'isengard-service.amazon.com';

    // Set Isengard service domain for non-Classic partitions
    if (PARTITION === 'aws-cn') {
        domain = 'isengard-service.bjs.aws-border.com';
    } else if (PARTITION === 'aws-us-gov') {
        domain = 'isengard-service-us-gov-west-1.amazon.com';
    } else if (PARTITION === 'aws-iso') {
        domain = 'isengard-service.dca.c2s-border.ic.gov';
    } else if (PARTITION === 'aws-iso-b') {
        domain = 'isengard-service.sc2s.sgov.gov';
    } else if (PARTITION === 'aws-eusc') {
        domain = 'isengard-service.eusc-de-east-1.amazonaws.eu';
    }

    return new Promise((resolve, reject) => {
        GM.xmlHttpRequest({
            method: 'POST',
            url: `https://${domain}/`,
            headers: {
                'Content-Type': 'application/json; charset=UTF-8',
                'Content-Encoding': 'amz-1.0',
                'X-Amz-Target': 'com.amazon.isengard.coral.IsengardService.GetPermissionsForUser',
            },
            onload: response => {
                const data = JSON.parse(response.responseText);
                const accounts = data.PermissionsForUserList || [];
                const current_account = accounts.find((account) => account.AWSAccountID == ACCOUNT_ID);
                if (!current_account) {
                    return reject();
                }

                const roles = current_account.IAMRoleNameList;
                const sorted_roles = roles.sort((a, b) => a.localeCompare(b, undefined, {sensitivity: 'base'}));
                GM.setValue(ROLE_CACHE_KEY, JSON.stringify({accountId: ACCOUNT_ID, roles: roles}))
                  .then(result => resolve(roles));
            }
        });
    });
}

/**
 * Adds role switcher functionality to account menu
 */
async function addRoleSwitcherOldNav() {
    // role switcher
    const accountFooter = document.getElementById('awsc-username-menu-footer');
    const roleContainer = document.createElement('div');
    roleContainer.style = 'border-top: solid 1px #ccc; padding-top: 15px;';

    const roles = await getRolesForAccount();
    roles.forEach((role) => {
        const isCurrentRole = role == CURRENT_ROLE;
        const elem = document.createElement('a');
        elem.text = role;
        elem.href = 'javascript:';

        if (isCurrentRole) {
            elem.style = `
                cursor: default;
                font-weight: bold;
                border-left: solid 3px #f91;
                margin-left: -8px;
                padding-left: 8px;
                pointer-events: none;
                `;
        } else {
            elem.addEventListener('click', () => {top.location = getFederatedUrl(role)});
        }
        roleContainer.appendChild(elem);
    });

    // Only show roles if at least 1 role is available. For cases when the account
    // has no roles managed through isengard
    if (roles.length) {
        accountFooter.parentNode.insertBefore(roleContainer, accountFooter);
    }
}

async function addRoleSwitcherNewNav() {
    // role switcher
    const menu = document.querySelector('#menu--account');
    const hrClone = menu.querySelector('hr').cloneNode();
    const menuList = document.querySelector('#menu--account ul[role=menu]');
    const listClassList = menuList.querySelector('li[role=menuitem]').classList;
    const linkClassList = menuList.querySelector('li a').classList;

    const roleLinks = (await getRolesForAccount()).map((role) => {
        const isCurrentRole = role == CURRENT_ROLE;
        const elem = document.createElement(isCurrentRole ? 'span' : 'a');
        elem.textContent = role;
        elem.classList = linkClassList;

        if (isCurrentRole) {
            elem.style = 'color: #95a5a6 !important;';
        } else {
            elem.href = getFederatedUrl(role);
            if (navigator.userAgent.toLowerCase().includes("firefox")) {
                elem.addEventListener('click', async function(e) {
                    // Prevent default so we can open in the default container
                    e.preventDefault();
                    GM.openInTab(elem.href, {
                        active: true,
                        container: 0,
                        insert: true,
                    });
                }, true);
            }
        }

        const roleContainer = document.createElement('li');
        roleContainer.classList = listClassList;
        roleContainer.appendChild(elem);

        return roleContainer;
    });
    // Only show roles if at least 1 role is available. For cases when the account
    // has no roles managed through isengard
    if (roleLinks.length) {
        menuList.append(hrClone);
        roleLinks.forEach(x => menuList.append(x));
    }
}

function getOldNav() {
    return document.getElementById('nav-usernameMenu');
}

async function updateOldNav() {
    const navUserNameMenu      = getOldNav();

    // We seem to fire early and litter console logs, sometimes.
    if (navUserNameMenu === null) return;

    const isenTextNode         = document.createTextNode('IsenLink');
    const elemNavMenuSeparator = document.createElement('div');
    const elemIsenLink         = document.createElement('a');

    elemNavMenuSeparator.className = 'nav-menu-separator';

    elemIsenLink.id = 'nav-isenlink';
    elemIsenLink.title = 'IsenLink';
    elemIsenLink.className = 'nav-elt nav-menu';

    const subDiv = document.createElement('div');
    subDiv.className = 'nav-elt-label';
    subDiv.appendChild(isenTextNode);

    elemIsenLink.appendChild(subDiv);

    // Add isenlink elements to the page
    navUserNameMenu.parentNode.insertBefore(elemIsenLink, navUserNameMenu);
    navUserNameMenu.parentNode.insertBefore(elemNavMenuSeparator, navUserNameMenu);

    var timeoutId;
    elemIsenLink.addEventListener('click', async function(e) {
        // Prevent default so we don't navigate away when trying to copy to clipboard
        e.preventDefault();

        clearTimeout(timeoutId);

        var tinyLink = await getTinyLink();
        GM.setClipboard(tinyLink);

        isenTextNode.nodeValue = 'IsenLink copied!';
        timeoutId = setTimeout(function() {
            isenTextNode.nodeValue = 'IsenLink';
        }, 1500);
    }, true);

    var updateIsenlink = () => {elemIsenLink.href = getFederatedUrl()};

    updateIsenlink();
    window.addEventListener('popstate', updateIsenlink);

    await addRoleSwitcherOldNav(navUserNameMenu)
        .catch(() => console.warn('Unable to add role switcher'));
}

function getNewNav() {
    return document.getElementById('awsc-navigation__more-menu--list');
}

async function updateNewNav() {

    const menuList = getNewNav();
    const listClassList = menuList.querySelector('li').classList;
    const linkClassList = menuList.querySelector('li a').classList;
    const buttonClassList = menuList.querySelector('li button').classList;
    const listElementForIsenLink = document.createElement('li');
    listElementForIsenLink.classList = listClassList;
    const linkElementForIsenLink = document.createElement('a');
    linkElementForIsenLink.classList = linkClassList;
    const buttonElementForIsenLink = document.createElement('button');
    buttonElementForIsenLink.innerText = 'IsenLink';
    buttonElementForIsenLink.classList = buttonClassList;

    listElementForIsenLink.appendChild(linkElementForIsenLink);
    linkElementForIsenLink.appendChild(buttonElementForIsenLink);
    menuList.prepend(listElementForIsenLink);

    buttonElementForIsenLink.id = 'nav-isenlink';
    buttonElementForIsenLink.title = 'IsenLink';

    var timeoutId;
    buttonElementForIsenLink.addEventListener('click', async function(e) {
        // Prevent default so we don't navigate away when trying to copy to clipboard
        e.preventDefault();

        clearTimeout(timeoutId);

        var tinyLink = await getTinyLink();
        GM.setClipboard(tinyLink);

        buttonElementForIsenLink.innerText = 'IsenLink copied!';
        timeoutId = setTimeout(function() {
            buttonElementForIsenLink.innerText = 'IsenLink';
        }, 1500);
    }, true);

    // The following is to support right click -> copy link, to skip Tiny if desired.

    function updateIsenlink() {
        try {
            linkElementForIsenLink.href = getFederatedUrl();
        } catch(error) {
            // We're hooking into window.history below, so let's be as defensive as
            // possible about suppressing any exceptions we might throw.
            // Otherwise we could impact console functionality.
            console.log(error);
        }
    }

    updateIsenlink();
    window.addEventListener('popstate', updateIsenlink);

    // React Router seems not to emit popstate events on navigation (try new S3 in Firefox).
    // Wrap push/replace so we can update the link appropriately.
    const originalPushState = window.history.pushState;
    const originalReplaceState = window.history.replaceState;
    window.history.pushState = function() {
        const result = originalPushState.apply(window.history, arguments);
        updateIsenlink();
        return result;
    }
    window.history.replaceState = function() {
        const result = originalReplaceState.apply(window.history, arguments);
        updateIsenlink();
        return result;
    }
    const navUserNameMenu = document.getElementById('nav-usernameMenu');
    await addRoleSwitcherNewNav(navUserNameMenu)
        .catch((e) => console.warn('Unable to add role switcher', e));
}

function isReady() {
    function isLinkStyleAvailable(menuList) {
        return menuList.querySelector('li a') !== null;
    }

    function isAccountMenuAvailable() {
        return document.querySelector('#menu--account ul[role=menu]') !== null;
    }

    const newNav = getNewNav();
    if (newNav !== null) {
        return (isLinkStyleAvailable(newNav) && isAccountMenuAvailable())
    }
    return !!getOldNav();
}

function waitForDocument() {
    return new Promise(resolve => {
        if (isReady()) {
            resolve();
            return;
        }
        const observer = new MutationObserver(mutations => {
            if (isReady()) {
                resolve();
                observer.disconnect();
            }
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    });
}

(async () => {
    if (!isManagedByIsengard()) return;
    await waitForDocument();

    if (isNewNav()) {
        await updateNewNav();
    } else {
        await updateOldNav();
    }
})();