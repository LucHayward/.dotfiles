// *******************************************************
// For all changes run through the test steps at:
// https://w.amazon.com/index.php/IGraphHelper/Testing
// *******************************************************
//
// ==UserScript==
// @name           iGraph Helper
// @downloadURL    https://improvement-ninjas.amazon.com/GreaseMonkey/iGraphHelper.amazon.user.js
// @updateURL      https://improvement-ninjas.amazon.com/GreaseMonkey/iGraphHelper.amazon.user.js
// @namespace      http://amazon.com/dept/monitoring
// @description    Version 2.6.13 - Vertical Lines | Support Pipelines Deployments, Support Cloudwatch Graphs Lines, Patch Apollo
// @version        2613
// @icon           https://monitorportal.amazon.com/favicon.ico
// @grant          GM_addStyle
// @grant          GM_getValue
// @grant          GM_log
// @grant          GM_openInTab
// @grant          GM_registerMenuCommand
// @grant          GM_setClipboard
// @grant          GM_setValue
// @grant          GM_xmlhttpRequest
// @grant          GM_notification
// @grant          GM_info
// @grant          unsafeWindow
// @include        http*://*.amazon.*/*
// @include        http*://*.*.amazon.*/*
// @include        http*://*.amazon.*:*/*
// @include        http*://*.aws-border.*/*
// @include        https://*.aws-border.sgov.gov/*
// @include        http*://*.aws.dev/*
// @include        http*://*.a2z.com/*
// @include        http*://*.a2z.org.cn/*
// @include        https://*.amazonaws-us-gov.com/*
// @include        https://*.amazonaws.cn/*
// @include        https://*c2shome.ic.gov/*
// @include        https://*.c2s-border.ic.gov/*
// @include        https://*.c2s-border.ic.gov/*
// @include        https://*.c2s-aws.ic.gov/*
// @include        https://*.c2s-a2z.ic.gov/*
// @include        https://*.sc2s-a2z.sgov.gov/*
// @include        https://*.sc2shome.sgov.gov/*
// @include        http*://wiki.imdb.*/*
// @include        http*://*awsdashboard*.a2z.com/*
// @include        http*://*.premonition.a2z.com/*
// @include        https://*.c2s.ic.gov/*
// @include        https://*.sc2s.sgov.gov/*
// @include        https://*.amazonaws.ic.gov/*
// @include        https://*.hci.ic.gov/*
// @include        https://*.adc-e.uk/*
// @include        https://*.amazonaws.eu/*
// @include        https://*.aws-border.eu/*
// @exclude        http*://amazon.tld/*
// @exclude        http*://www.amazon.*/*
// @exclude        http*://aws.amazon.com/marketplace*
// @exclude        http*://ad-jira.amazon.*/*
// @exclude        http*://s9-puma-*.amazon.*/*
// @exclude        http*://blueprints.amazon.*/*
// @exclude        http*://evolution.amazon.*/*
// @include        http*://wiki.labcollab.*/*
// @exclude        http*://peopleportal.amazon.*/*
// @exclude        http*://peopleportal.hr.corp.amazon.com*
// @exclude        http*://apollo.amazon.*/r/*
// @exclude        http*://timeoff.amazon.com/*
// @exclude        http*://*xwiki*.amazon.*/*
// @exclude        http*://intranet-analytics.amazon.com*
// @exclude        http*://ballard.amazon.com/*
// @exclude        http*://aws-blogs-*.amazon.com/*
// @exclude        http*://approvalbouncer.*.amazon.com/*
// @exclude        http*://docs.aws.amazon.com/*
// @exclude        http*://docs.amazonaws.cn/*
// @exclude        http*://*docs-aws*amazon.com/*
// @exclude        http*://*idp.amazon.work/*
// @exclude        http*://atv-pex-tools-*.amazon.com/*
// @exclude        http*://collator-items.*.amazon.com/*
// @exclude        http*://sonar-*.amazon.com/*
// ==/UserScript==

// Hostname-to-MonitorPortal origin mapping for isolated regions.
// Used by both the jQuery fallback and MonitorPortalRoot resolution.
// NOTE: No gamma CloudWatch console endpoints exist in isolated regions —
// awsc-integ (gamma) has OAuth issues (cross-domain credential fetch to prod).
// So console hostnames (sc2shome, c2shome, etc.) always map to prod MonitorPortal.
var _ighPortalOrigins = [
    // CloudWatch console hostnames — no gamma variant exists (OAuth cross-domain issues with awsc-integ)
    { pattern: /sc2shome\.sgov\.gov$/,                                portal: 'https://monitorportal.lck.aws-border.sgov.gov',   tiny: 'https://prod.y.sc2s-a2z.sgov.gov' },
    { pattern: /c2shome\.ic\.gov$/,                                   portal: 'https://monitorportal.dca.c2s-border.ic.gov',     tiny: 'https://prod.y.c2s-a2z.ic.gov' },
    { pattern: /csphome\.hci\.ic\.gov$/,                              portal: 'https://monitorportal.ale.aws-border.hci.ic.gov', tiny: 'https://prod.y.csp-a2z.hci.ic.gov' },
    // MonitorPortal hostnames — gamma-aware (monitorportal-gamma.* vs monitorportal.*)
    { pattern: /monitorportal-gamma\.dca\.c2s-border\.ic\.gov$/,      portal: 'https://monitorportal-gamma.dca.c2s-border.ic.gov',     tiny: 'https://prod.y.c2s-a2z.ic.gov' },
    { pattern: /(dca|apa)\.(amazon\.com|c2s-border\.ic\.gov)$/,       portal: 'https://monitorportal.dca.c2s-border.ic.gov',           tiny: 'https://prod.y.c2s-a2z.ic.gov' },
    { pattern: /monitorportal-gamma\.(lck|ffz)\.aws-border\.sgov\.gov$/, portal: 'https://monitorportal-gamma.lck.aws-border.sgov.gov', tiny: 'https://prod.y.sc2s-a2z.sgov.gov' },
    { pattern: /(lck|ffz)\.aws-border(\.com|\.sgov\.gov)$/,          portal: 'https://monitorportal.lck.aws-border.sgov.gov',         tiny: 'https://prod.y.sc2s-a2z.sgov.gov' },
    { pattern: /monitorportal-gamma\.ale\.aws-border\.hci\.ic\.gov$/, portal: 'https://monitorportal-gamma.ale.aws-border.hci.ic.gov', tiny: 'https://prod.y.csp-a2z.hci.ic.gov' },
    { pattern: /(ale|ltw)\.aws-border\.hci\.ic\.gov$/,                portal: 'https://monitorportal.ale.aws-border.hci.ic.gov',       tiny: 'https://prod.y.csp-a2z.hci.ic.gov' },
    // Non-isolated regions (no tiny URL changes)
    { pattern: /ncl\.aws-border\.adc-e\.uk$/,                         portal: 'https://monitorportal.ncl.aws-border.adc-e.uk' },
    { pattern: /(bjs\.(amazon|aws-border)\.(com|cn))$/,               portal: 'https://monitorportal.bjs.aws-border.cn' },
    { pattern: /(zhy\.(amazon|aws-border)\.(com|cn))$/,               portal: 'https://monitorportal.zhy.aws-border.cn' },
    { pattern: /thf\.aws-border\.eu$/,                                portal: 'https://monitorportal.thf.aws-border.eu' }
];

function _ighResolvePortalOrigin(hostname) {
    for (var i = 0; i < _ighPortalOrigins.length; i++) {
        if (_ighPortalOrigins[i].pattern.test(hostname)) {
            return _ighPortalOrigins[i].portal;
        }
    }
    return null;
}

function _ighResolveTinyOrigin(hostname) {
    for (var i = 0; i < _ighPortalOrigins.length; i++) {
        if (_ighPortalOrigins[i].pattern.test(hostname) && _ighPortalOrigins[i].tiny) {
            return _ighPortalOrigins[i].tiny;
        }
    }
    return null;
}

var TinyUrlRoot = _ighResolveTinyOrigin(window.location.hostname) || 'https://tiny.amazon.com';
var MonitorPortalRoot = _ighResolvePortalOrigin(window.location.hostname) || "https://monitorportal.amazon.com";

// Set portalData.portalURL so portalUrl() returns the correct regional endpoint.
// Merge rather than replace to avoid clobbering other portalData properties.
if (typeof unsafeWindow !== 'undefined') {
    unsafeWindow.portalData = unsafeWindow.portalData || {};
    unsafeWindow.portalData.portalURL = unsafeWindow.portalData.portalURL || MonitorPortalRoot;
}

// Debug logging. Enable via Tampermonkey menu "toggle debug logging", or:
// Debug stub (no-op)
var _ighDebug = function () { };
_ighDebug.isEnabled = function () { return false; };
_ighDebug.enable = function () { };
_ighDebug.disable = function () { };

// Bundled jQuery 3.7.1
!function (e, t) { "use strict"; "object" == typeof module && "object" == typeof module.exports ? module.exports = e.document ? t(e, !0) : function (e) { if (!e.document) throw new Error("jQuery requires a window with a document"); return t(e) } : t(e) }("undefined" != typeof window ? window : this, function (ie, e) { "use strict"; var oe = [], r = Object.getPrototypeOf, ae = oe.slice, g = oe.flat ? function (e) { return oe.flat.call(e) } : function (e) { return oe.concat.apply([], e) }, s = oe.push, se = oe.indexOf, n = {}, i = n.toString, ue = n.hasOwnProperty, o = ue.toString, a = o.call(Object), le = {}, v = function (e) { return "function" == typeof e && "number" != typeof e.nodeType && "function" != typeof e.item }, y = function (e) { return null != e && e === e.window }, C = ie.document, u = { type: !0, src: !0, nonce: !0, noModule: !0 }; function m(e, t, n) { var r, i, o = (n = n || C).createElement("script"); if (o.text = e, t) for (r in u) (i = t[r] || t.getAttribute && t.getAttribute(r)) && o.setAttribute(r, i); n.head.appendChild(o).parentNode.removeChild(o) } function x(e) { return null == e ? e + "" : "object" == typeof e || "function" == typeof e ? n[i.call(e)] || "object" : typeof e } var t = "3.7.1", l = /HTML$/i, ce = function (e, t) { return new ce.fn.init(e, t) }; function c(e) { var t = !!e && "length" in e && e.length, n = x(e); return !v(e) && !y(e) && ("array" === n || 0 === t || "number" == typeof t && 0 < t && t - 1 in e) } function fe(e, t) { return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase() } ce.fn = ce.prototype = { jquery: t, constructor: ce, length: 0, toArray: function () { return ae.call(this) }, get: function (e) { return null == e ? ae.call(this) : e < 0 ? this[e + this.length] : this[e] }, pushStack: function (e) { var t = ce.merge(this.constructor(), e); return t.prevObject = this, t }, each: function (e) { return ce.each(this, e) }, map: function (n) { return this.pushStack(ce.map(this, function (e, t) { return n.call(e, t, e) })) }, slice: function () { return this.pushStack(ae.apply(this, arguments)) }, first: function () { return this.eq(0) }, last: function () { return this.eq(-1) }, even: function () { return this.pushStack(ce.grep(this, function (e, t) { return (t + 1) % 2 })) }, odd: function () { return this.pushStack(ce.grep(this, function (e, t) { return t % 2 })) }, eq: function (e) { var t = this.length, n = +e + (e < 0 ? t : 0); return this.pushStack(0 <= n && n < t ? [this[n]] : []) }, end: function () { return this.prevObject || this.constructor() }, push: s, sort: oe.sort, splice: oe.splice }, ce.extend = ce.fn.extend = function () { var e, t, n, r, i, o, a = arguments[0] || {}, s = 1, u = arguments.length, l = !1; for ("boolean" == typeof a && (l = a, a = arguments[s] || {}, s++), "object" == typeof a || v(a) || (a = {}), s === u && (a = this, s--); s < u; s++)if (null != (e = arguments[s])) for (t in e) r = e[t], "__proto__" !== t && a !== r && (l && r && (ce.isPlainObject(r) || (i = Array.isArray(r))) ? (n = a[t], o = i && !Array.isArray(n) ? [] : i || ce.isPlainObject(n) ? n : {}, i = !1, a[t] = ce.extend(l, o, r)) : void 0 !== r && (a[t] = r)); return a }, ce.extend({ expando: "jQuery" + (t + Math.random()).replace(/\D/g, ""), isReady: !0, error: function (e) { throw new Error(e) }, noop: function () { }, isPlainObject: function (e) { var t, n; return !(!e || "[object Object]" !== i.call(e)) && (!(t = r(e)) || "function" == typeof (n = ue.call(t, "constructor") && t.constructor) && o.call(n) === a) }, isEmptyObject: function (e) { var t; for (t in e) return !1; return !0 }, globalEval: function (e, t, n) { m(e, { nonce: t && t.nonce }, n) }, each: function (e, t) { var n, r = 0; if (c(e)) { for (n = e.length; r < n; r++)if (!1 === t.call(e[r], r, e[r])) break } else for (r in e) if (!1 === t.call(e[r], r, e[r])) break; return e }, text: function (e) { var t, n = "", r = 0, i = e.nodeType; if (!i) while (t = e[r++]) n += ce.text(t); return 1 === i || 11 === i ? e.textContent : 9 === i ? e.documentElement.textContent : 3 === i || 4 === i ? e.nodeValue : n }, makeArray: function (e, t) { var n = t || []; return null != e && (c(Object(e)) ? ce.merge(n, "string" == typeof e ? [e] : e) : s.call(n, e)), n }, inArray: function (e, t, n) { return null == t ? -1 : se.call(t, e, n) }, isXMLDoc: function (e) { var t = e && e.namespaceURI, n = e && (e.ownerDocument || e).documentElement; return !l.test(t || n && n.nodeName || "HTML") }, merge: function (e, t) { for (var n = +t.length, r = 0, i = e.length; r < n; r++)e[i++] = t[r]; return e.length = i, e }, grep: function (e, t, n) { for (var r = [], i = 0, o = e.length, a = !n; i < o; i++)!t(e[i], i) !== a && r.push(e[i]); return r }, map: function (e, t, n) { var r, i, o = 0, a = []; if (c(e)) for (r = e.length; o < r; o++)null != (i = t(e[o], o, n)) && a.push(i); else for (o in e) null != (i = t(e[o], o, n)) && a.push(i); return g(a) }, guid: 1, support: le }), "function" == typeof Symbol && (ce.fn[Symbol.iterator] = oe[Symbol.iterator]), ce.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function (e, t) { n["[object " + t + "]"] = t.toLowerCase() }); var pe = oe.pop, de = oe.sort, he = oe.splice, ge = "[\\x20\\t\\r\\n\\f]", ve = new RegExp("^" + ge + "+|((?:^|[^\\\\])(?:\\\\.)*)" + ge + "+$", "g"); ce.contains = function (e, t) { var n = t && t.parentNode; return e === n || !(!n || 1 !== n.nodeType || !(e.contains ? e.contains(n) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(n))) }; var f = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\x80-\uFFFF\w-]/g; function p(e, t) { return t ? "\0" === e ? "\ufffd" : e.slice(0, -1) + "\\" + e.charCodeAt(e.length - 1).toString(16) + " " : "\\" + e } ce.escapeSelector = function (e) { return (e + "").replace(f, p) }; var ye = C, me = s; !function () { var e, b, w, o, a, T, r, C, d, i, k = me, S = ce.expando, E = 0, n = 0, s = W(), c = W(), u = W(), h = W(), l = function (e, t) { return e === t && (a = !0), 0 }, f = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped", t = "(?:\\\\[\\da-fA-F]{1,6}" + ge + "?|\\\\[^\\r\\n\\f]|[\\w-]|[^\0-\\x7f])+", p = "\\[" + ge + "*(" + t + ")(?:" + ge + "*([*^$|!~]?=)" + ge + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + t + "))|)" + ge + "*\\]", g = ":(" + t + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + p + ")*)|.*)\\)|)", v = new RegExp(ge + "+", "g"), y = new RegExp("^" + ge + "*," + ge + "*"), m = new RegExp("^" + ge + "*([>+~]|" + ge + ")" + ge + "*"), x = new RegExp(ge + "|>"), j = new RegExp(g), A = new RegExp("^" + t + "$"), D = { ID: new RegExp("^#(" + t + ")"), CLASS: new RegExp("^\\.(" + t + ")"), TAG: new RegExp("^(" + t + "|[*])"), ATTR: new RegExp("^" + p), PSEUDO: new RegExp("^" + g), CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + ge + "*(even|odd|(([+-]|)(\\d*)n|)" + ge + "*(?:([+-]|)" + ge + "*(\\d+)|))" + ge + "*\\)|)", "i"), bool: new RegExp("^(?:" + f + ")$", "i"), needsContext: new RegExp("^" + ge + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + ge + "*((?:-\\d)?\\d*)" + ge + "*\\)|)(?=[^-]|$)", "i") }, N = /^(?:input|select|textarea|button)$/i, q = /^h\d$/i, L = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/, H = /[+~]/, O = new RegExp("\\\\[\\da-fA-F]{1,6}" + ge + "?|\\\\([^\\r\\n\\f])", "g"), P = function (e, t) { var n = "0x" + e.slice(1) - 65536; return t || (n < 0 ? String.fromCharCode(n + 65536) : String.fromCharCode(n >> 10 | 55296, 1023 & n | 56320)) }, M = function () { V() }, R = J(function (e) { return !0 === e.disabled && fe(e, "fieldset") }, { dir: "parentNode", next: "legend" }); try { k.apply(oe = ae.call(ye.childNodes), ye.childNodes), oe[ye.childNodes.length].nodeType } catch (e) { k = { apply: function (e, t) { me.apply(e, ae.call(t)) }, call: function (e) { me.apply(e, ae.call(arguments, 1)) } } } function I(t, e, n, r) { var i, o, a, s, u, l, c, f = e && e.ownerDocument, p = e ? e.nodeType : 9; if (n = n || [], "string" != typeof t || !t || 1 !== p && 9 !== p && 11 !== p) return n; if (!r && (V(e), e = e || T, C)) { if (11 !== p && (u = L.exec(t))) if (i = u[1]) { if (9 === p) { if (!(a = e.getElementById(i))) return n; if (a.id === i) return k.call(n, a), n } else if (f && (a = f.getElementById(i)) && I.contains(e, a) && a.id === i) return k.call(n, a), n } else { if (u[2]) return k.apply(n, e.getElementsByTagName(t)), n; if ((i = u[3]) && e.getElementsByClassName) return k.apply(n, e.getElementsByClassName(i)), n } if (!(h[t + " "] || d && d.test(t))) { if (c = t, f = e, 1 === p && (x.test(t) || m.test(t))) { (f = H.test(t) && U(e.parentNode) || e) == e && le.scope || ((s = e.getAttribute("id")) ? s = ce.escapeSelector(s) : e.setAttribute("id", s = S)), o = (l = Y(t)).length; while (o--) l[o] = (s ? "#" + s : ":scope") + " " + Q(l[o]); c = l.join(",") } try { return k.apply(n, f.querySelectorAll(c)), n } catch (e) { h(t, !0) } finally { s === S && e.removeAttribute("id") } } } return re(t.replace(ve, "$1"), e, n, r) } function W() { var r = []; return function e(t, n) { return r.push(t + " ") > b.cacheLength && delete e[r.shift()], e[t + " "] = n } } function F(e) { return e[S] = !0, e } function $(e) { var t = T.createElement("fieldset"); try { return !!e(t) } catch (e) { return !1 } finally { t.parentNode && t.parentNode.removeChild(t), t = null } } function B(t) { return function (e) { return fe(e, "input") && e.type === t } } function _(t) { return function (e) { return (fe(e, "input") || fe(e, "button")) && e.type === t } } function z(t) { return function (e) { return "form" in e ? e.parentNode && !1 === e.disabled ? "label" in e ? "label" in e.parentNode ? e.parentNode.disabled === t : e.disabled === t : e.isDisabled === t || e.isDisabled !== !t && R(e) === t : e.disabled === t : "label" in e && e.disabled === t } } function X(a) { return F(function (o) { return o = +o, F(function (e, t) { var n, r = a([], e.length, o), i = r.length; while (i--) e[n = r[i]] && (e[n] = !(t[n] = e[n])) }) }) } function U(e) { return e && "undefined" != typeof e.getElementsByTagName && e } function V(e) { var t, n = e ? e.ownerDocument || e : ye; return n != T && 9 === n.nodeType && n.documentElement && (r = (T = n).documentElement, C = !ce.isXMLDoc(T), i = r.matches || r.webkitMatchesSelector || r.msMatchesSelector, r.msMatchesSelector && ye != T && (t = T.defaultView) && t.top !== t && t.addEventListener("unload", M), le.getById = $(function (e) { return r.appendChild(e).id = ce.expando, !T.getElementsByName || !T.getElementsByName(ce.expando).length }), le.disconnectedMatch = $(function (e) { return i.call(e, "*") }), le.scope = $(function () { return T.querySelectorAll(":scope") }), le.cssHas = $(function () { try { return T.querySelector(":has(*,:jqfake)"), !1 } catch (e) { return !0 } }), le.getById ? (b.filter.ID = function (e) { var t = e.replace(O, P); return function (e) { return e.getAttribute("id") === t } }, b.find.ID = function (e, t) { if ("undefined" != typeof t.getElementById && C) { var n = t.getElementById(e); return n ? [n] : [] } }) : (b.filter.ID = function (e) { var n = e.replace(O, P); return function (e) { var t = "undefined" != typeof e.getAttributeNode && e.getAttributeNode("id"); return t && t.value === n } }, b.find.ID = function (e, t) { if ("undefined" != typeof t.getElementById && C) { var n, r, i, o = t.getElementById(e); if (o) { if ((n = o.getAttributeNode("id")) && n.value === e) return [o]; i = t.getElementsByName(e), r = 0; while (o = i[r++]) if ((n = o.getAttributeNode("id")) && n.value === e) return [o] } return [] } }), b.find.TAG = function (e, t) { return "undefined" != typeof t.getElementsByTagName ? t.getElementsByTagName(e) : t.querySelectorAll(e) }, b.find.CLASS = function (e, t) { if ("undefined" != typeof t.getElementsByClassName && C) return t.getElementsByClassName(e) }, d = [], $(function (e) { var t; r.appendChild(e).innerHTML = "<a id='" + S + "' href='' disabled='disabled'></a><select id='" + S + "-\r\\' disabled='disabled'><option selected=''></option></select>", e.querySelectorAll("[selected]").length || d.push("\\[" + ge + "*(?:value|" + f + ")"), e.querySelectorAll("[id~=" + S + "-]").length || d.push("~="), e.querySelectorAll("a#" + S + "+*").length || d.push(".#.+[+~]"), e.querySelectorAll(":checked").length || d.push(":checked"), (t = T.createElement("input")).setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), r.appendChild(e).disabled = !0, 2 !== e.querySelectorAll(":disabled").length && d.push(":enabled", ":disabled"), (t = T.createElement("input")).setAttribute("name", ""), e.appendChild(t), e.querySelectorAll("[name='']").length || d.push("\\[" + ge + "*name" + ge + "*=" + ge + "*(?:''|\"\")") }), le.cssHas || d.push(":has"), d = d.length && new RegExp(d.join("|")), l = function (e, t) { if (e === t) return a = !0, 0; var n = !e.compareDocumentPosition - !t.compareDocumentPosition; return n || (1 & (n = (e.ownerDocument || e) == (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1) || !le.sortDetached && t.compareDocumentPosition(e) === n ? e === T || e.ownerDocument == ye && I.contains(ye, e) ? -1 : t === T || t.ownerDocument == ye && I.contains(ye, t) ? 1 : o ? se.call(o, e) - se.call(o, t) : 0 : 4 & n ? -1 : 1) }), T } for (e in I.matches = function (e, t) { return I(e, null, null, t) }, I.matchesSelector = function (e, t) { if (V(e), C && !h[t + " "] && (!d || !d.test(t))) try { var n = i.call(e, t); if (n || le.disconnectedMatch || e.document && 11 !== e.document.nodeType) return n } catch (e) { h(t, !0) } return 0 < I(t, T, null, [e]).length }, I.contains = function (e, t) { return (e.ownerDocument || e) != T && V(e), ce.contains(e, t) }, I.attr = function (e, t) { (e.ownerDocument || e) != T && V(e); var n = b.attrHandle[t.toLowerCase()], r = n && ue.call(b.attrHandle, t.toLowerCase()) ? n(e, t, !C) : void 0; return void 0 !== r ? r : e.getAttribute(t) }, I.error = function (e) { throw new Error("Syntax error, unrecognized expression: " + e) }, ce.uniqueSort = function (e) { var t, n = [], r = 0, i = 0; if (a = !le.sortStable, o = !le.sortStable && ae.call(e, 0), de.call(e, l), a) { while (t = e[i++]) t === e[i] && (r = n.push(i)); while (r--) he.call(e, n[r], 1) } return o = null, e }, ce.fn.uniqueSort = function () { return this.pushStack(ce.uniqueSort(ae.apply(this))) }, (b = ce.expr = { cacheLength: 50, createPseudo: F, match: D, attrHandle: {}, find: {}, relative: { ">": { dir: "parentNode", first: !0 }, " ": { dir: "parentNode" }, "+": { dir: "previousSibling", first: !0 }, "~": { dir: "previousSibling" } }, preFilter: { ATTR: function (e) { return e[1] = e[1].replace(O, P), e[3] = (e[3] || e[4] || e[5] || "").replace(O, P), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4) }, CHILD: function (e) { return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || I.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && I.error(e[0]), e }, PSEUDO: function (e) { var t, n = !e[6] && e[2]; return D.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && j.test(n) && (t = Y(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3)) } }, filter: { TAG: function (e) { var t = e.replace(O, P).toLowerCase(); return "*" === e ? function () { return !0 } : function (e) { return fe(e, t) } }, CLASS: function (e) { var t = s[e + " "]; return t || (t = new RegExp("(^|" + ge + ")" + e + "(" + ge + "|$)")) && s(e, function (e) { return t.test("string" == typeof e.className && e.className || "undefined" != typeof e.getAttribute && e.getAttribute("class") || "") }) }, ATTR: function (n, r, i) { return function (e) { var t = I.attr(e, n); return null == t ? "!=" === r : !r || (t += "", "=" === r ? t === i : "!=" === r ? t !== i : "^=" === r ? i && 0 === t.indexOf(i) : "*=" === r ? i && -1 < t.indexOf(i) : "$=" === r ? i && t.slice(-i.length) === i : "~=" === r ? -1 < (" " + t.replace(v, " ") + " ").indexOf(i) : "|=" === r && (t === i || t.slice(0, i.length + 1) === i + "-")) } }, CHILD: function (d, e, t, h, g) { var v = "nth" !== d.slice(0, 3), y = "last" !== d.slice(-4), m = "of-type" === e; return 1 === h && 0 === g ? function (e) { return !!e.parentNode } : function (e, t, n) { var r, i, o, a, s, u = v !== y ? "nextSibling" : "previousSibling", l = e.parentNode, c = m && e.nodeName.toLowerCase(), f = !n && !m, p = !1; if (l) { if (v) { while (u) { o = e; while (o = o[u]) if (m ? fe(o, c) : 1 === o.nodeType) return !1; s = u = "only" === d && !s && "nextSibling" } return !0 } if (s = [y ? l.firstChild : l.lastChild], y && f) { p = (a = (r = (i = l[S] || (l[S] = {}))[d] || [])[0] === E && r[1]) && r[2], o = a && l.childNodes[a]; while (o = ++a && o && o[u] || (p = a = 0) || s.pop()) if (1 === o.nodeType && ++p && o === e) { i[d] = [E, a, p]; break } } else if (f && (p = a = (r = (i = e[S] || (e[S] = {}))[d] || [])[0] === E && r[1]), !1 === p) while (o = ++a && o && o[u] || (p = a = 0) || s.pop()) if ((m ? fe(o, c) : 1 === o.nodeType) && ++p && (f && ((i = o[S] || (o[S] = {}))[d] = [E, p]), o === e)) break; return (p -= g) === h || p % h == 0 && 0 <= p / h } } }, PSEUDO: function (e, o) { var t, a = b.pseudos[e] || b.setFilters[e.toLowerCase()] || I.error("unsupported pseudo: " + e); return a[S] ? a(o) : 1 < a.length ? (t = [e, e, "", o], b.setFilters.hasOwnProperty(e.toLowerCase()) ? F(function (e, t) { var n, r = a(e, o), i = r.length; while (i--) e[n = se.call(e, r[i])] = !(t[n] = r[i]) }) : function (e) { return a(e, 0, t) }) : a } }, pseudos: { not: F(function (e) { var r = [], i = [], s = ne(e.replace(ve, "$1")); return s[S] ? F(function (e, t, n, r) { var i, o = s(e, null, r, []), a = e.length; while (a--) (i = o[a]) && (e[a] = !(t[a] = i)) }) : function (e, t, n) { return r[0] = e, s(r, null, n, i), r[0] = null, !i.pop() } }), has: F(function (t) { return function (e) { return 0 < I(t, e).length } }), contains: F(function (t) { return t = t.replace(O, P), function (e) { return -1 < (e.textContent || ce.text(e)).indexOf(t) } }), lang: F(function (n) { return A.test(n || "") || I.error("unsupported lang: " + n), n = n.replace(O, P).toLowerCase(), function (e) { var t; do { if (t = C ? e.lang : e.getAttribute("xml:lang") || e.getAttribute("lang")) return (t = t.toLowerCase()) === n || 0 === t.indexOf(n + "-") } while ((e = e.parentNode) && 1 === e.nodeType); return !1 } }), target: function (e) { var t = ie.location && ie.location.hash; return t && t.slice(1) === e.id }, root: function (e) { return e === r }, focus: function (e) { return e === function () { try { return T.activeElement } catch (e) { } }() && T.hasFocus() && !!(e.type || e.href || ~e.tabIndex) }, enabled: z(!1), disabled: z(!0), checked: function (e) { return fe(e, "input") && !!e.checked || fe(e, "option") && !!e.selected }, selected: function (e) { return e.parentNode && e.parentNode.selectedIndex, !0 === e.selected }, empty: function (e) { for (e = e.firstChild; e; e = e.nextSibling)if (e.nodeType < 6) return !1; return !0 }, parent: function (e) { return !b.pseudos.empty(e) }, header: function (e) { return q.test(e.nodeName) }, input: function (e) { return N.test(e.nodeName) }, button: function (e) { return fe(e, "input") && "button" === e.type || fe(e, "button") }, text: function (e) { var t; return fe(e, "input") && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase()) }, first: X(function () { return [0] }), last: X(function (e, t) { return [t - 1] }), eq: X(function (e, t, n) { return [n < 0 ? n + t : n] }), even: X(function (e, t) { for (var n = 0; n < t; n += 2)e.push(n); return e }), odd: X(function (e, t) { for (var n = 1; n < t; n += 2)e.push(n); return e }), lt: X(function (e, t, n) { var r; for (r = n < 0 ? n + t : t < n ? t : n; 0 <= --r;)e.push(r); return e }), gt: X(function (e, t, n) { for (var r = n < 0 ? n + t : n; ++r < t;)e.push(r); return e }) } }).pseudos.nth = b.pseudos.eq, { radio: !0, checkbox: !0, file: !0, password: !0, image: !0 }) b.pseudos[e] = B(e); for (e in { submit: !0, reset: !0 }) b.pseudos[e] = _(e); function G() { } function Y(e, t) { var n, r, i, o, a, s, u, l = c[e + " "]; if (l) return t ? 0 : l.slice(0); a = e, s = [], u = b.preFilter; while (a) { for (o in n && !(r = y.exec(a)) || (r && (a = a.slice(r[0].length) || a), s.push(i = [])), n = !1, (r = m.exec(a)) && (n = r.shift(), i.push({ value: n, type: r[0].replace(ve, " ") }), a = a.slice(n.length)), b.filter) !(r = D[o].exec(a)) || u[o] && !(r = u[o](r)) || (n = r.shift(), i.push({ value: n, type: o, matches: r }), a = a.slice(n.length)); if (!n) break } return t ? a.length : a ? I.error(e) : c(e, s).slice(0) } function Q(e) { for (var t = 0, n = e.length, r = ""; t < n; t++)r += e[t].value; return r } function J(a, e, t) { var s = e.dir, u = e.next, l = u || s, c = t && "parentNode" === l, f = n++; return e.first ? function (e, t, n) { while (e = e[s]) if (1 === e.nodeType || c) return a(e, t, n); return !1 } : function (e, t, n) { var r, i, o = [E, f]; if (n) { while (e = e[s]) if ((1 === e.nodeType || c) && a(e, t, n)) return !0 } else while (e = e[s]) if (1 === e.nodeType || c) if (i = e[S] || (e[S] = {}), u && fe(e, u)) e = e[s] || e; else { if ((r = i[l]) && r[0] === E && r[1] === f) return o[2] = r[2]; if ((i[l] = o)[2] = a(e, t, n)) return !0 } return !1 } } function K(i) { return 1 < i.length ? function (e, t, n) { var r = i.length; while (r--) if (!i[r](e, t, n)) return !1; return !0 } : i[0] } function Z(e, t, n, r, i) { for (var o, a = [], s = 0, u = e.length, l = null != t; s < u; s++)(o = e[s]) && (n && !n(o, r, i) || (a.push(o), l && t.push(s))); return a } function ee(d, h, g, v, y, e) { return v && !v[S] && (v = ee(v)), y && !y[S] && (y = ee(y, e)), F(function (e, t, n, r) { var i, o, a, s, u = [], l = [], c = t.length, f = e || function (e, t, n) { for (var r = 0, i = t.length; r < i; r++)I(e, t[r], n); return n }(h || "*", n.nodeType ? [n] : n, []), p = !d || !e && h ? f : Z(f, u, d, n, r); if (g ? g(p, s = y || (e ? d : c || v) ? [] : t, n, r) : s = p, v) { i = Z(s, l), v(i, [], n, r), o = i.length; while (o--) (a = i[o]) && (s[l[o]] = !(p[l[o]] = a)) } if (e) { if (y || d) { if (y) { i = [], o = s.length; while (o--) (a = s[o]) && i.push(p[o] = a); y(null, s = [], i, r) } o = s.length; while (o--) (a = s[o]) && -1 < (i = y ? se.call(e, a) : u[o]) && (e[i] = !(t[i] = a)) } } else s = Z(s === t ? s.splice(c, s.length) : s), y ? y(null, t, s, r) : k.apply(t, s) }) } function te(e) { for (var i, t, n, r = e.length, o = b.relative[e[0].type], a = o || b.relative[" "], s = o ? 1 : 0, u = J(function (e) { return e === i }, a, !0), l = J(function (e) { return -1 < se.call(i, e) }, a, !0), c = [function (e, t, n) { var r = !o && (n || t != w) || ((i = t).nodeType ? u(e, t, n) : l(e, t, n)); return i = null, r }]; s < r; s++)if (t = b.relative[e[s].type]) c = [J(K(c), t)]; else { if ((t = b.filter[e[s].type].apply(null, e[s].matches))[S]) { for (n = ++s; n < r; n++)if (b.relative[e[n].type]) break; return ee(1 < s && K(c), 1 < s && Q(e.slice(0, s - 1).concat({ value: " " === e[s - 2].type ? "*" : "" })).replace(ve, "$1"), t, s < n && te(e.slice(s, n)), n < r && te(e = e.slice(n)), n < r && Q(e)) } c.push(t) } return K(c) } function ne(e, t) { var n, v, y, m, x, r, i = [], o = [], a = u[e + " "]; if (!a) { t || (t = Y(e)), n = t.length; while (n--) (a = te(t[n]))[S] ? i.push(a) : o.push(a); (a = u(e, (v = o, m = 0 < (y = i).length, x = 0 < v.length, r = function (e, t, n, r, i) { var o, a, s, u = 0, l = "0", c = e && [], f = [], p = w, d = e || x && b.find.TAG("*", i), h = E += null == p ? 1 : Math.random() || .1, g = d.length; for (i && (w = t == T || t || i); l !== g && null != (o = d[l]); l++) { if (x && o) { a = 0, t || o.ownerDocument == T || (V(o), n = !C); while (s = v[a++]) if (s(o, t || T, n)) { k.call(r, o); break } i && (E = h) } m && ((o = !s && o) && u--, e && c.push(o)) } if (u += l, m && l !== u) { a = 0; while (s = y[a++]) s(c, f, t, n); if (e) { if (0 < u) while (l--) c[l] || f[l] || (f[l] = pe.call(r)); f = Z(f) } k.apply(r, f), i && !e && 0 < f.length && 1 < u + y.length && ce.uniqueSort(r) } return i && (E = h, w = p), c }, m ? F(r) : r))).selector = e } return a } function re(e, t, n, r) { var i, o, a, s, u, l = "function" == typeof e && e, c = !r && Y(e = l.selector || e); if (n = n || [], 1 === c.length) { if (2 < (o = c[0] = c[0].slice(0)).length && "ID" === (a = o[0]).type && 9 === t.nodeType && C && b.relative[o[1].type]) { if (!(t = (b.find.ID(a.matches[0].replace(O, P), t) || [])[0])) return n; l && (t = t.parentNode), e = e.slice(o.shift().value.length) } i = D.needsContext.test(e) ? 0 : o.length; while (i--) { if (a = o[i], b.relative[s = a.type]) break; if ((u = b.find[s]) && (r = u(a.matches[0].replace(O, P), H.test(o[0].type) && U(t.parentNode) || t))) { if (o.splice(i, 1), !(e = r.length && Q(o))) return k.apply(n, r), n; break } } } return (l || ne(e, c))(r, t, !C, n, !t || H.test(e) && U(t.parentNode) || t), n } G.prototype = b.filters = b.pseudos, b.setFilters = new G, le.sortStable = S.split("").sort(l).join("") === S, V(), le.sortDetached = $(function (e) { return 1 & e.compareDocumentPosition(T.createElement("fieldset")) }), ce.find = I, ce.expr[":"] = ce.expr.pseudos, ce.unique = ce.uniqueSort, I.compile = ne, I.select = re, I.setDocument = V, I.tokenize = Y, I.escape = ce.escapeSelector, I.getText = ce.text, I.isXML = ce.isXMLDoc, I.selectors = ce.expr, I.support = ce.support, I.uniqueSort = ce.uniqueSort }(); var d = function (e, t, n) { var r = [], i = void 0 !== n; while ((e = e[t]) && 9 !== e.nodeType) if (1 === e.nodeType) { if (i && ce(e).is(n)) break; r.push(e) } return r }, h = function (e, t) { for (var n = []; e; e = e.nextSibling)1 === e.nodeType && e !== t && n.push(e); return n }, b = ce.expr.match.needsContext, w = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i; function T(e, n, r) { return v(n) ? ce.grep(e, function (e, t) { return !!n.call(e, t, e) !== r }) : n.nodeType ? ce.grep(e, function (e) { return e === n !== r }) : "string" != typeof n ? ce.grep(e, function (e) { return -1 < se.call(n, e) !== r }) : ce.filter(n, e, r) } ce.filter = function (e, t, n) { var r = t[0]; return n && (e = ":not(" + e + ")"), 1 === t.length && 1 === r.nodeType ? ce.find.matchesSelector(r, e) ? [r] : [] : ce.find.matches(e, ce.grep(t, function (e) { return 1 === e.nodeType })) }, ce.fn.extend({ find: function (e) { var t, n, r = this.length, i = this; if ("string" != typeof e) return this.pushStack(ce(e).filter(function () { for (t = 0; t < r; t++)if (ce.contains(i[t], this)) return !0 })); for (n = this.pushStack([]), t = 0; t < r; t++)ce.find(e, i[t], n); return 1 < r ? ce.uniqueSort(n) : n }, filter: function (e) { return this.pushStack(T(this, e || [], !1)) }, not: function (e) { return this.pushStack(T(this, e || [], !0)) }, is: function (e) { return !!T(this, "string" == typeof e && b.test(e) ? ce(e) : e || [], !1).length } }); var k, S = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/; (ce.fn.init = function (e, t, n) { var r, i; if (!e) return this; if (n = n || k, "string" == typeof e) { if (!(r = "<" === e[0] && ">" === e[e.length - 1] && 3 <= e.length ? [null, e, null] : S.exec(e)) || !r[1] && t) return !t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e); if (r[1]) { if (t = t instanceof ce ? t[0] : t, ce.merge(this, ce.parseHTML(r[1], t && t.nodeType ? t.ownerDocument || t : C, !0)), w.test(r[1]) && ce.isPlainObject(t)) for (r in t) v(this[r]) ? this[r](t[r]) : this.attr(r, t[r]); return this } return (i = C.getElementById(r[2])) && (this[0] = i, this.length = 1), this } return e.nodeType ? (this[0] = e, this.length = 1, this) : v(e) ? void 0 !== n.ready ? n.ready(e) : e(ce) : ce.makeArray(e, this) }).prototype = ce.fn, k = ce(C); var E = /^(?:parents|prev(?:Until|All))/, j = { children: !0, contents: !0, next: !0, prev: !0 }; function A(e, t) { while ((e = e[t]) && 1 !== e.nodeType); return e } ce.fn.extend({ has: function (e) { var t = ce(e, this), n = t.length; return this.filter(function () { for (var e = 0; e < n; e++)if (ce.contains(this, t[e])) return !0 }) }, closest: function (e, t) { var n, r = 0, i = this.length, o = [], a = "string" != typeof e && ce(e); if (!b.test(e)) for (; r < i; r++)for (n = this[r]; n && n !== t; n = n.parentNode)if (n.nodeType < 11 && (a ? -1 < a.index(n) : 1 === n.nodeType && ce.find.matchesSelector(n, e))) { o.push(n); break } return this.pushStack(1 < o.length ? ce.uniqueSort(o) : o) }, index: function (e) { return e ? "string" == typeof e ? se.call(ce(e), this[0]) : se.call(this, e.jquery ? e[0] : e) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1 }, add: function (e, t) { return this.pushStack(ce.uniqueSort(ce.merge(this.get(), ce(e, t)))) }, addBack: function (e) { return this.add(null == e ? this.prevObject : this.prevObject.filter(e)) } }), ce.each({ parent: function (e) { var t = e.parentNode; return t && 11 !== t.nodeType ? t : null }, parents: function (e) { return d(e, "parentNode") }, parentsUntil: function (e, t, n) { return d(e, "parentNode", n) }, next: function (e) { return A(e, "nextSibling") }, prev: function (e) { return A(e, "previousSibling") }, nextAll: function (e) { return d(e, "nextSibling") }, prevAll: function (e) { return d(e, "previousSibling") }, nextUntil: function (e, t, n) { return d(e, "nextSibling", n) }, prevUntil: function (e, t, n) { return d(e, "previousSibling", n) }, siblings: function (e) { return h((e.parentNode || {}).firstChild, e) }, children: function (e) { return h(e.firstChild) }, contents: function (e) { return null != e.contentDocument && r(e.contentDocument) ? e.contentDocument : (fe(e, "template") && (e = e.content || e), ce.merge([], e.childNodes)) } }, function (r, i) { ce.fn[r] = function (e, t) { var n = ce.map(this, i, e); return "Until" !== r.slice(-5) && (t = e), t && "string" == typeof t && (n = ce.filter(t, n)), 1 < this.length && (j[r] || ce.uniqueSort(n), E.test(r) && n.reverse()), this.pushStack(n) } }); var D = /[^\x20\t\r\n\f]+/g; function N(e) { return e } function q(e) { throw e } function L(e, t, n, r) { var i; try { e && v(i = e.promise) ? i.call(e).done(t).fail(n) : e && v(i = e.then) ? i.call(e, t, n) : t.apply(void 0, [e].slice(r)) } catch (e) { n.apply(void 0, [e]) } } ce.Callbacks = function (r) { var e, n; r = "string" == typeof r ? (e = r, n = {}, ce.each(e.match(D) || [], function (e, t) { n[t] = !0 }), n) : ce.extend({}, r); var i, t, o, a, s = [], u = [], l = -1, c = function () { for (a = a || r.once, o = i = !0; u.length; l = -1) { t = u.shift(); while (++l < s.length) !1 === s[l].apply(t[0], t[1]) && r.stopOnFalse && (l = s.length, t = !1) } r.memory || (t = !1), i = !1, a && (s = t ? [] : "") }, f = { add: function () { return s && (t && !i && (l = s.length - 1, u.push(t)), function n(e) { ce.each(e, function (e, t) { v(t) ? r.unique && f.has(t) || s.push(t) : t && t.length && "string" !== x(t) && n(t) }) }(arguments), t && !i && c()), this }, remove: function () { return ce.each(arguments, function (e, t) { var n; while (-1 < (n = ce.inArray(t, s, n))) s.splice(n, 1), n <= l && l-- }), this }, has: function (e) { return e ? -1 < ce.inArray(e, s) : 0 < s.length }, empty: function () { return s && (s = []), this }, disable: function () { return a = u = [], s = t = "", this }, disabled: function () { return !s }, lock: function () { return a = u = [], t || i || (s = t = ""), this }, locked: function () { return !!a }, fireWith: function (e, t) { return a || (t = [e, (t = t || []).slice ? t.slice() : t], u.push(t), i || c()), this }, fire: function () { return f.fireWith(this, arguments), this }, fired: function () { return !!o } }; return f }, ce.extend({ Deferred: function (e) { var o = [["notify", "progress", ce.Callbacks("memory"), ce.Callbacks("memory"), 2], ["resolve", "done", ce.Callbacks("once memory"), ce.Callbacks("once memory"), 0, "resolved"], ["reject", "fail", ce.Callbacks("once memory"), ce.Callbacks("once memory"), 1, "rejected"]], i = "pending", a = { state: function () { return i }, always: function () { return s.done(arguments).fail(arguments), this }, "catch": function (e) { return a.then(null, e) }, pipe: function () { var i = arguments; return ce.Deferred(function (r) { ce.each(o, function (e, t) { var n = v(i[t[4]]) && i[t[4]]; s[t[1]](function () { var e = n && n.apply(this, arguments); e && v(e.promise) ? e.promise().progress(r.notify).done(r.resolve).fail(r.reject) : r[t[0] + "With"](this, n ? [e] : arguments) }) }), i = null }).promise() }, then: function (t, n, r) { var u = 0; function l(i, o, a, s) { return function () { var n = this, r = arguments, e = function () { var e, t; if (!(i < u)) { if ((e = a.apply(n, r)) === o.promise()) throw new TypeError("Thenable self-resolution"); t = e && ("object" == typeof e || "function" == typeof e) && e.then, v(t) ? s ? t.call(e, l(u, o, N, s), l(u, o, q, s)) : (u++, t.call(e, l(u, o, N, s), l(u, o, q, s), l(u, o, N, o.notifyWith))) : (a !== N && (n = void 0, r = [e]), (s || o.resolveWith)(n, r)) } }, t = s ? e : function () { try { e() } catch (e) { ce.Deferred.exceptionHook && ce.Deferred.exceptionHook(e, t.error), u <= i + 1 && (a !== q && (n = void 0, r = [e]), o.rejectWith(n, r)) } }; i ? t() : (ce.Deferred.getErrorHook ? t.error = ce.Deferred.getErrorHook() : ce.Deferred.getStackHook && (t.error = ce.Deferred.getStackHook()), ie.setTimeout(t)) } } return ce.Deferred(function (e) { o[0][3].add(l(0, e, v(r) ? r : N, e.notifyWith)), o[1][3].add(l(0, e, v(t) ? t : N)), o[2][3].add(l(0, e, v(n) ? n : q)) }).promise() }, promise: function (e) { return null != e ? ce.extend(e, a) : a } }, s = {}; return ce.each(o, function (e, t) { var n = t[2], r = t[5]; a[t[1]] = n.add, r && n.add(function () { i = r }, o[3 - e][2].disable, o[3 - e][3].disable, o[0][2].lock, o[0][3].lock), n.add(t[3].fire), s[t[0]] = function () { return s[t[0] + "With"](this === s ? void 0 : this, arguments), this }, s[t[0] + "With"] = n.fireWith }), a.promise(s), e && e.call(s, s), s }, when: function (e) { var n = arguments.length, t = n, r = Array(t), i = ae.call(arguments), o = ce.Deferred(), a = function (t) { return function (e) { r[t] = this, i[t] = 1 < arguments.length ? ae.call(arguments) : e, --n || o.resolveWith(r, i) } }; if (n <= 1 && (L(e, o.done(a(t)).resolve, o.reject, !n), "pending" === o.state() || v(i[t] && i[t].then))) return o.then(); while (t--) L(i[t], a(t), o.reject); return o.promise() } }); var H = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/; ce.Deferred.exceptionHook = function (e, t) { ie.console && ie.console.warn && e && H.test(e.name) && ie.console.warn("jQuery.Deferred exception: " + e.message, e.stack, t) }, ce.readyException = function (e) { ie.setTimeout(function () { throw e }) }; var O = ce.Deferred(); function P() { C.removeEventListener("DOMContentLoaded", P), ie.removeEventListener("load", P), ce.ready() } ce.fn.ready = function (e) { return O.then(e)["catch"](function (e) { ce.readyException(e) }), this }, ce.extend({ isReady: !1, readyWait: 1, ready: function (e) { (!0 === e ? --ce.readyWait : ce.isReady) || (ce.isReady = !0) !== e && 0 < --ce.readyWait || O.resolveWith(C, [ce]) } }), ce.ready.then = O.then, "complete" === C.readyState || "loading" !== C.readyState && !C.documentElement.doScroll ? ie.setTimeout(ce.ready) : (C.addEventListener("DOMContentLoaded", P), ie.addEventListener("load", P)); var M = function (e, t, n, r, i, o, a) { var s = 0, u = e.length, l = null == n; if ("object" === x(n)) for (s in i = !0, n) M(e, t, s, n[s], !0, o, a); else if (void 0 !== r && (i = !0, v(r) || (a = !0), l && (a ? (t.call(e, r), t = null) : (l = t, t = function (e, t, n) { return l.call(ce(e), n) })), t)) for (; s < u; s++)t(e[s], n, a ? r : r.call(e[s], s, t(e[s], n))); return i ? e : l ? t.call(e) : u ? t(e[0], n) : o }, R = /^-ms-/, I = /-([a-z])/g; function W(e, t) { return t.toUpperCase() } function F(e) { return e.replace(R, "ms-").replace(I, W) } var $ = function (e) { return 1 === e.nodeType || 9 === e.nodeType || !+e.nodeType }; function B() { this.expando = ce.expando + B.uid++ } B.uid = 1, B.prototype = { cache: function (e) { var t = e[this.expando]; return t || (t = {}, $(e) && (e.nodeType ? e[this.expando] = t : Object.defineProperty(e, this.expando, { value: t, configurable: !0 }))), t }, set: function (e, t, n) { var r, i = this.cache(e); if ("string" == typeof t) i[F(t)] = n; else for (r in t) i[F(r)] = t[r]; return i }, get: function (e, t) { return void 0 === t ? this.cache(e) : e[this.expando] && e[this.expando][F(t)] }, access: function (e, t, n) { return void 0 === t || t && "string" == typeof t && void 0 === n ? this.get(e, t) : (this.set(e, t, n), void 0 !== n ? n : t) }, remove: function (e, t) { var n, r = e[this.expando]; if (void 0 !== r) { if (void 0 !== t) { n = (t = Array.isArray(t) ? t.map(F) : (t = F(t)) in r ? [t] : t.match(D) || []).length; while (n--) delete r[t[n]] } (void 0 === t || ce.isEmptyObject(r)) && (e.nodeType ? e[this.expando] = void 0 : delete e[this.expando]) } }, hasData: function (e) { var t = e[this.expando]; return void 0 !== t && !ce.isEmptyObject(t) } }; var _ = new B, z = new B, X = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/, U = /[A-Z]/g; function V(e, t, n) { var r, i; if (void 0 === n && 1 === e.nodeType) if (r = "data-" + t.replace(U, "-$&").toLowerCase(), "string" == typeof (n = e.getAttribute(r))) { try { n = "true" === (i = n) || "false" !== i && ("null" === i ? null : i === +i + "" ? +i : X.test(i) ? JSON.parse(i) : i) } catch (e) { } z.set(e, t, n) } else n = void 0; return n } ce.extend({ hasData: function (e) { return z.hasData(e) || _.hasData(e) }, data: function (e, t, n) { return z.access(e, t, n) }, removeData: function (e, t) { z.remove(e, t) }, _data: function (e, t, n) { return _.access(e, t, n) }, _removeData: function (e, t) { _.remove(e, t) } }), ce.fn.extend({ data: function (n, e) { var t, r, i, o = this[0], a = o && o.attributes; if (void 0 === n) { if (this.length && (i = z.get(o), 1 === o.nodeType && !_.get(o, "hasDataAttrs"))) { t = a.length; while (t--) a[t] && 0 === (r = a[t].name).indexOf("data-") && (r = F(r.slice(5)), V(o, r, i[r])); _.set(o, "hasDataAttrs", !0) } return i } return "object" == typeof n ? this.each(function () { z.set(this, n) }) : M(this, function (e) { var t; if (o && void 0 === e) return void 0 !== (t = z.get(o, n)) ? t : void 0 !== (t = V(o, n)) ? t : void 0; this.each(function () { z.set(this, n, e) }) }, null, e, 1 < arguments.length, null, !0) }, removeData: function (e) { return this.each(function () { z.remove(this, e) }) } }), ce.extend({ queue: function (e, t, n) { var r; if (e) return t = (t || "fx") + "queue", r = _.get(e, t), n && (!r || Array.isArray(n) ? r = _.access(e, t, ce.makeArray(n)) : r.push(n)), r || [] }, dequeue: function (e, t) { t = t || "fx"; var n = ce.queue(e, t), r = n.length, i = n.shift(), o = ce._queueHooks(e, t); "inprogress" === i && (i = n.shift(), r--), i && ("fx" === t && n.unshift("inprogress"), delete o.stop, i.call(e, function () { ce.dequeue(e, t) }, o)), !r && o && o.empty.fire() }, _queueHooks: function (e, t) { var n = t + "queueHooks"; return _.get(e, n) || _.access(e, n, { empty: ce.Callbacks("once memory").add(function () { _.remove(e, [t + "queue", n]) }) }) } }), ce.fn.extend({ queue: function (t, n) { var e = 2; return "string" != typeof t && (n = t, t = "fx", e--), arguments.length < e ? ce.queue(this[0], t) : void 0 === n ? this : this.each(function () { var e = ce.queue(this, t, n); ce._queueHooks(this, t), "fx" === t && "inprogress" !== e[0] && ce.dequeue(this, t) }) }, dequeue: function (e) { return this.each(function () { ce.dequeue(this, e) }) }, clearQueue: function (e) { return this.queue(e || "fx", []) }, promise: function (e, t) { var n, r = 1, i = ce.Deferred(), o = this, a = this.length, s = function () { --r || i.resolveWith(o, [o]) }; "string" != typeof e && (t = e, e = void 0), e = e || "fx"; while (a--) (n = _.get(o[a], e + "queueHooks")) && n.empty && (r++, n.empty.add(s)); return s(), i.promise(t) } }); var G = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source, Y = new RegExp("^(?:([+-])=|)(" + G + ")([a-z%]*)$", "i"), Q = ["Top", "Right", "Bottom", "Left"], J = C.documentElement, K = function (e) { return ce.contains(e.ownerDocument, e) }, Z = { composed: !0 }; J.getRootNode && (K = function (e) { return ce.contains(e.ownerDocument, e) || e.getRootNode(Z) === e.ownerDocument }); var ee = function (e, t) { return "none" === (e = t || e).style.display || "" === e.style.display && K(e) && "none" === ce.css(e, "display") }; function te(e, t, n, r) { var i, o, a = 20, s = r ? function () { return r.cur() } : function () { return ce.css(e, t, "") }, u = s(), l = n && n[3] || (ce.cssNumber[t] ? "" : "px"), c = e.nodeType && (ce.cssNumber[t] || "px" !== l && +u) && Y.exec(ce.css(e, t)); if (c && c[3] !== l) { u /= 2, l = l || c[3], c = +u || 1; while (a--) ce.style(e, t, c + l), (1 - o) * (1 - (o = s() / u || .5)) <= 0 && (a = 0), c /= o; c *= 2, ce.style(e, t, c + l), n = n || [] } return n && (c = +c || +u || 0, i = n[1] ? c + (n[1] + 1) * n[2] : +n[2], r && (r.unit = l, r.start = c, r.end = i)), i } var ne = {}; function re(e, t) { for (var n, r, i, o, a, s, u, l = [], c = 0, f = e.length; c < f; c++)(r = e[c]).style && (n = r.style.display, t ? ("none" === n && (l[c] = _.get(r, "display") || null, l[c] || (r.style.display = "")), "" === r.style.display && ee(r) && (l[c] = (u = a = o = void 0, a = (i = r).ownerDocument, s = i.nodeName, (u = ne[s]) || (o = a.body.appendChild(a.createElement(s)), u = ce.css(o, "display"), o.parentNode.removeChild(o), "none" === u && (u = "block"), ne[s] = u)))) : "none" !== n && (l[c] = "none", _.set(r, "display", n))); for (c = 0; c < f; c++)null != l[c] && (e[c].style.display = l[c]); return e } ce.fn.extend({ show: function () { return re(this, !0) }, hide: function () { return re(this) }, toggle: function (e) { return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each(function () { ee(this) ? ce(this).show() : ce(this).hide() }) } }); var xe, be, we = /^(?:checkbox|radio)$/i, Te = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i, Ce = /^$|^module$|\/(?:java|ecma)script/i; xe = C.createDocumentFragment().appendChild(C.createElement("div")), (be = C.createElement("input")).setAttribute("type", "radio"), be.setAttribute("checked", "checked"), be.setAttribute("name", "t"), xe.appendChild(be), le.checkClone = xe.cloneNode(!0).cloneNode(!0).lastChild.checked, xe.innerHTML = "<textarea>x</textarea>", le.noCloneChecked = !!xe.cloneNode(!0).lastChild.defaultValue, xe.innerHTML = "<option></option>", le.option = !!xe.lastChild; var ke = { thead: [1, "<table>", "</table>"], col: [2, "<table><colgroup>", "</colgroup></table>"], tr: [2, "<table><tbody>", "</tbody></table>"], td: [3, "<table><tbody><tr>", "</tr></tbody></table>"], _default: [0, "", ""] }; function Se(e, t) { var n; return n = "undefined" != typeof e.getElementsByTagName ? e.getElementsByTagName(t || "*") : "undefined" != typeof e.querySelectorAll ? e.querySelectorAll(t || "*") : [], void 0 === t || t && fe(e, t) ? ce.merge([e], n) : n } function Ee(e, t) { for (var n = 0, r = e.length; n < r; n++)_.set(e[n], "globalEval", !t || _.get(t[n], "globalEval")) } ke.tbody = ke.tfoot = ke.colgroup = ke.caption = ke.thead, ke.th = ke.td, le.option || (ke.optgroup = ke.option = [1, "<select multiple='multiple'>", "</select>"]); var je = /<|&#?\w+;/; function Ae(e, t, n, r, i) { for (var o, a, s, u, l, c, f = t.createDocumentFragment(), p = [], d = 0, h = e.length; d < h; d++)if ((o = e[d]) || 0 === o) if ("object" === x(o)) ce.merge(p, o.nodeType ? [o] : o); else if (je.test(o)) { a = a || f.appendChild(t.createElement("div")), s = (Te.exec(o) || ["", ""])[1].toLowerCase(), u = ke[s] || ke._default, a.innerHTML = u[1] + ce.htmlPrefilter(o) + u[2], c = u[0]; while (c--) a = a.lastChild; ce.merge(p, a.childNodes), (a = f.firstChild).textContent = "" } else p.push(t.createTextNode(o)); f.textContent = "", d = 0; while (o = p[d++]) if (r && -1 < ce.inArray(o, r)) i && i.push(o); else if (l = K(o), a = Se(f.appendChild(o), "script"), l && Ee(a), n) { c = 0; while (o = a[c++]) Ce.test(o.type || "") && n.push(o) } return f } var De = /^([^.]*)(?:\.(.+)|)/; function Ne() { return !0 } function qe() { return !1 } function Le(e, t, n, r, i, o) { var a, s; if ("object" == typeof t) { for (s in "string" != typeof n && (r = r || n, n = void 0), t) Le(e, s, n, r, t[s], o); return e } if (null == r && null == i ? (i = n, r = n = void 0) : null == i && ("string" == typeof n ? (i = r, r = void 0) : (i = r, r = n, n = void 0)), !1 === i) i = qe; else if (!i) return e; return 1 === o && (a = i, (i = function (e) { return ce().off(e), a.apply(this, arguments) }).guid = a.guid || (a.guid = ce.guid++)), e.each(function () { ce.event.add(this, t, i, r, n) }) } function He(e, r, t) { t ? (_.set(e, r, !1), ce.event.add(e, r, { namespace: !1, handler: function (e) { var t, n = _.get(this, r); if (1 & e.isTrigger && this[r]) { if (n) (ce.event.special[r] || {}).delegateType && e.stopPropagation(); else if (n = ae.call(arguments), _.set(this, r, n), this[r](), t = _.get(this, r), _.set(this, r, !1), n !== t) return e.stopImmediatePropagation(), e.preventDefault(), t } else n && (_.set(this, r, ce.event.trigger(n[0], n.slice(1), this)), e.stopPropagation(), e.isImmediatePropagationStopped = Ne) } })) : void 0 === _.get(e, r) && ce.event.add(e, r, Ne) } ce.event = { global: {}, add: function (t, e, n, r, i) { var o, a, s, u, l, c, f, p, d, h, g, v = _.get(t); if ($(t)) { n.handler && (n = (o = n).handler, i = o.selector), i && ce.find.matchesSelector(J, i), n.guid || (n.guid = ce.guid++), (u = v.events) || (u = v.events = Object.create(null)), (a = v.handle) || (a = v.handle = function (e) { return "undefined" != typeof ce && ce.event.triggered !== e.type ? ce.event.dispatch.apply(t, arguments) : void 0 }), l = (e = (e || "").match(D) || [""]).length; while (l--) d = g = (s = De.exec(e[l]) || [])[1], h = (s[2] || "").split(".").sort(), d && (f = ce.event.special[d] || {}, d = (i ? f.delegateType : f.bindType) || d, f = ce.event.special[d] || {}, c = ce.extend({ type: d, origType: g, data: r, handler: n, guid: n.guid, selector: i, needsContext: i && ce.expr.match.needsContext.test(i), namespace: h.join(".") }, o), (p = u[d]) || ((p = u[d] = []).delegateCount = 0, f.setup && !1 !== f.setup.call(t, r, h, a) || t.addEventListener && t.addEventListener(d, a)), f.add && (f.add.call(t, c), c.handler.guid || (c.handler.guid = n.guid)), i ? p.splice(p.delegateCount++, 0, c) : p.push(c), ce.event.global[d] = !0) } }, remove: function (e, t, n, r, i) { var o, a, s, u, l, c, f, p, d, h, g, v = _.hasData(e) && _.get(e); if (v && (u = v.events)) { l = (t = (t || "").match(D) || [""]).length; while (l--) if (d = g = (s = De.exec(t[l]) || [])[1], h = (s[2] || "").split(".").sort(), d) { f = ce.event.special[d] || {}, p = u[d = (r ? f.delegateType : f.bindType) || d] || [], s = s[2] && new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)"), a = o = p.length; while (o--) c = p[o], !i && g !== c.origType || n && n.guid !== c.guid || s && !s.test(c.namespace) || r && r !== c.selector && ("**" !== r || !c.selector) || (p.splice(o, 1), c.selector && p.delegateCount--, f.remove && f.remove.call(e, c)); a && !p.length && (f.teardown && !1 !== f.teardown.call(e, h, v.handle) || ce.removeEvent(e, d, v.handle), delete u[d]) } else for (d in u) ce.event.remove(e, d + t[l], n, r, !0); ce.isEmptyObject(u) && _.remove(e, "handle events") } }, dispatch: function (e) { var t, n, r, i, o, a, s = new Array(arguments.length), u = ce.event.fix(e), l = (_.get(this, "events") || Object.create(null))[u.type] || [], c = ce.event.special[u.type] || {}; for (s[0] = u, t = 1; t < arguments.length; t++)s[t] = arguments[t]; if (u.delegateTarget = this, !c.preDispatch || !1 !== c.preDispatch.call(this, u)) { a = ce.event.handlers.call(this, u, l), t = 0; while ((i = a[t++]) && !u.isPropagationStopped()) { u.currentTarget = i.elem, n = 0; while ((o = i.handlers[n++]) && !u.isImmediatePropagationStopped()) u.rnamespace && !1 !== o.namespace && !u.rnamespace.test(o.namespace) || (u.handleObj = o, u.data = o.data, void 0 !== (r = ((ce.event.special[o.origType] || {}).handle || o.handler).apply(i.elem, s)) && !1 === (u.result = r) && (u.preventDefault(), u.stopPropagation())) } return c.postDispatch && c.postDispatch.call(this, u), u.result } }, handlers: function (e, t) { var n, r, i, o, a, s = [], u = t.delegateCount, l = e.target; if (u && l.nodeType && !("click" === e.type && 1 <= e.button)) for (; l !== this; l = l.parentNode || this)if (1 === l.nodeType && ("click" !== e.type || !0 !== l.disabled)) { for (o = [], a = {}, n = 0; n < u; n++)void 0 === a[i = (r = t[n]).selector + " "] && (a[i] = r.needsContext ? -1 < ce(i, this).index(l) : ce.find(i, this, null, [l]).length), a[i] && o.push(r); o.length && s.push({ elem: l, handlers: o }) } return l = this, u < t.length && s.push({ elem: l, handlers: t.slice(u) }), s }, addProp: function (t, e) { Object.defineProperty(ce.Event.prototype, t, { enumerable: !0, configurable: !0, get: v(e) ? function () { if (this.originalEvent) return e(this.originalEvent) } : function () { if (this.originalEvent) return this.originalEvent[t] }, set: function (e) { Object.defineProperty(this, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) } }) }, fix: function (e) { return e[ce.expando] ? e : new ce.Event(e) }, special: { load: { noBubble: !0 }, click: { setup: function (e) { var t = this || e; return we.test(t.type) && t.click && fe(t, "input") && He(t, "click", !0), !1 }, trigger: function (e) { var t = this || e; return we.test(t.type) && t.click && fe(t, "input") && He(t, "click"), !0 }, _default: function (e) { var t = e.target; return we.test(t.type) && t.click && fe(t, "input") && _.get(t, "click") || fe(t, "a") } }, beforeunload: { postDispatch: function (e) { void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result) } } } }, ce.removeEvent = function (e, t, n) { e.removeEventListener && e.removeEventListener(t, n) }, ce.Event = function (e, t) { if (!(this instanceof ce.Event)) return new ce.Event(e, t); e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && !1 === e.returnValue ? Ne : qe, this.target = e.target && 3 === e.target.nodeType ? e.target.parentNode : e.target, this.currentTarget = e.currentTarget, this.relatedTarget = e.relatedTarget) : this.type = e, t && ce.extend(this, t), this.timeStamp = e && e.timeStamp || Date.now(), this[ce.expando] = !0 }, ce.Event.prototype = { constructor: ce.Event, isDefaultPrevented: qe, isPropagationStopped: qe, isImmediatePropagationStopped: qe, isSimulated: !1, preventDefault: function () { var e = this.originalEvent; this.isDefaultPrevented = Ne, e && !this.isSimulated && e.preventDefault() }, stopPropagation: function () { var e = this.originalEvent; this.isPropagationStopped = Ne, e && !this.isSimulated && e.stopPropagation() }, stopImmediatePropagation: function () { var e = this.originalEvent; this.isImmediatePropagationStopped = Ne, e && !this.isSimulated && e.stopImmediatePropagation(), this.stopPropagation() } }, ce.each({ altKey: !0, bubbles: !0, cancelable: !0, changedTouches: !0, ctrlKey: !0, detail: !0, eventPhase: !0, metaKey: !0, pageX: !0, pageY: !0, shiftKey: !0, view: !0, "char": !0, code: !0, charCode: !0, key: !0, keyCode: !0, button: !0, buttons: !0, clientX: !0, clientY: !0, offsetX: !0, offsetY: !0, pointerId: !0, pointerType: !0, screenX: !0, screenY: !0, targetTouches: !0, toElement: !0, touches: !0, which: !0 }, ce.event.addProp), ce.each({ focus: "focusin", blur: "focusout" }, function (r, i) { function o(e) { if (C.documentMode) { var t = _.get(this, "handle"), n = ce.event.fix(e); n.type = "focusin" === e.type ? "focus" : "blur", n.isSimulated = !0, t(e), n.target === n.currentTarget && t(n) } else ce.event.simulate(i, e.target, ce.event.fix(e)) } ce.event.special[r] = { setup: function () { var e; if (He(this, r, !0), !C.documentMode) return !1; (e = _.get(this, i)) || this.addEventListener(i, o), _.set(this, i, (e || 0) + 1) }, trigger: function () { return He(this, r), !0 }, teardown: function () { var e; if (!C.documentMode) return !1; (e = _.get(this, i) - 1) ? _.set(this, i, e) : (this.removeEventListener(i, o), _.remove(this, i)) }, _default: function (e) { return _.get(e.target, r) }, delegateType: i }, ce.event.special[i] = { setup: function () { var e = this.ownerDocument || this.document || this, t = C.documentMode ? this : e, n = _.get(t, i); n || (C.documentMode ? this.addEventListener(i, o) : e.addEventListener(r, o, !0)), _.set(t, i, (n || 0) + 1) }, teardown: function () { var e = this.ownerDocument || this.document || this, t = C.documentMode ? this : e, n = _.get(t, i) - 1; n ? _.set(t, i, n) : (C.documentMode ? this.removeEventListener(i, o) : e.removeEventListener(r, o, !0), _.remove(t, i)) } } }), ce.each({ mouseenter: "mouseover", mouseleave: "mouseout", pointerenter: "pointerover", pointerleave: "pointerout" }, function (e, i) { ce.event.special[e] = { delegateType: i, bindType: i, handle: function (e) { var t, n = e.relatedTarget, r = e.handleObj; return n && (n === this || ce.contains(this, n)) || (e.type = r.origType, t = r.handler.apply(this, arguments), e.type = i), t } } }), ce.fn.extend({ on: function (e, t, n, r) { return Le(this, e, t, n, r) }, one: function (e, t, n, r) { return Le(this, e, t, n, r, 1) }, off: function (e, t, n) { var r, i; if (e && e.preventDefault && e.handleObj) return r = e.handleObj, ce(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler), this; if ("object" == typeof e) { for (i in e) this.off(i, t, e[i]); return this } return !1 !== t && "function" != typeof t || (n = t, t = void 0), !1 === n && (n = qe), this.each(function () { ce.event.remove(this, e, n, t) }) } }); var Oe = /<script|<style|<link/i, Pe = /checked\s*(?:[^=]|=\s*.checked.)/i, Me = /^\s*<!\[CDATA\[|\]\]>\s*$/g; function Re(e, t) { return fe(e, "table") && fe(11 !== t.nodeType ? t : t.firstChild, "tr") && ce(e).children("tbody")[0] || e } function Ie(e) { return e.type = (null !== e.getAttribute("type")) + "/" + e.type, e } function We(e) { return "true/" === (e.type || "").slice(0, 5) ? e.type = e.type.slice(5) : e.removeAttribute("type"), e } function Fe(e, t) { var n, r, i, o, a, s; if (1 === t.nodeType) { if (_.hasData(e) && (s = _.get(e).events)) for (i in _.remove(t, "handle events"), s) for (n = 0, r = s[i].length; n < r; n++)ce.event.add(t, i, s[i][n]); z.hasData(e) && (o = z.access(e), a = ce.extend({}, o), z.set(t, a)) } } function $e(n, r, i, o) { r = g(r); var e, t, a, s, u, l, c = 0, f = n.length, p = f - 1, d = r[0], h = v(d); if (h || 1 < f && "string" == typeof d && !le.checkClone && Pe.test(d)) return n.each(function (e) { var t = n.eq(e); h && (r[0] = d.call(this, e, t.html())), $e(t, r, i, o) }); if (f && (t = (e = Ae(r, n[0].ownerDocument, !1, n, o)).firstChild, 1 === e.childNodes.length && (e = t), t || o)) { for (s = (a = ce.map(Se(e, "script"), Ie)).length; c < f; c++)u = e, c !== p && (u = ce.clone(u, !0, !0), s && ce.merge(a, Se(u, "script"))), i.call(n[c], u, c); if (s) for (l = a[a.length - 1].ownerDocument, ce.map(a, We), c = 0; c < s; c++)u = a[c], Ce.test(u.type || "") && !_.access(u, "globalEval") && ce.contains(l, u) && (u.src && "module" !== (u.type || "").toLowerCase() ? ce._evalUrl && !u.noModule && ce._evalUrl(u.src, { nonce: u.nonce || u.getAttribute("nonce") }, l) : m(u.textContent.replace(Me, ""), u, l)) } return n } function Be(e, t, n) { for (var r, i = t ? ce.filter(t, e) : e, o = 0; null != (r = i[o]); o++)n || 1 !== r.nodeType || ce.cleanData(Se(r)), r.parentNode && (n && K(r) && Ee(Se(r, "script")), r.parentNode.removeChild(r)); return e } ce.extend({ htmlPrefilter: function (e) { return e }, clone: function (e, t, n) { var r, i, o, a, s, u, l, c = e.cloneNode(!0), f = K(e); if (!(le.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || ce.isXMLDoc(e))) for (a = Se(c), r = 0, i = (o = Se(e)).length; r < i; r++)s = o[r], u = a[r], void 0, "input" === (l = u.nodeName.toLowerCase()) && we.test(s.type) ? u.checked = s.checked : "input" !== l && "textarea" !== l || (u.defaultValue = s.defaultValue); if (t) if (n) for (o = o || Se(e), a = a || Se(c), r = 0, i = o.length; r < i; r++)Fe(o[r], a[r]); else Fe(e, c); return 0 < (a = Se(c, "script")).length && Ee(a, !f && Se(e, "script")), c }, cleanData: function (e) { for (var t, n, r, i = ce.event.special, o = 0; void 0 !== (n = e[o]); o++)if ($(n)) { if (t = n[_.expando]) { if (t.events) for (r in t.events) i[r] ? ce.event.remove(n, r) : ce.removeEvent(n, r, t.handle); n[_.expando] = void 0 } n[z.expando] && (n[z.expando] = void 0) } } }), ce.fn.extend({ detach: function (e) { return Be(this, e, !0) }, remove: function (e) { return Be(this, e) }, text: function (e) { return M(this, function (e) { return void 0 === e ? ce.text(this) : this.empty().each(function () { 1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || (this.textContent = e) }) }, null, e, arguments.length) }, append: function () { return $e(this, arguments, function (e) { 1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || Re(this, e).appendChild(e) }) }, prepend: function () { return $e(this, arguments, function (e) { if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) { var t = Re(this, e); t.insertBefore(e, t.firstChild) } }) }, before: function () { return $e(this, arguments, function (e) { this.parentNode && this.parentNode.insertBefore(e, this) }) }, after: function () { return $e(this, arguments, function (e) { this.parentNode && this.parentNode.insertBefore(e, this.nextSibling) }) }, empty: function () { for (var e, t = 0; null != (e = this[t]); t++)1 === e.nodeType && (ce.cleanData(Se(e, !1)), e.textContent = ""); return this }, clone: function (e, t) { return e = null != e && e, t = null == t ? e : t, this.map(function () { return ce.clone(this, e, t) }) }, html: function (e) { return M(this, function (e) { var t = this[0] || {}, n = 0, r = this.length; if (void 0 === e && 1 === t.nodeType) return t.innerHTML; if ("string" == typeof e && !Oe.test(e) && !ke[(Te.exec(e) || ["", ""])[1].toLowerCase()]) { e = ce.htmlPrefilter(e); try { for (; n < r; n++)1 === (t = this[n] || {}).nodeType && (ce.cleanData(Se(t, !1)), t.innerHTML = e); t = 0 } catch (e) { } } t && this.empty().append(e) }, null, e, arguments.length) }, replaceWith: function () { var n = []; return $e(this, arguments, function (e) { var t = this.parentNode; ce.inArray(this, n) < 0 && (ce.cleanData(Se(this)), t && t.replaceChild(e, this)) }, n) } }), ce.each({ appendTo: "append", prependTo: "prepend", insertBefore: "before", insertAfter: "after", replaceAll: "replaceWith" }, function (e, a) { ce.fn[e] = function (e) { for (var t, n = [], r = ce(e), i = r.length - 1, o = 0; o <= i; o++)t = o === i ? this : this.clone(!0), ce(r[o])[a](t), s.apply(n, t.get()); return this.pushStack(n) } }); var _e = new RegExp("^(" + G + ")(?!px)[a-z%]+$", "i"), ze = /^--/, Xe = function (e) { var t = e.ownerDocument.defaultView; return t && t.opener || (t = ie), t.getComputedStyle(e) }, Ue = function (e, t, n) { var r, i, o = {}; for (i in t) o[i] = e.style[i], e.style[i] = t[i]; for (i in r = n.call(e), t) e.style[i] = o[i]; return r }, Ve = new RegExp(Q.join("|"), "i"); function Ge(e, t, n) { var r, i, o, a, s = ze.test(t), u = e.style; return (n = n || Xe(e)) && (a = n.getPropertyValue(t) || n[t], s && a && (a = a.replace(ve, "$1") || void 0), "" !== a || K(e) || (a = ce.style(e, t)), !le.pixelBoxStyles() && _e.test(a) && Ve.test(t) && (r = u.width, i = u.minWidth, o = u.maxWidth, u.minWidth = u.maxWidth = u.width = a, a = n.width, u.width = r, u.minWidth = i, u.maxWidth = o)), void 0 !== a ? a + "" : a } function Ye(e, t) { return { get: function () { if (!e()) return (this.get = t).apply(this, arguments); delete this.get } } } !function () { function e() { if (l) { u.style.cssText = "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0", l.style.cssText = "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%", J.appendChild(u).appendChild(l); var e = ie.getComputedStyle(l); n = "1%" !== e.top, s = 12 === t(e.marginLeft), l.style.right = "60%", o = 36 === t(e.right), r = 36 === t(e.width), l.style.position = "absolute", i = 12 === t(l.offsetWidth / 3), J.removeChild(u), l = null } } function t(e) { return Math.round(parseFloat(e)) } var n, r, i, o, a, s, u = C.createElement("div"), l = C.createElement("div"); l.style && (l.style.backgroundClip = "content-box", l.cloneNode(!0).style.backgroundClip = "", le.clearCloneStyle = "content-box" === l.style.backgroundClip, ce.extend(le, { boxSizingReliable: function () { return e(), r }, pixelBoxStyles: function () { return e(), o }, pixelPosition: function () { return e(), n }, reliableMarginLeft: function () { return e(), s }, scrollboxSize: function () { return e(), i }, reliableTrDimensions: function () { var e, t, n, r; return null == a && (e = C.createElement("table"), t = C.createElement("tr"), n = C.createElement("div"), e.style.cssText = "position:absolute;left:-11111px;border-collapse:separate", t.style.cssText = "box-sizing:content-box;border:1px solid", t.style.height = "1px", n.style.height = "9px", n.style.display = "block", J.appendChild(e).appendChild(t).appendChild(n), r = ie.getComputedStyle(t), a = parseInt(r.height, 10) + parseInt(r.borderTopWidth, 10) + parseInt(r.borderBottomWidth, 10) === t.offsetHeight, J.removeChild(e)), a } })) }(); var Qe = ["Webkit", "Moz", "ms"], Je = C.createElement("div").style, Ke = {}; function Ze(e) { var t = ce.cssProps[e] || Ke[e]; return t || (e in Je ? e : Ke[e] = function (e) { var t = e[0].toUpperCase() + e.slice(1), n = Qe.length; while (n--) if ((e = Qe[n] + t) in Je) return e }(e) || e) } var et = /^(none|table(?!-c[ea]).+)/, tt = { position: "absolute", visibility: "hidden", display: "block" }, nt = { letterSpacing: "0", fontWeight: "400" }; function rt(e, t, n) { var r = Y.exec(t); return r ? Math.max(0, r[2] - (n || 0)) + (r[3] || "px") : t } function it(e, t, n, r, i, o) { var a = "width" === t ? 1 : 0, s = 0, u = 0, l = 0; if (n === (r ? "border" : "content")) return 0; for (; a < 4; a += 2)"margin" === n && (l += ce.css(e, n + Q[a], !0, i)), r ? ("content" === n && (u -= ce.css(e, "padding" + Q[a], !0, i)), "margin" !== n && (u -= ce.css(e, "border" + Q[a] + "Width", !0, i))) : (u += ce.css(e, "padding" + Q[a], !0, i), "padding" !== n ? u += ce.css(e, "border" + Q[a] + "Width", !0, i) : s += ce.css(e, "border" + Q[a] + "Width", !0, i)); return !r && 0 <= o && (u += Math.max(0, Math.ceil(e["offset" + t[0].toUpperCase() + t.slice(1)] - o - u - s - .5)) || 0), u + l } function ot(e, t, n) { var r = Xe(e), i = (!le.boxSizingReliable() || n) && "border-box" === ce.css(e, "boxSizing", !1, r), o = i, a = Ge(e, t, r), s = "offset" + t[0].toUpperCase() + t.slice(1); if (_e.test(a)) { if (!n) return a; a = "auto" } return (!le.boxSizingReliable() && i || !le.reliableTrDimensions() && fe(e, "tr") || "auto" === a || !parseFloat(a) && "inline" === ce.css(e, "display", !1, r)) && e.getClientRects().length && (i = "border-box" === ce.css(e, "boxSizing", !1, r), (o = s in e) && (a = e[s])), (a = parseFloat(a) || 0) + it(e, t, n || (i ? "border" : "content"), o, r, a) + "px" } function at(e, t, n, r, i) { return new at.prototype.init(e, t, n, r, i) } ce.extend({ cssHooks: { opacity: { get: function (e, t) { if (t) { var n = Ge(e, "opacity"); return "" === n ? "1" : n } } } }, cssNumber: { animationIterationCount: !0, aspectRatio: !0, borderImageSlice: !0, columnCount: !0, flexGrow: !0, flexShrink: !0, fontWeight: !0, gridArea: !0, gridColumn: !0, gridColumnEnd: !0, gridColumnStart: !0, gridRow: !0, gridRowEnd: !0, gridRowStart: !0, lineHeight: !0, opacity: !0, order: !0, orphans: !0, scale: !0, widows: !0, zIndex: !0, zoom: !0, fillOpacity: !0, floodOpacity: !0, stopOpacity: !0, strokeMiterlimit: !0, strokeOpacity: !0 }, cssProps: {}, style: function (e, t, n, r) { if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) { var i, o, a, s = F(t), u = ze.test(t), l = e.style; if (u || (t = Ze(s)), a = ce.cssHooks[t] || ce.cssHooks[s], void 0 === n) return a && "get" in a && void 0 !== (i = a.get(e, !1, r)) ? i : l[t]; "string" === (o = typeof n) && (i = Y.exec(n)) && i[1] && (n = te(e, t, i), o = "number"), null != n && n == n && ("number" !== o || u || (n += i && i[3] || (ce.cssNumber[s] ? "" : "px")), le.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (l[t] = "inherit"), a && "set" in a && void 0 === (n = a.set(e, n, r)) || (u ? l.setProperty(t, n) : l[t] = n)) } }, css: function (e, t, n, r) { var i, o, a, s = F(t); return ze.test(t) || (t = Ze(s)), (a = ce.cssHooks[t] || ce.cssHooks[s]) && "get" in a && (i = a.get(e, !0, n)), void 0 === i && (i = Ge(e, t, r)), "normal" === i && t in nt && (i = nt[t]), "" === n || n ? (o = parseFloat(i), !0 === n || isFinite(o) ? o || 0 : i) : i } }), ce.each(["height", "width"], function (e, u) { ce.cssHooks[u] = { get: function (e, t, n) { if (t) return !et.test(ce.css(e, "display")) || e.getClientRects().length && e.getBoundingClientRect().width ? ot(e, u, n) : Ue(e, tt, function () { return ot(e, u, n) }) }, set: function (e, t, n) { var r, i = Xe(e), o = !le.scrollboxSize() && "absolute" === i.position, a = (o || n) && "border-box" === ce.css(e, "boxSizing", !1, i), s = n ? it(e, u, n, a, i) : 0; return a && o && (s -= Math.ceil(e["offset" + u[0].toUpperCase() + u.slice(1)] - parseFloat(i[u]) - it(e, u, "border", !1, i) - .5)), s && (r = Y.exec(t)) && "px" !== (r[3] || "px") && (e.style[u] = t, t = ce.css(e, u)), rt(0, t, s) } } }), ce.cssHooks.marginLeft = Ye(le.reliableMarginLeft, function (e, t) { if (t) return (parseFloat(Ge(e, "marginLeft")) || e.getBoundingClientRect().left - Ue(e, { marginLeft: 0 }, function () { return e.getBoundingClientRect().left })) + "px" }), ce.each({ margin: "", padding: "", border: "Width" }, function (i, o) { ce.cssHooks[i + o] = { expand: function (e) { for (var t = 0, n = {}, r = "string" == typeof e ? e.split(" ") : [e]; t < 4; t++)n[i + Q[t] + o] = r[t] || r[t - 2] || r[0]; return n } }, "margin" !== i && (ce.cssHooks[i + o].set = rt) }), ce.fn.extend({ css: function (e, t) { return M(this, function (e, t, n) { var r, i, o = {}, a = 0; if (Array.isArray(t)) { for (r = Xe(e), i = t.length; a < i; a++)o[t[a]] = ce.css(e, t[a], !1, r); return o } return void 0 !== n ? ce.style(e, t, n) : ce.css(e, t) }, e, t, 1 < arguments.length) } }), ((ce.Tween = at).prototype = { constructor: at, init: function (e, t, n, r, i, o) { this.elem = e, this.prop = n, this.easing = i || ce.easing._default, this.options = t, this.start = this.now = this.cur(), this.end = r, this.unit = o || (ce.cssNumber[n] ? "" : "px") }, cur: function () { var e = at.propHooks[this.prop]; return e && e.get ? e.get(this) : at.propHooks._default.get(this) }, run: function (e) { var t, n = at.propHooks[this.prop]; return this.options.duration ? this.pos = t = ce.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : at.propHooks._default.set(this), this } }).init.prototype = at.prototype, (at.propHooks = { _default: { get: function (e) { var t; return 1 !== e.elem.nodeType || null != e.elem[e.prop] && null == e.elem.style[e.prop] ? e.elem[e.prop] : (t = ce.css(e.elem, e.prop, "")) && "auto" !== t ? t : 0 }, set: function (e) { ce.fx.step[e.prop] ? ce.fx.step[e.prop](e) : 1 !== e.elem.nodeType || !ce.cssHooks[e.prop] && null == e.elem.style[Ze(e.prop)] ? e.elem[e.prop] = e.now : ce.style(e.elem, e.prop, e.now + e.unit) } } }).scrollTop = at.propHooks.scrollLeft = { set: function (e) { e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now) } }, ce.easing = { linear: function (e) { return e }, swing: function (e) { return .5 - Math.cos(e * Math.PI) / 2 }, _default: "swing" }, ce.fx = at.prototype.init, ce.fx.step = {}; var st, ut, lt, ct, ft = /^(?:toggle|show|hide)$/, pt = /queueHooks$/; function dt() { ut && (!1 === C.hidden && ie.requestAnimationFrame ? ie.requestAnimationFrame(dt) : ie.setTimeout(dt, ce.fx.interval), ce.fx.tick()) } function ht() { return ie.setTimeout(function () { st = void 0 }), st = Date.now() } function gt(e, t) { var n, r = 0, i = { height: e }; for (t = t ? 1 : 0; r < 4; r += 2 - t)i["margin" + (n = Q[r])] = i["padding" + n] = e; return t && (i.opacity = i.width = e), i } function vt(e, t, n) { for (var r, i = (yt.tweeners[t] || []).concat(yt.tweeners["*"]), o = 0, a = i.length; o < a; o++)if (r = i[o].call(n, t, e)) return r } function yt(o, e, t) { var n, a, r = 0, i = yt.prefilters.length, s = ce.Deferred().always(function () { delete u.elem }), u = function () { if (a) return !1; for (var e = st || ht(), t = Math.max(0, l.startTime + l.duration - e), n = 1 - (t / l.duration || 0), r = 0, i = l.tweens.length; r < i; r++)l.tweens[r].run(n); return s.notifyWith(o, [l, n, t]), n < 1 && i ? t : (i || s.notifyWith(o, [l, 1, 0]), s.resolveWith(o, [l]), !1) }, l = s.promise({ elem: o, props: ce.extend({}, e), opts: ce.extend(!0, { specialEasing: {}, easing: ce.easing._default }, t), originalProperties: e, originalOptions: t, startTime: st || ht(), duration: t.duration, tweens: [], createTween: function (e, t) { var n = ce.Tween(o, l.opts, e, t, l.opts.specialEasing[e] || l.opts.easing); return l.tweens.push(n), n }, stop: function (e) { var t = 0, n = e ? l.tweens.length : 0; if (a) return this; for (a = !0; t < n; t++)l.tweens[t].run(1); return e ? (s.notifyWith(o, [l, 1, 0]), s.resolveWith(o, [l, e])) : s.rejectWith(o, [l, e]), this } }), c = l.props; for (!function (e, t) { var n, r, i, o, a; for (n in e) if (i = t[r = F(n)], o = e[n], Array.isArray(o) && (i = o[1], o = e[n] = o[0]), n !== r && (e[r] = o, delete e[n]), (a = ce.cssHooks[r]) && "expand" in a) for (n in o = a.expand(o), delete e[r], o) n in e || (e[n] = o[n], t[n] = i); else t[r] = i }(c, l.opts.specialEasing); r < i; r++)if (n = yt.prefilters[r].call(l, o, c, l.opts)) return v(n.stop) && (ce._queueHooks(l.elem, l.opts.queue).stop = n.stop.bind(n)), n; return ce.map(c, vt, l), v(l.opts.start) && l.opts.start.call(o, l), l.progress(l.opts.progress).done(l.opts.done, l.opts.complete).fail(l.opts.fail).always(l.opts.always), ce.fx.timer(ce.extend(u, { elem: o, anim: l, queue: l.opts.queue })), l } ce.Animation = ce.extend(yt, { tweeners: { "*": [function (e, t) { var n = this.createTween(e, t); return te(n.elem, e, Y.exec(t), n), n }] }, tweener: function (e, t) { v(e) ? (t = e, e = ["*"]) : e = e.match(D); for (var n, r = 0, i = e.length; r < i; r++)n = e[r], yt.tweeners[n] = yt.tweeners[n] || [], yt.tweeners[n].unshift(t) }, prefilters: [function (e, t, n) { var r, i, o, a, s, u, l, c, f = "width" in t || "height" in t, p = this, d = {}, h = e.style, g = e.nodeType && ee(e), v = _.get(e, "fxshow"); for (r in n.queue || (null == (a = ce._queueHooks(e, "fx")).unqueued && (a.unqueued = 0, s = a.empty.fire, a.empty.fire = function () { a.unqueued || s() }), a.unqueued++, p.always(function () { p.always(function () { a.unqueued--, ce.queue(e, "fx").length || a.empty.fire() }) })), t) if (i = t[r], ft.test(i)) { if (delete t[r], o = o || "toggle" === i, i === (g ? "hide" : "show")) { if ("show" !== i || !v || void 0 === v[r]) continue; g = !0 } d[r] = v && v[r] || ce.style(e, r) } if ((u = !ce.isEmptyObject(t)) || !ce.isEmptyObject(d)) for (r in f && 1 === e.nodeType && (n.overflow = [h.overflow, h.overflowX, h.overflowY], null == (l = v && v.display) && (l = _.get(e, "display")), "none" === (c = ce.css(e, "display")) && (l ? c = l : (re([e], !0), l = e.style.display || l, c = ce.css(e, "display"), re([e]))), ("inline" === c || "inline-block" === c && null != l) && "none" === ce.css(e, "float") && (u || (p.done(function () { h.display = l }), null == l && (c = h.display, l = "none" === c ? "" : c)), h.display = "inline-block")), n.overflow && (h.overflow = "hidden", p.always(function () { h.overflow = n.overflow[0], h.overflowX = n.overflow[1], h.overflowY = n.overflow[2] })), u = !1, d) u || (v ? "hidden" in v && (g = v.hidden) : v = _.access(e, "fxshow", { display: l }), o && (v.hidden = !g), g && re([e], !0), p.done(function () { for (r in g || re([e]), _.remove(e, "fxshow"), d) ce.style(e, r, d[r]) })), u = vt(g ? v[r] : 0, r, p), r in v || (v[r] = u.start, g && (u.end = u.start, u.start = 0)) }], prefilter: function (e, t) { t ? yt.prefilters.unshift(e) : yt.prefilters.push(e) } }), ce.speed = function (e, t, n) { var r = e && "object" == typeof e ? ce.extend({}, e) : { complete: n || !n && t || v(e) && e, duration: e, easing: n && t || t && !v(t) && t }; return ce.fx.off ? r.duration = 0 : "number" != typeof r.duration && (r.duration in ce.fx.speeds ? r.duration = ce.fx.speeds[r.duration] : r.duration = ce.fx.speeds._default), null != r.queue && !0 !== r.queue || (r.queue = "fx"), r.old = r.complete, r.complete = function () { v(r.old) && r.old.call(this), r.queue && ce.dequeue(this, r.queue) }, r }, ce.fn.extend({ fadeTo: function (e, t, n, r) { return this.filter(ee).css("opacity", 0).show().end().animate({ opacity: t }, e, n, r) }, animate: function (t, e, n, r) { var i = ce.isEmptyObject(t), o = ce.speed(e, n, r), a = function () { var e = yt(this, ce.extend({}, t), o); (i || _.get(this, "finish")) && e.stop(!0) }; return a.finish = a, i || !1 === o.queue ? this.each(a) : this.queue(o.queue, a) }, stop: function (i, e, o) { var a = function (e) { var t = e.stop; delete e.stop, t(o) }; return "string" != typeof i && (o = e, e = i, i = void 0), e && this.queue(i || "fx", []), this.each(function () { var e = !0, t = null != i && i + "queueHooks", n = ce.timers, r = _.get(this); if (t) r[t] && r[t].stop && a(r[t]); else for (t in r) r[t] && r[t].stop && pt.test(t) && a(r[t]); for (t = n.length; t--;)n[t].elem !== this || null != i && n[t].queue !== i || (n[t].anim.stop(o), e = !1, n.splice(t, 1)); !e && o || ce.dequeue(this, i) }) }, finish: function (a) { return !1 !== a && (a = a || "fx"), this.each(function () { var e, t = _.get(this), n = t[a + "queue"], r = t[a + "queueHooks"], i = ce.timers, o = n ? n.length : 0; for (t.finish = !0, ce.queue(this, a, []), r && r.stop && r.stop.call(this, !0), e = i.length; e--;)i[e].elem === this && i[e].queue === a && (i[e].anim.stop(!0), i.splice(e, 1)); for (e = 0; e < o; e++)n[e] && n[e].finish && n[e].finish.call(this); delete t.finish }) } }), ce.each(["toggle", "show", "hide"], function (e, r) { var i = ce.fn[r]; ce.fn[r] = function (e, t, n) { return null == e || "boolean" == typeof e ? i.apply(this, arguments) : this.animate(gt(r, !0), e, t, n) } }), ce.each({ slideDown: gt("show"), slideUp: gt("hide"), slideToggle: gt("toggle"), fadeIn: { opacity: "show" }, fadeOut: { opacity: "hide" }, fadeToggle: { opacity: "toggle" } }, function (e, r) { ce.fn[e] = function (e, t, n) { return this.animate(r, e, t, n) } }), ce.timers = [], ce.fx.tick = function () { var e, t = 0, n = ce.timers; for (st = Date.now(); t < n.length; t++)(e = n[t])() || n[t] !== e || n.splice(t--, 1); n.length || ce.fx.stop(), st = void 0 }, ce.fx.timer = function (e) { ce.timers.push(e), ce.fx.start() }, ce.fx.interval = 13, ce.fx.start = function () { ut || (ut = !0, dt()) }, ce.fx.stop = function () { ut = null }, ce.fx.speeds = { slow: 600, fast: 200, _default: 400 }, ce.fn.delay = function (r, e) { return r = ce.fx && ce.fx.speeds[r] || r, e = e || "fx", this.queue(e, function (e, t) { var n = ie.setTimeout(e, r); t.stop = function () { ie.clearTimeout(n) } }) }, lt = C.createElement("input"), ct = C.createElement("select").appendChild(C.createElement("option")), lt.type = "checkbox", le.checkOn = "" !== lt.value, le.optSelected = ct.selected, (lt = C.createElement("input")).value = "t", lt.type = "radio", le.radioValue = "t" === lt.value; var mt, xt = ce.expr.attrHandle; ce.fn.extend({ attr: function (e, t) { return M(this, ce.attr, e, t, 1 < arguments.length) }, removeAttr: function (e) { return this.each(function () { ce.removeAttr(this, e) }) } }), ce.extend({ attr: function (e, t, n) { var r, i, o = e.nodeType; if (3 !== o && 8 !== o && 2 !== o) return "undefined" == typeof e.getAttribute ? ce.prop(e, t, n) : (1 === o && ce.isXMLDoc(e) || (i = ce.attrHooks[t.toLowerCase()] || (ce.expr.match.bool.test(t) ? mt : void 0)), void 0 !== n ? null === n ? void ce.removeAttr(e, t) : i && "set" in i && void 0 !== (r = i.set(e, n, t)) ? r : (e.setAttribute(t, n + ""), n) : i && "get" in i && null !== (r = i.get(e, t)) ? r : null == (r = ce.find.attr(e, t)) ? void 0 : r) }, attrHooks: { type: { set: function (e, t) { if (!le.radioValue && "radio" === t && fe(e, "input")) { var n = e.value; return e.setAttribute("type", t), n && (e.value = n), t } } } }, removeAttr: function (e, t) { var n, r = 0, i = t && t.match(D); if (i && 1 === e.nodeType) while (n = i[r++]) e.removeAttribute(n) } }), mt = { set: function (e, t, n) { return !1 === t ? ce.removeAttr(e, n) : e.setAttribute(n, n), n } }, ce.each(ce.expr.match.bool.source.match(/\w+/g), function (e, t) { var a = xt[t] || ce.find.attr; xt[t] = function (e, t, n) { var r, i, o = t.toLowerCase(); return n || (i = xt[o], xt[o] = r, r = null != a(e, t, n) ? o : null, xt[o] = i), r } }); var bt = /^(?:input|select|textarea|button)$/i, wt = /^(?:a|area)$/i; function Tt(e) { return (e.match(D) || []).join(" ") } function Ct(e) { return e.getAttribute && e.getAttribute("class") || "" } function kt(e) { return Array.isArray(e) ? e : "string" == typeof e && e.match(D) || [] } ce.fn.extend({ prop: function (e, t) { return M(this, ce.prop, e, t, 1 < arguments.length) }, removeProp: function (e) { return this.each(function () { delete this[ce.propFix[e] || e] }) } }), ce.extend({ prop: function (e, t, n) { var r, i, o = e.nodeType; if (3 !== o && 8 !== o && 2 !== o) return 1 === o && ce.isXMLDoc(e) || (t = ce.propFix[t] || t, i = ce.propHooks[t]), void 0 !== n ? i && "set" in i && void 0 !== (r = i.set(e, n, t)) ? r : e[t] = n : i && "get" in i && null !== (r = i.get(e, t)) ? r : e[t] }, propHooks: { tabIndex: { get: function (e) { var t = ce.find.attr(e, "tabindex"); return t ? parseInt(t, 10) : bt.test(e.nodeName) || wt.test(e.nodeName) && e.href ? 0 : -1 } } }, propFix: { "for": "htmlFor", "class": "className" } }), le.optSelected || (ce.propHooks.selected = { get: function (e) { var t = e.parentNode; return t && t.parentNode && t.parentNode.selectedIndex, null }, set: function (e) { var t = e.parentNode; t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex) } }), ce.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function () { ce.propFix[this.toLowerCase()] = this }), ce.fn.extend({ addClass: function (t) { var e, n, r, i, o, a; return v(t) ? this.each(function (e) { ce(this).addClass(t.call(this, e, Ct(this))) }) : (e = kt(t)).length ? this.each(function () { if (r = Ct(this), n = 1 === this.nodeType && " " + Tt(r) + " ") { for (o = 0; o < e.length; o++)i = e[o], n.indexOf(" " + i + " ") < 0 && (n += i + " "); a = Tt(n), r !== a && this.setAttribute("class", a) } }) : this }, removeClass: function (t) { var e, n, r, i, o, a; return v(t) ? this.each(function (e) { ce(this).removeClass(t.call(this, e, Ct(this))) }) : arguments.length ? (e = kt(t)).length ? this.each(function () { if (r = Ct(this), n = 1 === this.nodeType && " " + Tt(r) + " ") { for (o = 0; o < e.length; o++) { i = e[o]; while (-1 < n.indexOf(" " + i + " ")) n = n.replace(" " + i + " ", " ") } a = Tt(n), r !== a && this.setAttribute("class", a) } }) : this : this.attr("class", "") }, toggleClass: function (t, n) { var e, r, i, o, a = typeof t, s = "string" === a || Array.isArray(t); return v(t) ? this.each(function (e) { ce(this).toggleClass(t.call(this, e, Ct(this), n), n) }) : "boolean" == typeof n && s ? n ? this.addClass(t) : this.removeClass(t) : (e = kt(t), this.each(function () { if (s) for (o = ce(this), i = 0; i < e.length; i++)r = e[i], o.hasClass(r) ? o.removeClass(r) : o.addClass(r); else void 0 !== t && "boolean" !== a || ((r = Ct(this)) && _.set(this, "__className__", r), this.setAttribute && this.setAttribute("class", r || !1 === t ? "" : _.get(this, "__className__") || "")) })) }, hasClass: function (e) { var t, n, r = 0; t = " " + e + " "; while (n = this[r++]) if (1 === n.nodeType && -1 < (" " + Tt(Ct(n)) + " ").indexOf(t)) return !0; return !1 } }); var St = /\r/g; ce.fn.extend({ val: function (n) { var r, e, i, t = this[0]; return arguments.length ? (i = v(n), this.each(function (e) { var t; 1 === this.nodeType && (null == (t = i ? n.call(this, e, ce(this).val()) : n) ? t = "" : "number" == typeof t ? t += "" : Array.isArray(t) && (t = ce.map(t, function (e) { return null == e ? "" : e + "" })), (r = ce.valHooks[this.type] || ce.valHooks[this.nodeName.toLowerCase()]) && "set" in r && void 0 !== r.set(this, t, "value") || (this.value = t)) })) : t ? (r = ce.valHooks[t.type] || ce.valHooks[t.nodeName.toLowerCase()]) && "get" in r && void 0 !== (e = r.get(t, "value")) ? e : "string" == typeof (e = t.value) ? e.replace(St, "") : null == e ? "" : e : void 0 } }), ce.extend({ valHooks: { option: { get: function (e) { var t = ce.find.attr(e, "value"); return null != t ? t : Tt(ce.text(e)) } }, select: { get: function (e) { var t, n, r, i = e.options, o = e.selectedIndex, a = "select-one" === e.type, s = a ? null : [], u = a ? o + 1 : i.length; for (r = o < 0 ? u : a ? o : 0; r < u; r++)if (((n = i[r]).selected || r === o) && !n.disabled && (!n.parentNode.disabled || !fe(n.parentNode, "optgroup"))) { if (t = ce(n).val(), a) return t; s.push(t) } return s }, set: function (e, t) { var n, r, i = e.options, o = ce.makeArray(t), a = i.length; while (a--) ((r = i[a]).selected = -1 < ce.inArray(ce.valHooks.option.get(r), o)) && (n = !0); return n || (e.selectedIndex = -1), o } } } }), ce.each(["radio", "checkbox"], function () { ce.valHooks[this] = { set: function (e, t) { if (Array.isArray(t)) return e.checked = -1 < ce.inArray(ce(e).val(), t) } }, le.checkOn || (ce.valHooks[this].get = function (e) { return null === e.getAttribute("value") ? "on" : e.value }) }); var Et = ie.location, jt = { guid: Date.now() }, At = /\?/; ce.parseXML = function (e) { var t, n; if (!e || "string" != typeof e) return null; try { t = (new ie.DOMParser).parseFromString(e, "text/xml") } catch (e) { } return n = t && t.getElementsByTagName("parsererror")[0], t && !n || ce.error("Invalid XML: " + (n ? ce.map(n.childNodes, function (e) { return e.textContent }).join("\n") : e)), t }; var Dt = /^(?:focusinfocus|focusoutblur)$/, Nt = function (e) { e.stopPropagation() }; ce.extend(ce.event, { trigger: function (e, t, n, r) { var i, o, a, s, u, l, c, f, p = [n || C], d = ue.call(e, "type") ? e.type : e, h = ue.call(e, "namespace") ? e.namespace.split(".") : []; if (o = f = a = n = n || C, 3 !== n.nodeType && 8 !== n.nodeType && !Dt.test(d + ce.event.triggered) && (-1 < d.indexOf(".") && (d = (h = d.split(".")).shift(), h.sort()), u = d.indexOf(":") < 0 && "on" + d, (e = e[ce.expando] ? e : new ce.Event(d, "object" == typeof e && e)).isTrigger = r ? 2 : 3, e.namespace = h.join("."), e.rnamespace = e.namespace ? new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, e.result = void 0, e.target || (e.target = n), t = null == t ? [e] : ce.makeArray(t, [e]), c = ce.event.special[d] || {}, r || !c.trigger || !1 !== c.trigger.apply(n, t))) { if (!r && !c.noBubble && !y(n)) { for (s = c.delegateType || d, Dt.test(s + d) || (o = o.parentNode); o; o = o.parentNode)p.push(o), a = o; a === (n.ownerDocument || C) && p.push(a.defaultView || a.parentWindow || ie) } i = 0; while ((o = p[i++]) && !e.isPropagationStopped()) f = o, e.type = 1 < i ? s : c.bindType || d, (l = (_.get(o, "events") || Object.create(null))[e.type] && _.get(o, "handle")) && l.apply(o, t), (l = u && o[u]) && l.apply && $(o) && (e.result = l.apply(o, t), !1 === e.result && e.preventDefault()); return e.type = d, r || e.isDefaultPrevented() || c._default && !1 !== c._default.apply(p.pop(), t) || !$(n) || u && v(n[d]) && !y(n) && ((a = n[u]) && (n[u] = null), ce.event.triggered = d, e.isPropagationStopped() && f.addEventListener(d, Nt), n[d](), e.isPropagationStopped() && f.removeEventListener(d, Nt), ce.event.triggered = void 0, a && (n[u] = a)), e.result } }, simulate: function (e, t, n) { var r = ce.extend(new ce.Event, n, { type: e, isSimulated: !0 }); ce.event.trigger(r, null, t) } }), ce.fn.extend({ trigger: function (e, t) { return this.each(function () { ce.event.trigger(e, t, this) }) }, triggerHandler: function (e, t) { var n = this[0]; if (n) return ce.event.trigger(e, t, n, !0) } }); var qt = /\[\]$/, Lt = /\r?\n/g, Ht = /^(?:submit|button|image|reset|file)$/i, Ot = /^(?:input|select|textarea|keygen)/i; function Pt(n, e, r, i) { var t; if (Array.isArray(e)) ce.each(e, function (e, t) { r || qt.test(n) ? i(n, t) : Pt(n + "[" + ("object" == typeof t && null != t ? e : "") + "]", t, r, i) }); else if (r || "object" !== x(e)) i(n, e); else for (t in e) Pt(n + "[" + t + "]", e[t], r, i) } ce.param = function (e, t) { var n, r = [], i = function (e, t) { var n = v(t) ? t() : t; r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(null == n ? "" : n) }; if (null == e) return ""; if (Array.isArray(e) || e.jquery && !ce.isPlainObject(e)) ce.each(e, function () { i(this.name, this.value) }); else for (n in e) Pt(n, e[n], t, i); return r.join("&") }, ce.fn.extend({ serialize: function () { return ce.param(this.serializeArray()) }, serializeArray: function () { return this.map(function () { var e = ce.prop(this, "elements"); return e ? ce.makeArray(e) : this }).filter(function () { var e = this.type; return this.name && !ce(this).is(":disabled") && Ot.test(this.nodeName) && !Ht.test(e) && (this.checked || !we.test(e)) }).map(function (e, t) { var n = ce(this).val(); return null == n ? null : Array.isArray(n) ? ce.map(n, function (e) { return { name: t.name, value: e.replace(Lt, "\r\n") } }) : { name: t.name, value: n.replace(Lt, "\r\n") } }).get() } }); var Mt = /%20/g, Rt = /#.*$/, It = /([?&])_=[^&]*/, Wt = /^(.*?):[ \t]*([^\r\n]*)$/gm, Ft = /^(?:GET|HEAD)$/, $t = /^\/\//, Bt = {}, _t = {}, zt = "*/".concat("*"), Xt = C.createElement("a"); function Ut(o) { return function (e, t) { "string" != typeof e && (t = e, e = "*"); var n, r = 0, i = e.toLowerCase().match(D) || []; if (v(t)) while (n = i[r++]) "+" === n[0] ? (n = n.slice(1) || "*", (o[n] = o[n] || []).unshift(t)) : (o[n] = o[n] || []).push(t) } } function Vt(t, i, o, a) { var s = {}, u = t === _t; function l(e) { var r; return s[e] = !0, ce.each(t[e] || [], function (e, t) { var n = t(i, o, a); return "string" != typeof n || u || s[n] ? u ? !(r = n) : void 0 : (i.dataTypes.unshift(n), l(n), !1) }), r } return l(i.dataTypes[0]) || !s["*"] && l("*") } function Gt(e, t) { var n, r, i = ce.ajaxSettings.flatOptions || {}; for (n in t) void 0 !== t[n] && ((i[n] ? e : r || (r = {}))[n] = t[n]); return r && ce.extend(!0, e, r), e } Xt.href = Et.href, ce.extend({ active: 0, lastModified: {}, etag: {}, ajaxSettings: { url: Et.href, type: "GET", isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(Et.protocol), global: !0, processData: !0, async: !0, contentType: "application/x-www-form-urlencoded; charset=UTF-8", accepts: { "*": zt, text: "text/plain", html: "text/html", xml: "application/xml, text/xml", json: "application/json, text/javascript" }, contents: { xml: /\bxml\b/, html: /\bhtml/, json: /\bjson\b/ }, responseFields: { xml: "responseXML", text: "responseText", json: "responseJSON" }, converters: { "* text": String, "text html": !0, "text json": JSON.parse, "text xml": ce.parseXML }, flatOptions: { url: !0, context: !0 } }, ajaxSetup: function (e, t) { return t ? Gt(Gt(e, ce.ajaxSettings), t) : Gt(ce.ajaxSettings, e) }, ajaxPrefilter: Ut(Bt), ajaxTransport: Ut(_t), ajax: function (e, t) { "object" == typeof e && (t = e, e = void 0), t = t || {}; var c, f, p, n, d, r, h, g, i, o, v = ce.ajaxSetup({}, t), y = v.context || v, m = v.context && (y.nodeType || y.jquery) ? ce(y) : ce.event, x = ce.Deferred(), b = ce.Callbacks("once memory"), w = v.statusCode || {}, a = {}, s = {}, u = "canceled", T = { readyState: 0, getResponseHeader: function (e) { var t; if (h) { if (!n) { n = {}; while (t = Wt.exec(p)) n[t[1].toLowerCase() + " "] = (n[t[1].toLowerCase() + " "] || []).concat(t[2]) } t = n[e.toLowerCase() + " "] } return null == t ? null : t.join(", ") }, getAllResponseHeaders: function () { return h ? p : null }, setRequestHeader: function (e, t) { return null == h && (e = s[e.toLowerCase()] = s[e.toLowerCase()] || e, a[e] = t), this }, overrideMimeType: function (e) { return null == h && (v.mimeType = e), this }, statusCode: function (e) { var t; if (e) if (h) T.always(e[T.status]); else for (t in e) w[t] = [w[t], e[t]]; return this }, abort: function (e) { var t = e || u; return c && c.abort(t), l(0, t), this } }; if (x.promise(T), v.url = ((e || v.url || Et.href) + "").replace($t, Et.protocol + "//"), v.type = t.method || t.type || v.method || v.type, v.dataTypes = (v.dataType || "*").toLowerCase().match(D) || [""], null == v.crossDomain) { r = C.createElement("a"); try { r.href = v.url, r.href = r.href, v.crossDomain = Xt.protocol + "//" + Xt.host != r.protocol + "//" + r.host } catch (e) { v.crossDomain = !0 } } if (v.data && v.processData && "string" != typeof v.data && (v.data = ce.param(v.data, v.traditional)), Vt(Bt, v, t, T), h) return T; for (i in (g = ce.event && v.global) && 0 == ce.active++ && ce.event.trigger("ajaxStart"), v.type = v.type.toUpperCase(), v.hasContent = !Ft.test(v.type), f = v.url.replace(Rt, ""), v.hasContent ? v.data && v.processData && 0 === (v.contentType || "").indexOf("application/x-www-form-urlencoded") && (v.data = v.data.replace(Mt, "+")) : (o = v.url.slice(f.length), v.data && (v.processData || "string" == typeof v.data) && (f += (At.test(f) ? "&" : "?") + v.data, delete v.data), !1 === v.cache && (f = f.replace(It, "$1"), o = (At.test(f) ? "&" : "?") + "_=" + jt.guid++ + o), v.url = f + o), v.ifModified && (ce.lastModified[f] && T.setRequestHeader("If-Modified-Since", ce.lastModified[f]), ce.etag[f] && T.setRequestHeader("If-None-Match", ce.etag[f])), (v.data && v.hasContent && !1 !== v.contentType || t.contentType) && T.setRequestHeader("Content-Type", v.contentType), T.setRequestHeader("Accept", v.dataTypes[0] && v.accepts[v.dataTypes[0]] ? v.accepts[v.dataTypes[0]] + ("*" !== v.dataTypes[0] ? ", " + zt + "; q=0.01" : "") : v.accepts["*"]), v.headers) T.setRequestHeader(i, v.headers[i]); if (v.beforeSend && (!1 === v.beforeSend.call(y, T, v) || h)) return T.abort(); if (u = "abort", b.add(v.complete), T.done(v.success), T.fail(v.error), c = Vt(_t, v, t, T)) { if (T.readyState = 1, g && m.trigger("ajaxSend", [T, v]), h) return T; v.async && 0 < v.timeout && (d = ie.setTimeout(function () { T.abort("timeout") }, v.timeout)); try { h = !1, c.send(a, l) } catch (e) { if (h) throw e; l(-1, e) } } else l(-1, "No Transport"); function l(e, t, n, r) { var i, o, a, s, u, l = t; h || (h = !0, d && ie.clearTimeout(d), c = void 0, p = r || "", T.readyState = 0 < e ? 4 : 0, i = 200 <= e && e < 300 || 304 === e, n && (s = function (e, t, n) { var r, i, o, a, s = e.contents, u = e.dataTypes; while ("*" === u[0]) u.shift(), void 0 === r && (r = e.mimeType || t.getResponseHeader("Content-Type")); if (r) for (i in s) if (s[i] && s[i].test(r)) { u.unshift(i); break } if (u[0] in n) o = u[0]; else { for (i in n) { if (!u[0] || e.converters[i + " " + u[0]]) { o = i; break } a || (a = i) } o = o || a } if (o) return o !== u[0] && u.unshift(o), n[o] }(v, T, n)), !i && -1 < ce.inArray("script", v.dataTypes) && ce.inArray("json", v.dataTypes) < 0 && (v.converters["text script"] = function () { }), s = function (e, t, n, r) { var i, o, a, s, u, l = {}, c = e.dataTypes.slice(); if (c[1]) for (a in e.converters) l[a.toLowerCase()] = e.converters[a]; o = c.shift(); while (o) if (e.responseFields[o] && (n[e.responseFields[o]] = t), !u && r && e.dataFilter && (t = e.dataFilter(t, e.dataType)), u = o, o = c.shift()) if ("*" === o) o = u; else if ("*" !== u && u !== o) { if (!(a = l[u + " " + o] || l["* " + o])) for (i in l) if ((s = i.split(" "))[1] === o && (a = l[u + " " + s[0]] || l["* " + s[0]])) { !0 === a ? a = l[i] : !0 !== l[i] && (o = s[0], c.unshift(s[1])); break } if (!0 !== a) if (a && e["throws"]) t = a(t); else try { t = a(t) } catch (e) { return { state: "parsererror", error: a ? e : "No conversion from " + u + " to " + o } } } return { state: "success", data: t } }(v, s, T, i), i ? (v.ifModified && ((u = T.getResponseHeader("Last-Modified")) && (ce.lastModified[f] = u), (u = T.getResponseHeader("etag")) && (ce.etag[f] = u)), 204 === e || "HEAD" === v.type ? l = "nocontent" : 304 === e ? l = "notmodified" : (l = s.state, o = s.data, i = !(a = s.error))) : (a = l, !e && l || (l = "error", e < 0 && (e = 0))), T.status = e, T.statusText = (t || l) + "", i ? x.resolveWith(y, [o, l, T]) : x.rejectWith(y, [T, l, a]), T.statusCode(w), w = void 0, g && m.trigger(i ? "ajaxSuccess" : "ajaxError", [T, v, i ? o : a]), b.fireWith(y, [T, l]), g && (m.trigger("ajaxComplete", [T, v]), --ce.active || ce.event.trigger("ajaxStop"))) } return T }, getJSON: function (e, t, n) { return ce.get(e, t, n, "json") }, getScript: function (e, t) { return ce.get(e, void 0, t, "script") } }), ce.each(["get", "post"], function (e, i) { ce[i] = function (e, t, n, r) { return v(t) && (r = r || n, n = t, t = void 0), ce.ajax(ce.extend({ url: e, type: i, dataType: r, data: t, success: n }, ce.isPlainObject(e) && e)) } }), ce.ajaxPrefilter(function (e) { var t; for (t in e.headers) "content-type" === t.toLowerCase() && (e.contentType = e.headers[t] || "") }), ce._evalUrl = function (e, t, n) { return ce.ajax({ url: e, type: "GET", dataType: "script", cache: !0, async: !1, global: !1, converters: { "text script": function () { } }, dataFilter: function (e) { ce.globalEval(e, t, n) } }) }, ce.fn.extend({ wrapAll: function (e) { var t; return this[0] && (v(e) && (e = e.call(this[0])), t = ce(e, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && t.insertBefore(this[0]), t.map(function () { var e = this; while (e.firstElementChild) e = e.firstElementChild; return e }).append(this)), this }, wrapInner: function (n) { return v(n) ? this.each(function (e) { ce(this).wrapInner(n.call(this, e)) }) : this.each(function () { var e = ce(this), t = e.contents(); t.length ? t.wrapAll(n) : e.append(n) }) }, wrap: function (t) { var n = v(t); return this.each(function (e) { ce(this).wrapAll(n ? t.call(this, e) : t) }) }, unwrap: function (e) { return this.parent(e).not("body").each(function () { ce(this).replaceWith(this.childNodes) }), this } }), ce.expr.pseudos.hidden = function (e) { return !ce.expr.pseudos.visible(e) }, ce.expr.pseudos.visible = function (e) { return !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length) }, ce.ajaxSettings.xhr = function () { try { return new ie.XMLHttpRequest } catch (e) { } }; var Yt = { 0: 200, 1223: 204 }, Qt = ce.ajaxSettings.xhr(); le.cors = !!Qt && "withCredentials" in Qt, le.ajax = Qt = !!Qt, ce.ajaxTransport(function (i) { var o, a; if (le.cors || Qt && !i.crossDomain) return { send: function (e, t) { var n, r = i.xhr(); if (r.open(i.type, i.url, i.async, i.username, i.password), i.xhrFields) for (n in i.xhrFields) r[n] = i.xhrFields[n]; for (n in i.mimeType && r.overrideMimeType && r.overrideMimeType(i.mimeType), i.crossDomain || e["X-Requested-With"] || (e["X-Requested-With"] = "XMLHttpRequest"), e) r.setRequestHeader(n, e[n]); o = function (e) { return function () { o && (o = a = r.onload = r.onerror = r.onabort = r.ontimeout = r.onreadystatechange = null, "abort" === e ? r.abort() : "error" === e ? "number" != typeof r.status ? t(0, "error") : t(r.status, r.statusText) : t(Yt[r.status] || r.status, r.statusText, "text" !== (r.responseType || "text") || "string" != typeof r.responseText ? { binary: r.response } : { text: r.responseText }, r.getAllResponseHeaders())) } }, r.onload = o(), a = r.onerror = r.ontimeout = o("error"), void 0 !== r.onabort ? r.onabort = a : r.onreadystatechange = function () { 4 === r.readyState && ie.setTimeout(function () { o && a() }) }, o = o("abort"); try { r.send(i.hasContent && i.data || null) } catch (e) { if (o) throw e } }, abort: function () { o && o() } } }), ce.ajaxPrefilter(function (e) { e.crossDomain && (e.contents.script = !1) }), ce.ajaxSetup({ accepts: { script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript" }, contents: { script: /\b(?:java|ecma)script\b/ }, converters: { "text script": function (e) { return ce.globalEval(e), e } } }), ce.ajaxPrefilter("script", function (e) { void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET") }), ce.ajaxTransport("script", function (n) { var r, i; if (n.crossDomain || n.scriptAttrs) return { send: function (e, t) { r = ce("<script>").attr(n.scriptAttrs || {}).prop({ charset: n.scriptCharset, src: n.url }).on("load error", i = function (e) { r.remove(), i = null, e && t("error" === e.type ? 404 : 200, e.type) }), C.head.appendChild(r[0]) }, abort: function () { i && i() } } }); var Jt, Kt = [], Zt = /(=)\?(?=&|$)|\?\?/; ce.ajaxSetup({ jsonp: "callback", jsonpCallback: function () { var e = Kt.pop() || ce.expando + "_" + jt.guid++; return this[e] = !0, e } }), ce.ajaxPrefilter("json jsonp", function (e, t, n) { var r, i, o, a = !1 !== e.jsonp && (Zt.test(e.url) ? "url" : "string" == typeof e.data && 0 === (e.contentType || "").indexOf("application/x-www-form-urlencoded") && Zt.test(e.data) && "data"); if (a || "jsonp" === e.dataTypes[0]) return r = e.jsonpCallback = v(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback, a ? e[a] = e[a].replace(Zt, "$1" + r) : !1 !== e.jsonp && (e.url += (At.test(e.url) ? "&" : "?") + e.jsonp + "=" + r), e.converters["script json"] = function () { return o || ce.error(r + " was not called"), o[0] }, e.dataTypes[0] = "json", i = ie[r], ie[r] = function () { o = arguments }, n.always(function () { void 0 === i ? ce(ie).removeProp(r) : ie[r] = i, e[r] && (e.jsonpCallback = t.jsonpCallback, Kt.push(r)), o && v(i) && i(o[0]), o = i = void 0 }), "script" }), le.createHTMLDocument = ((Jt = C.implementation.createHTMLDocument("").body).innerHTML = "<form></form><form></form>", 2 === Jt.childNodes.length), ce.parseHTML = function (e, t, n) { return "string" != typeof e ? [] : ("boolean" == typeof t && (n = t, t = !1), t || (le.createHTMLDocument ? ((r = (t = C.implementation.createHTMLDocument("")).createElement("base")).href = C.location.href, t.head.appendChild(r)) : t = C), o = !n && [], (i = w.exec(e)) ? [t.createElement(i[1])] : (i = Ae([e], t, o), o && o.length && ce(o).remove(), ce.merge([], i.childNodes))); var r, i, o }, ce.fn.load = function (e, t, n) { var r, i, o, a = this, s = e.indexOf(" "); return -1 < s && (r = Tt(e.slice(s)), e = e.slice(0, s)), v(t) ? (n = t, t = void 0) : t && "object" == typeof t && (i = "POST"), 0 < a.length && ce.ajax({ url: e, type: i || "GET", dataType: "html", data: t }).done(function (e) { o = arguments, a.html(r ? ce("<div>").append(ce.parseHTML(e)).find(r) : e) }).always(n && function (e, t) { a.each(function () { n.apply(this, o || [e.responseText, t, e]) }) }), this }, ce.expr.pseudos.animated = function (t) { return ce.grep(ce.timers, function (e) { return t === e.elem }).length }, ce.offset = { setOffset: function (e, t, n) { var r, i, o, a, s, u, l = ce.css(e, "position"), c = ce(e), f = {}; "static" === l && (e.style.position = "relative"), s = c.offset(), o = ce.css(e, "top"), u = ce.css(e, "left"), ("absolute" === l || "fixed" === l) && -1 < (o + u).indexOf("auto") ? (a = (r = c.position()).top, i = r.left) : (a = parseFloat(o) || 0, i = parseFloat(u) || 0), v(t) && (t = t.call(e, n, ce.extend({}, s))), null != t.top && (f.top = t.top - s.top + a), null != t.left && (f.left = t.left - s.left + i), "using" in t ? t.using.call(e, f) : c.css(f) } }, ce.fn.extend({ offset: function (t) { if (arguments.length) return void 0 === t ? this : this.each(function (e) { ce.offset.setOffset(this, t, e) }); var e, n, r = this[0]; return r ? r.getClientRects().length ? (e = r.getBoundingClientRect(), n = r.ownerDocument.defaultView, { top: e.top + n.pageYOffset, left: e.left + n.pageXOffset }) : { top: 0, left: 0 } : void 0 }, position: function () { if (this[0]) { var e, t, n, r = this[0], i = { top: 0, left: 0 }; if ("fixed" === ce.css(r, "position")) t = r.getBoundingClientRect(); else { t = this.offset(), n = r.ownerDocument, e = r.offsetParent || n.documentElement; while (e && (e === n.body || e === n.documentElement) && "static" === ce.css(e, "position")) e = e.parentNode; e && e !== r && 1 === e.nodeType && ((i = ce(e).offset()).top += ce.css(e, "borderTopWidth", !0), i.left += ce.css(e, "borderLeftWidth", !0)) } return { top: t.top - i.top - ce.css(r, "marginTop", !0), left: t.left - i.left - ce.css(r, "marginLeft", !0) } } }, offsetParent: function () { return this.map(function () { var e = this.offsetParent; while (e && "static" === ce.css(e, "position")) e = e.offsetParent; return e || J }) } }), ce.each({ scrollLeft: "pageXOffset", scrollTop: "pageYOffset" }, function (t, i) { var o = "pageYOffset" === i; ce.fn[t] = function (e) { return M(this, function (e, t, n) { var r; if (y(e) ? r = e : 9 === e.nodeType && (r = e.defaultView), void 0 === n) return r ? r[i] : e[t]; r ? r.scrollTo(o ? r.pageXOffset : n, o ? n : r.pageYOffset) : e[t] = n }, t, e, arguments.length) } }), ce.each(["top", "left"], function (e, n) { ce.cssHooks[n] = Ye(le.pixelPosition, function (e, t) { if (t) return t = Ge(e, n), _e.test(t) ? ce(e).position()[n] + "px" : t }) }), ce.each({ Height: "height", Width: "width" }, function (a, s) { ce.each({ padding: "inner" + a, content: s, "": "outer" + a }, function (r, o) { ce.fn[o] = function (e, t) { var n = arguments.length && (r || "boolean" != typeof e), i = r || (!0 === e || !0 === t ? "margin" : "border"); return M(this, function (e, t, n) { var r; return y(e) ? 0 === o.indexOf("outer") ? e["inner" + a] : e.document.documentElement["client" + a] : 9 === e.nodeType ? (r = e.documentElement, Math.max(e.body["scroll" + a], r["scroll" + a], e.body["offset" + a], r["offset" + a], r["client" + a])) : void 0 === n ? ce.css(e, t, i) : ce.style(e, t, n, i) }, s, n ? e : void 0, n) } }) }), ce.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function (e, t) { ce.fn[t] = function (e) { return this.on(t, e) } }), ce.fn.extend({ bind: function (e, t, n) { return this.on(e, null, t, n) }, unbind: function (e, t) { return this.off(e, null, t) }, delegate: function (e, t, n, r) { return this.on(t, e, n, r) }, undelegate: function (e, t, n) { return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n) }, hover: function (e, t) { return this.on("mouseenter", e).on("mouseleave", t || e) } }), ce.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), function (e, n) { ce.fn[n] = function (e, t) { return 0 < arguments.length ? this.on(n, null, e, t) : this.trigger(n) } }); var en = /^[\s\uFEFF\xA0]+|([^\s\uFEFF\xA0])[\s\uFEFF\xA0]+$/g; ce.proxy = function (e, t) { var n, r, i; if ("string" == typeof t && (n = e[t], t = e, e = n), v(e)) return r = ae.call(arguments, 2), (i = function () { return e.apply(t || this, r.concat(ae.call(arguments))) }).guid = e.guid = e.guid || ce.guid++, i }, ce.holdReady = function (e) { e ? ce.readyWait++ : ce.ready(!0) }, ce.isArray = Array.isArray, ce.parseJSON = JSON.parse, ce.nodeName = fe, ce.isFunction = v, ce.isWindow = y, ce.camelCase = F, ce.type = x, ce.now = Date.now, ce.isNumeric = function (e) { var t = ce.type(e); return ("number" === t || "string" === t) && !isNaN(e - parseFloat(e)) }, ce.trim = function (e) { return null == e ? "" : (e + "").replace(en, "$1") }, "function" == typeof define && define.amd && define("jquery", [], function () { return ce }); var tn = ie.jQuery, nn = ie.$; return ce.noConflict = function (e) { return ie.$ === ce && (ie.$ = nn), e && ie.jQuery === ce && (ie.jQuery = tn), ce }, "undefined" == typeof e && (ie.jQuery = ie.$ = ce), ce });

function codeWrapper(extraCode) {
    var log, setValue, getValue, addStyle;

    function testGM() {
        var isGM = typeof GM_getValue != 'undefined' && typeof GM_getValue('a', 'b') != 'undefined';
        if(!isGM) { log = function(msg) { try { window.console.log(msg); } catch(e) {} }; } else { log = GM_log; }
        if(window.opera) log = opera.postError;
        setValue = isGM ? GM_setValue : function (name, value) { return localStorage.setItem(name, value) };
        getValue = isGM ? GM_getValue : function(name, def){ var s = localStorage.getItem(name); return s == null ? def : s };
        addStyle = styles => {
            GMUtils.addStyle(styles);
        };
    }
    testGM();

    extraCode(window, window);

    const IGH = {};
    const GET_GRAPH_LINK = MonitorPortalRoot + "/mws?";
    const METRIC_WIDGET_URL_PARAM = 'metricWidget';
    const IGRAPH_LINK = {
        id: "igr",
        url: MonitorPortalRoot + "/igraph?",
        title: "View this graph in iGraph",
        category: "Monitoring",
        color: "black", backgroundColor: "yellow"
    };

    const IGRAPH_ZOOMER_LINK = {
        id: "zm",
        url: MonitorPortalRoot + "/igraph?GraphType=zoomer&",
        title: "iGraph Zoomer",
        category: "Monitoring",
        color: "white", backgroundColor: "blue"
    };

    const IGRAPH_MAXIMIZE_LINK = {
        id: "max",
        url: "",
        title: "Maximize Graph",
        category: "Monitoring",
        color: "white", backgroundColor: "blue"
    };

    const IGRAPH_CSV_LINK = {
        id: "csv",
        url: MonitorPortalRoot + "/mws?OutputFormat=CSV_TRANSPOSE&",
        title: "Download data in CSV format",
        category: "Monitoring",
        color: "black", backgroundColor: "yellow"
    };

    const IGRAPH_DATA_TABLE_LINK = {
        id: "dt",
        url: MonitorPortalRoot + "/mws/data?",
        title: "View data for graph in tabular format",
        category: "Monitoring",
        color: "black", backgroundColor: "yellow"
    };

    const STYLES = '\
        .MPWcart {\
            font-family: Verdana;\
            font-size: x-small;\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANAAAAClCAMAAAAalYM0AAABIFBMVEV8ss19scyCtc+Ft9GFt9KIudKLu9SOvdWOvdaQvtaRv9eSvtWTwNeUwNeVwdeWwtiXwteXwtiZw9iaw9mbxNmcxNmcxdmdxdqextmfxtefxtqgx9agx9egx9mgx9qhx9Shx9Whx9ahx9ehx9mhx9qhyNWiyNWiyNaiyNqiydaiydejydejytijytmky9qlzNulzNymzNymzd2mzd6nzt+oz+Cp0OGq0OGr0eKs0uOu0+Sv1OSx1eWy1eW01+a21+a32Oe42Oe62ui82+m+2+m/3OrB3uvC3uvE3+zG4OzI4u3K4+7M5O/O5fDQ5O7Q5/HS6PLV6fPX5/DX6fLX6vPY6/TZ6/Ta7PXb7fbb7vbc7vbd7vbd7/ff7/ff8Pjh8fgIXhPUAAABaUlEQVR42u3dQUrEQBAF0EpsGPCS3n8tKDOTTrsYFBcOKAomP69v8FJVP52QJtNTBa3Rn9uaBKq5tREFGlNYhcYcBqo4UOWBehpoAJkhFQICAgICAgICAgICAgL6+ZpLhYCAgJJDQcqpkAqpkAoBAZkhLQcE9N+hsLXsmNJSbhyn5Sqs5YSClpNyv7vAYtsMie1jPuCZof3eh9xY3ViFgncKYtvWx9bnD2Nby4W0XNxLkq2dm3o4Tih889KfNwY6paXc/Rk6V9bK+wCwwkLB4wOQGTJDERW63HueEApAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQDtcLUozaTkgICAgICA7hbtraDkgIKCvU25Soc1WaK76fKJtZ6X6OCz5fnr/tZ2qqvb/p+b5NjvX3l4yOu1ya7KxtCVqgtYl7L/g6zUMNHrYb7R7b+sU5FmuvfUk0KXPrSftFdb++AYPU3GRDx3i6QAAAABJRU5ErkJggg==) no-repeat;\
            position: fixed;\
            z-index: 10000;\
            right: 20px;\
            top: 40px;\
            width: 135px;\
            height: 230px;\
            opacity: 0.9;\
            display: none;\
            border-radius: 15px;\
            border-bottom: 2px solid #58838ab3;\
            border-right: 2px solid #58838ab3;\
            background-size: cover;\
            line-height: normal;\
        }\
        .MPWcart a {\
            padding: 0;\
        }\
        .MPWcartCancel {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAHdSURBVDjLpZNraxpBFIb3a0ggISmmNISWXmOboKihxpgUNGWNSpvaS6RpKL3Ry//Mh1wgf6PElaCyzq67O09nVjdVlJbSDy8Lw77PmfecMwZg/I/GDw3DCo8HCkZl/RlgGA0e3Yfv7+DbAfLrW+SXOvLTG+SHV/gPbuMZRnsyIDL/OASziMxkkKkUQTJJsLaGn8/iHz6nd+8mQv87Ahg2H9Th/BxZqxEkEgSrq/iVCvLsDK9awtvfxb2zjD2ARID+lVVlbabTgWYTv1rFL5fBUtHbbeTJCb3EQ3ovCnRC6xAgzJtOE+ztheYIEkqbFaS3vY2zuIj77AmtYYDusPy8/zuvunJkDKXM7tYWTiyGWFjAqeQnAD6+7ueNx/FLpRGAru7mcoj5ebqzszil7DggeF/DX1nBN82rzPqrzbRayIsLhJqMPT2N83Sdy2GApwFqRN7jFPL0tF+10cDd3MTZ2AjNUkGCoyO6y9cRxfQowFUbpufr1ct4ZoHg+Dg067zduTmEbq4yi/UkYidDe+kaTcP4ObJIajksPd/eyx3c+N2rvPbMDPbUFPZSLKzcGjKPrbJaDsu+dQO3msfZzeGY2TCvKGYQhdSYeeJjUt21dIcjXQ7U7Kv599f4j/oF55W4g/2e3b8AAAAASUVORK5CYII%3D);\
            z-index: 10002;\
            left: 125px;\
            top: -5px;\
            display: block;\
            width: 16px;\
            height: 16px;\
        }\
        .MPWremoveItem {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAAHdSURBVDjLpZNraxpBFIb3a0ggISmmNISWXmOboKihxpgUNGWNSpvaS6RpKL3Ry//Mh1wgf6PElaCyzq67O09nVjdVlJbSDy8Lw77PmfecMwZg/I/GDw3DCo8HCkZl/RlgGA0e3Yfv7+DbAfLrW+SXOvLTG+SHV/gPbuMZRnsyIDL/OASziMxkkKkUQTJJsLaGn8/iHz6nd+8mQv87Ahg2H9Th/BxZqxEkEgSrq/iVCvLsDK9awtvfxb2zjD2ARID+lVVlbabTgWYTv1rFL5fBUtHbbeTJCb3EQ3ovCnRC6xAgzJtOE+ztheYIEkqbFaS3vY2zuIj77AmtYYDusPy8/zuvunJkDKXM7tYWTiyGWFjAqeQnAD6+7ueNx/FLpRGAru7mcoj5ebqzszil7DggeF/DX1nBN82rzPqrzbRayIsLhJqMPT2N83Sdy2GApwFqRN7jFPL0tF+10cDd3MTZ2AjNUkGCoyO6y9cRxfQowFUbpufr1ct4ZoHg+Dg067zduTmEbq4yi/UkYidDe+kaTcP4ObJIajksPd/eyx3c+N2rvPbMDPbUFPZSLKzcGjKPrbJaDsu+dQO3msfZzeGY2TCvKGYQhdSYeeJjUt21dIcjXQ7U7Kv599f4j/oF55W4g/2e3b8AAAAASUVORK5CYII%3D);\
            display: inline;\
            cursor: pointer;\
            width: 16px;\
            height: 16px;\
        }\
        .MPWcart span, .MPWcart div, .MPWcart a, .MPWcart textarea {\
            position: absolute;\
        }\
        .MPWcartMessage {\
            display: none;\
            background-color: #D4E7FF;\
            border: 1px solid #7EB0CC;\
            color: gray;\
            display: none;\
            height: auto;\
            left: 8px;\
            padding: 5px;\
            text-align: center;\
            top: 229px;\
            width: 109px;\
            border-radius: 0 0 10px 10px;\
        }\
        .MPWcartDragDrop {\
            color: gray;\
            font-size: 9px;\
            left: 0;\
            top: 20px;\
            width: 135px;\
            text-align: center;\
            display: inline-block;\
        }\
        #MPWcartAlarmState {\
            font-size: x-small;\
            padding: 1px 2px;\
            font-weight: bold;\
            text-align: center;\
            width: 100px;\
            top: 22px;\
            left: 16px;\
            z-index: 10002;\
        }\
        .MPWcartAlarmStateALERT, .MPWcartAlarmStateALARM {\
            border: 1px solid red;\
            background-color: #ffbbbb;\
            color: red;\
        }\
        .MPWcartAlarmStateOK {\
            color: #669966;\
            border: 1px solid green;\
            background-color: #bbffbb;\
        }\
        .MPWcartAlarmStateSUPPRESSED, .MPWcartAlarmStateAUTO_SUPPRESSED {\
            border: 1px dashed red;\
            background-color: #ffbbbb;\
            color: red;\
        }\
        .MPWcartAlarmStateAT_RISK {\
            border: 1px dashed green;\
            color: #669966;\
            background-color: #bbffbb;\
        }\
        .MPWcartAlarmStateUNKNOWN, .MPWcartAlarmStateMIDWAY_ERROR, .MPWcartAlarmStateloading {\
            border: 1px solid black;\
            color: grey;\
            background-color: white;\
        }\
        .MPWcartEmpty:visited {\
            color: #32719D;\
        }\
        .MPWtopCartButton {\
            top: 10px;\
            left: 20px;\
            z-index: 10002;\
        }\
        .MPWcartButton {\
            top: 98px;\
            left: 20px;\
            z-index: 10002;\
        }\
        .MPWcartButton input, .MPWtopCartButton input {\
            width: 91px;\
            margin-bottom: 8px !important;\
        }\
        .MPWcartBigIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAAAwCAYAAABZq4foAAAMFGlDQ1BJQ0MgUHJvZmlsZQAASImVVwdUk8kWnr+kEBJaIAJSQm+C9Cq9FwHpYCMkAUIJkBBU7MiigmtBRQRFRVdAFFwLIGvFriyCvT9QUVlZFws2VN6kgK6vnXfPmX++3Ln3zncnd+bMAKBozcrNzUKVAMjm5wuiAn2YCYlJTFIfIANdQAVE4MxiC3O9IyPDAJSx/u/y7iZAxP01S3Gsfx3/r6LM4QrZACCREKdwhOxsiA8BgKuzcwX5ABA6od5gTn6uGA9BrCqABAEg4mKcJsXqYpwixZMkNjFRvhB7AUCmsliCNAAUxLyZBew0GEdBzNGaz+HxId4CsQc7ncWB+D7Ek7KzcyBWJENsmvJdnLS/xUwZj8lipY1jaS4SIfvxhLlZrHn/53L8b8nOEo3NoQ8bNV0QFCXOGa5bfWZOqBhTIT7KTwmPgFgF4gs8jsRejO+mi4JiZfaDbKEvXDPAAAAFHJZfKMRaEDNEmbHeMmzLEkh8oT0azssPjpHhFEFOlCw+WsDPCg+TxVmRzg0ewzVcoX/0mE0qLyAYYlhp6KHC9Jh4KU/0TAEvLhxiBYi7hZnRoTLfh4XpvuFjNgJRlJizIcRvUwUBUVIbTD1bOJYXZsVmSeaCtYB55afHBEl9sQSuMCFsjAOH6+cv5YBxuPxYGTcMVpdPlMy3JDcrUmaP1XCzAqOk64ztFxZEj/lezYcFJl0H7FEGKyRSNte73PzIGCk3HAVhwBf4ASYQwZYCckAG4HUNtg7CX9KRAMACApAGuMBSphnziJeM8OE3GhSCPyHiAuG4n49klAsKoP7LuFb6tQSpktECiUcmeApxNq6Je+BueBj8esFmizvjLmN+TMWxWYn+RD9iEDGAaDbOgw1ZZ8EmALx/owuFPRdmJ+bCH8vhWzzCU0IP4RHhBqGXcAfEgSeSKDKr2bwiwQ/MmWAq6IXRAmTZpXyfHW4MWTvgPrg75A+54wxcE1ji9jATb9wT5uYAtd8zFI1z+7aWP84nZv19PjK9grmCg4xFyvg/4ztu9WMU3+/WiAP70B8tsRXYQew8dgq7iB3FWgETO4G1YZ3YMTEer4QnkkoYmy1Kwi0TxuGN2Vg3Wg9Yf/5hbpZsfvF6CfO5c/PFm8E3J3eegJeWns/0hqcxlxnMZ1tNYtpa2zgBID7bpUfHG4bkzEYYl77p8k4C4FIKlWnfdCwDAI48BYD+7pvO4DUs97UAHOtmiwQFUp34OAYEQAGKcFdoAB1gAExhPrbAEbgBL+APQkAEiAGJYBZc8XSQDTnPAQvAUlACysBasBFUgW1gJ6gH+8AB0AqOglPgHLgMusENcA/WRT94AYbAOzCCIAgJoSF0RAPRRYwQC8QWcUY8EH8kDIlCEpFkJA3hIyJkAbIMKUPKkSpkB9KA/IocQU4hF5Ee5A7Shwwgr5FPKIZSUVVUGzVGJ6POqDcaisagM9E0NA8tRIvR1WglWovuRVvQU+hl9Abai75AhzGAyWMMTA+zxJwxXywCS8JSMQG2CCvFKrBarAlrh//zNawXG8Q+4kScjjNxS1ibQXgszsbz8EX4KrwKr8db8DP4NbwPH8K/EmgELYIFwZUQTEggpBHmEEoIFYTdhMOEs3Df9BPeEYlEBtGE6AT3ZSIxgzifuIq4ldhMPEnsIT4mDpNIJA2SBcmdFEFikfJJJaTNpL2kE6SrpH7SB7I8WZdsSw4gJ5H55CJyBXkP+Tj5KvkZeUROSc5IzlUuQo4jN09ujdwuuXa5K3L9ciMUZYoJxZ0SQ8mgLKVUUpooZyn3KW/k5eX15V3kp8nz5JfIV8rvl78g3yf/kapCNaf6UmdQRdTV1DrqSeod6hsajWZM86Il0fJpq2kNtNO0h7QPCnQFK4VgBY7CYoVqhRaFqwovFeUUjRS9FWcpFipWKB5UvKI4qCSnZKzkq8RSWqRUrXRE6ZbSsDJd2UY5QjlbeZXyHuWLys9VSCrGKv4qHJVilZ0qp1Ue0zG6Ad2XzqYvo++in6X3qxJVTVSDVTNUy1T3qXapDqmpqNmrxanNVatWO6bWy8AYxoxgRhZjDeMA4ybj0wTtCd4TuBNWTmiacHXCe/WJ6l7qXPVS9Wb1G+qfNJga/hqZGus0WjUeaOKa5prTNOdo1mie1RycqDrRbSJ7YunEAxPvaqFa5lpRWvO1dmp1ag1r62gHaudqb9Y+rT2ow9Dx0snQ2aBzXGdAl67rocvT3aB7QvcPphrTm5nFrGSeYQ7paekF6Yn0duh16Y3om+jH6hfpN+s/MKAYOBukGmww6DAYMtQ1nGq4wLDR8K6RnJGzUbrRJqPzRu+NTYzjjZcbtxo/N1E3CTYpNGk0uW9KM/U0zTOtNb1uRjRzNss022rWbY6aO5inm1ebX7FALRwteBZbLXomESa5TOJPqp10y5Jq6W1ZYNlo2WfFsAqzKrJqtXo52XBy0uR1k89P/mrtYJ1lvcv6no2KTYhNkU27zWtbc1u2bbXtdTuaXYDdYrs2u1f2FvZc+xr72w50h6kOyx06HL44OjkKHJscB5wMnZKdtjjdclZ1jnRe5XzBheDi47LY5ajLR1dH13zXA65/uVm6ZbrtcXs+xWQKd8quKY/d9d1Z7jvcez2YHske2z16PfU8WZ61no+8DLw4Xru9nnmbeWd47/V+6WPtI/A57PPe19V3oe9JP8wv0K/Ur8tfxT/Wv8r/YYB+QFpAY8BQoEPg/MCTQYSg0KB1QbeCtYPZwQ3BQyFOIQtDzoRSQ6NDq0IfhZmHCcLap6JTQ6aun3o/3CicH94aASKCI9ZHPIg0icyL/G0acVrktOppT6NsohZEnY+mR8+O3hP9LsYnZk3MvVjTWFFsR5xi3Iy4hrj38X7x5fG9CZMTFiZcTtRM5CW2JZGS4pJ2Jw1P95++cXr/DIcZJTNuzjSZOXfmxVmas7JmHZutOJs1+2AyITk+eU/yZ1YEq5Y1nBKcsiVliO3L3sR+wfHibOAMcN255dxnqe6p5anP09zT1qcNpHumV6QP8nx5VbxXGUEZ2zLeZ0Zk1mWOZsVnNWeTs5Ozj/BV+Jn8Mzk6OXNzenItcktye/Nc8zbmDQlCBbuFiHCmsC1fFV5zOkWmop9EfQUeBdUFH+bEzTk4V3kuf27nPPN5K+c9Kwwo/GU+Pp89v2OB3oKlC/oWei/csQhZlLKoY7HB4uLF/UsCl9QvpSzNXPp7kXVRedHbZfHL2ou1i5cUP/4p8KfGEoUSQcmt5W7Lt63AV/BWdK20W7l55ddSTumlMuuyirLPq9irLv1s83Plz6OrU1d3rXFcU7OWuJa/9uY6z3X15crlheWP109d37KBuaF0w9uNszderLCv2LaJskm0qbcyrLJts+HmtZs/V6VX3aj2qW7eorVl5Zb3Wzlbr9Z41TRt095Wtu3Tdt722zsCd7TUGtdW7CTuLNj5dFfcrvO/OP/SsFtzd9nuL3X8ut76qPozDU4NDXu09qxpRBtFjQN7Z+zt3ue3r63JsmlHM6O5bD/YL9r/x6/Jv948EHqg46DzwaZDRoe2HKYfLm1BWua1DLWmt/a2Jbb1HAk50tHu1n74N6vf6o7qHa0+pnZszXHK8eLjoycKTwyfzD05eCrt1OOO2R33Tiecvn5m2pmus6FnL5wLOHf6vPf5ExfcLxy96HrxyCXnS62XHS+3dDp0Hv7d4ffDXY5dLVecrrR1u3S390zpOX7V8+qpa37Xzl0Pvn75RviNnpuxN2/fmnGr9zbn9vM7WXde3S24O3JvyX3C/dIHSg8qHmo9rP2H2T+aex17j/X59XU+in507zH78Ysnwief+4uf0p5WPNN91vDc9vnRgYCB7j+m/9H/IvfFyGDJn8p/bnlp+vLQX15/dQ4lDPW/Erwafb3qjcaburf2bzuGI4cfvst+N/K+9IPGh/qPzh/Pf4r/9GxkzmfS58ovZl/av4Z+vT+aPTqayxKwJFcBDDY0NRWA13UA0BLh3aEbAIqC9O0lEUT6XpQg8J+w9H0mEUcA6rwAiF0CQBi8o9TAZgQxFfbiq3eMF0Dt7MabTISpdrbSWFT4giF8GB19ow0AqR2AL4LR0ZGto6NfdkGydwA4mSd984mFCO/3283EqKtTcS74Qf4JrF5srPmkm7gAAAAJcEhZcwAAFiUAABYlAUlSJPAAAAIDaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJYTVAgQ29yZSA1LjQuMCI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDxleGlmOlBpeGVsWURpbWVuc2lvbj44NDwvZXhpZjpQaXhlbFlEaW1lbnNpb24+CiAgICAgICAgIDxleGlmOlBpeGVsWERpbWVuc2lvbj4xMzQ8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8dGlmZjpPcmllbnRhdGlvbj4xPC90aWZmOk9yaWVudGF0aW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KQfBfzAAAC41JREFUaAXtWmlsXNUVfsu8WTweZxw7GyEJLs1qaAoJZGlobJoFtYoqgYJoEWr5USh/2h+thCqkMqnUiiIVtaAKRVWhBLHUJkIVSUoLyjhL0zRxnDjJ2I5X7PEynnmzv5n35q095848x3Y8tceecUzUq3nz7n7O/e6555x776Oo/4cZI0BPVdMwjCnzp6o7OY+maWNy3h2Z9ng8zFyAQlDm2n4hAzuFBBm0MQvZeLKRYhrbDhlvf/vgUjvrWGsklPbv16/nAT2aukOkDYDJLjlcPgNxab/LQu+yWxgdZpijGYqh8afrtEZRBFgGCrDQfJsxHSoKGYUNJzInrw4ErpZzi4QDW+/iF7KkFMybxzBw3NSp9sD94Yx8GcDDkIFHzT0avDUdArzJP8YhhWlSlqunwNvwR1MfH2xoYBvg8XoNS8EMLeAGzO6saFAypTwhq9TXJU03JEW1yqrGSgo+KpNRNEbRdFrWdFXVdBnjiq5TkGYUnYDN6gbF4jgrHdadnl17djRStSy1NGRfwGMvmDX6aNsXK/h0mlrlcD1aXWZbvbjCrthohraAvOFywwCrEeI6A3ZOgrhu0LoDywxVt8iGYWcYZm2Vy7G3nGMXKzpFB5LpX692O1/2+nyO+tpagXRyJ/y933yjusEXLJ/jWLiRuPgmrkkMCVE+fbS16+7Dh5s5r/HlW4qommAYtxq/965erTSBggpYqdCH6KWhmLAXlm4A2htpWUl2jEaexn4hSZanSWMhv4FXNHhEh+d4nwAYo8iOxaaSB4uoF/o0NWWHH8movWARY5iycZbycrt1T4Pf74D+UOAmEM22WFj/yCME/NM9Xl/5sTM3hcjklMlQ8QEPVDAzCn2H6ijilXX6h9ORtKKDi4FuhVFu5Xav1a0PYn9NTU0LWrpMoNCCXxnmH3/sK0veYKsXb3j+0iVLw7iVwTy/datSKEDj67cdOkTA+rDXCEdT6TMypOCn2a3Wmspyxw6oS7vq6sb8ufFtF1p82/4DT6+qWvTOKrfriTKWWXFXknUWnUdznbcOhdbzgngdHTAMEVE69s65KytfP3HCBskxXVB0BubQoSk53aPhnVFJ7Ue+eUGKXuoffY7yerN+Yk6NFGUAoJCQBr155ZIb4He9Cx6rivyzDLtz/fIVtdf9GgtLsSi05oDLLU2R5ydBp1Ien9VVVvYDt41dDf4ihlHQJeep+np0zBlzu1acAWT3fqQvIaO2q2hUgKqTYyuWux27WzOsxeWqW3BKvhH2s4hM249XrLNb6McwTtMUGqS/blm17DqCCVlZ+LCwWMEUZ2/3wH2BlNgDhMh+KCSkL5z6IlADdCaY5WLRnUM/Y/yMJNIvwsYFpchIZmTeNxx8BPv1mstwDkTyNR2TnB4+8WIqAxsiUF5pTU92hZMHsZFheIojyfk4KCAfcCG8tAZiNZF05oqpZ2FyLx1v612T5Xeini0m8waaXiSiaXoLTFMSRdrK0OVW2jhAebwWmvYgT2OgFjC2Ile9ubzcVuYpp437Giw2Fd0eUTXO//TzjkCOYPGXoDkSc7bOdQ3vH4ynoqDsiWhH01J3S//IJqwHdW67z2XyefLG4GY+LXWYUsWnRP/ZnuFdyKc58RgvSTCl5k/nry3rCMaP4zkPLEVFVFSpazTyAhClvX19t/UkwuRx2ZEjzs5w8gM8VwJ9IcMJijEcTf4KgYGsKfeGxVyGaEkIoR9tv380lEieTKRlMil2C2urKLPV/+yT5qrQxfSsdwuksyL9vbJhi6vSZlmJjhRscThJVdsHoumPsPtGkjUPdwnmzL3X0rtmOCmegjQJoqJ0XOob3I7MeG/jSQQwQwTEF4g9Cm5OPzKHUuWPCK8gb7nyKfVq0U8ycTMKgYV3v2+If80NytPBsW5QoOtcDsd3KOq5S3UUhboMqszD7GUBoNGnaoM7AgQEQ2WZda/dyq7GuE4Z/rgif4JxCAjU/El/bnbAT+mz88nUPxE99PSGEoLv02tdz3i83qzemkfL6AGJMn3Ba8P8xpiUuYJ8yaDdQ5Lc87eO3vWIFGTlNUBFlywkCBKDBoaBtzQQib9VpqgPOTiLu4zj1lVXODd6LiQ4qCbhNE8p79hJkYMnyxMBotrpqHdw3Ga4WFAzBm0ZiaR6hkJCMEdyTPqKzEL+7hAsLD3n96/kwdGDNJGuYEL8BeZDEgGbt2Dy86/uwNKoKHkhbWRUVRkUJNnbMfASMgJZOHd556+o1nCqkUcF2QmugwunC4lZLfTWT33+xe+fvVbe3NxMADMvd5HZEj1Imox1lbtsh52zbAOpgosZjQ3Fkkowle7K8Y5A3RbJIjN0+LPmRTdG+Y+JdwpIJDJKuG0wvJ06fJiDJFEDCFCO2ZK8zP7/0RpwRpLpDyENFlDLRIAp7w3/6T8ev7AcCZv1SsLEdJ0icXw+b+9Zx6ekjyBuwDWa5o/GfzmubUmBInRyk9EN7kJaUXmUKkFRjfbRaO/Rls49WAdYm3aVlZxRYALdCK0/FNuyrKK80WZla2JiZgguN/5D0yyIvM7A9VpRRf+m3b8Zg4EqHMtudFrZWgvLGimDsrQNBH7+8D0rfpcDCn2ZovIxTiBmFgVGULqIFQomUy/Bpa25FYPs2xOQgd5wwn+ipWs3jsJ0KaYb0bSiN10H05XnZovMWF8w3ajqegu2Aaf55rRP18kcytG/g3NIdNJBmCgebtQToBKOD0aTT0Vk6jJ2TU5LZ0CjJH7WZLoAmOl3dV4f4hudDuuDIPCjdivXjmV4lAM2SKNo+AIluyQRXAIw+tJwQQ7xbBL/cQIgEBVC4hqsoFwdMgMaZtAS/InQLgkXXHGapSNwlx5WNTk6KgjXvvnqscDb39uX1wGdPAZMl1xnjScKnrtlDbdsH2cxnoVD+v4ftvX/lrrcndjxyFYGN41qIKZnbH69c2Sd0bQpZOCOdizUtmXRGsvIE/H5aDhYQ7DySi4ev4hr1rhXL12aqq+pkfL0dEv2vILV0OCzKl+lVwwnk8wSe9mme6oq03dXOrr7YrHE3nvvjd/C3dwyaF8wuCwG5y/fWL4cP31C6cbx4oNgzgz8ufEw99bo7wTiwruSqg3AAeEVQVZOwlnST+Csy40DgoeFp9DPCMy9H9Mbju0Di/uWKCv/BoNyGq7k3mwfgetgCDnA5j6IUvZgMvn6iS4bn0z/AdITArgS6lAs8SrwQIwOFBYk9Wb9GwH+W6mMTC5MxhOIpsQ+n59/GMcI+QXpqlLiMmXfwCABYYBPfFdRtTgOBHxDuNUgW0YJ06Ks9vXx/IZCBwRNifML7eiokP499gUBvoYy8CAUH7KBiIuZlylP9hQU8gqaDOSp5K4DEhkfbBz9AOiLCshTwQqCw0p4wD2iwbF0ldNq35arX4hOgS5pwzccWQUW9j5sb1BkctDaj1l8oPVQzzO9rtnqq3kHi2UtaH3QUk2eWQAHDDxN26BsViH3pW/eJQaDNXS3u5BJmMDHfIJFwBFlvRXMUhS4QCUOq5A4p3jdD59c6pGUmLqY43AymBMYn5QgAGw6+9kgnCT4sAyAw5t47BcfEjSNal5b9YYwmyVo9jEvb5PB186dc4wkhCNoxyGYhxEG6DFpOCb8BpghIEFZIWCNbYTbQ9E6UPBdpPdxf3FR6rwyFHwABwvZeaVvXsCYCRHz/OpUj//x/pigJcWMCkcl3XDe1TSSTL1wNhRy5QZTEFAmbRPg3tHYvnhK/AtcklyErxAvRFOZP7cNhfdCPdMQmE0Kes+KqYIo5CrjQP7e3W29MDiorS2vWl1hK3vWZbeFljhtZ4KC6q9fn/1mHuvNVgGP58sLZ2XVwWBVKpWixP6acH09bS5HHPOs9dZ4GiWPm7M/mRDm5yubXPd/pXP93KKLi9H3vEnW5AEC8+aAyEyDNOXdy01uO5N0DhyTBn4r++WQpqkGV4yZnqrfUub9F9RdM1xrGrG0AAAAAElFTkSuQmCC);\
            position: absolute;\
            top: 43px;\
            left: 23px;\
            width: 75px;\
            height: 48px;\
            z-index: 10000;\
        }\
        .MPWcartNumItems {\
            color: white;\
            font-size: 25px;\
            font-weight: bold;\
            left: 0;\
            top: 44px;\
            width: 135px;\
            height: 35px;\
            display: inline-block;\
            text-align: center;\
            z-index: 10000;\
        }\
        .MPWcart textarea {\
            position: absolute;\
            color: white;\
            top: 0px;\
            left: 0px;\
            opacity: 0.1;\
            filter: alpha(opacity=10);\
            width: 135px;\
            height: 100%;\
            z-index: 10001;\
            cursor: default;\
            resize: none;\
        }\
        .MPWcart .MPWmoveCartToBottomIcon {\
            background-image: url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 448 512\'%3E%3Cpath fill=\'%23888888\' d=\'M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z\'/%3E%3C/svg%3E");\
            width: 18px;\
            height: 20px;\
            top: 212px;\
            left: 60px;\
            background-size: contain;\
            cursor: pointer;\
            z-index: 10002;\
        }\
        .MPWcart .MPWmoveCartToTopIcon {\
            background-image: url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 448 512\'%3E%3Cpath fill=\'%23888888\' d=\'M240.971 130.524l194.343 194.343c9.373 9.373 9.373 24.569 0 33.941l-22.667 22.667c-9.357 9.357-24.522 9.375-33.901.04L224 227.495 69.255 381.516c-9.379 9.335-24.544 9.317-33.901-.04l-22.667-22.667c-9.373-9.373-9.373-24.569 0-33.941L207.03 130.525c9.372-9.373 24.568-9.373 33.941-.001z\'/%3E%3C/svg%3E");\
            width: 18px;\
            height: 20px;\
            top: 0px;\
            left: 60px;\
            background-size: contain;\
            cursor: pointer;\
            z-index: 10002;\
            display: none;\
        }\
        .MPWmanageCartBox {\
            position: absolute;\
            background-color: #D4E7FF;\
            border: 1px solid #7EB0CC;\
            border-right: 0px;\
            color: gray;\
            width: 0px;\
            height: 210px;\
            left: 0px;\
            top: 10px;\
            text-align: center;\
            border-radius: 17px 0 0 17px;\
            overflow: hidden;\
        }\
        .MPWmanageCartBox .MPWmanageCartCloseIcon {\
            background-image: url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 512 512\'%3E%3Cpath fill=\'%23AAAAAA\' d=\'M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm113.9 231L234.4 103.5c-9.4-9.4-24.6-9.4-33.9 0l-17 17c-9.4 9.4-9.4 24.6 0 33.9L285.1 256 183.5 357.6c-9.4 9.4-9.4 24.6 0 33.9l17 17c9.4 9.4 24.6 9.4 33.9 0L369.9 273c9.4-9.4 9.4-24.6 0-34z\'/%3E%3C/svg%3E");\
            width: 20px;\
            height: 20px;\
            top: 85px;\
            left: 6px;\
            background-size: contain;\
            cursor: pointer;\
        }\
        .MPWmanageCartBox .MPWmanageCartOpenIcon {\
            background-image: url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 512 512\'%3E%3Cpath fill=\'%23AAAAAA\' d=\'M256 504C119 504 8 393 8 256S119 8 256 8s248 111 248 248-111 248-248 248zM142.1 273l135.5 135.5c9.4 9.4 24.6 9.4 33.9 0l17-17c9.4-9.4 9.4-24.6 0-33.9L226.9 256l101.6-101.6c9.4-9.4 9.4-24.6 0-33.9l-17-17c-9.4-9.4-24.6-9.4-33.9 0L142.1 239c-9.4 9.4-9.4 24.6 0 34z\'/%3E%3C/svg%3E");\
            width: 20px;\
            height: 20px;\
            top: 85px;\
            left: 6px;\
            background-size: contain;\
            cursor: pointer;\
            display: none;\
        }\
        .MPWmanageCartBox .MPWrefreshCartIcon {\
            background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAARCAYAAADQWvz5AAAACXZwQWcAAAASAAAAEQAIFT2JAAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAArwAAAK8AFCrDSYAAACVklEQVQ4y2P4//8/AzUwgoEGtOf45dusjjvtuib9r/uytO9aEwN3qvf4eqOrw2uQwdrIqR5HC/+Fnmn9n3S5/X/G1Z7/Ex+s/u+8IvOL5pTAJKIM0lkcHKe/LPC5/qrwcr3lwf5AfqfX9rxvlTdm/J/ycO1/l6XZn9X7ojStF6Vvt1mccRS3QQuDJ5gdTpREtlV3Wax14I6KbyBXzXu89b9qi/f7tc+O/PdZWPSZYBihA42JIUUTbq76v+Lp3v+rn+39f+Dtmf/Wk1IuYzXI7GgGp9nROCZ0Q3QWJ4ooNwVUha+u+Lfp5eH/m18dBxuk3hC4EcMgrZmBoSl7G39k72v+Gbqv9LH7loxThssiNgDDyBAYW1M2vTzw/8T7S/9Pf7gKpC+D2Qrlgf0YBmlO8Zn4/Mfb/+c+3vl/+N0loK1H/k9/tOG/1ky/iZpTwgz1Z0XNc1yUdTxwVeWD2BXVP8KXVHxXbgkMwjDIcFbg5pufHv7f9vLE/00vgQG5Mvuv5rTQUmDMCaF71ezoZkal2hh2rNHvuSzj6qn31/5vfHH4/6qn+//Xnpn9X3tOWAGhSMAwKHhDybc5D7f815rq+27xk+3/++4v/++5Lv+HzsJoa9QUHyejOSWyCqdBdiszz9luyNgEDHRNxyVpX5tuz/9fc3P2f5fV2T+Aqblboz8iWLUrtEa9K+yFel9wFFFZRGdxjJPjsvTPRdcn/88BZo/UK+3/Q8+1/nfeU/wPGPATiM5rIKA5LVxVrdN7hfWCxE+WixJ/6fSHHVdt88smGEZUK0YoxQATSWyMvwe1dwAAAABJRU5ErkJggg%3D%3D) no-repeat scroll center;\
            width: 20px;\
            height: 20px;\
            top: 188px;\
            left: 6px;\
            background-size: contain;\
            cursor: pointer;\
        }\
        .MPWmanageCartBox .MPWrefreshCounter {\
            width: 24px;\
            height: 2px;\
            box-sizing: unset;\
            top: 182px;\
            border: 1px solid #AAAAAA;\
            left: 3px;\
        }\
        .MPWmanageCartBox .MPWrefreshCounterPercent {\
            height: 2px;\
            background-color: #AAAAAA;\
        }\
        .MPWmanageCartBox .MPWtimeSinceLastRefresh {\
            top: 171px;\
            left: 2px;\
            color: #888888;\
            font-size: 8px;\
        }\
        .MPWmanageCartBox .MPWmanageCartGraphContainer {\
            width: 95%;\
            overflow-x: auto;\
            top: 20px;\
            left: 35px;\
            margin-right: 10px;\
            padding-bottom: 10px;\
        }\
        .MPWmanageCartGraphContainer img {\
            max-width: 300px;\
        }\
        button.MPWbutton:active, a.button.MPWbutton:active, input.MPWbutton[type="submit"]:active, input.MPWbutton[type="reset"]:active {\
            -moz-box-shadow:none;\
            color:black !important;\
            text-decoration:none !important;\
            top:1px;\
        }\
        button.MPWbutton, input.MPWbutton[type="submit"], input.MPWbutton[type="reset"] {\
            height:19px;\
            cursor: pointer;\
        }\
        button.MPWbutton, a.button.MPWbutton, input.MPWbutton[type="submit"], input.MPWbutton[type="reset"] {\
            -moz-background-clip:border;\
            -moz-background-inline-policy:continuous;\
            -moz-background-origin:padding;\
            -moz-border-radius: 6px;\
            -moz-box-shadow:1px 1px 2px rgba(0, 0, 0, 0.15);\
            border-radius: 6px;\
            background:#D4D484 url(https://monitorportal.amazon.com/images/lib/dtux.amazon.com/secondary_action_button_bg.png) repeat-x scroll 0 0;\
            border-color:#959567 #898958 #7C7C4D;\
            border-style:solid;\
            border-width:1px;\
            color:black !important;\
            display:inline-block;\
            font-family:Lucida Sans Unicode,Lucida Grande,Verdana,Arial,sans-serif;\
            font-size:11px !important;\
            line-height:15px !important;\
            margin:0;\
            overflow:visible;\
            padding:0 6px;\
            position:relative;\
            text-decoration:none;\
            text-shadow:0 1px 0 rgba(255, 255, 255, 0.5);\
            vertical-align:middle;\
            margin: 3px;\
        }\
        input.MPWbutton.primary[type="submit"], input.MPWbutton.primary[type="reset"] {\
            background-color: #FFC435;\
            background-image: url("https://monitorportal.amazon.com/images/lib/dtux.amazon.com/primary_action_button_bg.png");\
        }\
        .igraphMessage {\
            border: #A9A9A9 2px solid;\
            margin-top: 5px;\
            padding: 3px;\
            background-color: yellow;\
            text-align: center;\
            width: 99%;\
        }\
        div.iGraphBackground {\
            background-color: #E8F3FA;\
            position: absolute;\
            z-index: 10010;\
            display: none;\
            opacity: 0.9;\
        }\
        div#iGraphBackgroundTop {\
            -moz-border-radius: 3px 3px 0px 0px;\
            border-top: 1px solid #333333;\
            border-right: 1px solid #333333;\
            border-left: 1px solid #333333;\
            height: 24px;\
        }\
        div#iGraphBackgroundLeft {\
            border-left: 1px solid #333333;\
            width: 5px;\
        }\
        div#iGraphBackgroundRight {\
            border-right: 1px solid #333333;\
            width: 5px;\
        }\
        div#iGraphBackgroundBottom {\
            -moz-border-radius: 0px 0px 3px 3px;\
            border-bottom: 1px solid #333333;\
            border-right: 1px solid #333333;\
            border-left: 1px solid #333333;\
            height: 24px;\
        }\
        div#iGraphBackgroundBottom div {\
            margin: 5px 10px 0px;\
        }\
        div#iGraphMaximizeIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTNAay06AAAAAWdEVYdENyZWF0aW9uIFRpbWUAMDkvMzAvMTDV/ukiAAADCXByVld4nO2czW7aQBDH/67USyvueQcqQSJQydEmQKwAIYmSNtxCKrnFJKKB8HXKM/TUa6VWufURemhvfZDeqrxB3dkFIzDkkK7wNGJGstfjj/3N7K5nF9jl559vd2ijHQQBlHz+/cFaRfqx6lnPMS/WJH1xt7EybpgO3t/PXyU3TJWc4RWySMNFHjn08SRmfhI1vIM9TePmv0QKezgicg9VSuPm5+HgAqdUCwOMUJ/jxy1FdFj5LXRZ+dH2F7fsY4eVn6QowMm34bHy88z1f44tVr6HMiv/LRLM7S/Jyq9Rb8TJr9IbwMnvocLKz9FIiJN/xBx/KpHxT9ySQIO5/nn7vzRz/zdCgZXvMsefDvXAvPG3tdbjH24+d/wbMMefAXv7y611/LlmHv9sM8d/7vj3mizg/fw3ZOVfMscfh3n812Tuf8o0AuPkbzJ///iGvf2lmdufz8o/RImV3zZ6/60l8rAcMkbf/5jzS0b9rznfRZGVXzEafy3SHsrvG8Ufc34m8vtb3PwmWcDJNxt/m/N7hvHHlG82/jHnXxi+/6Z8s/GXOT8gEb7wHyvftP993HxzEb7whS984Qtf+MIXvvCFL3wO/s2vDTY7flj47nduY+cGERG+8IUvfOELX/jCXze+iIiIyP8in55aX75e3T4L14q72KF9brJ2fBDR+3o+UQceavq8p+c32hHdR1bfv03nGtiitIMT7KJFd9RxTJualXGJg3ueV3oCe3rtXIq0Ik5pX6f7HQzpqERHNp1T+rXWC7Qvaz2v9RztG7Q5ZEu4Eryi1wKPPcrodbGL6byns3qWLNqf5HSgfVI+FHFIV86JeEKb8nV23f1ijnk0iZSiYwdVymuX7LPpeY/09tSTOm02utpzV3ui7u9OrzfIE1+XkSotl44q2u/ouvtx6ug5mKGPypLhP9Wq0sM6GZfpIicx026W5zhr6aJlI2PLVJn509ZxRRapUj7WpabO9HQpZqal6s6UqqefCPUzfX1z7p8EbLKppj3oTTzpz1le0JapOVfLUmXxXzEMpJjgHgM1AAAASG1rQkb63sr+AAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAppDOhAAA5M21rVFN4nO1923PbxpI+NieOI9mW7WQr+7Avqtr91e/p5OBKgo8iKUpKKImHoGw5Ly4QJGJufDuSrMTLwv++092D23AAAhBFUTYkW0NicBl83fNNd08PcPxr+3r+YujM5m7wYng8m2tBb9hJFMN/nszmltdoWtOGHZz3O/5cDV5R8fKo6891NTg8GmE53Hf8eVMPhs7ZjFW3D9gZfPwJBv3+9bw9YH86e6PLufK9MlY85bXSVlzlUpkpXnB0csy2P2bb37Pth2z7hTJRdpU+q32vTINh93QMJ907wXPvsSYbUztod49mczNoH7O2T1mBd9J29nEnpwe30HYO8Vu7T8WvWHRO+An2e/h9OMJ9e2381hticUIbnQHb1wvaI6oc0dlHDl3kmM5HxdEetPIEWqUG3VMNmtM91eE03VMDix7bqLNCp8KAIiiAzdMFbIbKB+UT2zZRpsrkpghp9x+hUHschouvXN1EezTfrKw/2g3R0W5Xf2J0bqg/IkZlNOiOMXrMMdpj+FwwJNrs7yeG1huO1fccqxjDPHSg3Ql4Gibhg/VL8bHNFD5qCh9DTyM0uWEf0wkhnRAyCSGTEDIDZ/AbSdVx2AdvzDac0m04ziluKIPhI47hiGnXX0zfPrH6ZXpm6DJFywdSa3Eo9bFXAkrPJihx+62BqbeKgbnDwewwhXvLfmfK7wwuV/movFE+c0C3Ekr5jn3+oHzIBVPjvVYzCtO+pprybqvmdFtLJSSRDwBJ3y3cc3W7MJaGrROWhjYpjV1+h25OCDrbI+SmKzIo1LzhUq9IdsUgqwrQP1k/ncFeKYBMiwDSxoJu+RwilTDy8joqqMVy3UJCTOAEbAo4oVLdAlCLuhV11KoddMhqx9hB3+eqmdZarZ6tdlC9HT37jmP0ko0FV1J0moKKCUZHnl0Gh6bw0e8cH2fQJvZ32guk/yjC6w3a9B7TGIacoE0dHDeB8j8XonuOl6Z7UsQEwm965VXKbBBkLsfMmJiFx87qnZJdULdcAhKGmvJIDpD8rxiab0sh6ZsFRk4/HDnBnigIZMRtHEi0SVaPI8DnhNYIkBuZJeEHQJbskvDDsDTED9PORRl4ccxY6k6gOpfGd8otEzgYAG41Vg3wkOGqT6eEmTho5GNWxUCWk6Ju5RrInl6+j0fmsaUTdIRhMey0aWFqjBRP91PQbUXQwQjyGcfSKr5Z2jVDF6Fi7KNIR9ZtbqWgU1IQLUOXodUgtBqEVoO6MhEgfBj7QleGMWZ4WALHh5G14ip/LImR2IRii1BEEy2BonpTFE1CkVRMCqPlEo56Do6WysMALR4HaHEkueI1uOY1zCwwaUsCTGZ0llPKEevpTCWVP8r04kJaWcx6lqsldmYYqMcr5z8cYLAPh0AOkyMNjT3L1bOLnfkN8l86XJWoKdzppVGEDQhXaRXDVdkoPZOi1MXA3piZ4PndelNx0teE04j14xlzT+4rTsbKcdqKcPrALJKrNQaG83is5ZkVnTQ+JKgEjUrQqASNStCoBaHZkaoQn40prz5prlfXP/uSR0YWIWQRQtaNKPsQvdfrJd7rps4wcJTYiI0wWQSTRTC5BJNLMLlS278H7iZOt4yAayTKdMHMr13lmH+aKhdFTLEypoNmTYtMNqhSJ790l5MbDtyctQkqm4x/mmvIDozkY3eIAaY3PND0BtkqjR1YjRi2BA8IpammDFnymxYMWWlnRF0sGhF3bxW74lCFPbIfQZStaGL8zZP1SIhaZ9JW7KNXCCbdmp4l7fo4kgSWKkaS7GkJPB+mzPz3q51zLziRJQyNa+imEViAYxKs7zhYpzBlwCHajtxzsK0g3LbMunKrJieAN7MMJkNwLUNXKAy1oUIvOJZagXAGbEULi4Ol2+T7oKezhw4bKl+jQZ6PCSWGE5di+DyBIUSMINnDQTvV5VZZ/hjhSgNsBSCFSFbO1IznEqg6B9XThfjahMeIaOBe4mEy1SVYbY6rTcB6NgHrcWA9W/TX4cMw/JDq4FQVfQgDTIMh90mHwzDE6SyG62SiCIN0a4HfmBSCXwjRRejnzrtmxEpMbveZhD0zkBB7LA0sEWlCUYo0DuIAMCr6kBS/KLzbEbxXGFOBZJTLIvZPOKkdJlto7rQAvkXsH0tgjDSzAt86mCiXDW7DLAduCJzmRzESBFBfzhQ/ymPIPB2jGP82K/JvoWGKh/Z8V8gR4HCa4xT9mjL6DeEUecLifpzFHTlWppMuKAo1JECdIadm/h2A1nwpJYcezoBB+Z59WlRXTfk7q50xyJfOJaXnyStHn/N8vxI2QFpR7aqBg0Vk/kOGDFPDPbb1in3/O/sEhjp4hksnOVaL2WrtphViFg7zHTbIv2X/w66b3FPmzqDbkmliuuUDCyUMzOJDTCGgsJ8C/y2OLWB5Qo1DZTFIw+H6IEo8mMGAfTvpw15xM71UtplgfXL6cwlIl4C0Fwx1bnoms81SgCYBfMIBfIkWzZRPTaIOChMaxaI3Qt5e5FcXC+DAFGNJbYxsHjSZbjQtKUUymjOPJ9owVhF+GJ4mhm2VRhNBSYtjXGzSSLdlekoBoBUiHM4ZGeG8r1UcYLlPacjmjLBnZ/X9cjCWccp9bj36aevRdwuAWMTdvGkASK6iugxB8sqTXlA02SZmSIZ8OeQW9gflncCXMAS9V3xIyoLhWoahZpmEYSONoVsCwoZUD6VGDU39VrFqQi1ME6bO1RBLA0vqvQ3efYuDFiocTZLkuyuGrNMKaZLy0UUtbl0j3y5iNTaXT5pHvoowaQ4Ei3jRB4M+kH1tT7l9DR8GIYZO6PoNQ46koEcxTMO8wB64MDJEx2bKuQ61r4x3nTteI4ayZAS5/8cxNWSYerbcYWnx6FqLJ3W0GhQpQrcknCNvx25KOGcuRMezQYy96X8xGF00KPPV06pq+5QYUcjnS8TeSmRhMf9Qqp6wvce392h7BCWO1k0+WDdJQ0NIUUEPyTUs19lfIZ75o0t6hC6UN1jGluSaOZZOhgqetHR0yQpMZGXIpDMwuSqix5yxFuSMQfUeB+pPaICHZvkDDqKhdCuktzWLrKMp4tIYaRMnDSBTFUkooljYTLclseBDGqPL4LQd48T8wAM0c/7MR0w6wBRbehRCpi3XOU86wGhTGRlqa4XscWTBvMEkaQg7TBdS70XYGlXnHLTis4CRr2I0yicFhobgMq/vMDSdDxdN52XQPY/G3Le46qPsNIN8hvDmqof55Il5BldqTYfKVyQSK47EUuULLZphNFmwaMAU7cCnbPsVBryWLT9dRQe2igdgBQxbyweNMD1VMKdX1H1DHYTc/BnGCm9dBxcyKQ2pErbs9GSXLx015POHQoKvJ6dAmT0ohnHiaS5uxSTj2KSu7AabFg3LjXLa+iTynD+gK/OGAc+XSOTr7OoS4vLGaVu6RA7iIAnE9TIzMFlaS/aNs+gELkNwJ4HgXxjE2cVIRWkMMTBYYrFrhKO53JWuPD8AvnKBQQiDEF5TkpCOST64IfwQTr8MuDEJt0gTsgnrUpw5XCaFn7gUXuCMl4fZr5c4+QAMDDHi3ZhgytMJLaUqqthSNkkrtmBNYahtkUtKWaAGjxEZPLTOSuQSLp7k+DbgwkkFM1FaiakyOz1TBvZ+0Ot3r+e95JMGfBSLgwG5WSKJ1EdxnOCcxjsU1FlmDRdHjwDpETf0CIfePmpxb9jFXYZDqjuk4hyKoJf04qhB/LEP4LEJTUrWnGXWVGuSTk1ixUHUouesPV10HzHh2niVmPK5jLjY4zkfMPR5yh+MR8LZi97BCwb8SYdOfsQ+HwzgCSw9esSKij9BokoLq/jzV6DuFdSpNz+PVvEUYRX89JIJVz5fUzHD2O4nvH9RbkOO3qIqJWuqyc0guRm13MrIbYfLbciQ8djdQtzkd0F6O5GMZPucFdinmkRdkqhbS7SMRLejnghzAWDLJP0aPzFPENad5dRVk5xJkjNryVXpiySBK7R/LkK8hL4o3+eswD43YldNq0VaRqSxbeVi/ky80NDnIf5w+1nG9mriskhcVi2tKtIaoBHpJZ4j5fPoRrj9LGN7NWk1SVrNWlpVpNVDRCYRHqFU4u1nGdurScsmadm1tMpI6wmX1j5/psxH5LekcfKEy0e2x9nSParJskWybNWyLCPLh1yWbZxMvYymWP3oiQ4XUa8Tt1aTk0dy8mo5lZHTVuTcQV+hBdKiQx7XiA55XFNNZhOS2aSWWZVR7SXma04XRrV4+1nG9mrSmpK0prW0qjjbg3ieK7LxtyPrMFl3llNXTXI+Sc5PNexxpEZTZax0URRvcBounG8P1UasP1tSX62RGo/0QtnVEoj2unrqm5H6Zqa+jeCsQXCAAewqavosoaaf2F5DTNV/hdkGlKQRK6sh1ZCWqo71pIaoP1uxmuVpoIfqI2jybV1kBWpeCeDnAsAJaMNtWRD/HDdirOqum3X/E59Vpytb4pG5MK/4QncFdajL+5gtg/NomPpxgPmC7KgE0A1Z23TV8NJtU3/W7bBWG7ea2jhda0bgaFPTZ99StY2wsuFOPVVLVzat7BNrYotE8d2/5t+VUmxxpYAasN6AsGM1MGWtaTXNhiZ0AiPqBOOJ7QlA2VFtw9OnWkN6I1N/MvYmi6K8mybclTi+JrOoEkA7CX0dI4Vd4aJXcaSQMoCqGja0X84Aqqq33GYWA7ARtiEe28g7tJlzqCa2qBCBbXTz70ohnnKFIMssGsuWGQ+xSostS4zoqgr/M5stE9xtXeSu4YUUmw+YYnulnPIl+78vJyW9pbpWK4NMmtKx+wbnuWvWjrg65u9lAIWUmteqIgAVO89dAbTNAUo8iZnVLWFrNlY3Go0surNVWxUJLaa7RkOEI0F3cGDTz6I7unCWqrF/Bdl6o5t/14pAbL3I0Rm6nd0e7vkW7CNFznPXlriD72G4FixxqYq1jBZreJaKmTr8ZqnY2BobYy1DxRqNRd2NVWwyhV8pCKDWdlGHbKObf1dq8ChSg488Mwper/NuOVkumhh6snKBbOIG626OZSgaJ8yXSlJNpqcgH7vuWdtXEfzd73Wv5/u9xLzmFFXhCJOaIRDTZn+v8YkypAI/oHKACryLEvRpf2QF/njW/YFzPe929uHPr6hifN0YPlTJxf26/FFALmYbTINu5wXb898U1rTEkU+VfcXHReCgbkfsCEqonvFHCdNR33JVnKaOfRK3PkofuqBRnh/3jdJULOGYfdYFmPWIS/dxsSorcY49o4VP8Hkyv6P9Gb7H7D0edxkdYaSOeIzPO7xkDnTW/uIV4mclylH7m6Ip6gJyDmIOXfUYkxev+IOFZ8jf4bU04ShaJpSSfUwF/KiHyn8xlHy45sJ1d3AN+p/czQFtmSwcv8WOVxO/huILd3yIxmr+GfzEr3iGpxhKhPfdMFyVHhq806XtEO/lUUr7jvHBd0dKlx/9/5Q50x+obTD8QQK68nf2Ga4En2DbBJ8+ZLNtTVZD17Bwzyb7q7Ea+BakrrqVQH6kfAYJZmjGdmLPl7hajvXHSLe1hb1jPYp0NqFBhtAXthIaJLZDF3A6RMuAHAyZtiRkJRzp4CLJCeqM7Mgs2WzjkXDUKZPz/5CM+HEP2HUg/nIpMMIjhtcnnKMCNiAuuspEdytiLRFbcc//z3TtD9aKHqIwRXfrgqNxyq70lqFHD0R7x1D8gCx0wbYlteuM7X9Cy0X5VR4leHg3wcRI3CU4+yHn7B6tYKvZuWbnmp2/aHYWcarZefPZeYh5t7/X7Fyzc83OXzQ7WzU73xt23orY+RNeD6ReM3TN0DVDf8kM3agZ+t4xdCIiXTN0zdA1Q3/RDK3VDH1vGHqbM/RvKP3f2DV+V/Sao2uOrjn6i+Zos+boe8PRoRWd4OiaoWuGrhn6i2Zoo2boDWNoSb+tM+9qzq45+845W9sQzq4z79bB2XFfvAln15l3NTvX7Pw1sXOdeXf/2LnOvKvZuWbnr4Gd68y7+8POdeZdzdA1Q39tDF1n3t0/hq4z72qGrhn6a2HoOvPu/jB0nXlXc3TN0V8fR9eZd/eHo+vMu5qha4b+2hi6zrzbNIbusr1AVgk8o+cME0PHDz5/ndpLZOubcO7yHuMyzW8pJvudsPPZK+kx+Vok9nJXyEHaSR2dNS41JdoXHrMsPza5Lz2YNeZf0dZJ7rvYSw2GgLUW3Qv1aTelK2V1L5yj5iPdV6drDSEiXETXgLn1W9I2+x5r2w7XtuTILlqj33N9g7xixv51ztqNbVFduEJti67HFtVKs926bVFD4J1sW1TUojpj7X5Zoo9jPmUMndDmGzD0kF1hhrjUDF0z9H1k6M2PFoisWzP0l8rQT2I+VSa5HP00heIucgO9qvBtKmbgIL4zrEse8TP8LnD2fzJ9b7N2+3hXxAivWfsvUOOAQ/5k36+iewZO/t+o9Q9Q/3fhb8keNWb+ncpqW9gzptijTGSbsEeB1+eyX5/1otD/h71t9t1n/WrC9k/3qO+VSUG/7IHiCn3jG3Y2S9jHW8JGorbejoYsk2gVLXmcWht6dzEli7OljzwJbNpkvybbP9QCg30aox5MIo6wkYl91Bdg15vFlCxhXKtjSnIrUqYtVXRvO3W2sO7+2JINAfPldp5Z0faqbq/o2Gds1pcY82EfAtYEHq3er/JGSnMNWijXm7QGPma9ZMLshE+oJ7sJVEn3vkuuW9+YsXDCJGMx1EFWLbQkgQ0nTBqidWlHrAVsCTw5Yf/Bsm4J0rodGaTxK4f9Twzbi8g25X1E+YfYzzLslOfsXhaPfo2t+8Cu+T7qoSIf3JVUDSYfkMsYexaNaC0mNS3VB6F+ws6iohWkcg0A6Vso7UDgDk9AqwgCt6ML5eRZTle2mBcTMuPlWi3XZ2w/QPMC/bvXnPFes7sMXwgux/i5cNwbjszikX/D3m7lXjU+eqzQ6wCzjy3CLyrTxSnbB/SQrCyNndmS8ItekF92MnC6YO0eZ47MWXeZPEp2j4+xj5C+F7nSk8T+xa+SfU/TzLhQ3j3FRxW/p+wrZd1T/lV2JFdZpstPpVcqosciGuEV01qcd2fFjtiRtnB5X9liewKHvWN/RQ3ScvdMykUcCZJ7LmIrZn4k9xbvUlsDb8u4tRw7P2L1nzC+sps8V83QK2JoLWJos2bomqFrhv7KGDqLX8va0B2U8zXKYbOiv2nfaBr5RsYNfKPHsWTxHj4oM/RDLoODAQPtYDC6np/3O/Cy2ldUBPE23bJoK3wIBH1ALVz5OSHev8pzPgp1daVnvS0bZFE3y2n3c+UQ7/UfioPzO5/wyqCp4H1mxRAuJfsW8aCfYfz9vsYeJlH/0m/Uv96gxfg6nhcRWiufj9tmx5FW3lWkooiulNO+7XgLq6XWvl3p3MmDzBlWWUT4IUPnI85+A1afo/F1MV+giC06wWikyy1LmIXTMR8zHTsGfXJTc904P48Zm1PJXHc4xw86MMm0G24rdiyTV1rmD9j54dmm04SUe8iiNC9L+SLr8nKWy8nHbAOVyQFQB//Ax/nReO5MRZ8BpFHUZ7gt9GU4LkP/GY8khk+Z3eUW0R5rxUeYZ9oYSegoAx37jYsc67HSxBnspPdm4fxKseyQ25HEckzTUvk2mqEkmezg/YfMuRvWrtW6/HdkkHj0HvM2vM6Z/RcjAVlnWMwKaJXmT4vpgo1ybbAzN7Bf+nw2x0Rp+8ipGuY/WJgHAblFYLnauIe7wJ+3ow350szXhMfKbwo8e+PdHWnBM7YPXT8tP9HC+IZJQ5S+7Mh/sdJV3qbGz2+AN0tKv8XXLIC8G5GVpaOPA+sZxih90I8GjrFjlLyPo66OYyuwwjqkny3BfMnH3zeFf2H083A8nGL/oehZ6FdWi57dDuYxdst4doj21wx18m562A94T2EbyvayHzOPXlVPm6DUDcyCMXHU1fGKNvY0mGe1kGdBtj4y7QTHaRP1wEe5e2vi2Txp5mvCVrT3LqJwIcm73ox+p29wv5OhmI/7M+WAneETevoztAvuytr5XWhHsi+FfexTlG30A0P3Z/QKsn/FZ52Vm51Qo9kJY+PkvFxqaak/5BlrF5j//D7KoT3DVRNhzW6U4bVOyf+EDBu34jVGpC9xFfBVwVULP+acYxW6k3d+2ShhlWb5NMeYG8wxy7SmiOY9Tm/dQM6H/EAd/1s8V62F9m5zQR5hZuFdySMbyyKSELduCv4eajnEeSDHk6I+tOpkMerTvFP8RQTFeM8JzlFAtDjU/T30gnbjmgy+fYa6BbMn76M9i/HNj9IjP/FSzPfPimjfleynKEUVM3THGOfzUL4GWrweH5Hhr4UrfcKcX/Aop+iXgiW8nr6XJUux79G6w3SGePjsgUNE/8ONcsPT6+ZvPzdcnDdfvs5QE45Yts4QfKWyGeji6sd6pWG90pCklc7cr99fcldrDdexguLbjFUTchYOnw93gucHu35xhvP+rNLZDCZeXIlYc3HNxTUXbxYXr2NNZRYXf8dweot+zISxRrhqLbltUzxRH+OBJvfyPT6/1UrkLNMKbpX1hqIruG9r1VoSv/RdelHNov8HGhrGvQzh6R5byPKfc46CFrGygHyfI/PTHVwgJwLL7G6k1Cc4l9lExmuh1Bs4p9JKSX2Mc9qtlNThv4/7rmd2uwiqd6sLP2A+zGfeKlot/Zl9NjlukP27z3UkafNATJvGvs3K6gXZayh5m69z9HFN8TgVm2pgHoyBM7Xwl76bqE/r0o08NKvL6KmQTzHC1kC7vyw5UX7gemLq+YhWl9UWWuoX5G18cfKBbeuZV11EMS2THzG3bKZQBN5hbZjxT+CtgIWWlMr3cX7gvZRJk0miifkITcxLgL8NHCsttI7WIZNFDNMSeYTYTzFXGOzoMBs2XKU/QMv7CjnxjULP9gTf4hr7VfLai1bJTbz6b3G89hI+vOjjLJcSzAtO0ePw0feC2akpHhFKyUWbtIn9ROXPU9C5BdtiNZC1tQ4plcMZfo4dJsLgN/w72Btdz9ud/mzu+yr+BD36Rj9BexDJewvnCl6z65ENNItk/R+sBiI8oM0Dtv0vPh7uYURlxrZS33Uxfj8Jzvg8jbh/+IzgYfd0PFeD9t7JDAtnNjemdtDuHs3mWtA+PmYNZAXb7AZtZx93cnpY5xxi0e7jxvavWHRO+An2e/h9OMKdem0qhrjxhDY6g9m81QjaozZuHdHZRw5d5JjOR8XR3pgdcQKtUoPuqTab26zQ4TTdUwOLHtuos0KnwoAi6MWYfo+zbq/jJzNFo4q/EDM7y6zhePWozT26yx40Vmff8L56wy7uMhxS3SEV51AEo/P29Zwu/IC5kzQ0vmeK8uv1/OWA7WOrwSEvR85v7HxMT0ZH7C5GR93ZvOlPTF8F1Rqd91ZzomD/fHA97x2P4BY6/SEUgz7eyWAPFbePujGAKjjJYMS/n4JM9gZ9Khy46b29Dn7b62LhsNNM2Z5dOOAATqoGvwz+OZtbUDr09ZSKARx/0DuC4hcH9nFZuU9fR3C6X5w2AtsfIKIn0LgDpw/b+s4ZFF0q+g5KoOMcw2H7HQdu5uSVA9/6Dn47HKFiHY6IXrs4GEFn/xNLTLYOznu47/kxtn80xNOxI6E476JK7vfO2QmU4OTYvJ6zP7N5I8DCp0KjQhUKVvZgf6Y+VoAFG9z2TzpQjvawR40GL6E4h4ZqQad9htfptFGrOu093Nrdw2/d4+t5vzfy5+rPVjA6HdCH4RHf0j7lH4LOOUIYHJ+wyx+fdPGcwdExgj846lMBm/8b04V8dAIh8XmKQ6WF4TJK1rPRbQT6tjCAMGUD5xQdRkjqg2lMTKZmiLPWBUd9EtQrJrX+3itGhb8ewIazIepPn/e4l+wUY2RVF63Ci6DfRziOHdzvuIOn6R6hMDt96N77cMrOr7B9vw/XCoIXR+z+XtBOQbBwPZVf72F8HXZNLXUtla6l5V/r6Pgg2nB+2sO1elSkV+5hl9RM6pKsxC5pp3ukMW1AMG60h7cg3kRwMOxezw9Oz+F0B6evsHDYN6PByldU0oDSwB92RJcN9QddvJmD7q808uBYc9A9hM7TfQGXOnWQzE4dVKZg0O2wyw6R8l8Mj4nSOoli+E9GAJbXaFrThi3e51HXn+usY4HusXK47/jzph4MnTMk8oNOOOIxWmC33k4SNA16bRy8mFkRJRmMo6nlC5yg7qNBOs0dvEwavKY5g5daYvBSZYOX4RUevNTU4OUWGrwKYPN0AZshT6iY4PB/Q4TKDO8bilCoPeHkzg20R/PNyvojNX5KoKPdrv7E6NxQf0SMbmwgrg+jxxyjPYYPvQTmAtOM3kSOLmEVY5iHDrQ7AU/DJHywfik+tpnCR03hY+hphCY37GM6IaQTQiYhZBJCZuAMfiOpOjBieWO24ZRuw3FOcUMZDB9xDMH1+kuhZb3L9MzQZYqWD6TW4lDqY68ElJ5NUOL2WwNTbxUDc4eD2UGfn1azg50Pq/4+R95LrJQ0v/oh36fjvVYzCtO+pprybqvmdFtLJSSRDwBJ3y3cc3W7MJaGrROWhjYpjV1+h25OCDrbI+SmKzIo1LzhUq9IdsUgqwrQP1k/pYBTEiDTIoC0saBbYcBAJYy8vI4KarFct5AQEzgBmwJOqFS3ANSibkUdtWoHHWJADTro+1w101qr1bPVDqq3o2ffcYzA+buSotMUVEwwOvLsMjg0hY9+5/g4gzaxv9NeIP1HEV6UiO1hyPStoE2dKF7xuRDdc7w03ZMiJhB+0yuvUiYP5LkcM2NiFh47q3dKdkHdcglIGGrKIzmgJDQIi5ZC0jcLjJx+OHKCPVEQyIjbOJBok6weR4DPCa0RIDcyS8IPgCzZJeGHYWmIH6adizLw4pix1J1AdS6N75RbJnAwAIwh6JUCPGS46tMpYSYOGvmYVTGQ5aSoW7kGsqeX7+OReWzpBB1hWAw7bVqYGiPF0/1ANi3SwRHkM46lVXyztGuGLkLF2EeRjqzb3EpBp6QgWoYuQ6tBaDUIrQZ1ZSJA+DD2ha4MY8zwsASODyNrxVX+WBIjsQnFFqGIJloCRfWmKJqEIqmYFEbLJRz1HBwtlYcBWjwO0OJIcsVrcM1rmFlg0pYEmMzoLKeUI3yaoqf8UaYXF9LKYtazXC2xM8NAPV45/+EAg304BHKYHGlo7Fmunl3szG+Q/9LhqkRN4U4vjSJsQLhKqxiuykbpmRSlLgb2aE7/PuKkrwmnEWYKfLy3OBkrx2krwukD5mqvLzCcx2Mtz6zopPEhQSVoVIJGJWhUgkYtCM2OVIX4bEx59Ulzvbr+2Zc8MrIIIYsQsm5E2Yd8lj3fe93UGQaOEhuxESaLYLIIJpdgcgkmV2r79zAL5wqzIxnXSJTpgplfuzxT7w+cBy9gipUxHTRrWmSyQZU6+aW7nNxw4OasTVDZZPzTXEN2YCQfu0O+oiZ+9quIHViNGLYEDwilqaYMWfKbFgxZaWdEXSwaEXdvFbviUIU9Ml58lK1oYvzNk/VIiFpn0lbso1cIJt2aniXt+jiSBJYqRpLsaQk8H6bM/PernXMvOJGlriaprkQ3jcACHJNgfcfBOk1kLW5H7vkFXy+5zLpyqyYngDezDCZDcC1DVygMtaFCLziWWoFwBmxFC4uDpdvk+6Cns4cOGypfo0GejwklhhOXYvg8geEHzJdNZmQv8lw+op5dGFKIZOVMzXgugapzUD1diK9NeIyIBu4lHiZTXYLV5rjaBKxnE7AeB9azRX8dPgzDD6kOTlXRhzDANBhynxQSNSnE6SyG62SiCIN0a4HfmBSCXwjRRejnzrtmxEpMbveZhD0zkBB7LA0sEWlCUYo0DuIAMCr6kBS/KLzbEby0Rvw9rvsqYP+Ek9phsoXmTgvgW8T+sQTGSDMr8K2DiXLZ4DbMcuCGwGl+FCNBAPXlTPGjPIbM0zGK8W+zIv8WGqZ4aM93hRwBDqc5TtGvKaPfEE6RJyzux1nckWNlOumColBDAtQZcmrm3wFozZdScnZKfqiuqRT7dSbWS32/EjZAWlGLJdbfymKFL3wxQiHMwmE+fvg9dd3knjJ3Bt2WTBPTLR9YKGFgFh9iCgGF/RT4b3FsAcsTahwqi0EaDtcHUeIBrgS6nfRhr7iZXirbTLA+Of25BKRLQNoLhjo3PZPZZilAkwA+4QC+pIcw8KnJ5Cs0vo+c7CLRGyFvL/KriwVwYIqxpDZGNg+aTDealpQiGc2ZxxNtGKsIPwxPE8O2SqOJoKTFMS42aaTbMj2lANAKEQ7njIxw3tcqDrDcpzRkc0bYs7P6fjkYyzjlPrce/bT16LsFQCzibt40ACRXUV2GIHnlSS8ommwTMyRDvhxyC/uD8k7gS3pOE6xoBAdnJsNQs0zCsJHG0C0BYUOqh1KjhqZ+q1g1oRamCVPnaoilgSX13gbvvsVBCxWOJkny3RVD1mmFNEn56KIWt66RbxexGpvLJ80jX0WYNAeCRbzog0EfyL62p9y+hg+DEEMndP2GIUdS0KMYpmFeYA8f8i1BdGymnOtQ+8p417njNWIoS0aQ+38cU0OGqWfLHZYWj661eFJHq0GRInRLwjnyduymhHPmQnQ8G8TYm6an+ONz1HLV06pq+5QYUcjnS8TeSmRhMf9Qqp6wvce392h7BCWO1k0+WDdJQ0NIUUEPyTUs19lfIZ75o0t6hC6UN1jGluSaOZZOhgqetHR0yQpMZGXIpDMwuSqix5yxFgQesf1eiV/iFprlDziIhtKtkN7WLLKOpohLY6RNnDSATFUkoYhiYTPdlsSCD2mMLoPTdowT8wPDR5DlIiYdYIotPQoh05brnCcdYLSpjAy1tUL2OLJg3tATHPApEGLqvQhbo+qcg1Z8FjDyVYxG+aTA0BBc5vUdhqbz4aLpvAy659GY+xZXfZSdZpDPEN5c9TCfPDHP4Eqt6VD5ikRixZFYqnyhRTOMJgsWDZiiHZie5Pm2wPLTVXRgq3gAVsCwtXzQCNNTBXN6Rd031MEBPdQCZ1xvWQcXMikNqRK27PRkly8dNeTzh0KCryenQJk9KIZx4mkubsUk49ikruwGmxYNy41y2vok8pw/oCvzBt9Serk0YqatLiEub5y2pUvkIA6SQFwvMwOTpbVk3ziLTuAyBHcSCP6FQZxdjFSUxhADgyUWu0Y4mstd6crzA+ArFxiEMAjhNSUJ6ZjkgxvCD+H0y4Abk3CLNCGbsC7FmcNlUviJS4GeZuVh9uslf29m+GyziGDK0wktpSqq2FI2SSu2YE1hqG2RS0pZoAaPERk8tM5K5BIunuT4NuDCSQUzUVqJqTI7PVMG9n7Q63ev5xv3mKVe0oujBvHHPoDHJjQpWXOWWVOtSTo1iRUHUYues/Z40XzEhGvjVWLK5zLiYo/nfMDQ5yl/MB4JZy96By8Y8PDIIDj5Eft8AM/9YZ87iUeMJaq0sIo/fwXqXkGdevPzaBVPEVbBTy+ZcOXzNRUzjO1+wvsX5ZZ4Q58gt2RNNbkZJDejllsZue1wuQ35U/Do3bxp6e1EMpLtc1Zgn2oSdUmibi3RMhLdjnoizAWALZP0a/zEPEFYd5ZTV01yJknOrCVXpS+Gb9v4gPYRx0voi/J9zgrscyN21bRapGVEGttWLubPxAsNfR7iD7efZWyvJi6LxGXV0qoirQEakV7iOVI+j26E288ytleTVpOk1aylVUVaPUQkftFDKJV4+1nG9mrSskladi2tMtJ6wqW1z58p8xH5LWmcPOHyke1xtnSParJskSxbtSzLyPIhl2UbJ1MvoylWP3qiw0XU68St1eTkkZy8Wk5l5LQVOXfQV2iBtOiQxzWiQx7XVJPZhGQ2qWVWZVR7qdAzrcVRLd5+lrG9mrSmJK1pLa0qzvYgnueKbPztyDpM1p3l1FWTnE+S81MNexypETydu4uieIPTcOF8e6g2Yv3ZkvpqjdR4pBfKrpZ8o0JXT30zUt/M1LcRPgk9OMAAdhU1fZZQ009sryGm6r/CbANK0oiV1ZBqSEtVx3pSQ+Ah7ZGa5Wmgh+ojaPJtXWQFal4J4OcCwAlow21ZEP8cN2Ks6q6bdf8Tn1WnK1vikbkwr/hCdwV1qMv7mC2D82iY+nGA+YLwLvgY6IasbbpqeOm2qT/rdlirjVtNbZyuNSNwtKnps2+p2kZY2XCnnqqlK5tW9ok1sUWi+O5f8+9KKba4UnTwVTcfkbBjNTBlrWk1zYYmdAIj6gTjie0JQNlRbcPTp1pDeiNTfzL2JouivJsm3JU4viazqBJAOwl9HSOFXeGiV3GkkDKAqho2tF/OAKqqt9xmFgOwEbYhHtvIO7SZc6gmtqgQgW108+9KIZ5yhSDLLBrLlhkPsUqLLUuM6PAmlZxmywR3Wxe5a3ghxeYDptheKad8yf7vy0lJb6mu1cogk6Z07L7Bee6atSOujvl7GUAhpea1qghAxc5zVwBtc4AST2JmdUvYml5ylEV3tmqrIqHFdNdoiHAk6A4ObPpZdEcXzlI19q8gW2908+9aEYitFzk6Q7ez28M934J9pMh57toSd/A9DNeCJS5VsZbRYg3PUjFTh98sFRtbY2OsZahY+HYxuYpNpvArBQHU2i7qkG108+9KDR5FavCRZ0bB63XeLSfLRRNDT1YukE3cYN3NsQxF44T5UkmqyfQU5GPXPWv7KoK/+73u9Tzxot8nKNbXyhEmNUMgJnrpeTQvNo3W57jK1cLrfJ+HK8Tw8UkwS3aFAddLnkbnRa+z/TfhVb03eRFw8uXsYaLQBY3n0auBm4olHBO+9BgW6eOyVHyp7ltlktHCJ/jkmN/R0gzfWPYej7uMjjBSRzzGJxteMlc5a3/xCvFTEeWo/Q1fKS0i5yDm0CmPMU3xij9CeIZMHV5LE46iBUEpKcednh/1UPkvfDUyvQ49fd0dXG3+J3doQC8mC8dvsePVxK+h+MIdH6JZmn8GP/ErnuEpBg3H+FLkS6aXYNpOl7ZDvJflL4puYm0DXwoNL4CG16nDlfToRdEavo/Uw5d30zUs3LPJ/mqsBr4FqatuJZAfKZ9BghmasZ3Y8yWui7tS3mS+9no7oUeRziY0yBD6wlZCg/Lb8Qjl9Za7EjJtSchKONLB5ZAT1BnZkVmy2cYj4ahTJuf/IRlFr2f3MdJyKTDCI4bXJ5yNAjYgLrrKvKutiLVEbMU9b+fV3o8SjLub4Nwg9Rr25ey8xdn5N5T+b+wav9cMXTN0zdBfNEMbNUPfG4beXmRoRa85uubomqO/aI42a46+NxwdxjiGuBKitqBrdq7Z+ctmZ6tm53vDzmGMY8juHa4HUq8ZumbomqG/ZIZu1Ax9bxj6B87QDjt3+BAv2h8zBxR6hWPN2TVn15z9JXO2XnP2veHs0KpOcHbN0DVD1wz9RTO0VjP0hjG0pN/WmXc1O9fsvEZ21jaEnevMu3Wwc9wXb8LOdeZdzdA1Q39tDF1n3t0fhq4z72qOrjn66+PoOvPu/nB0nXlXs3PNzl8TO9eZd/eHnevMu5qha4b+2hi6zry7PwxdZ97VnF1zds3Zdebd/eHsOvOuZuiaob82hq4z7zaNobtsL5BVAs/oOcPE0PGDz1+n9hLZ+iacu7zHuEzzW4rJfifsfPZKeky+Fom93BXsi53U0VnjUlOifeExy/Jjk/vSg1lj/hXnd5L7LvZSgyFgrUX3Qn3aTelKWd0LZ0T4SPfV6VpDiD8U0TVgbv2WtM2+x9q2w7UtObKL1uj3XN8gZsDYv84zvrEtqgtXqG3R9diiWmm2W7ctagi8k22LilpUZxnfL0v0ccynjKET2nwDhh6yK8wQl5qha4a+jwy9+dECkXVrhv5SGfpJzKfKJJejn6ZQ3EVuoFcVvk34bdupVX9h3f1h6oagn8tZ1KzIbNXZQMe3rNmsbzN/j/Uo6Pk6+1UjNoBtsA9IK7yKjfzho08LnCCyQbYemmvQQ7neVNHAx6kz3V28yuJM7CMHA1M32a/J9q8upbLxKksYM+t4ldxClWlLFd17iizxFntQ6mzKz/C7oIH/yTSnzVrt4z0Ra7xmrb9A5gAL6k/2/Sq6Y9DN/43a/gA1aRf+ltTNsdJi+uGxv2AXTNGeMNHWCnUTYl6gmT7yCmkT7A1MAxo9YfundfN7ZVIwKvVAcQV5f8POZgn7eEtsMZE3b0c/lkk0rSWPmSZPmJ3wCXHYTfTQ8EVCezg6fGB1/Wh0uFyTXjxj+32APom242vO96+ZJMKXDcv79XPhuDfcwls88m9MOyxBkuJV46PHCr1qLPvY5ZoMLGmyeh+tXw1ZVmNnNhcsY5trsotsDDw8Yf/BK2gJmryTgdMFa/c40y7JusvkUbJ7fMzaMUV9KXalJ4n9i18l+56mmT5n3j3FRxW/p+wrZd1T/lV2JFdZpstPpVcqosciGuEV01qcd2fFjtiRtnB5X9liewJzvWN/RQ3ScvdMykUcSZJ7LmIrzion9xbvUlsDW2fxazmW/olx70XkxXJ7X/mH6DNkjOnP2V0tHv0a2wn68z7yNkTJ35U1YDA2BBYco/1J9mmLaZiWslShHjRTRYsBOLSF0YgJWgVidOEpjt9JtIogcDtaUU6e5XRlO/G6wF3e7rcr9TQeZMY6ZN7jQ4bTR4xDAWqfE5GX8n7mBGVrosXjoXfpYkSpJXgwoCtuKuqEkTKcO51Kok5htA20YZLJg7flZ8rkVU7mW2wLjAPXqEmbZdmn+/I06svGDfry45j58R4+KDPsN5fBwYCBdjAYXc/P+x14DeMrKoJ4m25ZtBU+BMJ4gaPUys8JkaxVnvNROJat9Ky3o98y3Syn3c+VQ7zXfzBvByKXn/DKoKnAlllj3qVk3yKM/wx9q/s6Vk6i/qXfqH+9wTjy69jnFVorjzRvs+NIK+9qZC2iK+W077vkqo2NYdUJ2tsmxltb3MsEaTYkXmYYLVnmZd6ORNL4lR3XEjbzWse1Lz8yoUeRCauOTNSRiToy8ZVFJmTcmmbnB+zssG5xGvHxM+6hhmsYd3lkY4+d4yNEojdmfIRR0WB/wb5xkes8Vpo4i5DkOgtnt4rlJ9yOHJZjukwq29ii93y2nLJ41hXBXy4JH3NAVJSHj6j7OG8TzzqqKAnwzIuOOrflictwTKP/bTSLSNjH3zcHb43V+ci8ZjT/EHre1Ub528E7xi4f463wO8PjGM++mGm3GWjrG4y2DMV83J8pB+wMn9ADnuEM6W50jnXa4v+OY2WyHeGIeYFjsovzvJ+iDJgfGLo/I+Nk/4rPUihnO6uR7WxsnJyXSy1f6jt4/6HHfFcSf5doQ1La2TP6oh+WdYbFmf5W6Ti0xaRpo53QYGdu4Jjmc+/bxP7vY2xaw5wGC3MbIFsSLEIb93AVMQ59O9qQL81lmjDkfQtiPXejCT9E/RvakJajGGH6hkklLckfM4/+Fytd5W1qTuIb6LmleQH438DsIOJ/Ha9ooybAjJWFmgC930ddmKAlZCJT+MgM3po0IU+a+ZrwWPlNgRXx7+5IC56xfej6ZTXgufTIVUm/xdfjQc9vRHFWHUd/WKs3Rh4ApmjgrNUYOcDHeSwdI7Pgb6xD+tkSTEv+Ic8ousD85/fR2sf01k2xvjwca8GbgAxU8i0o43zRt2je6agsIlgE9cfprRto/WqYjedjhIWi0C3sD80FqyjMKL0r/LOxLCKJp+yM73FFDNXsRjnY62TBn5Dr4la8xujRJa6Cvyq4aufHnHOswpLOO7+Mr63SnJv2uMwN9riWaY0Y1znBmVyYUwv7/x6OFLtxTYa+PUPJwRzz+2jPYnj/KD3yEy/FjNeseb+74p8pShUy2mGs9TDKp6K19XesGfN8EIPdt4Y2O61KgFF3imM3WGXr4Z8sWaa14Dulg4h/YvteRjOQyW2bwv0++sIm53WPWzytRJ4rZWyrDOuiGdu3NQOZxC99l15Us6jtkNUUspwhrGXcwn78OecoH+OcrQLyfY4rH+gOLnB0Am7b3UipT9C6baKN1UKpN9CbaaWkPkZ/t5WSOvz3cd/1eL5FUL1bXfgB48yfeato/cZn9tnkuEHG6D7XkeRKMbDgaX3nZmV6gew1lLzNczV9XD00TlnjDZxzMTAKAn/pu4n6tC7dyEOzuoy2cHy/oAzKL0w2E9y2njj1IorVZfJUiH+NsBXQ3i9NPtaaRtNliKZl9SPOY864z+Ww9sz4J1iR7+J8Zyyt7+N5t3spnyaTShMjgU2MCMLfBo6VFlpH65DPIoZpiTxC7KeYjw22fJhxHK40GKAHeYWcCJ8+ooRmyJa7qWsvWiU3ySr/FsdrL+GriDH95VICL3CKHo2P8/cQj5jiEaGUXLRJm9hnVJ4bp3MLtsVqII63DimVw1mMUdCzSdIrPcOnl55gG8DrXsz6vz+r3Is8j0QTjlj2PBKI8JZbS7+4UrR+Jkn9TJJQWun14/Xbae/qqSTrWJX/bcYTIORcHD4r8hDv/MONeNheMw+LOZmbwMOijGsWrlm4ZuHNYuF1PJMnxcLBYG90PW93+rO576v4E/ToG/0E7UHE01s4P/CaWd0UCZxFHs9/sBrgatDKAdv+F48K7SE/zthW8mBdjNlPgjM+NyPuHz4XeNg9Hc/VoL13MsPCmc2NqR20u0ezuRa0j49ZA1nBNrtB29nHnZwe1jmHWLT7uLH9KxadE36C/R5+H45wp16biiFuPKGNzmA2bzWC9qiNW0d09pFDFzmm81FxtDdmR5xAq9Sge6rN5jYrdDhN99TAosc26qzQqTCgCHoxpt/jLNzr+HkkkSfiL3giZ5k1HK8etblHd9mDxursG95Xb9jFXYZDqjuk4hyKYHTevp7ThR8w9aBgxPvg2Pn1ev5ywPax1eCQlyPnN3Y+piejI3YXo6PubN70J6avgjqNznurOVGwfz64nveOR3ALnf4QikEf72Swx3ZnX1A3BlAFJxmM+PdTkMneoE+FAze9t9fBb3tdLBx2minbswsHHMBJ1eCXwT9ncwtKh76eUjGA4w96R1D84sA+Liv36esITveL00Zg+wNE9AQad+D0YVvfOYOiS0XfQQl0nGM4bL/jwM2cvHLgW9/Bb4cjVKzDEQUZumgsQOf9E0tMbw/Oe7jv+TG2fzTE07EjoTjvokru987ZCZTg5Ni8nrM/s3kjwMKnQqNCFQpW9mB/pj5WgAUbxvdPOlCO9rBHjQYvoTiHhmpBp32G1+m0Uas67T3c2t3Db93j63m/N/Ln6s9WMDod0IfhEd/SPuUfgs45Qhgcn7DLH5908ZzB4ODkEiZ7BoqLxtMuMyqOjlEgg6M+FbDrf7NhDx6bNsbAAwWRDBwAbT6h1sDghYtBCw/Ty8aYaqHjI2Vc/NUZ+fYd1uKg/4qJsL/3ivHirwdwmbMhSZObpX2292eFHi3FJNdHXI5J4scd1LvuEUq104d+vg+n6/wK1ft9doGj44Now/lpD5cYU5FecIz9RTOpv7AS+4ud7i7GtAEj32iPtRt+XhwxBF/Q1YNg4SY0fhNbbCSZspvfjW8mdSMa3YiafyML1wsOusxGP+geQhfovoA9Th2kpFMHVSL4P0scv+djnmRRAAAAvm1rQlN4nF1Oyw6CMBDszd/wEwCD4BHKw4atGqgRvIGxCVdNmpjN/rstIAfnMpOZnc3IKjVY1HxEn1rgGj3qZrqJTGMQ7ukolEY/CqjOG42Om+toD9LStvQCgg4MQtIZTKtysPG1Bkdwkm9kGwasZx/2ZC+2ZT7JZgo52BLPXZNXzshBGhSyXI32XEybZvpbeGntbM+joxP9g1RzHzH2SAn7UYlsxEgfgtinRYfR0P90H+z2qw7jkChTiUFa8AWnpl9ZIO0EWAAAANlta0JU+s7K/gB/Pm8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHic7dmxDQAxDAMx77+0v8sCnyY4CuAEV2pnZi+a3eUdN9vr/x792/RvO+3+Tv8n6d+mf5v+bfq36d+mf5v+bfq36d+mf5v+bfq36d/m/23THwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuO0DROnLo9UOpq8AAAq1bWtCVPrOyv4Af1e6AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4nO2djZHbOAxGU0gaSSEpJI2kkBSSRlJIbpCbd/PuC0jJWa8d23gzntXqh6QIEqIAkPr5cxiGYRiGYRiGYRiGYXhJvn///tvvx48f/x27J1WOe5fh2fnw4cNvv69fv/6q99q+Z/1XOaoMw/uBvM/i9vCW/rm7to7Vbyd/rkdXDXs+fvzY1tVK/u7/bH/69OnX32/fvv388uXLf/qi9he1r/IpKi/O5RjnkU79XK7az7Hab/mTdp1baVpf1bFhz0rOnf4vOvl//vz51zb1T/8tuZQMkDkyYj/nVP7IFJnX/mwX9GvOJT+3E9oC5Rv27ORfMvL4r+jkzzHkQn+1DJFztRX3WeTHNeA+vjqGPgDKYz0x7NnJ/6z+T/l37wzoeeRef6stINfatiz9zFjJ33oA6PuVnnXD0HNN+SPXklVd6z5IX/eYwHn4WZLHdroh24n1jOVfbcRpDP9SdeL+c7QfXc1YnG0fp19n+ylZWd4pD/pt5l3XeSyXsqxt2iB6hjHJ6pphGIZhGIZheEUYx9+TR7DXp//zby/vWfLd+h5c6mu6NvWueITL6O1qB8/mZ0id8Jb2vruW9/Od/M/Y8Y98hnme93W+xC69lfz/hv7zFlz+9LNhz8Omjk0m/Xfp28MX5GvpI53PkPokP85d+QNN52+kjFyP/ci+LNsv7d/apZfytx/iUdtAyt9+Nh9zPyl9ic4suSAbbL7s55z0C9hnWCAj7HYF51HntA+T9me3HdoM90KemRby7uzZmV7K33X0qOOBrv8DdWi94L5tP459e12M0C5+yH3Qdl/3/0o763jnb8xnSvbr9Fldkt6z639AtukDLuyrKZnhb3F/Q5b8v5M/fd8+QMf7WJ/Azt+Y8ict/ADk08n/KL1XkT/P9vqbsrG8i/TF2xfn+t7pBvSJ2wm6xboYdv7GlL/P6+RPnMqZ9FL+nNf5w/527FtLP1tBfaU/Lf139u3ltdRt0dWR/X08R8hj5UuElb8xfYi8p3Xl8XjmTHreph4eVf7DMAzDMAzDUGNb7Jv8PD6/Z1w99oAZY78ftn3xs02+iwu9FX/D/MNnZ2fT6vzg1gnoDseE59zA9C1CXuvza19nP8zyoK9GP5yjs6sg/5Xd13YwfHzYjtAb2H89x6dIv1DG7ttn53Pst+Mvx2gf2JHxSQ3HdP3cfhfXe5Hy5/puXqd9gbbvWub4D7p5RJ7rl/PP7LfzNeiI6f/nWMl/pf9XdvD0padPHRsp7SL7sWMwzhzLdlngk9jFCwz/51ry73x+4LlfJS/PBSzO9H9wXIDLybl5zrDnWvIv0MnpOy94hhfW4c5z9fxf6Qa3OT//HatQzNyvNd27XO1bveN5fN7ZAhjD5/XEjTid1M/d+J9nAOT7v8vKsUx75D8MwzAMwzAM5xhf4GszvsDnhj60kuP4Ap8b29zGF/h65BqryfgCX4Od/McX+PxcU/7jC3w8rin/YnyBj8XK5ze+wGEYhmEYhmF4bi61lXTrhhxhfxI/bMT3XkPjld8RdmutrNi9I67g/dx+ZfuQ7in/tDM8M17XB9sbtrnCa/CsZGz5Y3/BJrdqSyubnOVvfyJl8vo8LuPKnmCbwepeKDN6zPLP9uh1Cp/BpmzbKza7+t92tO6bPJmG1xDDr4cNvms3Xf8vbNNjG1tg/U/a9vnQbn291+fymoSr7wuRR8rf646xBprXxHp0kBG4Xnbf5DIpfz87V23GcvU1nfwdb+Rj9h+zn/5Jeuw/+r6Yj5FP7vd6ePeMe7km2Mch+4VluXou/qn8u/2d/NMX1MUi0a/R7aR/9A253TH8FNbz5MHxR2fX/+17K9KPA7eSf9cebPt3PAH9PX1H3b3s2kbGqJBe+ikf9Z2Btux6SR1w5Ee/lfwLr+NL7ACs1pzOe8172cnfZcjvC/uaR5V/kTEy6cfbra/Pca+nmWl1bWYXl5M+vy6/1f7dfayuzevynK5+nmHsPwzDMAzDMAywmlt1tL+bK/A3+FN2cazD7+zm1q32ec6F5wodvT/egpF/j30YtqHlnBpY+ed37cW2kdp2zD/f5bDfqfD3RPD/gY/5WtuT8C1xL5Y/37PxPb/qPBHLzH62jJuHI/3f2eat/9nmuz6209lGa/+M2yJx/vh6sAFyrb9R6G8JOcbEcqYs+IjuraduzVlbOxztp2/mOgEpf0APuC1g16ct2DeL/Ch7zhux36+bU9Ltp936u0CvwrXl3/WfS+TvOR/o7vzWoL/JuJN/Pg86n27BM+kV5wpfW/9fKn/rbXSwY23sw0M+5HGk/1P+tI1Mk/gQxwg8sj/nEjxuoo/Rr24h/8I+Pffn3TzyvDbHfzv548er9HP89+j+3GEYhmEYhmEYhnvgeMuMmVzFf96K3fvqcB1457Y/MNeLvBcj/zWe3+D4eubH0Y+Zg2O/XaazsqF4Dl766myH8ryglQ/QxygT12b5sf86fh+fpsvT2aNeAWygaQ/Fbuc1Gjmvs6kXnlfHz363XDsU2z92/m6Ol+279ueSNmXMcqXf0f2/81ViU352+af+o16591UMTzdPKOl8Oyv5U8/pR/T8NHw/2GbtH7T/0Pe2Kj/Hco6X91d+zzLPb8VO/pbZn8p/pf9T/jn/135kjmGr55jn8u7Wh9zJ320USIs29uxtwFj/W//dSv6F/ZB+znMu4xLaA3mc0f+QbYM02bZP3O3vFXxCHv+tZPye8vf4L+f42QeY/sFiNf7byb/Ief7d+O9V5D8MwzAMwzAMwzAMwzAMwzAMwzAMwzC8LsRQFpd+DwQf/irWzjFAR1zin7/k3EvK8N4Q33JLWP+YtXMyf+KxKN+l8ue6jkrr7LcWujiUjownPuKSWEDilrwOzlGs+1H9GmKj4Npx9I6d8nd4iQvsYvcpk7/r7rhfykt8lY+Rds4XIN7cMeeO1U28NhBrCGWfZS0yx5vv+jX5nzmX8x0/S16ORbqkfok58s+xUe+xrlmu10a5OJbrfxEPTj/lfjs6PUo8l+/b3/6hLex0APG6xJJ5TkHeG8fpZ7v+Q/6OCVzh+0794ljKS+qXcykn6V5L/2dcfuLnMn2bNu191LO/t+HvKbke3G5dT7v7ct4dXhvM97Nqh36GIrfuex9w5rni+TI5d4A2lBzVL9AuHJ96LXbtOvsr/cf/o/OyTXveV5ce/Y/7Slm5r1r3rcrqtaJgJbeMDe3SpGw5j4W8EueV7Z62mRzVr88jT89VeivowVX/Pzvu/RP5c47n3GSafh528eBOt5uHRJ3nNyouWeerGyt2OtN5ZTv0+DjLfaZ+6f/dfIW3sivDkd6FTv45f6Pg3cB9lXtCxp4jdAav6ZjXeO6Q49Wtc49Yyb9rr4xTrB9W7Zv8L9Xnu3VKPW/qDEf9v/A8i9W7TCf/o7LzTKzyOg/kRF2yNtxqrGadmfJnTJjrBHqdL68r2L1be46Z3x26cvDdQ/RNrlnXcaZ+4ehbuxx7j3mLvKOu8s15GgljBch6Qb+n3vS79JHeO9Pud++Eq7GAxzmXrBN6yXN6V7+U+0iunPPs81aHYXgz/wCggvog4L8lowAADtdta0JU+s7K/gB/koEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHic7Z2NkRwpDIUdiBNxIA7EiTgQB+JEHMhe6eo+17tnSUDPz/5Yr2pqZ7tpEBII0IOel5fBYDAYDAaDwWAwGAwGg8HgP/z69evl58+ff3ziOveq5+JzpawAZfj3wf9R6fmK/jN8//795dOnT3984jr3Mnz58uXfzy6+ffv2O++wN2UE9PtHRtT7tJ6Vnk/1vwI20f6u9l/1Ufp2laaT1+3f+Z1dVPKs5ARdGr1epcuuZ+28ez5wauereuvsH+Vr33W5tG97HpoPeQWq/q95ZfWO+58/f/73e+gt0v348eP3vXiGuqgvC0Q6vR7pM0T+nibyiLy5F2WrXkgX1/V56qBpIy9PRx30evyNz6r/x9+vX7/+fu4KOvtzTWXR8iNNlM8zWZ8jPfcy+7sMUZ7bCJvH39CZponvjFtccz1FGp3zOLR9RT6kRxfIqelU7vigC9qyyh3XVB+qZy2f8X3X/vrMFaz8f1Zm1v/pf528gcz+6m+oU1Z37Bx6Vn3RLuKDL9A+qH6BPFZydrpAPsohP/cVVZ39+ZDPy98Z/+8xF7jF/ug8+iP17uSl/pX9fR3iwLbYPf5GWyB//vd+hqz0UdqLQvOhTpku8LcuK+2RuV5lf2TU5738TG8rW1zFLfanHWu77+QNZPZXf4fvzfoofd39j+o27nHd/SS+I7M/etA2lulC06nNaRfI7/bHP/JM/OUZzTeuIeMz7E9fUX3QnwF19e/qbxnfHJoemelb+j2epQ90a6XIi/v4TcD/kcbvISd9LwP1xodkutByMvnJX8dD+of/77Ko/DqXqfTpuh0MBoPBYDAYDDo495fdf83yb8E9uIQrOC3zNH3F257CY+XEpVjPZHGBe2JV/urZFZ/WcZiPwqnOrui44m3vIavGtqtnKs6q8h9VXHq3/Fv5tEdB5dY9E16nK3J18fx7tetMVuXV/P4J51WlPyn/Vj6t0pPzhs4p+h4F53iQhXycA1nprNKBxhW7Zx5pf/TjnFzFeWncXmPmVfrT8m/h0yo9EaMLwLPC8yHzyv7E7VQWlbPTWaUDtT9yZvJn/v/KHpoT+1ecl3PWyr1WHNlu+dT1Kp9W2R/uWPkj5RQ9/8xGyNz9f6oDz6uSf5crW6Eaq+BG9H7FeQVIq1xMl363/Fv5tM5P0oejjGgP9DWe3bW/jhme9lQHp/a/Fepv4BqUd698U2YXrvvcwdOflH8rn9bpKbO3zjsZF7TszEYB5RaztDs6eA3769jJx/fiKS+IT1POC3my61X6k/Jv4dMy3s5lA8opVmUzJ3eulOeRZ0dnmY4970r+rl6DwWAwGAwGg8EKxL6I+ZyCdSBrmFUsqksTc9sd/uce2JE1gG4eWeauLPcG52JYd3sMfwXiH6y/d9Ym3fr1mfsZM65R15SB+E6s8FFldtcfCY9dB6ivxre69q9nY0iv+sue5xnuab2d94p77pf0zEGmM57p9El/8ziGx2iz8nfyymTM0nXXd8vI9LiDVRxJ9+RX53GUg/A4re7V1+dJoz4HnSuXo/FA5eyUD3CZ9BxRxZ/h88hHY/5al6r8nfJcxqrM6vqOvMQbVcYTrOzfnbcEXczS+S/4Ou3/6MrPM2TnO8mrOmdCOchSnY3I9O98R1d+lZfu13cZqzKr6zvyZno8QcePkd+KZ+zsX+l/52wR+fqnyxd50P2Oz9L+nsXis/I9r52zhFWZ1fUdeTM9niAb/5Vb9DZf7fu52v8zXVX9X8vu7O8c9Kr/a95d/6/mf13/17KrMqvrO/Leav+Aji0+huGfdHzp+CuXaTX+q9xu/4Ce4avOn2e6Ws1ZfDz1MU55xax8RTf+a/qqzOr6jrz3sD/1rtb/ei9rm9zXPuQ8ms//PY3OkX1On83luxiBzoX5ngEZ/D7ldeVXea1krMqsrq/SZHocDAaDwWAwGAwq6NxcP1c4wEejksvXHx8Bz+ICWbv7HszVOoL90s9EFWer9mO+ZzyLC8z2MiuyuIDu2dX9/yfrV7UVsTa9nnFu2J97ngdy6HXnIne4PNJUa/TOLpke9FygcqSVvm7lG0/g++/VPlXsj5gTfmOHI1Q/o/Erruueefbve7xR+cIsjyxenXFGHS9Yxft2OLou1qlnE+HXM33tyLjiAk9Q+X/sjwx+biXjaFUH3kc0Dqfn+Chf+4VzbnxXfVRnJnheY+v0kyxG7f2Ftsf5FbDD0a24DvKr9LUr44oLPMHK/yMrfS/jVXc4Qs5SaF/Pyu/k0Xy7MzMhD22Wclw3VTmMberfKHvF0Z1wnZm+dmXc5QJ30Olb+6z6eK/rDkeo77XM+r+O313/37E/Zzv1LOdu39K9A9pvdzi6Xa6z0teV/q/P32J/9//I7uM/+sdPVum8Pfm4Wtlf887G/x37oyO/dmX8P+HodrnOTl9Xxv+ds44VqvW/ct5ZTIDr2m87jhD5sJ/OMbNnsjlwVl6VR7V+PplbX+HodrhOT7dT9x0ZnxUzGAwGg8FgMBi8f8Dn6NrvUbiSt75b4x7vvtfYwAl2ZX9PXBRrXjgA1pSPqAN2PAHrWmJ6uq+y2wdcAY7hFBpP7HCljq8FYha+biR+FvB9rL4Ox2/oepUzGPHRmA1tS+ML6KvjdlXGzv5dXrtptE66D97luFcdQfa7I7T3eI7rlKvpApHmat/KdMT17BwLcQuNszoHo7/PRT3QDXol1oXfcfkpQ2Px1VkBtUXF0e2kcZm0rsp5Ukf9LaErdQwoD0tcD/torFDTESel3Cpe2KGyv16v7K/xcdo9bRI9eXxL8/L4dsWrZfyJ21z9mHLIip00AbWfxx89jpvxe1fquPrdMdL7+wSdOz3dt+XyeBza6xNw+ztvQD76m5TImOkGVFzUjv0rHkOxkwY9Ku+Zyat8mL9H8EodT7hDyuUDV135lhV4jjEus5nvtaAPOV9Fn9CxqeINvf1W/XHH/gH1f8rjKXbSKOeo46DKkX3P7L9bR+UE8fkdd6icn+7HugId2/Tjey3ig2/0vRzcUx1k15Vfy57vzteDyv74MuXUHTtpVCafdyrfznf6h7eZkzoG1Aa6p8fHZ9ettpNT/k+h4wdzzOzeao/d6rrvJVqNW35fy69k6daut6TxsiudnNbx9LnMd13Z/zcYDAaDwWAw+Lug6xhdz9xrHtntSYx1kL4rZadMXasS787Wgu8Bb0Fej+ew7js9R1Khsz+cAOl27K+xFtY7PPcW9HmCtyBvFo8kTu4xG+e0iD0636VQ7lbjFQGedZ+jPLTHIDwmq/y/6jNLq3kTQ6m4GC8X+TSWoxxyxylpPbX+Ki98zo5ekF3LUblO0J0xcY5HuQiNpXc+w7l75ZXhCzxGqvXz843OwVb+n3KyMr1u2d5sb//Yjdinx3yxbbZvm7YCJ+JxYuyt7aLTi8vucp1gZX/s6mVmsf8Vj+g2CjAHqGx6kp9zQd5fsryrGLDuD9J4N7HW7LejKu5VfY3urVKuJfMZK724v0OuE6z8v9tf5wm32p9+SVz9UfbXfrFrf/wGeanPI1+3/2pvB35EeVXlD8CuXqr6nmA1/6OecIy6B+UW+2u57odvtT86pBzVy679yUPHDrW57nfZyQd/rvyfy+s+P9NLds/lOkG2/vN9RTq3yM5fq24cK3vR/nX/wz3sr/O/6txyoLOb93HNk77Ms10+Pv/LZNF9GCu9+PzP5Rp8TLyF9eLg9TD2/7sx/P5gMBgM7oVs/beKZYC39K75jmc6ha7XuvG2ip2eYFfX9ywzy0/jP6u9kQFdl74FXDn7UIH41+5+zVuwo2tP/wj7V/lp7EdjFX7GKeMIHcQtPJ4Od6a8Lv2PM3HMfZUP455/J3aqdfB3JFaxkqxuGpPRduHyKLJysrrC/7iuNY7vMqm9iFM7V7iLyv9rjF/PS9HPlPOtOEIvB93BnWj56EXP1aAflyeLOep3P39LO9J4OvJ4G/C6BTyW7HxAtg/bY7PEz72uFYen+Vb64HnixhUHu2N/9/9A25aOUx53zThCBxyV8nGuw+7/XfujFz2P6TIH9GyPQtNlNlZ9Zfb3uYieravyUv0ot9jpw8vh3glW/t9lyvZaVByh64Q03fsf72F/ZKKtZTIH3pL9K27xWfbP5n/4QvWXuo8Cn1RxhK5T/H/X/wO7/g7flOk8m8Pv+H+tWybPPfx/Zv+OW3yG//cP9fdzsHruUOcpGUfo5ejZwap9e1rXhc4zq7OZbjfFav4XcPtX87/Od2bldPbvuEW/d8/531vHvdc7g/eFsf9gbD8YDAaDwWAwGAwGg8FgMBgMBoPBYPD34RF70dn79JHBfhP/rPa9s8fS32kRYG9M9nmEPnVvqcPfaVxxiexL83x9/wjvANIP+zeeyVN2dTnNR/ft8ansr79jwr4j9tnpPrcsz2pv8K3yd3v11Yb6HhCH1hvdsodM+wT5PattV+jq8sgydV+k9o2s/zjYr5bl6Z9qb54/u9obsmt/3stE+vjf37Gh9n9tvIb9/XcH1D70ww7sI66gfanbyxbX9bdFOqzsT9uhTzs8/6z/c538eZeb7qHUfZsB2pu+a4l9fvqM7rHVfLVNkobvJzgZQ1QX/q6hrG8rqFtXnvqCzPaMvfiGVZnkqe/vUZn1/XIn9ve97lznf60n55J0nFRZuM939IrMei5E86U9qNxXfNPJfnE9X6G+AHmqvk273PHn2dkBzcf3lq/kx49r/gF0p+9iUz0y5vt8pdKxz3m0TtpffU+v7mXX+ZTmkb3bj/bg/fB0TOCcUzafcWBD/+3Mahxm/bQzliPL6dywsz961TEL/+ntSO2v/l33mpPnif31XCLtV8vM3l3l86zK/vxPO74yJ0C+7ONAfnRHG878Orqr/Krne+XddYHK/uo3AW0xixXomVFd31BXnR9W5xsy+1OujuV6Xc+lep/Scx+d/ZHJ29cz0MVdducWke6q3N14d9Ke9N062pc+2nmKwWDwofEPiCRqout3vRYAAAR5bWtCVPrOyv4Af6I2AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4nO2aiW3rMBAFXUgaSSEpJI2kkBSSRlKIPzb4YzxsSNmxZPiaBwx0kOKxy0Mitd8rpZRSSimllFJK/df39/f+6+trSoXfg7Iel0z7EulfU1Wf3W435fPzc//6+vpzfst1px5V1i1Vvn95eTnYY+v0r630//v7+y9Kdax6P6P/afvP4P+ZPj4+ftoAcwFto64rjHbBdYXVkfgVzr1ZmnXMOLO0+rN1ThnSP6RXUD7KMUpzpIpXaVb/5/yR/V91S/BFH/+Jz7iIL3KczPmjwohf4ppnS5VXXdexnpnNRVke8mNsyvMsW6afVJxZG0i7VL7P4P8Otpv5/+3t7fCOiH14pvfHTCN9QZsgvNLinPZH/J5WHcs3vJeRXvd9PpNp0p66si3nHPjo/p9p5v/sO32eTEr4sOxY7SbHVMpQ9zP9VN4jr/TfqB1n/67wSh8f1vlsDiAeZeT9J+89itb4P4XNmG/p5/lugO2xYfbr7Jv0vXw3GI0V+T6a/T/HkPRVliXLO6vvEo+irfyPL/Ft9rWeTn8v6ONJjrXZ92bzUdaD/Hp7yPE802TM6TbpZJlu+Tvor9rK/6WyUb4Dlm37e3v3Ne0k/cD7BGnRpnjmFP9nPMYk8iLNXr4lPer8r5RSSimlnlOX2ufNdO9lL/nWlOsgl7BhfRvNvmv699RftfZ5tT+sOdSayWzNeo3S/31tI7/zR9/8S2shrJv082soyznqR/zjMbu/lN7oepbXLK1RvybubM1pVua/iv2y3PsjX9Y88pz2wjO5zp5tJPdeOWcNl3s5JrB3sya82zrLmeuJdY/1Ztaa+rpShfc61r1MK21Xx/QZkFdeox6nxHol90mXve6lMp+j7pdsb6P+z1obtmY/vms09le83Mct6COs860JP1Yv7JdjXv+3IfchEHsZdcy1yrRVptnzGtm3/xNBnNH9kf9HZT5Hff4/xf8Zf/b+kHbinL0Zjvgz/8lYE35qvfqcl3sC+HpUp/RBt09ez/LKsNE+E/ezP3OdeY/KfK628H/fRymfUKY8LzHWMX4yltGe14afUi/CGDf4jwAb074Qc233fx9zco/ymP/5fyLzKPX73f+zMp+rY/7PuR079H6SdS318Sl9g7+Iyzy2Vfgxu2cYtuT9OudhxnDiYue0NXud+DP3KI+Vg39r8SFtJ23KntnI/6Myn/MuyH5b1il9R9/OumKP0VhF3Eyv59f92fvBmnDCluqVYdSDuaT7N+fy0TcYz/fnRnn1MNpA34tMGxM/856Vufe1S2hpvUA9vvS/UkoppZRSSimllFJKXU07EREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREZE75B+Hl45q2TuOnAAAAVNta0JU+s7K/gB/pYUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHic7dbhaYNgFIZRB3ERB3EQF3EQB3ERB7G8gQu3piH/ignngUObT/vrTWzOU5IkSZIkSZIkSZIkSZIkSZIkSR/RcRznvu9P5znLtXf3v7pP929d13Mcx3OapsfP7Bj9LPfUvXUWy7I8XscwDH++h3TvsmOVfbNhdq3N+z21f9U3v/6N7l+263tWOeuf5XqdffvG2b+6XtP9y3O+71//1+d5fto/1+z/fWXbeu7X79u2/frM9+e//b+v+h7X96v3QK7Vd/ucRdWfHddrkiRJkiRJkiRJ+vcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4QD8K+ay4UtoqZgAAKhdta0JU+s7K/gB/1PAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHic7X0ruOwo1vaSSCwSicQikUgkFhmJxCIjkVgkEhmJjYyMjI0smX9R+5zunp7p+dT/1Ihac+k+VXvXCbAu77suVObnfTaeANqzkS3G10Zgh6PDAnBdxQVrAN+FfsPzYh3ggQoQAbYKG9CeJMF33ZPZsYTB8c18c/zxQ28AlZvdQSvVcTO2vmxPFRTgeJ1A4SjpMPBhua8rP/cJEqDcVCykX40DrzeBuHNcndvez5heQmwxKfxDEfOV0g8PK9Rr2yjuRnlOIjj1lmRQQ8xfORbI0j5PBjAmbKs0uI9JbSv+7utukHfu20cXj3LFsPiNmeABPFGqg3EJD9EUCSuvl7KFSJN9DPqhrsFlobcdf3GPua5+foJbKS6jNWODiTYs1vq4xcDBgm0Onh0EdU+g+O+oOXBc+NP9PC8bDy8/vPy3uE7EOhKek03CmwVwKbYVIBX2xJwtHNUeMnDAJw+HdUtxYAK+tM1ft+Da5sAf1S+4mfs2/DQdPH4AhQu0Hjc3U+obgcfhTt3VQlHX4dbt8+unqJR1TeD3e4+O+zXIJS5Cpk7JigsYazoYCWubTsC8bYE52A/85wIqp3WBVcV8MqiG2SU70e8RgZurHbhdRuFh15IpzwuqUkUlSFdjME1nA8Y+u/gpL3RpaJNmmPXVCdG4WIY+ysocqBLLRcvF8uMpFZbUPA8s6Tb2czTF4cB/1jWbeuBi8D+kokof8OD2XBs8GU8cTSVPIyg35DbgOqcWPQmdqur904sHWUGj98KDSA22qwiQTKBzNpvOA02DWOrI+UJjWJ0mx5hKvRN0BGW7Lsr2EvyozwkzLhhqZSiUzz/UPD+dLTHpJHCdTwE9AP1/eBQaEowL/9r9CR9dPEp0wqG3VmebmmB8SSw85LiVfeBG8w5Ral3QbyVbUGHR/QGINv0YWBJZv8084ReqPxCoWW9oAIBGnhf8MDY34YGtHzZKRvGXR1vwhQV3dimazzc/LBzkQHeOCo0Gbk3gx6bdE23MBcprPj/16MlM2mrvD7MVPYDdD9old4NaiGl6RlR4BoEQ9IQkEYGva1D2OJtFt5Bt8vgJakFPmfHU1/regKueHD5+/pKG5dzg2IaRugbpQjn6teIJhgvWpAI4Va2rSxwOQ8N2tGpi6w9MC+jl50O8Au+Aea8FoQvnHo07pG0XagtQLtQFIJf44+9Ea/EVwup3/qFV/0XCwoAz9NyowZSRlZI4eOtVwIVKyvy5cxKPoxKJnlyEswgO6Mmfjis7Bn0HBHOtGEYQ4x1RKB5LSa3u96ZY3ZuExqgKuTELy/r+K0uP+qjoZFiMH107SsSjju9jCIh4JJ2nRNHXt94PEJ6iE1hgadceIOyo69EQQGzMj/tybrBtJIGoxl7XOc6E73pCR8+eoFE9FcZuZhDka4RE6vasZTsKPKj9+BZh0/w+LLXiop6basbva4cwQp9bcCj14iS/HQC6h8egkdv2zHD9NAxuyxnLcWCUWMaT+Qn6ds+19ugY2S549UhujPuNb3KfSr6AzzWs8cHg/0jgHHWpifHq64eXjwtm4KcWDO3X12HsGJWGiVtaFxk6PjzHTUBKoznzAv0CrOIk03FdFQGhAH09SIUWDGsE0P4zxsoYuuOv+emyunS/UZM9f4IBLAk3xscGtd+7/ezq53MNxD6Q46Iz+Lbv3tw2W6bRZ5WolwxSTI3Yjaqo+RGtPxe3KAyNJnfdLjdDI35CewiCXa/TCtfil1XUVwKyDDeZ0jF/amt+gmWUY0e7v3IWy8f5H9DjRNguGxI99MtLtNzu6wjFQN1X3cexTRID+zDlgJAD4/vt6OS8MM5cBtryeH+Q8652z3HfTlqiCz4jBMYNg4SM4EJFlwmZpSmVgromedhBfXTlP0L76gtZ7G0owldJcOGBybHygPELuHy9Mpcr6P3gXDK39iDt3imQbNw4t9Z0bBgFHMFAWi5CvYCj7xgElWXxhYuNg1JT3/SBxoNtPmSYSYHp/mz+9PInTg1hhmTEokczuSWNhrwjqyk/6LzPJAUBcx8c3wkDXzU9E7LtWRzHQlIjLWsicUdQLdBlEv4i52atwQjC4SXWqS3PkzMeN+rQ5MzIONRNOZkZgc+KGYosG6zo5F8qbjtIgsH6xkUWQsaxhh3WY2y/fvjO7rHnDcudW4OOL3Nhn2e4SRUXRQgy5Sx6A9Ix2hd0gRs6kmtMxtPnzsEGoc3tHMiZCA/lo4tHKeYc1HsSN8pv8MvFbmSo+KTot/DhlXtAcvVQmD4QxmvCd4xr172+oQsjuA9rWBdmeZES1kXH95rIQanNQsI5wnVNELDb3jRQPblfBNNskpDGZ1ePrtiH3U6VFNUjll9umYdH76RwA3ALLFqFHhL/VXWbNsiT98NWppvTsLjlMEVLkTcqfLf9GF2ve538NzVGXOnUtrv6elHYFaB6IeGCxwcJdRVIgD7u//OmdXCastr29VTZo7tvM1ApiPi0W+Be1Tbj1trz42AgLZpkJhLhKj22JcTAymZZkjy/XpKD2LdgXzadqN/IfGgduMzrBTPYoT6AhDIgGVC6EPpx/9c3BxXPjrML/dUO/CxOc75qu0aZPUK1ivxgC6jtgbOVQ6fy9gRpjlWSKQFS6ZCPQEzF3wbSroSL/4kdArfHp21iPDITRkiTUnGwshzDuUa9HuXj+PdYHLppjeSOsvVPbaxHQf3dELf00n06tioavssTdQzEZgXYOh1AyqtSSJkuA/LZ74qwNsLxvLHDNo5qkOUBp2PmR09wTy0NEPqtNh1IF9L9+tzKf0udyUrm21XAzuwWOrpKx4O+nYr9yXY8Z3qO44zoBPEg8f8IMUYqcW2ZLTuTDUnyjRQANw0/A94e4k/sKFlyDdlkZccKz8lGBsoXDeWZCdL60aX/lnLF2EiWEB/LwWHsx8fboeilPhjGEAAsoZW4rzP/ixtE7FoIi7lF8crGrgHScXHw7Ng3cBuBP7iDyIzeS6wGkPfFJQ7IpySBOw/ivD8e/VGschiNNrNwUAM3YLxhmYa46V49hAeE/clS57ZfF4b1mbMpbaOExz7ARDMjHsKjDLxfJw3nSf7CHcmtdQ/Ni0PByi1SjW4QZeOvhLOyz/Mfc3OVwO5Mz8w8yK0vE7XgG1IpfEx0XzG76fLBPHX1fUUKRMh6bMLxJBRI0xEOK+9OCB1fFTLsv3MHYwHbry3yckiRVi6gGbOliPQa/87U1o8ngJHvjJmFKH0L4G8Jsu06Xeisp9s2p0ZobHexhrxAjNJ6xns2ulBfmT8MAbYNResb0t0Y0GizovbfuaODw3ai5kurDC/7QukiTdL+smg7wNfx8foX5wTQsaFvv+spZ1ICbSDDJKw1vywglEWDePwoP6o6E7ZnwFXrtYUXRrw0npnqwCAJ6OAWCPO137nDRTSMgQYhlrNxPxBs5JgHkPVBrvUOiJ8WWXa07nM6bVIeqihHB/+wWt952kdxhCt3MBEpTnr79ufhdYhZ9C3FJpWnj+jAIqJZEAk9J0mG/c4dgzjwt+gYe7uZbYgbTC9+hLmPGYPCIf6Px/v/LuNC767g2NHMQT2onvjnvLFZmcsMfHoE9PA6ZokbI8Ksf29ouTJYaoH4x7xJfDHW2GkzE0EofPmndhBmMcUDE6XWDU5LgIiaTMDNqxraLp/r0+s/0nLZXcNxQlOgXiNvFvL+LmyAJQR6AuLigYsNr8T3WdLjfmmI5JSDUK4AiHEQHut1JjcohAUc+VU7QgKhkmwgekbreNeOBrOBootNm/fL8gssfFBmDFb11qD2a4KRJ5tOuvRizJQvoSRFTpW5qgpIA0HXad77UQs9gnUtHy9U5lFBRDmTo6jSZ9XsV+3w4CVZWu+uXICf2mHUpaTjNZBPrWpyqA/L0fGp+HUiOePWQth6cIPMrNZ2bKWtbD0LgxCPHhXJuFns6Md5nxXcvjV0A/2FptIRC9dtRYOBep4r/Kod700bsb6LPqhMv2vHPYtycgw0jQP57Oqn/BQvZ/0PmkXAchL+wH5QhhimbkLfW6CuXGdbFXuhq4eSZxqj41nbA3ZSn1cnG4aHCntGZbBtMe/eAYx7CwLdd74HA0z/1TuQHTeoJiSR5/54+mPa+MPQMJ8LgY6ebt32ifPtJhH62nXFQDVzQ+gUQ9WxbZzxHzhIGIPjZWbx77nGdAySzjxQSlr/9I6wQIOP75D5yNz/6B2huxY0nUt8ro8jYA4XfRdhn2sRUk7i/6Anl35JVSHCa/JXAYCBTIybWtf1RJgETkuVwaUF98yhVeMGDKOcz8T3/d07tJpnzBLvTH5hKF3lr94hQmp26CjRZvLH9R+jv7n0XLfzQuUFfZJBdUj3UqGkoBEGzgIA1Wfr95juGk0f7guoPDeHDE+LtzrI7cpb9202de129o7dxzszjua1Pcj87ncd6ad3jG4e6Puv//j6j5cEpKQzcEv+zk2ipLalg6ire/MuAHQLriKhA/NudJoaPxPg641kafGwYsxDNrPzPbDKRQmzGaAerR7VDoUsgKUb0a5PyAqynPUwuWj+dofLRxePkjsePbrv9U1WJaUT9vebyqqIcvynAMDkwjSdSBgNHThy5NnUBkvsjYDJeLrtQRz0OsoyDdoRZcAuqawB192fME48Z53r5IP4mSeIpsruzTaj6YclwcNHzDHW1rdtfe6hXmqubu3SvdNT/TAMQ3oBi8ftTFiGM/2cyFWD9oRNO14F4v5eFX5YY7C9joABYQEa6HYDR0gFdSLh5w0xivNrTtdL/VSCPyyI2edygz3u3I6GWH02Q0IQVzbbuwCQRt8XqFzuM5ZtezQhXTn/4but19xKNG7pFNgTNUrTc4R3gtxeDKpEn/doqA+CjfSMevaCu7aj3/04/5XgHFDrlF2Xep0X8PO6MbYbeKXifhcA/LVKOCNjviWBz74TrrdjRntk85cb3d8DHbq9bx33iEB3xTCJUXNQr+O5EppfFcyBziA/CDN5QjLEkHt8vv8FNbOnuId9yz54e3EoYb+y29GCYaE/BYCO0P5RkyXyp8xswaz2NPSCpM+CeG1XSdeGgEftr6ZD6BrS9OwxEuoSkgjbEmvXUdb9jDNpSmgb3CzH/4D64/qJGku6mlKI98XE8KIVxMLI9shPAWD6yOeFyrK7ho88IfONWxCeuE532fS2YcTc+LaiWoCOwHiJXFJ0dpoB0l5aSu3dYVwoAcoeyFqZUEWWj+v/7iAxipreowWhaI7g953seQYw91MAkEwhyHkOzVEDUA/MnhDtI1JA07EmNK9hnzkQAicyyQGexIvgtkkVrEXHOFjJ+Ely1cQKNKgTlip5nv1iH89/i8u80xovI4kNeLDd0dw7xjJSfhcAqosB9eIZ1uFPN8/tomjvk9WYVY7zXginawT0DbuapeOnKOS+oCyliJ8yGIf81ynPQwf3OijZkDuXHFEzPr3+NOEp+iWI+dRiNu4XQjgB/VygFB+zAHC19ZrJ7KtlPOq67VPpuRCQgtjs2ivTanPwxHCMhLgI3yU8Jhl0ezM/jKMIrHxOBilwNxFimdQCf+7j6T/UYaRp5EQTtVdsCH+SFgGhvfCIWJefAsBa2j47dfidKaRrbwMpI1fhyM1Tmm6uY1K9ePSUe1vAc1h2MaSsOTWJEV+sGqwwS+kY9cEYihG21Zk32j6eAFRwoTWHi7jZtKRsGjOlU/wi2J3qTO69iFiQ6oXnnatb4TVt9qH4Dgy6v1EAPSJ1ffaRxnDPmCp4jWL21Ym67uOX4yNpTSuz+UC7WiGQCf63z65+auDSWZTdrBUYkaG00iQePzWKlaBtBnTqdYhdIIcljkCO992FOg40aDjbg7iYobt0dewXM8A7+grOkU+kMUEvcou/BL6ZBQobxhHPUio1wMf7/8vsadwmaiMEWR4yOrokWggoYa1k5kDfPid6Cp4UBoTXTBCsr7Os2wIX64e2qb02WpDRwDh8YBvGNt0iAuWMWAEx31+AD3oFJxAN7kYtqfe70Y/7P7D6WF4C8gtBOj8xCKIHO9jMaC9LGJ5WQif1Bwz8dk9uEh8ZzwRGU/KCvMkM9QbGpOqw78zeUXs9a2g3mcAXTeWvwHdYUflw/Fx2782Tzk8v/7Yuxfba8bkK9I1OM7fNSEtS8MlsikuWIptxHQ/ylB6JXlfcBLNogbwxd3T5HuOgC2hABwKnrNEz8GUSHzb+TnyWkhe2wamLSTt57o/zPx8DOHRbBoNb6SGRC/qltSQsH86uTK23ZZYijwV6puUlSd6GQepr3MwXEVLkbCEzdfo44NqBeRPf6z8TX55Xxem9KYNBYkPS9en1T/khcnq/hGGipDVTsc1u1pejs4gRI8IUPP00M3mP3DYiqhWg0lL96tH034NDgYJRBOW/Jj64W4+8IwpCAEjNx73fe3ahZeAF12tPw9dUyWxxKI9VSAPwzbVojw8Mu92UOBC6LEB0sLX2yMPVgkzbe3AItBmV/B+JL9gqy0wijRRkX3kMH+9/n2ssNO4LR8yW/dFiRD4swc8ub2sSIv1EO4Z8N5ZbLhUctUTWQ+0XQZyfEeQjiWnH5uls//yvic+foUnWrNAW8gji894fRL9xvV0r3hhlRQmV8pZfqy0toJmDpgvasGOpHJuz6OeAXvi/pUz0EphxsTF+EesQQ5DfQ5P/lPieQ5M5oY4IZ06NEeTz/f/7GpP1SMgEOEIWa2jq56tKwY4jWqQtYPpWgW+nmU3LYSA5chgRFyQAE+7VuhQDWi28aPNraPIfCh8/Q5Mktwn7XpbxdMSP9785ZCiROBZQ3YVd2raao9d3WxKiAXdsGOnPO7WMZJXUbpfXhvRvzkur6I1k+QxIGqbehChE+q+Fr5+hSW78ScwgTe/j/F8oAPmBvA4Z8Bqckhju8DUpNhJIL/b1zFnNMYe4ILFRUuaMax8sbsvW+1hIva0GyonwDpGDyss/FD7/GJpkZpMEAecmNrN//Py9XkV/FUqWbYsSFKrpdN7Ie6VDl7WbvcxDrAJjYL3u2TDKhXYeNR3Dwng85IPzXDlZArfd/2Ph+9fQ5H0x2jA2Ite0IdaP85/rOepkbDonlgz7MUgiwTxITrYCJl0LxDXP9o82tjnHIRZJ7TE7IpDJHvjuWXhBz9dLLZd59X9tfGh/H5oMZBwNoiJd8M/X/9vruQhVuS5ha6tnYmJ3MjSsjab9mIPAai25IFEOqszCAE9kli3WBNbBOk6KFAlkR6eXy6VN2f6l8eX496FJCVb4Rz2zV/h/IQFyNumbd9FIM/OxGLsW+9JwIvEd19uLFwwBuaGCoyNnNip4pTkf8K6E72t7SJCuPFeQqPYI7dxCFlHfjU/nvw9NVgQR+YV7S2j1n148zEZ/FYlXDR085LVMwIbH/Tp3JHywb1mAnC1RXTwTyqvN2iHhIeWeufvwRs8ecUAQfTNmoVL4JR27mI1vFcS/D02Oo9AGcq9E9fLx/g8ry0587FnNWfyZjjb9ahuXcgMx0TEVazT4+mknWMkZ/GaDXDrcZa7evPcg3H65UDma5dIx7d+Nj7MK9h+GJjeOOFGhYXBl9cfx74bo9og1IDlvc6ZN2nmXCfVLBC3R23WKpHUWOebcB0JkeDdIh1aZvtbYJqZfD6ivnSFD8qNsARhnTA4g/zA0ibF/t3lT9wKlfXz+cdmz3mvQ8OwB2frMYq5zOgFmuicv0PyCwA4d47yzQCH+XSW5g9x6I9c9xEqkc8dgM5d/VyBlejyNUElH8g9Dk4Ku+zCoQOg07cf7vwsD1d4e+zW4AjVntZV4/2OO7VS/R/Tc+1UZ9COvUtQbQ0PGP3RkeMcc9Ib4TGCMxoE4p/Xr6WRnc1TiPw9NNn0sDAJfnZqTIB+WXIJr2awE3viebHTOhGyvc6CLOm0iMtfjNbdiAWVcXQhc8gzLm9zke3hh30xvuYtR039sUHdLN43s6T8PTe6liQBeYSzVH1/+bGIo1MAxhz/xv+uDBu3zDs8zkx2E3YxeN6Lb9jrwEIXL3oPDw166dXOsz5pxQrk4KsGN6GiAR3iMH7BZ/g9Dk201AoNNfu17Ux9nwDlu6JFSWJYdQ31b+auLF59oB0/OdEOblzEjVzPoByqa+zo7vSZfGIdHFNvbgrQmnEh8id3Q4MHoNYJMkYn/PDTJg+/yXGIFpvvH+7+GEZdEP11mTXtWNiqCU+Q8h5vZ22WZjTAsoCGr2A1BtMvYvrzn9oXkofaMS7gIn22knG2dwcbfjcNyi529T/dvQ5OtpJr8vDKJCggf93/W4SODw3AnJLRGkMu/QCHSezCeF1aEEaZZV6nYwm9lrSypiieqi0gnur/3YOdy/THO4troFYMjms2/D01SU5Ya3RATWbqP33+SWkId0GjEfJZ4srdI80ANNttZemlXH2yEd1ETwQwRHOF9gnlxDxdz4K3ssyFgq7Mffnkjoi1PGN0L1ZGq9rehSaJYlfeQbdbLERR/vP4H8ajMec/xgdH1n3zv/Cowb0CigRtd25OJXihgUA8RynHtq8KDdratZWa3AenPdu4nmk9BPUKA+x6Mg92CcOTvQ5NKIwq8qBAM1p6ej6f/cZXmNbENUtHD7he6gOuBd1Ym7YUpDNSpg9luQHBv743nsl3dzHszrHa2Ogv6DhjH+rWG3sNZkejNZiphV+/SX4cmJwpKazBupYmir0S4eOiP+38LlFwvSJPczMlEDOF1A85xD1qWXNqMRyvllbVYC3/sWqVUPnonETf5UYeBcRGbhLmOvrnJjO0CI0viUi7yL0OTuwdW1txnx1HXyKyo5enj8x9cC+IQ7GC4tz9k3NsXMXmzlOV1Tds2xrU4WlhdOMP4XnCFqndR6xZFvucNJgjvjIetMRZmchNSmgPBS2n78efQJBBHpBbOE9Pw1N2cnY/bxwHQlRgejK/waDMngcCuwviUt5MGx3u8HBQBsZoeHjs71n5GoPZL7jM30GuaFJbMdTwIcPa1ZMqO5eiIK0OofxmapAiZDI1S4Q+R9016ucaP5783GyluANKACKnmBPbUIGxFAw5HHRt5zWy9hzoSzJH/SY3e7ZJvH7FC7DxBXI6Mmlw2j2Tw6P1GpuBxH+DPocmFUYlb4rUxPGuo7t1Owz7e/5dTJXzrgs7Qle9zAVR1xmxlwfWSYppBfUG46+btFp7NtP4x4/0bMMBBex/JS/mTypgbFNO6vHRq0Qfyx9BkFkxJPXKeCREPolBSZ/P7x/NfTGK4UrOj6Q3FnusQbD+r4pCUnikhsNZbq4lGwuYIb9bnC3dpJgJrXpRDVih0QHD8VzLT97IO83to0niBSJdHUm6yBM2JjGURBENi+ngF1ImwgarpNkfBs6n3HZGsjVGF1mQyN1zM2KtknFORG8k9XLtGAqdmKrww6ZEdA9ujANwOT1ADkPrHNShyhFrfmRN4UZEQWhY+CKV+R6BBZR5OLfXj+f9qWfTcN5fSvm47+m4/07kiULeveNJ9Foe3lRoWEB0v4E7k9hgA3lc63YomtJfXvobZOngiDOqtpdGDEDuGxFLnFO2OlLkXDIGuY+SbhdGZ9bHx3BX9/P0XRWxtR8KnYT2PCxdoCPIWwqhCR1/mdYWz11luWuyrrUZZcyD0Vem1IhV6TRsmyzrL3UduuAHPde0u9URYiRqDyTVYbhQcmsGh9gKbO959ttSrJVhPP71+Mib53dgc7rgHRnJqaqIRGKIdhTiImwt5QcrG5BcqsVcQCRGhsxOJgKnSEEmQ0hGY9wSTOS+5p3WCYin1gVqzbBg66wxz4bwOuSA4sgg1wMBK9Zo+fv9ptIGcgZDQ85hJPJBrne0OwrYNiNmk416iU9d4mluL6Aey1nMOgK1HRBe44RbA4yiGACuJlyJFo7mzSG7WhkFfm+FcRrALWvm92Rkl0swbi5LE0j/e/zRgtQSsrHed1x5fe9k3oRwcErkQIvTdMKtZ7QbxrkCTZn2YpbbJ/+fFUEVqr23I2nY671HIHh2IvwTv0t5yTr6vW3fM9J164Cr2sYo1HAiLYz+iah+f/+UYlKyUZp03tbWXP0tf0RpQndEnLCBzWihvVA18kerDk1wtJerolJL7aISS7HmDwfjF88pcCWNLLxcJy6dZR9S72pD+ho0S0XomYyIMKscoLN/Rf9z/t3ntRZ9xKJp5B5hb9byyHHFg5WGgN1jEvN3gfhD/wf6kvlKupdAv5sl7aJJohfHMIqZn+MMaET13CJiO992g+9WXiIqEP/rT6f/MtpF1Ek4daHvcZxcP8/o/dHGqnoht7SzlonWiW/dZwvPab3T/BqEr9IAUIatoZtrnLjJd7N25P4cmlZx3QeFSiLS+RsPEvuu2vhFVZa2Cqwcl/Z1kz8tsAhuzafiBi9r+cf6XTXMm5zaZWJt3Fi0mzh4WWe2+hTMopa2ZRzmRrHtj14HM1qzHvw9N5t07o6Kt6Rx23vD6gG6BIpfOCAHtYrUduSkEvTyD177N3PGHZV/wMbYVHfyccOjo9+d996sxMfTdRiOR31lYg4FwFaRxFBpdl9xzjn8fmixbwiUqJhyhBrFAgx1EvGbzw9K5QYfZmWZzlAy9yyyog94+v/4zWc8c1JUXCDvnOiNoRUys151bAVJPZIvKEV5H6ZpBjcupZt9+WSH9y9DkReXqGPEIbhe3DvT8MK9+xeAvq0EO3fKBCpZL5W33ggGxED5e/91XWaJxhiK1ARITpeI8GAjRhkaKss7rKmMHub06Gnjbd4R8pM2ed62XJf1laFJnsOXY+gHm3OZkvznntPzMlarLw3aeM8B2DURnmY1o5z4+P//yM+mJaJ9ZRGuQZ0PjKAPKuRDCg6rUlY3011PJAbeGrNScfOgNETJRwfw5NKko8b0/T0cUlVEzNIUNZutjY7O2UG9wA1SAWWGDllcooz4fx/9ArXTjWDSIYPBMR6bZnnCVCIvJhONh7+OaxbBsHlykWzmCY/syNvPiVQ5/DE02Ziy6ivK8ywAnmxekEYUGnkPQ1vE0+Gk8RPduBLLvoSP4ePyX0LMNSHo1574PW6oKsl+pz8G36Bu0UXScwW2Jdk7LQ1/M8WCgh3jo0fzifg1NYggNcwAW1xRQRXi7hsfYhzviwPdjV8EXjCpuXAKY1j+Z/4/Xv3aDOk8I9bEzQGa+H4PC0lLPJsZl2/L18x0V78dtBZZbbdmcQweEh+o1Zhco/AxN1uTW2U5pA7+OWVjQeNCoE6Xm1T2nNAp5xEgYT5E85J4wfJqP538cEzP0pcwQCMxb//ZCCTp/ZDGRIlrZTyQrS3j3acySPe9zmOVKuP6A1GemiMgMBX7faVtSeieGGLyaB8ZHFZ4jr3aRl33aPqU/V35wH69zz6A/nv9rs95B99dLw3LFtcTFzmtAlknwfD5eePBzuD/9XNXwYCxEG+jk9cySAamMsI77Na8H6Z1XAxeP2/zJXqMT6PjndwuARNMZtU0HiOEW+FhmXzg8JXweABM4X+yZiXASUPMxhoXj7oRX/sBsbd+DmJOKZj80nv28uzq98syBD5Nfo9SUdiD7jx37TeA7a546cM3Wf7IfDuIcjV/W+eFzatiOcXddJEaHo30c/6IVu3mrDdfX+yxiGCfV6LBOh87+PdRvufbW9NQwLAr1qMf/urvifpbGTYseg8T7ClmVUrSJpTTiNishj5R9QH51h2qwY3SdQ9T64PVQLsVZKP14/9eOj6C913q1PzcSMMZXWEbco75vGwOMG723r4szeg6LgYqAMAh/sBauEMFjOKhSo+pHsaJnH5sw4PYTDAKmVJdV6xr48oS9uwSLnXetIi80s97Wj4/3v77uQ75RYFsFe0+zkwS6Y8hur12VA7YrlXvbe63nvN7VzgtOESGBM5WBPK7ex1btgux5eOksIUMK5plisi6g6ghsZtbX5cH4Jw6E0sFcINefzs/t4+tndSwQzry3uJp3LS8W9N8z26X5uvHtTrDt4lgom2MNg47T4m/1TRFE8JFzyhmiYbcj/CMwe2MNwcjA8CW1dURXQ0IBE6VagEHpzVo2uyzYj+f7eP0LKFolh7G12Od3gNHA4YpIYgZoVGIy+f48JPfGKmPAvOYIbmv3s5Rf99eQlfCr0Pe/I3tEK0IQPJkh4sf8Uy+8Z/8Dw49g+DmUrS5eB12fj8OfmcZD7cwrPpnsM++DK5UF/TXG612kBnGdh4TEcKZqJwpyrzm1vEZEyKwpfjoM4+gTup+XOUdt3OyTeDKSpfktP3MGlnJhRyJ5dlWzgXBhO1IPDwKr5+P498SDnBcgzEGfXCYX+rmTCv8/jSPEB+xuCdvtMNplZY29tJNkfm+SceW2ra8hACHHslBeSCk+vm+168iRLq7EvAiR1LY9SHm7GTe0U7QtTQK9CuE/3v/0OHmjY7bOEZnfp3EThHzcIwjeNSL5MtCRC4dstW0jl/1VidHKDrvs/WX8zqTOVobOyGIXTZAUg6TNmAX3akHMYzcGvlofCuRdPgs0vWdi9grEFf3x9XMJMldScxVLZwPtNt4I5ucNJ3M4cR8bevFUVFuUUptbd8QAzSlJi5c5+DV4pY7cV2r92g0jlCFuTit6UJLE2pQT4gnBSxBn4rLB3lRFjCwHwgHB+cfrP7Ole+leUn+oRN2lPbQEUqV1XnrDrmOvkqezzAelJkQOvASJJ2k3NPhTFctKvRzflI/tJkil5lWpG0fguxxbEfuC4WNyCMPNpoGKPPqSi6Ee179+Hv6JNH3ahRie7WiisM47r/zybHBBWvC0JZJY1FoWO3SuUT+EE7H39x0OnvN5me9rMSvGs3U2wh1bq6nM1uiGDOFE9ZljNL/GnNrz0N0qZISVQiMhfd7/ZT7Hc2FtaKG5/+pHM2Ne5x7mlzh1OfO8tZUb4riI34LPVel5h4dCO2YLIlmQaT3WRKcLPcriHILBNJHtiiahjpLe13y+Q/2T0jO7xPeaZ13Yfvz+m1dnagZoU0lYVQ6TkSIxQTVGHn9yNAbXEnv84dzrQeSX6Wxqn3e4VPDO4ZbddDY8He8vTsGgII1c+6T186tSpXTH+w6YYXwMxmmozM0+iVQumldvPj7/eIyVz6+8WbzmyHvnt7cAbSwHSrJ7Z2d9yXZ+KepdDxfR5nMhP3f46PdYm4mB5uiYHkeXRrClbCE3joZVnNZ8Q27hFmbvs4U6LkBtcSWuweiHlLF/3P/TUgYXdT8HLpaPOq/oYULrvNa6zMwPRSNHHINnJ3lYq0Tl/3WHU1e65JnHikQpjJgyMdfRtRmJVrWIYWdXrOBQjrOycY2956vPyJLPCwPNFnOUHz9/wraVQOVnIimq7arnqXNc1lTy4vR73gHqq2YzZ/eJbwLR/s8dXhB3Ol7rvCIAld17uRiqZCOzFRghz4Z04H2pLG7GeVdGS3YIj8KEWJQSNJaDfDz7jUIrBKDorsI4iGk9jy07tAizWAk1HGw9L3hs6vOOd5WW5fcdbrNd7CAKGeArU9vTvCx71Z4Ary/QlOJWAKH7uys8PA3YzAikrsBvIB6f4t7n6NSHZU5w+V5P//4WvNn5jk92C3FStiCjE3dIAUYz+92B3z1v/Y87/GB+a5JSzwN3Q9/P7bKUdcKm4xlroWpFmBN8+4lxz6mO1BQEgktWLM8L4M8qP97//nhr4dx9UZB4wVW56RMGnC9N2/zeA8TC4YE9nQuk1bBw/b7K5j3nipAIHs5eePpCFsuP9xfe2kt4q6fTQPBbkPLOSZm+1FlCXRZUqqbinpAHmY/n//rRS3EFyS4C4b2AUNbbdxv/vMPTQUdc9JpXws+LgdjiOfnjDs8yUx6zl+VBXOiTWVyc33k9x6jwR2r3vszpx/XVosJN7kAa4ox01IK2hHYDRH++/IMOes4rstnMQg7Euly3n6z8vMPVrIX32es2y9trmTZM/rjKptpS319y/W6dbHxVQc+vEDwRCqK5y3ymsiGCuDu6EsE4mV8x3Gfpc96N+cZDn4f/v+QgCz7qVkKJfuYstrmuGaDLmF//JmaZ5NVqcPEvV9nUjcp3YQD5TyC8mrBIDBIzydv7/r4BSWCYyPJ12PkVu/W4MerNpMn7twjIz/f/f+UrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yFYD/B92aGZl3Kab3AAAyEGlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNC4yLjItYzA2MyA1My4zNTE3MzUsIDIwMDgvMDcvMjItMTg6MTE6MTIgICAgICAgICI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyI+CiAgICAgICAgIDx4bXA6Q3JlYXRvclRvb2w+QWRvYmUgRmlyZXdvcmtzIENTNDwveG1wOkNyZWF0b3JUb29sPgogICAgICAgICA8eG1wOkNyZWF0ZURhdGU+MjAxMC0wOS0zMFQyMToxMzoxNFo8L3htcDpDcmVhdGVEYXRlPgogICAgICAgICA8eG1wOk1vZGlmeURhdGU+MjAxMC0wOS0zMFQyMToxNjo1Mlo8L3htcDpNb2RpZnlEYXRlPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIj4KICAgICAgICAgPGRjOmZvcm1hdD5pbWFnZS9wbmc8L2RjOmZvcm1hdD4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgCjw/eHBhY2tldCBlbmQ9InciPz5DnFz1AAAANklEQVQ4jWNkYGD4z0BFwERNw4aGgSwwxv//lAUlIyMjAwPDUPDyqIGjBo4aOCAGMjIM9hIbAIf+BSc7FnzSAAAAAElFTkSuQmCC) no-repeat scroll center;\
        }\
        div.iGraphHelperZoom {\
            float: right;\
            font-family: verdana;\
            font-size: 10px;\
            color: black;\
        }\
        div.iGraphHelperZoom a {\
            color: #002BB8;\
        }\
        div.iGraphHelperBottomIcons {\
            float: left;\
        }\
        div.iGraphHelperTopIcons {\
            float: right;\
        }\
        div.iGraphHelperIcons {\
            width: 18px;\
            height: 18px;\
            cursor: pointer;\
            margin: 3px 5px 3px 1px;\
            opacity: 1;\
        }\
        div#iGraphIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAACZ0lEQVR42q2UW0iUURDH/5+7YhFFRiCFkC9SiJZYFhsFgl2oEPJCRkT0IoUmkUlGN8PWLmwiSg8mRT1oipQVqClJbeuqmQ+JYvlQtoZ8uSu6uuzFXff7/j24nty2INJ5mTNzzvxmzgyMBIBYAtECALk4liRJCJs3kou60fPV+d+wsIWGze7C3VZr0ANP7RNM55+Fo/ACfCbTP4BIxEavRnO/G95ZFQDgKroEf+MLaCMiILmc8FTegyPnFNQx6x9hJMlthWb6FZWJJRbm1Y7RW1VNZ0oq/f0DnBdFljmdkcXJw0dY894u/ACoXUCDdcKBzKRVkJ+b4B+sQXh6GjQJ8SJjRX8EGrYYoA0DtMYpVBun8K4oJriipPMmkWE8TseR5ANcKGce27ixcJgX62xURkbo3rqdHx62iop+gQqMJEn/6Vx6ozcwNbOdBTUT9CsqM8p+MCpnmIaXkwLsO3GSnh07Q0GJ595QHhqmsjKSyvUSXq6fJLIt1By1UJNtYUOnk7+LN3ZTaI+gEuuGBoCoKKD4KvQA9NmRuNNox4r1j9Bp/wRTi4LMuGNIidkLANDodKHjJ1Wos7Og2Sgue793oc91HL3fTFgTvhbLsBxl5hto+9I0F3y7NHT8m/PbKJt7RNnlbTd5qHw3S5uu0O11Cf/9jgoerNoV9MWgHiXkveL4tI23nhYzTb+H+67p+Ky7PqQvM74Zplfup6FV/xdQbgvf9rWza7CD5o899Hg9JMlR2SYCRmUrSdI2Nca61/V0zTgFSAqAEJ/bDJAgAgnUOR1IJXSgG+L8+UEWJEmCAC12jUhLtdh+AkEUAe++FhGGAAAAAElFTkSuQmCC) no-repeat scroll center;\
        }\
        div#iGraphObserveIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAABo0lEQVR4AaVUMUhCURS9xQ+04Us0hGIQDg5/yEGHBgOhaAjaKlpyaGgMB+cEt8BBGv/g0mhb0RBCQgUONRT0hwJtkKKhpB/0JYV658l//edXIzzw4N/77j333HufjiQSiW92aBiUy2VSQJLJZGhYKN2OeuOTDq/rA5O24iFSPcpgonzp4U8i02rT7oom+UadhvFkukhUzxg/ThQua1SpvvZXtH1wJb6XtClKLYZJC6jcrjcsyh7d0anxwu3ssUEnO/NuRWgJwQCS9WSMV43vndHy/jkZzyb3zYUmhfp86V4mwoALFzXhTC2EyWy2eFXcISldvGG+Nhv0jKPFR34viKAGiTaCE16e7IRptZjvnTS/T/Kli7dORZaUpHoVfnrBbH5JNooKotxaRNpMpfrGAsYlHxK0gI+p+vgtyO6xEEGEILn3Gg/Krc/y4WKDnWKKNGDkSIoAvmp/Z9WYDzYFMj0ZZYQR7t/QK2IMILDVANIg8FoRbJPZ372gb8YkW3rZaMPZYj+sRoPiofZUBEBu90/CTTTt8rmInJv4DxT8KQ0LcPwAiY+nftwGTj8AAAAASUVORK5CYII=) no-repeat scroll center;\
        }\
        div#iGraphZoomerIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAB4ElEQVR42q2UvWuTURTGf/d93ySmJsZWmiIWP+ikgyIFRVzESf8CBxdXQf+Hzg7uIri7OgkuuihGpQpWE7TQEluSNI2aj9f3657jkCZSbJqKfZbDhXt/PJzz3GMAZR/kAaj+H8sY0wcNpKp8aQr1jsUPLYkVXCMUcw7nj09gjBkN679XVJX3axZVYXLC4DkKCkGiVJsBYZRw7dzUjjBjDM7gUNkQRC3FnCGILc2upd61+JFwcjqLAi+WWiMdDUH1dsxU1tAJLX6kJKJYq/QipfXLcuxIlspaezyoG1hcB/xIsaJYoQ8TpRcK6ZRLqx3uPjWAKE4QTZGIIgJW/1QVsNq/M9aRixDEgueYLScMa8oz+EFMxpXxoGLeZaXuk884pF2D3XKW8QyHsy4fl5sc+r5Ib/Pb7qCLc3mCMGZp9QcpF4p5j2LBI+0opU81ups1rsys8/LhHTobq6NzNAjksw8NKtU2rU5IElsOpB2mo6/MO6+YPX2B9cobVj6XuHr3EYWZU8McbQONkiQx7x4vEHcanDhziWr5NcvlEjfvL/4dyN3keCnmbyyQeAcpv31KcXaOTqu2c4/2Art86x6SKfD8yQPOXr89ukd7kYjF/9kgN3l021/7Z9CoNWL2a7H9BsVQBplwQpyqAAAAAElFTkSuQmCC) no-repeat scroll center;\
        }\
        div#iGraphCSVIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAIAAADZrBkAAAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAB90lEQVR4nJ2SzUtUURiH589w4cJC0TTNYcI0E2FQBh1BZ3LCm6aSU4yJ4zd+4MfVJpGuX8SgTFiBqUjZ5MYS3cyijSCCC12JrhJKSAhExUU9cI5nrrrz8GxmuM95z/t7X4vl2mfkew8EvrZCz2wdtL17Wh987BstfWa4nwQKNT3f0213deSAs+leVPuyNRfe/AizayF4/+PN28hocHVo/NsADIY79flm4Maoxr9o/87PydmJ4Pj0WPDn6FBwQeNt1LmkXXUO/v7m8QUNGVLT5/2fNj4g+MO14Jvxlk9owtH0R4r9w59ojnqb1ChNP1QomMjntd0r7Z3LTZ7hYj5tXvQ+nHbbXqdbnlvQ6kJlebVWqXEHGYi3YU5vTLUsvqhZqHL22c3OZY2syU0l8cDICq2HfDMajr3Rppy9g13fpDvXe1tqzIesVQZ8bR1IMyKvKiYdzqnC7OokugW0mmARP6XGTMeW+kVoOKKfW13xgUivMo0FfefXDlpWZaLUqgadjE44d1wpioSOG+1LfmWiVYzZ75bdlBq7IzQmIxDNvPysm29B00ZyrKVxUmPfWByzIAIws72/DR4jM7UkVmosKKMzO0LjeoFwwDVkjWrulvtq8QXMh6wJAOiHt1EH0JKLYqTGdirYHQYKzAfIDYiBloBS0WrXOP8BX5G9lz7LzIkAAAAASUVORK5CYII%3D) no-repeat scroll center;\
        }\
        div#iGraphDataTableIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAIAAADZrBkAAAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAA7EAAAOxAGVKw4bAAACOUlEQVR4nGNgIBv0bq8Fopb1JUBUuzQbiErnJuVOicroC0ntDopt8YpscA2tcQqssAUi70JzhLaJC7bN2/lo/oG3c/e9nrXn9bRdLydvfz5h67OeTU861j9qWfOgYeXd2qV3qmcfR2hrW1c5b/fTL99/E0Ql868gtAHdNm//G6Do0qtzFl6eMffClBnnJkw+3d13sr3zWFPL4bqGg1U1+8qACvJnX/HMN4Nqa1iRN3vva6Dof7wAqCBr+kX3XGOoNmAYzNj1Eii67PBLPAioIGXyOZdMQ6g2YLhN2f4cog1o6sojL+A2rDmOYL/++D2+/zRCGzCs+7c8/fTt16pjL9cA0fFXa4+/XHfy5YaTQPYLILnhxIutZ17ce/4psuuEfYoOVBswfno2Pv747de6k6+Apm4Ak5i23X76MbTtmHWCBlQbME7b1z388OXXptOvNp9BoO3nXgG1gSw88WLdiRc3Hn0IaTtiGacO1Rbf5t206v77zz+B6oCm7r7wGm7DrvOvPn2DhjBQW3zvCZMIJag2YNqpW3EXqG3Xhde7kdDei6+3nn0FR0BtMV3HDEMUoNqA6a1qyc13n3/uuwSyZ/9lhG1rjyP8CbKt55hugAxUGzCBli68/vbTj1cfvj97++3Rqy/3nn++/eQjUB0aiu08gtAWVGxVOv1Q3vTzGdMuJk86F9d3OrrrZFj78aCWw2gotHKFlo8EVBswdcIRMO0AIxSIgPEDRMBwAyJgMAC9BERAqxC2kQEA0b0fsDpUmdQAAAAASUVORK5CYII%3D) no-repeat scroll center;\
        }\
        div#iGraphRefreshIcon {\
            background: transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAARCAYAAADQWvz5AAAACXZwQWcAAAASAAAAEQAIFT2JAAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAArwAAAK8AFCrDSYAAACVklEQVQ4y2P4//8/AzUwgoEGtOf45dusjjvtuib9r/uytO9aEwN3qvf4eqOrw2uQwdrIqR5HC/+Fnmn9n3S5/X/G1Z7/Ex+s/u+8IvOL5pTAJKIM0lkcHKe/LPC5/qrwcr3lwf5AfqfX9rxvlTdm/J/ycO1/l6XZn9X7ojStF6Vvt1mccRS3QQuDJ5gdTpREtlV3Wax14I6KbyBXzXu89b9qi/f7tc+O/PdZWPSZYBihA42JIUUTbq76v+Lp3v+rn+39f+Dtmf/Wk1IuYzXI7GgGp9nROCZ0Q3QWJ4ooNwVUha+u+Lfp5eH/m18dBxuk3hC4EcMgrZmBoSl7G39k72v+Gbqv9LH7loxThssiNgDDyBAYW1M2vTzw/8T7S/9Pf7gKpC+D2Qrlgf0YBmlO8Zn4/Mfb/+c+3vl/+N0loK1H/k9/tOG/1ky/iZpTwgz1Z0XNc1yUdTxwVeWD2BXVP8KXVHxXbgkMwjDIcFbg5pufHv7f9vLE/00vgQG5Mvuv5rTQUmDMCaF71ezoZkal2hh2rNHvuSzj6qn31/5vfHH4/6qn+//Xnpn9X3tOWAGhSMAwKHhDybc5D7f815rq+27xk+3/++4v/++5Lv+HzsJoa9QUHyejOSWyCqdBdiszz9luyNgEDHRNxyVpX5tuz/9fc3P2f5fV2T+Aqblboz8iWLUrtEa9K+yFel9wFFFZRGdxjJPjsvTPRdcn/88BZo/UK+3/Q8+1/nfeU/wPGPATiM5rIKA5LVxVrdN7hfWCxE+WixJ/6fSHHVdt88smGEZUK0YoxQATSWyMvwe1dwAAAABJRU5ErkJggg%3D%3D) no-repeat scroll center;\
        }\
        div#iGraphCartIcon.addToCartIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAATCAYAAACdkl3yAAAMFGlDQ1BJQ0MgUHJvZmlsZQAASImVVwdUk8kWnr+kEBJaIAJSQm+C9Cq9FwHpYCMkAUIJkBBU7MiigmtBRQRFRVdAFFwLIGvFriyCvT9QUVlZFws2VN6kgK6vnXfPmX++3Ln3zncnd+bMAKBozcrNzUKVAMjm5wuiAn2YCYlJTFIfIANdQAVE4MxiC3O9IyPDAJSx/u/y7iZAxP01S3Gsfx3/r6LM4QrZACCREKdwhOxsiA8BgKuzcwX5ABA6od5gTn6uGA9BrCqABAEg4mKcJsXqYpwixZMkNjFRvhB7AUCmsliCNAAUxLyZBew0GEdBzNGaz+HxId4CsQc7ncWB+D7Ek7KzcyBWJENsmvJdnLS/xUwZj8lipY1jaS4SIfvxhLlZrHn/53L8b8nOEo3NoQ8bNV0QFCXOGa5bfWZOqBhTIT7KTwmPgFgF4gs8jsRejO+mi4JiZfaDbKEvXDPAAAAFHJZfKMRaEDNEmbHeMmzLEkh8oT0azssPjpHhFEFOlCw+WsDPCg+TxVmRzg0ewzVcoX/0mE0qLyAYYlhp6KHC9Jh4KU/0TAEvLhxiBYi7hZnRoTLfh4XpvuFjNgJRlJizIcRvUwUBUVIbTD1bOJYXZsVmSeaCtYB55afHBEl9sQSuMCFsjAOH6+cv5YBxuPxYGTcMVpdPlMy3JDcrUmaP1XCzAqOk64ztFxZEj/lezYcFJl0H7FEGKyRSNte73PzIGCk3HAVhwBf4ASYQwZYCckAG4HUNtg7CX9KRAMACApAGuMBSphnziJeM8OE3GhSCPyHiAuG4n49klAsKoP7LuFb6tQSpktECiUcmeApxNq6Je+BueBj8esFmizvjLmN+TMWxWYn+RD9iEDGAaDbOgw1ZZ8EmALx/owuFPRdmJ+bCH8vhWzzCU0IP4RHhBqGXcAfEgSeSKDKr2bwiwQ/MmWAq6IXRAmTZpXyfHW4MWTvgPrg75A+54wxcE1ji9jATb9wT5uYAtd8zFI1z+7aWP84nZv19PjK9grmCg4xFyvg/4ztu9WMU3+/WiAP70B8tsRXYQew8dgq7iB3FWgETO4G1YZ3YMTEer4QnkkoYmy1Kwi0TxuGN2Vg3Wg9Yf/5hbpZsfvF6CfO5c/PFm8E3J3eegJeWns/0hqcxlxnMZ1tNYtpa2zgBID7bpUfHG4bkzEYYl77p8k4C4FIKlWnfdCwDAI48BYD+7pvO4DUs97UAHOtmiwQFUp34OAYEQAGKcFdoAB1gAExhPrbAEbgBL+APQkAEiAGJYBZc8XSQDTnPAQvAUlACysBasBFUgW1gJ6gH+8AB0AqOglPgHLgMusENcA/WRT94AYbAOzCCIAgJoSF0RAPRRYwQC8QWcUY8EH8kDIlCEpFkJA3hIyJkAbIMKUPKkSpkB9KA/IocQU4hF5Ee5A7Shwwgr5FPKIZSUVVUGzVGJ6POqDcaisagM9E0NA8tRIvR1WglWovuRVvQU+hl9Abai75AhzGAyWMMTA+zxJwxXywCS8JSMQG2CCvFKrBarAlrh//zNawXG8Q+4kScjjNxS1ibQXgszsbz8EX4KrwKr8db8DP4NbwPH8K/EmgELYIFwZUQTEggpBHmEEoIFYTdhMOEs3Df9BPeEYlEBtGE6AT3ZSIxgzifuIq4ldhMPEnsIT4mDpNIJA2SBcmdFEFikfJJJaTNpL2kE6SrpH7SB7I8WZdsSw4gJ5H55CJyBXkP+Tj5KvkZeUROSc5IzlUuQo4jN09ujdwuuXa5K3L9ciMUZYoJxZ0SQ8mgLKVUUpooZyn3KW/k5eX15V3kp8nz5JfIV8rvl78g3yf/kapCNaf6UmdQRdTV1DrqSeod6hsajWZM86Il0fJpq2kNtNO0h7QPCnQFK4VgBY7CYoVqhRaFqwovFeUUjRS9FWcpFipWKB5UvKI4qCSnZKzkq8RSWqRUrXRE6ZbSsDJd2UY5QjlbeZXyHuWLys9VSCrGKv4qHJVilZ0qp1Ue0zG6Ad2XzqYvo++in6X3qxJVTVSDVTNUy1T3qXapDqmpqNmrxanNVatWO6bWy8AYxoxgRhZjDeMA4ybj0wTtCd4TuBNWTmiacHXCe/WJ6l7qXPVS9Wb1G+qfNJga/hqZGus0WjUeaOKa5prTNOdo1mie1RycqDrRbSJ7YunEAxPvaqFa5lpRWvO1dmp1ag1r62gHaudqb9Y+rT2ow9Dx0snQ2aBzXGdAl67rocvT3aB7QvcPphrTm5nFrGSeYQ7paekF6Yn0duh16Y3om+jH6hfpN+s/MKAYOBukGmww6DAYMtQ1nGq4wLDR8K6RnJGzUbrRJqPzRu+NTYzjjZcbtxo/N1E3CTYpNGk0uW9KM/U0zTOtNb1uRjRzNss022rWbY6aO5inm1ebX7FALRwteBZbLXomESa5TOJPqp10y5Jq6W1ZYNlo2WfFsAqzKrJqtXo52XBy0uR1k89P/mrtYJ1lvcv6no2KTYhNkU27zWtbc1u2bbXtdTuaXYDdYrs2u1f2FvZc+xr72w50h6kOyx06HL44OjkKHJscB5wMnZKdtjjdclZ1jnRe5XzBheDi47LY5ajLR1dH13zXA65/uVm6ZbrtcXs+xWQKd8quKY/d9d1Z7jvcez2YHske2z16PfU8WZ61no+8DLw4Xru9nnmbeWd47/V+6WPtI/A57PPe19V3oe9JP8wv0K/Ur8tfxT/Wv8r/YYB+QFpAY8BQoEPg/MCTQYSg0KB1QbeCtYPZwQ3BQyFOIQtDzoRSQ6NDq0IfhZmHCcLap6JTQ6aun3o/3CicH94aASKCI9ZHPIg0icyL/G0acVrktOppT6NsohZEnY+mR8+O3hP9LsYnZk3MvVjTWFFsR5xi3Iy4hrj38X7x5fG9CZMTFiZcTtRM5CW2JZGS4pJ2Jw1P95++cXr/DIcZJTNuzjSZOXfmxVmas7JmHZutOJs1+2AyITk+eU/yZ1YEq5Y1nBKcsiVliO3L3sR+wfHibOAMcN255dxnqe6p5anP09zT1qcNpHumV6QP8nx5VbxXGUEZ2zLeZ0Zk1mWOZsVnNWeTs5Ozj/BV+Jn8Mzk6OXNzenItcktye/Nc8zbmDQlCBbuFiHCmsC1fFV5zOkWmop9EfQUeBdUFH+bEzTk4V3kuf27nPPN5K+c9Kwwo/GU+Pp89v2OB3oKlC/oWei/csQhZlLKoY7HB4uLF/UsCl9QvpSzNXPp7kXVRedHbZfHL2ou1i5cUP/4p8KfGEoUSQcmt5W7Lt63AV/BWdK20W7l55ddSTumlMuuyirLPq9irLv1s83Plz6OrU1d3rXFcU7OWuJa/9uY6z3X15crlheWP109d37KBuaF0w9uNszderLCv2LaJskm0qbcyrLJts+HmtZs/V6VX3aj2qW7eorVl5Zb3Wzlbr9Z41TRt095Wtu3Tdt722zsCd7TUGtdW7CTuLNj5dFfcrvO/OP/SsFtzd9nuL3X8ut76qPozDU4NDXu09qxpRBtFjQN7Z+zt3ue3r63JsmlHM6O5bD/YL9r/x6/Jv948EHqg46DzwaZDRoe2HKYfLm1BWua1DLWmt/a2Jbb1HAk50tHu1n74N6vf6o7qHa0+pnZszXHK8eLjoycKTwyfzD05eCrt1OOO2R33Tiecvn5m2pmus6FnL5wLOHf6vPf5ExfcLxy96HrxyCXnS62XHS+3dDp0Hv7d4ffDXY5dLVecrrR1u3S390zpOX7V8+qpa37Xzl0Pvn75RviNnpuxN2/fmnGr9zbn9vM7WXde3S24O3JvyX3C/dIHSg8qHmo9rP2H2T+aex17j/X59XU+in507zH78Ysnwief+4uf0p5WPNN91vDc9vnRgYCB7j+m/9H/IvfFyGDJn8p/bnlp+vLQX15/dQ4lDPW/Erwafb3qjcaburf2bzuGI4cfvst+N/K+9IPGh/qPzh/Pf4r/9GxkzmfS58ovZl/av4Z+vT+aPTqayxKwJFcBDDY0NRWA13UA0BLh3aEbAIqC9O0lEUT6XpQg8J+w9H0mEUcA6rwAiF0CQBi8o9TAZgQxFfbiq3eMF0Dt7MabTISpdrbSWFT4giF8GB19ow0AqR2AL4LR0ZGto6NfdkGydwA4mSd984mFCO/3283EqKtTcS74Qf4JrF5srPmkm7gAAAAJcEhZcwAALiMAAC4jAXilP3YAAAIEaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJYTVAgQ29yZSA1LjQuMCI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDxleGlmOlBpeGVsWURpbWVuc2lvbj4yNjg8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MjY0PC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPHRpZmY6T3JpZW50YXRpb24+MTwvdGlmZjpPcmllbnRhdGlvbj4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+CpnH5CIAAAPJSURBVDgRVVRRTFtlFP56e4tSwFI62yXLQrWbEqtspECR6UIgkRgm8YmHPfDAg+FBjZEXMPiwiBoeJBqMJiQmsOAixpgsIYKwEmtIlulkIytOMLAxGSFdGy4rbW97b/t7zj9awrm59/7/Pef/zne+8//XksvlLgkhziuKkgBgtVgs9Dq0u7H7uLq5iPXUI7zuqsGb3mY8a3cgJwQH5yjSQRjfWQgkTJPzh0sPR3f2NvDZ3Z/wot2DgPM0rjxchM/uRt/LXXAq9mKgaZpfKNvb249jsRg2Nzf1RCJhklfea/EHZu21j8wf1r4260uqzbdONpu2/Yz56e1PzA8WvjTTRobj9AO0lNLT02OtqamB1+tVp6amVHLIe+HedfUUytS+6j7VWepQ8wLqOddL6ocn31Uvx66rq482CrEgWRTE4/FfqDwxOztrtLW18VDae3ND4mrkWmEqzBypcmDvzFwSs2u/88w4+DSkVlVVSXaBQAA7OzsIhUI488oZCC2Ln1MhZLI6/MdfQI3Hh9DqIqLJOMZ2buBCVRD/3XuATD4LbVeDQopLoMrKStTV1WHhtwVkM1kEHX5M3P8cXdMX8Hd0g+njq9s/4uLC20AyhRNPu6E91tDb24uGhgYoVqtVAqmqisbGRtz88yaMnIHj6jF8e3YSKPfhr4cRhP/9A3eIzaueHnzvfx8KSZ3S01j9ZxWjo6NQJMrBw+/3Y+7XOQjaSsecVXij+hy+Of0xrtwKoeXyRQTTLgw814XXvAHYniqBYRhwOp1ob2+XHSpi+Xw+Od7TNAi6Ent7aH0+iOYTZ6GoClRFBe0ZaAkNVquKra0ttLa2gtcdYeR2u9HS0oJkMgnqBkEB+3oSOgnOltJT0A0dgvZCnrTVKGF9fb3U7whQaWkpgsEgIpGIpFxRXg5npfPJuKICDocDjmcc4E6z+Nzh2tpamYQ3lTRmwOesqakJg4ODYFC73U7MgGw2I+esCZfGHV5eXsbMzAzGx8fl+iLQEziABV9ZWcHw8DCi0ShsNhvKysqQyWRQUlIiy2Fm6+vr6O7ulj5eWwQqnHo6Ktjd3SUWWUmfmebzecmWx7xNeM7GCdjydB3RiGkzAxZxbGwM4XAYLpcLHo8H3Ah+s01OTmJ6elqCyw+MS1nkWSMQg3a5SKfToqOjgxsm7/n5eQoRgvyC/QMDA0XfxMSEPGuk3VCREcUWS9nf35eJ+MElshVKp0Ryzg9dL/xFaEKZJCMCMqh2Ti6WlpZEZ2enGBkZEQQqvzEbNhJZ0K9H9Pf3C/qPSUbkG/ofgQYPGkB9aTMAAAAASUVORK5CYII=) no-repeat scroll center;\
        }\
        div#iGraphCartIcon.removeFromCartIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAATCAYAAACdkl3yAAAMFGlDQ1BJQ0MgUHJvZmlsZQAASImVVwdUk8kWnr+kEBJaIAJSQm+C9Cq9FwHpYCMkAUIJkBBU7MiigmtBRQRFRVdAFFwLIGvFriyCvT9QUVlZFws2VN6kgK6vnXfPmX++3Ln3zncnd+bMAKBozcrNzUKVAMjm5wuiAn2YCYlJTFIfIANdQAVE4MxiC3O9IyPDAJSx/u/y7iZAxP01S3Gsfx3/r6LM4QrZACCREKdwhOxsiA8BgKuzcwX5ABA6od5gTn6uGA9BrCqABAEg4mKcJsXqYpwixZMkNjFRvhB7AUCmsliCNAAUxLyZBew0GEdBzNGaz+HxId4CsQc7ncWB+D7Ek7KzcyBWJENsmvJdnLS/xUwZj8lipY1jaS4SIfvxhLlZrHn/53L8b8nOEo3NoQ8bNV0QFCXOGa5bfWZOqBhTIT7KTwmPgFgF4gs8jsRejO+mi4JiZfaDbKEvXDPAAAAFHJZfKMRaEDNEmbHeMmzLEkh8oT0azssPjpHhFEFOlCw+WsDPCg+TxVmRzg0ewzVcoX/0mE0qLyAYYlhp6KHC9Jh4KU/0TAEvLhxiBYi7hZnRoTLfh4XpvuFjNgJRlJizIcRvUwUBUVIbTD1bOJYXZsVmSeaCtYB55afHBEl9sQSuMCFsjAOH6+cv5YBxuPxYGTcMVpdPlMy3JDcrUmaP1XCzAqOk64ztFxZEj/lezYcFJl0H7FEGKyRSNte73PzIGCk3HAVhwBf4ASYQwZYCckAG4HUNtg7CX9KRAMACApAGuMBSphnziJeM8OE3GhSCPyHiAuG4n49klAsKoP7LuFb6tQSpktECiUcmeApxNq6Je+BueBj8esFmizvjLmN+TMWxWYn+RD9iEDGAaDbOgw1ZZ8EmALx/owuFPRdmJ+bCH8vhWzzCU0IP4RHhBqGXcAfEgSeSKDKr2bwiwQ/MmWAq6IXRAmTZpXyfHW4MWTvgPrg75A+54wxcE1ji9jATb9wT5uYAtd8zFI1z+7aWP84nZv19PjK9grmCg4xFyvg/4ztu9WMU3+/WiAP70B8tsRXYQew8dgq7iB3FWgETO4G1YZ3YMTEer4QnkkoYmy1Kwi0TxuGN2Vg3Wg9Yf/5hbpZsfvF6CfO5c/PFm8E3J3eegJeWns/0hqcxlxnMZ1tNYtpa2zgBID7bpUfHG4bkzEYYl77p8k4C4FIKlWnfdCwDAI48BYD+7pvO4DUs97UAHOtmiwQFUp34OAYEQAGKcFdoAB1gAExhPrbAEbgBL+APQkAEiAGJYBZc8XSQDTnPAQvAUlACysBasBFUgW1gJ6gH+8AB0AqOglPgHLgMusENcA/WRT94AYbAOzCCIAgJoSF0RAPRRYwQC8QWcUY8EH8kDIlCEpFkJA3hIyJkAbIMKUPKkSpkB9KA/IocQU4hF5Ee5A7Shwwgr5FPKIZSUVVUGzVGJ6POqDcaisagM9E0NA8tRIvR1WglWovuRVvQU+hl9Abai75AhzGAyWMMTA+zxJwxXywCS8JSMQG2CCvFKrBarAlrh//zNawXG8Q+4kScjjNxS1ibQXgszsbz8EX4KrwKr8db8DP4NbwPH8K/EmgELYIFwZUQTEggpBHmEEoIFYTdhMOEs3Df9BPeEYlEBtGE6AT3ZSIxgzifuIq4ldhMPEnsIT4mDpNIJA2SBcmdFEFikfJJJaTNpL2kE6SrpH7SB7I8WZdsSw4gJ5H55CJyBXkP+Tj5KvkZeUROSc5IzlUuQo4jN09ujdwuuXa5K3L9ciMUZYoJxZ0SQ8mgLKVUUpooZyn3KW/k5eX15V3kp8nz5JfIV8rvl78g3yf/kapCNaf6UmdQRdTV1DrqSeod6hsajWZM86Il0fJpq2kNtNO0h7QPCnQFK4VgBY7CYoVqhRaFqwovFeUUjRS9FWcpFipWKB5UvKI4qCSnZKzkq8RSWqRUrXRE6ZbSsDJd2UY5QjlbeZXyHuWLys9VSCrGKv4qHJVilZ0qp1Ue0zG6Ad2XzqYvo++in6X3qxJVTVSDVTNUy1T3qXapDqmpqNmrxanNVatWO6bWy8AYxoxgRhZjDeMA4ybj0wTtCd4TuBNWTmiacHXCe/WJ6l7qXPVS9Wb1G+qfNJga/hqZGus0WjUeaOKa5prTNOdo1mie1RycqDrRbSJ7YunEAxPvaqFa5lpRWvO1dmp1ag1r62gHaudqb9Y+rT2ow9Dx0snQ2aBzXGdAl67rocvT3aB7QvcPphrTm5nFrGSeYQ7paekF6Yn0duh16Y3om+jH6hfpN+s/MKAYOBukGmww6DAYMtQ1nGq4wLDR8K6RnJGzUbrRJqPzRu+NTYzjjZcbtxo/N1E3CTYpNGk0uW9KM/U0zTOtNb1uRjRzNss022rWbY6aO5inm1ebX7FALRwteBZbLXomESa5TOJPqp10y5Jq6W1ZYNlo2WfFsAqzKrJqtXo52XBy0uR1k89P/mrtYJ1lvcv6no2KTYhNkU27zWtbc1u2bbXtdTuaXYDdYrs2u1f2FvZc+xr72w50h6kOyx06HL44OjkKHJscB5wMnZKdtjjdclZ1jnRe5XzBheDi47LY5ajLR1dH13zXA65/uVm6ZbrtcXs+xWQKd8quKY/d9d1Z7jvcez2YHske2z16PfU8WZ61no+8DLw4Xru9nnmbeWd47/V+6WPtI/A57PPe19V3oe9JP8wv0K/Ur8tfxT/Wv8r/YYB+QFpAY8BQoEPg/MCTQYSg0KB1QbeCtYPZwQ3BQyFOIQtDzoRSQ6NDq0IfhZmHCcLap6JTQ6aun3o/3CicH94aASKCI9ZHPIg0icyL/G0acVrktOppT6NsohZEnY+mR8+O3hP9LsYnZk3MvVjTWFFsR5xi3Iy4hrj38X7x5fG9CZMTFiZcTtRM5CW2JZGS4pJ2Jw1P95++cXr/DIcZJTNuzjSZOXfmxVmas7JmHZutOJs1+2AyITk+eU/yZ1YEq5Y1nBKcsiVliO3L3sR+wfHibOAMcN255dxnqe6p5anP09zT1qcNpHumV6QP8nx5VbxXGUEZ2zLeZ0Zk1mWOZsVnNWeTs5Ozj/BV+Jn8Mzk6OXNzenItcktye/Nc8zbmDQlCBbuFiHCmsC1fFV5zOkWmop9EfQUeBdUFH+bEzTk4V3kuf27nPPN5K+c9Kwwo/GU+Pp89v2OB3oKlC/oWei/csQhZlLKoY7HB4uLF/UsCl9QvpSzNXPp7kXVRedHbZfHL2ou1i5cUP/4p8KfGEoUSQcmt5W7Lt63AV/BWdK20W7l55ddSTumlMuuyirLPq9irLv1s83Plz6OrU1d3rXFcU7OWuJa/9uY6z3X15crlheWP109d37KBuaF0w9uNszderLCv2LaJskm0qbcyrLJts+HmtZs/V6VX3aj2qW7eorVl5Zb3Wzlbr9Z41TRt095Wtu3Tdt722zsCd7TUGtdW7CTuLNj5dFfcrvO/OP/SsFtzd9nuL3X8ut76qPozDU4NDXu09qxpRBtFjQN7Z+zt3ue3r63JsmlHM6O5bD/YL9r/x6/Jv948EHqg46DzwaZDRoe2HKYfLm1BWua1DLWmt/a2Jbb1HAk50tHu1n74N6vf6o7qHa0+pnZszXHK8eLjoycKTwyfzD05eCrt1OOO2R33Tiecvn5m2pmus6FnL5wLOHf6vPf5ExfcLxy96HrxyCXnS62XHS+3dDp0Hv7d4ffDXY5dLVecrrR1u3S390zpOX7V8+qpa37Xzl0Pvn75RviNnpuxN2/fmnGr9zbn9vM7WXde3S24O3JvyX3C/dIHSg8qHmo9rP2H2T+aex17j/X59XU+in507zH78Ysnwief+4uf0p5WPNN91vDc9vnRgYCB7j+m/9H/IvfFyGDJn8p/bnlp+vLQX15/dQ4lDPW/Erwafb3qjcaburf2bzuGI4cfvst+N/K+9IPGh/qPzh/Pf4r/9GxkzmfS58ovZl/av4Z+vT+aPTqayxKwJFcBDDY0NRWA13UA0BLh3aEbAIqC9O0lEUT6XpQg8J+w9H0mEUcA6rwAiF0CQBi8o9TAZgQxFfbiq3eMF0Dt7MabTISpdrbSWFT4giF8GB19ow0AqR2AL4LR0ZGto6NfdkGydwA4mSd984mFCO/3283EqKtTcS74Qf4JrF5srPmkm7gAAAAJcEhZcwAALiMAAC4jAXilP3YAAAIEaVRYdFhNTDpjb20uYWRvYmUueG1wAAAAAAA8eDp4bXBtZXRhIHhtbG5zOng9ImFkb2JlOm5zOm1ldGEvIiB4OnhtcHRrPSJYTVAgQ29yZSA1LjQuMCI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDxleGlmOlBpeGVsWURpbWVuc2lvbj4yODA8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+MjY0PC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPHRpZmY6T3JpZW50YXRpb24+MTwvdGlmZjpPcmllbnRhdGlvbj4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+Cj1tM28AAANXSURBVDgRZVNLT1NREP7u7S19y0MIGF4SFkYWbuThg24IkeiKDVEhQYLoQhP1H2g0YcHCyBYXLjTSQHCpUQMLIgZcovERqUSsBNBgbaGWtvdevznYq42TTM65M3O+mW9mrmbbdr9lWYcApHQKT0dyvOWi72A9nYSV3oa+txL6qbPwVuxzYvIXjSCzmqaF84aCc+UT8HAM+PFt16xpQHUDMHAZCJUUhBoE+fnHkuZp2KYJzeVCKvYZO+FGYIXWUuo2tZgqmC9fIXj3AdzBEGDbABMYkUjEtbW1hWQyaYTDYaP58GFYjDVnX8De3w73zfPkR5LqgQ7LtmBeuIjclTcwjh79C+Ri9mAwiPn5eczNzWFiYgI6M5gfPkK/dBmh02cI+1ekb4mVGHJfYtCIgz9tNXp6elRUR0cHmpqa8DUWQ3VdHVLV1TBv3EJ2bQNazmTMLgWpKH3rJgIzM0izSi2dhquoCIbJnkhVxcXFONHVhbtjY+gdGMDqnhDq37+Fee0qpAq2WaDgoSbgwxeegdevcf/ePRw5dgy6gIh4PB5If6LLy/C73QgeOIBUJII1+rIIQSaRocao5pNH8FdUwGMYuH3njnqrcY8e03eSmpuenjY6OzuxtLSEn/E4/KWl2FldRXB9Hb82NhCorUO8fC+85eXIpVLYyWTQ0tKCaDQKgwCONDY2qrtMUUaaSSaBkhJ8DwTgazqIH+wVF0+BCM04k5WVlaGykovqoPBSVVWFtrY2bG9zizkNTSbC0btNCzpB9GxWAYld/Jubm+g/148AExUAeb1edLHhi4uL8Pv9irvX54PH54WcXtqK2EuJE6CFhQW0H29XtTjU2Cuy0dDa2oqRkRFVnUwyx4qyrESAM+yJTDkUCmGZQ3n2/BmGhoZ2SUmzqTb/uaycbJzQL1AurE0gm8DKzp6os7m52U4kEvLMdiqSakTq6+uxzimluWhSPhOoKsTPeLi5GiJy95Gu9EfEAZIPccpeSflTU1OoqalBd3e381hiZKLj4+MqTv4KSSDx8lhR46mosR92b2+vQ21ycpIuOmkXGR4ednyjo6PKJr6CqUlGEdnyvOQ3X2iK5L/l/q/tP2oG1/76jeuora1Fw/4GtQ7yKC+Dg4MKTOL6+vryZvwGSWqFaQfeFMUAAAAASUVORK5CYII=) no-repeat scroll center;\
        }\
        div#iGraphColorBlindFriendlyIcon{\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAAASdEVYdFNvZnR3YXJlAEdyZWVuc2hvdF5VCAUAAAEbSURBVDhPrVQxDsIwDHS6dEMVLEiwVDDxBt7CQ3hO39C3MCF1YWAgbcWOSs5xQhJRQMBJp9jx+eQ0bRURDYY/g42Gq02+hZoQZRJTu1lL9DnSHkzE1Mu1j0HUUj7TSu1RdALXNEZouq57beSEXKzOEZVSvlaWJethiNw/IwAPDZidjmQabBLgslhxDWiahvpbR0VRcA5414hmgvCYHJu9PM8jnTuFvf5hIDO2CQNUZ170fssrTyJ7tJvb1QB96Oej9X1PdV1zYRRPTIC2bSWS8UCtdTS2Ow7o46Dubk7yhxGYZRkX0MixGHmzxGTUCAwbHHH1WFFL9aKJN1OhiJhvNOOCVwy18Ig+2unBvmyfANrwo/3bb+RPPzaiO3OWgslMWGyFAAAAAElFTkSuQmCC) no-repeat scroll center;\
        }\
        div#iGraphSnapshotIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsEAAA7BAbiRa+0AAAASdEVYdFNvZnR3YXJlAEdyZWVuc2hvdF5VCAUAAAEVSURBVDhPpZOxDcIwEEUviBIqOliBJRALMAKhYwaHikSICegII7AAYgkKMkDomAH8D184B6cIeZJ1Z/v738lOIiJ62dEZNrJ8Zn8SRRH1XN6Zxo42SeIyn22auuwLOgIw8kiMcdkvoT14eB1JF6GqmrrO60hXQh6qXF/f73Yc4eFdNpwTW204GHC1VRx7QzpAR9Dei4LnoO9iRZZlaJEPjicTOj/ndDvMuAAOYw/RGEOPsnSn6Pf5IRBgAqbrK6Xq3qBBQU1lVFr3kECAmQCNLgi8jrQgP51oMbpwDnTeVJBvPl4uX1bALyBrkofWoMUZtfY1EoHEOnoPsdGoLdrI+7Lx5G045jlHfA6NP20bKqPPtAtEbw8iYxB46Q0cAAAAAElFTkSuQmCC) no-repeat scroll center;\
        }\
        div#iGraphCloudWatchServiceLogsIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACXBIWXMAAAsTAAALEwEAmpwYAAABWWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgpMwidZAAAEMUlEQVRIDbVVXWgcVRQ+d+bub3bT3W6TbGL+1zTZDaS0EUp8aDYP+iBUUNkFlYrQ0ELF0kXwBx8yDypEoS/SBxUpiCI0UMQHQRS61BDUtj4l/hRXacMmMTU/y+7M7mR+rufOZpKd7aYB0cOcufece+Y7555z7lyA/5nIfvipFIgAKevhtjPpGRMHtt93/3pdkiRBupakjMG+wXEnextxAALsxOODfT2jgefbY02LxHB/MX3224IdnSQlqSRldVtuNDZ0kEwmaTab1Z++MNpeWq3Mtsf8/Q8dDoBWMf5EkKuEsCvvTn73YyPAel1DB2jE9ezkqZE+zTQWwh0e2hUPmtQleESRQEXWdUJgDvnS9OnrV+pBa2WhVsC55fD48YeDT06OTEXjvg+ohzDMN7ejmmroHBytaCDsOWEyeNP+XpIsG1vcGR0OMDXYMQCBTrEXQSS3T3xMoMQPjHE7vkY5OI5bZVnDAYrIe2WBrzf2KpqCiWGva6pZYSa2JC+3kwRBwA6o6h/Yso4dODHAhbAuzPOeXU+qrVrv3AHzIAeAANXobCcNYsUzYaV1aqrx4WvoYMsRQ1XA1kQEHQxTA9PUwWQGlsbQpYnqOUjPpBpi8YLtUEtL1orR7/cTQrCI25vnbcTr7HMdAhd1A6aNiFQAXTBa3v78uRdluXDznfTMPNrhdxhJDTm83htOWpBffXZL03UNUQkIAgVKKazlVVi+rWL0gLvQxbJaZhVNHgDvxmXFWHmKYyK4A4/rHIqsVN3B9MevBtxuL61o60KhuASaUWFbFQ3y+UUoyEtQUu9BsbxMikqeyUoBopHBZg6GZFSH3bdVIBTtTmCnX3/ijbbWlvcSQ8OeruigWzQPCExQiYyg62vLrLWnCZiwRbw0DO2RONGLTWTlNz0xPjF2LjHWGvxpNnd9G97CrK0BV7D8Uq5nU853Hwx0Qm93TEkMxZk/eNSlKIor15ojkYNeOBSKMr8noCmyqv8wN0vdnXdCEAmG7txa7+fg/E9rtTfO7ci53nKQyoz5ShuFZ0vK6isGrCXCgSHoaj+sxvpiWrSjjbq8BDZLa/qmuuj6PfeLZ/7GzzBx8tFfO/rCr708fvVLDoRkYdkTS7P92lm4eDHjm7v9/Qul8sZ5zSwkyuW/oSUSV2NHD4DgLXqo6AFVFm9+88kfq/NzKyH8/mvkj5CXkXlt+cXk2AGXgf+0stkkcrW/M5mU727l7im1XDnvDprDA8dCeADpvGmI76cn+y8/Qj7kP6Ujza3iWaVodutl9gzKKvKOE5zfT9zRmTOjrt2VXm/6wrGXMpfGz+Hp9W7rxZGRtqZdG5jDed+2XFvfGpO6KXfEL6A6tSV2xpsHcPIp8lvIM8jTyDbxdN+fInu1fuSOFhZShN//nPDyt3v+CIpx5L+QryFz2qllVfxv31bkNuQ/6QmDzBSaM80AAAAASUVORK5CYII=) no-repeat scroll center;\
        }\
        div#iGraphCloudWatchApplicationLogsIcon {\
            background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACXBIWXMAAAsTAAALEwEAmpwYAAABWWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgpMwidZAAAEP0lEQVRIDbVVXWhcRRQ+M3f27k/uJtmmm2Zr/re2+cFKm4faB8u2oA9CCxZ2IYoitDaIoi2CtPiQ+1CFqFQQigSVPoVKYsUi9UnsYkoppRVLawqFEEmyCeZ/u393c3/GM3f3prtxk6DgsLNnzpkz33dmzpk7AP9zI1vhR6MgAUTtn/AdiY1YKPhW6/7zvKqqVL0eYZzDlsEJko2dBAABfujFPW0tPcqroXDVFDHlHwb6fk460alqhKlq3HD0SrIiQSQSYfF43Dh+uieUntNuhMK+9qd2K6Br5gSCfE8IH/7k5OjtSoDrbRUJ0EnY+dHX9rbplvlHYKebNXX6LeaibkkioGUMgxC4if3iwIlfh9eDluq0VMGxTXjgwC7/sZN7+xs6vYPMTTiet/Bjet40BDh6MSXgPmRx+NBZr6q2j6OuyTICPBqsGAClUWpFEFX2Si9QRnzAufATc0yAo1zNZXQUkMK+0SmI+cqskkUtDHtJz1sat7AkRbrLG6UUK6Bg37Rky3ZQjgEuhHXhOW9Y9aRQquvJy2A2IwAEKETnkFSIFe+Efaz9/ZUvX0WC1bIYCgqWJiIYYFo6WJYBFjcxNaahHi7cg9hItCKWSNhaCwbjdow+n48Qgkksbl6Ukciz17UdXEwGPDYiMQoGNYMfXX7ljUwmeefj2MgD9MN1GElJK2Od747YkD8N3dUNQ0dUApQyYIzBYiIPs4/yGD3gLgwpl89xTc8+Dd6VS1lz7mWBSWKkDE/YygxxtbCDgW8+UGTZwzR9iSZTM6CbGl/VdEgkpiCZmYF0fh5SuVmSyk7zx6kFCNXt8gswGAHTliV/doJQdyqBnzj70rkd9cFPuzq63U0Ne2TJqqGc5kkGQZcWZ3l9SxWGpRNZqoXG7d1EW/KRqftad9/Z4289d6zB98uVsdEino1ZmgNh4ImZ8ZaVTKJ5m9IIrc3hbFdHJ/f597my2axrvH6c1G1zQzAQ4m5WpQPlxsS93+WvP7taq7T/Vev1e5pF8JiyQsSI6EQu7DZB9MxBb3o52ZvOzr1vwmJXQOmAptDufLgtrDfs3MFcHgIr6UVjMTspzy9PyL/deGAFapq1mT+Xrt2+9kUvITEsL8TCe+iACuk0m0QoFy6c8d58dOv1dG75Xd1KduVyCxCs68yH99UA9abcFGSYn9RXR7+bHnr2SMP5K5/f78dlb2IXVS5yKx4m+/si5ForfLQi0uDgt6tjd6bvHj1y+FKewqRMA+0uHw8FmzyMWsrD6uravqtfjk2P31vY//DWHHcrtLe2no3mHlsJBBNHbxOsAa8fCKJTp3pcT+ytntjp/W+/d/H5d65z1cndj1V19Jy/nh1Ev8vYzxf9neJ5snyjkSASD9D6+faewDOeajpUYhckX5XoZVegxF55KIii0agUHY5KxffYjZ7eoreIWORPwf7vgIsAm4nSSvyH399InITuoxR4MwAAAABJRU5ErkJggg==) no-repeat scroll center;\
        }\
        div#iGraphCartIcon.iGraphHelperTopIcons {\
            float: left;\
            position: absolute;\
            left: 4px;\
        }\
        \
        .imgareaselect-border1, .imgareaselect-border2,\
        .imgareaselect-border3, .imgareaselect-border4 {\
            opacity: 0.5;\
            filter: alpha(opacity=50);\
        }\
        \
        .imgareaselect-handle {\
            background-color: #fff;\
            border: solid 1px #000;\
            opacity: 0.5;\
            filter: alpha(opacity=50);\
        }\
        \
        .imgareaselect-outer {\
            background-color: #000;\
            opacity: 0.5;\
            filter: alpha(opacity=50);\
        }\
        \
        .imgareaselect-selection {  \
            opacity: 0.5;\
            color: red;\
        }\
        #iGHmodalClose {\
            cursor: pointer;\
        }\
        #iGHmodalPage {\
            display: none;\
            position: fixed;\
            width: 100%;\
            height: 100%;\
            top: 0px; left: 0px;\
            font-family: Verdana, Arial, Helvetica, sans-serif;\
            color: #000000;\
            text-align: left;\
            z-index: 10; \
        }\
        .iGHmodalHeader a, .iGHmodalHeader a:visited, .iGHmodalHeader a:hover  {\
            color: #32719D;\
            background-color: transparent;\
            font-family: arial;\
            font-weight: normal;\
        }\
        #iGHmodalPage select {\
            vertical-align: top;\
            border-color: none;\
        }\
        .iGHmodalBackground {\
            filter: Alpha(Opacity=60); -moz-opacity:0.6; opacity: 0.6;\
            width: 100%; height: 100%; background-color: #999999;\
            position: absolute;\
            z-index: 500;\
            top: 0px; left: 0px;\
        }\
        .iGHmodalContainer {\
            position: absolute;\
            width: 760px;\
            left: 50%;\
            top: 50%;\
            z-index: 750;\
            font-size: 10px;\
        }\
        .iGHmodalHeader {\
            background-color: #EEE;\
        }\
        .iGHmodal {\
            background-color: white;\
            border: solid 1px black; position: relative;\
            top: -230px;\
            left: -380px;\
            width: 760px;\
            height: 460px;\
            z-index: 10000;\
            padding: 0px;\
        }\
        .iGHzooms {\
            float: right;\
        }\
        .iGHmodalTop {\
            width: 752px;\
            background:#5A7EAA url(https://monitorportal.amazon.com/images/header_background.png) repeat-x scroll 0 0;\
            padding: 4px;\
            color: #ffffff;\
            text-align: right;\
        }\
        .iGHperiod {\
            font-size: 9px;\
            margin-top: 4px;\
        }\
        .iGHmodalLeft {\
            float: left; \
        } \
        .iGHinstructions {\
            position:absolute;\
        }\
        .iGHmodalRight {\
            float: right; \
        } \
        .iGHmodalTop a, .iGHmodalTop a:visited, .iGHmodalTop a:hover  {\
            font-size: 10px;\
            color: #ffffff;\
            background-color: transparent;\
        }\
        .iGHmodalBody {\
            width: 760px;\
            height: 426px;\
        }\
        #iGHaddToMyGraphs {\
            display: inline; \
            margin: 8px 5px 0px 10px;\
        }\
        #iGHaddToMyGraphs span {\
            width: 100px;\
        }\
        .iGHwikiView {\
            cursor: pointer;\
        }\
        #iGHsnapshotWiki {\
            margin-left: 63px;\
        }\
        #iGHsnapshotS3-button, #iGHsnapshotWiki-button, #iGHsnapshotNewWiki-button, #iGHsnapshotTT-button, #iGHsnapshotSIM-button, #iGHsnapshotJIRA-button, #iGHsnapshotMCM-button {\
            margin-left: auto;\
            margin-right: auto;\
            text-align: center;\
        }\
        #iGHsnapshotS3, #iGHsnapshotWiki, #iGHsnapshotNewWiki, #iGHsnapshotTT, #iGHsnapshotSIM, #iGHsnapshotJIRA, #iGHsnapshotMCM,\
        #iGHsnapshotS3 .first-child, #iGHsnapshotWiki .first-child, #iGHsnapshotNewWiki .first-child, #iGHsnapshotTT .first-child, #iGHsnapshotSIM .first-child, #iGHsnapshotJIRA .first-child, iGHsnapshotMCM .first-child {\
            width: 150px;\
        }\
        #iGHsnapshotS3, #iGHsnapshotWiki, #iGHsnapshotNewWiki, #iGHsnapshotTT, #iGHsnapshotSIM, #iGHsnapshotJIRA, #iGHsnapshotMCM {\
            margin-top: 5px;\
        }\
        .iGHlabel {\
            cursor: pointer;\
        }\
        button.iGHbutton:active, a.button.iGHbutton:active, input.iGHbutton[type="submit"]:active, input.iGHbutton[type="reset"]:active {\
            -moz-box-shadow:none;\
            color:black !important;\
            text-decoration:none !important;\
            top:1px;\
        }\
        button.iGHbutton, input.iGHbutton[type="submit"], input.iGHbutton[type="reset"] {\
            height:19px;\
            cursor: pointer;\
        }\
        button.iGHbutton, a.button.iGHbutton, input.iGHbutton[type="submit"], input.iGHbutton[type="reset"] {\
            -moz-background-clip:border;\
            -moz-background-inline-policy:continuous;\
            -moz-background-origin:padding;\
            -moz-border-radius-bottomleft:6px;\
            -moz-border-radius-bottomright:6px;\
            -moz-border-radius-topleft:6px;\
            -moz-border-radius-topright:6px;\
            -moz-box-shadow:1px 1px 2px rgba(0, 0, 0, 0.15);\
            background:#D4D484 url(https://monitorportal.amazon.com/images/lib/dtux.amazon.com/secondary_action_button_bg.png) repeat-x scroll 0 0;\
            border-color:#959567 #898958 #7C7C4D;\
            border-style:solid;\
            border-width:1px;\
            color:black !important;\
            display:inline-block;\
            font-family:Lucida Sans Unicode,Lucida Grande,Verdana,Arial,sans-serif;\
            font-size:11px !important;\
            line-height:15px !important;\
            margin:0;\
            overflow:visible;\
            padding:0 6px;\
            position:relative;\
            text-decoration:none;\
            text-shadow:0 1px 0 rgba(255, 255, 255, 0.5);\
            vertical-align:middle;\
            margin: 3px;\
        }\
        span.iGHrefreshAll {\
            top: -2px;\
            position: relative;\
        }\
         .iGHwidget {\
         }\
        .iGHmenuArea {\
            -moz-background-clip: border;\
            -moz-background-inline-policy: continuous;\
            -moz-background-origin: padding;\
            -moz-border-radius-bottomleft:8px;\
            -moz-border-radius-bottomright:8px;\
            -moz-border-radius-topleft:8px;\
            -moz-border-radius-topright:8px;\
            background-color: #EAF3FE;\
            border: 1px solid #CCCCCC;\
            padding: 5px 0px;\
            margin-top: 5px;\
         }\
        .iGHmenuArea select {\
            vertical-align: inherit;\
         }\
         .iGHmenuTitle {\
            padding-left: 10px;\
         }\
         .iGHmenuLink {\
            font-size: 9px;\
            padding-left: 10px;\
         }\
         .iGHradio {\
            -moz-background-clip: border;\
            -moz-background-inline-policy: continuous;\
            -moz-background-origin: padding;\
            -moz-border-radius-bottomleft:4px;\
            -moz-border-radius-bottomright:4px;\
            -moz-border-radius-topleft:4px;\
            -moz-border-radius-topright:4px;\
            background-color: white;\
            font-size: 10px;\
            border: 1px solid #CCCCCC;\
            display: inline-block;\
            padding: 4px 6px 0px 2px;\
            height: 18px;\
         }\
         .iGHradio input {\
            margin-top: 0px;\
         }\
         .iGHradio label {\
            top: -3px;\
            position: relative;\
            cursor: pointer;\
         }\
         .iGHcopyPasteTimeRanges {\
             text-align: right;\
             position: absolute;\
             right: 20px;\
         }\
         .iGHextraOptionsWide {\
            position: relative;\
            left: -500px;\
            width: 850px;\
            max-width: 850px;\
        }\
        .iGHicon {\
             cursor: pointer;\
             margin: 1px 3px 0 3px;\
             font-size: 1.2em;\
         }\
         .timeRangesResetIcon.iGHicon {\
             margin: 1px 1px 0 1px;\
         }\
         .metricMathEnlargeIcon, .metricMathReduceIcon {\
            font-size: 1.5em;\
         }\
        ';

    var isIgraph = false;
    var ICON_WIDTH = 18;
    var LOADER_IMAGE = "data:image/gif;base64,R0lGODlhyAA8APMAAAAAAH9/fzMzM7+/v4+Pj09PTw8PD8zMzK+vrz8/P9/f329vbx8fH5+fn19fX////yH5BAEHAA8ALAAAAADIADwAAAT+8MlJq7046827/2AojmRpnmiqrmzrvnAsz3Rt33iu73zv/8CgcEgsGo/IpHLJbDqf0Kh0Sq1ar9isdsvter/gsPimGAwUyYOZoh6MfQEAIJBMyCl2wLsXn9fvE3l7PH10SIITDQGGgzmFf3qNQI+HgJJwcoweBwSLCGgZZYsBBG6higEHEogSbWxrDwqophiyi6oPrpcVlB0IDHLBBpoTCg7ByAYEFsbIAAkKrA/Sgn3BDLgUzcgCB9K7D70bx87B0GwG5cjLxQLqAu6Rq5bTcuTOBqASCvH4wPLgwmXyFSwAGlnpACzAI6eAKQUI4hmgUECOAAQSGvyjRy3YRQn+CBI6oLBADgOMD34hCzhBXIaEDSocSAjqgJwEzILhsglAgL5YCQF27PmTJ4NiJn8q2MhSgssLCOxdaCBn4YMBCxLQYgjAVEkAKClQ5UgWQMwK/yYQkHOWQlR64J5a6BNWm0UO/OSY+rYvGFeuP+fJ4yshYVOBfjbkCTwh3gUzARzk0SvhJgbHgcpeYAVMAAbCkuRWAF0P4ICK6ig/sLxZc2aAryewtkB6kOi/ny2NTZaAQDxTs0e7FtxaXnDcLG9PQM1YArCJV4M5aLA1j6l0Ry9gJh6btiV30C1sD6jcKdsLCliTqzvhnynmOYeXLj6BHOP0cHeVz3XcPAB2hA3+EIwpayUmll/dcSecPG+NxAuCyQ3EQTwOJhIMKKhtdVVQDyW01UwQzpcgcg/8w05GKzXVRwKjtDhKTeZQh8A9jIxlwAJmNHDPeSjaY8YC6Rg2ImHSCGjRIv3Q400CbbWSAJMyPdlkFNakptoDDQTljFWNpdabhBJ85Yxk8hEJ127IJDCekcSwWYGbVFRp5VbbBOMQM0ByE5MC6XhGwQD9DCOigoOSuI8D/wgQU5FgSgDnBI9KYoaGF7TRHHqw6GBHeIdJskABxEyQDk6dXkLOlIidWOogNhJQEzn5rGqqlWDJqp+WN2Vj6yUDjNLApbsGK+ywxBZr7LHIJqvssswQNuvss9BGK+201FZrbRYRAAA7";
    var graphsFound = false;
    var stylesInitialized = false;
    var modalCreated = false;
    var iconsCreated = false;
    var ticketGraphCache = {
        currentGraph: null,
        graphParams: {}
    };

    function initialize() {
        _ighDebug('init', 'initialize | images=' + document.images.length);
        IGH.WikiHtml.initialize();
        IGH.WikiEditor.initialize();
        IGH.MetricSchemas.initialize();
        IGH.PortalGraphZoomer.initialize();
        IGH.PortalGraphSelector.initialize();
        IGH.loadingImage = new Image();
        IGH.loadingImage.src = LOADER_IMAGE;
        decorateGraphs();
        createIGraphLinks();
        IGH.IGraphUpdates.initialize();
        IGH.WikiCart.initialize();
        IGH.TT.initialize();
        OCLSettingsManager.setOCLConfigInitialValue();
        document.addEventListener("keydown", checkKeyPress, false);
        iGraphHelper = { initialize, decorateGraphs, IGH };
    }

    function setStyles() {
        if (!stylesInitialized) {
            // Setup styles for the links
            stylesInitialized = true;
            IGH.WikiWidgets.initialize();
            addStyle(STYLES);
        }
    }

    function checkKeyPress(e) {
        // Check for Ctrl-Alt-G
        if (e.ctrlKey && e.altKey && ((e.which == 103) || (e.which == 71))) {
            decorateGraphs();
        }
    }

    function goToCloudWatchConsole(logType) {
        _ighDebug('ocl', 'goToCloudWatchConsole', { logType: logType });
        if (IGH.hoveredImage) {
            return OCLLinksManager.goToCloudWatchConsole(logType, getFullGraphUrl());
        }
        return false;
    }

    function iconClicked(baseUrl) {
        _ighDebug('action', 'iconClicked', { baseUrl: baseUrl });
        if (IGH.hoveredImage) {
            window.open(getFullGraphUrl(baseUrl));
        }
        return false;
    }

    function getFullGraphUrl(baseUrl) {
        var graphArgs = getGraphArgs(IGH.hoveredImage, false);
        return baseUrl + graphArgs;
    }

    function maximizeClicked(graphParams) {
        _ighDebug('action', 'maximizeClicked');
        var img = MonitorPortalRoot + "/mws?Action=GetGraph&Version=2007-07-07&";
        img += removeQueryParams(graphParams, ["WidthInPixels", "HeightInPixels", "Action", "Version", "ShowLegend", "ShowXAxisLabel"]);
        revealModal(img);
    }
    function removeQueryParams(url, paramList) {
        var newUrl = url;
        for (var i = 0; i < paramList.length; i++) {
            var re = new RegExp(paramList[i] + "(=|%3D)[^&]*", "gi");
            newUrl = newUrl.replace(re, "");
        }
        return newUrl;
    }
    function extractQueryValue(url, param) {
        var re = new RegExp(param + "=([^&]*)");
        if (null !== url.match(re)) {
            return RegExp.$1;
        }
        return null;
    }

    function createModal() {
        if (modalCreated) {
            return;
        }
        _ighDebug('ui', 'createModal');
        var modalContainer = document.createElement("div");
        modalContainer.innerHTML = '\
                <div id="iGHmodalPage" style="display: none;">\
                    <div class="iGHmodalBackground">\
                    </div>\
                    <div class="iGHmodalContainer">\
                        <div class="iGHmodal">\
                            <div class="iGHmodalTop">\
                                <div class="iGHmodalLeft"><a href="https://w.amazon.com/?IGraphHelper" target="_blank">iGraph Helper</a> - Magnifier (click and drag to zoom in)</div>\
                                <div class="iGHmodalRight"><a id="iGHmodalClose" href="">Esc or [X]</a></div>\
                                <div style="clear: both;"></div>\
                            </div>\
                            <div class="iGHmodalHeader">\
                                <input type="submit" value="View in iGraph" class="iGHbutton" id="iGHviewInIGraph">\
                                <input type="submit" value="View in Zoomer" class="iGHbutton" id="iGHviewInZoomer">\
                                <input type="submit" value="Snapshot" class="iGHbutton" id="iGHSnapshot">\
                                <span class="iGHzooms">\
                                    <input type="submit" value="Apply Selection to All Graphs" class="iGHbutton" id="iGHapplyToAll">\
                                    &nbsp;&nbsp;Period: \
                                        <select class="iGHperiod" name="iGHperiod">\
                                            <option value="">Select...</option>\
                                            <option value="OneMinute">1 Minute</option>\
                                            <option value="FiveMinute">5 Minutes</option>\
                                            <option value="OneHour">1 Hour</option>\
                                            <option value="OneDay">1 Day</option>\
                                            <option value="OneWeek">1 Week</option>\
                                        </select>\
                                    &nbsp;Zoom: <a>1h</a> | <a>3h</a> | <a>8h</a> | <a>1d</a> | <a>1w</a> | <a>2w</a> | <a>30d</a> | <a>3m</a> | <a>1y</a>&nbsp;\
                                    <input type="submit" value="Refresh" class="iGHbutton" id="iGHrefresh">\
                                </span>\
                            </div>\
                            <div class="iGHmodalBody">\
                                <img id="iGHimage" title="When the graph loads, select and drag to zoom in to a time range. Use the _Apply Selection to All Graphs_ button to apply your time range and period selection to all graphs on the underlying page">\
                            </div>\
                        </div>\
                    </div>\
                </div>';
        document.body.insertBefore(modalContainer, document.body.firstChild);
        jQuery('#iGHmodalPage').on('click', hideModal);
        jQuery(document).on('keydown', function(e) {
            if (e.keyCode == 27) {
                hideModal();
            }});
        jQuery('.iGHmodalContainer').on('click', function() {return false;});
        jQuery('#iGHmodalClose').on('click', hideModal);
        jQuery('#iGHapplyToAll').on('click', applyToAll);
        jQuery('#iGHrefresh').on('click', refresh);
        jQuery('#iGHviewInIGraph').on('click', function() {viewGraphInOtherPage(IGRAPH_LINK.url);});
        jQuery('#iGHviewInZoomer').on('click', function() {viewGraphInOtherPage(IGRAPH_ZOOMER_LINK.url);});
        jQuery('#iGHSnapshot').on('click', function() {
            var graphArgs = window.MPW.getGraphArgs(window.MPW.getImageUrlWithSelectedPeriod(jQuery('#iGHimage')[0]));
            WikiSnapshot.snapshotDisplayInPopup(Lightbox.display, graphArgs);
        });
        jQuery('#iGHmodalPage select[name="iGHperiod"]').on('change', setPeriodAcrossImage);
        jQuery('a', '.iGHzooms').attr('href', '#').on('click', function() {setTime.call(this, jQuery("#iGHimage")[0]); return false;});
        modalCreated = true;
    }

    function getModalImage() {
        var modalImage =  jQuery("#iGHimage");
        if (modalImage.length === 1) {
            return modalImage[0];
        }
        return undefined;
    }

    function loadingImg(img) {
        const width = extractQueryValue(img.src, 'WidthInPixels') || img.clientWidth;
        const height = extractQueryValue(img.src, 'HeightInPixels') || img.clientHeight;
        img.src = LOADER_IMAGE;
        if (width && height) {
            img.width = width;
            img.height = height;
            img.style.width  = `${width}px`;
            img.style.height = `${height}px`;
        }
    }

    function setTimeRangeForGraph(url, start, end) {
        let newImgUrl;

        if (IGH.util.isCloudWatchGraph(url)) {
            const metricWidget = IGH.util.getMetricWidgetFromUrl(url);
            metricWidget.start = start;
            metricWidget.end = end;
            const metricWidgetStr = IGH.util.metricWidgetToJsonUrlParam(metricWidget);
            newImgUrl = removeQueryParams(url, ['metricWidget', 'start', 'end']);
            newImgUrl += `&metricWidget=${metricWidgetStr}`;
        } else {
            newImgUrl = removeQueryParams(url, ["StartTime1", "EndTime1"]);
            newImgUrl += `&StartTime1=${start}&EndTime1=${end}`;
        }

        return newImgUrl;
    }

    function setTime(img) {
        const TIMES = { '1h': '-PT1H', '3h': '-PT3H', '8h': '-PT8H', '1d': '-P1D', '1w': '-P7D', '2w': '-P14D', '30d': '-P30D', '3M': '-P90D', '1y': '-P365D' };
        const newStart = TIMES[jQuery(this).text()];
        const newImgUrl = setTimeRangeForGraph(img.src, newStart, 'P0D');
        loadingImg(img);
        img.src = cleanImgUrl(newImgUrl);
    }

    function viewGraphInOtherPage(baseUrl) {
        var imgUrl = getModalImage().src;
        window.open(baseUrl + imgUrl.replace(/.*[?]/, ""), "_blank");
    }

    function setPeriodAcrossImage() {
        var img = getModalImage();
        var newImg = getImageUrlWithSelectedPeriod(img.src);
        loadingImg(img);
        img.src = cleanImgUrl(newImg);
    }

    function getImageUrlWithSelectedPeriod(imgUrl) {
        var period = getSelectedPeriod();
        if (period !== null && period.length > 0) {
            return imgUrl.replace(/(\bPeriod\d*=)[^&]*/g, "$1" + period);
        }
        return imgUrl;
    }

    function getSelectedPeriod() {
        return jQuery('select[name="iGHperiod"] option:selected', '#iGHmodalPage').val();
    }
    function setSelectedPeriod(period) {
        jQuery('select[name="iGHperiod"] option[value="' + period + '"]', '#iGHmodalPage').prop("selected", "selected");
    }

    function refresh() {
        _refreshImg(getModalImage());
    }

    function _refreshImg(img) {
        var newImgUrl = removeQueryParams(img.src, ['iGHrefresh']);
        newImgUrl += /[?]/.test(newImgUrl) ? '' : '?';
        newImgUrl += '&iGHrefresh=' + new Date().valueOf();
        loadingImg(img);
        img.src = cleanImgUrl(newImgUrl);
    }

    function refreshAll() {
        _ighDebug('action', 'refreshAll');
        if (isIgraph) {
            MP.GraphSection.displayGraph();
        }
        else {
            for (i = 0; i < document.images.length; i++) {
                var image = document.images[i];
                var searchString = getGraphArgs(image, true);
                if (searchString != null) {
                    loadingImg(image);
                    var newUrl = MonitorPortalRoot + "/mws?Action=GetGraph&Version=2007-07-07&";
                    newUrl += removeQueryParams(searchString, ["Action", "Version", "iGHrefresh"]);
                    newUrl += "&iGHrefresh=" + new Date().valueOf();
                    image.src = cleanImgUrl(newUrl);
                }
            }
        }
    }

    function applyToAll() {
        hideModal();
        var timeRange = getImageTimeRange();
        if (isIgraph) {
            var model = MP.graph.model();
            model.timeRanges().clear();
            var rangeType = IGH.TimeRangeUtils.isDuration(timeRange.startTime) ? MP.MWS.TimeRangeType.RELATIVE : MP.MWS.TimeRangeType.FIXED;
            model.timeRanges().add(model.createTimeRange(rangeType, timeRange.startTime, timeRange.endTime));
            MP.GraphSection.displayGraph();
        }
        else {
            for (i = 0; i < document.images.length; i++) {
                var image = document.images[i];
                var searchString = getGraphArgs(image, true);
                if (searchString != null) {
                    loadingImg(image);
                    var newUrl = MonitorPortalRoot + "/mws?Action=GetGraph&Version=2007-07-07&";
                    newUrl += removeQueryParams(searchString, ["Action", "Version", "StartTime1", "EndTime1"]);
                    newUrl += "&StartTime1=" + timeRange.startTime + "&EndTime1=" + timeRange.endTime;
                    newUrl = getImageUrlWithSelectedPeriod(newUrl);
                    image.src = cleanImgUrl(newUrl);
                }
            }
            decorateGraphs(true);
        }
    }

    function getImageTimeRange() {
        var imgUrl = getModalImage().src;
        return {startTime: extractQueryValue(imgUrl, "StartTime1"),
            endTime: extractQueryValue(imgUrl, "EndTime1")};
    }

    function revealModal(img) {
        createModal();
        var modalSize = sizeModal();
        var imgWidth  = modalSize.width - 2;
        var imgHeight = modalSize.height - 46;
        img += "&WidthInPixels=" + imgWidth + "&HeightInPixels=" + imgHeight;
        var period = extractQueryValue(img, "Period1");
        if (period) {
            setSelectedPeriod(period);
        }
        jQuery('#iGHmodalPage').show();
        getModalImage().width = imgWidth;
        getModalImage().height = imgHeight;
        loadingImg(getModalImage());
        jQuery('#iGHimage').attr("src", cleanImgUrl(img));
        iGraphResizer(getModalImage(), zoomGraph, imgHeight);
    }

    function zoomGraph(x, width, zoomLevel) {
        var imageTimeRange = getImageTimeRange();
        var now = new Date();
        var minutesRange = IGH.TimeRangeUtils.getTimeRangeInMinutes(now, imageTimeRange);

        var startDuration, endDuration;

        var centerSpot = minutesRange.startTime - Math.floor((minutesRange.startTime - minutesRange.endTime) * x / width);
        var halfDuration = Math.floor((minutesRange.startTime - minutesRange.endTime) * zoomLevel / 2);
        var newStartMinutes = centerSpot + halfDuration;
        var newEndMinutes = centerSpot - halfDuration;

        if (newEndMinutes >= newStartMinutes) {
            newEndMinutes = newStartMinutes - 1;
        }

        var newStartDuration = IGH.TimeRangeUtils.getDurationFromControl(
          IGH.TimeRangeUtils.UNITS.MINUTE, newStartMinutes);
        var newEndDuration   = IGH.TimeRangeUtils.getDurationFromControl(
          IGH.TimeRangeUtils.UNITS.MINUTE, newEndMinutes);
        var newStart = IGH.TimeRangeUtils.getXMLCalendarFromDuration(new Date(), newStartDuration);
        var newEnd   = IGH.TimeRangeUtils.getXMLCalendarFromDuration(new Date(), newEndDuration);

        var img = getModalImage();
        var imgUrl = img.src;
        var newImg = removeQueryParams(imgUrl, ["StartTime1", "EndTime1"]);
        newImg += "&StartTime1=" + newStart + "&EndTime1=" + newEnd;
        loadingImg(img);
        img.src = cleanImgUrl(newImg);
    }

    function cleanImgUrl(imgUrl) {
        var newImg = removeQueryParams(imgUrl, ["actionSource", "actionSource1", "NoRedirect"]);
        newImg += "&actionSource=iGraphHelper&NoRedirect=1";
        return newImg.replace(/[&]+/g, "&");     // Replace contiguous &'s with single &
    }

    function hideModal() {
        jQuery('#iGHmodalPage').hide();
    }

    function sizeModal() {
        var TOP_BOTTOM_MARGIN = 50;
        var SIDE_MARGIN = 100;
        var MODAL_TOP_MARGIN = 8;
        var MODAL_BODY_MARGIN = 46;

        var windowSize  = IGH.getWindowSize();
        var modalWidth  = windowSize.width - (2 * SIDE_MARGIN);
        var modalHeight = windowSize.height - (2 * TOP_BOTTOM_MARGIN);
        jQuery(".iGHmodalContainer").width(modalWidth);
        jQuery(".iGHmodal").css("top", -(modalHeight/2)).css("left", -(modalWidth/2)).width(modalWidth).height(modalHeight);
        jQuery(".iGHmodalTop").width(modalWidth - MODAL_TOP_MARGIN);
        jQuery(".iGHmodalBody").width(modalWidth).height(modalHeight - MODAL_BODY_MARGIN);

        return {width: modalWidth, height: modalHeight};
    }
    
    function isFeatureEnabled(cookieName) {
        var cookies = document.cookie.split('; ');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            if (cookie.indexOf(cookieName + '=') === 0) {
                var cookieValue = cookie.substring(cookieName.length + 1);
                return cookieValue === "true";
            }
        }
        return false;
    }

    function createIcons() {
        if (iconsCreated) {
            return;
        }
        _ighDebug('ui', 'createIcons');
        var iconContainer = document.createElement("div");
        iconContainer.innerHTML = `
          <div id="iGraphBackgroundTop" class="iGraphBackground">
            <div id="iGraphMaximizeIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="Maximize - Display this graph maximized (iGraphHelper)"></div> 
            <div id="iGraphIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="iGraph - Display this graph in iGraph (iGraphHelper)"></div>
            <div id="iGraphObserveIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="iGraph - Display this graph in Observe (iGraphHelper)"></div>
            <div id="iGraphZoomerIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="iGraph Zoomer - Display this graph in iGraph Zoomer tool (iGraphHelper)"></div>
            <div id="iGraphDataTableIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="iGraph Data Table - See the data for this graph (iGraphHelper)"></div>
            <div id="iGraphCSVIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="CSV - Download the CSV data for the graph (iGraphHelper)"></div>
            <div id="iGraphColorBlindFriendlyIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="Color Blind Friendly - Convert graph to color blind friendly colors (iGraphHelper)"></div>
            <div id="iGraphSnapshotIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="Snapshot - Take a snapshot of graph image (iGraphHelper)"></div>
            <div id="iGraphCloudWatchApplicationLogsIcon" class="iGraphHelperIcons iGraphHelperTopIcons OCLIcons" title="CloudWatch - Go to Cloudwatch application logs for this graph"></div>
            <div id="iGraphCloudWatchServiceLogsIcon" class="iGraphHelperIcons iGraphHelperTopIcons OCLIcons" title="CloudWatch - Go to Cloudwatch service logs for this graph"></div>
            <div id="iGraphCartIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="Buy Now - Add to iGraph Shopping Cart, for merging with other graphs in cart (iGraphHelper)"></div>
          </div>
          <div id="iGraphBackgroundLeft" class="iGraphBackground"></div>
          <div id="iGraphBackgroundRight" class="iGraphBackground"></div>
          <div id="iGraphBackgroundBottom" class="iGraphBackground">
            <div id="iGraphRefreshIcon" class="iGraphHelperIcons iGraphHelperBottomIcons" title="Refresh - Refresh this graph (iGraphHelper)"></div>
            <div class="iGraphHelperZoom"><a>1h</a>|<a>3h</a>|<a>8h</a>|<a>1d</a>|<a>1w</a>|<a>2w</a>|<a>30d</a>|<a>3m</a>|<a>1y</a></div>
          </div>
        `;
        document.body.insertBefore(iconContainer, document.body.firstChild);

        jQuery('#iGraphIcon')[0].addEventListener('click', () =>
            expandUrlForSnapshotGraphs(IGH.hoveredImage, false,(imgUrl) => {
                if (IGH.util.isCloudWatchGraph(imgUrl)) {
                    window.open(IGH.util.getConsoleUrl(imgUrl));
                } else {
                    return iconClicked(IGRAPH_LINK.url);
                }
            }),
          false);

        jQuery('#iGraphObserveIcon')[0].addEventListener('click', () =>
            expandUrlForSnapshotGraphs(IGH.hoveredImage, false, (imgUrl) => {
                if (IGH.util.isCloudWatchGraph(imgUrl)) {
                    window.open(IGH.util.getObserveUrl(imgUrl));
                } else {
                    return iconClicked(IGRAPH_LINK.url);
                }
            }),
            false);

        jQuery('#iGraphZoomerIcon')[0].addEventListener('click', () =>
          expandUrlForSnapshotGraphs(IGH.hoveredImage, false,(imgUrl) => {
              if (IGH.util.isCloudWatchGraph(imgUrl)) {
                  window.open(IGH.util.getConsoleUrl(imgUrl));
              } else {
                  return iconClicked(IGRAPH_ZOOMER_LINK.url);
              }
          }), false);

        jQuery('#iGraphDataTableIcon')[0].addEventListener('click', () =>
          expandUrlForSnapshotGraphs(IGH.hoveredImage, false, (imgUrl) => {
              if (IGH.util.isCloudWatchGraph(imgUrl)) {
                  alert('Display as Data Table is not supported for CloudWatch graphs')
              } else {
                  return iconClicked(IGRAPH_DATA_TABLE_LINK.url);
              }
          }), false);

        jQuery('#iGraphCSVIcon')[0].addEventListener('click', () =>
          expandUrlForSnapshotGraphs(IGH.hoveredImage, false,(imgUrl) => {
              if (IGH.util.isCloudWatchGraph(imgUrl)) {
                  alert('Export as CSV data is not supported for CloudWatch graphs')
              } else {
                  return iconClicked(IGRAPH_CSV_LINK.url);
              }
          }), false);

        jQuery('#iGraphColorBlindFriendlyIcon')[0].addEventListener('click',  () =>
          expandUrlForSnapshotGraphs(IGH.hoveredImage, false, () => {
              if (IGH.hoveredImage) {
                  var graphUrl = isIgraph ? getGraphUrl() : getGraphArgs(IGH.hoveredImage, false);
                  WikiSnapshot.displayColorBlindFriendly(IGH.hoveredImage, graphUrl);
              }
              return false;
          }),
        false);

        jQuery('#iGraphSnapshotIcon')[0].addEventListener('click',  () =>
            expandUrlForSnapshotGraphs(IGH.hoveredImage, false, () => {
                if (IGH.hoveredImage) {
                    var graphUrl = isIgraph ? getGraphUrl() : getGraphArgs(IGH.hoveredImage, false);
                    WikiSnapshot.snapshotDisplayInPopup(IGH.util.lightbox, graphUrl, getSnapshotSizeMessage());
                }
                return false;
            }),
          false);

        jQuery('#iGraphCloudWatchApplicationLogsIcon')[0].addEventListener('click', function() { return goToCloudWatchConsole(OCLLinksManager.APPLICATION_LOG_KEY); }, false);
        jQuery('#iGraphCloudWatchServiceLogsIcon')[0].addEventListener('click', function() { return goToCloudWatchConsole(OCLLinksManager.SERVICE_LOG_KEY); }, false);

        jQuery('#iGraphMaximizeIcon')[0].addEventListener('click', () =>
          expandUrlForSnapshotGraphs(IGH.hoveredImage, false,(imgUrl) => {
              if (IGH.util.isCloudWatchGraph(imgUrl)) {
                  alert('Maximize is not supported for CloudWatch graphs')
              } else {
                  maximizeClicked(getGraphArgs(IGH.hoveredImage, false));
              }
          }), false);

        jQuery('#iGraphCartIcon')[0].addEventListener('click', function() {
            const self = this;
            expandUrlForSnapshotGraphs(IGH.hoveredImage, false,() => {
                var graphUrl = isIgraph ? getGraphUrl() : getGraphArgs(IGH.hoveredImage, false);
                return jQuery(self).hasClass('addToCartIcon') ? IGH.WikiCart.addGraphToCart(graphUrl) : IGH.WikiCart.removeGraphFromCart(graphUrl);
            });
        });

        jQuery('#iGraphBackgroundTop')[0].addEventListener('mouseout', mouseOutTop, false);
        jQuery('#iGraphBackgroundBottom')[0].addEventListener('mouseout', mouseOutBottom, false);

        jQuery('a', '#iGraphBackgroundBottom').attr('href', '#').on('click', function() {
            expandUrlForSnapshotGraphs(IGH.hoveredImage, false, () => {
                setTime.call(this, IGH.hoveredImage);
            });
            return false;
        });

        jQuery('#iGraphRefreshIcon')[0].addEventListener('click', () => {
            return expandUrlForSnapshotGraphs(IGH.hoveredImage, true, () => _refreshImg(IGH.hoveredImage));
        }, false);

        iconsCreated = true;
    }

    function decorateGraphs(noEvents){
        _ighDebug('graph', 'decorateGraphs | images=' + document.images.length + ' | ' + window.location.href.substring(0, 60));
        var iGHimage = getModalImage();
        // Go through all images in doc and look for GetGraph or chart.cgi images
        for (let i = 0; i < document.images.length; i++) {
            var image = document.images[i];
            var searchString = getGraphArgs(image, true);
            if (searchString != null && image != iGHimage) {
                if (IGH.WikiEditor.onWiki()) {
                    jQuery(image).parent().attr("title", "");
                }
                jQuery(image).attr("origimgurl", searchString);
                if (!noEvents) {
                    image.addEventListener("mouseover", function(e){ mouseOverGraph(e, searchString);}, false);
                    image.addEventListener("mouseout",  function(e){ mouseOutGraph(e, searchString);}, false);
                    jQuery(image).iGHSingleDoubleClick(
                      function() { maximizeClicked(jQuery(this).attr("origimgurl"));},
                      function() { IGH.WikiCart.graphDoubleClicked(jQuery(this));});
                }
                var period = extractQueryValue(searchString, 'Period1');
                var startTime = extractQueryValue(searchString, 'StartTime1');
                IGH.WikiWidgets.setDefaultPeriod(period);
                IGH.WikiWidgets.setDefaultStartTime(startTime);

                graphsFound = true;
            }
        }

        doDecorateIGraph(noEvents);
        graphsFound = graphsFound || doDecorateTicketing();
        setStyles();
        if (graphsFound) {
            createIcons();
        }
    }

    function doDecorateIGraph(noEvents) {
        // Check for iGraph page
        if (noEvents) {
            return;
        }
        jQuery('.iGraphHelperContainer').hide();
        var igraphImg = document.getElementById("graphImg");
        if (/igraph/.test(window.location.href) && igraphImg) {
            igraphImg.addEventListener("mouseover", function(e){ mouseOverGraph(e, igraphImg);}, false);
            igraphImg.addEventListener("mouseout",  function(e){ mouseOutGraph(e, igraphImg);}, false);
            iGraphResizer(igraphImg, function(x, width, zoomLevel) {
                MP.GraphSection._zoom(x, width, zoomLevel);
                MP.GraphSection.displayGraph();
            });
            addIGraphZoom();
            addIGraphReset();
            addSnapshotButton();
            addTTSearch();
            isIgraph = true;
            graphsFound = true;
        }
    }

    function getDurationBetweenStartEnd(start, end) {
        const now = new Date();
        const startInMin = IGH.TimeRangeUtils._getTimeInMinutes(now, start);
        const endInMin = IGH.TimeRangeUtils._getTimeInMinutes(now, end);
        const duration = Math.round(startInMin - endInMin);
        const minDuration = Math.max(duration, 30);     // Don't go below 30 minutes
        return `-PT${minDuration}M`;
    }

    function graphDeepLinkToImageUrl(deepLink, convertTimeRangeToNow) {
        let graphUrl = null;

        // Check for CloudWatch Console deep link
        if (/metricsV2:graph=/.test(deepLink)) {
            const metricWidgetUrlBit = deepLink.replace(/.*metricsV2:graph=/, '');
            let metricWidgetStr = decodeURIComponent(metricWidgetUrlBit.replace(/\+/g, '%20'));

            if (convertTimeRangeToNow) {
                try {
                    const metricWidget = JSON.parse(metricWidgetStr);
                    const newStart = getDurationBetweenStartEnd(metricWidget.start, metricWidget.end);
                    metricWidget.start = newStart;
                    metricWidget.end = 'P0D';
                    metricWidgetStr = IGH.util.metricWidgetToJsonUrlParam(metricWidget);
                } catch (e) {
                    // Ignore and carry on
                }
            }

            graphUrl = IGH.util.graphArgsToCloudWatchGraphUrl(`metricWidget=${metricWidgetStr}`);
        }
        // Check for iGraph deep link
        else  if (/.amazon.com\/igraph[?]/.test(deepLink)) {
            graphUrl = deepLink.replace(/igraph[?]/, 'mws?Action=GetGraph&Version=2007-07-07&');

            if (convertTimeRangeToNow) {
                const startTime = extractQueryValue(deepLink, 'StartTime1');
                const endTime = extractQueryValue(deepLink, 'EndTime1');
                try {
                    const newStart = getDurationBetweenStartEnd(startTime, endTime);
                    graphUrl = IGH.util.replaceQueryParam(graphUrl, 'StartTime1', newStart);
                    graphUrl = IGH.util.replaceQueryParam(graphUrl, 'EndTime1', 'P0D');
                } catch (e) {
                    // Ignore and carry on
                }
            }
        }

        return graphUrl;
    }

    async function expandUrlForSnapshotGraphs(img, convertTimeRangeToNow, then) {
        if (!img) {
            return false;
        }
        const origSrc = img.src;
        const sourceUrl = jQuery(img).data('sourceUrl');
        if (sourceUrl) {
            loadingImg(img);
            const expandedUrl = await expandTinyUrl(sourceUrl);
            let graphUrl = graphDeepLinkToImageUrl(expandedUrl, convertTimeRangeToNow);

            jQuery(img).data('sourceUrl', null);

            if (graphUrl) {
                graphUrl = graphUrl.replace(/#TT-EMBED/, '');
                img.src = graphUrl;
            } else {
                img.src = origSrc;
            }
        }

        then(img.src);
        return false;
    }

    function expandTinyUrl(sourceUrl) {
        const MATCH_TINY_SITE = /^https:..tiny.amazon.com/;
        if (MATCH_TINY_SITE.test(sourceUrl)) {
            return new Promise(resolve => GMUtils.gmXmlHttpRequest({
                method: 'GET',
                url: sourceUrl,
                dataType: 'json',
                onload: function(response) {
                    if (response && response.finalUrl) {
                        if (MATCH_TINY_SITE.test(response.finalUrl)) {
                            const expandedLink = response.response.split('\n').join('')
                              .replace(/.*; URL=/m, '')
                              .replace(/" \/\>\<\/head\>$/m, '');
                            resolve(expandedLink);
                        } else {
                            resolve(response.finalUrl);
                        }
                    }
                }
            }));
        }

        return sourceUrl;
    }

    function grabTicketingMouseOvers(event) {
        const target = event.target;
        if (target.tagName === 'IMG') {
            // Check for rolling over a graph we've already expanded
            if (jQuery(target).data('sourceUrl')) {
                return mouseOverGraph(event);
            }
            // Check for rolling over a snapshot graph
            else if (/.amazon.com\/snap\/load/.test(target.src)) {
                ticketGraphCache.currentGraph = target;

                // Try to find source URL for graph (usually tiny link) in link closeby image
                const sourceUrl = jQuery(target).parent().siblings('a').attr('href') ||
                  jQuery(target).parent().parent().nextAll('a:first').attr('href');

                if (sourceUrl) {
                    // Tag image with sourceUrl, for handy access if someone clicks controls on hover border
                    jQuery(target).data('sourceUrl', sourceUrl);
                    return mouseOverGraph(event);
                }
            }
            // Check for rolling over live portal graph (probably converted from a snapshot)
            else if (/https:..monitorportal.amazon.com/.test(target.src)) {
                return mouseOverGraph(event);
            }
        }

        mouseOutGraph(event);
        ticketGraphCache.currentGraph = null;
    }

    // Do special snapshot expansion only for ticketing sites, for the moment
    function isOnTicketingSite() {
        const ALL_TICKETING_SITES = {
            'issues.amazon.com': 1, 'i.amazon.com': 1, 'issues-pdx.amazon.com': 1,
            'issues-dub.amazon.com': 1, 'issues-iad.amazon.com': 1, 'sim.amazon.com': 1,
            'issues-integ.amazon.com': 1, 't.corp.amazon.com': 1, 't-integ.amazon.com': 1,
            'tt.amazon.com': 1, 'halp-beta.amazon.com': 1, 'halp.amazon.com': 1
        };
        const domain = window.location.hostname;
        return !!ALL_TICKETING_SITES[domain];
    }

    function doDecorateTicketing() {
        if (isOnTicketingSite()) {
            // Grab all mouse over events in page on ticketing sites, to help discover hovering over snapshot images
            document.addEventListener('mouseover', grabTicketingMouseOvers);
            return true;
        }
        return false;
    }

    function iGraphResizer(igraphImg, zoomFn, height) {
        var MIN_ZOOM = 5;
        var minHeight = height || jQuery(igraphImg).height();
        var imgAreaSelect = jQuery(igraphImg).imgAreaSelect({
            onSelectEnd: function(img, select) {
                if (zoomFn && (select.x2 - select.x1 >= MIN_ZOOM)) {
                    zoomFn((select.x1 + select.x2) / 2,
                      jQuery(igraphImg).width(), (select.width * 1.0 / jQuery(igraphImg).width()));
                }
            },
            onSelectStart: function() {imgAreaSelect.setOptions({
                minHeight: jQuery(igraphImg).height(),
                maxHeight: jQuery(igraphImg).height()
            });
                imgAreaSelect.doResize();},
            instance: true,
            autoHide: true,
            minHeight: minHeight,
            maxHeight: minHeight,
            selectionColor: "#CFFCFF"
        });
    }

    function addSnapshotButton() {
        var id = "iGHsnapshotS3";
        var button = jQuery('<input type="button" id="' + id + '" name="iGHsnapshotButton" class="wikiButtonClass" value="Snapshot..." title="Snapshot graph as fixed bitmap and get code for pasting it elsewhere (added by iGraph Helper)"/>');
        jQuery(button).insertAfter(jQuery('#wikiButton'));
        button.on('click', function() {
            snapshotTo(getSnapshotSizeMessage());
        });
    }

    function getGraphUrl() {
        const obeyFit = GMUtils.getValue('iGraphHelper.snapshotObeyFit') != "false";

       if (obeyFit && ($('#graphImg').attr('src'))) {
            // Return the parameters from the currently plotted iGraph, size of which obeys the 'Fit' flag
            return $('#graphImg').attr('src').replace(/.*[?]/, '');
        }

        if (typeof MP.GraphSection.getGraphUrlWithoutInvisibleMetrics === 'function') {
            return MP.GraphSection.getGraphUrlWithoutInvisibleMetrics(MP.graph.model());
        }
        return MP.GraphSection.getDataModelQueryString();
    }

    function addTTSearch() {
        var search = jQuery(
          '<iframe name="emptyFrame" src="/images/state_ok.png" style="display: none;"></iframe>' +
          '<form id="ttForm" target="emptyFrame" action="/images/state_ok.png">' +
          '<input type="text" name="ttSearch" placeholder="Search TT (embedding current graph)" id="ttSearch" style="width: 235px; margin: 5px 0 0 10px;">' +
          '</form>');
        jQuery(search).appendTo(jQuery('#wikiButton').parent());
        jQuery('#ttSearch').on('keyup', function(e) {
            if (e.which == 13) {
                var search = jQuery('#ttSearch').val();
                var graphArgs = getGraphUrl();
                graphArgs = IGH.util.removeQueryParams(graphArgs, ["WidthInPixels", "HeightInPixels"]) + "&WidthInPixels=1024&HeightInPixels=300";
                window.open('https://tt.amazon.com/search?phrase_search_text=' + search + '&search=Search!&' + graphArgs, "_blank");
            }
        });
    }

    function getSnapshotSizeMessage() {
        let width;
        let height;
        if (isIgraph) {
            const iGraphUrl = getGraphUrl();
            width = extractQueryValue(iGraphUrl, 'WidthInPixels');
            height = extractQueryValue(iGraphUrl, 'HeightInPixels');
        } else {
            width = IGH.hoveredImage.width;
            height = IGH.hoveredImage.height;
        }
        return `The snapshot image size will be ${width} x ${height} pixels`;
    }

    function snapshotTo(message) {
        var queryString = getGraphUrl();
        WikiSnapshot.snapshotDisplayInPopup(IGH.util.lightbox, queryString, message);
    }

    // Includes a Javascript a file, given by 'url', in the current document
    function includeScript(url) {
        if (document.body || document.head) {
            var script = document.createElement('script');
            script.setAttribute('type', 'text/javascript');
            script.setAttribute('src', url);
            (document.body || document.head).appendChild(script);
        }
    }

    function getWikiPage() {
        return "https://w.amazon.com/index.php/" + jQuery('input[name="iGraphHelper.wikiGraphPage"]').val();
    }

    function saveGraph(user) {
        var queryString = getGraphUrl();
        if (queryString && queryString.length) {
            var model = MP.graph.model();
            var wikiText = "{{IGraph/graph|graph=" + queryString.replace(/=/g, "%3D").replace(/:/g, "%3A").replace(/[&]/g, "%26") +
              "|width=" + model.options().widthInPixels() + "|height=" + model.options().heightInPixels()  + "}}";
            saveTextToWiki(user, wikiText);
        }
        else {
            alert("Please display a graph first.\n\nYou can then save it to Wiki (" + getWikiPage() + ")");
        }
    }

    function saveTextToWiki(user, text) {
        var wikiEdit = getWikiPage() + "?action=edit&autoadd=" + encodeURI(text);
        window.open(wikiEdit, "_blank");
    }

    function getIgraphUser() {
        return jQuery('.hidden.username').text();
    }

    function addIGraphZoom() {
        var zoomRow = '<tr><td>Zoom:</td><td><a>1h</a> | <a>3h</a> | <a>8h</a> | <a>1d</a> | <a>1w</a> | <a>2w</a> | <a>30d</a></td></tr>';
        var fixedZoom = jQuery(zoomRow);
        var relZoom   = jQuery(zoomRow);
        var naturalZoom   = jQuery(zoomRow);
        var TIMES = { "1h": "-PT1H", "3h": "-PT3H", "8h": "-PT8H", "1d": "-P1D", "1w": "-P7D", "2w": "-P14D", "30d": "-P30D" };
        function setTime() {
            var model = MP.graph.model();
            model.timeRanges().clear();
            model.timeRanges().add(model.createTimeRange(MP.MWS.TimeRangeType.RELATIVE, TIMES[jQuery(this).text()], "-PT0M"));
            MP.GraphSection.displayGraph();
            return false;
        }

        jQuery('a', fixedZoom).attr('href', '#').on('click', setTime);
        jQuery('a', relZoom).attr('href', '#').on('click', setTime);
        jQuery('a', naturalZoom).attr('href', '#').on('click', setTime);
        jQuery('#relative-time tbody').prepend(relZoom);
        jQuery('#fixed-time tbody').prepend(fixedZoom);
        jQuery('#natural-time tbody').prepend(naturalZoom);
    }

    function addIGraphReset() {
        var reset = jQuery('<li><a href="#" title="Reset visibility of controls and height of graph (iGraphHelper)">Factory Settings</a></li>');
        reset.on('click', function() {
            MP.SectionHelper._slidingFinished(MP.SectionHelper, 'timeRanges', true);
            MP.SectionHelper._slidingFinished(MP.SectionHelper, 'generalOptions', false);
            MP.SectionHelper._slidingFinished(MP.SectionHelper, 'yAxisOptions', false);
            MP.SectionHelper._slidingFinished(MP.SectionHelper, 'extraOptions', false);
            MP.SectionHelper._slidingFinished(MP.SectionHelper, 'dashboarding', false);
            MP.SectionHelper._slidingFinished(MP.SectionHelper, 'searchControls', false);
            jQuery(".graphImgResize").height(200);
            MP.GraphSection.resizeAll();
            MP.GraphSection._refreshGraph();
            MP.IgraphConfig.setAndStore("graphHeight", jQuery("#graphImgContainer").height());
        });

        jQuery('.globalFeatures').prepend(reset);
    }

    function createIGraphLinks(){
        if (document.getElementById('metrics') && document.getElementById('monitor-amazon-com')) {
            addStyle("\
                div#graph-control div.control-container { \
                    overflow: visible; \
                }\n \
                div#main div.detailpanel {\
                    overflow: visible;\
                }\
                ");
        }
    }

    function mouseOverGraph(event, data) {
        // Get position of graph
        IGH.hoveredImage = event.target;
        if (! document.getElementById("iGraphBackgroundTop")) {
            decorateGraphs();
            return;
        }
        var MARGIN = 5;
        var TOP_HEIGHT = 24;
        var imgWidth = event.target.width;
        var imgHeight = event.target.height;
        var offset = $(event.target).offset();
        var pos = { x: Math.floor(offset.left),
            y: Math.floor(offset.top) + 1};
        var args = jQuery(event.target).attr("origimgurl");
        var widthOffset = ICON_WIDTH + 5;
        var nextIcon = 3;
        var width = 96;

        if (isIgraph && data) {
            args = data.src.replace(/.*[?]/, "");
            jQuery('#iGraphIcon').hide();
            width = 72;
        }
        else {
            jQuery('#iGraphIcon').show();
        }

        var imgUrl = jQuery(IGH.hoveredImage).attr('src');
        var isObserveEnabled = isFeatureEnabled('MPW_CLOUDWATCH_OBSERVE_ENABLED');

        // Observe icon should only be displayed for CloudWatch graphs. But graph snapshots are hard to tell, you
        // usually have to call Tiny.amazon.com first to know the original URL of the graph. So for snapshotted
        // graphs, just display Observe icon and handle different when icon is clicked
        var isObservableGraph = IGH.util.isCloudWatchGraph(imgUrl) || IGH.util.isSnapshottedGraph(imgUrl);
        if (isObserveEnabled && isObservableGraph) {
            jQuery('#iGraphObserveIcon').show();
        } else {
            jQuery('#iGraphObserveIcon').hide();
        }

        IGH.WikiCart.updateCartIcon();
        jQuery("#iGraphBackgroundTop").
            width(imgWidth + 2 * MARGIN - 1).
            css("left", pos.x - MARGIN).
            css("top", pos.y - TOP_HEIGHT - 1).
            fadeIn();
        jQuery("#iGraphBackgroundLeft").
            height(imgHeight).
            css("left", pos.x - MARGIN).
            css("top", pos.y).
            fadeIn();
        jQuery("#iGraphBackgroundRight").
            height(imgHeight).
            css("left", pos.x + imgWidth).
            css("top", pos.y).
            fadeIn();
        jQuery("#iGraphBackgroundBottom").
            width(imgWidth + 2 * MARGIN - 1).
            css("left", pos.x - MARGIN).
            css("top", pos.y + imgHeight - 1).
            fadeIn();

        if (IGH.hoveredImage) {
            OCLLinksManager.setOCLIconsVisibility(getFullGraphUrl());
        }
    }

    function mouseOutGraph(event) {
        // Ignore if hover border is invisible
        if (jQuery('#iGraphBackgroundTop').length === 0) {
            return;
        }

        // Get mouse and current element positions
        var mousePos = IGH.getMouseCoords(event);
        var posTop = IGH.getElementPosition(jQuery("#iGraphBackgroundTop")[0]);
        var posBottom = IGH.getElementPosition(jQuery("#iGraphBackgroundBottom")[0]);

        // If mouse is outside both elements hide the icons
        if (isMouseOutside(mousePos, posTop, jQuery("#iGraphBackgroundTop").width(), jQuery("#iGraphBackgroundTop").height() + 2)
          && isMouseOutside(mousePos, posBottom, jQuery("#iGraphBackgroundBottom").width(), jQuery("#iGraphBackgroundBottom").height())) {
            hideGraphBorder();
        }
        return false;
    }
    function mouseOutTop(event) {
        var mousePos = IGH.getMouseCoords(event);
        var igraphBackgroundPos = IGH.getElementPosition(jQuery("#iGraphBackgroundTop")[0]);
        if (isMouseNotBelow(mousePos, igraphBackgroundPos, jQuery("#iGraphBackgroundTop").width(), jQuery("#iGraphBackgroundTop").height())) {
            hideGraphBorder();
        }
        return false;
    }
    function mouseOutBottom(event) {
        var mousePos = IGH.getMouseCoords(event);
        var igraphBackgroundPos = IGH.getElementPosition(jQuery("#iGraphBackgroundBottom")[0]);
        if (isMouseNotAbove(mousePos, igraphBackgroundPos, jQuery("#iGraphBackgroundBottom").width(), jQuery("#iGraphBackgroundBottom").height())) {
            hideGraphBorder();
        }
        return false;
    }
    function hideGraphBorder() {
        jQuery("#iGraphBackgroundTop").hide();
        jQuery("#iGraphBackgroundBottom").hide();
        jQuery("#iGraphBackgroundLeft").hide();
        jQuery("#iGraphBackgroundRight").hide();
    }

    function isMouseOutside(mousePos, pos, width, height) {
        if (!mousePos || mousePos.x < pos.x || mousePos.x > pos.x + width ||
          mousePos.y < pos.y || mousePos.y > pos.y + height) {
            return true;
        }
        return false;
    }
    function isMouseNotBelow(mousePos, pos, width, height) {
        if (!mousePos || mousePos.x < pos.x || mousePos.x > pos.x + width ||
          mousePos.y < pos.y) {
            return true;
        }
        return false;
    }
    function isMouseNotAbove(mousePos, pos, width, height) {
        if (!mousePos || mousePos.x < pos.x || mousePos.x > pos.x + width ||
          mousePos.y > pos.y + height) {
            return true;
        }
        return false;
    }

    function getGraphArgs(image, includeQPlot) {
        // Look for graph image in http://performance*.amazon.com/chart.cgi
        if (/var\/performance\/cache\/png/.test(image.src) &&
          /amazon.com\/chart.cgi/.test(window.location.href) && includeQPlot) {
            return getSearchFromChartCgi();
        }
        else if (/Action=GetGraph/.test(image.src)) {
            return convertMWSParamsToIGraph(image.src.replace(/.*[?]/, ""));
        }
        else if (/Action=GetGraph/.test(image.alt)) {
            return convertMWSParamsToIGraph(image.alt.replace(/.*[?]/, ""));
        }
        else if (/SchemaName[0-9]*=/.test(image.title)) {
            return convertMWSParamsToIGraph(image.title.replace(/^MWS:/, ""));
        }
        else if (/amazon.com\/dashboard-PMETGraphs.cgi/.test(image.src) && includeQPlot) {
            return getSearchFromQplotUrl(image.src);
        } else if (/cw\/getMetricWidgetImage/.test(image.src)) {
            // CloudWatch bitmap graph
            return image.src.replace(/.*[?]/, "");
        }
        else if (image.tagName === "DIV") {
            return jQuery(image).parents(".MPWgraphInteractiveContainer").children(".MPWgraphInteractiveParams").text();
        }

        return null;
    }

    // Gets graph args from a deep link to igraph
    // ** Would be good to expand later with deep links from CloudWatch Console, just requires understanding of jsUrl
    function getGraphArgsFromPageDeepLink(url) {
        if (/\bSchemaName/i.test(url)) {
            return convertMWSParamsToIGraph(url.replace(/.*[?]/, ''));
        }
        return null;
    }

    function convertMWSParamsToIGraph(url) {
        var SEARCH_REPLACEMENTS = {
            "StartTime=": "StartTime1=",
            "EndTime=": "EndTime1=",
            "MetricSchema&": "&",
            "Period1=1": "Period1=One",
            "Period1=5": "Period1=Five",
            "StatOptions=": "StatOptions1=",
            "HorizontalLineLeft=": "HorizontalLineLeft1=",
            "HorizontalLineRight=": "HorizontalLineRight1=",
            "ValueUnit=": "ValueUnit1=",
            "SecurityToken": "",
            "X-Amz-Algorithm": "",
            "X-Amz-Credential": "",
            "X-Amz-Date": "",
            "X-Amz-Expires": "",
            "X-Amz-Signature": ""
        };
        var NON_SEARCH_REPLACEMENTS = {
            "SchemaName=": "SchemaName1=",
            "Period=": "Period1=",
            "Stat=": "Stat1=",
            "=Oneminute": "=OneMinute",
            "=Fiveminute": "=FiveMinute",
            "=Onehour": "=OneHour",
            "=Oneday": "=OneDay",
            "=Oneweek": "=OneWeek"
        };

        var graph = url.replace(/%3D/g, "=");

        var replacementList = [ SEARCH_REPLACEMENTS ];
        if (! /SchemaName[0-9]*=Search/.test(graph)) {  // If graph doesn't contain a search string do more conversions
            replacementList.push(NON_SEARCH_REPLACEMENTS);
            var schemaDefs = IGH.MetricSchemas.schemaDefs;
            for (var schemaName in schemaDefs) {
                var dims = schemaDefs[schemaName];
                for (var i = 0; i < dims.length; i++) {
                    graph = graph.replace(new RegExp(dims[i] + "=", "i"), dims[i] + "1=");
                }
            }
        }

        for (var r = 0; r < replacementList.length; r++) {
            var replacements = replacementList[r];
            for (var reStr in replacements) {
                var re = new RegExp(reStr, "g");
                graph = graph.replace(re, replacements[reStr]);
            }
        }
        return graph;
    }

    function getSearchFromMWSGetGraph(getGraphUrl) {
        var regexp = new RegExp("^(.*)[0-9]+$");
        var metricSearch = new IGH.MetricSearch();
        var paramValues = getGraphUrl.split("&");
        for (var i = 0; i < paramValues.length; i++) {
            var paramValue = paramValues[i].split("=");
            if (paramValue.length = 2) {
                var param = paramValue[0];
                var match = regexp.exec(param);
                var field = match ? match[1] : param;
                if (IGH.MetricSchemas.getUniqueDimensions()[field]) {
                    metricSearch.add(field, paramValue[1]);
                }
            }
        }

        return metricSearch.getSearchString();
    }

    function getSearchFromChartCgi() {
        var regexp = new RegExp("^Metric pmet[0-9] (.*): got ");
        var textNode, text = document.evaluate("//span[@id='Output Messages']/font/text()",document,null,6,null);
        var haveMatch = false;

        var metricSearch = new IGH.MetricSearch();
        for (var i = text.snapshotLength - 1; i >= 0; i--) {
            var textContent = text.snapshotItem(i).textContent;
            var match = regexp.exec(textContent);
            if (match) {
                var metricFields = match[1].split(",");
                metricSearch.addMetric(new IGH.Metric(metricFields));
            }
        }
        var searchString = metricSearch.getSearchString();
        if (searchString) {
            var graphTable = document.evaluate("/html/body/table[3]",document,null,6,null).snapshotItem(0);
            var div = document.createElement('div');
            div.className = "igraphMessage";
            var link = document.createElement('a');
            link.target = '_blank';
            link.href = IGRAPH_LINK.url + "search=" + encodeURIComponent(searchString);
            link.textContent = 'Click here to search for the metrics below in iGraph';
            div.appendChild(link);
            graphTable.parentNode.insertBefore(div, graphTable);
            graphsFound = true;
        }


        return null;
    }

    function getSearchFromQplotUrl(qplot) {
        return null;
    }

    IGH.WikiHtml = {
        initialize: function() {
            // Go check if we're on Wiki. Then
            if (IGH.WikiEditor.onWiki()) {
                var htmlContainer = jQuery('pre.html');
                var html = htmlContainer.text();
                try {
                    htmlContainer.replaceWith(html);
                }
                catch (e) {
                    log(e);
                }
            }
        }

    };

    IGH.WikiWidgets = {
        DEFAULT_WIDGETS: {
            period: "menu|Period|,1 Minute;OneMinute,5 Minute;FiveMinute,1 Hour;OneHour,1 Day;OneDay,1 Week;OneWeek|",
            time: "radio|Zoom;StartTime&EndTime|1h;-PT1H&P0D,3h;-PT3H&P0D,8h;-PT8H&P0D,1d;-P1D&P0D,3d;-P3D&P0D,1w;-P7D&P0D,2w;-P14D&P0D|",
            refresh: "refresh"
        },

        defaultPeriod: '',
        defaultTime: '',

        initialize: function() {
            if (! IGH.WikiEditor.onWiki()) {
                return;
            }

            this.displayWidgets();
        },

        displayWidgets: function() {
            var self = this;
            var widgetElements = jQuery('.IGraphWidget');

            var widgetDefs = [];
            var insertAfter = null;
            if (widgetElements.length == 0) {
                insertAfter = jQuery("#toc")[0] || jQuery("#contentSub")[0];

            }
            else {
                insertAfter = jQuery('.IGraphWidget:first');
                widgetElements.each(function() {
                    widgetDefs.push(jQuery(this).text());
                });
            }
            if (jQuery('.IGraphNoDefaultWidgets').length === 0) {
                widgetDefs.push(this.DEFAULT_WIDGETS.period + this.defaultPeriod);
                widgetDefs.push(this.DEFAULT_WIDGETS.time + this.defaultTime);
                widgetDefs.push(this.DEFAULT_WIDGETS.refresh);
            }
            this.displayWidgetsFromDefs(widgetDefs, insertAfter);
        },

        displayWidgetsFromDefs: function(widgetDefs, insertAfter) {
            if (widgetDefs.length == 0) {
                return;
            }
            var div = jQuery('<div>').addClass('iGHmenuArea');
            for (var i = 0; i < widgetDefs.length; i++) {
                var def = widgetDefs[i];
                var fields = def.split("|");
                if (fields.length > 0) {
                    var menuType = jQuery.trim(fields[0]);
                    if (menuType === 'menu' && fields.length == 4) {
                        this.doMenu(div, fields[1], fields[2], fields[3]);
                    }
                    else if (menuType === 'radio' && fields.length == 4) {
                        this.doRadio(div, i, fields[1], fields[2], fields[3]);
                    }
                    else if (menuType === 'html' && fields.length == 2) {
                        this.doHtml(div, fields[1]);
                    }
                    else if (menuType === 'refresh') {
                        this.doRefresh(div);
                    }
                    else {
                        log("Error, expected '[menu|radio]|<name>|<options>|<default>' but got this: " + def);
                    }
                }
                else {
                    log("Error, expected '[menu|radio|input]|<field>[|<fields>]...' but got this: " + def);
                }
            };
            div.append('<a href="http://w.amazon.com/index.php/IGraphHelper#Adding_Custom_Wiki_Controls" target="_blank" class="iGHmenuLink">Customize...</a>');
            div.insertAfter(insertAfter);
        },

        doMenu: function(div, nameField, optionsField, defaultOptionField) {
            var self = this;
            var menuName = this.parseMenuEntry(jQuery.trim(nameField));
            var options = jQuery.trim(optionsField).split(",");
            var defaultOption = jQuery.trim(defaultOptionField);
            var container = jQuery('<span>').addClass('iGHwidget').appendTo(div);
            jQuery('<span>').addClass('iGHmenuTitle').text(menuName.text + ": ").appendTo(container);
            var optionsHtml = "";
            for (var j = 0; j < options.length; j++) {
                var option = this.parseMenuEntry(options[j]);
                var selected = option.value == defaultOption ? "selected" : "";
                optionsHtml += '<option value="' + option.value + '" ' + selected + '>' + option.text + '</option>';
            }
            jQuery('<select>' + optionsHtml + '</select>').appendTo(container).on('change', function() {
                self.updateFields(menuName.value, jQuery(this).val());
            });
        },

        doRadio: function(div, index, nameField, optionsField, defaultOptionField) {
            var self = this;
            var radioName = this.parseMenuEntry(jQuery.trim(nameField));
            var options = jQuery.trim(optionsField).split(",");
            var defaultOption = jQuery.trim(defaultOptionField);
            var container = jQuery('<span>').addClass('iGHwidget').appendTo(div);
            jQuery('<span>').addClass('iGHmenuTitle').text(radioName.text + ": ").appendTo(container);
            var radioContainer = jQuery('<span class="iGHradio"></span>').appendTo(container);
            for (var j = 0; j < options.length; j++) {
                var option = this.parseMenuEntry(options[j]);
                if (option.value.length > 0) {
                    var selected = option.value == defaultOption ? ' checked="checked"' : '';
                    var inputName = 'iGraphRadio' + index;
                    var inputId = inputName + '_' + j;
                    var radio = jQuery('<input type="radio" name="' + inputName + '" id="' + inputId + '" value="' + option.value + '"' + selected + '>' +
                      '<label for="' + inputId + '" title="' + option.text + '">' + option.text + '</label>');
                    radio.appendTo(radioContainer);
                    var radioValue = new String(option.value)
                    radio.on('change', function() {
                        self.updateFields(radioName.value, jQuery(this).val());
                    });
                }
            }
        },

        doHtml: function(div, html) {
            jQuery(div).append(html);
        },

        doRefresh: function(div) {
            jQuery(div).append(' <span class="iGHrefreshAll"><input type="submit" value="Refresh" class="iGHbutton"></span>');
            jQuery('.iGHrefreshAll input', div).on('click', refreshAll);
        },

        parseMenuEntry: function(menuEntry) {
            var fields = menuEntry.split(';');
            var value = fields.length == 2 ? fields[1] : fields[0];
            return {text: jQuery.trim(fields[0]), value: jQuery.trim(value)};
        },

        keys: function(object)  {
            var keys = [];
            var key;
            for (key in object) {
                if (object.hasOwnProperty(key)) {
                    keys.push(key);
                }
            }
            return keys;
        },

        updateFields: function(fields, values) {
            var fieldEntries = fields.split("&");
            var valueEntries = values.split("&");
            if (fieldEntries.length != valueEntries.length) {
                log('Error: different number of entries in "' + fields + '" versus "' + values + '"');
                return;
            }
            for (i = 0; i < document.images.length; i++) {
                var image = document.images[i];
                var searchString = getGraphArgs(image, true);
                if (searchString != null) {
                    var modified = false;
                    for (var f = 0; f < fieldEntries.length; f++) {
                        var fieldEntry = fieldEntries[f];
                        var valueEntry = valueEntries[f];
                        var replaced = this._doFieldReplace(searchString, fieldEntry, valueEntry);
                        if (replaced) {
                            modified = true;
                            searchString = replaced;
                        }
                    }
                    if (modified) {
                        loadingImg(image);
                        var newUrl = MonitorPortalRoot + "/mws?Action=GetGraph&Version=2007-07-07&" + searchString;
                        image.src = cleanImgUrl(newUrl);
                    }
                }
            }
            decorateGraphs(true);
        },

        _doFieldReplace: function(string, field, value) {
            var fieldSplit = field.split("#");
            if (fieldSplit.length == 2) {
                var reStr = "(\\b" + fieldSplit[0] + "\\d*=)([^&]*)(" + fieldSplit[1].replace(/%3D/g, "=") +")([^&]*)";
                var valueRe = new RegExp(reStr, "g");
                if (valueRe.test(string)) {
                    return string.replace(valueRe, "$1$2" + value.replace(/%3D/g, "=") + "$4");
                }
            }
            else {
                var re = new RegExp("(\\b" + field + "\\d*=)([^&]*)", "g");
                if (re.test(string)) {
                    return string.replace(re, "$1" + value);
                }
            }
            return null;
        },

        setDefaultPeriod: function(period) {
            if (this.defaultPeriod.length === 0) {
                this.defaultPeriod = period;
            }
        },

        setDefaultStartTime: function(startTime) {
            if (this.defaultTime.length === 0) {
                this.defaultTime = startTime.replace(/T0H$/, '') + '&P0D';
            }
        }
    };

    IGH.WikiEditor = {
        initialize: function() {
            // Check if we're on a Wiki page with parameters
            if (this.onWiki(true)) {
                // We're on Wiki. Check for edit
                var queryParams = window.location.href.replace(/.*[?]/, '');
                var action = extractQueryValue(queryParams, 'action');
                if (action == 'edit') {
                    // We're on an edit page. Check for autoadd
                    var autoadd = extractQueryValue(queryParams, 'autoadd');
                    if (autoadd && autoadd.length > 0) {
                        if ((jQuery('#wpTextbox1').val().length === 0) && /MyGraphs\//.test(window.location.href)) {
                            autoadd = "[[Category:MyGraphs]]\n" + autoadd;
                        }
                        // We've got autoadd, let's add it to the page contents and save
                        this.addAndSaveText(decodeURI(autoadd).replace(/[%]26/g, "&"));
                    }
                }
            }
        },

        addAndSaveText: function(text) {
            var textBox = jQuery('#wpTextbox1');

            // Add text to edit box
            textBox.val(textBox.val() + '\n' + text);

            // Set summary for edit
            jQuery('#wpSummary').val('Autoadded by iGraph Helper, https://w.amazon.com/?IGraphHelper');

            // Click 'Save Page'
            jQuery('#wpSave').trigger('click');
        },

        onWiki: function(withArgs) {
            // Check if we're on a Wiki page with parameters
            if (! /^w[.].*amazon[.]com/.test(window.location.host)) {
                return false;
            }
            if (withArgs && ! /[?]/.test(window.location.href)) {
                return false;
            }
            return true;
        }
    };

    IGH.Metric = function(dimValues) {
        this._schemaName = dimValues[0];
        dimValues.splice(0, 1);
        this._dimValues = dimValues.slice();
    }
    IGH.Metric.prototype = {
        getSchemaName: function() {
            return this._schemaName;
        },

        getDimensions: function() {
            return IGH.MetricSchemas.getDimensions(this._schemaName);
        },

        getDimensionValues: function() {
            return this._dimValues;
        }
    }

    IGH.MetricSearch = function() {
        this._uniqueValues = new Array();
    }
    IGH.MetricSearch.prototype = {
        add: function(field, value) {
            if (!this._uniqueValues[field]) {
                this._uniqueValues[field] = new Array();
            }
            if (field == IGH.SCHEMA_NAME_FIELD) {
                value = value.replace(/MetricSchema/, "");
            }
            this._uniqueValues[field][value] = true;
        },

        addMetric: function(metric) {
            this.add(IGH.SCHEMA_NAME_FIELD, metric.getSchemaName());
            var dimensions = metric.getDimensions();
            var dimValues  = metric.getDimensionValues();
            for (var i = 0; i < dimensions.length; i++) {
                if (dimValues[i]) {
                    this.add(dimensions[i], dimValues[i]);
                }
            }
        },

        getSearchString: function() {
            var clauses = [];
            for (var field in this._uniqueValues) {
                var values = [];
                for (var value in this._uniqueValues[field]) {
                    if (field == IGH.SCHEMA_NAME_FIELD) {
                        values.push(value);
                    }
                    else {
                        values.push("$" + value + "$");
                    }
                }

                var clause = field.toLowerCase() + "=";
                clause += (values.length == 1) ? values[0] : "(" + values.join(" OR ") + ")";
                clauses.push(clause);
            }

            return clauses.length ? clauses.join(" ") : null;
        }
    }

    IGH.SCHEMA_NAME_FIELD = "SchemaName";

    IGH.MetricSchemas = {
        initialize: function() {
            for (var schemaName in this.schemaDefs) {
                this._schemas.push(schemaName);
                var dims = this.getDimensions(schemaName);
                for (var i = 0; i < dims.length; i++) {
                    this._uniqueDimensions[dims[i]] = true;
                }
                this._uniqueDimensions[IGH.SCHEMA_NAME_FIELD] = true;
            }
        },

        getDimensions: function(schemaName) {
            return this.schemaDefs[schemaName];
        },

        getSchemas: function () {
            return this._schemas;
        },

        getUniqueDimensions: function() {
            return this._uniqueDimensions;
        },

        schemaDefs: {
            "Apollo": ["Environment","Host","Stage","Step","Metric"],
            "ArizonaAccess": ["Family","Host","Page","User","Metric"],
            "CatalogRTP": ["Family","Instance","Metric"],
            "Community": ["Marketplace","ActionName","URLType","DisplayGroup","Metric"],
            "COSS": ["Family","Host","Program","OperationName","CustType","Metric"],
            "ErrorLog": ["Family","Host","Program","Severity","SignatureName","URLType","Source","Function"],
            "GKM": ["Family","Filter1","Filter2","Filter3","Filter4","Filter5","Filter6","Filter7","Filter8","Metric"],
            "Marmoset": ["Family","Host","Metric"],
            "Network": ["DataSet","AlternateName","SourceName","SourceType","DestinationName","Instance","Grouping","Metric"],
            "OnlineQueryLog": ["Family","Host","URLType","CustType","Metric"],
            "OrdersCreated": ["Family","Merchant","ProductGroup","Event"],
            "PAQ": ["ModuleName","Host","Domain","Realm","ServiceName","Queue","Metric"],
            "Search": ["Pattern"],
            "SearchSDA": ["Component","Marketplace","Host","Metric"],
            "SellerCentral": ["Family","Host","Merchant","ServiceName","Status","Tool","Metric"],
            "Service": ["DataSet","Marketplace","HostGroup","Host","ServiceName","MethodName","Client","MetricClass","Instance","Metric"],
            "Snitch": ["DataSet","HostGroup","Host","Class","Object","Metric"],
            "Spools": ["SpoolName","Type","Host","Metric"],
            "SubscriptionServices": ["DataSet","Marketplace","PlanGroup","Plan","Category","OperationName","Metric"],
            "TimingLog": ["Family","Host","Function","ServiceName","Metric"],
            "WebLabData": ["Family","WebLab","Metric"],
            "XDQ": ["XDQ","XDQVersion","Machine","Metric"] },
        _schemas: [],
        _uniqueDimensions: {}
    };

    /*
     * Browser constants
     */
    IGH.BrowserConstants = {};
    IGH.BrowserConstants._isIE = navigator.appVersion.match(/MSIE/);
    IGH.BrowserConstants._userAgent = navigator.userAgent;
    IGH.BrowserConstants._isFireFox = IGH.BrowserConstants._userAgent.match(/firefox/i);
    IGH.BrowserConstants._isFireFoxOld = IGH.BrowserConstants._isFireFox &&
      (IGH.BrowserConstants._userAgent.match(/firefox\/2./i)
        || IGH.BrowserConstants._userAgent.match(/firefox\/1./i));
    IGH.BrowserConstants._isFireFoxNew = IGH.BrowserConstants._isFireFox && !IGH.BrowserConstants._isFireFoxOld;
    IGH.BrowserConstants._isSafari = /^((?!chrome|android|crios|fxios).)*safari/i.test(IGH.BrowserConstants._userAgent);
    IGH.BrowserConstants._isOpera = IGH.BrowserConstants._userAgent.indexOf(' OPR/') >= 0;

    /*
     * Get the absolute position of any HTML element
     */
    IGH.getElementPosition = function(element) {
        var offset = $(element).offset();
        var pos = { x: Math.floor(offset.left),
            y: Math.floor(offset.top) };
        return pos;
    };

    IGH._parseBorderWidth = function(width) {
        var res = 0;
        if (typeof(width) == "string" && width != null
          && width != "" ) {
            var p = width.indexOf("px");
            if (p >= 0) {
                res = parseInt(width.substring(0, p));
            }
            else {
                //do not know how to calculate other
                //values (such as 0.5em or 0.1cm) correctly now
                //so just set the width to 1 pixel
                res = 1;
            }
        }
        return res;
    }

    //returns border width for some element
    IGH._getBorderWidth = function(element) {
        var res = new Object();
        res.left = 0; res.top = 0; res.right = 0; res.bottom = 0;
        if (window.getComputedStyle) {
            //for Firefox
            var elStyle = window.getComputedStyle(element, null);
            res.left = parseInt(elStyle.borderLeftWidth.slice(0, -2));
            res.top = parseInt(elStyle.borderTopWidth.slice(0, -2));
            res.right = parseInt(elStyle.borderRightWidth.slice(0, -2));
            res.bottom = parseInt(elStyle.borderBottomWidth.slice(0, -2));
        }
        else {
            //for other browsers
            res.left = IGH.BrowserConstants._parseBorderWidth(element.style.borderLeftWidth);
            res.top = IGH.BrowserConstants._parseBorderWidth(element.style.borderTopWidth);
            res.right = IGH.BrowserConstants._parseBorderWidth(element.style.borderRightWidth);
            res.bottom = IGH.BrowserConstants._parseBorderWidth(element.style.borderBottomWidth);
        }

        return res;
    }

    /*
    * Utility function for getting size of window
    */
    IGH.getWindowSize = function() {
        var myWidth = 0, myHeight = 0;
        if (typeof( window.innerWidth ) == 'number' ) {
            //Non-IE
            myWidth = window.innerWidth;
            myHeight = window.innerHeight;
        } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
            //IE 6+ in 'standards compliant mode'
            myWidth = document.documentElement.clientWidth;
            myHeight = document.documentElement.clientHeight;
        } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
            //IE 4 compatible
            myWidth = document.body.clientWidth;
            myHeight = document.body.clientHeight;
        }
        return { width: myWidth, height: myHeight};
    };

    /*
     *  Given an event returns the absolute position of the mouse pointer
     */
    IGH.getMouseCoords = function(ev) {
        try {
            ev = ev || window.event;
            if (ev.pageX || ev.pageY) {
                return {
                    x: ev.pageX,
                    y: ev.pageY
                };
            }
            var windowOffset = IGH.getWindowOffset();
            return {
                x: ev.clientX + windowOffset.x - document.body.clientLeft,
                y: ev.clientY + windowOffset.y - document.body.clientTop
            };
        }
        catch (e) {
            // The event object was not obtainable or did not contain location information
            return null;
        }
    };

    IGH.getWindowOffset = function() {
        return {
            x: IGH.filterAreaResults(window.pageXOffset ? window.pageXOffset : 0,
              document.documentElement ? document.documentElement.scrollLeft : 0,
              document.body ? document.body.scrollLeft : 0),
            y: IGH.filterAreaResults(window.pageYOffset ? window.pageYOffset : 0,
              document.documentElement ? document.documentElement.scrollTop : 0,
              document.body ? document.body.scrollTop : 0)
        }
    };

    /*
    * Utility function for getting the correct number in the DOM for x and y positions.
    * It is given numbers that come from the window, document and documeny body and
    * the algorithm figures out the correct one to use.
    */
    IGH.filterAreaResults = function(n_win, n_docel, n_body) {
        var n_result = n_win ? n_win : 0;
        if (n_docel && (!n_result || (n_result > n_docel))) {
            n_result = n_docel;
        }
        return n_body && (!n_result || (n_result > n_body)) ? n_body : n_result;
    };

    IGH.PortalGraphZoomer = {
        initialize: function() {
            monitorPortal = document.getElementById("masthead");
            if (monitorPortal) {
                if (!(/[<]h1[>]Infrastructure[<].h1[>]/.exec(monitorPortal.innerHTML) &&
                  /[<]h2[>]Powered By Monitoring[<].h2[>]/.exec(monitorPortal.innerHTML) && window.jQuery)) {
                    return;
                }

                // Register click event on all graphs
                jQuery("#graph_results .img img").on('click', IGH.PortalGraphZoomer._graphClickEvent);
                jQuery("#graph_results .img img").css("cursor", "pointer");
                jQuery("#graph_results .img img").attr("title", "Click to zoom");
            }
        },

        /*
         * Graph was left-clicked:
         * - left-click on its own zooms in by 2, and recenters around clicked-on spot
         * - shift-left-click recenters graph on around clicked-on spot (no zoom)
         * - ctrl-left-click jumps to latest data (no zoom)
         */
        _graphClickEvent: function(e) {
            var event = window.event || e;
            var graphPos = jQuery(this).offset();
            var width = jQuery(this).width();
            var xClick = event.clientX - graphPos.left;

            IGH.PortalGraphZoomer._zoom(xClick, width, event.shiftKey ? 1.0 : 0.5);
            return false;
        },

        _getTimeRange: function() {
            var endTime = jQuery('#end_time').val();
            var endTimeMillis = Date.parse(endTime);
            var isFixedTime = jQuery('div#time-control .switch-time a').attr('id') != 'fixed-time';
            if (isFixedTime) {
                var startTime = jQuery('#start_time').val();
                var startTimeMillis = Date.parse(startTime);
            }
            else {
                var relTime = jQuery('#relative_time_value').val();
                var period = jQuery('#relative_time_value').next().val();
                var minMultiplier = 1;
                if (period == "hour") {
                    minMultiplier = 60;
                }
                else if (period == "day") {
                    minMultiplier = 24 * 60;
                }
                else if (period == "week") {
                    minMultiplier = 7 * 24 * 60;
                }
                var relMinutes = relTime * minMultiplier;
                var startTimeMillis = endTimeMillis - 60000 * relMinutes;
            }
            return {startTime: startTimeMillis, endTime: endTimeMillis};
        },

        _zoom: function(x, width, zoomLevel) {
            var timeRange = this._getTimeRange();
            var startDuration, endDuration;

            var centerSpot = timeRange.startTime - Math.floor((timeRange.startTime - timeRange.endTime) / 1.0 / width * x);
            var halfDuration = Math.floor((timeRange.startTime - timeRange.endTime) * zoomLevel / 2);
            var newStartMillis = centerSpot + halfDuration;
            var newEndMillis = centerSpot - halfDuration;

            this._setTimeRange(newStartMillis, newEndMillis);
            jQuery('#graph-metrics').submit();
        },

        _setTimeRange: function(startTimeMillis, endTimeMillis) {
            this._displayFixedTime();
            var startTime = new Date(startTimeMillis);
            var endTime = new Date(endTimeMillis);
            jQuery('#start_time').val(this._formatTime(startTime));
            jQuery('#end_time').val(this._formatTime(endTime));
        },

        _formatTime: function(time) {
            var y = time.getYear() + 1900;
            var m = time.getMonth() + 1;
            var d = time.getDate();
            var h = time.getHours();
            var min = time.getMinutes();

            return (y + "/" + this._zeroPad(m) + "/" + this._zeroPad(d) + " " + this._zeroPad(h) + ":" + this._zeroPad(min));
        },

        _displayFixedTime: function() {
            var timecontrol = jQuery('div#time-control');
            var fixedTime = 'div#hidden-fixed-time-control';
            timecontrol.empty().append(jQuery(fixedTime).html());
        },

        _zeroPad: function(x) {
            return(x<0||x>9?"":"0")+x;
        }

    };

    IGH.PortalGraphSelector = {
        initialize: function() {
            if (unsafeWindow.GraphData && unsafeWindow.GraphData.initDataTable && ! (/monitorportal.amazon.com[/]mws[/]data/.test(window.location.href))) {
                this._origInitDataTable = unsafeWindow.GraphData.initDataTable;
                unsafeWindow.GraphData.initDataTable = this._myInitDataTable;
                graphsFound = true;
            }
        },

        _myInitDataTable: function(index) {
            IGH.PortalGraphSelector._origInitDataTable(index);
            var divId = "#graph_data_" + index;
            jQuery(divId + " table.tablesorter tr td").on("click", function() {
                var cb = jQuery("input", jQuery(this).parent());
                cb.prop("checked", ! cb.prop("checked"));
            });
            jQuery(divId).prepend("<a id='iGraphPreview" + index + "' style='cursor: pointer;' title='Preview metrics in popup (iGraphHelper)'>Preview</a>");
            jQuery(divId).prepend("<a id='iGraphView" + index + "' style='cursor: pointer;' title='View metrics in iGraph (iGraphHelper)'>View in iGraph</a>&nbsp|&nbsp;");
            jQuery("#iGraphPreview" + index).on('click', function() {IGH.PortalGraphSelector._previewGraphs(index);});
            jQuery("#iGraphView" + index).on('click', function() {IGH.PortalGraphSelector._viewGraphs(index);});
            jQuery(divId + " table tr:first").prepend("<th><input type=checkbox checked title='Toggle all metrics (iGraphHelper)'></th>");
            jQuery(divId + " table tr:first input").on('change', function() { IGH.PortalGraphSelector._checkAllChanged(this, index);});
            jQuery(divId + " table tr:gt(0)").prepend("<td><input type=checkbox checked title='Toggle this metric (iGraphHelper)'></td>");


        },

        _checkAllChanged: function(cb, index) {
            jQuery("#graph_data_" + index + " table tr:gt(0) input").prop("checked", jQuery(cb).prop("checked"));
            return false;
        },

        _viewGraphs: function(index) {
            var igraph = "/igraph?";
            var args = IGH.PortalGraphSelector._getGraphs(index);
            if (args.length == 0) {
                alert("Please tick metrics below to view in iGraph");
            }
            else {
                window.open(igraph + args);
            }
            return false;
        },

        _previewGraphs: function(index) {
            var img = MonitorPortalRoot + "/mws?Action=GetGraph&Version=2007-07-07&WidthInPixels=760&HeightInPixels=460&";
            var args = IGH.PortalGraphSelector._getGraphs(index);
            if (args.length == 0) {
                alert("Please tick metrics below to preview");
            }
            else {
                maximizeClicked(args);
//            jQuery.blockUI(IGH.PortalGraphSelector._getPreviewModalHtml(img + args), window.modal_normal);
            }
            return false;

        },

        _getGraphs: function(index) {
            var LIMIT = 50;
            var args = "";
            jQuery("#graph_data_" + index + " table tr:gt(0) input:checked").each(function(i) {
                var td = jQuery(this).parent().next();
                var link = jQuery("a", td).attr("href");
                if (!link) {
                    link = IGH.PortalGraphSelector._getLinkFromMetricString(jQuery.trim(td.text()), index);
                }

                link = link.replace(/^.igraph[?]/, "").replace(/\d+=/g, (i + 1) + "=");
                if (i > 0) {
                    link = link.replace(/[&]StartTime.*/, "");
                }
                if (i < LIMIT) {
                    args += "&"+ link;
                }
                else if (i == LIMIT) {
                    alert("Warning: limited to displaying " + LIMIT + " metrics in iGraph");
                }
            });

            return args;
        },

        _getPreviewModalHtml: function(img) {
            return  '\
                    <div id="lightbox">\
                        <div id="header"><h2>Preview Metrics (iGraphHelper)</h2>\
                             <a href="#" class="close" onclick="jQuery.unblockUI(); return false;">close</a><br/>\
                        </div>\
                        <div style="background:url(\'/images/spinner-l-lime.gif\') no-repeat scroll center center #FFFFFF; width: 760px; height: 460px;">\
                            <center>\
                                <img src="' + img + '" onclick="jQuery.unblockUI(); return false;" title="Click to close" style="cursor: pointer;">\
                            </center>\
                        </div>\
                    </div>';

        },

        _getLinkFromMetricString: function(label, index) {
            var metricString = jQuery(".title", jQuery("#graph_data_" + index).parents("tr").children(":first-child")).text();
            var METRIC_EXTRACTOR_REGEXP =  new RegExp('^([^ ]*) ([^ ]*) ([^ ]*)');
            var metricParts = METRIC_EXTRACTOR_REGEXP.exec(metricString);
            if (metricParts && metricParts.length == 4) {
                return "&SchemaName1=Snitch&Stat1=avg&Period1=OneMinute&DataSet1=prod" +  this._getHostOrHostclass(label) +
                  "&DecoratePoints=true" + this._getCurrentTimeRange() +
                  "&Class1=" + metricParts[1] +
                  "&Object1=" + metricParts[2] +
                  "&Metric1=" + metricParts[3];
            }
        },

        _getHostOrHostclass: function(label) {
            return location.pathname.indexOf('/hostclasses/') === 0 ?
              ("&HostGroup1=" + encodeURIComponent(label) + "&Host1=ALL") :
              ("&HostGroup1=NONE&Host1=" + encodeURIComponent(label));
        },

        _getCurrentTimeRange: function() {
            var time = IGH.PortalGraphZoomer._getTimeRange();
            var startTime = new Date(time.startTime);
            var endTime = new Date(time.endTime);
            return "&StartTime1=-PT" + parseInt((endTime.getTime() - startTime.getTime()) / 3600000) + "H&EndTime1=-P0D";

        },

        _getTimeInHours: function(time) {
            var now = new Date();
            return (now.getTime() - time.getTime()) / 1000 / 60 / 60;
        }
    };

    IGH.IGraphUpdates = {
        initialize: function() {
            if ((typeof MP !== 'undefined') && MP.graph && MP.graph.model &&
              MP.graph.PARAMS.MODEL_CHANGED_EVENT && MP.graph.model() &&
              jQuery) {
                MP.graph.model().register(MP.graph.PARAMS.MODEL_CHANGED_EVENT, IGH.IGraphUpdates.setTitle);
                IGH.IGraphUpdates.setTitle();
                jQuery('#linkToThisGraphTiny').on('click', IGH.IGraphUpdates.tinyClicked);
            }
        },

        setTitle: function() {
            var title = MP.graph.model().options().graphTitle();
            if (title != null && title != "") {
                window.document.title = title;
            }

        },

        tinyClicked: function() {
            var title = MP.graph.model().options().graphTitle();
            var tinyLink = jQuery('#linkToThisGraphTiny').attr("href");
            if (tinyLink) {
                var tinyHostname = TinyUrlRoot.replace(/^https?:\/\//, '');
                tinyLink = tinyLink.replace(/\/\/tiny\.amazon\.com\//, "//" + tinyHostname + "/");
                tinyLink = tinyLink.replace(/comment=iGraph/, "comment=" + encodeURIComponent(title || 'iGraph'));
                jQuery('#linkToThisGraphTiny').attr("href", tinyLink);
            }
            return true;
        }
    };


    IGH.TimeRangeUtils = {

        TZ_PDT: "PST8PDT",
        XML_DATE: new RegExp('(\\d{4})-(\\d{2})-(\\d{2})'),
        XML_TIME: new RegExp('T(\\d{2}):(\\d{2}):(\\d{2})'),
        XML_TZ: new RegExp('([-+]\\d{2}):00$'),
        DECIMAL: 10,
        MILLISECONDS_IN_MINUTE: 60 * 1000,
        DURATION: new RegExp('^-?P'),

        PATTERN: {
            DAY: new RegExp('(\\d*)D'),
            HOUR: new RegExp('(\\d*)H'),
            MINUTE: new RegExp('(\\d*)M')
        },

        DURATIONS: {
            DAY: "D",
            HOUR: "H",
            MINUTE: "M"
        },

        MINUTES: {
            DAY: 24 * 60,
            HOUR: 60,
            MINUTE: 1
        },

        UNITS: {
            MINUTE: "MINUTE",
            HOUR: "HOUR",
            DAY: "DAY"
        },

        ORDERED_UNITS: ["MINUTE", "HOUR", "DAY"],

        // get units and corresponding value form a control
        getControlFromDuration: function(duration){
            var minutes = this.getMinutes(duration);
            var unit = this.getUnits(duration);
            var value = minutes / this.MINUTES[unit];
            var result = {};
            result[unit] = value;
            return result;
        },

        // get number of minutes corresponding to a duration
        getMinutes: function(duration){
            // sign is inverted sign widget is ago
            var sign = duration.match("-P") ? 1 : -1;
            var minutes = 0;
            for (var i = 0; i < this.ORDERED_UNITS.length; i++) {
                var index = this.ORDERED_UNITS[i];
                var results = this.PATTERN[index].exec(duration);
                if (results && results[1] !== "") {
                    minutes += this.MINUTES[index] * parseInt(results[1], this.DECIMAL);
                }
            }
            return sign * minutes;
        },

        // get most significant Unit present in a duration
        getUnits: function(duration){
            var unit = this.UNITS.MINUTE;
            for (var i = 0; i < this.ORDERED_UNITS.length; i++) {
                var index = this.ORDERED_UNITS[i];
                var results = this.PATTERN[index].exec(duration);
                if (results && results[1] !== "") {
                    unit = index;
                }
            }
            return unit;
        },

        // create a duration form the screen widget
        getDurationFromControl: function(unit, value){
            // sign is inverted sign widget is ago
            var sign = value < 0 ? "" : "-";
            var minutes = Math.floor(this.MINUTES[unit] * Math.abs(value));
            var duration = sign + "P";
            if (minutes >= this.MINUTES.DAY || unit === this.UNITS.DAY) {
                var days = Math.floor(minutes / this.MINUTES.DAY);
                duration += days + this.DURATIONS.DAY;
                minutes = minutes % this.MINUTES.DAY;
            }
            duration += "T";
            if (minutes >= this.MINUTES.HOUR || unit === this.UNITS.HOUR) {
                var hours = Math.floor(minutes / this.MINUTES.HOUR);
                duration += hours + this.DURATIONS.HOUR;
                minutes = minutes % this.MINUTES.HOUR;
            }
            if (minutes >= this.MINUTES.MINUTE || unit === this.UNITS.MINUTE) {
                var mins = Math.floor(minutes / this.MINUTES.MINUTE);
                duration += mins + this.DURATIONS.MINUTE;
            }
            if( duration.charAt(duration.length-1) === "T") {
                duration= duration.slice(0,-1);
            }
            return duration;
        },

        // get a calendar string in UTC from the int values of a javascript date
        getXMLCalendarFromControl: function(year, month, dayOfMonth, hours, minutes){
            var date = new fleegix.date.Date(year, month, dayOfMonth, hours, minutes, this.TZ_PDT, false);
            return this.getXMLCalendarFromDate(date);
        },

        // get a calendar string in UTC from a date
        getXMLCalendarFromDate: function(date){
            return date.getUTCFullYear() + "-" + this.pad(date.getUTCMonth() + 1) + "-" + this.pad(date.getUTCDate()) + "T" + this.pad(date.getUTCHours()) + ":" + this.pad(date.getUTCMinutes()) + ":00Z";
        },

        // get a date in PDT from an xml calendar in UTC
        getDateFromXMLCalendar: function(xmlCalendar){
            var hour = 0;
            var minute = 0;
            var second = 0;
            var tz = 0;
            var results = this.XML_TZ.exec(xmlCalendar);
            if (results) {
                tz = parseInt(results[1], this.DECIMAL);
            }
            results = this.XML_TIME.exec(xmlCalendar);
            if (results) {
                hour = parseInt(results[1], this.DECIMAL);
                minute = parseInt(results[2], this.DECIMAL);
                second = parseInt(results[3], this.DECIMAL);
            }
            results = this.XML_DATE.exec(xmlCalendar);
            if (results) {
                var year = parseInt(results[1], this.DECIMAL);
                var month = parseInt(results[2], this.DECIMAL) - 1;
                var dayInMonth = parseInt(results[3], this.DECIMAL);
                var utc = new Date(Date.UTC(year, month, dayInMonth, hour, minute, second) - (tz * (60 * 60 * 1000)));
                return utc;
            }
            return null;
        },

        // get an xml calendar in UTC from a date and an xml duration
        getXMLCalendarFromDuration: function(now, duration){
            var minutes = this.getMinutes(duration);
            now.setMinutes(now.getMinutes() - minutes);
            return this.getXMLCalendarFromDate(now);
        },

        // get an xml calendar in UTC from a date and an xml duration
        getDurationFromXMLCalendar: function(now, calendar){
            calendar = unescape(calendar);
            var then = this.getDateFromXMLCalendar(calendar);
            var minutes = (now.getTime() - then.getTime()) / this.MILLISECONDS_IN_MINUTE;
            return this.getDurationFromControl(this.UNITS.MINUTE, minutes);
        },

        // Convert a time range into minute durations
        getTimeRangeInMinutes: function(now, timeRange) {
            var minuteRange = new Object();
            minuteRange.startTime = this._getTimeInMinutes(now, timeRange.startTime);
            minuteRange.endTime   = this._getTimeInMinutes(now, timeRange.endTime);
            return minuteRange;
        },

        // Convert a time (duration or fixed) into number of minutes, compared to now
        _getTimeInMinutes: function(now, time) {
            var duration;
            if (! this.isDuration(time)) {
                duration = this.getDurationFromXMLCalendar(now, time);
            }
            else {
                duration = time;
            }
            return this.getMinutes(duration);
        },

        // Return true if time is a duration
        isDuration: function(time) {
            return this.DURATION.test(time);
        },

        pad: function(number){
            if (number < 10) {
                return "0" + number;
            }
            return number;
        }
    };

    /*
    * imgAreaSelect jQuery plugin
    * version 0.9.2
    *
    * Copyright (c) 2008-2010 Michal Wojciechowski (odyniec.net)
    *
    * Dual licensed under the MIT (MIT-LICENSE.txt)
    * and GPL (GPL-LICENSE.txt) licenses.
    *
    * http://odyniec.net/projects/imgareaselect/
    *
    */
    (function($) {

        var abs = Math.abs,
          max = Math.max,
          min = Math.min,
          round = Math.round;

        function div() {
            return $('<div/>');
        }

        $.imgAreaSelect = function (img, options) {
            var

              $img = $(img),

              imgLoaded,

              $box = div(),
              $area = div(),
              $border = div().add(div()).add(div()).add(div()),
              $outer = div().add(div()).add(div()).add(div()),
              $handles = $([]),

              $areaOpera,

              left, top,

              imgOfs,

              imgWidth, imgHeight,

              $parent,

              parOfs,

              zIndex = 0,

              position = 'absolute',

              startX, startY,

              scaleX, scaleY,

              resizeMargin = 10,

              resize,

              minWidth, minHeight, maxWidth, maxHeight,

              aspectRatio,

              shown,

              x1, y1, x2, y2,

              selection = { x1: 0, y1: 0, x2: 0, y2: 0, width: 0, height: 0 },

              docElem = document.documentElement,

              $p, d, i, o, w, h, adjusted;

            function viewX(x) {
                return x + imgOfs.left - parOfs.left;
            }

            function viewY(y) {
                return y + imgOfs.top - parOfs.top;
            }

            function selX(x) {
                return x - imgOfs.left + parOfs.left;
            }

            function selY(y) {
                return y - imgOfs.top + parOfs.top;
            }

            function evX(event) {
                return event.pageX - parOfs.left;
            }

            function evY(event) {
                return event.pageY - parOfs.top;
            }

            function getSelection(noScale) {
                var sx = noScale || scaleX, sy = noScale || scaleY;

                return { x1: round(selection.x1 * sx),
                    y1: round(selection.y1 * sy),
                    x2: round(selection.x2 * sx),
                    y2: round(selection.y2 * sy),
                    width: round(selection.x2 * sx) - round(selection.x1 * sx),
                    height: round(selection.y2 * sy) - round(selection.y1 * sy) };
            }

            function setSelection(x1, y1, x2, y2, noScale) {
                var sx = noScale || scaleX, sy = noScale || scaleY;

                selection = {
                    x1: round(x1 / sx),
                    y1: round(y1 / sy),
                    x2: round(x2 / sx),
                    y2: round(y2 / sy)
                };

                selection.width = selection.x2 - selection.x1;
                selection.height = selection.y2 - selection.y1;
            }

            function adjust() {
                if (!$img.width())
                    return;

                imgOfs = { left: round($img.offset().left), top: round($img.offset().top) };

                imgWidth = $img.width();
                imgHeight = $img.height();

                minWidth = options.minWidth || 0;
                minHeight = options.minHeight || 0;
                maxWidth = min(options.maxWidth || 1<<24, imgWidth);
                maxHeight = min(options.maxHeight || 1<<24, imgHeight);

                if ($().jquery == '1.3.2' && position == 'fixed' &&
                  !docElem['getBoundingClientRect'])
                {
                    imgOfs.top += max(document.body.scrollTop, docElem.scrollTop);
                    imgOfs.left += max(document.body.scrollLeft, docElem.scrollLeft);
                }

                parOfs = $.inArray($parent.css('position'), ['absolute', 'relative']) + 1 ?
                  { left: round($parent.offset().left) - $parent.scrollLeft(),
                      top: round($parent.offset().top) - $parent.scrollTop() } :
                  position == 'fixed' ?
                    { left: $(document).scrollLeft(), top: $(document).scrollTop() } :
                    { left: 0, top: 0 };

                left = viewX(0);
                top = viewY(0);

                if (selection.x2 > imgWidth || selection.y2 > imgHeight)
                    doResize();
            }

            function update(resetKeyPress) {
                if (!shown) return;

                $box.css({ left: viewX(selection.x1), top: viewY(selection.y1) })
                  .add($area).width(w = selection.width).height(h = selection.height);

                $area.add($border).add($handles).css({ left: 0, top: 0 });

                $border
                  .width(max(w - $border.outerWidth() + $border.innerWidth(), 0))
                  .height(max(h - $border.outerHeight() + $border.innerHeight(), 0));

                $($outer[0]).css({ left: left, top: top,
                    width: selection.x1, height: imgHeight });
                $($outer[1]).css({ left: left + selection.x1, top: top,
                    width: w, height: selection.y1 });
                $($outer[2]).css({ left: left + selection.x2, top: top,
                    width: imgWidth - selection.x2, height: imgHeight });
                $($outer[3]).css({ left: left + selection.x1, top: top + selection.y2,
                    width: w, height: imgHeight - selection.y2 });

                w -= $handles.outerWidth();
                h -= $handles.outerHeight();

                switch ($handles.length) {
                    case 8:
                        $($handles[4]).css({ left: w / 2 });
                        $($handles[5]).css({ left: w, top: h / 2 });
                        $($handles[6]).css({ left: w / 2, top: h });
                        $($handles[7]).css({ top: h / 2 });
                    case 4:
                        $handles.slice(1,3).css({ left: w });
                        $handles.slice(2,4).css({ top: h });
                }

                if (resetKeyPress !== false) {
                    if ($.imgAreaSelect.keyPress != docKeyPress)
                        $(document).off($.imgAreaSelect.keyPress,
                          $.imgAreaSelect.onKeyPress);

                    if (options.keys)
                        $(document).on($.imgAreaSelect.keyPress, $.imgAreaSelect.onKeyPress = docKeyPress);
                }

                if (IGH.BrowserConstants._isIE && $border.outerWidth() - $border.innerWidth() == 2) {
                    $border.css('margin', '0');
                    setTimeout(function () { $border.css('margin', 'auto'); }, 0);
                }
            }

            function doUpdate(resetKeyPress) {
                if (!imgOfs) return;
                adjust();
                update(resetKeyPress);
                x1 = viewX(selection.x1); y1 = viewY(selection.y1);
                x2 = viewX(selection.x2); y2 = viewY(selection.y2);
            }

            function hide($elem, fn) {
                options.fadeSpeed ? $elem.fadeOut(options.fadeSpeed, fn) : $elem.hide();

            }

            function areaMouseMove(event) {
                var x = selX(evX(event)) - selection.x1,
                  y = selY(evY(event)) - selection.y1;

                if (!adjusted) {
                    adjust();
                    adjusted = true;

                    $box.one('mouseout', function () { adjusted = false; });
                }

                resize = '';

                if (options.resizable) {
                    if (y <= resizeMargin)
                        resize = 'n';
                    else if (y >= selection.height - resizeMargin)
                        resize = 's';
                    if (x <= resizeMargin)
                        resize += 'w';
                    else if (x >= selection.width - resizeMargin)
                        resize += 'e';
                }

                $box.css('cursor', resize ? resize + '-resize' :
                  options.movable ? 'move' : '');
                if ($areaOpera)
                    $areaOpera.toggle();
            }

            function docMouseUp(event) {
                $('body').css('cursor', '');

                if (options.autoHide || selection.width * selection.height == 0)
                    hide($box.add($outer), function () { $(this).hide(); });

                options.onSelectEnd(img, getSelection());

                $(document).off('mousemove', selectingMouseMove);
                $box.on('mousemove', areaMouseMove);
            }

            function areaMouseDown(event) {
                if (event.which != 1) return false;

                adjust();

                if (resize) {
                    $('body').css('cursor', resize + '-resize');

                    x1 = viewX(selection[/w/.test(resize) ? 'x2' : 'x1']);
                    y1 = viewY(selection[/n/.test(resize) ? 'y2' : 'y1']);

                    $(document).on('mousemove', selectingMouseMove)
                      .one('mouseup', docMouseUp);
                    $box.off('mousemove', areaMouseMove);
                }
                else if (options.movable) {
                    startX = left + selection.x1 - evX(event);
                    startY = top + selection.y1 - evY(event);

                    $box.off('mousemove', areaMouseMove);

                    $(document).on('mousemove', movingMouseMove)
                      .one('mouseup', function () {
                          options.onSelectEnd(img, getSelection());

                          $(document).off('mousemove', movingMouseMove);
                          $box.on('mousemove', areaMouseMove);
                      });
                }
                else
                    $img.on('mousedown', event);

                return false;
            }

            function fixAspectRatio(xFirst) {
                if (aspectRatio)
                    if (xFirst) {
                        x2 = max(left, min(left + imgWidth,
                          x1 + abs(y2 - y1) * aspectRatio * (x2 > x1 || -1)));

                        y2 = round(max(top, min(top + imgHeight,
                          y1 + abs(x2 - x1) / aspectRatio * (y2 > y1 || -1))));
                        x2 = round(x2);
                    }
                    else {
                        y2 = max(top, min(top + imgHeight,
                          y1 + abs(x2 - x1) / aspectRatio * (y2 > y1 || -1)));
                        x2 = round(max(left, min(left + imgWidth,
                          x1 + abs(y2 - y1) * aspectRatio * (x2 > x1 || -1))));
                        y2 = round(y2);
                    }
            }

            function doResize() {
                x1 = min(x1, left + imgWidth);
                y1 = min(y1, top + imgHeight);

                if (abs(x2 - x1) < minWidth) {
                    x2 = x1 - minWidth * (x2 < x1 || -1);

                    if (x2 < left)
                        x1 = left + minWidth;
                    else if (x2 > left + imgWidth)
                        x1 = left + imgWidth - minWidth;
                }

                if (abs(y2 - y1) < minHeight) {
                    y2 = y1 - minHeight * (y2 < y1 || -1);

                    if (y2 < top)
                        y1 = top + minHeight;
                    else if (y2 > top + imgHeight)
                        y1 = top + imgHeight - minHeight;
                }

                x2 = max(left, min(x2, left + imgWidth));
                y2 = max(top, min(y2, top + imgHeight));

                fixAspectRatio(abs(x2 - x1) < abs(y2 - y1) * aspectRatio);

                if (abs(x2 - x1) > maxWidth) {
                    x2 = x1 - maxWidth * (x2 < x1 || -1);
                    fixAspectRatio();
                }

                if (abs(y2 - y1) > maxHeight) {
                    y2 = y1 - maxHeight * (y2 < y1 || -1);
                    fixAspectRatio(true);
                }

                selection = { x1: selX(min(x1, x2)), x2: selX(max(x1, x2)),
                    y1: selY(min(y1, y2)), y2: selY(max(y1, y2)),
                    width: abs(x2 - x1), height: abs(y2 - y1) };

                update();

                options.onSelectChange(img, getSelection());
            }

            function selectingMouseMove(event) {
                x2 = resize == '' || /w|e/.test(resize) || aspectRatio ? evX(event) : viewX(selection.x2);
                y2 = resize == '' || /n|s/.test(resize) || aspectRatio ? evY(event) : viewY(selection.y2);

                doResize();

                return false;

            }

            function doMove(newX1, newY1) {
                x2 = (x1 = newX1) + selection.width;
                y2 = (y1 = newY1) + selection.height;

                $.extend(selection, { x1: selX(x1), y1: selY(y1), x2: selX(x2),
                    y2: selY(y2) });

                update();

                options.onSelectChange(img, getSelection());
            }

            function movingMouseMove(event) {
                x1 = max(left, min(startX + evX(event), left + imgWidth - selection.width));
                y1 = max(top, min(startY + evY(event), top + imgHeight - selection.height));

                doMove(x1, y1);

                event.preventDefault();

                return false;
            }

            function startSelection() {
                adjust();

                x2 = x1;
                y2 = y1;

                doResize();

                resize = '';

                if ($outer.is(':not(:visible)'))
                    $box.add($outer).hide().fadeIn(options.fadeSpeed||0);

                shown = true;

                $(document).off('mouseup', cancelSelection)
                  .on('mousemove', selectingMouseMove).one('mouseup', docMouseUp);
                $box.off('mousemove', areaMouseMove);

                options.onSelectStart(img, getSelection());
            }

            function cancelSelection() {
                $(document).off('mousemove', startSelection);
                hide($box.add($outer));

                selection = { x1: selX(x1), y1: selY(y1), x2: selX(x1), y2: selY(y1),
                    width: 0, height: 0 };

                options.onSelectChange(img, getSelection());
                options.onSelectEnd(img, getSelection());
            }

            function imgMouseDown(event) {
                if (event.which != 1 || $outer.is(':animated')) return false;

                adjust();
                startX = x1 = evX(event);
                startY = y1 = evY(event);

                $(document).one('mousemove', startSelection)
                  .one('mouseup', cancelSelection);

                return false;
            }

            function windowResize() {
                doUpdate(false);
            }

            function imgLoad() {
                imgLoaded = true;

                setOptions(options = $.extend({
                    classPrefix: 'imgareaselect',
                    movable: true,
                    resizable: true,
                    parent: 'body',
                    onInit: function () {},
                    onSelectStart: function () {},
                    onSelectChange: function () {},
                    onSelectEnd: function () {}
                }, options));

                $box.add($outer).css({ visibility: '' });

                if (options.show) {
                    shown = true;
                    adjust();
                    update();
                    $box.add($outer).hide().fadeIn(options.fadeSpeed||0);
                }

                setTimeout(function () { options.onInit(img, getSelection()); }, 0);
            }

            var docKeyPress = function(event) {
                var k = options.keys, d, t, key = event.keyCode;

                d = !isNaN(k.alt) && (event.altKey || event.originalEvent.altKey) ? k.alt :
                  !isNaN(k.ctrl) && event.ctrlKey ? k.ctrl :
                    !isNaN(k.shift) && event.shiftKey ? k.shift :
                      !isNaN(k.arrows) ? k.arrows : 10;

                if (k.arrows == 'resize' || (k.shift == 'resize' && event.shiftKey) ||
                  (k.ctrl == 'resize' && event.ctrlKey) ||
                  (k.alt == 'resize' && (event.altKey || event.originalEvent.altKey)))
                {
                    switch (key) {
                        case 37:
                            d = -d;
                        case 39:
                            t = max(x1, x2);
                            x1 = min(x1, x2);
                            x2 = max(t + d, x1);
                            fixAspectRatio();
                            break;
                        case 38:
                            d = -d;
                        case 40:
                            t = max(y1, y2);
                            y1 = min(y1, y2);
                            y2 = max(t + d, y1);
                            fixAspectRatio(true);
                            break;
                        default:
                            return;
                    }

                    doResize();
                }
                else {
                    x1 = min(x1, x2);
                    y1 = min(y1, y2);

                    switch (key) {
                        case 37:
                            doMove(max(x1 - d, left), y1);
                            break;
                        case 38:
                            doMove(x1, max(y1 - d, top));
                            break;
                        case 39:
                            doMove(x1 + min(d, imgWidth - selX(x2)), y1);
                            break;
                        case 40:
                            doMove(x1, y1 + min(d, imgHeight - selY(y2)));
                            break;
                        default:
                            return;
                    }
                }

                return false;
            };

            function styleOptions($elem, props) {
                for (option in props)
                    if (options[option] !== undefined)
                        $elem.css(props[option], options[option]);
            }

            function setOptions(newOptions) {
                if (newOptions.parent)
                    ($parent = $(newOptions.parent)).append($box.add($outer));

                $.extend(options, newOptions);

                adjust();

                if (newOptions.handles != null) {
                    $handles.remove();
                    $handles = $([]);

                    i = newOptions.handles ? newOptions.handles == 'corners' ? 4 : 8 : 0;

                    while (i--)
                        $handles = $handles.add(div());

                    $handles.addClass(options.classPrefix + '-handle').css({
                        position: 'absolute',
                        fontSize: '0',
                        zIndex: `${zIndex + 1 || 1}`
                    });

                    if (!parseInt($handles.css('width')))
                        $handles.width(5).height(5);

                    if (o = options.borderWidth)
                        $handles.css({ borderWidth: o, borderStyle: 'solid' });

                    styleOptions($handles, { borderColor1: 'border-color',
                        borderColor2: 'background-color',
                        borderOpacity: 'opacity' });
                }

                scaleX = options.imageWidth / imgWidth || 1;
                scaleY = options.imageHeight / imgHeight || 1;

                if (newOptions.x1 != null) {
                    setSelection(newOptions.x1, newOptions.y1, newOptions.x2,
                      newOptions.y2);
                    newOptions.show = !newOptions.hide;
                }

                if (newOptions.keys)
                    options.keys = $.extend({ shift: 1, ctrl: 'resize' },
                      newOptions.keys);

                $outer.addClass(options.classPrefix + '-outer');
                $area.addClass(options.classPrefix + '-selection');
                for (i = 0; i++ < 4;)
                    $($border[i-1]).addClass(options.classPrefix + '-border' + i);

                styleOptions($area, { selectionColor: 'background-color',
                    selectionOpacity: 'opacity' });
                styleOptions($border, { borderOpacity: 'opacity',
                    borderWidth: 'border-width' });
                styleOptions($outer, { outerColor: 'background-color',
                    outerOpacity: 'opacity' });
                if (o = options.borderColor1)
                    $($border[0]).css({ borderStyle: 'solid', borderColor: o });
                if (o = options.borderColor2)
                    $($border[1]).css({ borderStyle: 'dashed', borderColor: o });

                $box.append($area.add($border).add($handles).add($areaOpera));

                if (IGH.BrowserConstants._isIE) {
                    if (o = $outer.css('filter').match(/opacity=([0-9]+)/))
                        $outer.css('opacity', o[1]/100);
                    if (o = $border.css('filter').match(/opacity=([0-9]+)/))
                        $border.css('opacity', o[1]/100);
                }

                if (newOptions.hide)
                    hide($box.add($outer));
                else if (newOptions.show && imgLoaded) {
                    shown = true;
                    $box.add($outer).fadeIn(options.fadeSpeed||0);
                    doUpdate();
                }

                aspectRatio = (d = (options.aspectRatio || '').split(/:/))[0] / d[1];

                if (options.disable || options.enable === false) {
                    $box.off('mousemove', areaMouseMove).off('mousedown', areaMouseDown);
                    $img.add($outer).off('mousedown', imgMouseDown);
                    $(window).off('resize', windowResize);
                }
                else if (options.enable || options.disable === false) {
                    if (options.resizable || options.movable)
                        $box.on('mousemove', areaMouseMove).on('mousedown', areaMouseDown);

                    if (!options.persistent)
                        $img.add($outer).on('mousedown', imgMouseDown);

                    $(window).on('resize', windowResize);
                }

                options.enable = options.disable = undefined;
            }

            this.remove = function () {
                $img.off('mousedown', imgMouseDown);
                $box.add($outer).remove();
            };

            this.getOptions = function () { return options; };

            this.setOptions = setOptions;

            this.getSelection = getSelection;

            this.setSelection = setSelection;

            this.update = doUpdate;

            this.doResize = doResize;

            $p = $img;

            while ($p.length) {
                zIndex = max(zIndex,
                  !isNaN($p.css('z-index')) ? $p.css('z-index') : zIndex);
                if ($p.css('position') == 'fixed')
                    position = 'fixed';

                $p = $p.parent(':not(body)');
            }

            zIndex = options.zIndex || zIndex;

            if (IGH.BrowserConstants._isIE)
                $img.attr('unselectable', 'on');

            $.imgAreaSelect.keyPress = IGH.BrowserConstants._isIE ||
            IGH.BrowserConstants._isSafari ? 'keydown' : 'keypress';

            if (IGH.BrowserConstants._isOpera)
                $areaOpera = div().css({ width: '100%', height: '100%',
                    position: 'absolute', zIndex: `${zIndex + 2 || 2}` });

            $box.add($outer).css({ visibility: 'hidden', position: position,
                overflow: 'hidden', zIndex: `${zIndex || 0}` });
            $box.css({ zIndex: `${zIndex + 2 || 2}` });
            $area.add($border).css({ position: 'absolute', fontSize: '0' });

            img.complete || img.readyState == 'complete' || !$img.is('img') ?
              imgLoad() : $img.one('load', imgLoad);
        };

        $.fn.imgAreaSelect = function (options) {
            options = options || {};

            this.each(function () {
                if ($(this).data('imgAreaSelect')) {
                    if (options.remove) {
                        $(this).data('imgAreaSelect').remove();
                        $(this).removeData('imgAreaSelect');
                    }
                    else
                        $(this).data('imgAreaSelect').setOptions(options);
                }
                else if (!options.remove) {
                    if (options.enable === undefined && options.disable === undefined)
                        options.enable = true;

                    $(this).data('imgAreaSelect', new $.imgAreaSelect(this, options));
                }
            });

            if (options.instance)
                return $(this).data('imgAreaSelect');

            return this;
        };

    })(jQuery);

    /*
     * Wiki Cart
     *
     * This is the graph shopping cart, where users can add graphs to their shopping cart for later merging
     * and viewing in iGraph
     */
    IGH.WikiCart = {
        IGRAPH_BASE: MonitorPortalRoot + "/igraph?",
        MESSAGE_TIMEOUT_IN_MS: 5 * 1000,
        REFRESH_UPDATE_IN_MS: 500,
        REFRESH_COUNT: 60,      // This times REFRESH_UPDATE_IN_MS is how often cart refreshes (30s)
        REFRESH_PERCENT_MAX_WIDTH: 24,
        CART_STORAGE_KEY: 'MPWcartState',
        NOT_NEEDED_PARAMS: ['forceRefresh', 'wiki', 'iGHrefresh', 'fixed', 'actionSource', 'Action', 'Version', 'actionSource1'],

        initialize: function() {
            this.createCart();
            this.codec = IGH.graph.createMWSCodec();
            this.messageTimer = null;
            this.refreshTimer = null;
            this.refreshCounter = 0;
            this.numItems = 0;
            this.isMouseOverCart = false;
            this.restoreState();
            this.updateCartVisibility();
            this.lookForAlarm();
        },

        createCart: function() {
            this.cart = jQuery(this.getCartHtml());
            this.cartDropDetector = jQuery('textarea', this.cart);
            this.cartMessage = jQuery('.MPWcartMessage', this.cart);
            this.cartCheckoutButton  = jQuery('.MPWcartButton .checkoutButton', this.cart);
            this.cartAddAllGraphsButton   = jQuery('.MPWcartButton .addGraphButton', this.cart);
            this.cartEmptyButton   = jQuery('.MPWcartButton .emptyCartButton', this.cart);
            this.grabEvents();
            this.cart.appendTo('body');
            WikiBulkSnapshot.injectSnapshotButtonIntoCart();
        },

        lookForAlarm: function() {
            if (!isOnTicketingSite()) {
                return;
            }
            this.state.alarms = this.state.alarms || [];

            // Continually look for Carnaval alarm on page until one is found.
            // SIM and T.Corp are rendered asynchronously and ticket overview may load after many seconds
            this.alarmTimer = setInterval(() => { this.lookForAlarmOnTicketingSite(); }, 1000);
        },

        lookForAlarmOnTicketingSite: function() {
            const ticketIdField = jQuery('.ticket-id,#context_bar tbody td:first,.breadcrumb .label:last').text();
            if (!ticketIdField) {
                return;     // Nothing found
            }

            const ticketId = ticketIdField.trim().split(' ')[0];   // First word in field is the id

            // Check if the ticket is already mentioned in persisted state, for quick restore
            const alarmInfo = this.state.alarms.find(entry => entry.ticketId === ticketId);
            if (alarmInfo) {
                clearInterval(this.alarmTimer);
                this.currentAlarm = alarmInfo.carnavalId;
                this.updateCarnavalAlarmState();
            } else {
                // Let's try and find carnaval link on page
                const MATCH_CARNAVAL_LINK = 'a[href*="http://carnaval.amazon.com/v1/viewObject.do"]';
                const MATCH_CARNAVAL_ON_TICKET_SITE = `.overview-content-children ${MATCH_CARNAVAL_LINK},#details_readonly ${MATCH_CARNAVAL_LINK},#issue-description-container ${MATCH_CARNAVAL_LINK}`;
                const url = jQuery(MATCH_CARNAVAL_ON_TICKET_SITE).attr('href');
                if (url) {
                    const carnavalId = extractQueryValue(url, 'name');
                    if (carnavalId) {
                        const MAX_ALARMS_FOR_TICKETS_TO_CACHE = 5;
                        clearInterval(this.alarmTimer);
                        this.state.alarms.push({ticketId, carnavalId});
                        if (this.state.alarms.length > MAX_ALARMS_FOR_TICKETS_TO_CACHE) {
                            this.state.alarms.shift();
                        }
                        this.currentAlarm = carnavalId;
                        this.updateCarnavalAlarmState();
                        return;
                    }
                }
            }
        },

        retrieveCarnavalAlarmState: function(effectiveAlarm, effectiveSuppression) {
            if (!effectiveSuppression) {
                if (effectiveAlarm) {
                    return 'ALERT';
                } else {
                    return 'OK';
                }
            } else {
                if (effectiveAlarm) {
                    return 'SUPPRESSED';
                } else {
                    return 'AT_RISK';
                }
            }
        },

        displayCarnavalAlarmState: function(alarmName, state) {
            const carnavalAlarmUrl = `http://carnaval.amazon.com/v1/viewObject.do?name=${alarmName}`;

            jQuery('.MPWcartDragDrop').hide();
            jQuery('#MPWcartAlarmState')
              .removeClass()
              .show()
              .text(state)
              .addClass(`MPWcartAlarmState${state}`)
              .attr('title', `State of alarm '${alarmName}' is '${state}`)
              .attr('href', carnavalAlarmUrl);
        },

        updateCarnavalAlarmState: async function() {
            // Don't display if Cart is not shown
            if (this.state.isCancelled || ! this.currentAlarm) {
                return;
            }

            this.displayCarnavalAlarmState(this.currentAlarm, 'loading');

            const url = `http://carnaval-api.amazon.com/?AlarmName=${this.currentAlarm}&HistoryType=StateUpdate&MaxRecords=1&Operation=DescribeAlarmHistory&Version=2010-10-16&ContentType=JSON`;
            const self = this;

            await GMUtils.gmXmlHttpRequest({
                method: 'GET',
                url: url,
                headers: {
                    'User-agent': 'Mozilla/5.0 (compatible) Greasemonkey/iGraphHelper.user.js'
                },
                onload: function(response) {
                    let state = 'UNKNOWN';
                    if (response.status === 200) {
                        const fileContent = JSON.parse(response.responseText);
                        const alarmHistoryItems = fileContent.DescribeAlarmHistoryResponse.DescribeAlarmHistoryResult.AlarmHistoryItems;
                        if (alarmHistoryItems.length > 0) {
                            const historyItem = alarmHistoryItems[0];
                            const historyData = JSON.parse(historyItem.HistoryData);
                            state = self.retrieveCarnavalAlarmState(historyData.effectiveAlarm === 'true', historyData.effectiveSuppression === 'true');
                        }
                    } else if (response.status === 401 && response.finalUrl) {
                        state = 'MIDWAY ERROR';
                    }

                    self.displayCarnavalAlarmState(self.currentAlarm, state);
                    self.updateRefreshCycle();
                }
            });
        },

        grabEvents: function() {
            var that = this;

            if (this.cart.on) {
                this.cart.on('mouseenter', function () {
                    that.isMouseOverCart = true;
                    return that.restoreState();
                });
                this.cart.on('mouseleave', function () {
                    that.isMouseOverCart = false;
                    return that.updateCartVisibility();
                });
            }

            this.cartCheckoutButton.on('click', function() { return that.checkout(); });
            this.cartAddAllGraphsButton.on('click', function() {
                return isIgraph ? that.addGraphToCart(getGraphUrl()) : that.addAllGraphsToCart();
            });
            this.cartEmptyButton.on('click', function() { return that.empty(false); });
            jQuery('.MPWcartCancel', this.cart).on('click', function() { return that.cancel(); });
            jQuery('.MPWrefreshCartIcon', this.cart).on('click', function() { return that.doRefreshTick(true); });
            jQuery('.MPWmanageCartCloseIcon', this.cart).on('click', function() { return that.closeCartManagerBox(); });
            jQuery('.MPWmanageCartOpenIcon', this.cart).on('click', function() { return that.openCartManagerBox(); });
            jQuery('.MPWmoveCartToBottomIcon', this.cart).on('click', function() { return that.moveCartToBottom(); });
            jQuery('.MPWmoveCartToTopIcon', this.cart).on('click', function() { return that.moveCartToTop(); });
        },

        cartDropEventDetected: function(event) {
            let graphArgs;
            let isExternal = false;
            event.preventDefault();
            this.cartDropDetector.val("");
            if (event.dataTransfer) {
                const droppedUrl = event.dataTransfer.getData('text');
                isExternal = true;
                if (/^https*:\/\/carnaval/.test(droppedUrl)) {
                    const carnavalId = extractQueryValue(droppedUrl, 'name');
                    if (carnavalId) {
                        this.currentAlarm = carnavalId;
                        this.updateCarnavalAlarmState();
                    }
                    return;
                } else {
                    graphArgs = getGraphArgsFromPageDeepLink(droppedUrl);
                }
            } else {
                graphArgs = getGraphArgs(IGH.hoveredImage, false);
            }

            if (graphArgs) {
                this.addGraphToCart(graphArgs, isExternal);
            }
        },

        graphDoubleClicked: function(img) {
            this.addGraphToCart(getGraphArgs(IGH.hoveredImage, false));
        },

        addGraphToCart: function(graphUrl, isExternal) {
            this.restoreState();
            if (this.isGraphPresentOnCart(graphUrl)) {
                this.displayMessage("iGraph already present on cart.", 3000);
                return false;
            }
            this.state.graphArgs.push(this.getGraphUrlForCart(graphUrl));
            this.storeState();
            if (!isExternal) {
                this.updateCartIcon();
            }
            this.showOpenedCart();
            this.displayMessage("iGraph has been added to cart.", 3000);
            return false;
        },

        removeGraphFromCart: function(graphUrl) {
            this.restoreState();
            const index = this.state.graphArgs.indexOf(this.getGraphUrlForCart(graphUrl));
            if (index >= 0 && index < this.state.graphArgs.length) {
                this.state.graphArgs.splice(index, 1);
            }
            this.storeState();
            this.updateCartIcon();
            this.updateCartManagerBox();
            this.updateCartVisibility();
            this.numItems > 0 ? this.openCartManagerBox() : this.closeCartManagerBox();
            this.displayMessage('graph has been removed from cart.', 3000);
            return false;
        },

        addAllGraphsToCart: function() {
            const graphArgs = this.state.graphArgs;
            this.restoreState();
            let removeCount=0, addedCount=0;
            const graphsOnPage = jQuery('img[src*="Action=GetGraph"],img[src*="getMetricWidgetImage"],  .MPWgraphInteractiveParams').filter((':not(.MPWmanageCartImg)'));
            for (let i = 0; i < graphsOnPage.length; i++) {
                const element = graphsOnPage[i];
                const graphUrl = getGraphArgs(element, false);
                if (graphUrl != null) {
                    const url = this.getGraphUrlForCart(graphUrl);
                    const index = graphArgs.indexOf(url);
                    if (index >= 0 && index < graphArgs.length) {
                        graphArgs.splice(index, 1);
                        removeCount++;
                    }
                    graphArgs.push(url);
                    addedCount++;
                }
            }
            this.state.graphArgs = graphArgs;

            //Display message according to the count of graphs added to cart.
            if (addedCount == removeCount) {
                this.restoreState();
                this.displayMessage('All ' + (addedCount > 1 ? addedCount : '') + ' graphs already present on cart.', 3000);
            }
            else if (removeCount == 0) {
                this.displayMessage('All ' + (addedCount > 1 ? addedCount : '') + ' graphs have been added to cart.', 3000);
            }
            else {
                this.displayMessage(removeCount + ' of ' + addedCount + ' graphs already present on cart, ' + (addedCount - removeCount) + ' more added.', 4000);
            }

            this.storeState();
            this.updateCartVisibility();
            this.updateCartManagerBox();
            this.openCartManagerBox();
        },

        isGraphPresentOnCart: function(url) {
            this.restoreState();
            const index = this.state.graphArgs.indexOf(this.getGraphUrlForCart(url));
            return index >= 0 && index < this.state.graphArgs.length ? true : false;
        },

        mergeGraphUrls: function(newGraphUrl) {
            this.restoreState();
            let mergedModel;
            for (let i = 0; i < this.state.graphArgs.length; i++) {
                const newModel = IGH.graph.DataModelHelper.modelFromUrl("/igraph?" + this.state.graphArgs[i]);
                if(mergedModel) {
                    IGH.graph.DataModelHelper.mergeModels(mergedModel, newModel);
                }
                else {
                    mergedModel = newModel;
                }
            }
            mergedModel.options().leftYAxis().showYAxis("true");
            mergedModel.options().rightYAxis().showYAxis("true");
            mergedModel.options().showXAxisLabel("true");
            mergedModel.options().showLegend("true");
            const finalGraphUrl = this.IGRAPH_BASE + this.codec.toQueryString(jQuery.extend(this.codec.encode(mergedModel), this.codec.encodeFunctions(mergedModel)));
            return finalGraphUrl;
        },

        displayMessage: function(msg, durationInMS) {
            var that = this;
            this.cartMessage.html(msg);
            this.cartMessage.fadeIn();
            clearTimeout(this.messageTimer);
            this.messageTimer = setTimeout(function() { that.cartMessage.fadeOut(); }, durationInMS);
        },

        checkout: function() {
            var iGraphUrl = this.mergeGraphUrls();
            if (iGraphUrl !== "") {
                window.open(iGraphUrl);
            }
            return false;
        },

        showOpenedCart: function() {
            this.state.isCancelled = false;
            this.state.isCartManagerOpened = true;
            this.storeState();
            this.updateCartVisibility();
        },

        openCartManagerBox: function() {
            const self = this;
            this.state.isCartManagerOpened = true;
            this.storeState();
            const n = this.numItems;
            const boxWidth = n < 2 ? 350 : (n === 2 ? 670 : 985);

            jQuery('.MPWmanageCartBox').show();
            jQuery('.MPWmanageCartCloseIcon').show();
            jQuery('.MPWmanageCartOpenIcon').hide();
            jQuery('.MPWmanageCartBox').animate({
                'margin-left': `-${boxWidth}px`,
                'width' : `${boxWidth}px`
            }, 500);
            this.updateCartManagerBox();
            this.updateRefreshCycle();
        },

        closeCartManagerBox: function() {
            this.state.isCartManagerOpened = false;
            this.storeState();
            jQuery('.MPWmanageCartCloseIcon').hide();
            jQuery('.MPWmanageCartOpenIcon').show();
            jQuery('.MPWmanageCartBox').animate({
                'margin-left': '-36px',
                'width' : '36px'
            }, 500);
            this.updateRefreshCycle();
        },

        graphArgsToImageUrl: function(graphArgs) {
            const WIDTH = 300;
            const HEIGHT = 160;
            const queryString = IGH.util.removeQueryParams(graphArgs , ['Action', 'Version', 'WidthInPixels', 'HeightInPixels', 'ShowLegend', 'LabelLeft', 'LabelRight', 'width', 'height']);
            const params = IGH.util.parseQueryParams(graphArgs);
            let path;

            // Check if it's a CloudWatch graph
            if (params.metricWidget) {
                path = `/cw/getMetricWidgetImage?${queryString}&width=${WIDTH}&height=${HEIGHT}`;
            } else {
                path = `/mws?Action=GetGraph&Version=2007-07-07&${queryString}&ShowLegend=false&WidthInPixels=${WIDTH}&HeightInPixels=${HEIGHT}`;
            }

            return MonitorPortalRoot + path;
        },

        updateCartManagerBox: function() {
            var self = this;
            this.restoreState();
            var innerHtml = '<table><tr>';
            for (var i = 0; i < this.numItems; i++) {
                var graphArgs = this.state.graphArgs[i];
                var graphPreviewUrl = this.graphArgsToImageUrl(graphArgs);
                innerHtml += '<td>' +
                  '<div class="MPWremoveItem MPWbutton" data-index="' + i + '" title="Remove this graph from cart."></div>' +
                  '<img class="MPWmanageCartImg" src="' + graphPreviewUrl + '">' +
                  '</td>';
            }
            innerHtml += '</tr></table>';
            jQuery('.MPWmanageCartGraphContainer').html(innerHtml);
            jQuery('.MPWmanageCartGraphContainer .MPWbutton').on('click', function () {
                self.removeGraphFromCart(self.state.graphArgs[jQuery(this).attr('data-index')]);
            });
        },

        moveCartToBottom: function() {
            this.state.position = 'bottom';
            this.storeState();
            jQuery('.MPWcart').css('top', 'initial').css('bottom', '40px');
            jQuery('.MPWmoveCartToBottomIcon').hide();
            jQuery('.MPWmoveCartToTopIcon').show();
        },

        moveCartToTop: function() {
            this.state.position = 'top';
            this.storeState();
            jQuery('.MPWcart').css('top', '40px').css('bottom', 'initial');
            jQuery('.MPWmoveCartToBottomIcon').show();
            jQuery('.MPWmoveCartToTopIcon').hide();
        },

        empty: function(isCancelled) {
            this.state = this.state || { alarms: [] };
            this.state.graphArgs = [];
            this.state.isCartManagerOpened = false;
            this.state.isCancelled = isCancelled;
            this.numItems = 0;
            this.displayNumItems();
            this.storeState();
            this.cartMessage.hide();
            this.closeCartManagerBox();
            return false;
        },

        cancel: function() {
            this.state.isCancelled = true;
            this.storeState();
            this.isMouseOverCart = false;
            this.updateCartVisibility();
            return false;
        },

        updateRefreshCycle: function() {
            // If there are cart items and an open cart manager, or a current alarm make sure refresh timer is started
            if ((this.numItems > 0 && this.state.isCartManagerOpened) || this.currentAlarm) {
                if (! this.refreshTimer) {
                    this.refreshCounter = 0;
                    this.refreshTimer = setInterval(() => {
                        this.doRefreshTick();
                    }, this.REFRESH_UPDATE_IN_MS);

                    this.doRefreshTick(true);
                    jQuery('.MPWrefreshCounter,.MPWtimeSinceLastRefresh').show();
                }
            } else {
                // There shouldn't be a timer, stop it
                if (this.refreshTimer) {
                    clearInterval(this.refreshTimer);
                    this.refreshTimer = null;
                }

                jQuery('.MPWrefreshCounter,.MPWtimeSinceLastRefresh').hide();
            }
        },

        doRefreshTick: function(reset) {
            this.refreshCounter = reset ? 0 : (this.refreshCounter + 1) % this.REFRESH_COUNT;

            // When down to zero, refresh the graphs and alarm state
            if (this.refreshCounter === 0) {
                this.lastRefreshTimestamp = new Date();
                jQuery('.MPWmanageCartImg').each(function() {
                    _refreshImg(this);
                });
                this.updateCarnavalAlarmState();
            }

            // Update the countdown indicator bar
            const proportionRemaining = 1 - this.refreshCounter / this.REFRESH_COUNT;
            jQuery('.MPWrefreshCounterPercent').width(Math.round(proportionRemaining * this.REFRESH_PERCENT_MAX_WIDTH) + 'px');

            // Display seconds since last refresh
            if (this.lastRefreshTimestamp) {
                const now = new Date();
                const secondsSinceLastRefresh = Math.round((now.getTime() - this.lastRefreshTimestamp.getTime()) / 1000);
                jQuery('.MPWtimeSinceLastRefresh').text(`${secondsSinceLastRefresh}s ago`);
            }

            return false;
        },

        updateCartVisibility: function() {
            this.displayNumItems();
            if (this.isMouseOverCart || !this.state.isCancelled) {
                this.cart.show();
                jQuery('.MPWcartButton').show();
                this.state.isCartManagerOpened ?  this.openCartManagerBox() : this.closeCartManagerBox();
                this.state.position === 'bottom' ?  this.moveCartToBottom() : this.moveCartToTop();
            }
            else {
                this.cart.hide();
                jQuery('.MPWcartButton').hide();
            }
        },

        displayNumItems: function() {
            jQuery('.MPWcartNumItems').text(this.numItems == 0 ? '' : this.numItems + '');
            if (this.numItems) {
                jQuery('.MPWcartButton input').prop('disabled', false).css('opacity', '1').css('cursor', 'pointer');
                jQuery('.MPWcartNumItems').css('font-size', this.numItems <= 99 ? '25px' : '17px')
                  .css('top' , this.numItems <= 99 ? '44px' : '49px');
            }
            else {
                jQuery('.MPWcartButton input:not(.addGraphButton)').prop('disabled', true).css('opacity', '0.50')
                  .css('cursor', 'not-allowed');
            }
        },

        storeState: function() {
            if (localStorage) {
                localStorage.setItem(this.CART_STORAGE_KEY, JSON.stringify(this.state));
                this.numItems = this.state.graphArgs.length;
            }
        },

        restoreState: function() {
            try {
                this.state = JSON.parse(localStorage.getItem(this.CART_STORAGE_KEY));
                if (!this.state) {
                    this.empty(true);
                }
                this.state.graphArgs = this.state.graphArgs.filter(Boolean); // Remove any empty entries
                this.numItems = this.state.graphArgs.length;
                this.displayNumItems();
            } catch(e) {
                this.empty(true);
            }
        },

        updateCartIcon: function() {
            var graphUrl = isIgraph ? getGraphUrl() : getGraphArgs(IGH.hoveredImage, false);
            var isGraphPresentOnCart = this.isGraphPresentOnCart(graphUrl);
            jQuery('#iGraphCartIcon').addClass(isGraphPresentOnCart ? 'removeFromCartIcon' : 'addToCartIcon');
            jQuery('#iGraphCartIcon').removeClass(isGraphPresentOnCart ? 'addToCartIcon' : 'removeFromCartIcon');
            jQuery('#iGraphCartIcon').attr('title', isGraphPresentOnCart ? 'Remove from iGraph Shopping Cart.'
              : 'Add to Shopping Cart, for merging with other graphs, or live dashboard.');
        },

        getGraphUrlForCart: function(url) {
            return url ? IGH.util.removeQueryParams(IGH.util.removeDomainFromUrl(url), this.NOT_NEEDED_PARAMS).replace(/[&]+/g, '&').replace('=-PT0H','=P0D') : null;
        },

        getCartHtml: function() {
            return '<div class="MPWcart">' +
              '<textarea name="MPWcart" ondrop="iGraphHelper.IGH.WikiCart.cartDropEventDetected(event)"></textarea>' +
              '<span class="MPWcartDragDrop">Drag/drop or double click<br>graphs here for merging.</span>' +
              '<a id="MPWcartAlarmState" target="_blank"></a>' +
              '<span class="MPWcartNumItems">0</span>' +
              '<span class="MPWcartBigIcon" title="Drag/drop or double click graphs here for merging."></span>' +
              '<span class="MPWmoveCartToBottomIcon" title="Position cart at bottom right of page"></span>' +
              '<span class="MPWmoveCartToTopIcon" title="Position cart at top right of page"></span>' +
              '<div class="MPWcartMessage"></div>' +
              '<div class="MPWcartButton">' +
              '<input type="submit" class="MPWbutton primary checkoutButton" value="Merge graphs" title="Merge all graphs in cart and open in new window.">' +
              '<input type="submit" class="MPWbutton addGraphButton" value="Add all graphs" title="Add all graphs from this page to the cart (only manually refreshed snapshots will add).">' +
              '<input type="submit" class="MPWbutton emptyCartButton" value="Empty cart" title="Remove all graphs from cart.">' +
              '</div>' +
              '<a class="MPWcartCancel" href="#"></a>' +
              '<div class="MPWmanageCartBox">' +
              '<span class="MPWmanageCartCloseIcon"></span>' +
              '<span class="MPWmanageCartOpenIcon"></span>' +
              '<span class="MPWrefreshCartIcon"></span>' +
              '<span class="MPWtimeSinceLastRefresh" title="Time since the last cart refresh was triggered"></span>' +
              '<div class="MPWrefreshCounter">' +
              '<div class="MPWrefreshCounterPercent"></div>' +
              '</div>' +
              '<div class="MPWmanageCartGraphContainer"></div>' +
              '</div>' +
              '</div>';
        }
    };

    /*
     * TT integration, for displaying graphs within TT communication
     */
    IGH.TT = {
        CM_COMMUNICATION_TAB: "#tab-communication",
        CM_REFRESH_COMMUNICATION: "#update_communication_link",
        REFRESH_COMMUNICATION: "#update_chatter_link",
        SEARCH_RESULTS_HEADERS: "#search_results thead th",
        SEARCH_RESULTS_ROWS: "#search_results tbody tr",
        CORRESPONDENCE_TAB: "#tab_correspondence",
        CORRESPONDENCE_VIEW_ROWS: "#correspondence_view tr",
        CHATTER_TAB: "#tab_chatter",
        CHATTER_VIEW_ROWS: "#chatter_view tr",
        LAST_SAVED_TT_FIELD: "iGraphHelper.lastSavedTT",
        OVERVIEW_TAB_CONTENT: "#tab-overview",
        SEVERITY_COLORS: { '1': '#990000', '2': '#993333', '3': '#4881b6', '4': '#52789a', '5': '#666666' },
        PORTAL: "https://monitorportal.amazon.com",
        SEARCH_RESULTS_BUTTONS: "#hd table tr td:eq(1)",
        SIM_TICKETING: "SIM Ticketing",

        initialize: function() {
            if (this.isOnTT()) {
                this.addTTVerticalLines();
                this.displayEmbeddedImages();
                var oldRegisterActionMenus = registerActionMenus;
                registerActionMenus = function() {
                    oldRegisterActionMenus();
                    IGH.TT.displayCorrespondenceTabIfNeeded();
                    IGH.TT.displayEmbeddedImages();
                }
                this.trapTTSaves();
            }
            else if (this.isOnTTSearch()) {
                this.addTTSearchVerticalLines();
            }
            else if (this.isOnCM()) {
                this.addCMVerticalLines();
                this.displayEmbeddedImages();
                var old_convert_chatter_time = convert_chatter_time;
                convert_chatter_time = function(show_timezone) {
                    old_convert_chatter_time(show_timezone);
                    IGH.TT.displayCorrespondenceTabIfNeeded();
                    IGH.TT.displayEmbeddedImages();
                }
            }
            else if (this.isOnSIMTicketing()) {
                setInterval(function() {
                    IGH.TT.addSimTVerticalLines()
                }, 3000);

                // SIM Ticketing can update content at any time, so simplest is to periodically (every second) look for embedded images
                setInterval(function() {
                    IGH.TT.displayEmbeddedImages();
                }, 1000);
            }
        },

        displayEmbeddedImages: function() {
            $('a[href*="monitorportal.amazon.com/snap"],a[href*=iGraphSnapshot],a[href*=TT-EMBED]').filter(':not(.tt_button , a[href*=iGraphAnalyzer])').each(function(link) {
                if ($(this).children(".expandedIGraph,img").length == 0) {
                    const imgUrl = $(this).attr('href');
                    const sourceUrl = extractQueryValue(imgUrl, 'sourceUrl');
                    const sourceUrlParam = sourceUrl ? `data-sourceUrl="${decodeURIComponent(sourceUrl)}"` : '';
                    $(this).append(`<br/><div class="expandedIGraph" style="display: inline-block;">
                                <img src="${imgUrl}" ${sourceUrlParam} title="Inlined image provided by iGraph Helper"/>
                            </div><br/>`);
                }
            })
        },

        trapTTSaves: function() {
            $("#save-button").on('click', function() { IGH.TT.recordSavedTTId(); });
        },

        currentTTId: function() {
            return $("#case_id").val();
        },

        recordSavedTTId: function() {
            this.localStore(this.LAST_SAVED_TT_FIELD, this.currentTTId());
        },

        localStore: function(id, val) {
            if (typeof localStorage !== 'undefined') {
                if (typeof val !== 'undefined') {
                    localStorage.setItem(id, val);
                }
                else {
                    return localStorage.getItem(id);
                }
            }
            return null;
        },

        displayCorrespondenceTabIfNeeded: function() {
            if ($(this.OVERVIEW_TAB_CONTENT).is(':visible') && (this.localStore(this.LAST_SAVED_TT_FIELD) === this.currentTTId()) &&
              (($(this.CHATTER_VIEW_ROWS).length > 1) || ($(this.CORRESPONDENCE_VIEW_ROWS).length > 2))) {
                $(this.CHATTER_TAB).trigger('click');
                $(this.CORRESPONDENCE_TAB).trigger('click');
            }
            this.localStore(this.LAST_SAVED_TT_FIELD, null);
        },

        isOnTT: function() {
            return (($(this.REFRESH_COMMUNICATION).length || $(this.CORRESPONDENCE_TAB).length)
              && typeof registerActionMenus !== 'undefined');
        },

        isOnTTSearch: function() {
            return $(this.SEARCH_RESULTS_ROWS).length > 0;
        },

        isOnCM: function() {
            return ($(this.CM_REFRESH_COMMUNICATION).length && typeof convert_chatter_time !== 'undefined');
        },

        isOnSIMTicketing: function() {
            return this.SIM_TICKETING === document.title;
        },

        getGmtOffset: function(date) {
            var gmtOffset = date.replace(/.*GMT/, '').replace(')', '').substring(0, 5);
            gmtOffset = gmtOffset.substring(0, 3) + ':' + gmtOffset.substring(3);
            return gmtOffset;
        },

        getTTColor: function(severity) {
            var color = this.SEVERITY_COLORS[severity];
            return color ? color : 'red';
        },

        addTTVerticalLines: function() {
            var ttNum = $.trim($('#context_bar td:eq(0)').text().replace('TT', ''));
            var severity = parseInt($('#context_bar td:eq(1)').text());
            var start = $('#context_bar td:eq(2)').text();
            var end = $('#context_bar td:eq(3)').text();
            var gmtOffset = this.getGmtOffset($('#context_bar th:eq(2)').text());
            var verticalLineDef = IGH.util.createVerticalLine(ttNum, severity, this.ttDateToXmlDate(start, gmtOffset), this.ttDateToXmlDate(end, gmtOffset), gmtOffset)
            $('<div style="float: left; margin-top: 12px;"><a class="button iGraphVerticalLineButton" style="margin-left: 20px; font-weight: normal;">iGraph Vertical Lines...</a>' +
              '&nbsp;<span style="font-size: 12px;">(<a target="_blank" title="Open blank iGraph with vertical lines" href="' + this.iGraphUrl(verticalLineDef) + '">iGraph</a>)</span></div>').insertBefore('#nav-section');

            IGH.util.buttonAcknowledgmentMessageUtil(
              '.iGraphVerticalLineButton',
              "Vertical lines copied to clipboard",
              function () {
                  GMUtils.setClipboard(verticalLineDef);
              }
            );
        },

        convertDateToIsoFormat: function (dateStr) {
            let parts = dateStr.match(/(\d{4}-\d{2}-\d{2}) (\d{1,2}):(\d{2}):(\d{2}) (AM|PM)/);
            if (!parts) return null;

            let date = parts[1];
            let hours = parseInt(parts[2], 10);
            let minutes = parts[3];
            let seconds = parts[4];
            let ampm = parts[5];

            if (ampm === 'PM' && hours < 12) hours += 12;
            if (ampm === 'AM' && hours === 12) hours = 0;

            return new Date(`${date}T${hours.toString().padStart(2, '0')}:${minutes}:${seconds}Z`).toISOString();
        },

        addSimTVerticalLines: async function () {
            var container = $('.created-date') // This is the div that we will be injecting into
            var iGraphVerticalLineContainerClass = 'iGraphVerticalLineContainer'

            if($(`.${iGraphVerticalLineContainerClass}`).length < 1 && container.length > 0) { // Verify we have not already added our div, and that the container we need is present
                try {
                    var ticketDetails = $('.issue-detail-side')
                    var ttNum = ticketDetails.find('.ticket-id').text()
                    var severity = ticketDetails.find('.issue-summary-severity').find('.info-value').text()
                    var start = ticketDetails.find('.created-date').find('.info-value')
                    var startDateFormatted
                    try {
                        startDateFormatted = new Date(this.SimTDateToXmlDate(start[0].innerText)).toISOString();
                    } catch(e) {
                        startDateFormatted = this.convertDateToIsoFormat(this.SimTDateToXmlDate(start[0].innerText));
                    }

                    if (ttNum.match(/INSIGHTS-TT-|SIMTicketing-/)) {
                        const ttNumFromLocation = document.location.pathname.split('/')[1];

                        if (ttNumFromLocation) {
                            ttNum += ` - ${ttNumFromLocation}`;
                        }
                    }

                    var igraphVerticalLineDef = IGH.util.createVerticalLine(ttNum, severity, startDateFormatted)
                    var igraphButtonClass = 'iGraphVerticalLineButton'
                    var igraphButton = `<a class="button ${igraphButtonClass}" style="font-weight: normal; cursor: pointer;">iGraph</a>`
                    var igraphLink = `<span style="font-size: 12px;">(<a target="_blank" title="Open blank iGraph with vertical lines" href="${this.iGraphUrl(igraphVerticalLineDef)}">iGraph</a>)</span>`

                    var cloudwatchButtonClass = 'cloudwatchVerticalLineButton'
                    var cloudwatchVerticalLineDef = IGH.util.createCloudWatchVerticalLine(ttNum, severity, startDateFormatted)
                    var cloudwatchButton = `<a class="button ${cloudwatchButtonClass}" style="font-weight: normal; cursor: pointer;">Cloudwatch</a>`

                    container.prepend(`<div class="display-mode-container ${iGraphVerticalLineContainerClass}" style="position: relative;">` +
                        `<div class="info-key" style="font-weight: 700;">Vertical Lines:</div>` +
                        `<div class="info-value"><div>${cloudwatchButton}<span> | </span>${igraphButton}&nbsp;${igraphLink}</div></div>`)

                    IGH.util.buttonAcknowledgmentMessageUtil(
                        `.${igraphButtonClass}`,
                        "Vertical lines copied to clipboard",
                        function () {
                            GMUtils.setClipboard(igraphVerticalLineDef);
                        }
                    );
                    IGH.util.buttonAcknowledgmentMessageUtil(
                        `.${cloudwatchButtonClass}`,
                        "Vertical lines copied to clipboard",
                        function () {
                            GMUtils.setClipboard(cloudwatchVerticalLineDef);
                        }
                    );
                } catch (err) {
                    console.log("Error adding vertical lines", err)
                }
            }
        },

        getTTSearchColIndex: function() {
            var colIndex = {};
            $(this.SEARCH_RESULTS_HEADERS).each(function(index, col) {
                  var colText = $.trim($(col).text())
                  if (colText != "") {
                      colIndex[colText] = index;}
              }
            );
            return colIndex;
        },

        getCol: function(row, colName, colIndex) {
            var col = colIndex[colName];
            if (col) {
                return $.trim($('td:eq(' + col + ')', row).text());
            }
            return null;
        },

        addTTSearchVerticalLines: function() {
            var tickets = $(this.SEARCH_RESULTS_ROWS);
            var colIndex = this.getTTSearchColIndex();
            var verticalLineDef = '';
            var sep = '';
            tickets.each(function() {
                var createDate = IGH.TT.getCol(this, "Create Date", colIndex);
                var ttNum =  IGH.TT.getCol(this, "Case ID", colIndex);
                var severity =  IGH.TT.getCol(this, "Impact", colIndex);
                var desc =  IGH.TT.getCol(this, "Description", colIndex);
                if (createDate != null) {
                    var gmtOffset = IGH.TT.getGmtOffset(createDate);
                    verticalLineDef += sep + 'TT ' + ttNum + '[' + severity + ']: ' + encodeURIComponent(desc) + ' #color=' + IGH.TT.getTTColor(severity) + ' @' + IGH.TT.ttDateToXmlDate(createDate, gmtOffset);
                    sep = ',';
                }
            });
            if (verticalLineDef != '') {
                $('<div style="display: inline-block; margin-top: 18px;">' +
                  'iGraph: ' +
                  '<a class="button iGraphVerticalLineButton" title="View iGraph vertical line definitions for search results (added by iGraph Helper)"><span>Vertical Lines...</span></a>' +
                  '<a class="button iGraphEmbedButton" title="Embed an iGraph in search results page (added by iGraph Helper)"><span>Embed...</span></a>' +
                  '</div>').appendTo(this.SEARCH_RESULTS_BUTTONS);
                $('.iGraphVerticalLineButton').on('click', function() { prompt("Vertical Lines for pasting into iGraph", verticalLineDef);} );
                $('.iGraphEmbedButton').on('click', function() {
                    var iGraphUrl = prompt("Paste iGraph URL for graph to embed", "");
                    IGH.TT.addTTIGraph(verticalLineDef, iGraphUrl.replace(/.*[?]/, ""));
                });
                this.addTTIGraph(verticalLineDef);
            }
        },

        addTTIGraph: function(verticalLineDef, iGraph) {
            var queryParams = IGH.util.parseQueryParams();
            var fullTTLink;
            if (!iGraph) {
                if (queryParams['SchemaName1']) {
                    fullTTLink = window.location.href;
                    iGraph = IGH.util.removeQueryParams(window.location.search.replace(/^[?]/, ""), ["search"]);
                }
                else {
                    if (localStorage && localStorage.getItem("iGraph")) {
                        iGraph = localStorage.getItem("iGraph");
                        fullTTLink = window.location.href + '&' + iGraph;
                    }
                }
            }
            else {
                fullTTLink = window.location.href.replace(/search=Search..*/, 'search=Search!') + '&' + iGraph;
            }

            if (iGraph) {
                if (localStorage) {
                    localStorage.setItem("iGraph", iGraph);
                }
                var graph = this.iGraph(verticalLineDef, iGraph);
                $('.iGraphContainer,.iGraphWikiButtonContainer').remove();
                $('<div class="iGraphContainer"><a href="#" class="iGraphRemove">Remove this graph</a><br>' + graph + '</div>').insertBefore('#search_results');
                $('<div style="display: inline-block; margin-top: 18px;" class="iGraphWikiButtonContainer">' +
                  '<a class="button iGraphWikiButton" title="View Wiki code for dashboarding this page (added by iGraph Helper)"><span>Wiki...</span></a>' +
                  '</div>').appendTo(this.SEARCH_RESULTS_BUTTONS);
                $('.iGraphRemove').on('click', function() {
                    $('.iGraphContainer').remove();
                    if (localStorage) {
                        localStorage.removeItem("iGraph");
                    }
                });
                $('.iGraphWikiButton').on('click', function() {
                    var sanitizedLink = fullTTLink.replace(/\[/g, "%5B").replace(/\]/g, "%5D") + "#bd{{StringLinks/Inline|auto=on|width=1200|height=450}}";
                    IGH.util.lightbox('<span>Copy and paste this into Wiki (make sure you have <a target="_blank" href="https://w.amazon.com/index.php/StringLinks">StringLinks</a> installed)</span><br>' +
                      '<textarea class="iGraphWikiLink" style="width: 500px; height: 280px;">[' + sanitizedLink + ' My TT Embedded Graph (please change this text)]</textarea>', 500, 300);
                    $('.iGraphWikiLink').trigger('select');
                });
                decorateGraphs();
            }
        },

        ttDateToXmlDate: function(date, offset = "") {
            var m = date.match(/(\d+)-(\d+)-(\d+) (\d+):(\d+):(\d\d)( ?..)/);
            if (m) {
                m[4] = m[4] == "12" ? "00" : m[4];     // Convert '12' hour to '00' for 24 hour clock
                return m[1] + '-' + m[2] + '-' + m[3] + 'T' + (m[7].trim().toUpperCase() == "AM" ? m[4] : 12 + parseInt(m[4])) + ':' + m[5] + ':' + m[6] + offset;
            }
            return "now";
        },

        SimTDateToXmlDate: function(date) {
            /*
            It expects newline separated string.
            From something like
                2023-11-13T10:29:48-06:00
                2023-11-13T16:29:48Z
                Epoch: 1699892988
            return the first line which is something SimT user configured for themselves.
            The rest two lines are optional if user configured to show those.
            */
            return date.split('\n')[0]
        },


        addCMVerticalLines: function() {
            var cmId = $('#cm_id').text();
            var scheduledStart = $('#cm_scheduled_start').text();
            var scheduledEnd = $('#cm_scheduled_end').text();
            var actualStart = $('#cm_actual_start').text();
            var actualEnd = $('#cm_actual_end').text();
            var verticalLineDef = '(' + scheduledStart + ',CM ' + cmId + ' scheduled:' + this.getReadableDateFromXmlDate(scheduledEnd) + ' @' + scheduledEnd + ')';
            $('<div style="float: left; margin-top: 18px;"><a class="button iGraphVerticalLineButton" style="margin-left: 20px; font-weight: normal;">iGraph Vertical Lines...</a>' +
              '&nbsp;<span style="font-size: 12px;">(<a target="_blank" title="Open blank iGraph with vertical lines" href="' + this.iGraphUrl(verticalLineDef) + '">iGraph</a>)</span></div>').insertAfter('#header .logo');
            if (actualStart != '') {
                verticalLineDef += ',(' + actualStart + ',CM ' + cmId + ' actual:' + this.getReadableDateFromXmlDate(actualEnd) + ' @' + actualEnd + ')';
            }
            $('.iGraphVerticalLineButton').on('click', function() { prompt("Vertical Lines for pasting into iGraph", verticalLineDef);} );
        },

        getReadableDateFromXmlDate: function(xmlDate) {
            return xmlDate == "now" ? xmlDate : xmlDate.replace(/-/g, '/').replace('T', ' ').replace(/:..Z/, "") + " UTC";
        },

        iGraphUrl: function(verticalLineDef) {
            return this.PORTAL + '/igraph?VerticalLine1=' + encodeURIComponent(verticalLineDef);
        },

        iGraph: function(verticalLineDef, graphParams) {
            var allParams =  encodeURIComponent(verticalLineDef) +'&' + graphParams;
            return '<a class="iGraph" target="_blank" href="' + this.PORTAL + '/igraph?VerticalLine1=' + allParams + '"><img src="' + this.PORTAL + '/mws?Action=GetGraph&Version=2007-07-07&VerticalLine1=' + allParams + '" style="box-shadow: 5px 5px 17px rgb(136, 136, 136); margin-left: 50px;"></a>';
        }
    };

    IGH.util = typeof IGH.util === 'undefined'  ? {} : IGH.util;
    IGH.graph = typeof IGH.graph === 'undefined'  ? {} : IGH.graph;
    IGH.MWS = typeof IGH.MWS === 'undefined'  ? {} : IGH.MWS;

    // Some constants
    IGH.KEY_CODE_ENTER = 13;

    // For search syntax
    IGH.SEARCH_FIELD_DELIMITER = "=";
    IGH.SEARCH_EXACT_MATCH_DELIMITER = "$";
    IGH.SEARCH_CLAUSE_SEPARATOR = " ";
    IGH.SEARCH_AND_CLAUSE = "AND";
    IGH.SEARCH_NOT_CLAUSE = "NOT";
    IGH.SEARCH_NOT_CLAUSE_SHORT = "!";
    IGH.SEARCH_OR_CLAUSE = "OR";
    IGH.SEARCH_OPEN_PAREN = "(";
    IGH.SEARCH_CLOSE_PAREN = ")";

    IGH.SCHEMA_NAME_SEARCH_FIELD          = "schemaname";
    IGH.SCHEMA_NAME_ERROR_LOG             = "ErrorLog";
    IGH.SCHEMA_NAME_SNITCH                = "Snitch";
    IGH.SCHEMA_NAME_PAQ                   = "PAQ";
    IGH.SCHEMA_NAME_SUBSCRIPTION_SERVICES = "SubscriptionServices";

    IGH.METRIC_FIELD_HOST_GROUP     = "HostGroup";
    IGH.METRIC_FIELD_OPERATION_NAME = "OperationName";
    IGH.METRIC_FIELD_OPERATION      = "Operation";
    IGH.METRIC_FIELD_SERVICE_NAME   = "ServiceName";
    IGH.METRIC_FIELD_SERVICE        = "Service";
    IGH.METRIC_FIELD_SIGNATURE_NAME = "SignatureName";
    IGH.METRIC_FIELD_SIGNATURE      = "Signature";

    IGH.METRIC_VALUE_NONE           = "NONE";

    IGH.PERIOD_FIELD = "period";
    IGH.STAT_FIELD = "stat";
    IGH.METRIC_ID_SEPARATOR = "|";

    // MWS API
    IGH.MWS_BASE_URL = "/mws";
    IGH.MWS_ARG_ACTION = "Action";
    IGH.MWS_ARG_VERSION = "Version=2007-07-07";
    IGH.MWS_ARG_SCHEMA_NAME  = "SchemaName";
    IGH.MWS_ARG_PERIOD       = "Period";
    IGH.MWS_ARG_STAT         = "Stat";
    IGH.MWS_ACTION_GET_GRAPH = "GetGraph";
    IGH.MWS_ACTION_GET_METRIC_DATA = "GetMetricData";

    IGH.QPLOT_ARG_SCHEMA_NAME = "origin";
    IGH.QPLOT_ARG_PERIOD      = "period";
    IGH.QPLOT_ARG_STAT        = "statname";

    IGH.SUBMENU_PROPERTY = "submenu";

    IGH.IGRAPH_BASE_URL = "/igraph";
    IGH.IGRAPH_SEARCH_BASE_URL = "/igraph/search";

    /*
     * Lowercase the first letter of the parameter
     */
    IGH.util.getFunctionName = function(parameter){
        // lowercase the first letter ( for method names)
        return parameter.charAt(0).toLowerCase() + parameter.substring(1);
    };

    /*
     * Uppercase the first letter of the parameter
     */
    IGH.util.getAttributeName = function(parameter){
        // uppercase the first letter ( for method names)
        return parameter.charAt(0).toUpperCase() + parameter.substring(1);
    };
    /**
     *  constants that belong to the MWS API
     */
    // How we represent boolean in calls to MWS
    IGH.MWS.Boolean = {
        TRUE: "true",
        FALSE: "false"
    };

    //Defines valid time ranges types
    IGH.MWS.TimeRangeType = {
        FIXED: "Fixed",
        RELATIVE: "Relative",
        NATURAL: "Natural"
    };

    IGH.MWS.LegendPlacement = {
        BOTTOM: "bottom",
        RIGHT: "right"
    };

    IGH.MWS.GraphType = {
        BITMAP: "bitmap",
        ZOOMER: "zoomer",
        PIE: "pie",
        BAR: "bar"
    };

    IGH.MWS.MetricResult = {
        METRIC_DATA: "MetricData",
        NO_DATA: "NoData",
        NO_METRIC: "NoMetric",
        PROCESSING_ERROR: "ProcessingError",
        THROTTLED: "Throttled"
    };

    IGH.MWS.Operations = {
        ADDITION: "+",
        DIVISION: "/",
        MULTIPLICATION: "*",
        SUBTRACTION: "-"
    };

    IGH.MWS.StatOptions = {
        VAL: "Val",
        PREDICTIONS: "Predictions"
    };

    IGH.MWS.YAxisPreference = {
        LEFT: "left",
        RIGHT: "right"
    };

    IGH.MWS.AggregationFunction = {
        AVERAGE: "average",
        MINIMUM: "minimum",
        MAXIMUM: "maximum",
        MEDIAN: "median",
        SUM: "sum",
        WEIGHTED_AVERAGE: "weightedAverage"
    };

    IGH.MWS.ValueUnit = {
        NANOSECOND: "nanosecond",
        MICROSECOND: "microsecond",
        MILLISECOND: "millisecond",
        SECOND: "second",
        MINUTE: "minute",
        HOUR: "hour",
        DAY: "day",
        WEEK: "week",
        BYTE: "byte",
        KILOBYTE: "kilobyte",
        MEGABYTE: "megabyte",
        GIGABYTE: "gigabyte",
        TERABYTE: "terabyte",
        KIBIBYTE: "kibibyte",
        MEBIBYTE: "mebibyte",
        GIBIBYTE: "gibibyte",
        TEBIBYTE: "tebibyte",
        CPUSECOND: "cpuSecond",
        REQUEST: "request",
        PAGE: "page",
        ORDER: "order",
        PERCENT: "percent",
        FILE: "file",
        NONE: "none"
    };

    IGH.MWS.QS = {
        SCHEMA_NAME: "SchemaName",
        HEIGHT_IN_PIXELS: "HeightInPixels",
        WIDTH_IN_PIXELS: "WidthInPixels",
        GRAPH_TITLE: "GraphTitle",
        SHOW_LEGEND: "ShowLegend",
        SHOW_LEGEND_ERRORS: "ShowLegendErrors",
        LEGEND_PLACEMENT: "LegendPlacement",
        SHOW_X_AXIS_LABEL: "ShowXAxisLabel",
        DECORATE_POINTS: "DecoratePoints",
        GRAPH_TYPE: "GraphType",
        TIMEZONE: "Timezone",
        SHOW_GAPS: "ShowGaps",
        HORIZONTAL_LINE: "HorizontalLine",
        LOG_SCALING: "LogScaling",
        UPPER_VALUE: "UpperValue",
        LOWER_VALUE: "LowerValue",
        CLIP_UPPER_VALUE: "ClipUpperValue",
        SHOW_Y_AXIS: "ShowYAxis",
        SHRINK_BOUNDS_TO_GRAPH_DATA: "ShrinkBoundsToGraphData",
        LABEL: "Label",
        START_TIME: "StartTime",
        END_TIME: "EndTime",
        PERIOD: "Period",
        STAT: "Stat",
        VALUE_UNIT: "ValueUnit",
        STAT_OPTIONS: "StatOptions",
        Y_AXIS_PREFERENCE: "YAxisPreference",
        AGGREGATION_FUNCTION: "AggregationFunction",
        AGGREGATION_PERIOD: "AggregationPeriod",
        FUNCTION_EXPRESSION: "FunctionExpression",
        FUNCTION_LABEL: "FunctionLabel",
        FUNCTION_OPERATE_ON_PARTIAL_INPUT: "FunctionOperateOnPartialInput",
        FUNCTION_Y_AXIS_PREFERENCE: "FunctionYAxisPreference",
        VERTICAL_LINE: "VerticalLine"
    };

    IGH.MWS.QS_DEFAULTS = {
        WIDTH_IN_PIXELS: 640,
        HEIGHT_IN_PIXELS: 480,
        SHOW_LEGEND: IGH.MWS.Boolean.TRUE,
        SHOW_LEGEND_ERRORS: IGH.MWS.Boolean.TRUE,
        LEGEND_PLACEMENT: IGH.MWS.LegendPlacement.BOTTOM,
        SHOW_X_AXIS_LABEL: IGH.MWS.Boolean.TRUE,
        DECORATE_POINTS: IGH.MWS.Boolean.FALSE,
        GRAPH_TYPE: IGH.MWS.GraphType.BITMAP,
        SHOW_GAPS: IGH.MWS.Boolean.TRUE,
        LOG_SCALING: IGH.MWS.Boolean.FALSE,
        SHOW_Y_AXIS: IGH.MWS.Boolean.TRUE,
        SHRINK_BOUNDS_TO_GRAPH_DATA: IGH.MWS.Boolean.FALSE,
        Y_AXIS_PREFERENCE: IGH.MWS.YAxisPreference.LEFT,
        FUNCTION_OPERATE_ON_PARTIAL_INPUT:  IGH.MWS.Boolean.TRUE,
        STAT_OPTIONS: IGH.MWS.StatOptions.VAL,
        TIMEZONE: "",
        VALUE_UNIT: IGH.MWS.ValueUnit.NONE
        // can't default this until we add fallback in MWS FUNCTION_Y_AXIS_PREFERENCE: IGH.MWS.YAxisPreference.LEFT
    };

    //Defines valid MWS periods
    IGH.Period = {
        ONE_MINUTE: "OneMinute",
        FIVE_MINUTE: "FiveMinute",
        ONE_HOUR: "OneHour",
        ONE_DAY: "OneDay",
        ONE_WEEK: "OneWeek"
    }

    //Defines valid MWS stats
    IGH.Stat = {
        AVG: "avg",
        SUM: "sum",
        N: "n",
        P0: "p0",
        P10: "p10",
        P20: "p20",
        P25: "p25",
        P30: "p30",
        P40: "p40",
        P50: "p50",
        P60: "p60",
        P70: "p70",
        P75: "p75",
        P80: "p80",
        P90: "p90",
        P99: "p99",
        P99_9: "p99.9",
        P99_99: "p99.99",
        P100: "p100",
        GP0: "gp0",
        GP10: "gp10",
        GP20: "gp20",
        GP25: "gp25",
        GP50: "gp50",
        GP90: "gp90",
        GP99: "gp99",
        GP99_9: "gp99.9",
        GP99_99: "gp99.99",
        GP100: "gp100",
        GAVG: "gavg",
        GSUM: "gsum",
        U1000: "u1000",
        U2000: "u2000",
        U3500: "u3500",
        U6000: "u6000",
        O1000: "o1000",
        O2000: "o2000",
        O3500: "o3500",
        O6000: "o6000"
    }
    /*
     * Add observablity (Observer pattern) to the 'that' object
     */
    // 'event' is a string
    // 'listener' is the callback function
    IGH.util.observability = function(that){

        var registry = {};
        var _enabled = true;

        //May be used to temporarily enable/disabled all notifications
        that.enableNotification = function(enabled){
            _enabled = enabled;
        };

        // Send out a notification to all registered listeners for an event
        that.notify = function(event){
            if (_enabled) {
                var listeners = registry[event];
                if (listeners) {
                    for (var i = 0; i < listeners.length; ++i) {
                        listeners[i](event);
                    }
                }
            }
        };

        // Register a listener function with an event
        that.register = function(event, listener){
            if (registry[event]) {
                registry[event].push(listener);
            }
            else {
                registry[event] = [listener];
            }
        };

        // allow chaining
        return that;
    };
    /*
     * urlEncode utility function
     */
    IGH.util.urlEncode = function(string) {
        return escape(string).replace(/[+]/g, "%2B").replace(/\//g, "%2F");
    };

    /*
     * Utility function for getting size of window
     */
    IGH.util.getWindowSize = function() {
        var myWidth = 0, myHeight = 0;
        if (typeof( window.innerWidth ) == 'number' ) {
            //Non-IE
            myWidth = window.innerWidth;
            myHeight = window.innerHeight;
        } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
            //IE 6+ in 'standards compliant mode'
            myWidth = document.documentElement.clientWidth;
            myHeight = document.documentElement.clientHeight;
        } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
            //IE 4 compatible
            myWidth = document.body.clientWidth;
            myHeight = document.body.clientHeight;
        }
        return { width: myWidth, height: myHeight};
    };

    /*
     *  Given an event returns the absolute position of the mouse pointer
     */
    IGH.util.getMouseCoords = function(ev) {
        try {
            ev = ev || window.event;
            if (ev.pageX || ev.pageY) {
                return {
                    x: ev.pageX,
                    y: ev.pageY
                };
            }
            var windowOffset = IGH.util.getWindowOffset();
            return {
                x: ev.clientX + windowOffset.x - document.body.clientLeft,
                y: ev.clientY + windowOffset.y - document.body.clientTop
            };
        }
        catch (e) {
            // The event object was not obtainable or did not contain location information
            return null;
        }
    };

    /*
     * Return the offset of the top left of the window within the
     * current document
     */
    IGH.util.getWindowOffset = function() {
        return {
            x: IGH.util.filterAreaResults(window.pageXOffset ? window.pageXOffset : 0,
              document.documentElement ? document.documentElement.scrollLeft : 0,
              document.body ? document.body.scrollLeft : 0),
            y: IGH.util.filterAreaResults(window.pageYOffset ? window.pageYOffset : 0,
              document.documentElement ? document.documentElement.scrollTop : 0,
              document.body ? document.body.scrollTop : 0)
        }
    };

    /*
     * Utility function for getting the correct number in the DOM for x and y positions.
     * It is given numbers that come from the window, document and documeny body and
     * the algorithm figures out the correct one to use.
     */
    IGH.util.filterAreaResults = function(n_win, n_docel, n_body) {
        var n_result = n_win ? n_win : 0;
        if (n_docel && (!n_result || (n_result > n_docel)))
            n_result = n_docel;
        return n_body && (!n_result || (n_result > n_body)) ? n_body : n_result;
    };

    /* Prints an integer into a nice string format */
    IGH.util.numberWithCommas = function(nStr, decimalPlaces) {
        nStr += '';
        if (typeof decimalPlaces !== undefined) {
            nStr = parseFloat(nStr).toFixed(decimalPlaces) + '';
        }
        var beforeAfterDec = nStr.split('.');
        var beforeDec = beforeAfterDec[0];
        var afterDec = beforeAfterDec.length > 1 ? '.' + beforeAfterDec[1] : '';
        afterDec = afterDec.replace(/0*$/, "");
        if (afterDec === ".") {
            afterDec = "";
        }
        var regex = /(\d+)(\d{3})/;
        while (regex.test(beforeDec)) {
            beforeDec = beforeDec.replace(regex, '$1' + ',' + '$2');
        }
        return beforeDec + afterDec;
    };

    /*
     * Makes elements appear/disappear by "sliding" into/out of view
     */
    IGH.util.toggleExpander = function(expander, controlSelector){
        var expanderSpan = expander.firstChild.nextSibling;
        $(expanderSpan).toggleClass("expanderGrow");
        $(expanderSpan).toggleClass("expanderShrink");
        IGH.util.toggleSlide(controlSelector);
    };

    /*
     * Makes elements appear/disappear by "sliding" into/out of view
     */
    IGH.util.toggleSlide = function(jquerySelector){
        if ($(jquerySelector).is(":hidden")) {
            $(jquerySelector).slideDown("fast");
            return true;
        }
        else {
            $(jquerySelector).slideUp("fast");
            return false;
        }
    };

    /*
     * Makes elements appear/disappear by "fading" into/out of view
     */
    IGH.util.toggleFade = function(jquerySelector){
        if ($(jquerySelector).is(":hidden")) {
            $(jquerySelector).fadeIn();
            return true;
        }
        else {
            $(jquerySelector).fadeOut();
            return false;
        }
    };

    /*
     * Toggles visibility of items. Returns true if the items are now visible
     */
    IGH.util.toggleShowHide = function(jquerySelector) {
        if ($(jquerySelector).is(":hidden")) {
            $(jquerySelector).show();
            return true;
        }
        else {
            $(jquerySelector).hide();
            return false;
        }
    },

      /*
       * Scrolls to top of screen in animation
       */
      IGH.util.scrollToTop = function() {
          $('html, body').animate({scrollTop:0}, 'slow');
      },

      /*
       * Scrolls to Y value of particular object (jquery selector) on screen
       */
      IGH.util.scrollTo = function(jquerySelector) {

          $('html, body').animate({scrollTop: $(jquerySelector).offset().top}, 'slow');
      },

      /*
       * Return the URL parameters from the href that launched the current window.
       *
       * Remove any anchors from the end
       */
      IGH.util.getUrlParameters = function() {
          return window.location.href.replace(/.*[?]/, "").replace(/#\w*$/, "");
      };

    /*
     * Remove domain from a URL
     */
    IGH.util.removeDomainFromUrl = function(url) {
        return url.replace(/^http[s]*(?:\/[^\/]*){2}/, "")
    };

    /*
     * Utility function to help setting/getting of object properties
     *
     * Return property value if 'value' parameter is not specified else
     * set the property value and return the object, so that settings
     * can be 'chained' like so: a.prop1(10).prop2(20);
     */
    IGH.util.GetterSetter = function(obj, property, value) {
        if (value == undefined) {
            return obj[property];
        }
        else {
            obj[property] = value;
            return obj;
        }
    };

    //returns a function that will validate a value against the supplied enum
    IGH.util.createOptionalEnumValidator = function(validValues) {
        return function(value) {
            if(value === undefined) {
                return true;
            }
            for(var valid in validValues) {
                if(validValues[valid] === value) {
                    return true;
                }
            }
            return false;
        };
    };

    //returns a function that will validate a value against an MWS Boolean
    IGH.util.createOptionalBooleanValidator = function() {
        return function(value) {
            if(value === undefined) {
                return true;
            }
            for(var valid in  IGH.MWS.Boolean ) {
                if(IGH.MWS.Boolean[valid] === value.toLowerCase()) {
                    return true;
                }
            }
            return false;
        };
    };

    /* Helper for setting a query string arg*/
    IGH.util.GetQueryArg = function(field, value) {
        return "&" + field + "=" + this.urlEncode(value);
    };

    /* Helper for setting a qplot arg*/
    IGH.util.GetQplotArg = function(field, value) {
        return " -" + field.toLowerCase() + "=" + value;
    };

    /*
     *  Parses a single Query String parameter into a key/value pair.
     *  Returns a null for invalid, or '{ key: "key", value: "value"}' for valid parameters
     */
    IGH.util.queryParamToKeyValue = function(param) {
        var EQUALS = "=";
        var EQUALS_ENCODED = "%3D";

        var equals = param.indexOf(EQUALS);
        var equalsOffset = EQUALS.length;
        if (equals <= 0) {
            // No '=', try for '%3D'
            equals = param.indexOf(EQUALS_ENCODED);
            equalsOffset = EQUALS_ENCODED.length;
        }
        if (equals > 0) {
            var result = {};
            result.key = param.slice(0, equals);
            result.value = unescape(param.slice(equals + equalsOffset));
            return result;
        }
        return null;
    };

    /*
     * Returns a url in its parts: ['url', 'scheme', 'slash', 'host', 'port', 'path', 'query', 'hash']
     */
    IGH.util.URL_PARTS = ['url', 'scheme', 'slash', 'host', 'port', 'path', 'query', 'hash'];
    IGH.util.parseUrl = function(url) {
        var parse_url = /^(?:([A-Za-z]+):)?(\/{0,3})([0-9.\-A-Za-z]+)(?::(\d+))?(?:\/([^?#]*))?(?:\?([^#]*))?(?:#(.*))?$/;
        var result = parse_url.exec(jQuery.trim(url));
        if (result == null) {
            return null;
        }
        var parsedUrl = {};
        for (i = 0; i < this.URL_PARTS.length; i++) {
            parsedUrl[this.URL_PARTS[i]] = result[i] ? result[i] : "";
        }
        return parsedUrl;
    };

    IGH.util.parseQueryParams = function(query) {
        var str = query || window.location.search;
        var paramMap = {};
        str.replace(new RegExp( "([^?=&]+)(=([^&]*))?", "g" ),
          function($0, $1, $2, $3) {
              paramMap[$1] = $3;
          }
        );
        return paramMap;
    };

    IGH.util.lightbox = Lightbox.display;

    /*
     * Helper for making a batch update to the graph data model. It calls the function passed in
     * with specified parameters and guarantees only one update event is propagated.
     */
    IGH.util.BatchUpdate = function(fn, param1, param2, param3, param4, param5) {
        var model = IGH.graph.model();

        model.enableNotification(false);        // Switch off model events
        var ret = fn(param1, param2, param3, param4, param5);             // Call the passed-in function
        model.enableNotification(true);         // Re-enable model events
        model.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);    // Fire a model changed event
        return ret;
    };

    /*
     * Debugging utility, to display alert of object contents
     */
    IGH.util.LogObject = function(obj) {
        for (var key in obj) {
            try {
                console.log("obj[" + key + "] = " + obj[key]);
            }
            catch (e) {}
        }
    };

    /*
     * Converts XMLObject into string
     */
    IGH.util.xmlToString = function(xml){
        var serialized;
        try {
            serializer = new XMLSerializer();
            serialized = serializer.serializeToString(xml);
        }
        catch (e) {
            // Internet Explorer has a different approach to serializing XML
            serialized = xml.xml ? xml.xml : xml;
        }

        return serialized;
    };

    /*
     *  Given a list of param names, removes them from a URL of parameters and returns the trimmed URL
     */
    IGH.util.removeQueryParams = function(url, paramList) {
        var newUrl = url;
        for (var i = 0; i < paramList.length; i++) {
            var re = new RegExp(paramList[i] + "(=|%3D)[^&]*", "gi");
            newUrl = newUrl.replace(re, "");
        }
        return newUrl;
    };

    IGH.util.replaceQueryParam = function(url, param, value) {
        let newUrl = this.removeQueryParams(url, [param]);
        newUrl += '&' + param + '=' + encodeURIComponent(value);
        return newUrl.replace(/[&]+/g, '&');
    };

    IGH.util.isCloudWatchGraph = function(args) {
        return new RegExp(`\\b${METRIC_WIDGET_URL_PARAM}=`).test(args);
    };

    IGH.util.isSnapshottedGraph = function(imgUrl) {
        return /\/snap\/load\//.test(imgUrl);
    };

    IGH.util.getMetricWidgetFromUrl = function(url) {
        try {
            const OVERRIDE_URL_PARAMS = [ 'start', 'end', 'width', 'height' ];
            const metricWidgetEncodedString = extractQueryValue(url, METRIC_WIDGET_URL_PARAM);
            const metricWidgetString = decodeURIComponent(metricWidgetEncodedString.replace(/\+/g, '%20'));
            const metricWidget = JSON.parse(metricWidgetString);

            // start, end, width, height as URL params can override JSON, so stick them into JSON if found
            OVERRIDE_URL_PARAMS.forEach((param) => {
                const paramValue = extractQueryValue(url, param);
                if (paramValue) {
                    metricWidget[param] = isFinite(paramValue) ? parseFloat(paramValue) : paramValue;
                }
            });

            return metricWidget;
        } catch (e) {
            console.error(e);
            return {};
        }
    };

    IGH.util.getConsoleUrl = function(imgUrl) {
        const DEFAULT_REGION = 'us-east-1';
        let region = DEFAULT_REGION;
        let consoleUrl = 'console.aws.amazon.com/cloudwatch/deeplink.js?region=';
        let metricWidget = {};

        if (imgUrl) {
            metricWidget = IGH.util.getMetricWidgetFromUrl(imgUrl);
            if (metricWidget.region) {
                region = metricWidget.region;
            }
        }

        consoleUrl += region;
        if (region !== DEFAULT_REGION) {
            consoleUrl = region + '.' + consoleUrl;
        }

        const metricWidgetJsonUrl = IGH.util.metricWidgetToJsonUrlParam(metricWidget);
        return `https://${consoleUrl}#metricsV2:graph=${metricWidgetJsonUrl}`;
    };

    // Taken from https://code.amazon.com/packages/MonitorPortalWebsite/blobs/aws-ssl-proxy/--/rails-root/public/javascripts/igraph/graph/CloudWatchGraph.js
    IGH.util.getObserveUrl = function (imgUrl) {
        const CW_OBSERVE_URL = 'observe.aka.amazon.com/?accountId=';
        const DEFAULT_IGRAPH_OBSERVE_ACCOUNT_ID = '590183943009';  // cw-ui-observe+igraph@amazon.com
        const DEFAULT_REGION = 'us-east-1';
        let region = DEFAULT_REGION;
        let metricWidget = {};
        let observeUrl = CW_OBSERVE_URL;
        let accountId;

        if (imgUrl) {
            metricWidget = IGH.util.getMetricWidgetFromUrl(imgUrl);
        }

        if (metricWidget) {
            const graph = IGH.util.metricWidgetToJsonUrlParam(metricWidget);
            const decodedGraph = decodeURIComponent(graph);

            const regexAccountId = /"accountId"\s*:\s*"(\d+)"/;
            const graphedAccountId = decodedGraph.match(regexAccountId);
            accountId = graphedAccountId ? graphedAccountId[1] : null;

            const regexIgraph = /"accountId"\s*:\s*"igraph"/;

            if (!accountId && decodedGraph.match(regexIgraph)) {
                accountId = this.DEFAULT_IGRAPH_OBSERVE_ACCOUNT_ID;
            }
            if (metricWidget.region) {
                region = metricWidget.region;
            }
            if (metricWidget.accountId) {
                accountId = metricWidget.accountId;
            }
            delete metricWidget.theme;
        }

        observeUrl += accountId;

        return 'https://' + observeUrl + '#metricsV2?region=' + region + '&graph=' + IGH.util.metricWidgetToJsonUrlParam(metricWidget);
    };

    IGH.util.metricWidgetToJsonUrlParam = function(metricWidget) {
        const metricWidgetString = JSON.stringify(metricWidget).replace(/[%]7C/g, '|');

        // Need to encode = to %3D and # to %23, to get through to Metrics page in console okay
        return encodeURIComponent(metricWidgetString)
          .replace(/#/g, '%23')
          .replace(/=/g, '%3D');
    };

    IGH.util.graphArgsToCloudWatchGraphUrl = function(args) {
        return `${MonitorPortalRoot}/cw/getMetricWidgetImage?${args}`;
    };

    IGH.util.getLocalTimezoneOffset = function(seperator = "") {
        const timezoneOffsetMin = new Date().getTimezoneOffset();
        let offsetHours = parseInt(Math.abs(timezoneOffsetMin / 60));
        let offsetMinutes = Math.abs(timezoneOffsetMin % 60);

        offsetHours   = (offsetHours < 10 ? '0' : '') + offsetHours;
        offsetMinutes = (offsetMinutes < 10 ? '0' : '') + offsetMinutes;

        // Negative offset means "ahead of UTC"
        return (timezoneOffsetMin <= 0 ? '+' : '-') + offsetHours + seperator + offsetMinutes;
    };

    IGH.util.createVerticalLine = function(ttNum, severity, start, end, gmtOffset) {
        var ttDescription = `TT ${ttNum} [${severity}]`

        if (end == null) { // If no end is specified, add a line
            return `${ttDescription} @ ${start}`;
        } else { // Otherwise add a band
            return `(${ttDescription} @ ${start} , ${end})`;
        }
    },

    IGH.util.createCloudWatchVerticalLine = function(ttNum, severity, start, end) {
        const color = severity === "2" || severity === "1" ? "#d62728" : "#ff7f0e"

        const ttDescription = `TT ${ttNum} [${severity}]`

        const startLine = `{"color": "${color}","label": "${ttDescription}","value": "${start}"}`

        if (end == null) { // If no end is specified, add a line
            return `"annotations": {"vertical": [${startLine}]}`;
        } else { // Otherwise add a band
            return `"annotations": {"vertical": [${startLine},{"color": "${color}","label": "${ttDescription}","value": "${start}"}]}`;
        }
    },

      IGH.util.waitForPageReady = async function(condition, retryDelay, maxRetries) {
          for (let i = 0; i < maxRetries; i++) { // Loop until max retries are exhausted
              await new Promise(resolve => { // Delay to slow down retries
                  setTimeout(() => {
                      resolve();
                  }, retryDelay);
              });

              if (condition() === true) {
                  return;
              }
          }
          throw `Wait for ready failed`
      };

    /*
     * This function takes an html element, a message, and a function and displays a small
     * tooltip with the message after the execution of the function.
     * Note: The containing div must have "position: relative" for the banner to scroll correctly.
     */
    IGH.util.buttonAcknowledgmentMessageUtil = function(buttonSelector, message, clickFunction) {
        $(buttonSelector).on('click', function(e) {
            const messageClass = "igh-copy-msg"
            $(`.${messageClass}`).remove() // Remove all existing messages
            $('<div>', { // Add a hidden div containing the success message to show
                class: messageClass,
                style: "display:none;position:absolute; z-index:1; background-color: white; color: green; padding: 2px; border: 1px solid green;",
                text: message
            }).appendTo(buttonSelector);

            clickFunction(e) // Run the provided click function
            $(`.${messageClass}`).fadeIn("slow", function() { // Fade in and out the message
                window.setTimeout(function() {
                    $(`.${messageClass}`).fadeOut("slow");
                }, 1000)
            })
        } );
    };

    IGH.startsWith = function(str, beginning) {
        return str.indexOf(beginning) == 0;
    };

    /*
     * Implement the DataModel for the graph page of iGraph
     */
    IGH.graph.PARAMS = {
        ENABLED: "enabled",
        USER_LABEL: "UserLabel",
        METRIC: "metric",
        Y_AXIS: "YAxis",
        FUNCTION: "function",
        TYPE: "type",
        MODEL_CHANGED_EVENT: "ModelChanged"
    };

    IGH.graph.createDataModel = function(){

        // lowercase the first letter (of method name) - this should always be safe
        var _getName = function(parameter){
            return parameter.charAt(0).toLowerCase() + parameter.substring(1);
        };

        var _createGetterAndSetter = function(obj, method, property, validator){

            obj[_getName(method)] = function(value){
                if (value === undefined) {
                    return property;
                }
                else {
                    // TODO only apply valid changes ( fail silently otherwise) - is this correct?
                    if (!validator || validator(value)) {
                        // only fire a change if the value changes
                        if (property !== value || typeof value === 'object') {
                            property = value;
                            that.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);
                        }
                    }
                    return obj;
                }
            };
        };

        var _createGetter = function(obj, method, property){
            obj[_getName(method)] = function(){
                return property;
            };
        };

        // We do this rather than use javascript array directly so that we can observe changes
        var _createArray = function(){
            var _array = [];

            var other = {};
            other.size = function(){
                return _array.length;
            };
            other.add = function(element){
                _array.push(element);
                that.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);
            };
            other.get = function(i){
                if (i >= 0 && i < _array.length) {
                    return _array[i];
                }
            };
            other.remove = function(i){
                if (i >= 0 && i < _array.length) {
                    _array.splice(i, 1);
                    that.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);
                }
            };
            other.clear = function(){
                // only fire event on real changes
                if(_array.length > 0) {
                    _array = [];
                    that.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);
                }
            };
            return other;
        };

        var _createSources = function(){
            return _createArray();
        };

        var _createFunctions = function(){
            return _createArray();
        };

        var _createYAxis = function(){
            var _horizontalLine = _createArray();
            var _logScaling = IGH.MWS.QS_DEFAULTS.LOG_SCALING;
            var _showYAxis = IGH.MWS.QS_DEFAULTS.SHOW_Y_AXIS;
            var _upperValue;
            var _lowerValue;
            var _clipUpperValue;
            var _shrinkBoundsToGraphData = IGH.MWS.QS_DEFAULTS.SHRINK_BOUNDS_TO_GRAPH_DATA;
            var _label;

            var that = {};
            _createGetter(that, IGH.MWS.QS.HORIZONTAL_LINE, _horizontalLine);
            _createGetterAndSetter(that, IGH.MWS.QS.LOG_SCALING, _logScaling, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.SHOW_Y_AXIS, _showYAxis, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.UPPER_VALUE, _upperValue);
            _createGetterAndSetter(that, IGH.MWS.QS.LOWER_VALUE, _lowerValue);
            _createGetterAndSetter(that, IGH.MWS.QS.CLIP_UPPER_VALUE, _clipUpperValue);
            _createGetterAndSetter(that, IGH.MWS.QS.SHRINK_BOUNDS_TO_GRAPH_DATA, _shrinkBoundsToGraphData, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.LABEL, _label);
            return that;
        };

        var _createOptions = function(){
            var _heightInPixels;
            var _widthInPixels;
            var _leftYAxis = _createYAxis();
            var _rightYAxis = _createYAxis();
            var _graphTitle;
            var _showLegend = IGH.MWS.QS_DEFAULTS.SHOW_LEGEND;
            var _legendPlacement = IGH.MWS.QS_DEFAULTS.LEGEND_PLACEMENT;
            var _showXAxisLabel = IGH.MWS.QS_DEFAULTS.SHOW_X_AXIS_LABEL;
            var _decoratePoints = IGH.MWS.QS_DEFAULTS.DECORATE_POINTS;
            var _graphType = IGH.MWS.QS_DEFAULTS.GRAPH_TYPE;
            var _timezone = IGH.MWS.QS_DEFAULTS.TIMEZONE;
            var _showLegendErrors = IGH.MWS.QS_DEFAULTS.SHOW_LEGEND_ERRORS;
            var _showGaps = IGH.MWS.QS_DEFAULTS.SHOW_GAPS;
            var _verticalLine = _createArray();

            var that = {};
            _createGetterAndSetter(that, IGH.MWS.QS.HEIGHT_IN_PIXELS, _heightInPixels);
            _createGetterAndSetter(that, IGH.MWS.QS.WIDTH_IN_PIXELS, _widthInPixels);
            _createGetterAndSetter(that, IGH.MWS.QS.GRAPH_TITLE, _graphTitle);
            _createGetterAndSetter(that, IGH.MWS.QS.SHOW_LEGEND, _showLegend, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.LEGEND_PLACEMENT, _legendPlacement, IGH.util.createOptionalEnumValidator(IGH.MWS.LegendPlacement));
            _createGetterAndSetter(that, IGH.MWS.QS.SHOW_X_AXIS_LABEL, _showXAxisLabel, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.DECORATE_POINTS, _decoratePoints, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.GRAPH_TYPE, _graphType, IGH.util.createOptionalEnumValidator(IGH.MWS.GraphType));
            _createGetterAndSetter(that, IGH.MWS.QS.TIMEZONE, _timezone);
            _createGetterAndSetter(that, IGH.MWS.QS.SHOW_LEGEND_ERRORS, _showLegendErrors, IGH.util.createOptionalBooleanValidator());
            _createGetterAndSetter(that, IGH.MWS.QS.SHOW_GAPS, _showGaps, IGH.util.createOptionalBooleanValidator());
            _createGetter(that, IGH.MWS.YAxisPreference.LEFT + IGH.graph.PARAMS.Y_AXIS, _leftYAxis);
            _createGetter(that, IGH.MWS.YAxisPreference.RIGHT + IGH.graph.PARAMS.Y_AXIS, _rightYAxis);
            _createGetter(that, IGH.MWS.QS.VERTICAL_LINE, _verticalLine);
            return that;
        };

        var _createTimeRanges = function(){
            return _createArray();
        };


        var _timeRanges = _createTimeRanges();
        var _sources = _createSources();
        var _options = _createOptions();
        var _functions = _createFunctions();


        var that = {};
        _createGetter(that, "timeRanges", _timeRanges);
        _createGetter(that, "sources", _sources);
        _createGetter(that, "options", _options);
        _createGetter(that, "functions", _functions);

        that.reset = function(){
            _timeRanges = _createTimeRanges();
            _sources = _createSources();
            _functions = _createFunctions();
            _options = _createOptions();
            that.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);
        };

        that.createTimeRange = function(type, startTime, endTime){
            var _type = type;
            var _startTime = startTime;
            var _endTime = endTime;

            var that = {};
            _createGetterAndSetter(that, IGH.graph.PARAMS.TYPE, _type, IGH.util.createOptionalEnumValidator(IGH.MWS.TimeRangeType));
            _createGetterAndSetter(that, IGH.MWS.QS.START_TIME, _startTime);
            _createGetterAndSetter(that, IGH.MWS.QS.END_TIME, _endTime);
            return that;
        };

        that.createFunction = function(){
            var _function = {};
            var _expression;
            var _label;
            var _yAxisPreference = IGH.MWS.QS_DEFAULTS.Y_AXIS_PREFERENCE;
            var _operateOnPartialInput = IGH.MWS.QS_DEFAULTS.FUNCTION_OPERATE_ON_PARTIAL_INPUT;
            var that = {};
            _createGetterAndSetter(that, IGH.MWS.QS.FUNCTION_EXPRESSION, _expression);
            _createGetterAndSetter(that, IGH.MWS.QS.FUNCTION_LABEL, _label);
            _createGetterAndSetter(that, IGH.MWS.QS.FUNCTION_Y_AXIS_PREFERENCE, _yAxisPreference, IGH.util.createOptionalEnumValidator(IGH.MWS.YAxisPreference));
            _createGetterAndSetter(that, IGH.MWS.QS.FUNCTION_OPERATE_ON_PARTIAL_INPUT, _operateOnPartialInput, IGH.util.createOptionalBooleanValidator());
            return that;
        };

        that.createGraphSchemaDataSource = function(){
            var _metric = {}; //required
            var _period; //required
            var _stat; // required
            var _valueUnit = IGH.MWS.QS_DEFAULTS.VALUE_UNIT;
            var _statOptions = IGH.MWS.QS_DEFAULTS.STAT_OPTIONS;
            var _yAxisPreference = IGH.MWS.QS_DEFAULTS.Y_AXIS_PREFERENCE;
            var _label;
            var _userLabel; // this is not an MWS parameter to hold a user define label
            var that = {};
            _createGetterAndSetter(that, IGH.graph.PARAMS.METRIC, _metric);
            _createGetterAndSetter(that, IGH.MWS.QS.PERIOD, _period, IGH.util.createOptionalEnumValidator(IGH.Period));
            _createGetterAndSetter(that, IGH.MWS.QS.STAT, _stat, IGH.util.createOptionalEnumValidator(IGH.Stat));
            _createGetterAndSetter(that, IGH.MWS.QS.VALUE_UNIT, _valueUnit, IGH.util.createOptionalEnumValidator(IGH.MWS.ValueUnit));
            _createGetterAndSetter(that, IGH.MWS.QS.STAT_OPTIONS, _statOptions, IGH.util.createOptionalEnumValidator(IGH.MWS.StatOptions));
            _createGetterAndSetter(that, IGH.MWS.QS.Y_AXIS_PREFERENCE, _yAxisPreference, IGH.util.createOptionalEnumValidator(IGH.MWS.YAxisPreference));
            _createGetterAndSetter(that, IGH.MWS.QS.LABEL, _label);
            _createGetterAndSetter(that, IGH.graph.PARAMS.USER_LABEL, _userLabel);
            that.type = function(){
                return IGH.graph.PARAMS.METRIC;
            };
            return that;
        };

        IGH.util.observability(that);
        return that;
    };


    IGH.graph.DataModelHelper = {

        cloneDataSource: function(model, source){
            var clone;
            if (source.type() === IGH.graph.PARAMS.METRIC) {
                clone = model.createGraphSchemaDataSource();
            }
            else {
                clone = model.createBinaryFunctionDataSource();
            }

            for (var func in source) {
                // need a deep copy of the metric object
                if (func === IGH.graph.PARAMS.METRIC) {
                    clone[func](this._clone(source[func]()));
                }
                else {
                    clone[func](source[func]());
                }
            }
            return clone;
        },

        copyMetricsToFunctions: function(model) {
            var metrics = model.sources();
            for (var i = 1; i <= metrics.size(); ++i) {
                var metric = metrics.get(i - 1);
                metric.statOptions(IGH.MWS.StatOptions.VAL);     // Make sure predictions switched off, not valid with functions
                var func = model.createFunction();
                if (this.isSearchMetric(metric)) {
                    func.functionExpression("S" + i);
                    func.functionLabel("{metricLabel}");
                }
                else {
                    func.functionExpression("M" + i);
                    func.functionLabel(metric.label());
                }
                func.functionYAxisPreference(metric.yAxisPreference());
                model.functions().add(func);
            }
        },

        isSearchMetric: function(metric) {
            return metric.metric()['SchemaName'] === 'Search';
        },

        modelFromUrl: function(url) {
            var model = IGH.graph.createDataModel();
            var codec = IGH.graph.createMWSCodec();
            var queryParams = codec.fromQueryString(IGH.util.parseUrl(url)['query']);
            codec.decode(queryParams, model);
            codec.decodeFunctions(queryParams, model);
            return model;
        },

        mergeModels: function(toModel, fromModel) {
            var fromMetrics = fromModel.sources();
            if (fromMetrics.size() == 0) {      // Nothing to merge
                return null;
            }
            var toMetrics = toModel.sources();
            var fromFunctions = fromModel.functions();
            var toFunctions = toModel.functions();
            var newMetricsOffset = toMetrics.size();
            this._copyMetricsToFunctionsIfEitherModelContainsFunctions(toModel, fromModel);
            this._setFromAxisToRightIfAllAreLeft(toMetrics, toFunctions, fromMetrics, fromFunctions);

            this._mergeGraphTitles(toModel, fromModel);
            this._mergeMetrics(toMetrics, fromMetrics);

            if (((toFunctions.size() > 0) || (newMetricsOffset == 0)) && (fromMetrics.size() > 0)) {
                for (var i = 0; i < fromFunctions.size(); i++) {
                    var newFunction = fromFunctions.get(i);
                    newFunction.functionExpression(this._renumberFunctionExpression(newFunction.functionExpression(), newMetricsOffset));
                    toFunctions.add(fromFunctions.get(i));
                }
            }

            return newMetricsOffset;
        },

        _setFromAxisToRightIfAllAreLeft: function(toMetrics, toFunctions, fromMetrics, fromFunctions) {
            if (toMetrics.size() == 0) {
                return;
            }
            if (fromFunctions.size() > 0) {
                this._setFromAxisToRightIfAllAreLeftForFunctionsOrMetrics(toFunctions, fromFunctions, 'functionYAxisPreference');
            }
            this._setFromAxisToRightIfAllAreLeftForFunctionsOrMetrics(toMetrics, fromMetrics, 'yAxisPreference');
        },

        _setFromAxisToRightIfAllAreLeftForFunctionsOrMetrics: function(toArray, fromArray, yAxisFunc) {
            var toRight   = this._hasRightYAxisPreference(toArray,   yAxisFunc);
            var fromRight = this._hasRightYAxisPreference(fromArray, yAxisFunc);
            if (!toRight && !fromRight) {
                this._setYAxisPreference(fromArray, yAxisFunc, IGH.MWS.YAxisPreference.RIGHT);
            }
        },

        _hasRightYAxisPreference: function(array, yAxisFunc) {
            for (var i = 0; i < array.size(); i++) {
                if (array.get(i)[yAxisFunc]() === IGH.MWS.YAxisPreference.RIGHT) {
                    return true;
                }
            }
            return false;
        },

        _setYAxisPreference: function(array, yAxisFunc, axisPreference) {
            for (var i = 0; i < array.size(); i++) {
                array.get(i)[yAxisFunc](axisPreference);
            }
        },

        _renumberFunctionExpression: function(expr, offset) {
            return expr.replace(/\b([MS])(\d+)\b/g, function(fullMatch, metricType, index){
                return metricType + (parseInt(index) + offset);
            });
        },

        _mergeGraphTitles: function(toModel, fromModel) {
            var toTitle = toModel.options().graphTitle();
            var fromTitle = fromModel.options().graphTitle();
            if (fromTitle && fromTitle != "") {
                var newTitle = fromTitle;
                if (toTitle && toTitle != "") {
                    newTitle = toTitle + " / " + fromTitle;
                }
                toModel.options().graphTitle(newTitle);
            }
        },

        _mergeMetrics: function(toMetrics, fromMetrics) {
            for (var i = 0; i < fromMetrics.size(); i++) {
                toMetrics.add(fromMetrics.get(i));
            }
        },

        _copyMetricsToFunctionsIfEitherModelContainsFunctions: function(toModel, fromModel) {
            var toFunctions = toModel.functions();
            var fromFunctions = fromModel.functions();
            if ((toFunctions.size() > 0) || (fromFunctions.size() > 0)) {
                if (toFunctions.size() == 0) {
                    this.copyMetricsToFunctions(toModel);
                }
                if (fromFunctions.size() == 0) {
                    this.copyMetricsToFunctions(fromModel);
                }
            }
        },

        _clone: function(map){
            var newMap = {};
            for (var prop in map) {
                if (map.hasOwnProperty(prop)) {
                    newMap[prop] = map[prop];
                }
            }
            return newMap;
        }
    };
    /*
     * Implement conversions between model for IGraph graph tab and MWS requests
     */
    // TODO how will we deal with default values, mws treats undefined properties as default values ( it may not always default a boolean to false)

    IGH.graph.createMWSCodec = function(){
        var METRIC_PATTERN = new RegExp("^[M 0-9]*$");
        var AMPERSAND = "&";
        var EQUALS = "=";
        var EQUALS_ENCODED = "%3D";
        var EMPTY = "";
        var NO_SUFFIX = "";

        var _encodeSources = function(parameters, sources){
            parameters = _encodeMetrics(parameters, sources);
            return parameters;
        };

        var _encodeMetrics = function(parameters, sources){
            var numMetrics = 0;
            // metrics
            for (var i = 0; i < sources.size(); ++i) {
                var source = sources.get(i);
                if (source.type() === IGH.graph.PARAMS.METRIC) {
                    numMetrics++;
                    for (var func in source) {
                        if (func === IGH.graph.PARAMS.METRIC) {
                            parameters = _encodeMetric(parameters, source[func](), numMetrics);
                        }
                        else
                        if (func === IGH.graph.PARAMS.TYPE) {
                            // ignore Type distinguished Functions and GraphSchema
                        }
                        else
                        if (IGH.startsWith(func, IGH.graph.PARAMS.FUNCTION) || func === IGH.graph.PARAMS.ENABLED) {
                            // handle in _encodeFunctions
                        }
                        else
                        if (func === _getFunctionName(IGH.graph.PARAMS.USER_LABEL) || func === _getFunctionName(IGH.MWS.QS.LABEL)) {
                            // fallback does not make sense for user labels
                            parameters = _addParameter(parameters, source, func, numMetrics);
                        }
                        else {
                            parameters = _addParameterWithFallback(parameters, source, func, numMetrics);
                        }
                    }
                }
            }
            return parameters;
        };

        var _encodeMetric = function(parameters, metric, index){
            var schema = metric[IGH.MWS.QS.SCHEMA_NAME];
            parameters = _addParameterFromProperty(parameters, metric, IGH.MWS.QS.SCHEMA_NAME, index);
            var fields = IGH.MetricSchemas.schemaDefs[schema];
            if (fields) {
                for (var i = 0; i < fields.length; ++i) {
                    parameters = _addParameterFromPropertyWithFallback(parameters, metric, fields[i], index);
                }
            }
            return parameters;
        };

        var _encodeFunctions = function(parameters, functions){
            var numFunctions = 0;
            for (var i = 0; i < functions.size(); ++i) {
                var functionDef = functions.get(i);
                numFunctions++;
                for (var func in functionDef) {
                    parameters = _addParameter(parameters, functionDef, func, numFunctions);
                }
            }
            return parameters;
        };

        var _encodeTimeRanges = function(parameters, timeRanges){
            for (var i = 0; i < timeRanges.size(); ++i) {
                parameters = _addParameter(parameters, timeRanges.get(i), IGH.MWS.QS.START_TIME, i + 1);
                parameters = _addParameter(parameters, timeRanges.get(i), IGH.MWS.QS.END_TIME, i + 1);
            }
            return parameters;
        };

        var _encodeOptions = function(parameters, options){
            for (var func in options) {
                if (func === IGH.MWS.YAxisPreference.LEFT + IGH.graph.PARAMS.Y_AXIS) {
                    parameters = _encodeYAxis(parameters, options[func](), _getName(IGH.MWS.YAxisPreference.LEFT));
                } else if (func === IGH.MWS.YAxisPreference.RIGHT + IGH.graph.PARAMS.Y_AXIS) {
                    parameters = _encodeYAxis(parameters, options[func](), _getName(IGH.MWS.YAxisPreference.RIGHT));
                } else if (func === _getFunctionName(IGH.MWS.QS.VERTICAL_LINE)) {
                    parameters = _encodeLineOption(parameters, options, func, NO_SUFFIX);
                } else {
                    parameters = _addParameter(parameters, options, func, NO_SUFFIX);
                }
            }
            return parameters;
        };

        var _decodeMetric = function(parameters, source, numMetrics){
            for (var func in source) {
                if (func === IGH.graph.PARAMS.METRIC) {
                    _decodeMetricSchema(parameters, source[func](), numMetrics);
                }
                else
                if (func === IGH.graph.PARAMS.TYPE) {
                    // handled in _decodeSources
                }
                else
                if (IGH.startsWith(func, IGH.graph.PARAMS.FUNCTION) || func === IGH.graph.PARAMS.ENABLED) {
                    // handled in _decodeFunctions
                }
                else
                if (func === _getFunctionName(IGH.graph.PARAMS.USER_LABEL) || func === _getFunctionName(IGH.MWS.QS.LABEL)) {
                    // fallback is not appropriate for userLabels
                    _getParameter(parameters, source, func, numMetrics);
                }
                else {
                    _getParameterWithFallback(parameters, source, func, numMetrics);
                }
            }
        };

        var _decodeMetricSchema = function(parameters, metric, index){
            _getParameterFromProperty(parameters, metric, IGH.MWS.QS.SCHEMA_NAME, index);
            var schema = metric[IGH.MWS.QS.SCHEMA_NAME];
            var fields = IGH.MetricSchemas.schemaDefs[schema];
            if (fields) {
                for (var i = 0; i < fields.length; ++i) {
                    _getParameterFromPropertyWithFallback(parameters, metric, fields[i], index);
                }
            }
        };

        var _decodeMetrics = function(model, parameters, sources){
            sources.clear();
            var metrics = _getArray(parameters, IGH.MWS.QS.SCHEMA_NAME);
            var numMetrics = 0;
            var source;
            for (var i = 0; i < metrics.length; ++i) {
                numMetrics++;
                source = model.createGraphSchemaDataSource();
                source.type(IGH.graph.PARAMS.METRIC);
                _decodeMetric(parameters, source, i+1);
                sources.add(source);
            }
        };

        var _decodeFunctions = function(model, parameters, functions){
            functions.clear();
            var expressions = _getArray(parameters, IGH.MWS.QS.FUNCTION_EXPRESSION);
            var numFunctions = 0;
            var functionDef;
            for (var i = 0; i < expressions.length; ++i) {
                numFunctions++;
                functionDef = model.createFunction();
                _decodeFunction(parameters, functionDef, i+1);
                functions.add(functionDef);
            }
        };

        var _decodeFunction = function(parameters, functionDef, numFunctions){
            for (var func in functionDef) {
                _getParameter(parameters, functionDef, func, numFunctions);
            }
        };

        var _decodeTimeRanges = function(model, parameters, timeRanges){
            timeRanges.clear();
            var start = _getArray(parameters, IGH.MWS.QS.START_TIME);
            var end = _getArray(parameters, IGH.MWS.QS.END_TIME);
            // Switch to only understanding StartTime1, EndTime1 until full support for Period over Period
            for (var i = 0; i < Math.min(1, Math.min(start.length, end.length)); ++i) {
                var type = IGH.TimeRangeUtils.getTimeType(start[i]);
                timeRanges.add(model.createTimeRange(type, start[i], end[i]));
            }
        };

        var _decodeOptions = function(parameters, options){
            for (var func in options) {
                if (func === IGH.MWS.YAxisPreference.LEFT + IGH.graph.PARAMS.Y_AXIS) {
                    _decodeYAxis(parameters, options[func](), _getName(IGH.MWS.YAxisPreference.LEFT));
                } else if (func === IGH.MWS.YAxisPreference.RIGHT + IGH.graph.PARAMS.Y_AXIS) {
                    _decodeYAxis(parameters, options[func](), _getName(IGH.MWS.YAxisPreference.RIGHT));
                } else if (func === _getFunctionName(IGH.MWS.QS.VERTICAL_LINE)) {
                    _decodeLineOption(parameters, options, func, NO_SUFFIX);
                } else {
                    _getParameter(parameters, options, func, NO_SUFFIX);
                }
            }
        };

        var _decodeYAxis = function(parameters, object, axisName){
            for (var func in object) {
                if (func === _getFunctionName(IGH.MWS.QS.HORIZONTAL_LINE)) {
                    _decodeLineOption(parameters, object, func, axisName);
                }
                else {
                    _getParameter(parameters, object, func, axisName);
                }
            }
        };

        var _decodeLineOption = function(parameters, object, func, axisName) {
            object[func]().clear();
            var lines = _getArray(parameters, _getName(func) + axisName);
            for (var i = 0; i < lines.length; ++i) {
                object[func]().add(lines[i]);
            }
        };

        var _getArray = function(parameters, name){
            var result = [];
            var i = 1;
            do {
                value = parameters[name + i];
                if (value) {
                    result.push(value);
                }
                i++;
            }
            while (value);
            return result;
        };

        var _getParameter = function(parameters, object, func, suffix){
            object[_getFunctionName(func)](_getParameterInternal(parameters, _getName(func), suffix));
        };

        var _getParameterWithFallback = function(parameters, object, func, suffix){
            object[_getFunctionName(func)](_getParameterInternalWithFallback(parameters, _getName(func), suffix));
        };

        var _getParameterFromProperty = function(parameters, object, func, suffix){
            object[_getName(func)] = _getParameterInternal(parameters, _getName(func), suffix);
        };

        var _getParameterFromPropertyWithFallback = function(parameters, object, func, suffix){
            object[_getName(func)] = _getParameterInternalWithFallback(parameters, _getName(func), suffix);
        };

        var _getParameterInternalWithFallback = function(parameters, name, index){
            for (var i = index; i > 0; --i) {
                var value = parameters[name + i];
                if (value) {
                    return value;
                }
            }
        };

        var _getParameterInternal = function(parameters, name, suffix){
            return parameters[name + suffix];
        };

        var _encodeYAxis = function(parameters, object, axisName){
            for (var func in object) {
                if (func === _getFunctionName(IGH.MWS.QS.HORIZONTAL_LINE)) {
                    parameters = _encodeLineOption(parameters, object, func, axisName);
                }
                else {
                    parameters = _addParameter(parameters, object, func, axisName);
                }
            }
            return parameters;
        };

        var _encodeLineOption = function(parameters, object, func, suffix) {
            var lines = object[func]();
            for (var i = 0; i < lines.size(); ++i) {
                parameters[_getName(func) + suffix + (i + 1)] = lines.get(i);
            }
            return parameters;
        };

        var _addParameter = function(parameters, object, func, suffix){
            return _addParameterInternal(parameters, _getName(func), object[_getFunctionName(func)](), suffix);
        };

        var _addParameterWithFallback = function(parameters, object, func, suffix){
            return _addParameterWithFallbackInternal(parameters, _getName(func), object[_getFunctionName(func)](), suffix);
        };

        var _addParameterFromProperty = function(parameters, object, property, suffix){
            return _addParameterInternal(parameters, _getName(property), object[property], suffix);
        };

        var _addParameterFromPropertyWithFallback = function(parameters, object, property, suffix){
            return _addParameterWithFallbackInternal(parameters, _getName(property), object[property], suffix);
        };

        var _addParameterWithFallbackInternal = function(parameters, name, value, index){
            if (value && value !== _getPreviousValue(parameters, name, index)) {
                parameters[name + index] = value;
            }
            return parameters;
        };

        var _addParameterInternal = function(parameters, name, value, suffix){
            if (value && !(value.toString().toLowerCase() === _getDefaultValue(name, value, suffix))) {
                parameters[name + suffix] = value;
            }
            return parameters;
        };

        var _getDefaultValue = function(name, value, suffix){
            for (var prop in IGH.MWS.QS_DEFAULTS) {
                if (IGH.MWS.QS_DEFAULTS.hasOwnProperty(prop)) {
                    var defaulted = IGH.MWS.QS[prop];
                    if (defaulted === name) {
                        return IGH.MWS.QS_DEFAULTS[prop];
                    }
                }
            }
        };

        var _getPreviousValue = function(parameters, name, index){
            for (var i = index - 1; i > 0; --i) {
                if (parameters[name + i]) {
                    return parameters[name + i];
                }
            }
            return _getDefaultValue(name, name, index);
        };

        // uppercase the first letter ( for QS parameter names)
        var _getName = function(parameter){
            return parameter.charAt(0).toUpperCase() + parameter.substring(1);
        };

        // lowercase the first letter ( for method names)
        var _getFunctionName = function(parameter){
            return parameter.charAt(0).toLowerCase() + parameter.substring(1);
        };

        // public methods
        var that = {};

        // translates a data model into an object filed with key/value pairs
        that.encode = function(dataModel){
            var parameters = {};
            parameters = _encodeSources(parameters, dataModel.sources());
            parameters = _encodeOptions(parameters, dataModel.options());
            parameters = _encodeTimeRanges(parameters, dataModel.timeRanges());
            return parameters;
        };

        that.encodeFunctions = function(dataModel){
            var parameters = {};
            parameters = _encodeFunctions(parameters, dataModel.functions());
            return parameters;
        };

        // translates an object filled with key/value pairs into a url segment
        that.toQueryString = function(parameters){
            var out = EMPTY;
            for (var parameter in parameters) {
                if (parameters.hasOwnProperty(parameter)) {
                    out += IGH.util.GetQueryArg(parameter, parameters[parameter]);
                }
            }
            return out.length > 0 ? out.substring(1) : out;
        };

        // translates a url segment into an object filled with key/value pairs
        that.fromQueryString = function(urlSegment){
            var parameters = {};
            var params = urlSegment.split(AMPERSAND);
            for (var i = 0; i < params.length; ++i) {
                var keyValue = IGH.util.queryParamToKeyValue(params[i]);
                if (keyValue) {
                    parameters[keyValue.key] = keyValue.value;
                }
            }
            return parameters;
        };

        // translates an object filed with key/value pairs into a data model

        that.decode = function(parameters, dataModel){
            _decodeOptions(parameters, dataModel.options());
            _decodeTimeRanges(dataModel, parameters, dataModel.timeRanges());
            _decodeMetrics(dataModel, parameters, dataModel.sources());
            return dataModel;
        };

        that.decodeFunctions = function(parameters, dataModel){
            _decodeFunctions(dataModel, parameters, dataModel.functions());
            return dataModel;
        };

        return that;

    };
    IGH.TimeRangeUtils = {

        TZ_PDT: "PST8PDT",
        XML_DATE: new RegExp('(\\d{4})-(\\d{2})-(\\d{2})'),
        XML_TIME: new RegExp('T(\\d{2}):(\\d{2}):(\\d{2})'),
        XML_TZ: new RegExp('([-+]\\d{2}):00$'),
        DECIMAL: 10,
        MILLISECONDS_IN_MINUTE: 60 * 1000,

        PATTERN: {
            DAY: new RegExp('(\\d*)D'),
            HOUR: new RegExp('(\\d*)H'),
            MINUTE: new RegExp('(\\d*)M')
        },

        DURATIONS: {
            DAY: "D",
            HOUR: "H",
            MINUTE: "M"
        },

        MINUTES: {
            DAY: 24 * 60,
            HOUR: 60,
            MINUTE: 1
        },

        UNITS: {
            MINUTE: "MINUTE",
            HOUR: "HOUR",
            DAY: "DAY"
        },

        ORDERED_UNITS: ["MINUTE", "HOUR", "DAY"],

        // get units and corresponding value form a control
        getControlFromDuration: function(duration){
            var minutes = this.getMinutes(duration);
            var unit = this.getUnits(duration);
            var value = minutes / this.MINUTES[unit];
            var result = {};
            result[unit] = value;
            return result;
        },

        // get number of minutes corresponding to a duration
        getMinutes: function(duration){
            // sign is inverted sign widget is ago
            var sign = duration.match("-P") ? 1 : -1;
            var minutes = 0;
            for (var i = 0; i < this.ORDERED_UNITS.length; i++) {
                var index = this.ORDERED_UNITS[i];
                var results = this.PATTERN[index].exec(duration);
                if (results && results[1] !== "") {
                    minutes += this.MINUTES[index] * parseInt(results[1], this.DECIMAL);
                }
            }
            return sign * minutes;
        },

        // natural time from a duration
        getNaturalFromDuration: function(duration){
            var minutes = this.getMinutes(duration);
            var unit = this.getUnits(duration);
            var value = Math.round(minutes / this.MINUTES[unit]);
            if (value === 0) {
                return "now";
            }
            return value + " " + unit.toLowerCase() + (value === 1 ? "" : "s") + " ago";
        },

        // natural time from a XML calendar
        getNaturalFromXMLCalendar: function(calendar){
            var date = IGH.TimeRangeUtils.getControlFromXMLCalendar(calendar);
            var hours = date.getHours();
            var amPm = "am";
            if (hours >= 12) {
                hours -= 12;
                amPm = "pm";
            }
            if (hours === 0) {
                hours = 12;
            }
            var minutes = Math.floor(date.getMinutes() / 5) * 5;
            minutes = (minutes < 10) ? "0" + minutes : minutes;
            return $.datepicker.formatDate(IGH.TimeRanges.FORMAT, date) + " " + hours + ":" + minutes + amPm;
        },

        // get most significant Unit present in a duration
        getUnits: function(duration){
            var unit = this.UNITS.MINUTE;
            for (var i = 0; i < this.ORDERED_UNITS.length; i++) {
                var index = this.ORDERED_UNITS[i];
                var results = this.PATTERN[index].exec(duration);
                if (results && results[1] !== "") {
                    unit = index;
                }
            }
            return unit;
        },

        // create a duration form the screen widget
        getDurationFromControl: function(unit, value){
            // sign is inverted sign widget is ago
            var sign = value < 0 ? "" : "-";
            var minutes = Math.floor(this.MINUTES[unit] * Math.abs(value));
            var duration = sign + "P";
            if (minutes >= this.MINUTES.DAY || unit === this.UNITS.DAY) {
                var days = Math.floor(minutes / this.MINUTES.DAY);
                duration += days + this.DURATIONS.DAY;
                minutes = minutes % this.MINUTES.DAY;
            }
            duration += "T";
            if (minutes >= this.MINUTES.HOUR || unit === this.UNITS.HOUR) {
                var hours = Math.floor(minutes / this.MINUTES.HOUR);
                duration += hours + this.DURATIONS.HOUR;
                minutes = minutes % this.MINUTES.HOUR;
            }
            if (minutes >= this.MINUTES.MINUTE || unit === this.UNITS.MINUTE) {
                var mins = Math.floor(minutes / this.MINUTES.MINUTE);
                duration += mins + this.DURATIONS.MINUTE;
            }
            if( duration.charAt(duration.length-1) === "T") {
                duration= duration.slice(0,-1);
            }
            return duration;
        },

        // get a calendar string in UTC from the int values of a javascript date
        getXMLCalendarFromControl: function(year, month, dayOfMonth, hours, minutes){
            var date = new fleegix.date.Date(year, month, dayOfMonth, hours, minutes, this.TZ_PDT, false);
            return this.getXMLCalendarFromDate(date);
        },

        // get a calendar string in UTC from a date
        getXMLCalendarFromDate: function(date){
            return date.getUTCFullYear() + "-" + this.pad(date.getUTCMonth() + 1) + "-" + this.pad(date.getUTCDate()) + "T" + this.pad(date.getUTCHours()) + ":" + this.pad(date.getUTCMinutes()) + ":00Z";
        },

        // get a date in PDT from an xml calendar in UTC
        getControlFromXMLCalendar: function(xmlCalendar){
            var hour = 0;
            var minute = 0;
            var second = 0;
            var tz = 0;
            var results = this.XML_TZ.exec(xmlCalendar);
            if (results) {
                tz = parseInt(results[1], this.DECIMAL);
            }
            results = this.XML_TIME.exec(xmlCalendar);
            if (results) {
                hour = parseInt(results[1], this.DECIMAL);
                minute = parseInt(results[2], this.DECIMAL);
                second = parseInt(results[3], this.DECIMAL);
            }
            results = this.XML_DATE.exec(xmlCalendar);
            if (results) {
                var year = parseInt(results[1], this.DECIMAL);
                var month = parseInt(results[2], this.DECIMAL) - 1;
                var dayInMonth = parseInt(results[3], this.DECIMAL);
                var utc = Date.UTC(year, month, dayInMonth, hour, minute, second);
                if (window.fleegix) {
                    var offset = this.getPDTUTCOffset(utc) - tz;
                    return new fleegix.date.Date(year, month, dayInMonth, hour + offset, minute, second, this.TZ_PDT, false);
                } else {
                    return new Date(utc);
                }
            }
            return null;
        },

        // get an xml calendar in UTC from a date and an xml duration
        getXMLCalendarFromDuration: function(now, duration){
            var minutes = this.getMinutes(duration);
            now.setMinutes(now.getMinutes() - minutes);
            return this.getXMLCalendarFromDate(now);
        },

        // get an xml calendar in UTC from a date and an xml duration
        getDurationFromXMLCalendar: function(now, calendar){
            var then = this.getControlFromXMLCalendar(calendar);
            var minutes = (now.getTime() - then.getTime()) / this.MILLISECONDS_IN_MINUTE;
            return this.getDurationFromControl(this.UNITS.MINUTE, minutes);
        },

        // get current js date in PDT
        getNowInPDT: function(){
            var date = new Date();
            var offset = this.getPDTUTCOffset(date.getTime());
            return new fleegix.date.Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours() + offset, date.getUTCMinutes(), date.getUTCSeconds(), date.getUTCMilliseconds(), this.TZ_PDT, false);
        },

        // Convert a time range into minute durations
        getTimeRangeInMinutes: function(now, timeRange) {
            // Can't calculate range with natural time
            if (this.getTimeType(timeRange.startTime()) === IGH.MWS.TimeRangeType.NATURAL) {
                return null;
            }
            var minuteRange = new Object();
            minuteRange.startTime = this._getTimeInMinutes(now, timeRange.startTime());
            minuteRange.endTime   = this._getTimeInMinutes(now, timeRange.endTime());
            return minuteRange;
        },

        // Convert a time (duration or fixed) into number of minutes, compared to now
        _getTimeInMinutes: function(now, time) {
            var duration;
            if (! this.isDuration(time)) {
                duration = this.getDurationFromXMLCalendar(now, time);
            }
            else {
                duration = time;
            }
            return this.getMinutes(duration);
        },

        // Return true if time is a duration
        isDuration: function(time) {
            return IGH.TimeRanges.DURATION.test(time);
        },

        getTimeType: function(time) {
            if (this.isDuration(time)) {
                return IGH.MWS.TimeRangeType.RELATIVE;
            }
            if (this.getControlFromXMLCalendar(time) !== null) {
                return IGH.MWS.TimeRangeType.FIXED;
            }
            return IGH.MWS.TimeRangeType.NATURAL;
        },

        pad: function(number){
            if (number < 10) {
                return "0" + number;
            }
            return number;
        },

        // get PDT offset in hours for a input date
        getPDTUTCOffset: function(dateIn){
            var date = new fleegix.date.Date(dateIn);
            date.setTimezone(this.TZ_PDT);
            return -(date.getTimezoneOffset()) / this.MINUTES.HOUR;
        }
    };
    /*
     * Implements the controls in the Time Ranges section
     *  note only supports a single time range currently
     */
    IGH.TimeRanges = {

        FORMAT: 'yy/mm/dd',
        DURATION: new RegExp('^-?P'),
        DEFAULT_REL_START: '-PT3H',
        DEFAULT_REL_END:   '-PT0H',

        // Initialize.
        init: function(){
            // dates that know about PDT
            var _tz = fleegix.date.timezone;
            _tz.loadingScheme = _tz.loadingSchemes.MANUAL_LOAD;
            var data = {
                "zones": {
                    "PST8PDT": [["-8:00", "US", "P%sT"]]
                },
                "rules": {
                    "US": [["1918", "1919", "-", "Mar", "lastSun", "2:00", "1:00", "D"], ["1918", "1919", "-", "Oct", "lastSun", "2:00", "0", "S"], ["1942", "only", "-", "Feb", "9", "2:00", "1:00", "W", ""], ["1945", "only", "-", "Aug", "14", "23:00u", "1:00", "P", ""], ["1945", "only", "-", "Sep", "30", "2:00", "0", "S"], ["1967", "2006", "-", "Oct", "lastSun", "2:00", "0", "S"], ["1967", "1973", "-", "Apr", "lastSun", "2:00", "1:00", "D"], ["1974", "only", "-", "Jan", "6", "2:00", "1:00", "D"], ["1975", "only", "-", "Feb", "23", "2:00", "1:00", "D"], ["1976", "1986", "-", "Apr", "lastSun", "2:00", "1:00", "D"], ["1987", "2006", "-", "Apr", "Sun>=1", "2:00", "1:00", "D"], ["2007", "max", "-", "Mar", "Sun>=8", "2:00", "1:00", "D"], ["2007", "max", "-", "Nov", "Sun>=1", "2:00", "0", "S"]]
                }
            };
            _tz.loadZoneDataFromObject(data);
            this.model = IGH.graph.model();
            var options = {
                dateFormat: IGH.TimeRanges.FORMAT,
                showOn: 'button',
                buttonImage: '/images/calendar.png',
                buttonImageOnly: true
            };
            // initialize
            IGH.TimeRanges.syncControlsFromModel();
            // listen for changes to the model
            this.model.register(IGH.graph.PARAMS.MODEL_CHANGED_EVENT, function(event){
                IGH.TimeRanges.syncControlsFromModel();
            });
            // add UI listeners
            var self = this;
            $(".setFixedTimeType").on('click', function()    { return self.setTimeType(IGH.MWS.TimeRangeType.FIXED); });
            $(".setRelativeTimeType").on('click', function() { return self.setTimeType(IGH.MWS.TimeRangeType.RELATIVE); });
            $(".setNaturalTimeType").on('click', function()  { return self.setTimeType(IGH.MWS.TimeRangeType.NATURAL); });
            $(".startNow").on('click', this.start3HoursAgo);
            $(".endNow").on('click', this.endNow);
            var times = ["start", "end"];
            for (var i in times) {
                if (times.hasOwnProperty(i)) {
                    $("#" + times[i] + "TimeValue").on('change', this.updateDurationFromControl(times[i]));
                    $("select[name=" + times[i] + "Value]").on('change', this.updateDurationFromControl(times[i]));
                    $("select[name=" + times[i] + "Hours]").on('change', this.updateDateFromControl(times[i]));
                    $("select[name=" + times[i] + "Minutes]").on('change', this.updateDateFromControl(times[i]));
                    $("#" + times[i] + "Date").datepicker(options).on('change', this.updateDateFromControl(times[i]));
                    $("#" + times[i] + "Natural").on('change', this.updateNaturalFromControl(times[i]));
                }
            }
            this._addQuickZoomOnClickHandling();
        },

        syncControlsFromModel: function(){
            var self = IGH.TimeRanges;
            if (self.model.timeRanges().size() === 1) {
                var timeRange = self.model.timeRanges().get(0);
                var timeType = IGH.TimeRangeUtils.getTimeType(timeRange.startTime());
                if (timeType === IGH.MWS.TimeRangeType.RELATIVE) {
                    self.updateControlFromDuration("start");
                    self.updateControlFromDuration("end");
                    self.showControls("relative");
                }
                else if (timeType === IGH.MWS.TimeRangeType.FIXED) {
                    self.updateControlFromCalendar("start");
                    self.updateControlFromCalendar("end");
                    self.showControls("fixed");
                }
                else {
                    self.updateControlFromNatural("start");
                    self.updateControlFromNatural("end");
                    self.showControls("natural");
                }
            }
        },

        showControls: function(controlType) {
            $(".timeSwitch").show();
            $("." + controlType + "TimeSwitch").hide();
            $(".timePanel").hide();
            $("#" + controlType + "-time").show();
        },

        start3HoursAgo: function(){
            for (var i = 0; i < IGH.TimeRanges.model.timeRanges().size(); ++i) {
                var timeRange = IGH.TimeRanges.model.timeRanges().get(i);
                if (timeRange.type() === IGH.MWS.TimeRangeType.FIXED) {
                    var now = IGH.TimeRangeUtils.getNowInPDT();
                    now.setHours(now.getHours() - 3);
                    timeRange.startTime(IGH.TimeRangeUtils.getXMLCalendarFromDate(now));
                }
                else if (timeRange.type() === IGH.MWS.TimeRangeType.NATURAL) {
                    timeRange.startTime("3 hours ago");
                }
            }
            return false;
        },

        endNow: function(){
            for (var i = 0; i < IGH.TimeRanges.model.timeRanges().size(); ++i) {
                var timeRange = IGH.TimeRanges.model.timeRanges().get(i);
                if (timeRange.type() === IGH.MWS.TimeRangeType.FIXED) {
                    timeRange.endTime(IGH.TimeRangeUtils.getXMLCalendarFromDate(IGH.TimeRangeUtils.getNowInPDT()));
                }
                else if (timeRange.type() === IGH.MWS.TimeRangeType.NATURAL) {
                    timeRange.endTime("now");
                }
            }
            return false;
        },

        setTimeType: function(newTimeType){
            var self = IGH.TimeRanges;

            // only want one event from this change
            self.model.enableNotification(false);
            for (var i = 0; i < self.model.timeRanges().size(); ++i) {
                var timeRange = self.model.timeRanges().get(i);
                var currentTimeType = timeRange.type();
                self._convertFromCurrentTimeToNewTime(timeRange, newTimeType, currentTimeType);
                timeRange.type(newTimeType);
            }
            self.model.enableNotification(true);
            self.model.notify(IGH.graph.PARAMS.MODEL_CHANGED_EVENT);
            return false;
        },

        _addQuickZoomOnClickHandling: function() {
            function setTime() {
                var startTime = "-" + IGH.TimeRanges._timeTextToDuration($(this).text());
                var model = IGH.graph.model();
                IGH.util.BatchUpdate(IGH.TimeRanges.setTimeRange, model.createTimeRange(IGH.MWS.TimeRangeType.RELATIVE, startTime, IGH.TimeRanges.DEFAULT_REL_END));
                IGH.GraphSection.displayGraph();
                return false;
            }

            $('.quickZoom a').attr('href', '#').on('click', setTime);
        },

        setTimeRange: function(range) {
            var model = IGH.graph.model();
            model.timeRanges().clear();
            model.timeRanges().add(range);
        },

        // Convert time text in format such as 1h, 2d, 3w to a duration
        _timeTextToDuration: function(timeText) {
            var timeValue = parseInt(timeText.substr(0, timeText.length - 1));
            var timeUnit = timeText.substr(timeText.length - 1).toUpperCase();
            if ("W" == timeUnit) {
                timeUnit = "D";
                timeValue *= 7;
            }

            return ("H" == timeUnit ? "PT" : "P") + timeValue + timeUnit;
        },

        _convertFromCurrentTimeToNewTime: function(timeRange, newTimeType, currentTimeType) {
            if (newTimeType === IGH.MWS.TimeRangeType.NATURAL) {
                if (currentTimeType === IGH.MWS.TimeRangeType.RELATIVE) {
                    timeRange.startTime(IGH.TimeRangeUtils.getNaturalFromDuration(timeRange.startTime()));
                    timeRange.endTime(IGH.TimeRangeUtils.getNaturalFromDuration(timeRange.endTime()));
                }
                else {
                    timeRange.startTime(IGH.TimeRangeUtils.getNaturalFromXMLCalendar(timeRange.startTime()));
                    timeRange.endTime(IGH.TimeRangeUtils.getNaturalFromXMLCalendar(timeRange.endTime()));
                }
            }
            else if (newTimeType === IGH.MWS.TimeRangeType.FIXED) {
                if (currentTimeType === IGH.MWS.TimeRangeType.RELATIVE) {
                    timeRange.startTime(IGH.TimeRangeUtils.getXMLCalendarFromDuration(IGH.TimeRangeUtils.getNowInPDT(), timeRange.startTime()));
                    timeRange.endTime(IGH.TimeRangeUtils.getXMLCalendarFromDuration(IGH.TimeRangeUtils.getNowInPDT(), timeRange.endTime()));
                }
                else {
                    timeRange.startTime(IGH.TimeRangeUtils.getXMLCalendarFromDuration(IGH.TimeRangeUtils.getNowInPDT(), IGH.TimeRanges.DEFAULT_REL_START));
                    timeRange.endTime(IGH.TimeRangeUtils.getXMLCalendarFromDuration(IGH.TimeRangeUtils.getNowInPDT(), IGH.TimeRanges.DEFAULT_REL_END));
                }
            }
            else if (newTimeType === IGH.MWS.TimeRangeType.RELATIVE) {
                if (currentTimeType === IGH.MWS.TimeRangeType.FIXED) {
                    timeRange.startTime(IGH.TimeRangeUtils.getDurationFromXMLCalendar(IGH.TimeRangeUtils.getNowInPDT(), timeRange.startTime()));
                    timeRange.endTime(IGH.TimeRangeUtils.getDurationFromXMLCalendar(IGH.TimeRangeUtils.getNowInPDT(), timeRange.endTime()));
                }
                else {
                    timeRange.startTime(IGH.TimeRanges.DEFAULT_REL_START);
                    timeRange.endTime(IGH.TimeRanges.DEFAULT_REL_END);
                }
            }
        },

        // only update the ui on real changes
        updateControlOnChange: function(control, value){
            if (control.val() !== value) {
                control.val(value);
            }
        },

        // duration has changes in model -> update the UI
        updateControlFromNatural: function(name){
            var naturalTime = IGH.TimeRanges.model.timeRanges().get(0)[name + "Time"]();
            IGH.TimeRanges.updateControlOnChange($("#" + name + "Natural"), naturalTime);
            return false;
        },

        // duration has changes in model -> update the UI
        updateControlFromDuration: function(name){
            var duration = IGH.TimeRanges.model.timeRanges().get(0)[name + "Time"]();
            var control = IGH.TimeRangeUtils.getControlFromDuration(duration);
            for (var prop in control) {
                if (control.hasOwnProperty(prop)) {
                    IGH.TimeRanges.updateControlOnChange($("#" + name + "TimeValue"), Math.round(control[prop] * 10) / 10);
                    IGH.TimeRanges.updateControlOnChange($("select[name=" + name + "Value]"), prop.toLowerCase() + "s");
                }
            }
            return false;
        },

        // calendar has changed in model -> update the UI
        updateControlFromCalendar: function(name){
            var calendar = IGH.TimeRanges.model.timeRanges().get(0)[name + "Time"]();
            var date = IGH.TimeRangeUtils.getControlFromXMLCalendar(calendar);
            // end dates must be after, start dates must be before
            // if end date is not aligned move to the following aligned value (see floor below)
            if (name === "end" && ( date.getSeconds() !== 0 || date.getMinutes() % 5 !== 0)) {
                date.setMinutes(date.getMinutes() + 5);
            }
            IGH.TimeRanges.updateControlOnChange($("#" + name + "Date"), $.datepicker.formatDate(IGH.TimeRanges.FORMAT, date));
            IGH.TimeRanges.updateControlOnChange($("select[name=" + name + "Hours]"), date.getHours());
            IGH.TimeRanges.updateControlOnChange($("select[name=" + name + "Minutes]"), Math.floor(date.getMinutes() / 5) * 5);
            return false;
        },

        // date control has changes update the model
        updateDateFromControl: function(name){
            return function(){
                var date = $("#" + name + "Date").val();
                var hours = parseInt($("select[name=" + name + "Hours]").val(), IGH.TimeRangeUtils.DECIMAL);
                var minutes = parseInt($("select[name=" + name + "Minutes]").val(minutes), IGH.TimeRangeUtils.DECIMAL);
                var parts = date.split('/');
                if (parts.length === 3) {
                    var year = parseInt(parts[0], IGH.TimeRangeUtils.DECIMAL);
                    var month = parseInt(parts[1], IGH.TimeRangeUtils.DECIMAL) - 1;
                    var dayInMonth = parseInt(parts[2], IGH.TimeRangeUtils.DECIMAL);
                    var timeRange = IGH.TimeRanges.model.timeRanges().get(0);
                    var newValue = IGH.TimeRangeUtils.getXMLCalendarFromControl(year, month, dayInMonth, hours, minutes);
                    timeRange[name + "Time"](newValue);
                }
                return false;
            };
        },

        // natural time control has changes, update the model
        updateNaturalFromControl: function(name){
            return function(){
                var timeRange = IGH.TimeRanges.model.timeRanges().get(0);
                timeRange[name + "Time"]($("#" + name + "Natural").val());
                return false;
            };
        },

        // duration control has changes update the model
        updateDurationFromControl: function(name){
            return function(){
                var value = $("#" + name + "TimeValue").val();
                var units = $("select[name=" + name + "Value]").val();
                units = units.slice(0, -1).toUpperCase();
                var timeRange = IGH.TimeRanges.model.timeRanges().get(0);
                var newValue = IGH.TimeRangeUtils.getDurationFromControl(units, value);
                timeRange[name + "Time"](newValue);
                return false;
            };
        }

    };

    jQuery.fn.iGHSingleDoubleClick = function(singleClickCallback, doubleClickCallback, timeout) {
        return this.each(function() {
            var clicks = 0, self = this;
            jQuery(this).on('click', function(event) {
                if (event.preventDefault) {
                    event.preventDefault();
                }
                if (event.stopPropagation) {
                    event.stopPropagation();
                }
                clicks++;
                if (clicks == 1) {
                    setTimeout(function() {
                        if (clicks == 1) {
                            singleClickCallback.call(self, event);
                        }
                        else {
                            doubleClickCallback.call(self, event);
                        }
                        clicks = 0;
                    }, timeout || 300);
                }
            });
        });
    }

    // Initialize and decorate strings
    initialize();
}

IGraphPage = {
    initialize: function() {
        if (!this.onIGraph()) {
            return;
        }
        this.MP = unsafeWindow.MP;
        if (!this.hasFeature('mpFontAwesome')) {
            this.injectFontAwesome();
        }
        if (!this.hasFeature('mpResetControls')) {
            this.addResetControls();
        }
        if (!this.hasFeature('mpMetricMathEnlargeControl')) {
            this.addMetricMathEnlargeControl();
        }
        if (!this.hasFeature('mpCopyPasteTimeControls')) {
            this.addCopyPasteTimeControls();
        }
        this.trapTinyLink();
        this.addSearchCsv();
    },

    hasFeature: function(id) {
        return $('#' + id).length > 0;
    },

    onIGraph: function(withArgs) {
        // Check if we're on iGraph
        var url = window.location.href;
        if (! /\/\/monitorportal.*.amazon.com\/igraph/.test(url)) {
            return false;
        }
        return true;
    },

    injectFontAwesome: function() {
        var heads = document.getElementsByTagName("head");
        if (heads.length > 0) {
            var link = document.createElement("link");
            link.type = "text/css";
            link.rel = "stylesheet";
            link.href = "https://m.media-amazon.com/images/G/01/Fonts/FontAwesome/css/font-awesome.min.css";
            heads[0].appendChild(link);
        }
    },

    updateModel: function(modelSettingsFunc) {
        var MP = IGraphPage.MP;
        var model = MP.graph.model();
        model.enableNotification(false);        // Switch off model events
        modelSettingsFunc();
        model.enableNotification(true);         // Re-enable model events
        model.notify(MP.graph.PARAMS.MODEL_CHANGED_EVENT);    // Fire a model changed event
        MP.GraphSection.displayGraph();
    },

    addMetricMathEnlargeControl: function() {
        var extraOptionsHeader = $('.extraOptionsHeader .headerRight');
        extraOptionsHeader.append('<i class="fa fa-angle-double-left iGHicon metricMathEnlargeIcon" title="Expand panel size (added by iGraphHelper)"></i>');
        extraOptionsHeader.append('<i class="fa fa-angle-double-right iGHicon metricMathReduceIcon" style="display: none;" title="Reset size of panel (added by iGraphHelper)"></i>');
        $('.metricMathEnlargeIcon').on('click', function() {
            $(this).css('display', 'none');
            $('.metricMathReduceIcon').css('display', '');
            $('#extraOptions').addClass('iGHextraOptionsWide');
            $('#extraEditor').attr('rows', 20);
            IGraphPage.MP.SectionHelper._slidingFinished(IGraphPage.MP.SectionHelper, 'extraOptions', true);
        });
        $('.metricMathReduceIcon').on('click', function() {
            $(this).css('display', 'none');
            $('.metricMathEnlargeIcon').css('display', '');
            $('#extraOptions').removeClass('iGHextraOptionsWide');
            $('#extraEditor').attr('rows', 6);
        });
    },

    addResetControls: function() {
        var MP = IGraphPage.MP;
        ['timeRanges', 'generalOptions', 'yAxisOptions', 'extraOptions'].forEach(function(section) {
            $('.' + section + 'Header .headerRight').append('<i class="fa fa-undo iGHicon ' + section + 'ResetIcon" title="Reset settings (added by iGraphHelper)"></i>');
        });
        $('.timeRangesResetIcon').on('click', function() {
            IGraphPage.updateModel(function() {
                var model = MP.graph.model();
                MP.TimeRanges.setTimeRange(model.createTimeRange(MP.MWS.TimeRangeType.RELATIVE, '-PT3H', MP.TimeRanges.DEFAULT_REL_END));
            });
        });
        $('.generalOptionsResetIcon').on('click', function() {
            IGraphPage.updateModel(function() {
                try {
                    var defs = MP.MWS.QS_DEFAULTS;
                    var model = MP.graph.model();
                    var options = model.options();
                    options.graphTitle('');
                    options.decoratePoints(MP.MWS.Boolean.TRUE);
                    options.showXAxisLabel(defs.SHOW_X_AXIS_LABEL);
                    options.showGaps(defs.SHOW_GAPS);
                    options.showLegend(defs.SHOW_LEGEND);
                    options.showLegendErrors(defs.SHOW_LEGEND_ERRORS);
                    options.splitLegend(defs.SPLIT_LEGEND);
                    options.legendPlacement(defs.LEGEND_PLACEMENT);
                    options.verticalLine().clear();
                } catch (e) { console.error(e); }
            });
        });
        $('.yAxisOptionsResetIcon').on('click', function() {
            IGraphPage.updateModel(function() {
                var defs = MP.MWS.QS_DEFAULTS;
                var model = MP.graph.model();
                var options = model.options();
                [ options.leftYAxis(), options.rightYAxis() ].forEach(function(axis) {
                    axis.label('');
                    axis.horizontalLine().clear();
                    axis.showYAxis(defs.SHOW_Y_AXIS)
                    axis.logScaling(defs.LOG_SCALING)
                    axis.shrinkBoundsToGraphData(defs.LOG_SCALING)
                    axis.upperValue('');
                    axis.lowerValue('');
                    axis.clipUpperValue('');
                });
            });
        });
        $('.extraOptionsResetIcon').on('click', function() {
            IGraphPage.updateModel(function() {
                MP.ExtraOptions.setExtra('');
            });
        });
    },

    addCopyPasteTimeControls: function() {
        var MP = IGraphPage.MP;
        $('#timeRanges .topLeft').prepend(
          '<div class="iGHcopyPasteTimeRanges">'
          + '    <i class="fa fa-copy iGHicon copyTimeRangesIcon" style="position: relative;"  title="Copy time range to clipboard for pasting to iGraph or to Wiki dashboard URL (added by iGraphHelper)"></i>'
          + '    <i class="fa fa-paste iGHicon pasteTimeRangesIcon" title="Pastes time ranges from clipboard (added by iGraphHelper)"></i>'
          + '</div>');

        $('.copyTimeRangesIcon').on('click', function() {
            var model = MP.graph.model();
            var timeRangeString = 'No time range was found in iGraph';
            if (model.timeRanges().size() > 0) {
                var timeRange = model.timeRanges().get(0);
                timeRangeString = '?StartTime1=' + timeRange.startTime() + '&EndTime1=' + timeRange.endTime();
            }
            $(this).animate({top: "-5px" }).animate({top: "0" })
            GM_setClipboard(timeRangeString);
        });
        $('.pasteTimeRangesIcon').on('click', function() {
            try {
                var timeRangeString = prompt('Paste iGraph URL or time range copied from another iGraph', '');
                if (timeRangeString) {
                    var params = VerticalLineUtils.parseQueryParams(timeRangeString);
                    var startTime = params['StartTime1'];
                    var endTime = params['EndTime1'];
                    if (startTime && endTime) {
                        var timeType = MP.TimeRangeUtils.getTimeType(startTime);
                        var model = MP.graph.model();
                        var timeRanges = model.timeRanges();
                        IGraphPage.updateModel(function () {
                            timeRanges.clear();
                            timeRanges.add(model.createTimeRange(timeType, startTime, endTime));
                        });
                    }
                }
            } catch (e) { console.error(e);}

        });
    },

    addSearchCsv: function() {
        function showCsv() {
            var csv = IGraphPage.processSearchResultRows();
            Lightbox.display('<span>Search Results in CSV format ' +
              '(<a href="data:text/csv,' + encodeURIComponent(csv) + '" download="iGraphSearch.csv">download link</a>)</span><br>' +
              '<textarea style="width: 500px; height: 280px;" wrap="off">' + csv + '</textarea>', 500, 300);
            $('.iGraphWikiLink').trigger('select');
            return false;
        }

        $('<li><a href="#">CSV</a></li>')
          .insertBefore('.globalFeatureContainer .linkToThisPageClass:last')
          .on('click', showCsv);
    },

    /**
     * Processes each row, creating a corresponding comma-separated
     * row, and deliminate each row with a newline.
     *
     * @return The CSV as a string.
     */
    processSearchResultRows: function() {
        var result = '';

        var rows = document.querySelector('.yui3-tab-panel-selected .yui3-datatable-data, .yui3-tab-panel-selected .yui-dt-data').children;
        for (var rowI = 0; rowI < rows.length; rowI++) {
            var row = rows[rowI];

            var firstPass = true;
            var columns = row.getElementsByTagName('a');
            for (var columnI = 0; columnI < columns.length; columnI++) {
                var column = columns[columnI];

                if(firstPass) {
                    firstPass = false;
                }
                else {
                    result += ',';
                }
                result += column.text;
            }
            result += '\n';
        }

        return result;
    },

    selectText: function(element) {
        var doc = document;
        var text = doc.getElementById(element);
        var selection = window.getSelection();
        var range = doc.createRange();
        range.selectNodeContents(text);
        selection.removeAllRanges();
        selection.addRange(range);
    },

    trapTinyLink: function() {
        if (! jQuery) {
            return;
        }
        var SPINNER = '<img src="/images/spinner.gif">',
          link = document.getElementById('linkToThisGraphTiny'),
          self = this;
        jQuery(link).after('<div id="urlToThisGraphTiny" style="display:none;display:inline;"></div>');
        link.addEventListener('click', function (e) {
            var url = jQuery(link).attr("href");
            var tinyHostname = TinyUrlRoot.replace(/^https?:\/\//, '');
            url = url.replace(/\/\/tiny\//, "//" + tinyHostname + "/");
            url = url.replace(/[?]comment=undefined/, "?comment=iGraph");   // Fix undefined comment
            jQuery(link).hide();
            jQuery("#urlToThisGraphTiny").html(SPINNER).fadeIn();
            GMUtils.getTinyLinkForUrl(url, function(tinyUrl) {
                jQuery(link).hide();
                var container = jQuery("#urlToThisGraphTiny");
                container.empty();
                var span = document.createElement('span');
                span.id = 'tinyUrl';
                span.textContent = tinyUrl;
                container.append(span);
                container.append('\u00a0');
                var msgSpan = document.createElement('span');
                msgSpan.textContent = 'has been copied to clipboard';
                container.append(msgSpan);
                GM_setClipboard(tinyUrl);
                IGraphPage.selectText("tinyUrl");
                setTimeout(function() {
                    jQuery("#urlToThisGraphTiny").fadeOut(function() {
                        jQuery("#linkToThisGraphTiny").fadeIn();
                    });
                }, 3000);
            });
            e.preventDefault();
            return false;
        });
    }
};

IGraphSettings = {
    settings: {},

    initialize: function() {
        if (! $) {
            return;
        }
        var settingsJSON = $('.IGraphSettings').text();
        if (settingsJSON != '') {
            this.settings = JSON.parse(settingsJSON);
        }
    }
};

VerticalLineUtils = {
    getReadableDateFromXmlDate: function(xmlDate) {
        return xmlDate == "now" ? xmlDate : xmlDate.replace(/-/g, '/').replace('T', ' ').replace(/:..Z/, "") + " UTC";
    },

    epochDaysAgo: function(numberOfDays) {
        return Math.floor(new Date().getTime() / 1000) - numberOfDays * 24 * 60 * 60;
    },

    iGraphUrl: function(verticalLineDef) {
        return 'https://monitorportal.amazon.com/igraph?VerticalLine1=' + encodeURIComponent(verticalLineDef);
    },

    pad: function(number){
        if (number < 10) {
            return "0" + number;
        }
        return number;
    },

    parseQueryParams: function(queryParams) {
        var str = queryParams || window.location.search;
        var paramMap = {};
        str.replace(new RegExp( "([^?=&]+)(=([^&]*))?", "g" ),
          function($0, $1, $2, $3) {
              paramMap[$1] = decodeURIComponent($3);
          }
        );
        return paramMap;
    },

    queryParamsToUrl: function(paramMap) {
        var fieldVals = [];
        for (var key in paramMap) {
            fieldVals.push(encodeURIComponent(key) + "=" + encodeURIComponent(paramMap[key]));
        }
        return fieldVals.join('&');
    }
};

ApolloDeployments = {
    CHECK_DELAY_MS: 250,
    verticalLineSettings: null,
    autoDisplay: false,
    fleetWideOnly: true,
    loadAll: false,
    days: 30,
    COLORS: ['#0000FF', '#00FF00', '#FF00FF', '#00E0E0', '#FFC000', '#FF0000', '#B24DE8',       // Taken from iGraph line colors
        '#808080', '#00B200', '#B200B2', '#00B2B2', '#B28600', '#B20000', '#B3B306',
        '#000000', '#007C00', '#800780', '#007C7C', '#7C5D00', '#FFAFAF', '#E0E000' ],
    DAYS_SELECTION: [ 1, 3, 7, 14, 30, 60, 90, 180 ],
    colorIndex: 0,

    initialize: function() {
        if (! $) {
            return;
        }

        if (IGraphSettings.settings.apolloVerticalLines) {
            for (key in IGraphSettings.settings.apolloVerticalLines) {
                this[key] = IGraphSettings.settings.apolloVerticalLines[key];
            }
        }
        this.displayVerticalLinesLinksOnApolloPage();
    },

    isNewApolloWebsite: function() {
        return $('.awsui').length > 0;
    },

    displayVerticalLinesLinksOnApolloPage: function() {
        var self = this,
          links = [],
          linesHtml;

        ApolloDeployments.DAYS_SELECTION.forEach(function(day) {
            links.push('<a class="iGraphVerticalLineDays" href="#">' + day + '</a>');
        });

        linesHtml = '<span class="iGraphStuff"><span style="display: inline-block; margin-left: 20px; ">iGraph Vertical Lines: ' +
          links.join('&nbsp;') + ' days</span> (include partial <input style="position: relative; top: 2px;" class="iGraphPartial" type="checkbox">) ' +
            '(CloudWatchVLines <input style="position: relative; top: 2px;" class="cloudWatchVLines" type="checkbox">)</span>';

        $('.iGraphStuff').remove();

        const clickEventInsert = function() {
            $('.iGraphVerticalLineDays').on('click', function() {
                var days = parseInt($(this).text(), 10);
                self.loadDeploymentTimesForApollo(days, !$('.iGraphPartial').is(':checked'), $('.cloudWatchVLines').is(':checked'));
            });
        };
        if (ApolloDeployments.isNewApolloWebsite()) {
            const observer = new MutationObserver(() => {
                if ($('#environmentStageSection #deploymentsSection .awsui-util-container-header').siblings(".iGraphStuff").length == 0) {
                    $('#environmentStageSection #deploymentsSection .awsui-util-container-header').after(linesHtml);
                    clickEventInsert();
                }
            });

            $('#environmentStageSection #deploymentsSection .awsui-util-container-header').parent().each(function() {
                observer.observe(this, {
                    subtree: true,
                    childList: true,
                });
            });
        }
        else {
            $(linesHtml).insertBefore('#tabcontainer div.content');
        }

        clickEventInsert();
    },

    loadDeploymentTimesForApollo: function(days, doFleetWideOnly, isCloudwatchAction) {
        var envUrl;
        if (ApolloDeployments.isNewApolloWebsite()) {
            var stage = $('#environmentStageSection .awsui-tabs-header a.awsui-tabs-tab-active.awsui-tabs-tab-link').attr('data-testid');
            envUrl = window.location.href.replace(/#$/, '').replace(/\/$/, '').replace('https://apollo.amazon.com', '');
            if (!envUrl.includes('/stages/')) {
                envUrl = envUrl + `/stages/${stage}`;
            }
        }
        else {
            envUrl = $('#environment .tabs .selected > a').attr('href');
        }
        if (envUrl != null) {
            var env = envUrl.replace('/environments/', '').replace('-/stages/', '').replace('stages/', '');
            ApolloDeployments.loadDeploymentTimes(env, days, true, null, doFleetWideOnly, isCloudwatchAction);
        }
    },

    loadDeploymentTimes: async function(apolloStage, days, isApolloPage, element, doFleetWideOnly, isCloudwatchAction) {
        var start = VerticalLineUtils.epochDaysAgo(days),
          end = VerticalLineUtils.epochDaysAgo(0);

        if (apolloStage == '') {
            this.displayVerticalLinesOniGraphs(null, element);
            this.colorIndex = 0;
        }
        var deployments = await ApolloDeployments.getDeploymentTimes(apolloStage, [], doFleetWideOnly, start, end);
        if (deployments) {
            ApolloDeployments.displayDeploymentTimes(deployments, days, apolloStage, isApolloPage, element, doFleetWideOnly, isCloudwatchAction);
        }
    },

    getDeploymentTimes: function(apolloStage, deployments, doFleetWideOnly, start, end, ) {
        return new Promise((resolve, reject) => {
            var post_data = JSON.stringify({EnvironmentStageIdentifier: ApolloDeployments.toNameAndStage(apolloStage),
                ...(doFleetWideOnly && { Fleetwide: doFleetWideOnly }),
                Queued: false,
                NotBefore: start,
                NotAfter: end,
                MaxResults: 100});
            GM_xmlhttpRequest({
                method: "POST",
                url: "https://apollo-api-tcp-iad.iad.proxy.amazon.com/",
                data: post_data,
                headers: {
                    "Content-Encoding": "amz-1.0",
                    "Accept": "text/javascript, */*",
                    "Content-Type": "application/json; charset=UTF-8",
                    "X-Amz-Target": "com.amazon.apolloapi.coral.generated.ApolloAPIService.ListDeploymentsForEnvironmentStageV2"
                },
                onload: function(response) {
                    if (response.responseText) {
                        if (/Midway auth/i.test(response.responseText)) {
                            alert("Failed to contact Apollo API service due to Midway auth. Please close the new tab that will open next, then return here and try again.\n\n**If tab fails to load, then please connect to VPN before trying again**");
                            GM_openInTab('https://apollo-api-tcp-iad.iad.proxy.amazon.com', false);
                            resolve(null);
                        }
                        else {
                            try {
                                var deployments = JSON.parse(response.responseText).Deployments;
                                resolve(deployments || []);
                            } catch (e) {
                                // Not a JSON response, so treat as no deployments
                                console.error(error);
                                resolve([]);
                            }
                        }
                    }
                    else {
                        resolve([]);
                    }
                }
            })
        });
    },

    toNameAndStage: function(apolloStage) {
        var stageIndex = apolloStage.lastIndexOf('/')
        var envName = apolloStage.substr(0, stageIndex)
        var stageName = apolloStage.substr(stageIndex + 1)
        return {EnvironmentName: envName, Stage: stageName}
    },

    wasRequestThrottled: function(response) {
        return response.status != 200 && response.responseText && /throttled/.test(response.responseText);
    },

    pushDeployments: function(deployments, currentDeployments) {
        var lastDeploymentId = deployments.length > 0 ? this.getTagValue(deployments[deployments.length - 1], 'deploymentId') : null;
        for (var i = 0; i < currentDeployments.length; i++) {
            var currentDeployment = currentDeployments[i],
              currentDeploymentId = this.getTagValue(currentDeployment, 'deploymentId');
            if (currentDeploymentId !== lastDeploymentId) {
                return deployments.push.apply(deployments, currentDeployments.slice(i));
            }
        }
    },

    parseDeployments: function(response) {
        var goodResponse = response.status == 200,
          xml = new DOMParser().parseFromString(response.responseText, "text/xml"),
          apolloDeployments = xml.getElementsByTagName("entry");

        if (!goodResponse) {
            return;
        }

        return Array.prototype.slice.call(apolloDeployments);
    },

    getOldestDeployment: function(deployments) {
        if (deployments.length > 0) {
            return deployments[deployments.length - 1];
        }
    },

    displayDeploymentTimes: function(deployments, days, apolloStage, isApolloPage, element, doFleetWideOnly, isCloudwatchAction) {
        var verticalLines = [],
          color = this.color || this.COLORS[this.colorIndex ++ % this.COLORS.length],
          verticalLineDef;

        if (deployments.length === 0) {
            alert('No deployments found in last ' + days + ' day' + (days > 1 ? 's': ''));
            return;
        }

        for (var i = 0; i < deployments.length; i++) {
            var deployment = deployments[i];
            verticalLines.push(this.getVerticalLineString(deployment, color));
        }
        verticalLineDef = verticalLines.join(",");

        if (isCloudwatchAction) {
            this.convert_iGraph_To_Cloud_Watch_VLines(verticalLineDef, days);
            return;
        }

        if (isApolloPage) {
            this.displayVerticalLinesOnApolloPage(verticalLineDef, days);
        }
        else {
            this.displayVerticalLinesOniGraphs(verticalLineDef, element);
        }
        this.ifLoadAllSetLoadNextEnv(element);
    },

    getVerticalLineString: function(deployment, color) {
        var startTime = new Date(deployment.StartTime * 1000).toISOString();
        var endTime = new Date(deployment.EndTime * 1000).toISOString();
        var depId = deployment.Id;
        var colorDef = color ? ('#color=' + color) : "";
        return "(Deployment " + depId + " " + colorDef + " @ " + startTime +
          ", ends " + colorDef + " @ " + endTime + ")";
    },

    convert_iGraph_To_Cloud_Watch_VLines: function(iGraphVLines, days) {
        const result = WikiVerticality.ig_to_cw(iGraphVLines);

        GMUtils.setClipboard(result);
        alert('Cloudwatch vertical lines (days: ' + days + ') have been copied to the clipboard');
    },

    ifLoadAllSetLoadNextEnv: function(element) {
        if (this.loadAll) {
            var numEnvs = $('option', element).length;
            if (element.selectedIndex + 1 < numEnvs) {
                element.selectedIndex += 1;
                $(element).trigger('change');
            }
        }
    },

    displayVerticalLinesOnApolloPage: function(verticalLineDef, days) {
        GMUtils.setClipboard(verticalLineDef);
        alert('Vertical lines (days: ' + days + ') have been copied to the clipboard');
    },

    getCpuGraphUrl: function(hostclass, host, period, verticalLineDef, days) {
        return 'https://monitorportal.amazon.com/igraph?SchemaName1=Snitch&DataSet1=prod&HostGroup1=' + hostclass + '&Host1=' + host + '&Class1=CPU&Object1=cpu&Metric1=CapacityCPUUtilization&Period1=' + period + '&Stat1=avg&HeightInPixels=250&WidthInPixels=600&VerticalLine1=' + encodeURIComponent(verticalLineDef) + '&StartTime1=-P' + days  + 'D&EndTime1=-PT0H';
    },

    deploymentTimeClicked: function() {
        var deploymentDays = parseInt($(this).text());
        if (deploymentDays > 0) {
            ApolloDeployments.loadDeploymentTimesForApollo(deploymentDays);
        }
    },

    getDateString: function(deployment, tag) {
        var date = this.getTagValue(deployment, tag);
        return date == null ? "now" : date;
    },

    getTagValue: function(deployment, tag) {
        var el = deployment.getElementsByTagName(tag);
        if (! el[0]) {
            el = deployment.getElementsByTagName("apollo:" + tag);
        }
        if (! el[0]) {
            return null;
        } else {
            return el[0].textContent;
        }
    }
};

PipelineDeployments = {
    days: 30,
    DAYS_SELECTION: ApolloDeployments.DAYS_SELECTION,

    initialize: function() {
        if (! $) {
            return;
        }

        if (IGraphSettings.settings.apolloVerticalLines) {
            for (key in IGraphSettings.settings.apolloVerticalLines) {
                this[key] = IGraphSettings.settings.apolloVerticalLines[key];
            }
        }
        this.displayVerticalLinesLinksOnPipelinesRevisionPage();
        this.setupDeploymentsPageCallback();
    },

    displayVerticalLinesLinksOnPipelinesRevisionPage: function() {
        var self = this,
          links = [],
          linesHtml;

        PipelineDeployments.DAYS_SELECTION.forEach(function(day) {
            links.push('<a class="iGraphVerticalLineDays" href="#">' + day + '</a>');
        });

        linesHtml = '<span class="iGraphStuff"><span style="display: inline-block; margin-left: 20px; ">iGraph Vertical Lines: ' +
          links.join('&nbsp;') + ' days</span> (CloudWatchVLines <input style="position: relative; top: 2px;" class="cloudWatchVLines" type="checkbox">)</span>';

        $('.iGraphStuff').remove();
        $(linesHtml).insertBefore('table#revisions_data_table');
        $('.iGraphVerticalLineDays').on('click', function() {
            var days = parseInt($(this).text(), 10);
            self.loadDeploymentTimesForPipelinesRevisions(days);
        });
    },

    loadDeploymentTimesForPipelinesRevisions: function(days) {
        var args = (/https:\/\/pipelines\.amazon\.com\/pipelines\/(?<pipeline_name>.+)\/stages\/(?<stage_name>.+)\/revisions/.exec(window.location.href));
        PipelineDeployments.getPipelineRevisionsFor({
                pipeline: args.groups['pipeline_name'],
                stage: args.groups['stage_name'],
                start: VerticalLineUtils.epochDaysAgo(days),
                end: VerticalLineUtils.epochDaysAgo(0),
            })
            .then(result => {
                if ($('.cloudWatchVLines')?.is(':checked')) {
                    const cw_result = WikiVerticality.ig_to_cw(result);
                    GMUtils.setClipboard(cw_result);
                    alert('Cloudwatch vertical lines (days: ' + days + ') have been copied to the clipboard');
                } else {
                    GMUtils.setClipboard(result);
                    alert('Vertical lines (days: ' + days + ') have been copied to the clipboard');
                }
            });
    },

    getPipelineRevisionsFor: async function(pipeline) {
        return new Promise(function (resolve, reject) {
                GM.xmlHttpRequest({
                    method: 'GET',
                    url: `https://pipelines.amazon.com/pipelines/${pipeline.pipeline}/stages/${pipeline.stage}/revisions.rss?from=${pipeline.start}&to=${pipeline.end}`,
                    timeout: 5000,
                    onload: function (response) {
                        if (response.status >= 200 && response.status < 300) {
                            resolve(this);
                        } else {
                            console.error(response.responseText)
                            reject(this);
                        }
                    },
                    ontimeout: reject,
                    onerror: reject,
                    onabort: reject,
                });
            })
            .then(data => new DOMParser().parseFromString(data.response, "text/xml"))
            .then(xmlDoc => Promise.all(Array.from(xmlDoc.getElementsByTagName("rss")[0].getElementsByTagName("channel")[0].getElementsByTagName("item"))
                .map(e => e.getElementsByTagName("guid")[0].innerHTML)
                .map(url => url.match(/deploymentJobId=([0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12})/))
                .filter(match => match != null)
                .map(match => match[1])
                .map(id => { return { deploymentJobId: id, pipeline: pipeline } })
                .map(deployment => new Promise((resolve) => {
                    let div = document.createElement("div");
                    div.id = deployment.deploymentJobId;
                    Array.from(document.children)[0].lastChild.after(div);
                    div.style.display = "none";
                    let frame = document.createElement("iframe");
                    div.appendChild(frame);
                    frame.name = `dummy-frame-${deployment.deploymentJobId}`;
        
                    const endpoint = 'https://deployment-group.pipelines.a2z.com';
                    window.addEventListener("message", (event) => {
                        if (event.origin === endpoint && event.data?.deploymentJob?.deploymentJobId === deployment.deploymentJobId) {
                            resolve({ ...event.data, config: deployment.pipeline });
                            frame.remove();
                        }
                    }, false);
        
                    frame.src = `${endpoint}/deployments/${deployment.deploymentJobId}`;
                }))
            ))
            .then(deployments => deployments.map((deployment) => [
                {
                    "label": `${deployment.deploymentJob.status} | ${deployment.deploymentJob.deploymentJobId}`,
                    "value": new Date(deployment.deploymentJob.startTime * 1000).toISOString()
                },
                {
                    "value": new Date(deployment.deploymentJob.completeTime * 1000).toISOString()
                }
            ]))
            .then(deployments => WikiVerticality.cw_to_ig(deployments));
    },

    setupDeploymentsPageCallback: function() {
        if (location.host === "deployment-group.pipelines.a2z.com" && window.top !== window.self) {
            const SEND_ACTUAL = unsafeWindow.XMLHttpRequest.prototype.send;
            // Determine parent origin for postMessage - only allow pipelines.amazon.com
            const allowedParentOrigin = 'https://pipelines.amazon.com';
            unsafeWindow.XMLHttpRequest.prototype.send = function (data) {
                const json = JSON.parse(data);
                if (json.deploymentJobId) {
                    this.onloadend = function () {
                        if (this.readyState == XMLHttpRequest.DONE) {
                            window.top.postMessage(JSON.parse(this.responseText), allowedParentOrigin);
                        }
                    }
                }
                SEND_ACTUAL.apply(this, arguments);
            }
        } 
    }
};

WikiVerticality = {
    initialize: function() {
        if (! $) {
            return;
        }

        if (IGraphSettings.settings.apolloVerticalLines) {
            for (key in IGraphSettings.settings.apolloVerticalLines) {
                this[key] = IGraphSettings.settings.apolloVerticalLines[key];
            }
        }
        this.bootstrapVerticalLinesHandling();
    },

    __enhanceAdvancedPanel: function(widgets, optionTitle, days, label, defaultsSample, formatPrompt, template, callback) {
        const options = (widgets.filter(a => a.innerHTML.startsWith(optionTitle)) ?? [null]);
        const infoBlurb = `You can specify which default options are available for your dashboard by adding this to your wiki source:\n\n${defaultsSample}`;

        const target = $($(template).clone(true));
        target.insertAfter(template);

        const title = $(target.find(".MPWmenuTitle")[0]);
        title.text(`${label}: `);
        target.find("input")[0].remove();

        const id = `MPW${label.replaceAll(" ", "")}`;
        const input = $(`<input type="text" list="${id}" placeholder="${formatPrompt}" />`);
        const datalist = $(`<datalist id="${id}"></datalist>`);
        if (options) {
            $(options)?.find("select option").each((index, elem) => {
                if (elem.text && elem.text.length > 0) {
                    datalist.append($(`<option value="${elem.text}">`));
                }
            });
            $(options)?.remove();
        }
        title.after(input);
        input.after(datalist);

        const info = $('<span><svg style="cursor: pointer;display: inline-block;top: 2px;position: relative;" width="15px" height="15px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M12 3.53846C7.32682 3.53846 3.53846 7.32682 3.53846 12C3.53846 16.6732 7.32682 20.4615 12 20.4615C16.6732 20.4615 20.4615 16.6732 20.4615 12C20.4615 7.32682 16.6732 3.53846 12 3.53846ZM2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12Z" fill="#030D45"/><path fill-rule="evenodd" clip-rule="evenodd" d="M12 16.359C12.4248 16.359 12.7692 16.0146 12.7692 15.5897V11.4872C12.7692 11.0623 12.4248 10.7179 12 10.7179C11.5752 10.7179 11.2308 11.0623 11.2308 11.4872V15.5897C11.2308 16.0146 11.5752 16.359 12 16.359Z" fill="#030D45"/><path d="M13.0256 8.41026C13.0256 7.84381 12.5664 7.38462 12 7.38462C11.4336 7.38462 10.9744 7.84381 10.9744 8.41026C10.9744 8.9767 11.4336 9.4359 12 9.4359C12.5664 9.4359 13.0256 8.9767 13.0256 8.41026Z" fill="#030D45"/></svg></span>');
        $(target.find(".MPWenter")[0]).after(info);
        info.on("click", function() {
            alert(infoBlurb);
        });
        const loading = $('<span style="display: none"><div class="igh_loader"></div></span>');
        info.after(loading);

        const doHandle = function() {
            loading.css("display", "");
            callback(input.val()).then((deployments) => {
                unsafeWindow.MPW.WikiWidgets.updateFields(
                    $(template.find("input")[0]),
                    {
                        text: "VerticalLine1",
                        value: "VerticalLine1"
                    },
                    deployments
                );
                if (deployments.length == 0) {
                    throw Error("no deployments");
                }
            })
            .catch((error) => {
                console.error(error);
                alert(`No deployments found for '${input.val()}' over the last ${days} days.\n\nDoes the input match the right format?\n\n**${formatPrompt}**`);
            })
            .finally(() => {
                loading.css("display", "none");
            });
        };
        target.find(".MPWenter")[0].onclick = function () {
            doHandle();
        };
        input.on("keyup", function( event ) {
            if (event.keyCode === 13) {
                doHandle();
            }
        });
    },

    enhanceInputs: function() {
        const widgets = Array.from($('.MPWwidget .MPWmenuTitle'));
        const vline = $(widgets.filter(a => a.innerHTML.startsWith("Vertical Line"))[0].parentNode);

        this.__enhanceAdvancedPanel(
            widgets, 
            "Pipeline Deployments", 
            PipelineDeployments.days, 
            "Pipelines Deployment Lines", 
            '{{igraph type="menu" args="Pipeline Deployments | , PipelineOne/Stage, PipelineTwo/Stage | 0"/}}',
            "PipelineName/Stage", 
            vline, 
            (val) => PipelineDeployments.getPipelineRevisionsFor({
                pipeline: val.split("/")[0].trim(),
                stage: val.split("/")[1].trim(),
                start: VerticalLineUtils.epochDaysAgo(PipelineDeployments.days),
                end: VerticalLineUtils.epochDaysAgo(0),
            })
        );

        this.__enhanceAdvancedPanel(
            widgets,
            "Deployments",
            ApolloDeployments.days,
            "Apollo Deployment Lines",
            '{{igraph type="menu" args="Deployments | , ApolloFleet/NA/Alpha, ApolloFleet/EU/Alpha | 0"/}}',
            "ApolloEnv/Stage",
            vline,
            (val) => {
                return ApolloDeployments.getDeploymentTimes(
                        val,
                        [],
                        true,
                        VerticalLineUtils.epochDaysAgo(ApolloDeployments.days),
                        VerticalLineUtils.epochDaysAgo(0)
                    )
                    .then((deployments) => {
                        return deployments.map((deployment) => ApolloDeployments.getVerticalLineString(deployment, ApolloDeployments.COLORS[0]));
                    })
                    .then((deployments) => {
                        return deployments.join(",");
                    });
            }
        );
    },

    injectStyle: function() {
        const style = document.createElement('style');
        style.innerHTML = `
            .igh_loader {
                border: 1px solid #F3F3F3;
                border-radius: 50%;
                border-top: 1px solid #050D42;
                display: inline-block;
                width: 10px;
                height: 10px;
                -webkit-animation: igh_spinner 2s linear infinite;
                animation: igh_spinner 2s linear infinite;
                margin-left: 5px;
            }

            @-webkit-keyframes igh_spinner {
                0% { -webkit-transform: rotate(0deg); }
                100% { -webkit-transform: rotate(360deg); }
            }

            @keyframes igh_spinner {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(style);
    },

    swizzleUpdateFields: function(widgets) {
        widgets.__swizzled_updateFields = widgets.updateFields;
        widgets.updateFields = function (target, event, input) {
            if (event.text === "VerticalLine1") {
                try {
                    const json = JSON.parse(input);
                    input = WikiVerticality.cw_to_ig(json);
                } catch(err) {
                    // Assuming not cloudwatch annotation format
                    input = input;
                }
            }

            widgets.__swizzled_updateFields(target, event, input);
        };
    },

    swizzleUpdateFieldsInInteractiveGraphs: function(widgets) {
        widgets.__swizzled_doUpdateFieldsInInteractiveGraphs = widgets._doUpdateFieldsInInteractiveGraphs;
        widgets._doUpdateFieldsInInteractiveGraphs = function (target, event, input) {
            widgets.__swizzled_doUpdateFieldsInInteractiveGraphs(target, event, input);
            if (event[0] === "VerticalLine1") {
                let verticles = WikiVerticality.ig_to_cw(input[0]);
                Array.from(document.getElementsByTagName('iframe'))
                    .filter(e => (/dashboardInternal/.test(e.src)))
                    .forEach(frame => {
                        // Use frame's origin for postMessage instead of wildcard
                        var frameOrigin = new URL(frame.src).origin;
                        frame.contentWindow.postMessage({"properties": {"annotations": { "vertical": JSON.parse(`${verticles}`) }}}, frameOrigin);
                    });
            }
        };
    },

    bootstrapVerticalLinesHandling: function() {
        const interval = setInterval(() => {
            const widgets = unsafeWindow?.MPW?.WikiWidgets;
            if (widgets) {
                clearInterval(interval);
                if (null != document.body.className.match("mediawiki")) {
                    this.injectStyle();
                    this.enhanceInputs();
                    this.swizzleUpdateFields(widgets);
                    this.swizzleUpdateFieldsInInteractiveGraphs(widgets);
                }
            }
        }, 100);
    },

    cw_to_ig: function(json) {
        return Array.from(json)
            .map((annotation) => {
                if (annotation instanceof Array && annotation.length == 2) {
                    return `(${annotation[0]['label']} #color=${annotation[0]['color'] ?? ApolloDeployments.COLORS[0]} @ ${annotation[0]['value']},${annotation[1]['label'] ?? ""} #color=${annotation[1]['color'] ?? ApolloDeployments.COLORS[0]} @ ${annotation[1]['value']})`;
                } else {
                    return `${annotation['label']} #color=${annotation['color'] ?? ApolloDeployments.COLORS[0]} @ ${annotation[0]['value']}`;
                }
            })
            .join(",");
    },

    ig_to_cw: function(str) {
        const annotations = this._ig_split_lines(str)
            .map((line) => {
                for (let converter of [this._ig_band_to_cw, this._ig_line_to_cw, this._timestamp_to_cw, this._duration_to_cw]) {
                    try {
                        const result = converter(line);
                        if (result) {
                            return result;
                        }
                    } catch(error) {
                        // no-op
                    }
                }
                return "";
            });

        return `[${annotations}]`;
    },

    _ig_split_lines_splitter: function(lines, delimiter) {
        const delim = lines.indexOf(delimiter);
        if (delim != -1) {
            return {
                line: lines.slice(0, delim + delimiter.length - 1),
                remaining: lines.slice(delim + delimiter.length)
            };
        } else {
            return {
                line: lines
            };
        }
    },

    _ig_split_lines: function(lines) {
        if (lines.startsWith("(")) {
            let ll = this._ig_split_lines_splitter(lines, "),")
            return [
                ll.line,
                ...(ll.remaining ? this._ig_split_lines(ll.remaining) : [])
            ];
        } else if (lines.includes(",")) {
            let ll = this._ig_split_lines_splitter(lines, ",")
            return [
                ll.line,
                ...(ll.remaining ? this._ig_split_lines(ll.remaining) : [])
            ];
        } else {
            return [ lines ];
        }
    },

    _ig_band_to_cw: function(str) {
        const regex = /\((?<label_1>.*) ((#color=(?<color_1>.*))|-) @ (?<value_1>.*),(?<label_2>.*) ((#color=(?<color_2>.*))|-) @ (?<value_2>.*)\)/gm;
        const result = regex.exec(str);
        if (result) {
            const { groups: { label_1, label_2, color_1, color_2, value_1, value_2 } } = result;

            return JSON.stringify([
                {
                    label: label_1,
                    ...(color_1 ? {color: color_1} : {}),
                    value: value_1,
                },
                {
                    label: (label_2 ?? "").trim(),
                    ...(color_2 ? {color: color_2} : {}),
                    value: value_2,
                },
            ]);
        } else {
            return null;
        }
    },

    _ig_line_to_cw: function(str) {
        const regex = /(?<label>.*) ((#color=(?<color>.*))|-) @ (?<value>.*)/gm;
        const result = regex.exec(str);
        if (result) {
            const { groups: { label, color, value } } = result;

            return JSON.stringify({
                label: label,
                ...(color ? {color: color} : {}),
                value: value,
            });
        } else {
            return null;
        }
    },

    _timestamp_to_cw: function(str) {
        if (!isNaN(Date.parse(str))) {
            return JSON.stringify({
                "value": str
            });
        } else {
            return null;
        }

    },

    _duration_to_cw: function(str) {
        const regex = /(?<direction>\+|-)P((?<years>\d)Y)?((?<months>\d)M)?((?<days>\d)D)?T?((?<hours>\d)H)?((?<minutes>\d)M)?((?<seconds>\d(.(?<millis>\d))?)S)?/gm;
        const result = regex.exec(str);
        if (result) {
            const { groups: { direction, years, months, days, hours, minutes, seconds, millis } } = result;
            const operand = direction == "+" ? 1 : -1;
            let timestamp = Date.now();
            timestamp += (years ?? 0) * operand * 1000 * 60 * 60 * 24 * 365.25;
            timestamp += (months ?? 0) * operand * 1000 * 60 * 60 * 24 * 365.25 / 12;
            timestamp += (days ?? 0) * operand * 1000 * 60 * 60 * 24;
            timestamp += (hours ?? 0) * operand * 1000 * 60 * 60;
            timestamp += (minutes ?? 0) * operand * 1000 * 60;
            timestamp += (seconds ?? 0) * operand * 1000;
            timestamp += (millis ?? 0) * operand;
            const date = new Date(timestamp);
            return JSON.stringify({
                "label": str,
                "value": date.toISOString()
            });
        } else {
            return null;
        }
    },
};

InteractiveWikiGraphs = {
    initialize: function() {
        WebLabTimes.waitFor(function () {
            return document.querySelector('.MPWwidgetContainer') != null;
        }, InteractiveWikiGraphs.displayInteractiveButton);
    },

    addChildWindowOpening: function() {
        function interactiveGraphOpening() {
            var CHILD_URI = 'https://cloudwatch-console-tools.iad.amazon.com',
              CHILD_URL = CHILD_URI + '/igraph/GoInteractive.html',
              childWindow;

            window.openInteractiveGraphWindow = function() {
                childWindow = window.open(CHILD_URL);
            }
            function childReady(event) {
                childWindow.postMessage(window.dashboardDef, CHILD_URI);
            }
            window.addEventListener("message", childReady, false);
        }
        var script = document.createElement('script');
        script.appendChild(document.createTextNode('('+ interactiveGraphOpening +')();'));
        (document.head || document.body).appendChild(script);
    },

    getGraphDefinition: function(graphArgs) {
        var title = WikiSnapshot.extractQueryValue(graphArgs, 'GraphTitle') || '',
          graphDef =
            'metrics:\n' +
            '- {iGraph: "' + graphArgs + '" }\n' +
            'title: "' + title + '"\n' +
            'period: 300\n' +
            'stat: Average\n' +
            'yAxis: \n' +
            '  left: \n' +
            '  right: \n' +
            'region: us-east-1\n';
        return graphDef;
    },

    getDashboardDefinition: function() {
        var dashboardDef = [],
          imageIndex = 0;

        for (var i = 0; i < document.images.length; i++) {
            var image = document.images[i];
            var graphArgs = unsafeWindow.MPW.getGraphArgs(image, true);
            if (graphArgs != null) {
                dashboardDef.push(this.getGraphDefinition(graphArgs));
            }
        }
        return JSON.stringify(dashboardDef);
    },

    displayInteractiveGraphs: function() {
        unsafeWindow.dashboardDef = InteractiveWikiGraphs.getDashboardDefinition();
        unsafeWindow.openInteractiveGraphWindow();
    },

    displayInteractiveGraph: function(graphArgs) {
        unsafeWindow.dashboardDef = JSON.stringify([ InteractiveWikiGraphs.getGraphDefinition(graphArgs) ]);
        unsafeWindow.openInteractiveGraphWindow();
    },

    displayInteractiveButton: function() {
        InteractiveWikiGraphs.addChildWindowOpening();
        var button = document.createElement('span');
        button.style.float = 'right';
        button.innerHTML = '<input value="Interactive Graphs" class="MPWbutton primary IGHinteractiveGraphs" type="submit">';
        button.onclick = InteractiveWikiGraphs.displayInteractiveGraphs;
        document.querySelector('.MPWwidgetContainer').appendChild(button);
    }
};

var addStyle = GM_addStyle;

function localGMCode(win, unsafeWin) {
    var $ = jQuery;
    win.Lightbox = {
        display: function (content, width, height) {
            function initLightbox() {
                var STYLES = '\
                #iGraphLightbox {\
                    visibility:hidden;\
                    position:fixed;\
                    background:white;\
                    border:2px solid #3c3c3c;\
                    color:black;\
                    z-index:15100;\
                    padding:20px;\
                }\
                #iGraphLightboxDimmer{\
                    background: #000;\
                    position: fixed;\
                    opacity: .5;\
                    top: 0;\
                    z-index:1509;\
                }';
                addStyle(STYLES);
                $('body').append('<div id="iGraphLightbox"></div><div id="iGraphLightboxDimmer"></div>');
            }

            if (!this.initialized) {
                initLightbox();
                this.initialized = true;
            }

            var lightbox = document.getElementById("iGraphLightbox"),
              dimmer = document.getElementById("iGraphLightboxDimmer");
            $(lightbox).html(content);

            lightbox.style.width = width + 'px';
            lightbox.style.height = height + 'px';
            dimmer.style.width = window.innerWidth + 'px';
            dimmer.style.height = window.innerHeight + 'px';

            dimmer.onclick = function () {
                lightbox.style.visibility = 'hidden';
                dimmer.style.visibility = 'hidden';
                $(lightbox).html('');
            }

            dimmer.style.visibility = 'visible';
            lightbox.style.visibility = 'visible';
            lightbox.style.top = (window.innerHeight - height) / 2 + 'px';
            lightbox.style.left = (window.innerWidth - width) / 2 + 'px';
            $('.iGraphChimeRoomManagerControls').hide();
            return false;
        }
    };

    win.GMUtils = {
        initialize: function() {
            this.injectFunctionsIntoPage();
        },

        injectFunctionsIntoPage: function () {
            var gmInjectFuncs = {
                getAccountName: function(accountId) { if (typeof AccountName !== 'undefined') { return AccountName.getAccountName(accountId); } },
                accountIdToName: async function(accountId) { if (typeof AccountName !== 'undefined') { return await AccountName.accountIdToName(accountId); } },
                addStyle: function(styles) { return setTimeout(() => { GM_addStyle(styles); }, 0); },
                domToImage: function() { return domtoimage; },
                getIsengardLinkForUrl: function(url) { return getIsengardLinkForUrl(url); },
                getTinyLinkForUrl: function(url, callback) { return getTinyLinkForUrl(url, callback); },
                getValue: function(name, def) { return GM_getValue(name, def); },
                gmXmlHttpRequest: function(object) { return GM_xmlhttpRequest(object); },
                sendFormDataToS3: function(object) { return sendFormDataToS3(object); },
                sendJSONtoURL: function(webhookUrl, message) { return sendJSONtoURL(webhookUrl, message); },
                setClipboard: function(value, type) { return setTimeout(() => { GM_setClipboard(value, type) }, 0); },
                setValue: function(name, value) { return GM_setValue(name, value); },
                snapshotDisplay: function(snapshotUrl, iGraphUrl, graphId) { if (typeof WikiSnapshot != 'undefined') { WikiSnapshot.snapshotDisplay(snapshotUrl, iGraphUrl, graphId); } },
                snapshotDisplayInPopup: function(graphModel, id) { if (typeof WikiSnapshot != 'undefined') { WikiSnapshot.snapshotDisplayInPopup(Lightbox.display, graphModel, 'CloudWatch graph', false, id); } }
            };

            // Support for GreaseMonkey implementations that don't proxy the
            // Firefox Components.utils API (e.g. ViolentMonkey)
            if (typeof createObjectIn === "undefined") {
                createObjectIn = function(scope, opts) {
                    return scope[opts.defineAs] = new scope.Object();
                }
            }

            if (typeof exportFunction === "undefined") {
                exportFunction = function(func, scope, options) {
                    if (options && options.defineAs) {
                        scope[options.defineAs] = func;
                    }
                    return func;
                };
            }

            var injectedGM = createObjectIn(unsafeWin, {defineAs: "iGraphHelperGM"});
            exportFunction(gmInjectFuncs.accountIdToName, injectedGM, {defineAs: "accountIdToName" });
            exportFunction(gmInjectFuncs.getAccountName, injectedGM, {defineAs: "getAccountName" });
            exportFunction(gmInjectFuncs.addStyle, injectedGM, {defineAs: "addStyle" });
            exportFunction(gmInjectFuncs.domToImage, injectedGM, {defineAs: "domToImage" });
            exportFunction(gmInjectFuncs.getValue, injectedGM, {defineAs: "getValue" });
            exportFunction(gmInjectFuncs.gmXmlHttpRequest, injectedGM, {defineAs: "gmXmlHttpRequest" });
            exportFunction(gmInjectFuncs.getTinyLinkForUrl, injectedGM, {defineAs: "getTinyLinkForUrl" });
            exportFunction(gmInjectFuncs.sendFormDataToS3, injectedGM, {defineAs: "sendFormDataToS3" });
            exportFunction(gmInjectFuncs.sendJSONtoURL, injectedGM, {defineAs: "sendJSONtoURL" });
            exportFunction(gmInjectFuncs.setClipboard, injectedGM, {defineAs: "setClipboard" });
            exportFunction(gmInjectFuncs.setValue, injectedGM, {defineAs: "setValue" });
            exportFunction(gmInjectFuncs.snapshotDisplay, injectedGM, {defineAs: "snapshotDisplay" });
            exportFunction(gmInjectFuncs.snapshotDisplayInPopup, injectedGM, {defineAs: "snapshotDisplayInPopup" });
            return true;
        },

        log: function(msg) {
            win.console.log(msg);
        },

        getValue: function(key) {
            if (typeof GM_getValue !== 'undefined') {
                return GM_getValue(key);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.getValue(key);
            }
            return null;
        },

        setValue: function(key, value) {
            if (typeof GM_setValue !== 'undefined') {
                return GM_setValue(key, value);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.setValue(key, value);
            }
            return null;
        },

        gmXmlHttpRequest: function(object) {
            if (typeof GM_xmlhttpRequest !== 'undefined') {
                return GM_xmlhttpRequest(object);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.gmXmlHttpRequest(object);
            }
            return null;
        },

        getTinyLinkForUrl: function(url, callback) {
            if (typeof getTinyLinkForUrl !== 'undefined') {
                return getTinyLinkForUrl(url, callback);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.getTinyLinkForUrl(url, callback);
            }
            return null;
        },

        sendFormDataToS3: function(object) {
            if (typeof sendFormDataToS3 !== 'undefined') {
                return sendFormDataToS3(object);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.sendFormDataToS3(object);
            }
            return null;
        },

        sendJSONtoURL: function(webhookUrl, message) {
            if (typeof sendJSONtoURL !== 'undefined') {
                return sendJSONtoURL(webhookUrl, message);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.sendJSONtoURL(webhookUrl, message);
            }
            return null;
        },

        setClipboard: function(value, type) {
            if (typeof GM_setClipboard !== 'undefined') {
                return GM_setClipboard(value, type);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.setClipboard(value, type);
            }
            return null;
        },

        addStyle: function(styles) {
            if (typeof GM_addStyle !== 'undefined') {
                return GM_addStyle(styles);
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.addStyle(styles);
            }
            return null;
        },

        domToImage: function(styles) {
            if (typeof domtoimage !== 'undefined') {
                return domtoimage;
            } else if (typeof iGraphHelperGM !== 'undefined') {
                return iGraphHelperGM.domToImage();
            }
            return null;
        }
    };

    win.WikiSourceEditor = {
        CW_CONSOLE: 'https://console.aws.amazon.com/cloudwatch/home?region=us-east-1',
        NOT_FOUND: 'Could not find a CloudWatch graph definition. Is the cursor inside a \'{{transclude name="CloudWatch.Graph"... /}}\' definition?',
        $textarea: null,
        _metricWidgetStr: null,
        _cwConsoleChildWindow: null,

        initialize: function() {
            this.$textarea = jQuery('#content');
            if (/transclude.*name="CloudWatch.Graph"/.test(this.$textarea.val())) {
                GM_registerMenuCommand("iGraph Helper: open current graph in console (Ctrl-Alt-C)", function() { WikiSourceEditor._openCurrentGraph(); } );
                GM_registerMenuCommand("iGraph Helper: select current graph (Ctrl-Alt-V)", function() { WikiSourceEditor._selectCurrentGraph(); } );
                unsafeWin.addEventListener('keydown', function(e) { WikiSourceEditor._keyListen(e); }, true);
            }
        },

        onEditPage: function() {
            return /^[/]bin[/]edit[/]/.test(window.location.pathname);
        },

        onSourceEditor: function() {
            return /editor=wiki/.test(window.location.search);
        },

        _keyListen: function(e) {
            if (e.ctrlKey && e.altKey) {
                if (e.code === 'KeyC') {
                    this._openCurrentGraph();
                } else if (e.code === 'KeyV') {
                    this._selectCurrentGraph();
                }
            }
        },

        _getCurrentGraph: function() {
            var wikiSource = this.$textarea.val(),
              cursor = this.$textarea.prop('selectionStart'),
              before = wikiSource.substr(0, cursor),
              after = wikiSource.substr(cursor),
              start = this._lastIndexOf(before, /{{transclude name="CloudWatch.Graph"/g),
              end = after.search(/\/}}/);

            if (start >= 0 && end >= 0) {
                return {
                    start: start,
                    end: before.length + end + 3,
                    text: before.substr(start) + after.substr(0, end)
                };
            }

            return null;
        },

        _openCurrentGraph: function() {
            var currentGraph = this._getCurrentGraph(),
              metricWidgetStr,
              jsonStart,
              jsonEnd,
              graphText;

            if (currentGraph) {
                // Found graph - now find Metric Widget definition - it's the JSON in {} - skip past the {{ and }} at start/end
                graphText = currentGraph.text.replace(/^{{/, '').replace(/}}$/, '');
                jsonStart = graphText.indexOf('{');
                jsonEnd = graphText.lastIndexOf('}');

                if (jsonStart >= 0 && jsonEnd >= 0) {
                    metricWidgetStr = graphText.substr(jsonStart, jsonEnd - jsonStart + 1);
                    this._openInCloudWatchConsole(metricWidgetStr);
                    return;
                }
            }

            alert(this.NOT_FOUND);
        },

        _selectCurrentGraph: function() {
            var currentGraph = this._getCurrentGraph();

            if (currentGraph) {
                // Select graph text and set focus to textarea
                this.$textarea.prop('selectionStart', currentGraph.start);
                this.$textarea.prop('selectionEnd', currentGraph.end);
                this.$textarea.focus();
            } else {
                alert(this.NOT_FOUND);
            }
        },

        _receiveMessagesInit: function () {
            var self = this;
            if (! this._receiveInitialized) {
                this._receiveInitialized = true;
                unsafeWin.addEventListener('message', function(event) {
                    self._receiveChildPostMessageEvents(event);
                }, false);
            }
        },

        _openInCloudWatchConsole: function(metricWidgetStr) {
            this._receiveMessagesInit();
            this._metricWidgetStr = metricWidgetStr;
            this._cwConsoleChildWindow = unsafeWin.open(this.CW_CONSOLE);
        },

        _receiveChildPostMessageEvents: function(event) {
            var encodedGraph;
            // Validate origin - only accept messages from CloudWatch console
            var cwConsoleOrigin = 'https://console.aws.amazon.com';
            if (event && event.origin === cwConsoleOrigin && event.data === 'CloudWatchDashboardsReady' && this._cwConsoleChildWindow && this._metricWidgetStr) {
                // % chars in URL need special handling to get through console's GWT URL handling, quadruple encoded!
                encodedGraph = encodeURIComponent(this._metricWidgetStr.replace(/[%]/g, '%252525').replace(/[#]/g, '%252523'));
                this._cwConsoleChildWindow.postMessage(JSON.stringify({
                    action: 'DeepLink',
                    deepLink: '#metricsV2:graph=' + encodedGraph
                }), cwConsoleOrigin);

                // Forget graph, so that a refresh of the child page does not trigger continuous deep link posting events
                this._metricWidgetStr = null;
            }
        },

        _lastIndexOf: function(str, regex) {
            var lastIndexOf = -1,
              nextStop = 0,
              result;

            while((result = regex.exec(str)) != null) {
                lastIndexOf = result.index;
                regex.lastIndex = ++nextStop;
            }
            return lastIndexOf;
        }
    };

    win.RefreshGraphs = {
        DELAY_IN_MS: 500,   // Refresh 2 every second

        refreshSlowly: function() {
            var images = unsafeWin.jQuery('img[src*="Action=GetGraph"],img[src*="/cw/getMetricWidgetImage"]').sortByDistanceFromView();
            for (var i = 0; i < images.length; i++) {
                this.refreshAfter(images[i], i * this.DELAY_IN_MS);
            }
        },

        refreshAfter: function(image, millis) {
            setTimeout(function() {
                console.log(image);
                unsafeWin.MPW.refreshImage(image);
            }, millis);
        }
    };

    win.Tinify = {
        initialize: function() {
            function checkForCtrlY(event) {
                if (event.key === 'y' && event.ctrlKey) {
                    win.Tinify.tiny();
                }
            }
            document.addEventListener('keydown', checkForCtrlY, false);
        },

        tiny: function() {
            const url = win.location.href;
            const pageTitle = (win.document.title || '').substring(0, 20);  // Max 20 chars
            const tinyCommandUrl = `${TinyUrlRoot}/submit/url?comment=${encodeURIComponent(pageTitle)}&name=${encodeURIComponent(url)}`;

            GMUtils.getTinyLinkForUrl(tinyCommandUrl, function(tinyUrl) {
                setTimeout(() => { GM_setClipboard(tinyUrl); }, 0);      // call clipboard asynchronously, more reliable

                GM_notification({
                    title: 'iGraph Helper',
                    text: 'Tiny URL copied to clipboard: ' + tinyUrl,
                    timeout: 2000
                });
            });
        }
    };

    win.AccountName = {
        accountIdNamePairs: {},
        getAccountName: function (accountId) {
            return this.accountIdNamePairs[accountId];
        },

        accountIdToName: async function (accountId) {
            const trimmedAccountId = accountId.trim();
            if (/^\d{12}$/.test(trimmedAccountId)) {
                let name = await this.getAccountNameFromIsengard(trimmedAccountId);
                if (!name) {
                    name = await this.getAccountNameFromConduit(trimmedAccountId);
                }
                this.accountIdNamePairs[trimmedAccountId] = name;
                return name;
            }
        },
  
        getAccountNameFromIsengard: async function(accountId) {
            const response = await GM.xmlHttpRequest({
                method: 'POST',
                url: 'https://isengard-service.amazon.com',
                headers: {
                    'Content-Encoding': 'amz-1.0',
                    'X-Amz-Target': 'com.amazon.isengard.coral.IsengardService.GetAWSAccount',
                    'Content-Type': 'application/json; charset=UTF-8'
                },
                xhrFields: {
                    withCredentials : true
                },
                data: `{"AWSAccountID": "${accountId}"}`
            });

            if (response && response.responseText) {
                const accountInfo = JSON.parse(response.responseText);
                if (accountInfo && accountInfo.AWSAccount) {
                    let name = accountInfo.AWSAccount.Name;

                    // Name field may not be set - take the email address before @ instead
                    if (!name || /^\s*$/.test(name)) {
                        name = accountInfo.AWSAccount.Email.split("@")[0];
                    }
                    
                    return name;
                }
            }
        },

        getAccountNameFromConduit: async function(accountId) {
            const response = await GM.xmlHttpRequest({
                method: 'GET',
                url: `https://conduit.security.a2z.com/api/accounts/partition/aws/accountId/${accountId}`,
                xhrFields : {
                    withCredentials : true
                }
            });

            if (response && response.responseText && !/EntityNotFoundException/.test(response.responseText)) {
                const accountInfo = JSON.parse(response.responseText);
                if (accountInfo && accountInfo.account) {
                    return accountInfo.account.name;
                }
            }
        }
    };

    win.WikiSnapshot = win.WikiSnapshot || {
        SPINNER_IMG: 'data:image/gif;base64,R0lGODlhEAAQALMAAN7e3s7Ozrm5uampqZiYmIiIiHd3d2dnZ1ZWVkZGRjExMQAAAP///wAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQFBwAMACwAAAAAEAAQAAAEZ5BJBqgxM8+QAlBKoGXB0oFAqgUisRDKklYZohABaBwqRQOHhULgmcwqswFCRMoQDrsBLdMrHK6D0fEoKEwlPXAhwVsRxQkCgIBjSQFnRlGAEAzUuJHEoL4DAmpaXmsEFAJfIwICehEAIfkEBQcADAAsAAAAAA8AEAAABFmQycnKDHQemSRIQ8YoyMct2ARMQ6IQyzYZ3ZcUhrKsVJ6kDIFAJDnwiIOCckhkAAgGQ4HZvBCqrIOBeCQcQowBYJUKHBkBQ0AYPE8swSGASrkGxWhsADiJAAAh+QQFBwAMACwAAAAAEAAQAAAEWpDJyUiRgFKTUeqCxmTckTAGE06ZpDDeCgAhUCBCgBwWIhULReuSygACBEVwQBFcKANFoSWwEAKi1mhQeIq+EiZYUyBkNdyQYDU6j6YBrFY0qMnnUEl8rJl9IwAh+QQFBwAMACwAAAAAEAAPAAAEVpDJKQmgGBRpEMdSgGzGwWygNDBCKaHBtAFHMRCHwgw6NQIxiSCRSsUMAcBlwEwZFNCDgEANUnILBUKpFBi5IcIKZGURYoGy5BKaDMDFUJILLM7pykkEACH5BAUHAAwALAAAAAAQAA8AAARbkMnJxqBYElnMDBlwbEzBGAqYMUdQmEp2gaZwJYzA4FpBBABJELHTfUgTQIIQZAQEAmCmgKgWAhYjxhM7UFRJxTWgAkAxgcUi0XwKmxPDIsWAwym2O0B/p/QzEQAh+QQFBwAMACwAAAAAEAAQAAAEWpDJyYSgWA5JCs9SsRUEQyRg5UkBKgGSMMBEKRSIlBzTJcCTwEGBCGAuFCEFEAAAMQPD4UBgBpqZE8qwzCCqjKczuWHwJmMKYtFNDRbcFCaxQKaMFUVZHnxGAAAh+QQFBwAMACwAAAAAEAAQAAAEVZDJyQK9U0wyAWaENUyHh1nAwCEjFWjMIAQBYUjHLb3WVTAGkwTQ6xhaH0zBoPMIKQPEAfFLSo7WjkABtBIKCUWgoEAkFYpfFYZB94oft4X9OSSclAgAIfkEBQcADAAsAgAAAA4AEAAABFeQyRmmlZUJIcfVgMYJxQeMAlBaoVYBQxkYBAPcV4isUmsVnM9FQCgUBr6hYVkTMoA2TI+SUPAkCusAkWgdJoWFIZGo1TKMwEIRqAIQbAtBEYwmPq+lMAIAIfkEBQcADAAsAAAAABAAEAAABFCQyckAoBiHIEWWF7NJxAeKHMGZVjdUhYkRsUyVNpXmUlD8r07Cc8scFgsc6MBQKhYISeJViBISMQCB2EREFaAVJQHwMpghioeTiJZZkt8nAgAh+QQFBwAMACwAAAEAEAAOAAAETZBJBqoFYWp9xf6TAIAc5jHDQGoCca6SkEmFkigFmA7CsSyKA4hAfBEYs8kgiQxtDAhNgmFgIIQBQrXnZBypB48KpIgehIUoSH2WGJIRACH5BAUHAAwALAAAAgAQAA4AAARWkMlJGaihzkuDWkQFcELGCJ8iYGVXLAPGSQlTa4CgB4biFzjBYGAKDBCzDQVgYChMk0IhJkEoJoaAEMiYSoiMgWIgZSA0ksuhCySsNYF3odlFUwYhTQQAIfkECQcADAAsAAAAABAAEAAABFuQSSCrvUykgLtYSdcdywBQGIAwBbMoaRWsDDFYJzoRinDpEsSBhgkYAYVEAkHoGAMogMCA8Vk4itBlQLAyqC1Di9MEdCVWnzVg4DCADESryRi0OneWhADH3DARADs=',
        SNAPSHOT_IMG: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsEAAA7BAbiRa+0AAAASdEVYdFNvZnR3YXJlAEdyZWVuc2hvdF5VCAUAAAEVSURBVDhPpZOxDcIwEEUviBIqOliBJRALMAKhYwaHikSICegII7AAYgkKMkDomAH8D184B6cIeZJ1Z/v738lOIiJ62dEZNrJ8Zn8SRRH1XN6Zxo42SeIyn22auuwLOgIw8kiMcdkvoT14eB1JF6GqmrrO60hXQh6qXF/f73Yc4eFdNpwTW204GHC1VRx7QzpAR9Dei4LnoO9iRZZlaJEPjicTOj/ndDvMuAAOYw/RGEOPsnSn6Pf5IRBgAqbrK6Xq3qBBQU1lVFr3kECAmQCNLgi8jrQgP51oMbpwDnTeVJBvPl4uX1bALyBrkofWoMUZtfY1EoHEOnoPsdGoLdrI+7Lx5G045jlHfA6NP20bKqPPtAtEbw8iYxB46Q0cAAAAAElFTkSuQmCC',
        COLOR_BLIND_FRIENDY_IMG: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAAASdEVYdFNvZnR3YXJlAEdyZWVuc2hvdF5VCAUAAAEbSURBVDhPrVQxDsIwDHS6dEMVLEiwVDDxBt7CQ3hO39C3MCF1YWAgbcWOSs5xQhJRQMBJp9jx+eQ0bRURDYY/g42Gq02+hZoQZRJTu1lL9DnSHkzE1Mu1j0HUUj7TSu1RdALXNEZouq57beSEXKzOEZVSvlaWJethiNw/IwAPDZidjmQabBLgslhxDWiahvpbR0VRcA5414hmgvCYHJu9PM8jnTuFvf5hIDO2CQNUZ170fssrTyJ7tJvb1QB96Oej9X1PdV1zYRRPTIC2bSWS8UCtdTS2Ow7o46Dubk7yhxGYZRkX0MixGHmzxGTUCAwbHHH1WFFL9aKJN1OhiJhvNOOCVwy18Ig+2unBvmyfANrwo/3bb+RPPzaiO3OWgslMWGyFAAAAAElFTkSuQmCC',
        INTERACTIVE_IMG: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASCAYAAABWzo5XAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAASdEVYdFNvZnR3YXJlAEdyZWVuc2hvdF5VCAUAAABdSURBVDhPY2RgYPgPxBQDsEH/j5hCeGQCRpvTDExQNsWAlgaBfAvCIPCRIR3obEabBwzboSK4ABaDQGFPevjTK7B/MEzMINtr5IFRgwgDqhk0jDMt2GsQJiWAgQEAZyAY3kmtuyIAAAAASUVORK5CYII=',
        SNAPSHOT_HISTORY_KEY: 'iGraphHelper.snapshotHistory',
        SNAPSHOT_HISTORY_PREVIOUS_KEY: 'iGraphHelper.snapshotHistoryPrevious',
        SNAPSHOT_OUTPUT_MODE_KEY: 'iGraphHelper.snapshotOutputMode',
        SNAPSHOT_AUTOSNAP_KEY: 'iGraphHelper.snapshotAutoSnap',
        SNAPSHOT_OBEY_FIT_KEY: 'iGraphHelper.snapshotObeyFit',
        SNAPSHOT_CHIME_ROOMS_KEY: 'iGraphHelper.chimeRooms',
        SNAPSHOT_CURRENT_CHIME_ROOM_KEY: 'iGraphHelper.currentChimeRoom',
        COLOR_BLIND_FRIENDLY_PALETTE: [ // Taken from iGraph cbf palette
            '#781c81', '#55a1b2', '#ceb641', '#531b7f', '#62ac9a', '#dbab3b', '#452d8a',
            '#72b582', '#e39a36', '#3f479c', '#83ba6d', '#e78232', '#4063b0', '#97bd5d',
            '#e6642c', '#447cbf', '#abbe51', '#e14226', '#4b91c0', '#bebc48'
        ],
        MAX_HISTORY_ITEMS: 200,
        DECIMAL: 10,
        DURATION: new RegExp('^-?P'),
        PATTERN: {
            DAY: new RegExp('(\\d*)D'),
            HOUR: new RegExp('(\\d*)H'),
            MINUTE: new RegExp('(\\d*)M')
        },
        DURATIONS: {
            DAY: "D",
            HOUR: "H",
            MINUTE: "M"
        },
        MINUTES: {
            DAY: 24 * 60,
            HOUR: 60,
            MINUTE: 1
        },
        UNITS: {
            MINUTE: "MINUTE",
            HOUR: "HOUR",
            DAY: "DAY"
        },
        ORDERED_UNITS: ["MINUTE", "HOUR", "DAY"],
        MODES: { RAW: "Raw", TT: "TT", NEW_WIKI: "New Wiki", OLD_WIKI: "Old Wiki", MARKDOWN: "Markdown (SIM etc)", JIRA: "JIRA", EMAIL: "Email", CHIME_MARKDOWN: "ChimeMarkdown", CHIME: "Chime", SLACK: "Slack", QUIP2WIKI: "Quip2Wiki", },

        // Add good jQuery DOM selector defaults for Amazon pages here
        PAGE_TO_SNAPSHOT_SELECTOR_MATCHER: [
            { urlRegex: /cloudwatch[/]home.*#alpine/, selector: '#gwt-debug-dashboards', name: 'CloudWatch Alpine' },
            { urlRegex: /cloudwatch[/]home.*#contributor-insights:rules/, selector: '#gwt-debug-dashboards', name: 'CloudWatch Contributor Insights' },
            { urlRegex: /cloudwatch[/]home.*#dashboards:name/, selector: '.cwdb-dashboard-content', name: 'CloudWatch Dashboard' },
            { urlRegex: /cloudwatch[/]home.*#alarmsV2:alarm/, selector: '.graph-section-content', name: 'CloudWatch Alarm' },
            { urlRegex: /cloudwatch[/]home.*#logsV2:logs-insights/, selector: '.histogram', name: 'CloudWatch Insights' },
            { urlRegex: /cloudwatch[/]home.*#xray:service-map\/map/, selector: '.graph', name: 'X-Ray Trace Map' },
            { urlRegex: /retro.corp.amazon.com/, selector: '.main-content', name: 'Simple Retrospectives' },
            { urlRegex: /rtla.amazon.com.explore.do/, selector: '#chart', name: 'RTLA' },
            { urlRegex: /w.amazon.*index.php/, selector: '#mainContent', name: 'Old Wiki' },
            { urlRegex: /^https:..k2[.]/, selector: '.highcharts-container', name: 'K2 graph' },
            { urlRegex: /profiler.amazon.com[/]profile/, selector: '.flame-graph svg', name: 'Amazon Profiler' }
        ],
        K2_ENDPOINT: {
            'aws': 'https://k2.amazon.com',
            'aws-cn': 'https://k2.bjs.aws-border.com',
            'aws-us-gov': 'https://k2.amazon.com',
            'aws-iso': 'https://k2.us-iso-east-1.c2s.ic.gov',
            'aws-isob': 'https://k2.lck.aws-border.com',
            'aws-eusc': 'https://k2service.eusc-de-east-1.amazonaws.eu'
        },

        // All public regions before HKG do not have to be "opted-in" to, see https://w.amazon.com/bin/view/AWSAuth/Onboarding/OptInRegions/
        // For these regions we can use GetMetricWidgetImage API to snapshot graphs, but all other regions
        // require using the in-browser method (which can be less reliable)
        NOT_AUTH_OPT_IN_REGION: {
            "ap-northeast-1": true,
            "ap-northeast-2": true,
            "ap-northeast-3": true,
            "ap-south-1": true,
            "ap-southeast-1": true,
            "ap-southeast-2": true,
            "ca-central-1": true,
            "eu-central-1": true,
            "eu-north-1": true,
            "eu-west-1": true,
            "eu-west-2": true,
            "eu-west-3": true,
            "sa-east-1": true,
            "us-east-1": true,
            "us-east-2": true,
            "us-west-1": true,
            "us-west-2": true
        },

        STYLES: '\
            .iGraphWikiSpinner {\
                left: -1px !important;\
                position: relative !important;\
                top: 4px !important;\
                margin-right: 6px !important;\
                visibility: hidden;\
                vertical-align: unset !important;\
                padding-top: 0px !important;\
            }\
            .iGraphWikiSnapshotPopup, .iGraphWikiSnapshotMessage {\
                font-family: Arial, Helvetica, sans-serif !important;\
                font-size: 12px !important;\
                text-align: left !important;\
            }\
            .iGraphWikiSnapshotControls, .iGraphChimeRoomManagerControls {\
                position: relative !important;\
                margin-bottom: 5px !important;\
            }\
            .iGraphWikiSnapshotControls .MPWbutton,\
            .iGraphWikiSnapshotControls .iGHbutton {\
                margin-right: 10px !important;\
            }\
            .iGraphWikiSnapshotMessage {\
                position: absolute !important;\
                bottom: 20px !important;\
                left: 25px !important;\
            }\
            .iGraphWikiSnapshotImageContainer {\
                width: 400px !important;\
                height: 200px !important;\
                display: inline-block !important;\
                vertical-align: top !important;\
                margin-right: 10px !important;\
                overflow: hidden !important;\
            }\
            .iGraphWikiSnapshotImage {\
                max-width: 100% !important;\
                max-height: 100% !important;\
            }\
            .iGraphWikiSnapshotImageControls {\
                width: 305px !important;\
                height: 200px !important;\
                display: inline-block !important;\
                vertical-align: top !important;\
            }\
            .iGraphWikiSnapshotPreview {\
                border: 1px solid #999 !important;\
                margin-left: 5px !important;\
                width: 750px !important;\
                height: 250px !important;\
                vertical-align: top !important;\
                display: inline-block !important;\
                overflow: auto !important;\
            }\
            .iGraphWikiSnapshotTitle {\
                font-size: 15px !important;\
                font-weight: bold !important;\
            }\
            .iGraphWikiChimeRooms {\
                width: 98px !important;\
                padding: 0 !important;\
                font-size: 12px !important;\
                height: 20px !important;\
                margin: 0px 10px !important;\
            }\
            .iGHbutton-bar {\
                display: inline-block !important;\
                vertical-align: top !important;\
                margin: 0 0 5px 5px !important;\
            }\
            .iGHbutton-bar:after {\
                clear: both !important;\
            }\
            .iGHbutton-bar .iGHbutton-group {\
                margin-right: 0.55556rem !important;\
            }\
            .iGHbutton-bar .iGHbutton-group div {\
                overflow: hidden !important;\
            }\
            .iGHbutton-group {\
                left: 0 !important;\
                list-style: outside none none !important;\
                margin: 0 !important;\
                padding: 0 !important;\
            }\
            .iGHbutton-group:before, .iGHbutton-group:after {\
                content: " " !important;\
                display: table !important;\
            }\
            .iGHbutton-group:after {\
                clear: both !important;\
            }\
            .iGHbutton-group > li {\
                display: inline-block !important;\
                margin: 0 -2px !important;\
            }\
            .iGHbutton-group > li > iGHbutton, .iGHbutton-group > li .iGHbutton {\
                border-color: rgba(255, 255, 255, 0.5) !important;\
                border-left: 1px solid rgba(255, 255, 255, 0.5) !important;\
            }\
            .iGHbutton-group > li:first-child iGHbutton, .iGHbutton-group > li:first-child .iGHbutton {\
                border-left: 0 none !important;\
            }\
            .iGHbutton-group.iGHround > * {\
                display: inline-block !important;\
                margin: 0 -2px !important;\
            }\
            .iGHbutton-group.iGHround > * > iGHbutton, .iGHbutton-group.iGHround > * .iGHbutton {\
                border-color: rgba(255, 255, 255, 0.5) !important;\
                border-left: 1px solid rgba(255, 255, 255, 0.5) !important;\
            }\
            .iGHbutton-group.iGHround > *:first-child iGHbutton, .iGHbutton-group.iGHround > *:first-child .iGHbutton {\
                border-left: 0 none !important;\
            }\
            .iGHbutton-group.iGHround > *, .iGHbutton-group.iGHround > * > a, .iGHbutton-group.iGHround > * > iGHbutton, .iGHbutton-group.iGHround > * > .iGHbutton {\
                border-radius: 0 !important;\
            }\
            .iGHbutton-group.iGHround > *:first-child, .iGHbutton-group.iGHround > *:first-child > a, .iGHbutton-group.iGHround > *:first-child > iGHbutton, .iGHbutton-group.iGHround > *:first-child > .iGHbutton {\
                border-bottom-left-radius: 1000px !important;\
                border-top-left-radius: 1000px !important;\
            }\
            .iGHbutton-group.iGHround > *:last-child, .iGHbutton-group.iGHround > *:last-child > a, .iGHbutton-group.iGHround > *:last-child > iGHbutton, .iGHbutton-group.iGHround > *:last-child > .iGHbutton {\
                border-bottom-right-radius: 1000px !important;\
                border-top-right-radius: 1000px !important;\
            }\
            .iGHbutton-group.iGHround.stack > * {\
                display: block !important;\
                margin: 0 !important;\
            }\
            .iGHbuttonFlat {\
                background-color: #008cba !important;\
                border-color: #007095 !important;\
                border-radius: 0 !important;\
                border-style: solid !important;\
                border-width: 1px !important;\
                color: #ffffff !important;\
                cursor: pointer !important;\
                display: inline-block !important;\
                font-family: Lucida Sans Unicode,Lucida Grande,Verdana,Arial,sans-serif !important;\
                font-size: 0.88889rem !important;\
                font-weight: normal !important;\
                line-height: normal !important;\
                padding: 0.5rem 1rem !important;\
                position: relative !important;\
                text-align: center !important;\
                text-decoration: none !important;\
                transition: background-color 300ms ease-out 0s !important;\
            }\
            .iGHbuttonFlat:hover, .iGHbuttonFlat:focus {\
                background-color: #007095 !important;\
                text-decoration: none !important;\
            }\
            .iGHbuttonFlat:hover, .iGHbuttonFlat:focus {\
                color: #ffffff !important;\
            }\
            .iGHbuttonFlat.iGHsecondary {\
                background-color: #e7e7e7 !important;\
                border-color: #b9b9b9 !important;\
                color: #333333 !important;\
            }\
            .iGHbuttonFlat.iGHsecondary:hover {\
                background-color: #dcdcdc !important;\
            }\
            .iGHbuttonFlat.iGHsecondary.iGHselected {\
                background-color: #b9b9b9 !important;\
            }\
            iGHbuttonFlat.iGHsmall, .iGHbuttonFlat.iGHsmall {\
                font-size: 11px !important;\
                padding: 2px 15px !important;\
            }\
            .iGraphChimeManagerTextbox {\
                width: 220px !important !important;\
                height: 20px !important !important;\
                margin-right: 10px; !important;\
                padding: 0px !important;\
                border: 1px solid #ccc !important;\
                border-radius: 4px !important;\
                display: inline-block !important;\
                font-size: 12px !important;\
            }\
            .iGraphChimeRoomContainer {\
                margin: 15px !important;\
                width: 100% !important;\
                max-width: 100% !important;\
                font-weight: bold !important;\
                font-size: 12px !important;\
            }\
            .iGraphChimeRoomContainer > tbody > tr > td{\
                border: 0px !important;\
            }\
            .iGraphWebhookManagerPageTitle {\
                font-size: 15px !important;\
                font-weight: bold !important;\
                margin: 0px 0px 10px 10px !important;\
                display: inline-block !important;\
            }\
            #iGraphWebhookManager, #iGraphAddChimeRoomButton, #iGraphWebhookPageBackButton {\
                margin-top: -1px !important;\
            }\
        ',
        callbackFunction: 'WikiSnapshot.snapshotDisplay',
        snapshotHistory: [],
        snapshotHistoryPrevious: [],
        chimeRooms: {},
        outputMode: null,
        stylesAdded: false,
        autoSnap: true,
        snapWithData: false,
        takingBulkSnap: false,
        noOfSnapshotsToBeCopied: 0,

        initialize: function() {
            WebLabTimes.waitFor(function () {
                return unsafeWin.MPW;
            }, WikiSnapshot.interceptGraphHover);
            this.injected = GMUtils.injectFunctionsIntoPage();
            if (this.injected) {
                this.callbackFunction = 'iGraphHelperGM.snapshotDisplay';
            }
            this.loadChimeRoomDefinitions();
            this.decorateChimeRoomLinks();
            OCLSettingsManager.setOCLConfigInitialValue();

            this.getHistory();

            this.outputMode = GMUtils.getValue(this.SNAPSHOT_OUTPUT_MODE_KEY) || this.MODES.RAW;
        },

        decorateChimeRoomLinks: function() {
            const chimeRoomsHeader = $('.iGraphHelperChimeRooms');
            const chimeRoomsDoneAlready = $('.iGHsnapshotSaveChimeRooms');
            const self = this;

            if ((chimeRoomsHeader.length > 0) && (chimeRoomsDoneAlready.length === 0)) {
                this.addStyles();
                chimeRoomsHeader.prepend('<div>' +
                  '<input type="submit" value="Save Slack channels/Chime rooms to iGraph Helper" class="iGHsnapshotSaveChimeRooms" style="background-color: orange;"><br><br>' +
                  '<input type="submit" value="Clear All Channels/Rooms from iGraph Helper ..." class="iGHsnapshotClearChimeRooms" style="color: white; background-color: red;">' +
                  '</div><br>');
                $('.iGHsnapshotSaveChimeRooms').on('click', function() {
                    $('.iGraphHelperChimeRooms a').each(function () {
                        var name = $.trim($(this).text()),
                          url = $.trim($(this).attr('href'));

                        self.chimeRooms[name] = { url: url };
                    });
                    self.saveChimeRoomDefinitions();
                    alert('Slack channel/Chime room webhook saved to iGraph Helper');
                });
                $('.iGHsnapshotClearChimeRooms').on('click', function() {
                    if (confirm('Are you sure you want to clear all stored Slack/Chime webhooks in iGraph Helper?')) {
                        self.chimeRooms = {};
                        self.saveChimeRoomDefinitions();
                    }
                });
            }
        },

        addStyles: function() {
            if (!this.stylesAdded) {
                addStyle(this.STYLES);
                this.stylesAdded = true;
            }
        },

        storeHistory: function() {
            GMUtils.setValue(this.SNAPSHOT_HISTORY_KEY, JSON.stringify(this.snapshotHistory));
            GMUtils.setValue(this.SNAPSHOT_HISTORY_PREVIOUS_KEY, JSON.stringify(this.snapshotHistoryPrevious));
        },

        getHistory: function() {
            var storedHistory = GMUtils.getValue(this.SNAPSHOT_HISTORY_KEY),
              storedHistoryPrevious = GMUtils.getValue(this.SNAPSHOT_HISTORY_PREVIOUS_KEY);

            if (storedHistory) {
                this.snapshotHistory = JSON.parse(storedHistory);
            }
            if (storedHistoryPrevious) {
                this.snapshotHistoryPrevious = JSON.parse(storedHistoryPrevious);
            }
        },

        loadChimeRoomDefinitions: function() {
            var chimeRooms = GMUtils.getValue(this.SNAPSHOT_CHIME_ROOMS_KEY);

            this.currentChimeRoomName = GMUtils.getValue(this.SNAPSHOT_CURRENT_CHIME_ROOM_KEY);
            if (chimeRooms) {
                var rooms = JSON.parse(chimeRooms);
                if (typeof rooms === 'object') {
                    this.chimeRooms = rooms;
                }
            }
        },

        saveChimeRoomDefinitions: function() {
            GMUtils.setValue(this.SNAPSHOT_CHIME_ROOMS_KEY, JSON.stringify(this.chimeRooms));
            GMUtils.setValue(this.SNAPSHOT_CURRENT_CHIME_ROOM_KEY, this.currentChimeRoomName);
        },

        interceptGraphHover: function () {
            WikiSnapshot.MPW = unsafeWin.MPW;
            $('#iGraphHoverBorderTop').append('<div id="iGraphColorBlindFriendlyIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="iGraphHelper: Color Blind Friendly..." style="background: url(' + WikiSnapshot.COLOR_BLIND_FRIENDY_IMG + ') no-repeat scroll center center transparent;"></div>');
            $('#iGraphHoverBorderTop').append('<div id="iGraphSnapshotIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="iGraphHelper: Snapshot..." style="background: url(' + WikiSnapshot.SNAPSHOT_IMG + ') no-repeat scroll center center transparent;"></div>');
            $('#iGraphHoverBorderTop').append('<div id="iGraphInteractiveIcon" class="iGraphHelperIcons iGraphHelperTopIcons" title="iGraphHelper: Go Interactive..." style="background: url(' + WikiSnapshot.INTERACTIVE_IMG + ') no-repeat scroll center center transparent;"></div>');
            $('#iGraphHoverBorderTop').append('<div id="iGraphCloudWatchApplicationLogsIcon" class="iGraphHelperIcons iGraphHelperTopIcons OCLIcons" title="iGraphHelper: Go to Cloudwatch application logs for this graph" style="background: url(' + OCLLinksManager.CLOUDWATCH_APPLICATION_LOG_IMG + ') no-repeat scroll center transparent;"></div>');
            $('#iGraphHoverBorderTop').append('<div id="iGraphCloudWatchServiceLogsIcon" class="iGraphHelperIcons iGraphHelperTopIcons OCLIcons" title="iGraphHelper: Go to Cloudwatch service logs for this graph" style="background: url(' + OCLLinksManager.CLOUDWATCH_SERVICE_LOG_IMG + ') no-repeat scroll center transparent;"></div>');
            document.getElementById('iGraphColorBlindFriendlyIcon').addEventListener('click', function () {
                return WikiSnapshot.displayColorBlindFriendly();
            });
            document.getElementById('iGraphSnapshotIcon').addEventListener('click', function () {
                return WikiSnapshot.displaySnapshotPopup();
            });
            document.getElementById('iGraphInteractiveIcon').addEventListener('click', function () {
                return WikiSnapshot.goInteractive();
            });
            document.getElementById('iGraphCloudWatchServiceLogsIcon').addEventListener('click', function () {
                WikiSnapshot.goToCloudWatchConsole(OCLLinksManager.SERVICE_LOG_KEY);
            });
            document.getElementById('iGraphCloudWatchApplicationLogsIcon').addEventListener('click', function () {
                WikiSnapshot.goToCloudWatchConsole(OCLLinksManager.APPLICATION_LOG_KEY);
            });
            WikiSnapshot.addOCLIconsMouseOverEventListener();
        },

        addOCLIconsMouseOverEventListener: function() {
            for (let i = 0; i < document.images.length; i++) {
                var image = document.images[i];
                var searchString = this.MPW.getGraphArgs(image, true);
                if (searchString != null) {
                    image.addEventListener("mouseover", function() { WikiSnapshot.setOCLIconsVisibility();}, false);
                }
            }
        },

        setOCLIconsVisibility: function() {
            if (this.MPW.hoveredImage) {
                var graphArgs = this.MPW.getGraphArgs(this.MPW.hoveredImage);
                OCLLinksManager.setOCLIconsVisibility(graphArgs);
            }
        },

        goToCloudWatchConsole: function(logType) {
            if (this.MPW.hoveredImage) {
                var graphArgs = this.MPW.getGraphArgs(this.MPW.hoveredImage);
                OCLLinksManager.goToCloudWatchConsole(logType, graphArgs);
            }
        },

        goInteractive: function() {
            if (this.MPW.hoveredImage) {
                var graphArgs = this.MPW.getGraphArgs(this.MPW.hoveredImage);
                InteractiveWikiGraphs.displayInteractiveGraph(graphArgs);
            }
            return false;
        },

        displayColorBlindFriendly: function(imgParam, graphArgsParam) {
            let img = imgParam || this.MPW.hoveredImage;
            const graphArgs = graphArgsParam || this.MPW.getGraphArgs(img);

            if (img) {
                let newImgParams;

                if (this.isCloudWatchGraph(graphArgs)) {
                    const metricWidget = this.getMetricWidgetFromUrl(graphArgs);
                    const metrics = metricWidget.metrics;
                    let visibleMetricIndex = 0;
                    if (metrics) {
                        // Go through each entry in metrics array and assign successive color from color blind friendly palette
                        metrics.forEach((metric, i) => {
                            const cbfColor = this.COLOR_BLIND_FRIENDLY_PALETTE[visibleMetricIndex % this.COLOR_BLIND_FRIENDLY_PALETTE.length];
                            const last = metric[metric.length - 1];

                            // Check for custom options/expression at end of a visible metric
                            if (typeof last === 'object') {
                                if (last.visible !== false) {
                                    if (last.expression) {
                                        // Give expressions the full color palette, "round-robin", starting from current visible metric index
                                        last.color = this.COLOR_BLIND_FRIENDLY_PALETTE.slice(visibleMetricIndex).concat(this.COLOR_BLIND_FRIENDLY_PALETTE.slice(0, visibleMetricIndex));
                                    } else {
                                        last.color = cbfColor;
                                    }
                                    visibleMetricIndex ++;
                                }
                            } else {
                                metric.push({ color: cbfColor});
                                visibleMetricIndex ++;
                            }
                        });
                    }

                    const metricWidgetStr = this.metricWidgetToJsonUrlParam(metricWidget);
                    newImgParams = this.removeQueryParams(graphArgs, ["metricWidget"]) + `&metricWidget=${metricWidgetStr}`;
                } else {
                    newImgParams = this.removeQueryParams(graphArgs, ["Palette"]);
                    newImgParams += `&Palette=cbf`;
                }

                img.src = img.src.replace(/[?].*/, '?') + newImgParams;
            }
            return false;
        },

        displaySnapshotPopup: function() {
            if (this.MPW.hoveredImage) {
                var graphArgs = this.MPW.getGraphArgs(this.MPW.hoveredImage);
                this.snapshotDisplayInPopup(Lightbox.display, graphArgs, this.getSnapshotSizeMessage());
            }
        },

        getSnapshotSizeMessage: function() {
            var msg = "The graph to be snapshotted is " + this.MPW.hoveredImage.width + " by " + this.MPW.hoveredImage.height + " pixels";
            return msg;
        },

        isCloudWatchGraph: function(graphArgs) {
            return this.isCloudWatchInteractiveGraph(graphArgs) || this.isCloudWatchBitmapGraph(graphArgs);
        },

        isCloudWatchInteractiveGraph: function(graphArgs) {
            return (graphArgs && typeof graphArgs === 'object');
        },

        isCloudWatchBitmapGraph: function(graphArgs) {
            return  /\bmetricWidget=/.test(graphArgs);
        },

        getMetricWidgetFromUrl: function(url) {
            try {
                url = (url.includes('+') && !url.includes('%20') && !url.includes(" ")) ? url.replace(/\+/g, ' ') : url;
                const metricWidgetString = this.extractQueryValue(url, 'metricWidget');
                const metricWidget = JSON.parse(metricWidgetString);
                const start = this.extractQueryValue(url, 'start');
                const end = this.extractQueryValue(url, 'end');

                // + is explicitly converted to space above, but this is invalid within the time range and timezone
                // where you actually want a + to denote timezone offset
                metricWidget.start = (start || metricWidget.start).replace(' ', '%2b');
                metricWidget.end = (end || metricWidget.end).replace(' ', '%2b');
                if (metricWidget.timezone) {
                    metricWidget.timezone = metricWidget.timezone.replace(' ', '%2b');
                }

                return metricWidget;
            } catch (e) {
                return {};
            }
        },

        metricWidgetToJsonUrlParam: function(metricWidget) {
            const metricWidgetString = JSON.stringify(metricWidget).replace(/[%]7C/g, '|');

            // Need to encode = to %3D and # to %23, to get through to Metrics page in console okay
            return encodeURIComponent(metricWidgetString)
              .replace(/#/g, '%23')
              .replace(/=/g, '%3D');
        },

        setSnapshotSizeSettingFromString: function(string) {
            try {
                if(string !== null) {
                    parsedInputs = string.replace('"', '').split(",").map(input => parseInt(input))
                    if(parsedInputs.length === 2 && Number.isInteger(parsedInputs[0]) && Number.isInteger(parsedInputs[1])) {
                        WikiSnapshot.setSnapshotSizeSetting(parsedInputs[0], parsedInputs[1])
                    } else {
                        throw "Invalid string"
                    }
                }
            } catch (error) {
                alert(`Unable to set default width and height from ${string} (${error})`)
            }
        },

        setSnapshotSizeSetting: function(width, height) {
            if(width === 0 && height === 0) {
                console.log("Unsetting fixed graph size")
                GMUtils.setValue("igraph.defaults.width", null)
                GMUtils.setValue("igraph.defaults.height", null)
            } else {
                console.log(`Setting fixed graph size to ${width}, ${height}`)
                GMUtils.setValue("igraph.defaults.width", width)
                GMUtils.setValue("igraph.defaults.height", height)
            }
        },

        setSnapshotSize: function(graphArgs) {
            if(!graphArgs) return graphArgs;
            if(GMUtils.getValue('iGraphHelper.snapshotObeyFit') == "false") {
                // graphArgs can either be a URL string or an Object
                const fixedHeight = GMUtils.getValue('igraph.defaults.height')
                const fixedWidth = GMUtils.getValue('igraph.defaults.width')

                if (typeof graphArgs === 'string' || graphArgs instanceof String) {
                    if(fixedHeight != null && fixedWidth != null && unsafeWindow.iGraphHelper && unsafeWindow.iGraphHelper.IGH) { // If the user has not set the fixed size setting we will skip updating the url and fall back to igraph general settings
                        graphArgs = unsafeWindow.iGraphHelper.IGH.util.removeQueryParams(graphArgs, ["WidthInPixels", "HeightInPixels"]) + `&WidthInPixels=${fixedWidth}&HeightInPixels=${fixedHeight}`;
                    }
                } else {
                    // For CW we can't fall back to igraph so fall back to a sane default
                    graphArgs.height = fixedHeight || 250
                    graphArgs.width = fixedWidth || 500
                }
            }
            return graphArgs
        },

        snapshotDomElement: function() {
            let url = window.location.href;
            let match = WikiSnapshot.PAGE_TO_SNAPSHOT_SELECTOR_MATCHER.find(function(matcher) {
                return matcher.urlRegex.test(url)
            }) || { selector: '', name: 'current page' };

            let selector = prompt(`Snapshot a DOM element on the page. This is an experimental feature that may or may not work, depending on the content in the page.\n\nPlease enter a jQuery selector for the element that should be snapshotted on ${match.name}.`, match.selector);
            if (selector) {
                WikiSnapshot.snapshotDisplayInPopup(Lightbox.display, null, 'Snapshot jQuery selector: ' + selector, false, selector);
            }
        },

        snapshotHtmlNode: function(selector, deepLinkUrl, isRetry) {
            let self = this;
            this.setSpinnerVisibility(true);
            this.displayMessage('Snapshotting ...');
            let $htmlNode = jQuery(selector);
            let $iframe = jQuery('iframe');
            let options = {};

            // Also look for the selector in the iframes (only for string selectors)
            if (typeof selector === 'string') {
                try {
                    if ($iframe.length > 0) {
                        for (let i = 0; i < $iframe.length; i++) {
                            try {
                                let searchNode = jQuery($iframe[i]).contents().find(selector);
                                if (searchNode.length > 0) {
                                    $htmlNode = searchNode;
                                }
                            } catch(error) {
                                console.log(`Unable to iterate frame ${error}`);
                            }
                        }
                    }
                } catch(error) {
                    console.log(`Unable to iterate iframes: ${error}`);
                }
            }

            if ($htmlNode.length < 1) {
                self.setSpinnerVisibility(false);
                this.displayMessage(`Unable to locate selector: ${selector}`);
                return;
            }

            if ((jQuery('.cwdb-dark').length != 0) && (selector === '.cwdb-standalone-graph-container')) {
                options.bgcolor = '#2a2e33'
            }
            // Convert HTML to base64 PNG image
            GMUtils.domToImage().toPng($htmlNode[0], options)
              .then(dataUrl => {
                  this.uploadImage(dataUrl, deepLinkUrl);
              })
              .catch(function(error) {
                  console.error(error);
                  if (isRetry) {
                      // We were doing a retry, time to give up
                      self.setSpinnerVisibility(false);
                      alert('Unexpected error converting graph to image');
                  } else {
                      // Browser can fail to render SVG sometimes, randomly. Try a single automatic retry on error
                      console.log('retrying in-browser snapshot');
                      self.snapshotHtmlNode(selector, deepLinkUrl, true);
                  }
              });
        },

        uploadImage: function(dataUrl, deepLinkUrl) {
            // Strip away URL preamble to leave just pure base64 image content
            let base64image = dataUrl.replace(/^data:.*base64,/, ''),
              portalUrl = this.portalUrl(),
              self = this;

            this.setSpinnerVisibility(true);
            this.displayMessage('Uploading image ...');

            // Save image as snapshot
            setTimeout(function() {
                GMUtils.gmXmlHttpRequest({
                    method : 'POST',
                    timeout : 45000,
                    url: portalUrl + '/snap/saveImage',
                    data: JSON.stringify({ base64image }),
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    onload: response => {
                        try {
                            let responseData = response.responseText;
                            let snapshotInfo = JSON.parse(responseData);
                            WikiSnapshot.snapshotDisplay(snapshotInfo.snapshotUrl, deepLinkUrl || win.location.href, '');
                        } catch (exc) {
                            console.error(exc);
                            self.setSpinnerVisibility(false);
                            alert('Unexpected error uploading snapshot');
                        }
                    },
                    onerror: (error) => {
                        console.error(error);
                        self.setSpinnerVisibility(false);
                        alert('Unexpected error uploading snapshot');
                    },
                    ontimeout: () => {
                        self.setSpinnerVisibility(false);
                        alert('Request timeout. Please try again after some time');
                    }
                });
            },0);
        },

        portalUrl: function() {
            return ((unsafeWin || {}).portalData || {}).portalURL || MonitorPortalRoot || window.location.origin;
        },

        fromSvg: function() {
            if (this.MPW && this.MPW.hoveredImage && this.MPW.hoveredImage.farthestViewportElement
              && this.MPW.hoveredImage.farthestViewportElement.tagName === 'svg') {
                return this.MPW.hoveredImage.farthestViewportElement;
            } else {
                const iGraphSvg = jQuery('#monitor-amazon-com #chartdiv svg');
                if (iGraphSvg.length === 1) {
                    return iGraphSvg[0];
                }
            }
            return undefined;
        },

        snapshotGraphUrl: function(graphArgs, idSelector = undefined) {
            try {
                if (graphArgs && typeof graphArgs === 'object') {
                    graphArgs = JSON.parse(JSON.stringify(graphArgs));
                }
                var url = this.portalUrl(),
                  metricWidget;
                let deepLinkUrl = window.location.href;
                const svg = this.fromSvg();

                graphArgs = this.setSnapshotSize(graphArgs)

                if (svg) {
                    return this.snapshotHtmlNode(svg, deepLinkUrl);
                } else  if (this.isCloudWatchBitmapGraph(graphArgs)) {
                    metricWidget = this.getMetricWidgetFromUrl(graphArgs);
                    if (metricWidget.start && metricWidget.end) {
                        if (this.isDuration(metricWidget.start)) {
                            var startMins = this.getDurationInMinutes(metricWidget.start),
                              endMins   = this.getDurationInMinutes(metricWidget.end),
                              now = new Date();
                            metricWidget.start = this.getFixedTimeFromDuration(now, startMins);
                            metricWidget.end = this.getFixedTimeFromDuration(now, endMins);
                        }
                        url += "/cw/snapshot?metricWidget=" + encodeURIComponent(JSON.stringify(metricWidget));
                    } else {
                        url += "/cw/snapshot?" + graphArgs;
                    }
                } else if (this.isCloudWatchInteractiveGraph(graphArgs)) {
                    // Only line/stack graphs in non Opt-In regions should be snapshotted using bitmap API
                    const region = graphArgs.region || unsafeWin.region;
                    const partition = (unsafeWin.partition && unsafeWin.partition.name) ? unsafeWin.partition.name : 'aws';
                    const isNotOptInRegion = this.NOT_AUTH_OPT_IN_REGION[region];
                    const isK2Mode = jQuery('.k2-mock').length > 0;
                    const k2Account = jQuery('.k2-mock a:first').text();
                    const graphHasMetrics = graphArgs.metrics;
                    const jsonMetrics = JSON.stringify(graphArgs.metrics);
                    const hasAnomalyBand = /ANOMALY_DETECTION/.test(jsonMetrics);
                    const hasDbPiMetrics = /DB_PERF_INSIGHTS/.test(jsonMetrics);
                    const hasLambdaCalls = /\bLAMBDA\b/.test(jsonMetrics);
                    const hasAccountLabelProp = /\${\s*PROP\s*\(\s*'AccountLabel'\s*\)\s*}/.test(jsonMetrics);
                    const isDarkMode = jQuery('.cwdb-dark').length != 0;
                    const safeToCallBitmapAPI = graphHasMetrics &&
                      !graphArgs.alpine && graphArgs.view !== 'singleValue' && !hasLambdaCalls &&
                      !graphArgs.role && isNotOptInRegion && !isK2Mode && !hasAnomalyBand && !hasDbPiMetrics && !hasAccountLabelProp;

                    if (graphArgs.annotations && graphArgs.annotations.horizontal) {
                        graphArgs.annotations.horizontal.map((annotation) => {
                            if (annotation.unitValue) {
                                delete annotation.unitValue;
                            }
                        });
                    }

                    if (graphArgs.annotations && graphArgs.annotations.vertical) {
                        const validVerticalProps = ['value', 'label', 'color', 'fill', 'visible'];
                        const cleanAnnotation = (a) => {
                            Object.keys(a).forEach(k => { if (!validVerticalProps.includes(k)) delete a[k]; });
                            if (typeof a.value === 'number') {
                                a.value = new Date(a.value).toISOString();
                            }
                            if (a.color && a.color.startsWith('var(')) {
                                a.color = a.color.replace(/.*,\s*([#\w]+)\)/, '$1');
                            }
                        };
                        graphArgs.annotations.vertical.map((annotation) => {
                            if (Array.isArray(annotation)) {
                                annotation.forEach(cleanAnnotation);
                            } else {
                                cleanAnnotation(annotation);
                            }
                        });
                    }

                    if (isK2Mode) {
                        const encodedUrl = encodeURIComponent(deepLinkUrl);
                        const k2Domain = this.K2_ENDPOINT[partition] || this.K2_ENDPOINT.aws;
                        deepLinkUrl = `${k2Domain}/workbench/scripts/${partition}/CloudWatch-Console-Justify?AccountId=${k2Account}&Partition=${partition}&Destination=${encodedUrl}&_run=1`;
                    }

                    if (safeToCallBitmapAPI) {
                        delete graphArgs.liveData;
                        if (graphArgs.annotations) {
                            delete graphArgs.annotations.alarms;
                        }
                        const validTopLevelProps = ['metrics', 'annotations', 'end', 'height', 'legend',
                            'period', 'region', 'stacked', 'start', 'stat', 'theme', 'timezone', 'title', 'view', 'width', 'yAxis', 'accountId'];
                        Object.keys(graphArgs).forEach(k => { if (!validTopLevelProps.includes(k)) delete graphArgs[k]; });

                        if (graphArgs.metrics) {
                            graphArgs.metrics = graphArgs.metrics.map((metric) => {
                                if (Array.isArray(metric)) {
                                    const exprObj = metric.find(item => typeof item === 'object' && item !== null && item.expression);
                                    if (exprObj) {
                                        if (exprObj.color && exprObj.color.startsWith('var(')) {
                                            exprObj.color = exprObj.color.replace(/.*,\s*([#\w]+)\)/, '$1');
                                        }
                                        return [exprObj];
                                    }
                                    const last = metric[metric.length - 1];
                                    if (typeof last === 'object' && last !== null && last.color && last.color.startsWith('var(')) {
                                        last.color = last.color.replace(/.*,\s*([#\w]+)\)/, '$1');
                                    }
                                }
                                return metric;
                            });
                        }

                        if (graphArgs.timezone === 'Local') {
                            graphArgs.timezone = (typeof IGH !== 'undefined') ? IGH.util.getLocalTimezoneOffset() : new Date().toString().match(/([+-]\d{4})/)?.[1] || '+0000';
                        } else  if (graphArgs.timezone === 'UTC') {
                            delete graphArgs.timezone;
                        }
                        graphArgs.theme = isDarkMode ? 'dark' : 'light';
                        url += "/cw/snapshot?metricWidget=" + encodeURIComponent(JSON.stringify(graphArgs)) +
                          "&width=" + graphArgs.width + "&height=" + graphArgs.height;
                    } else {
                        // Generic snapshotting, by converting DOM element in-browser to PNG

                        // Check that id exists, fallback to standalone graph container if it doesn't
                        // Also, override the id for standalone graph page as the original does not work for this kind
                        // of snapshotting
                        if (!unsafeWin.document.querySelector(idSelector) || (idSelector === '.metrics-view-graph')) {
                            idSelector = '.cwdb-standalone-graph-container';
                        }

                        console.log('snapshotting ' + idSelector);
                        return this.snapshotHtmlNode(idSelector, deepLinkUrl);
                    }
                } else if (graphArgs === null) {
                    // No graph, indicates it is a DOM node or selector
                    return this.snapshotHtmlNode(idSelector, deepLinkUrl);
                } else { // Snapshotting from iGraph
                    url += "/mws/snapshot?" + this.replaceRelativeWithFixedTime(graphArgs);
                }
                url += "&snapshotCallback=" + this.callbackFunction + (typeof idSelector != "undefined" ? "&graphId=" + idSelector : "&graphId=0");

                this.includeScript(url);
                this.setSpinnerVisibility(true);
                !this.takingBulkSnap ? this.displayMessage('Snapshotting ...') : undefined;
            } catch (e) { console.log(e); }
        },

        /* Function to fetch graph data using chart.cgi if 'snapWithData' is true,
           If snapshot is taking from wiki page than this function uses GMUtils.gmXmlHttpRequest, and from iGraph page it uses .ajax call because
           win.snapshot code get injected in iGraph page so callback function of gmXmlHttpRequest does not work because of injection, however
           this is not the case in Wiki page
         */
        getChartData: function(snapshotUrl , iGraphUrl, tinyUrl, graphId) {
            try {
                var self = this,
                  snapshotName = this.getSnapshotId(snapshotUrl),
                  snapshotName = snapshotName.substring(0,snapshotName.lastIndexOf('.')),
                  chartCgiUrl = iGraphUrl.replace(/.*[/]igraph[?]/, 'https://monitorportal.amazon.com/igraph/chart?');

                chartCgiUrl = chartCgiUrl.replace(/\bHeightInPixels=\d+\b/,"HeightInPixels=400");
                chartCgiUrl = chartCgiUrl.replace(/\bWidthInPixels=\d+\b/,"WidthInPixels=900");

                if (window.location.href.search(/monitorportal.*.amazon.com/) >= 0) {
                    self.sendRequestFromIGraph(snapshotUrl , iGraphUrl , chartCgiUrl , snapshotName, tinyUrl, graphId);
                }
                else {
                    self.sendRequestFromWiki(snapshotUrl , iGraphUrl , chartCgiUrl , snapshotName, tinyUrl, graphId);
                }
            } catch (e) { console.log(e); }
        },

        sendRequestFromWiki: function(snapshotUrl , iGraphUrl , chartCgiUrl , snapshotName, tinyUrl, graphId) {
            try {
                var self = this;
                setTimeout(function() {
                    GMUtils.gmXmlHttpRequest({
                        method : 'POST',
                        timeout : 45000,
                        url: chartCgiUrl,
                        onload: function(response){
                            var responseData = response.responseText;
                            var snapshot = self.getSnapshotObject(snapshotUrl, tinyUrl);
                            snapshot.hasSnappedData = self.uploadDataToS3(responseData, snapshotName);
                            self.takingBulkSnap ? WikiBulkSnapshot.onSnapshotComplete(snapshot, graphId) : self.addHistoryItem(snapshot);
                        }.bind(WikiSnapshot),
                        ontimeout : function(response){
                            alert("Request timeout \nPlease try again after some time");
                        }
                    });
                },0);
            } catch (e) { console.log(e); }
        },

        sendRequestFromIGraph: function(snapshotUrl , iGraphUrl , chartCgiUrl , snapshotName, tinyUrl, graphId) {
            try {
                var self = this;
                $.ajax({
                    url: chartCgiUrl,
                    success: function(responseData){
                        var snapshot = self.getSnapshotObject(snapshotUrl, tinyUrl);
                        snapshot.hasSnappedData = self.uploadDataToS3(responseData, snapshotName);
                        self.takingBulkSnap ? WikiBulkSnapshot.onSnapshotComplete(snapshot, graphId) : self.addHistoryItem(snapshot);
                    }
                });
            } catch (e) { console.log(e); }
        },

        uploadDataToS3: function(responseData, snapshotName) {
            var self = this;
            var chartJson = responseData.substring(responseData.indexOf('{'),responseData.lastIndexOf('}')+1);
            if (eval ("("+ chartJson +")").error.length > 0) {
                alert(eval ("("+ chartJson +")").error+"\n\n*** For this snapshot will be taken without data ***");
                return false;
            }
            else {
                var blob = new Blob([JSON.stringify(chartJson, null, 2)], {type : 'application/json'});
                var formData = new FormData();
                formData.append("data", blob);
                formData.append("f", snapshotName + ".json");
                GMUtils.sendFormDataToS3(formData);
                return true;
            }
        },

        snapshotDisplay: function(snapshotUrl, iGraphUrl, graphId) {
            var self = this;

            var federationUrl = null, federationComment = null;
            var iGraphUrlIsengard = this.getIsengardLinkForUrl(iGraphUrl);
            if (iGraphUrlIsengard) {
                federationUrl = iGraphUrlIsengard;
                federationComment = 'IsenLink';
            }

            var onObserve = (/\/(observe.aka.amazon|observe-gamma.aka.amazon)/.test(window.location.href));
            var urlToTinyify = onObserve ? window.location.href : iGraphUrl;

            if (!this.takingBulkSnap) { this.displayMessage('Tinyfying graph URL ...'); }
            GMUtils.getTinyLinkForUrl(TinyUrlRoot + '/submit/url?comment=snapshot&name=' + escape(urlToTinyify), function(tinyUrl) {
                if (self.snapWithData) {
                    if (!self.takingBulkSnap) { self.displayMessage('Collecting graph data ...'); }
                    self.getChartData(snapshotUrl, iGraphUrl, tinyUrl, graphId);
                }
                else if (federationUrl) {
                    if (!this.takingBulkSnap) { self.displayMessage('Tinyfying federation URL ...'); }
                    GMUtils.getTinyLinkForUrl(TinyUrlRoot + '/submit/url?comment=' + escape(federationComment) + '&name=' + escape(federationUrl), function(tinyFederationUrl) {
                        var snapshot = self.getSnapshotObject(snapshotUrl, tinyUrl, tinyFederationUrl, federationComment);
                        self.takingBulkSnap ? WikiBulkSnapshot.onSnapshotComplete(snapshot, graphId) : self.addHistoryItem(snapshot);
                    });
                } else {
                    var snapshot = self.getSnapshotObject(snapshotUrl, tinyUrl);
                    self.takingBulkSnap ? WikiBulkSnapshot.onSnapshotComplete(snapshot, graphId) : self.addHistoryItem(snapshot);
                }
            });
        },

        getSnapshotObject: function(snapshotUrl, tinyUrl, tinyFederationUrl=null, federationDescription=null) {
            return  {
                snapshotUrl: snapshotUrl,
                iGraphUrl: tinyUrl,
                federationUrl: tinyFederationUrl,
                federationDescription: federationDescription,
                timestamp: new Date().toLocaleString(),
                hasSnappedData: this.snapWithData
            }
        },

        setSpinnerVisibility: function(isVisible) {
            $('.iGraphWikiSpinner').css('visibility', isVisible ? 'visible' : 'hidden');
        },

        displayMessage: function(message, delay) {
            if (message) {
                $('.iGraphWikiSnapshotMessage').html(message).css('display', 'block').fadeIn('slow');
                if (delay) {
                    setTimeout(function() { $('.iGraphWikiSnapshotMessage').fadeOut('slow') }, delay);
                }
            }
        },

        enable: function(selector, enabled) {
            if (enabled) {
                $(selector).prop('disabled', false).css('opacity', '1').css('cursor', 'pointer');
            } else {
                $(selector).prop('disabled', true).css('opacity', '0.35').css('cursor', 'not-allowed');
            }
        },

        snapshotDisplayInPopup: function(lightboxDisplay, graphArgs, message, takingBulkSnap = false, id = null) {
            var self = this;

            lightboxDisplay(this.getPopupHtml(), 800, 385);
            this.displayMessage(message, 5000);
            this.setChimeSelectOptions();
            this.takingBulkSnap = takingBulkSnap;
            this.enable('#iGraphWikiSnapshot', true);
            this.enable('#iGraphSnapshotWithData', true);

            if (this.takingBulkSnap) {
                this.enable('#iGraphWikiSnapshot', false);
                this.enable('#iGraphSnapshotWithData', false);
                WikiBulkSnapshot.snapshotCartGraphs();
            }
            if (this.isCloudWatchGraph(graphArgs)) {
                this.enable('#iGraphSnapshotWithData', false);
            }
            $('#iGraphWikiSnapshot').on('click', function () {
                self.snapWithData = false ;
                self.snapshotGraphUrl(graphArgs, id);
            });
            $('#iGraphSnapshotWithData').on('click', function () {
                self.snapWithData = true ;
                self.snapshotGraphUrl(graphArgs, id);
            });
            $('#iGraphWikiSnapshotClear').on('click', function () {
                self.clearHistory();
            });
            $('#iGraphWikiSnapshotCopyAll').on('click', function () {
                self.noOfSnapshotsToBeCopied = self.snapshotHistory.length;
                self.copyAllHistoryToClipboard();
            });
            $('#iGraphWikiSnapshotRestoreHistory').on('click', function () {
                self.restoreHistory();
            });
            $('.iGHSnapshotOutputMode').on('click', function () {
                self.outputModeClicked(this)
            });
            $('#iGraphWikiSnapshotAuto').on('click', function () {
                self.setAutoSnap(this);
            });
            $('#iGraphWikiSnapshotObeyFit').on('click', function () {
                self.setObeyFit(this);
            });
            $('#iGraphWebhookManager').on('click', function () {
                self.showChimeWebhookManagerPage(this)
            });
            $('#iGraphWebhookPageBackButton').on('click', function() {
                self.showSnapshotControllerPage();
            });
            $('#iGraphAddChimeRoomButton').on('click', function () {
                self.addChimeRoom(this);
            });

            // Support drag and drop of image files, for snapshotting
            let popup = $('.iGraphWikiSnapshotPopup')[0];
            popup.addEventListener('dragover', e => {
                this.filesBeingDraggedOver(e);
            });
            popup.addEventListener('drop', e => {
                this.filesDropped(e);
            });

            // Enable pasting images from clipboard into the snapshot preview
            popup.addEventListener('paste', (e) => {
                const items = (e.clipboardData || e.originalEvent.clipboardData).items;
                for (let item of items) {
                    if (item.type.indexOf('image') !== -1) {
                        e.preventDefault();
                        const file = item.getAsFile();
                        const reader = new FileReader();
                        reader.onload = (loadEvent) => {
                            this.uploadImage(loadEvent.target.result);
                        };
                        reader.readAsDataURL(file);
                        break;
                    }
                }
            });

            this.updateOutputMode();
            this.initObeyFit();
            this.initAutoSnap(graphArgs, id);
        },

        filesBeingDraggedOver: function(dragOverEvent) {
            dragOverEvent.stopPropagation();
            dragOverEvent.preventDefault();
            dragOverEvent.dataTransfer.dropEffect = 'copy';
        },

        filesDropped: function(dropEvent) {
            dropEvent.stopPropagation();
            dropEvent.preventDefault();
            let files = dropEvent.dataTransfer.files; // Array of all files

            [].slice.call(files).forEach(file => {
                if (file.type.includes('image')) {
                    let reader = new FileReader();

                    reader.onload = loadEvent => {
                        this.uploadImage(loadEvent.target.result);
                    };

                    reader.readAsDataURL(file); // start reading the file data.
                }
            });
        },

        initAutoSnap: function(graphArgs, id) {
            this.autoSnap = GMUtils.getValue(this.SNAPSHOT_AUTOSNAP_KEY) != "false";
            GMUtils.setValue(this.SNAPSHOT_AUTOSNAP_KEY, this.autoSnap + '');
            $('#iGraphWikiSnapshotAuto').prop('checked', this.autoSnap);

            // Only auto-snap if autoSnap is on, not taking bulk snapshot and there is
            // a graph or DOM element to snap
            if (!this.isTakingBulkSnap && this.autoSnap && (graphArgs || id)) {
                this.snapshotGraphUrl(graphArgs, id);
            }
        },

        setAutoSnap: function(checkbox) {
            this.autoSnap = $('#iGraphWikiSnapshotAuto:checked').length != 0;
            GMUtils.setValue(this.SNAPSHOT_AUTOSNAP_KEY, this.autoSnap + '');
        },

        initObeyFit: function() {
            this.obeyFit = GMUtils.getValue(this.SNAPSHOT_OBEY_FIT_KEY) != "false";
            GMUtils.setValue(this.SNAPSHOT_OBEY_FIT_KEY, this.obeyFit + '');
            $('#iGraphWikiSnapshotObeyFit').prop('checked', this.obeyFit);
        },

        setObeyFit: function(checkbox) {
            this.obeyFit = $('#iGraphWikiSnapshotObeyFit:checked').length != 0;
            GMUtils.setValue(this.SNAPSHOT_OBEY_FIT_KEY, this.obeyFit + '');
        },

        outputModeClicked: function(button) {
            this.outputMode = $(button).attr('data-mode');
            this.updateOutputMode();
            if (this.snapshotHistory.length > 0) {
                if (this.takingBulkSnap) {
                    this.copyAllHistoryToClipboard();
                }
                else {
                    this.copyCodeToClipboard(this.getSnapshotCode(0));
                    this.displayMessage("Code for last snapshot copied to clipboard", 2000);
                }
            }
        },

        updateOutputMode: function() {
            if (this.outputMode == null) {
                this.outputMode = GMUtils.getValue(this.SNAPSHOT_OUTPUT_MODE_KEY) || this.MODES.RAW;
            }
            GMUtils.setValue(this.SNAPSHOT_OUTPUT_MODE_KEY, this.outputMode);
            $('.iGHSnapshotOutputMode').removeClass("iGHselected");
            $('.iGHSnapshotOutputMode[data-mode="' + this.outputMode + '"]').addClass("iGHselected");
            this.updateSnapshots();
        },

        showSnapshotControllerPage: function(button) {
            this.displayMessage(" ");
            $('.iGraphWikiSnapshotControls').show();
            $('.iGraphChimeRoomManagerControls').hide();
            this.updateSnapshots();
        },

        showChimeWebhookManagerPage: function(button) {
            this.displayMessage(" ");
            $('.iGraphWikiSnapshotControls').hide();
            $('.iGraphChimeRoomManagerControls').show();
            this.updateChimeRoomList();
        },

        updateChimeRoomList: function() {
            this.loadChimeRoomDefinitions();
            var self = this;
            var roomListHtml = '<table class="iGraphChimeRoomContainer" cellspacing="15">';
            var index=1;
            Object.keys(this.chimeRooms).sort().forEach(function(roomName) {
                roomListHtml += '<tr>' +
                  '<td><span>' + index++  + '.</span></td>' +
                  '<td><span>' + roomName + '</span></td>' +
                  '<td><a target="_blank" href="' + self.chimeRooms[roomName].url + '">' + roomName + '\'s Slack/Chime webhook url...</a></td>' +
                  '<td><input type="submit" value="Delete" class="iGHbutton MPWbutton iGHdeleteChimeRoom" data-code="' + roomName + '"></td>' +
                  '</tr>';
            });
            roomListHtml += '</table>';
            $('.iGraphWikiSnapshotPreview').html(roomListHtml);
            $('.iGHdeleteChimeRoom').on('click', function() {
                var room = $(this).attr('data-code');
                delete self.chimeRooms[room];
                self.saveChimeRoomDefinitions();
                self.updateChimeRoomList();
                self.setChimeSelectOptions();
                self.displayMessage("Slack/Chime webhook has been deleted.", 2000);
            });
        },

        copyCodeToClipboard: function(code) {
            GMUtils.setClipboard(code, this.outputMode == "Email" ? "html" : "text");
        },

        displayCurrent: function() {
            var index = this.snapshotHistory.length - this.current;
            if (this.current) {
                $('.iGraphWikiLink').text(index >= 0 ? this.getSnapshotCode(index) : '');
                $('.iGraphWikiSnapshotPreview').html(this.getSnapshotImagePreviewHtml(index));
            }
            $('#iGraphWikiSnapshotPrevious').val('Previous (' + index + ')');
            if (index == 0) {
                $('#iGraphWikiSnapshotPrevious').prop('disabled', true).css('opacity', '0.5');
            } else {
                $('#iGraphWikiSnapshotPrevious').prop('disabled', false).css('opacity', '1');
            }
        },

        clearHistory: function() {
            if (this.snapshotHistory.length == 0) {
                return;
            }
            this.saveCurrentHistory();
            this.snapshotHistory = [];
            this.storeHistoryAndUpdate();
        },

        addHistoryItem: function(snapshot) {
            this.saveCurrentHistory();
            this.snapshotHistory.unshift(snapshot);
            if (!this.takingBulkSnap) {
                this.copyCodeToClipboard(this.getSnapshotCode(0));
                this.displayMessage("Snapshot code copied to clipboard.", 5000);
            }
            if (this.snapshotHistory.length > this.MAX_HISTORY_ITEMS) {
                this.snapshotHistory.pop();
            }
            this.storeHistoryAndUpdate();
        },

        removeHistoryItem: function(index) {
            if (index >= this.snapshotHistory.length) {
                return;
            }
            this.saveCurrentHistory();
            this.snapshotHistory.splice(index, 1);
            this.storeHistoryAndUpdate();
        },

        restoreHistory: function() {
            if (this.snapshotHistoryPrevious.length == 0) {
                return;
            }
            this.snapshotHistory = this.snapshotHistoryPrevious.slice(0);
            this.snapshotHistoryPrevious = [];
            this.storeHistoryAndUpdate();
        },

        storeHistoryAndUpdate: function() {
            this.storeHistory();
            this.updateSnapshots();
        },

        saveCurrentHistory: function() {
            this.snapshotHistoryPrevious = this.snapshotHistory.slice(0);
        },

        copyAllHistoryToClipboard: function() {
            var self = this;
            var count = self.noOfSnapshotsToBeCopied;
            var allCode = this.snapshotHistory.slice(0, count).map(function(snapshot, i) {
                return self.getSnapshotCode(i);
            });
            if (allCode.length > 0) {
                this.copyCodeToClipboard(allCode.join('\n\n'));
                this.displayMessage(this.outputMode + " code for first " + count + " snapshot" + ((count > 1)? "s" : "") + " copied to clipboard.", 7000);
            }
            else {
                this.displayMessage("There isn't any snapshot to copy.", 4000);
            }
        },

        addChimeRoom: function() {
            var roomName = $.trim($('#iGraphChimeRoomName').val()),
              url = $.trim($('#iGraphChimeWebhookUrl').val());

            if (roomName !== "" && url !== "") {
                this.chimeRooms[roomName] = { url: url };
                this.currentChimeRoomName = roomName;
                this.setChimeSelectOptions();
                this.saveChimeRoomDefinitions();
                $('#iGraphChimeRoomName').val('');
                $('#iGraphChimeWebhookUrl').val('');
                this.updateChimeRoomList();
                this.displayMessage("Slack/Chime webhook has been added successfully.", 2000);
            }
            else {
                alert("Enter both Slack channel/Chime room and its webhook URL.");
            }
        },

        getUsername: function() {
            var wikiUser = $('.userpage').text(),
              newWikiUser = $('.avatarLink').attr('href'),
              portalUser = $('.username').text(),
              isengardRole = $('#nav-usernameMenu div').text(),
              wikiParts;

            if (wikiUser !== '') {
                wikiParts = $.trim(wikiUser).split(' ');
                return wikiParts[wikiParts.length - 1].toLowerCase();
            } else if (newWikiUser) {
                wikiParts = $.trim(newWikiUser).split('/');
                return wikiParts[wikiParts.length - 1];
            } else if (portalUser !== '') {
                return portalUser;
            } else if (isengardRole !== '') {
                return isengardRole.replace(/.*\//, '').replace(/-.*/, '');
            }

            return null;
        },

        handleSendToChimeClick: function(button, doPresent, doMarkdown) {
            var self = this,
              chimeCode = decodeURIComponent($(button).attr('data-chime')),
              slackCode = decodeURIComponent($(button).attr('data-slack')),
              selectedRoomUrl = $('.iGraphWikiChimeRooms').val(),
              bold = doMarkdown ? '**' : '',
              username = self.getUsername() || 'someone',
              message;

            if (selectedRoomUrl === '') {
                if (Object.keys(self.chimeRooms).length > 0) {
                    alert('First select a Slack channel/Chime room from the dropdown above');
                } else {
                    alert('First you must configure a Slack channel/Chime room webhook.');
                    self.showChimeWebhookManagerPage();
                }
            }

            if (selectedRoomUrl) {
                message = prompt('Enter message to accompany Slack/Chime post, emojis are allowed\n', 'Snapshot of ');

                if (message !== null) {
                    if (/hooks.slack.com.services/.test(selectedRoomUrl)) {
                        // Raw slack webhook
                        const slackMessage = {
                            text: `${username} shared a snapshot direct from iGraph Helper`,
                            blocks: [
                                {
                                    type: "section",
                                    text: {
                                        type: "mrkdwn",
                                        text: `*${username}* shared a snapshot direct from iGraph Helper\n${message}`
                                    }
                                },
                                {
                                    type: "section",
                                    text: {
                                        type: "mrkdwn",
                                        text: slackCode,
                                    }
                                }
                            ]
                        };
                        GMUtils.sendJSONtoURL(selectedRoomUrl, slackMessage);
                    } else {
                        // Chime or Chime-compatible Slack workflow
                        const content = (doMarkdown ? '/md\n' : '') +
                          (doPresent ? '@Present ' : '') +
                          (username ? bold + '(from: ' + username + ')' + bold + ' ' : '') +
                          (message === '' ? chimeCode : message + '\n' + chimeCode);
                        GMUtils.sendJSONtoURL(selectedRoomUrl, { Content: content });
                    }
                }
            }
        },

        updateSnapshots: function() {
            var self = this;
            this.getHistory();
            var history = this.snapshotHistory.map(function(snapshot, i) {
                snapshot.iGraphUrl = snapshot.iGraphUrl || '';
                return self.getSnapshotImagePreviewHtml(i, self.getSnapshotCode(i), self.getSnapshotCode(i, 'Chime'), self.getSnapshotCode(i, 'ChimeMarkdown'), self.getSnapshotCode(i, 'Slack'));
            });
            $('.iGraphWikiSnapshotPreview').html(history.join('<br>'));
            $('#iGraphWikiSnapshotClear').val('Clear History (' + history.length + ')');
            $('.iGHsnapshotCopyCode').on('click', function() {
                var code = $(this).attr('data-code');
                self.displayMessage("Snapshot code copied to clipboard", 3000);
                self.copyCodeToClipboard(decodeURIComponent(code));
            });
            $('.iGHsnapshotCopyImage').on('click', function() {
                self.copyImageToClipboard(this);
            });
            $('.iGHsnapshotDelete').on('click', function() {
                var index = parseInt($(this).attr('data-index'));
                self.removeHistoryItem(index);
            });
            $('.iGHsnapshotSendToChime').on('click', function() { self.handleSendToChimeClick(this, false, false); });
            $('.iGHsnapshotSendToChimePresent').on('click', function() { self.handleSendToChimeClick(this, true, false); });
            $('.iGHsnapshotSendToChimeMarkdown').on('click', function() { self.handleSendToChimeClick(this, false, true); });
            this.setSpinnerVisibility(false);
        },

        copyImageToClipboard: function(button) {
            function selectText(element) {
                if (document.body.createTextRange) {
                    var range = document.body.createTextRange();
                    range.moveToElementText(element);
                    range.select();
                } else if (unsafeWin.getSelection) {
                    var selection = unsafeWin.getSelection();
                    var range = document.createRange();
                    range.selectNodeContents(element);
                    selection.removeAllRanges();
                    selection.addRange(range);
                }
            }

            var container = $(button).parent().parent();
            container.attr("contenteditable", true);
            selectText($(container).find('a').get(0));
            document.execCommand('copy');
            unsafeWin.getSelection().removeAllRanges();
            container.removeAttr("contenteditable");
        },

        getSnapshotId: function(snapshotUrl) {
            return snapshotUrl.replace(/.*[=/]/, '');
        },

        getConsoleUsername: function() {
            var usernameEl = document.getElementById('nav-usernameMenu');
            return usernameEl ? usernameEl.textContent : undefined;
        },

        getFederatedPathForDeeplinking: function(pathname) {
            // deeplink.js mechanism somehow doesn't work correctly with Isengard federation
            if (pathname.endsWith('/cloudwatch/deeplink.js')) {
                pathname = pathname.replace(/\/deeplink.js$/, '/home');
            }
            return pathname;
        },

        getIsengardLinkForUrl: function(fullUrl) {
            var self = this;
            var url = new URL(fullUrl);

            if (! /Isengard/.test(self.getConsoleUsername())) {
                return undefined;
            }

            url.pathname = self.getFederatedPathForDeeplinking(url.pathname);

            try {
                var awsUserInfoRegex = /(?:(?:^|.*;\s*)aws-userInfo\s*\=\s*([^;]*).*$)|^.*$/,
                  awsUserInfo = JSON.parse(
                    decodeURIComponent(document.cookie).replace(awsUserInfoRegex, '$1')
                  ),
                  issuer = awsUserInfo.issuer;

                // 'issuer' should be Isengard site, e.g. 'https://isengard.amazon.com' ... with or without federate path. Add federate if it's not there
                if (!/federate/.test(issuer)) {
                    issuer += '/federate';
                }
                var issuerUrl = new URL(issuer);
                var accountAndRoleMatch = awsUserInfo.arn.match(/^arn:[^:]+:[^:]+:[^:]*:([^:]*):assumed-role\/(.+)\/.*$/);
                var searchParams = issuerUrl.searchParams;
                searchParams.set('account', accountAndRoleMatch[1]);
                searchParams.set('role', accountAndRoleMatch[2]);
                searchParams.set('destination', url.pathname + url.search + url.hash);
                issuerUrl.search = searchParams.toString();
                return issuerUrl.toString();

            } catch (e) {
                console.error('IsenLink:', e);
                return undefined;
            }
        },

        getSnapshotCode: function(index, outputMode) {
            const MAX_SHORT_URL_LEN = 256;
            const snapshot = this.snapshotHistory[index];
            const MODES = this.MODES;
            const sourceUrlParam = snapshot.iGraphUrl.length > MAX_SHORT_URL_LEN ? '' : '?sourceUrl=' + encodeURIComponent(snapshot.iGraphUrl);

            outputMode = outputMode || this.outputMode;
            var iGraphAnalyzerUrl = this.getAnalyzerUrl(snapshot, outputMode),
              snapshotId = this.getSnapshotId(snapshot.snapshotUrl);

            switch (outputMode) {
                case MODES.TT:
                    return (snapshot.snapshotUrl + sourceUrlParam + '#TT-EMBED (source: ' + snapshot.iGraphUrl +
                      (snapshot.federationUrl ? ' | ' + snapshot.federationDescription + ': ' + snapshot.federationUrl : '') +
                      ').' + iGraphAnalyzerUrl);
                case MODES.OLD_WIKI:
                    return '{{iGraph/snapshotTinyMP|1=' + snapshotId + '|2=' + snapshot.iGraphUrl + iGraphAnalyzerUrl +'}}';
                case MODES.NEW_WIKI:
                    if (iGraphAnalyzerUrl === "") {
                        return '{{transclude name="iGraph.Snapshot" args="f=' + snapshotId + '|tiny=' + snapshot.iGraphUrl + '" /}}';
                    } else {
                        return '{{transclude name="iGraph.Snapshot.Data" args="f=' + snapshotId + '|tiny=' + snapshot.iGraphUrl + iGraphAnalyzerUrl + '" /}}';
                    }
                case MODES.CHIME_MARKDOWN:
                case MODES.MARKDOWN:
                    return ('[![snapshot](' + snapshot.snapshotUrl + ')](' + snapshot.iGraphUrl + ')\n[source](' + snapshot.iGraphUrl + ')' +
                      (snapshot.federationUrl ? ' | [' + snapshot.federationDescription + '](' + snapshot.federationUrl + ') ' : ' ') + iGraphAnalyzerUrl);
                case MODES.JIRA:
                    return ('Snapshot ([Link to source|' + snapshot.iGraphUrl + ']' +
                      (snapshot.federationUrl ? ' \| [' + snapshot.federationDescription + '|' + snapshot.federationUrl + ']' : '') +
                      '):\n!'+ snapshot.snapshotUrl + '!');
                case MODES.CHIME:
                    return (`:camera: snapshot: ${snapshot.snapshotUrl}\n:chart_with_upwards_trend: source: ${snapshot.iGraphUrl}` +
                      (snapshot.federationUrl ? `\n:unlock: ${snapshot.federationDescription}: ${snapshot.federationUrl}` : '') +
                      iGraphAnalyzerUrl);
                case MODES.SLACK:
                    return (`:camera: <${snapshot.snapshotUrl}|snapshot image> - :chart_with_upwards_trend: <${snapshot.iGraphUrl}|source>` +
                      (snapshot.federationUrl ? ` - :unlock: <${snapshot.federationUrl}|${snapshot.federationDescription}>` : '') +
                      iGraphAnalyzerUrl);
                case MODES.EMAIL:
                    return '' +
                      '<div>' +
                      '<h3 style="margin-bottom: 0px;">Snapshot: ' + snapshot.timestamp + '</h3>' +
                      '<hr style="height: 1px;">' +
                      '<a href="' + snapshot.iGraphUrl + '">' +
                      '<img src="' + snapshot.snapshotUrl + '">' +
                      '</a>' +
                      (snapshot.federationUrl ? '<br/><a href="' + snapshot.federationUrl + '">' + snapshot.federationDescription + '</a>' : "") +
                      iGraphAnalyzerUrl +
                      '</div>';
                case MODES.QUIP2WIKI:
                    return `--wiki-macro: "macro_name=transclude, name='iGraph.Snapshot', args='f=` + snapshotId + `|tiny=` + snapshot.iGraphUrl + `'"--`;
                default:
                    return snapshot.snapshotUrl + sourceUrlParam;
            }
        },

        getAnalyzerUrl: function(snapshot, outputMode) {
            var directLink, id,
              MODES = this.MODES;
            if (snapshot.hasSnappedData) {
                id = this.getSnapshotId(snapshot.snapshotUrl);
                directLink = 'https://monitorportal.amazon.com/iGraphAnalyzer.html?snapshot=' + id;

                switch (outputMode) {
                    case MODES.TT:
                    case MODES.QUIP2WIKI:
                        return "\n(Link to iGraphAnalyzer: " + directLink + ").";
                    case MODES.OLD_WIKI:
                    case MODES.NEW_WIKI:
                        return " | data=" + id;
                    case MODES.CHIME_MARKDOWN:
                    case MODES.MARKDOWN:
                        return ' ([Open with iGraphAnalyzer](' + directLink + '))';
                    case MODES.EMAIL:
                        return '<br/><a href="' + directLink + '">'+
                          '<span style="font-size:78%;font-family:Trebuchet MS">Open with iGraphAnalyzer</span></a>';
                    case MODES.CHIME:
                        return ' - iGraph analyzer :mag: ' + directLink;
                    case MODES.SLACK:
                        return ` - :mag: <${directLink}|iGraph analyzer>`;

                    default:
                        return "";
                }
            }
            return "";
        },

        getSnapshotImagePreviewHtml: function(index, code, chimeCode, chimeMarkdownCode, slackCode) {
            var snapshot = this.snapshotHistory[index];
            return '' +
              '<div>' +
              '<div class="iGraphWikiSnapshotImageContainer">' +
              '<a href="' + snapshot.iGraphUrl + '" target="_blank">' +
              '<img src="' + snapshot.snapshotUrl + '" class="iGraphWikiSnapshotImage">' +
              '</a>' +
              '</div>' +
              '<div class="iGraphWikiSnapshotImageControls">' +
              '<span class="iGraphWikiSnapshotTitle">' + (index + 1) + '. Captured on ' + (snapshot.timestamp ? snapshot.timestamp : "unknown date") + '</span>' +
              '<br><br>' +
              '<input type="submit" value="Copy Code to Clipboard" class="iGHbutton MPWbutton primary iGHsnapshotCopyCode" data-code="' + encodeURIComponent(code) + '">' +
              '<input type="submit" value="Copy Image to Clipboard" class="iGHbutton MPWbutton iGHsnapshotCopyImage">' +
              '<br>' +
              '<input type="submit" value="Clear from History" class="iGHbutton MPWbutton iGHsnapshotDelete" data-index="' + index + '">' +
              '<br>' +
              '<input type="submit" value="To Slack/Chime ..." title="Send to Slack channel/Chime room" class="iGHbutton MPWbutton iGHsnapshotSendToChime"' +
              ' data-chime="' + encodeURIComponent(chimeCode) + '"' +
              ' data-slack="' + encodeURIComponent(slackCode) + '">' +
              '</div>' +
              '</div>';
        },

        setChimeSelectOptions: function() {
            var options = '<option value="">Slack/Chime...</option>',
              self = this;

            Object.keys(this.chimeRooms).sort().forEach(function(roomName) {
                var selected = roomName === self.currentChimeRoomName ? 'selected="selected" ' : '';

                options += '<option ' + selected + 'value="' + self.chimeRooms[roomName].url +'">' + roomName + '</option>';
            });

            $('.iGraphWikiChimeRooms').html(options);
            $('.iGraphWikiChimeRooms').on('change', function() {
                var optionSelected = $("option:selected", this);
                self.currentChimeRoomName = optionSelected.text();
                self.saveChimeRoomDefinitions();
            });
        },

        getPopupHtml: function() {
            this.addStyles();
            this.loadChimeRoomDefinitions();
            var PREVIEW = '<center><div style="margin-top: 50px;">No Snapshot History</div></center>';

            return '' +
              '<div class="iGraphWikiSnapshotPopup">' +
              '<div class="iGraphWikiSnapshotControls">' +
              this.getOutputTypeHtml() +
              '<select class="iGraphWikiChimeRooms"></select>&nbsp;' +
              '<input type="submit" value="Manage Slack/Chime" class="iGHbutton MPWbutton" id="iGraphWebhookManager"><br>' +
              '<input type="submit" value="Snapshot" class="iGHbutton MPWbutton primary" id="iGraphWikiSnapshot" title="Snapshot the underlying graph">' +
              '<img class="iGraphWikiSpinner" src="' + this.SPINNER_IMG + '"/>' +
              '<input type="submit" value="Snapshot with Data" class="iGHbutton MPWbutton primary" id="iGraphSnapshotWithData" title="Snapshot graph with data for future analysis as zoomer">' +
              '<input type="submit" value="Copy All to Clipboard" class="iGHbutton MPWbutton" id="iGraphWikiSnapshotCopyAll" title="Copy snapshot code for all graphs (present in snapshot history) to clipboard">' +
              '<input type="submit" value="Clear History" class="iGHbutton MPWbutton" id="iGraphWikiSnapshotClear" title="Clear the graphs below from the snapshot history. Reverse with Undo button.">' +
              '<input type="submit" value="Undo" class="iGHbutton MPWbutton" id="iGraphWikiSnapshotRestoreHistory" title="Undo the last change to the snapshot history below">' +
              '<input type="checkbox" id="iGraphWikiSnapshotAuto">&nbsp;' +
              '<label for="iGraphWikiSnapshotAuto" title="Tick here to snapshot automatically on launch" style="display:inline-block;">Auto-snap</label>&nbsp;' +
              '<input type="checkbox" id="iGraphWikiSnapshotObeyFit">&nbsp;' +
              '<label for="iGraphWikiSnapshotObeyFit" title="Untick to snapshot on iGraph page using width/height in General options (activates on next snapshot)" style="display:inline-block;">Obey fit</label>&nbsp;' +
              '</div>' +
              '<div class="iGraphChimeRoomManagerControls" style="display:none;">' +
              '<input type="submit" value=" <-Back " class="iGHbutton MPWbutton" id="iGraphWebhookPageBackButton">' +
              '<span class="iGraphWebhookManagerPageTitle">Manage Slack/Chime room webhooks for iGraphHelper</span><br>' +
              '<span style="margin: 5px;">Room/Channel:</span>&nbsp;' +
              '<input type="text" class="iGraphChimeManagerTextbox" id="iGraphChimeRoomName" maxlength="30">' +
              '<span style="margin: 5px;">Webhook Url:</span>&nbsp;' +
              '<input type="text" class="iGraphChimeManagerTextbox" id="iGraphChimeWebhookUrl" size="42">' +
              '<input type="submit" value="Add Slack/Chime Webhook" class="iGHbutton MPWbutton primary" id="iGraphAddChimeRoomButton" title="test">' +
              '</div>' +
              '<div class="iGraphWikiSnapshotPreview">' + PREVIEW + '</div>' +
              '</div>' +
              '<span class="iGraphWikiSnapshotMessage" style="display: none;"></span>';
        },

        getOutputTypeHtml: function() {
            var self = this,
              MODES = this.MODES,
              modesInOrder = [ MODES.RAW, MODES.TT, MODES.NEW_WIKI, MODES.MARKDOWN, MODES.JIRA, MODES.EMAIL, MODES.OLD_WIKI, MODES.QUIP2WIKI ],
              html = '<div class="iGHbutton-bar"><ul class="iGHbutton-group iGHround" title="Choose format for snapshot code: raw graph links, or pasting into TT, Wiki, SIM, as markdown or into an email">';

            modesInOrder.forEach(function(mode) {
                html += '<li><a class="iGHsmall iGHbuttonFlat iGHsecondary iGHSnapshotOutputMode" data-mode="' + mode + '" role="button" tabindex="0">' + mode + '</a></li>';
            });
            html += '</ul></div>';
            return html;
        },

        // Includes a Javascript a file, given by 'url', in the current document
        includeScript: function (url) {
            if (unsafeWin.document.body || unsafeWin.document.head) {
                var script = unsafeWin.document.createElement('script');
                script.setAttribute('type', 'text/javascript');
                script.setAttribute('src', url);
                (unsafeWin.document.body || unsafeWin.document.head).appendChild(script);
            }
        },

        pad: function(number){
            if (number < 10) {
                return "0" + number;
            }
            return number;
        },

        replaceRelativeWithFixedTime: function(graphArgs) {
            var time = this.getTimeRange(graphArgs);
            if (time.startTime && this.isDuration(time.startTime)) {
                var startMins = this.getDurationInMinutes(time.startTime),
                  endMins   = this.getDurationInMinutes(time.endTime),
                  now = new Date();
                graphArgs = this.removeQueryParams(graphArgs, ["StartTime1", "EndTime1"]);
                graphArgs += '&StartTime1=' + this.getFixedTimeFromDuration(now, startMins) +
                  '&EndTime1=' + this.getFixedTimeFromDuration(now, endMins);
            }
            return graphArgs;
        },

        getFixedTimeFromDuration: function(date, minutes){
            var offsetDate = new Date(date.getTime());
            offsetDate.setMinutes(date.getMinutes() - minutes);
            return this.getFixedTimeFromDate(offsetDate);
        },

        getFixedTimeFromDate: function(date){
            return date.getUTCFullYear() + "-" + this.pad(date.getUTCMonth() + 1) + "-" + this.pad(date.getUTCDate()) + "T" + this.pad(date.getUTCHours()) + ":" + this.pad(date.getUTCMinutes()) + ":00Z";
        },

        // get number of minutes corresponding to a duration
        getDurationInMinutes: function(duration){
            // sign is inverted sign widget is ago
            var sign = duration.match("-P") ? 1 : -1;
            var minutes = 0;
            for (var i = 0; i < this.ORDERED_UNITS.length; i++) {
                var index = this.ORDERED_UNITS[i];
                var results = this.PATTERN[index].exec(duration);
                if (results && results[1] !== "") {
                    minutes += this.MINUTES[index] * parseInt(results[1], this.DECIMAL);
                }
            }
            return sign * minutes;
        },

        extractQueryValue: function(url, param) {
            var re = new RegExp(param + "=([^&]*)");
            if (null !== url.match(re)) {
                return decodeURIComponent(RegExp.$1);
            }
            return null;
        },

        removeQueryParams: function(url, paramList) {
            var newUrl = url;
            for (var i = 0; i < paramList.length; i++) {
                var re = new RegExp(paramList[i] + "(=|%3D)[^&]*", "gi");
                newUrl = newUrl.replace(re, "");
            }
            return newUrl;
        },

        isDuration: function(time) {
            return this.DURATION.test(time);
        },

        getTimeRange: function(graphArgs) {
            return { startTime: this.extractQueryValue(graphArgs, "StartTime1"),
                endTime:   this.extractQueryValue(graphArgs, "EndTime1")};
        }
    };

    win.WikiBulkSnapshot = {

        graphArgs: [],
        snapshots: [],
        numItems: 0,
        completedSnapCount: 0,
        CART_STORAGE_KEY_OLD: 'MPWcartGraphUrl',
        CART_STORAGE_KEY: 'MPWcartState',

        initialize: function() {
            WebLabTimes.waitFor(function () {
                return unsafeWin.MPW;
            }, WikiBulkSnapshot.injectSnapshotButtonIntoCart);
        },

        injectSnapshotButtonIntoCart: function() {
            jQuery('.MPWcartButton .dummySnapButton').remove();
            jQuery('.MPWcartButton').append('<input type="submit" class="MPWbutton iGraphSnapshotButton" value="Bulk Snapshot" title="Take snapshot of all graphs. (Use Ctrl/Cmd-click for Snapshot with data)">');
            jQuery('.iGraphSnapshotButton').on('click', function(event) {
                WikiSnapshot.snapWithData = false;
                var message = "Started taking bulk snapshots...";
                if (event.ctrlKey || event.metaKey) {
                    WikiSnapshot.snapWithData = true;
                    message = "Started taking bulk snapshots with data...";
                }
                WikiSnapshot.snapshotDisplayInPopup(Lightbox.display, undefined, message, true);
            });
        },

        snapshotCartGraphs: function() {
            this.restoreState();
            var counter = 0;
            var cartGraphs = this.graphArgs;
            var timer = setInterval(function() {
                WikiSnapshot.snapshotGraphUrl(cartGraphs[counter].replace(/.*[?]/, ""), counter);
                if ( counter ==  cartGraphs.length-1) {
                    clearInterval(timer);
                }
                counter++;
            }, 100);
        },

        onSnapshotComplete: function(snapshot, uniqueId) {
            this.snapshots[uniqueId] = snapshot;
            this.completedSnapCount++;
            WikiSnapshot.displayMessage("Snapshotting graphs : " + this.completedSnapCount + " of " + this.numItems + " completed.");
            if (this.completedSnapCount == this.numItems) {
                for (var i=this.snapshots.length-1; i >= 0; i--) {
                    WikiSnapshot.addHistoryItem(this.snapshots[i]);
                }
                this.completedSnapCount = 0;
                this.snapshots = [];
                WikiSnapshot.noOfSnapshotsToBeCopied = this.numItems;
                WikiSnapshot.copyAllHistoryToClipboard();
            }
        },

        restoreState: function() {
            if (localStorage) {
                if (localStorage.getItem(this.CART_STORAGE_KEY)) {
                    this.graphArgs = JSON.parse(localStorage.getItem(this.CART_STORAGE_KEY)).graphArgs;
                }

                if (Object.keys(this.graphArgs).length === 0 && localStorage.getItem(this.CART_STORAGE_KEY_OLD)) {
                    this.graphArgs = JSON.parse(localStorage.getItem(this.CART_STORAGE_KEY_OLD));
                }
            }
            this.numItems = this.graphArgs.length;
        },

        storeState: function() {
            if (localStorage) {
                localStorage.setItem(this.CART_STORAGE_KEY, JSON.stringify({graphArgs: this.graphArgs}));
                localStorage.setItem(this.CART_STORAGE_KEY_OLD, JSON.stringify(this.graphArgs));
            }
        },
    };
};

function sendJSONtoURL(url, json) {
    setTimeout(function() {
        GM_xmlhttpRequest({
            method: 'POST',
            url: $.trim(url),
            headers: {
                'Content-Type': 'application/json'
            },
            timeout: 10000,
            data: JSON.stringify(json),
            onload: function (response) {
                if (response.status !== 200) {
                    console.log(response);
                    alert("Failed to post, please try again");
                }
            },
            onerror: function (response) {
                console.log(response);
                alert("Failed to post, please try again");
            },
            ontimeout: function (response) {
                console.log(response);
                alert("Request timeout while sending, please try again after some time");
            }
        });
    }, 0);
};

function sendFormDataToS3(formData){
    setTimeout(function() {
        GM_xmlhttpRequest({
            method : 'POST',
            url : (_ighResolvePortalOrigin(window.location.hostname) || window.location.origin) + '/snap/saveGraphData',
            timeout : 45000,
            data : formData,
            onload : function(response) {
                if (response.status == 200) {
                }
                else {
                    alert("Facing difficulty while uploading data file to S3\nPlease try again");
                    console.log("iGraphHelper:- Rsp.status: " + response.status + ", Text: " + response.responseText);
                    console.log('failed1');
                }
            },
            onerror: function(response) {
                console.log("iGraphHelper: onError from sending form data to S3");
                console.log(response);
            },
            ontimeout: function(response){
                alert("Request timeout while uploading file to S3 \nPlease try again after some time");
            }
        });
    }, 0);
};

function getTinyLinkForUrl(url, callback) {
    function tinyError(response) {
        console.log("iGraphHelper: tiny URL unavailable, using full URL instead");
        if (response) {
            console.log("iGraphHelper:" + JSON.stringify(response));
        }
        callback(url);
    }
    setTimeout(function() {
        try {
            GM_xmlhttpRequest({
                method: "GET",
                url: url,
                onload: function(response) {
                    var tinyUrl = jQuery("#url_box", jQuery(response.responseText)).html();
                    if (tinyUrl) {
                        var tinyHostname = TinyUrlRoot.replace(/^https?:\/\//, '');
                        tinyUrl = tinyUrl.replace(/\/\/tiny\//, "//" + tinyHostname + "/");
                        callback(tinyUrl);
                    } else {
                        tinyError(response);
                    }
                },
                onabort: tinyError,
                onerror: tinyError,
                ontimeout: tinyError
            });
        } catch (e) {
            tinyError();
        }
    }, 0);
}

var WebLabTimes = {
    BTN_TEMPLATE: "<a class='igraph-helper btn btn-small' style='display: block'><small>iGraph Vertical Lines</small></a>",
    initialize: function() {
        this.addControls();
    },
    addControls: function() {
        $(document).on('click', '.expand-activation-history', function(ev) {
            var colapsible_div = $(this.getAttribute('href'));

            // remove old controls
            $('.igraph-helper', colapsible_div.parent()).remove();

            // add control only if expanded
            if (colapsible_div.hasClass('in')) {
                var $html = $(WebLabTimes.BTN_TEMPLATE);
                $html.on('click', function() {
                    WebLabTimes.createLines(colapsible_div);
                });
                colapsible_div.parent().prepend($html);
            }
        });
    },
    createLines: function(parent_table) {
        var text_lines = [];
        var last_line_description = '';
        var weblab_name = $('h1').text().split(':')[0];

        $('tbody tr', parent_table).each(function() {
            var all_tds = $('td', this);
            var wtype = all_tds[0].innerText;
            // clear new lines
            var wallocation = all_tds[1].innerText.replace(/(?:\r\n|\r|\n)/g, ' ');
            // remove timezone from date, since the date is in browser timezone
            var wdate = $.trim(all_tds[2].innerText).replace(/\s[A-Z0-9]*$/, '');
            var line_date = new Date(wdate).toISOString();
            // line of igraph
            var line_description = weblab_name + ': ' + wtype + ' ' + wallocation;

            // if last line is equal current line, remove last to add again with last time
            if (line_description === last_line_description) {
                text_lines.pop();
            }
            text_lines.push([line_description, line_date].join(' @ '));
            last_line_description = line_description;
        });

        WebLabTimes.display_vlines(text_lines.join(','));
    },
    display_vlines: function(content) {
        GM_setClipboard(content);
        alert('Vertical lines copied to clipboard.');
    },
    waitFor: function(condition, callback) {
        if (condition()) {
            callback();
        } else {
            window.setTimeout(WebLabTimes.waitFor, ApolloDeployments.CHECK_DELAY_MS, condition, callback);
        }
    }
};

/*
 * Pipelines RediFork integration, for displaying iGraph links within Pipeline RediFork approval workflow steps
 */

var PipelinesRediForkIntegration = (function () {
    "use strict";

    var PipelinesRediForkIntegration = {};
    PipelinesRediForkIntegration.initialize = function() {
        if (/pipelines\.amazon\.com\/pipelines/.test(window.location.href)) {
            initializePipelinesPage();
        } else if (/pipelines\.amazon\.com\/approval_attempts/.test(window.location.href)) {
            initializeWorkflowDetailsPage();
        }

    };

    var initializePipelinesPage = function() {
        $.map(PipelineView.forCurrentPage().getWorkflows(), function(workflow) {
            var attemptDetailsLink = workflow.getAttemptDetailsLink();
            if (!attemptDetailsLink) {
                return;
            }

            var loadAttemptDetailsPageAndAddLinksForRediForkSteps = function() {
                $.get(attemptDetailsLink, function(response, status, xhr) {
                    if (status != "success") {
                        return;
                    }

                    var workflowDetails = WorkflowDetailsView.forDocument(response);

                    $.map(workflowDetails.getSteps(), function(step) {
                        if (step.getType() != "RediFork") {
                            return;
                        }

                        var iGraphLinks = calculateIGraphLinksForRediForkStep(step);

                        var pipelineViewWorkflowStep = workflow.getStepByName(step.getName());

                        pipelineViewWorkflowStep._jqStep.find("div.last-instance")
                          .append("<div style='font-size: 11px;'>"+iGraphLinks+"</div>");
                    });
                });
            };

            if (workflow.areStepsExpanded()) {
                loadAttemptDetailsPageAndAddLinksForRediForkSteps();
            } else {
                workflow._jqWorkflow.find('.expand-indicator')
                  .one('click', loadAttemptDetailsPageAndAddLinksForRediForkSteps);
            }
        });
    };

    var initializeWorkflowDetailsPage = function() {
        $.map(WorkflowDetailsView.forCurrentPage().getSteps(), function(step) {
            if (step.getType() != "RediFork") {
                return;
            }

            var iGraphLinks = calculateIGraphLinksForRediForkStep(step);

            step._jqStep.find("span.extra").append(iGraphLinks);
        });
    };

    var PipelineView = (function() {
        var clazz = {};

        clazz.forCurrentPage = function() {
            return clazz.forDocument(document);
        };

        clazz.forDocument = function(doc) {
            var details = new Object();

            details._doc = doc;
            details.getWorkflows = _getWorkflows;
            return details;
        };

        var _getWorkflows = function() {
            return $('div.workflows div.workflow', this._doc).map(function() {
                return PipelineWorkflowView.fromWorkflowElement(this);
            }).get();
        };

        return clazz;
    })();

    var PipelineWorkflowView = (function() {
        var clazz = {};

        clazz.fromWorkflowElement = function(workflowElement) {
            if (workflowElement == null) throw "workflowElement must not be null";
            return clazz.fromJQueryWorkflow($(workflowElement));
        };

        clazz.fromJQueryWorkflow = function(jqWorkflow) {
            if (jqWorkflow == null) throw "jqWorkflow must not be null";

            var workflow = new Object();
            workflow._jqWorkflow = jqWorkflow;
            workflow._steps = $.map(workflow._jqWorkflow.find("li.workflow_step").toArray(), PipelineWorkflowStepView.fromStepElement);
            workflow._stepsByName = (function() {
                var stepsByName = {};
                $.each(workflow._steps, function(idx, step) {
                    stepsByName[step.getName()] = step;
                });
                return stepsByName;
            })();
            workflow.getAttemptDetailsLink = _getAttemptDetailsLink;
            workflow.getSteps = _getSteps;
            workflow.getStepByName = _getStepByName;
            workflow.areStepsExpanded = _areStepsExpanded;
            return workflow;
        };

        var _getAttemptDetailsLink = function() {
            return this._jqWorkflow.find("span.attempt-details a").attr('href')
        };

        var _getSteps = function() {
            return this._steps.slice(0);
        };

        var _getStepByName = function(stepName) {
            return this._stepsByName[stepName];
        };

        var _areStepsExpanded = function() {
            return this._jqWorkflow.find('.workflow_steps').is(':visible');
        };

        return clazz;
    })();

    var PipelineWorkflowStepView = (function() {
        var clazz = {};

        clazz.fromStepElement = function(stepElement) {
            if (stepElement == null) throw "stepElement must not be null";
            return clazz.fromJQueryStep($(stepElement));
        };

        clazz.fromJQueryStep = function(jqStep) {
            if (jqStep == null) throw "jqStep must not be null";

            var step = new Object();
            step._jqStep = jqStep;
            step.getName = _getName;
            return step;
        };

        var _getName = function() {
            return $.trim(this._jqStep.find("h3").text())
        };

        return clazz;
    })();

    var WorkflowDetailsView = (function() {
        var clazz = {};

        clazz.forCurrentPage = function() {
            return clazz.forDocument(document);
        };

        clazz.forDocument = function(doc) {
            var details = new Object();

            details._doc = doc;
            details.getSteps = _getWorkflowSteps;
            return details;
        };

        var _getWorkflowSteps = function() {
            return $.map($('li.step', this._doc).toArray(), WorkflowDetailsViewStep.fromStepElement);
        };

        return clazz;
    })();

    var WorkflowDetailsViewStep = (function() {
        var clazz = {};

        clazz.fromStepElement = function(stepElement) {
            if (stepElement == null) throw "stepElement must not be null";
            return clazz.fromJQueryStep($(stepElement));
        };

        clazz.fromJQueryStep = function(jqStep) {
            if (jqStep == null) throw "jqStep must not be null";

            var step = new Object();
            step._jqStep = jqStep;
            step.getName = _getName;
            step.getType = _getType;
            step.getField = _getField;
            step.getStartMillis = _getStartMillis;
            step.getStatusNote = _getStatusNote;
            step.getCurrentState = _getCurrentState;
            return step;
        };

        var _getName = function() {
            return $.trim(this._jqStep.find("h3 span")[0].previousSibling.nodeValue);
        };

        var _getField = function(fieldName) {
            var fieldLabel = this._jqStep.find("ul.parameters li:contains('" + fieldName + ":') b");
            if (!fieldLabel.length) {
                throw "field: '" + fieldName + "' doesn't exist in pipeline workflow step: '" + this.getName() + "'";
            }
            return $.trim(fieldLabel[0].nextSibling.nodeValue);
        }

        var _getType = function() {
            return this.getField('Type');
        };

        var _getStartMillis = function() {
            return parseInt(this._jqStep.find("div.time span.relative-time").attr("data-millis"));
        };

        var _getStatusNote = function() {
            return $.trim(this._jqStep.find("p.note").text() || "");
        };

        var _getCurrentState = function() {
            return $.trim(this._jqStep.find("h3 span").text());
        };

        return clazz;
    })();

    var calculateIGraphLinksForRediForkStep = function(step) {
        var successThresholds = step.getField('Metric Count').split(";");

        return step.getField('Metric').split(";").map(function (metric, index, _) {
            var verticalLineAndRange = getVerticalLineAndTimeRangeFromRediForkStep(step);

            var iGraphTimeWindow = calculateTimeWindowForRediForkIGraphDisplay(verticalLineAndRange.startTime, verticalLineAndRange.endTime);

            var baseIGraphUrl = createIGraphUrlForRediForkMetric.apply(null, metric.split(","));

            var iGraphUrl = baseIGraphUrl +
              "&VerticalLine1=" + encodeURIComponent(verticalLineAndRange.verticalLine) +
              "&StartTime1=" + iGraphTimeWindow.start +
              "&EndTime1=" + iGraphTimeWindow.end;

            var iGraphLinks = "&nbsp;-&nbsp;<a target='_blank' href='"+iGraphUrl+"'>iGraph</a>";

            var iGraphRunningSumTimeWindow = calculateRunningSumTimeWindowForRediForkIGraphDisplay(verticalLineAndRange.startTime, verticalLineAndRange.endTime);

            if (!iGraphRunningSumTimeWindow) {
                return iGraphLinks;
            }

            var successThreshold = successThresholds[index];

            var iGraphRunningSumUrl = baseIGraphUrl +
              "&VerticalLine1=" + encodeURIComponent(verticalLineAndRange.verticalLine) +
              "&StartTime1=" + iGraphRunningSumTimeWindow.start +
              "&EndTime1=" + iGraphRunningSumTimeWindow.end +
              "&HorizontalLineLeft1=" + encodeURIComponent("RediFork success threshold #color=green - @ " + successThreshold)  +
              "&FunctionExpression1=" + encodeURIComponent("RUNNING_SUM(M1)") +
              "&FunctionLabel1=" + encodeURIComponent("{Running sum since start of RediFork workflow} [last: {last}]") +
              "&FunctionYAxisPreference1=left";

            return iGraphLinks + "&nbsp;(<a target='_blank' href='"+iGraphRunningSumUrl+"'>Running sum iGraph</a>)";
        }).join("");
    };

    var calculateRunningSumTimeWindowForRediForkIGraphDisplay = function(startTime, endTime) {
        if (startTime && endTime == "now") {
            var nowMillis = new Date().getTime();
            var hoursSinceStart = (nowMillis - startTime) / (1000 * 3600);
            var hoursWindowStart = hoursSinceStart;
            var minutesWindowStart = (hoursWindowStart * 60.0) | 0;
            return {
                start: "-PT" + minutesWindowStart + "M",
                end: "-PT0M"
            };
        }

        if (startTime && endTime) {
            return {
                start: millisToIgraphFixedTime(startTime),
                end: millisToIgraphFixedTime(endTime)
            };
        }

        return null;
    };

    var calculateTimeWindowForRediForkIGraphDisplay = function(startTime, endTime) {
        if (startTime && endTime == "now") {
            var nowMillis = new Date().getTime();
            var hoursSinceStart = (nowMillis - startTime) / (1000 * 3600);
            var hoursWindowStart = 1.25 * hoursSinceStart;
            var minutesWindowStart = (hoursWindowStart * 60) | 0;
            return {
                start: "-PT" + minutesWindowStart + "M",
                end: "-PT0M"
            };
        }

        if (startTime && endTime) {
            var durationMillis = endTime - startTime;
            var windowStartMillis = startTime - (durationMillis * 0.125);
            var windowEndMillis = endTime + (durationMillis * 0.125);

            return {
                start: millisToIgraphFixedTime(windowStartMillis),
                end: millisToIgraphFixedTime(windowEndMillis)
            };
        }

        return {
            start: "-PT3H",
            end: "-PT0M"
        };
    };

    var millisToIgraphFixedTime = function(epochMillis) {
        var d = new Date(epochMillis);

        var year = d.getUTCFullYear();
        var month = d.getUTCMonth() + 1;
        var day = d.getUTCDate();

        var hour = d.getUTCHours();
        var minute = d.getUTCMinutes();

        return year + "-" + pad(month, 2) + "-" + pad(day, 2) + "T" + pad(hour, 2) + ":" + pad(minute, 2) + ":00Z";
    };

    var createIGraphUrlForRediForkMetric = function(dataset, marketplace, hostGroup, host, serviceName, methodName, client, metricClass, instance, metric, stat) {
        stat = stat || "n";

        return "https://monitorportal.amazon.com/igraph?SchemaName1=Service"+
          "&DataSet1="+dataset+
          "&Marketplace1="+marketplace+
          "&HostGroup1="+hostGroup+
          "&Host1="+host+
          "&ServiceName1="+serviceName+
          "&MethodName1="+methodName+
          "&Client1="+client+
          "&MetricClass1="+metricClass+
          "&Instance1="+instance+
          "&Metric1="+metric+
          "&Stat1="+stat+
          "&Period1=FiveMinute"+
          "&DecoratePoints=true";
    };

    var getVerticalLineAndTimeRangeFromRediForkStep = function(step) {
        var startMillis = step.getStartMillis();
        var endMillis = null;

        if (!startMillis) {
            return {
                verticalLine: "",
                startTime: null,
                endTime: null
            };
        }

        var start = millisToIgraphFixedTime(startMillis);
        var end = "now";

        var statusNote = step.getStatusNote();

        var m = statusNote.match(/Total time: ((\d+) hours?, )?(\d+) minutes?/);
        if (m) {
            var hours = parseInt(m[2] || "0");
            var minutes = parseInt(m[3] || "0");

            endMillis = startMillis + (3600 * 1000 * hours) + (60 * 1000 * minutes);
            end = millisToIgraphFixedTime(endMillis);
        }

        if (statusNote.indexOf("Timeout reached") != -1) {
            var hours = parseInt(step.getField('Maximum Time'));
            endMillis = startMillis + (3600 * 1000 * hours);
            end = millisToIgraphFixedTime(endMillis);
        }

        var currentState = step.getCurrentState();

        var color = "green";
        if (currentState == "Failed") {
            color = "red";
        } else if (currentState == "In progress") {
            color = "#df8d00";
        }

        return {
            verticalLine: "(Start: " + step.getName() + " #color=" + color + " - @ " + start + ", " + currentState + " #color=" + color + " - @ " + end + ")",
            startTime: startMillis,
            endTime: endMillis ? endMillis : "now"
        };
    };

    var pad = function(n, width) {
        n = n + '';
        return n.length >= width ? n : new Array(width - n.length + 1).join(0) + n;
    };

    return PipelinesRediForkIntegration;
})();

/*
* dom-to-image plugin
*
* Copyright (c) 2015 Anatolii Saienko
*
* Licensed under MIT License (MIT)
*
* Use this URL to get the latest version
* https://code.amazon.com/packages/CloudWatchDashboardsJS/blobs/mainline/--/src/app/data/domToImage.js
*/

(function (global) {
    'use strict';

    var util = newUtil();
    var inliner = newInliner();
    var fontFaces = newFontFaces();
    var images = newImages();

    // Default impl options
    var defaultOptions = {
        // Default is to fail on error, no placeholder
        imagePlaceholder: undefined,
        // Default cache bust is false, it will use the cache
        cacheBust: false
    };

    // owning window for the node initialize
    var ownerWindow = window;

    var domtoimage = {
        toSvg: toSvg,
        toPng: toPng,
        toJpeg: toJpeg,
        toBlob: toBlob,
        toPixelData: toPixelData,
        impl: {
            fontFaces: fontFaces,
            images: images,
            util: util,
            inliner: inliner,
            options: {}
        }
    };

    if (typeof module !== 'undefined')
        module.exports = domtoimage;
    else
        global.domtoimage = domtoimage;


    /**
     * @param {Node} node - The DOM Node object to render
     * @param {Object} options - Rendering options
     * @param {Function} options.filter - Should return true if passed node should be included in the output
     *          (excluding node means excluding it's children as well). Not called on the root node.
     * @param {String} options.bgcolor - color for the background, any valid CSS color value.
     * @param {Number} options.width - width to be applied to node before rendering.
     * @param {Number} options.height - height to be applied to node before rendering.
     * @param {Object} options.style - an object whose properties to be copied to node's style before rendering.
     * @param {Number} options.quality - a Number between 0 and 1 indicating image quality (applicable to JPEG only),
                defaults to 1.0.
     * @param {String} options.imagePlaceholder - dataURL to use as a placeholder for failed images, default behaviour is to fail fast on images we can't fetch
     * @param {Boolean} options.cacheBust - set to true to cache bust by appending the time to the request url
     * @return {Promise} - A promise that is fulfilled with a SVG image data URL
     * */

    function updateWindowForNode(node) {
        if (node) ownerWindow = node.ownerDocument ? node.ownerDocument.defaultView : window;
    }

    function toSvg(node, options) {
        updateWindowForNode(node);
        options = options || {};
        copyOptions(options);
        return Promise.resolve(node)
            .then(function (node) {
                return cloneNode(node, options.filter, true);
            })
            .then(embedFonts)
            .then(inlineImages)
            .then(applyOptions)
            .then(function (clone) {
                return makeSvgDataUri(clone,
                    options.width || util.width(node),
                    options.height || util.height(node)
                );
            });

        function applyOptions(clone) {
            if (options.bgcolor) clone.style.backgroundColor = options.bgcolor;

            if (options.width) clone.style.width = options.width + 'px';
            if (options.height) clone.style.height = options.height + 'px';

            if (options.style)
                Object.keys(options.style).forEach(function (property) {
                    clone.style[property] = options.style[property];
                });

            return clone;
        }
    }

    /**
     * @param {Node} node - The DOM Node object to render
     * @param {Object} options - Rendering options, @see {@link toSvg}
     * @return {Promise} - A promise that is fulfilled with a Uint8Array containing RGBA pixel data.
     * */
    function toPixelData(node, options) {
        updateWindowForNode(node);
        return draw(node, options || {})
            .then(function (canvas) {
                return canvas.getContext('2d').getImageData(
                    0,
                    0,
                    util.width(node),
                    util.height(node)
                ).data;
            });
    }

    /**
     * @param {Node} node - The DOM Node object to render
     * @param {Object} options - Rendering options, @see {@link toSvg}
     * @return {Promise} - A promise that is fulfilled with a PNG image data URL
     * */
    function toPng(node, options) {
        updateWindowForNode(node);
        return draw(node, options || {})
            .then(function (canvas) {
                return canvas.toDataURL();
            });
    }

    /**
     * @param {Node} node - The DOM Node object to render
     * @param {Object} options - Rendering options, @see {@link toSvg}
     * @return {Promise} - A promise that is fulfilled with a JPEG image data URL
     * */
    function toJpeg(node, options) {
        updateWindowForNode(node);
        options = options || {};
        return draw(node, options)
            .then(function (canvas) {
                return canvas.toDataURL('image/jpeg', options.quality || 1.0);
            });
    }

    /**
     * @param {Node} node - The DOM Node object to render
     * @param {Object} options - Rendering options, @see {@link toSvg}
     * @return {Promise} - A promise that is fulfilled with a PNG image blob
     * */
    function toBlob(node, options) {
        updateWindowForNode(node);
        return draw(node, options || {})
            .then(util.canvasToBlob);
    }

    function copyOptions(options) {
        // Copy options to impl options for use in impl
        if(typeof(options.imagePlaceholder) === 'undefined') {
            domtoimage.impl.options.imagePlaceholder = defaultOptions.imagePlaceholder;
        } else {
            domtoimage.impl.options.imagePlaceholder = options.imagePlaceholder;
        }

        if(typeof(options.cacheBust) === 'undefined') {
            domtoimage.impl.options.cacheBust = defaultOptions.cacheBust;
        } else {
            domtoimage.impl.options.cacheBust = options.cacheBust;
        }
    }

    function draw(domNode, options) {
        return toSvg(domNode, options)
            .then(util.makeImage)
            .then(util.delay(100))
            .then(function (image) {
                var canvas = newCanvas(domNode);
                canvas.getContext('2d').drawImage(image, 0, 0);
                return canvas;
            });

        function newCanvas(domNode) {
            var canvas = document.createElement('canvas');
            canvas.width = options.width || util.width(domNode);
            canvas.height = options.height || util.height(domNode);

            if (options.bgcolor) {
                var ctx = canvas.getContext('2d');
                ctx.fillStyle = options.bgcolor;
                ctx.fillRect(0, 0, canvas.width, canvas.height);
            }

            return canvas;
        }
    }

    function cloneNode(node, filter, root) {
        if (!root && filter && !filter(node)) return Promise.resolve();

        return Promise.resolve(node)
            .then(makeNodeCopy)
            .then(function (clone) {
                return cloneChildren(node, clone, filter);
            })
            .then(function (clone) {
                return processClone(node, clone);
            });

        function makeNodeCopy(node) {
            if (node instanceof ownerWindow.HTMLCanvasElement || node instanceof HTMLCanvasElement) return util.makeImage(node.toDataURL());
            return node.cloneNode(false);
        }

        function cloneChildren(original, clone, filter) {
            var children = original.childNodes;
            if (children.length === 0) return Promise.resolve(clone);

            return cloneChildrenInOrder(clone, util.asArray(children), filter)
                .then(function () {
                    return clone;
                });

            function cloneChildrenInOrder(parent, children, filter) {
                var done = Promise.resolve();
                children.forEach(function (child) {
                    done = done
                        .then(function () {
                            return cloneNode(child, filter);
                        })
                        .then(function (childClone) {
                            if (childClone) parent.appendChild(childClone);
                        });
                });
                return done;
            }
        }

        function processClone(original, clone) {
            if (!(clone instanceof ownerWindow.Element) && !(clone instanceof Element)) return clone;

            return Promise.resolve()
                .then(cloneStyle)
                .then(clonePseudoElements)
                .then(copyUserInput)
                .then(fixSvg)
                .then(function () {
                    return clone;
                });

            function cloneStyle() {
                copyStyle(window.getComputedStyle(original), clone.style);

                function copyStyle(source, target) {
                    if (source.cssText) target.cssText = source.cssText;
                    else copyProperties(source, target);

                    function copyProperties(source, target) {
                        util.asArray(source).forEach(function (name) {
                            if (!name.includes('--')) {
                                target.setProperty(
                                    name,
                                    source.getPropertyValue(name),
                                    source.getPropertyPriority(name)
                                );
                            };
                        });
                    }
                }
            }

            function clonePseudoElements() {
                [':before', ':after'].forEach(function (element) {
                    clonePseudoElement(element);
                });

                function clonePseudoElement(element) {
                    var style = window.getComputedStyle(original, element);
                    var content = style.getPropertyValue('content');

                    if (content === '' || content === 'none') return;

                    var className = util.uid();
                    clone.className = clone.className + ' ' + className;
                    var styleElement = document.createElement('style');
                    styleElement.appendChild(formatPseudoElementStyle(className, element, style));
                    clone.appendChild(styleElement);

                    function formatPseudoElementStyle(className, element, style) {
                        var selector = '.' + className + ':' + element;
                        var cssText = style.cssText ? formatCssText(style) : formatCssProperties(style);
                        return document.createTextNode(selector + '{' + cssText + '}');

                        function formatCssText(style) {
                            var content = style.getPropertyValue('content');
                            return style.cssText + ' content: ' + content + ';';
                        }

                        function formatCssProperties(style) {

                            return util.asArray(style)
                                .map(formatProperty)
                                .join('; ') + ';';

                            function formatProperty(name) {
                                return name + ': ' +
                                    style.getPropertyValue(name) +
                                    (style.getPropertyPriority(name) ? ' !important' : '');
                            }
                        }
                    }
                }
            }

            function copyUserInput() {
                if ((original instanceof ownerWindow.HTMLTextAreaElement) || (original instanceof HTMLTextAreaElement)) clone.innerHTML = original.value;
                if ((original instanceof ownerWindow.HTMLInputElement) || (original instanceof HTMLInputElement)) clone.setAttribute('value', original.value);
            }

            function fixSvg() {
                if (!(clone instanceof ownerWindow.SVGElement) && !(clone instanceof SVGElement)) return;
                clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');

                if (!(clone instanceof ownerWindow.SVGRectElement) && !(clone instanceof SVGRectElement)) return;
                ['width', 'height'].forEach(function (attribute) {
                    var value = clone.getAttribute(attribute);
                    if (!value) return;

                    clone.style.setProperty(attribute, value);
                });
            }
        }
    }

    function embedFonts(node) {
        return fontFaces.resolveAll()
            .then(function (cssText) {
                var styleNode = document.createElement('style');
                node.appendChild(styleNode);
                styleNode.appendChild(document.createTextNode(cssText));
                return node;
            });
    }

    function inlineImages(node) {
        return images.inlineAll(node)
            .then(function () {
                return node;
            });
    }

    function makeSvgDataUri(node, width, height) {
        return Promise.resolve(node)
            .then(function (node) {
                node.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml');
                return new XMLSerializer().serializeToString(node);
            })
            .then(function (xhtml) {
                return '<foreignObject x="0" y="0" width="100%" height="100%">' + xhtml + '</foreignObject>';
            })
            .then(function (foreignObject) {
                return '<svg xmlns="http://www.w3.org/2000/svg" width="' + width + '" height="' + height + '">' +
                    foreignObject + '</svg>';
            })
            .then(function (svg) {
                return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
            });
    }

    function newUtil() {
        return {
            escape: escape,
            parseExtension: parseExtension,
            mimeType: mimeType,
            dataAsUrl: dataAsUrl,
            isDataUrl: isDataUrl,
            canvasToBlob: canvasToBlob,
            resolveUrl: resolveUrl,
            getAndEncode: getAndEncode,
            uid: uid(),
            delay: delay,
            asArray: asArray,
            escapeXhtml: escapeXhtml,
            makeImage: makeImage,
            width: width,
            height: height
        };

        function mimes() {
            /*
             * Only WOFF and EOT mime types for fonts are 'real'
             * see https://www.iana.org/assignments/media-types/media-types.xhtml
             */
            var WOFF = 'application/font-woff';
            var JPEG = 'image/jpeg';

            return {
                'woff': WOFF,
                'woff2': WOFF,
                'ttf': 'application/font-truetype',
                'eot': 'application/vnd.ms-fontobject',
                'png': 'image/png',
                'jpg': JPEG,
                'jpeg': JPEG,
                'gif': 'image/gif',
                'tiff': 'image/tiff',
                'svg': 'image/svg+xml'
            };
        }

        function parseExtension(url) {
            var match = /\.([^\.\/]*?)$/g.exec(url);
            if (match) return match[1];
            else return '';
        }

        function mimeType(url) {
            var extension = parseExtension(url).toLowerCase();
            return mimes()[extension] || '';
        }

        function isDataUrl(url) {
            return url.search(/^(data:)/) !== -1;
        }

        function toBlob(canvas) {
            return new Promise(function (resolve) {
                var binaryString = window.atob(canvas.toDataURL().split(',')[1]);
                var length = binaryString.length;
                var binaryArray = new Uint8Array(length);

                for (var i = 0; i < length; i++)
                    binaryArray[i] = binaryString.charCodeAt(i);

                resolve(new Blob([binaryArray], {
                    type: 'image/png'
                }));
            });
        }

        function canvasToBlob(canvas) {
            if (canvas.toBlob)
                return new Promise(function (resolve) {
                    canvas.toBlob(resolve);
                });

            return toBlob(canvas);
        }

        function resolveUrl(url, baseUrl) {
            var doc = document.implementation.createHTMLDocument();
            var base = doc.createElement('base');
            doc.head.appendChild(base);
            var a = doc.createElement('a');
            doc.body.appendChild(a);
            base.href = baseUrl;
            a.href = url;
            return a.href;
        }

        function uid() {
            var index = 0;

            return function () {
                return 'u' + fourRandomChars() + index++;

                function fourRandomChars() {
                    /* see https://stackoverflow.com/a/6248722/2519373 */
                    return ('0000' + (Math.random() * Math.pow(36, 4) << 0).toString(36)).slice(-4);
                }
            };
        }

        function makeImage(uri) {
            return new Promise(function (resolve, reject) {
                var image = new Image();
                image.onload = function () {
                    resolve(image);
                };
                image.onerror = reject;
                image.src = uri;
            });
        }

        function isValidUrl(string) {
            try {
                new URL(string);
                return true;
            } catch (err) {
                return false;
            }
        }

        function getAndEncode(url) {
            var TIMEOUT = 30000;
            if(domtoimage.impl.options.cacheBust) {
                // Cache bypass so we dont have CORS issues with cached images
                // Source: https://developer.mozilla.org/en/docs/Web/API/XMLHttpRequest/Using_XMLHttpRequest#Bypassing_the_cache
                url += ((/\?/).test(url) ? '&' : '?') + (new Date()).getTime();
            }
            if(!isValidUrl(url)) {
                url = location.origin + url;
            }

            return new Promise(function (resolve) {
                var request = new XMLHttpRequest();

                request.onreadystatechange = done;
                request.ontimeout = timeout;
                request.responseType = 'blob';
                request.timeout = TIMEOUT;
                request.open('GET', url, true);
                request.send();

                var placeholder;
                if(domtoimage.impl.options.imagePlaceholder) {
                    var split = domtoimage.impl.options.imagePlaceholder.split(/,/);
                    if(split && split[1]) {
                        placeholder = split[1];
                    }
                }

                function done() {
                    if (request.readyState !== 4) return;

                    if (request.status !== 200) {
                        if(placeholder) {
                            resolve(placeholder);
                        } else {
                            fail('cannot fetch resource: ' + url + ', status: ' + request.status);
                        }

                        return;
                    }

                    var encoder = new FileReader();
                    encoder.onloadend = function () {
                        var content = encoder.result.split(/,/)[1];
                        resolve(content);
                    };
                    encoder.readAsDataURL(request.response);
                }

                function timeout() {
                    if(placeholder) {
                        resolve(placeholder);
                    } else {
                        fail('timeout of ' + TIMEOUT + 'ms occured while fetching resource: ' + url);
                    }
                }

                function fail(message) {
                    console.error(message);
                    resolve('');
                }
            });
        }

        function dataAsUrl(content, type) {
            return 'data:' + type + ';base64,' + content;
        }

        function escape(string) {
            return string.replace(/([.*+?^${}()|\[\]\/\\])/g, '\\$1');
        }

        function delay(ms) {
            return function (arg) {
                return new Promise(function (resolve) {
                    setTimeout(function () {
                        resolve(arg);
                    }, ms);
                });
            };
        }

        function asArray(arrayLike) {
            var array = [];
            var length = arrayLike.length;
            for (var i = 0; i < length; i++) array.push(arrayLike[i]);
            return array;
        }

        function escapeXhtml(string) {
            return string.replace(/#/g, '%23').replace(/\n/g, '%0A');
        }

        function width(node) {
            var leftBorder = px(node, 'border-left-width');
            var rightBorder = px(node, 'border-right-width');
            return node.scrollWidth + leftBorder + rightBorder;
        }

        function height(node) {
            var topBorder = px(node, 'border-top-width');
            var bottomBorder = px(node, 'border-bottom-width');
            return node.scrollHeight + topBorder + bottomBorder;
        }

        function px(node, styleProperty) {
            var value = window.getComputedStyle(node).getPropertyValue(styleProperty);
            return parseFloat(value.replace('px', ''));
        }
    }

    function newInliner() {
        var URL_REGEX = /url\(['"]?([^'"]+?)['"]?\)/g;

        return {
            inlineAll: inlineAll,
            shouldProcess: shouldProcess,
            impl: {
                readUrls: readUrls,
                inline: inline
            }
        };

        function shouldProcess(string) {
            return string.search(URL_REGEX) !== -1;
        }

        function readUrls(string) {
            var result = [];
            var match;
            while ((match = URL_REGEX.exec(string)) !== null) {
                result.push(match[1]);
            }
            return result.filter(function (url) {
                return !util.isDataUrl(url);
            });
        }

        function inline(string, url, baseUrl, get) {
            return Promise.resolve(url)
                .then(function (url) {
                    return baseUrl ? util.resolveUrl(url, baseUrl) : url;
                })
                .then(get || util.getAndEncode)
                .then(function (data) {
                    return util.dataAsUrl(data, util.mimeType(url));
                })
                .then(function (dataUrl) {
                    return string.replace(urlAsRegex(url), '$1' + dataUrl + '$3');
                });

            function urlAsRegex(url) {
                return new RegExp('(url\\([\'"]?)(' + util.escape(url) + ')([\'"]?\\))', 'g');
            }
        }

        function inlineAll(string, baseUrl, get) {
            if (nothingToInline()) return Promise.resolve(string);

            return Promise.resolve(string)
                .then(readUrls)
                .then(function (urls) {
                    var done = Promise.resolve(string);
                    urls.forEach(function (url) {
                        done = done.then(function (string) {
                            return inline(string, url, baseUrl, get);
                        });
                    });
                    return done;
                });

            function nothingToInline() {
                return !shouldProcess(string);
            }
        }
    }

    function newFontFaces() {
        return {
            resolveAll: resolveAll,
            impl: {
                readAll: readAll
            }
        };

        function resolveAll() {
            return readAll(document)
                .then(function (webFonts) {
                    return Promise.all(
                        webFonts.map(function (webFont) {
                            return webFont.resolve();
                        })
                    );
                })
                .then(function (cssStrings) {
                    return cssStrings.join('\n');
                });
        }

        function readAll() {
            return Promise.resolve(util.asArray(document.styleSheets))
                .then(getCssRules)
                .then(selectWebFontRules)
                .then(function (rules) {
                    return rules.map(newWebFont);
                });

            function selectWebFontRules(cssRules) {
                return cssRules
                    .filter(function (rule) {
                        return rule.type === CSSRule.FONT_FACE_RULE;
                    })
                    .filter(function (rule) {
                        return inliner.shouldProcess(rule.style.getPropertyValue('src'));
                    });
            }

            function getCssRules(styleSheets) {
                var cssRules = [];
                styleSheets.forEach(function (sheet) {
                    try {
                        util.asArray(sheet.cssRules || []).forEach(cssRules.push.bind(cssRules));
                    } catch (e) {
                        console.log('Error while reading CSS rules from ' + sheet.href, e.toString());
                    }
                });
                return cssRules;
            }

            function newWebFont(webFontRule) {
                return {
                    resolve: function resolve() {
                        var baseUrl = (webFontRule.parentStyleSheet || {}).href;
                        return inliner.inlineAll(webFontRule.cssText, baseUrl);
                    },
                    src: function () {
                        return webFontRule.style.getPropertyValue('src');
                    }
                };
            }
        }
    }

    function newImages() {
        return {
            inlineAll: inlineAll,
            impl: {
                newImage: newImage
            }
        };

        function newImage(element) {
            return {
                inline: inline
            };

            function inline(get) {
                if (util.isDataUrl(element.src)) return Promise.resolve();

                return Promise.resolve(element.src)
                    .then(get || util.getAndEncode)
                    .then(function (data) {
                        return util.dataAsUrl(data, util.mimeType(element.src));
                    })
                    .then(function (dataUrl) {
                        return new Promise(function (resolve, reject) {
                            element.onload = resolve;
                            element.onerror = reject;
                            element.src = dataUrl;
                        });
                    });
            }
        }

        function inlineAll(node) {
            if (!(node instanceof ownerWindow.Element) && !(node instanceof Element)) return Promise.resolve(node);

            return inlineBackground(node)
                .then(function () {
                    if ((node instanceof ownerWindow.HTMLImageElement) || (node instanceof HTMLImageElement))
                        return newImage(node).inline();
                    else
                        return Promise.all(
                            util.asArray(node.childNodes).map(function (child) {
                                return inlineAll(child);
                            })
                        );
                });

            function inlineBackground(node) {
                var background = node.style.getPropertyValue('background');

                if (!background) return Promise.resolve(node);

                return inliner.inlineAll(background)
                    .then(function (inlined) {
                        node.style.setProperty(
                            'background',
                            inlined,
                            node.style.getPropertyPriority('background')
                        );
                    })
                    .then(function () {
                        return node;
                    });
            }
        }
    }
})(this);

/* END-OF-domToImage-CODE */

/*

 Copyright (c) 2012, Stephen Woods
 All rights reserved. (BSD License)

 Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */

var  Ascii = (function(){
    DEFAULT_CHAR_MAP = "$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\|()1{}[]?-_+~i!lI;:,\"^`'. ";
    CHAR_ASPECT_RATIO = 0.6;
    var AsciiArt = function(config) {
        this.config = config;
        this.config.maxPixels = this.config.maxPixels || 5000;
        this.config.scalingFactor = this.config.scalingFactor || 1.0;
        this.color = false;
        this.charMap = this.config.charMap || DEFAULT_CHAR_MAP;
    }

    AsciiArt.prototype.makeAscii = function(img){
        var map = this.charMap;
        var grays = map.length;
        var canvas = document.createElement('canvas'),
          ctx = canvas.getContext('2d'),
          w = img.width,
          h = img.height,
          thisRow,
          out = [];

        if (w * h > this.config.maxPixels) {
            var scaleDownFactor = Math.sqrt(1.0 * this.config.maxPixels / (w * h));
            w = w * scaleDownFactor;
            h = h * scaleDownFactor;
        }
        w = w * Math.sqrt(this.config.scalingFactor);
        h = h * Math.sqrt(this.config.scalingFactor);

        canvas.width = w;
        canvas.height = h;
        console.time('calc');
        ctx.drawImage(img, 0, 0, w, h);

        var data = ctx.getImageData(0, 0, w, h),
          i, avg, color, ch;

        for(var y = 0; y < data.height; y++){
            thisRow = [];
            for(var x = 0; x < data.width; x++){
                i = (y * 4) * data.width + x * 4;
                avg = (data.data[i] + data.data[i + 1] + data.data[i + 2]) / 3;
                color = [data.data[i], data.data[i + 1], data.data[i + 2]];

                ch = map[Math.round((avg/255) * grays)];
                if (!ch){
                    ch = map[map.length-1];
                }
                thisRow.push(ch);
            }
            out.push(thisRow);
        }
        ctx.putImageData(data, 0, 0);

        var outStr = '';

        var len = out.length;
        for (var i=0; i < len; i++) {
            outStr += out[i].join('');
            outStr += '\n';
        };
        console.timeEnd('calc');
        return outStr;
    }

    return AsciiArt;
}());

AsciiArtGraphGenerator = {
    GRAPH: "https://monitorportal.amazon.com/igraph?SchemaName1=OrdersCreated&Family1=us&Merchant1=ALL&ProductGroup1=ALL&Event1=OrderRate&Period1=FiveMinute&Stat1=sum&Label1=sum&HeightInPixels=900&WidthInPixels=800&GraphTitle=US%20Order%20Rate%20-%20Ascii%20Art&Timezone=UTC&ShowLegendErrors=false&HorizontalLineRight1={ASCII}&UpperValueRight={UPPER}&LowerValueRight=0&StartTime1=-P1D&EndTime1=-PT0H&FunctionExpression1=M1&FunctionLabel1=US%20OrderRate%20[max%3A%20{max}]&FunctionYAxisPreference1=left&FunctionExpression2=-1*M1&FunctionLabel2=AsciiArt&FunctionYAxisPreference2=right&ShowYAxisRight=false",
    MAX_URL_LEN: 27500,

    initialize: function() {
        unsafeWindow.AsciiArtGraphGenerator = this;
        this.displayAsciiArtEditor();
        this.trapImageClicks();
        this.autoDoAsciiArtIfOnImagePage();
    },

    displayAsciiArtEditor: function() {
        if (!onWiki || ($('.iGraphHelperAsciiEditor').length == 0)) {
            return;
        }

        var user = unsafeWindow.wgUserName.toLowerCase();
        var editorCode = $('.iGraphHelperAsciiEditor').text();
        editorCode = editorCode.replace(/{USER}/g, user);
        $('.iGraphHelperAsciiEditor').html(editorCode).show();
        $('.install').hide();
    },

    trapImageClicks: function(imgs) {
        var images = imgs || document.getElementsByTagName("img");
        for (var i = 0; i < images.length ; i++) {
            images[i].addEventListener("click",
              function (ev) {
                  if (ev.shiftKey && ev.altKey) {
                      ev.preventDefault();
                      window.open(ev.target.src + "#DOASCIIART", "_blank");
                  }
              },
              false);
        }
    },

    autoDoAsciiArtIfOnImagePage: function() {
        if (!/#DOASCIIART/.test(unsafeWindow.location.href)) {
            return;
        }

        window.focus();
        var instructions = document.createElement("div");
        instructions.innerHTML = '\
                <style> \
                    .label { text-align: right; } \
                    table { margin-top: 50px; color: black; font-family: Verdana, Arial, Sans-serif; font-size: 14px; background-color: white; } \
                    th { background-color: #DEF3F7; padding: 6px; border: 1px solid grey;} \
                </style>\
                <div><center>\
                   <table>\
                        <tr><th colspan="2">Select options for generating image in iGraph, then click button below</th></tr>\
                        <tr><td class="label">Character Map:</td><td><input id="charMap" type="text" size=40 value="$@B%8&WM#*oahkbdpqwmZO0QLCJUYXzcvunxrjft/\|()1{}[]?-_+~i!lI;:, "> dark chars to lighter, e.g. try: @80GCLft1i;:,.</td></tr>\
                        <tr><td class="label">Color:</td><td><input id="color" type="text" value="#FF0000"> #RRGGBB, or black, blue, green etc works too</td></tr>\
                        <tr><td class="label">Font Size:</td><td><input id="size" type="text" value="5"> reduce to fit image in smaller area on graph</td></tr>\
                        <tr><td class="label">Max Pixels:</td><td><input id="maxPixels" type="text" value="20000"> reduce if graph does not load - URL will get too long if there is too many "pixels"</td></tr>\
                    </table>\
                   <button class="iGraphButton" style="font-size: 32px; margin-top: 20px;">Click here to load this image into iGraph</button>\
                </center></div>';
        document.body.insertBefore(instructions, document.body.firstChild);
        document.getElementsByClassName("iGraphButton")[0].addEventListener("click", function() {
            var self = AsciiArtGraphGenerator;
            var config = {
                charMap:   document.getElementById("charMap").value,
                color:     document.getElementById("color").value,
                fontSize:  parseInt(document.getElementById("size").value),
                maxPixels: parseInt(document.getElementById("maxPixels").value),
                scalingFactor: 1.0
            };
            var image = document.getElementsByTagName("img")[0];
            var graph = self.getGraphFromAsciiArtString(new Ascii(config).makeAscii(image), config);
            if (graph.length > self.MAX_URL_LEN) {
                config.scalingFactor = 1.0 * self.MAX_URL_LEN / graph.length;
                GM_log("First graph URL too long (" + graph.length + " > " + self.MAX_URL_LEN + "), scaling down to " + config.scalingFactor);
                graph = self.getGraphFromAsciiArtString(new Ascii(config).makeAscii(image), config);    // Try again, scaled down
                GM_log("Second graph URL: " + graph.length);
            }
            window.open(graph);
        });
    },

    getGraphFromAsciiArtString: function(str, config) {
        var color = config.color != "#FF0000" ? " #color=" + config.color : "";
        var fontSize = config.fontSize != 10 ? " #size=" + config.fontSize : "";
        var lines = str.split('\n');
        var upper = lines.length;
        var longestLine = this.longestLine(lines);
        for (var i = 0; i < lines.length; i++) {
            lines[i] = this.encodeSingleLine(this.padLine(lines[i], longestLine)) + " #family=Monospaced #line=false" + color + fontSize + " @" + (upper - i);
        }
        var graph = AsciiArtGraphGenerator.GRAPH.replace("{ASCII}", this.urlEncode(lines.join(",")));
        graph = graph.replace("{UPPER}", "" + upper);
        return graph;
    },

    longestLine: function(lines) {
        var len = 0;
        for (var i = 0; i < lines.length; i++) {
            if (lines[i].length > len) {
                len = lines[i].length;
            }
        }
        return len;
    },

    encodeSingleLine: function(line) {
        return line.replace(/[%]/g, "%25").replace(/[(]/g, "%28").replace(/[)]/g, "%29").replace(/@/g, '%40').replace(/,/g, "%2C").replace(/#/g, '%23');
    },

    urlEncode: function(string) {
        return escape(string).replace(/[+]/g, "%2B").replace(/\//g, "%2F");
    },

    padLine: function(line, len) {
        return line + Array(len - line.length).join(" ") + ".";
    }

};

Carnaval = {
    COLORS: { OK: '0x669966', ALERT: 'red', ALARM: 'red', SUPPRESSED: 'red', AUTO_SUPPRESSED: 'red', AT_RISK: '0x669966' },
    ISENGARD_ENDPOINTS: {
        'aws': 'isengard.amazon.com',
        'aws-us-gov': 'isengard.pdt.aws-border.com',
        'aws-cn': 'isengard.bjs.aws-border.com',
        'aws-iso': 'isengard.dca.c2s-border.ic.gov',
        'aws-iso-b': 'isengard.lck.aws-border.com',
        'aws-eusc': 'isengard.eusc-de-east-1.amazonaws.eu'
    },
    CONSOLE_ENDPOINT_SUFFIXES: {
        'aws': 'console.aws.amazon.com',
        'aws-us-gov': 'console.amazonaws-us-gov.com',
        'aws-cn': 'console.amazonaws.cn',
        'aws-iso': 'console.c2shome.ic.gov',
        'aws-iso-b': 'console.sc2shome.sgov.gov',
        'aws-eusc': 'console.aws.eu'
    },
    ALARM_VIEWER_ROLE_NAME: 'ReadOnly',

    initialize: function() {
        this.addControls();
    },

    addControls: function() {
        var controlsHtml = '' +
          '<button type="button" class="button iGraphVerticalLinesButton" title="Generate iGraph vertical line definition from history times (added by iGraphHelper)">'
          + 'iGraph Vertical Lines' +
          '</button> ' +
          '<span class="iGraphAddedToClipboard" style="display: none;">Vertical lines definition copied to clipboard</span>';
        $('#historyForm').append(controlsHtml);
        $('.iGraphVerticalLinesButton').on('click', this.createLines);

        this.addCloudWatchLinkIfRelevant();
    },

    addCloudWatchLinkIfRelevant: function() {
        var agentDetailsSourceRow = $("tr td.default:contains('source')").parent().filter("tr:has(td.default:contains('CloudWatch'))");
        var cloudWatchMonitorArn = agentDetailsSourceRow.parent().find("tr td.default:contains('name')").next().text();

        if (!cloudWatchMonitorArn) {
            return;
        }

        var arnMatch = /arn:([^:]+):cloudwatch:([^:]+):([^:]+):alarm:(.*)/.exec(cloudWatchMonitorArn);
        if (!arnMatch) {
            return;
        }

        var awsPartition = arnMatch[1];
        var awsRegion = arnMatch[2];
        var accountId = arnMatch[3];
        var alarmName = arnMatch[4];

        var addConduitLinkRow = function() {
            var baseCloudWatchConsoleDomain = (awsPartition == 'aws-cn') ? 'amazonaws.cn' : 'aws.amazon.com';

            var consoleCloudWatchAlarmUrl = `https://console.${baseCloudWatchConsoleDomain}/cloudwatch/home?region=${awsRegion}#alarmsV2:alarm/${alarmName}`;

            var accessFederatedUrl = `https://conduit.security.a2z.com/api/consoleUrl?awsAccountId=${accountId}&awsPartition=${awsPartition}&redirect=true&destination=${encodeURIComponent(consoleCloudWatchAlarmUrl)}`;

            agentDetailsSourceRow.after(`<tr><td class="default">Links</td><td class="default"><a target=_blank id='iGraphHelperConduitCloudWatchMonitorLink' href='${accessFederatedUrl}'>Open via Conduit</a></td></tr>`);
        };

        const addIsengardLinkRow = () => {
            const isengardEndpoint = Carnaval.ISENGARD_ENDPOINTS[awsPartition];
            const consoleEndpoint = `https://${awsRegion}.${Carnaval.CONSOLE_ENDPOINT_SUFFIXES[awsPartition]}`;
            const cwAlarmName = alarmName.replace(/ /g, '+');
            const alarmDeepLink = encodeURIComponent(`${consoleEndpoint}/cloudwatch/home?region=${awsRegion}#alarmsV2:alarm/${cwAlarmName}`);
            const isengardUrl = `https://${isengardEndpoint}/federate?account=${accountId}&role=${Carnaval.ALARM_VIEWER_ROLE_NAME}&destination=${alarmDeepLink}`;

            agentDetailsSourceRow.after(`<tr><td class="default">Links</td><td class="default"><a target=_blank id='iGraphHelperIsengardCloudWatchMonitorLink' href='${isengardUrl}' title='Isengard link will only work if the role ${Carnaval.ALARM_VIEWER_ROLE_NAME} is configured in account ${accountId} and you have access'>Open via Isengard (role: ${Carnaval.ALARM_VIEWER_ROLE_NAME})</a></td></tr>`);
        };

        var accountNameCacheKey = 'iGraphHelperConduitAcctById_' + accountId;

        var accountName = GM_getValue(accountNameCacheKey);

        if (accountName !== undefined && accountName !== null && accountName !== '') {
            if (accountName) {
                addConduitLinkRow();
            }
            return;
        }

        var conduitUrl = `https://conduit.security.a2z.com/api/accounts/partition/${awsPartition}/accountId/${accountId}`;

        GM_xmlhttpRequest({
            method: "GET",
            url: conduitUrl,
            onload: function (response) {
                try {
                    const jsonResponse = response.responseText;
                    const accountInfo = JSON.parse(jsonResponse);
                    const accountName = accountInfo.account.name;

                    GM_setValue(accountNameCacheKey, accountName);

                    if (!accountName) {
                        // Account not recognized by Conduit, assume it's Isengard account
                        addIsengardLinkRow();
                    }
                    else {
                        addConduitLinkRow();
                    }
                } catch (e) {
                    console.log(`Could not load Conduit AWS account by partition=${awsPartition} id=${accountId}`);
                    console.log(e);

                    // Fallback to Isengard
                    addIsengardLinkRow();
                }
            }
        });
    },

    /**
     * Driver function for creating the vertical lines pop-up.
     */
    createLines: function() {
        // Compute the output.
        var lines = [];
        $('#AuditLogTable tr:gt(0)').each(function() {
            if (! $(this).attr('id')) {
                var timestamp = $('td:eq(0)', this).text().trim();
                var className = $('td:eq(1) div', this).attr('class');
                var state = $('td:eq(1)', this).text().trim();

                var color = Carnaval.COLORS[className] || 'red';
                var hourMin = timestamp.replace(/.* /, '').replace(/:\d\d$/, '');
                var utcXml = timestamp.replace(/ /, 'T') + 'Z';
                lines.push(state + ' #color=' + color + ' (' + hourMin + ') @ ' + utcXml);
            }
        });
        var linesStr = lines.join(',');
        GM_setClipboard(linesStr);
        $('.iGraphAddedToClipboard').css('display', 'inline').fadeIn().delay(2000).fadeOut();
    }
};

// CloudWatch Insights uses JSURL for url generation
/**
 * Copyright (c) 2011 Bruno Jouhier <bruno.jouhier@sage.com>
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */
!function(e){"use strict";var f={true:!0,false:!(e.stringify=function r(t){function e(r){return/[^\w-.]/.test(r)?r.replace(/[^\w-.]/g,function(r){return"$"===r?"!":(r=r.charCodeAt(0))<256?"*"+("00"+r.toString(16)).slice(-2):"**"+("0000"+r.toString(16)).slice(-4)}):r}var n;switch(typeof t){case"number":return isFinite(t)?"~"+t:"~null";case"boolean":return"~"+t;case"string":return"~'"+e(t);case"object":if(!t)return"~null";if(n=[],Array.isArray(t)){for(var a=0;a<t.length;a++)n[a]=r(t[a])||"~null";return"~("+(n.join("")||"~")+")"}for(var i in t)if(t.hasOwnProperty(i)){var s=r(t[i]);s&&n.push(e(i)+s)}return"~("+n.join("~")+")";default:return}}),null:null};e.parse=function(i){if(!i)return i;i=i.replace(/%(25)*27/g,"'");var s=0,u=i.length;function o(r){if(i.charAt(s)!==r)throw new Error("bad JSURL syntax: expected "+r+", got "+(i&&i.charAt(s)));s++}function c(){for(var r,t=s,e="";s<u&&"~"!==(r=i.charAt(s))&&")"!==r;)switch(r){case"*":t<s&&(e+=i.substring(t,s)),t="*"===i.charAt(s+1)?(e+=String.fromCharCode(parseInt(i.substring(s+2,s+6),16)),s+=6):(e+=String.fromCharCode(parseInt(i.substring(s+1,s+3),16)),s+=3);break;case"!":t<s&&(e+=i.substring(t,s)),e+="$",t=++s;break;default:s++}return e+i.substring(t,s)}return function r(){var t,e,n;switch(o("~"),e=i.charAt(s)){case"(":if(s++,"~"===i.charAt(s))if(t=[],")"===i.charAt(s+1))s++;else for(;t.push(r()),"~"===i.charAt(s););else if(t={},")"!==i.charAt(s))do{t[c()]=r()}while("~"===i.charAt(s)&&++s);o(")");break;case"'":s++,t=c();break;default:for(n=s++;s<u&&/[^)~]/.test(i.charAt(s));)s++;var a=i.substring(n,s);if(/[\d\-]/.test(e))t=parseFloat(a);else if(void 0===(t=f[a]))throw new Error("bad value keyword: "+a)}return t}()},e.tryParse=function(r,t){try{return e.parse(r)}catch(r){return t}}}("undefined"!=typeof exports?exports:window.JSURL=window.JSURL||{});

OCLLinksManager = {
    CLOUDWATCH_SERVICE_LOG_IMG: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACXBIWXMAAAsTAAALEwEAmpwYAAABWWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgpMwidZAAAEMUlEQVRIDbVVXWgcVRQ+d+bub3bT3W6TbGL+1zTZDaS0EUp8aDYP+iBUUNkFlYrQ0ELF0kXwBx8yDypEoS/SBxUpiCI0UMQHQRS61BDUtj4l/hRXacMmMTU/y+7M7mR+rufOZpKd7aYB0cOcufece+Y7555z7lyA/5nIfvipFIgAKevhtjPpGRMHtt93/3pdkiRBupakjMG+wXEnextxAALsxOODfT2jgefbY02LxHB/MX3224IdnSQlqSRldVtuNDZ0kEwmaTab1Z++MNpeWq3Mtsf8/Q8dDoBWMf5EkKuEsCvvTn73YyPAel1DB2jE9ezkqZE+zTQWwh0e2hUPmtQleESRQEXWdUJgDvnS9OnrV+pBa2WhVsC55fD48YeDT06OTEXjvg+ohzDMN7ejmmroHBytaCDsOWEyeNP+XpIsG1vcGR0OMDXYMQCBTrEXQSS3T3xMoMQPjHE7vkY5OI5bZVnDAYrIe2WBrzf2KpqCiWGva6pZYSa2JC+3kwRBwA6o6h/Yso4dODHAhbAuzPOeXU+qrVrv3AHzIAeAANXobCcNYsUzYaV1aqrx4WvoYMsRQ1XA1kQEHQxTA9PUwWQGlsbQpYnqOUjPpBpi8YLtUEtL1orR7/cTQrCI25vnbcTr7HMdAhd1A6aNiFQAXTBa3v78uRdluXDznfTMPNrhdxhJDTm83htOWpBffXZL03UNUQkIAgVKKazlVVi+rWL0gLvQxbJaZhVNHgDvxmXFWHmKYyK4A4/rHIqsVN3B9MevBtxuL61o60KhuASaUWFbFQ3y+UUoyEtQUu9BsbxMikqeyUoBopHBZg6GZFSH3bdVIBTtTmCnX3/ijbbWlvcSQ8OeruigWzQPCExQiYyg62vLrLWnCZiwRbw0DO2RONGLTWTlNz0xPjF2LjHWGvxpNnd9G97CrK0BV7D8Uq5nU853Hwx0Qm93TEkMxZk/eNSlKIor15ojkYNeOBSKMr8noCmyqv8wN0vdnXdCEAmG7txa7+fg/E9rtTfO7ci53nKQyoz5ShuFZ0vK6isGrCXCgSHoaj+sxvpiWrSjjbq8BDZLa/qmuuj6PfeLZ/7GzzBx8tFfO/rCr708fvVLDoRkYdkTS7P92lm4eDHjm7v9/Qul8sZ5zSwkyuW/oSUSV2NHD4DgLXqo6AFVFm9+88kfq/NzKyH8/mvkj5CXkXlt+cXk2AGXgf+0stkkcrW/M5mU727l7im1XDnvDprDA8dCeADpvGmI76cn+y8/Qj7kP6Ujza3iWaVodutl9gzKKvKOE5zfT9zRmTOjrt2VXm/6wrGXMpfGz+Hp9W7rxZGRtqZdG5jDed+2XFvfGpO6KXfEL6A6tSV2xpsHcPIp8lvIM8jTyDbxdN+fInu1fuSOFhZShN//nPDyt3v+CIpx5L+QryFz2qllVfxv31bkNuQ/6QmDzBSaM80AAAAASUVORK5CYII=',
    CLOUDWATCH_APPLICATION_LOG_IMG: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACXBIWXMAAAsTAAALEwEAmpwYAAABWWlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyI+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgpMwidZAAAEP0lEQVRIDbVVXWhcRRQ+M3f27k/uJtmmm2Zr/re2+cFKm4faB8u2oA9CCxZ2IYoitDaIoi2CtPiQ+1CFqFQQigSVPoVKYsUi9UnsYkoppRVLawqFEEmyCeZ/u393c3/GM3f3prtxk6DgsLNnzpkz33dmzpk7AP9zI1vhR6MgAUTtn/AdiY1YKPhW6/7zvKqqVL0eYZzDlsEJko2dBAABfujFPW0tPcqroXDVFDHlHwb6fk460alqhKlq3HD0SrIiQSQSYfF43Dh+uieUntNuhMK+9qd2K6Br5gSCfE8IH/7k5OjtSoDrbRUJ0EnY+dHX9rbplvlHYKebNXX6LeaibkkioGUMgxC4if3iwIlfh9eDluq0VMGxTXjgwC7/sZN7+xs6vYPMTTiet/Bjet40BDh6MSXgPmRx+NBZr6q2j6OuyTICPBqsGAClUWpFEFX2Si9QRnzAufATc0yAo1zNZXQUkMK+0SmI+cqskkUtDHtJz1sat7AkRbrLG6UUK6Bg37Rky3ZQjgEuhHXhOW9Y9aRQquvJy2A2IwAEKETnkFSIFe+Efaz9/ZUvX0WC1bIYCgqWJiIYYFo6WJYBFjcxNaahHi7cg9hItCKWSNhaCwbjdow+n48Qgkksbl6Ukciz17UdXEwGPDYiMQoGNYMfXX7ljUwmeefj2MgD9MN1GElJK2Od747YkD8N3dUNQ0dUApQyYIzBYiIPs4/yGD3gLgwpl89xTc8+Dd6VS1lz7mWBSWKkDE/YygxxtbCDgW8+UGTZwzR9iSZTM6CbGl/VdEgkpiCZmYF0fh5SuVmSyk7zx6kFCNXt8gswGAHTliV/doJQdyqBnzj70rkd9cFPuzq63U0Ne2TJqqGc5kkGQZcWZ3l9SxWGpRNZqoXG7d1EW/KRqftad9/Z4289d6zB98uVsdEino1ZmgNh4ImZ8ZaVTKJ5m9IIrc3hbFdHJ/f597my2axrvH6c1G1zQzAQ4m5WpQPlxsS93+WvP7taq7T/Vev1e5pF8JiyQsSI6EQu7DZB9MxBb3o52ZvOzr1vwmJXQOmAptDufLgtrDfs3MFcHgIr6UVjMTspzy9PyL/deGAFapq1mT+Xrt2+9kUvITEsL8TCe+iACuk0m0QoFy6c8d58dOv1dG75Xd1KduVyCxCs68yH99UA9abcFGSYn9RXR7+bHnr2SMP5K5/f78dlb2IXVS5yKx4m+/si5ForfLQi0uDgt6tjd6bvHj1y+FKewqRMA+0uHw8FmzyMWsrD6uravqtfjk2P31vY//DWHHcrtLe2no3mHlsJBBNHbxOsAa8fCKJTp3pcT+ytntjp/W+/d/H5d65z1cndj1V19Jy/nh1Ev8vYzxf9neJ5snyjkSASD9D6+faewDOeajpUYhckX5XoZVegxF55KIii0agUHY5KxffYjZ7eoreIWORPwf7vgIsAm4nSSvyH399InITuoxR4MwAAAABJRU5ErkJggg==',

    // The hash args property prevents an unnecessary redirect (essential to detect signed-out scenarios)
    AWS_CONSOLE_URL: "https://console.aws.amazon.com/console/home?region=us-east-1&state=hashArgs%23",
    AWS_CONSOLE_BASE_URL: "https://console.aws.amazon.com/",
    AWS_ACCOUNT_SIGN_OUT_URL: "https://signin.aws.amazon.com/oauth?Action=logout&redirect_uri=aws.amazon.com",
    CLOUDWATCH_BASE_URL: "https://console.aws.amazon.com/cloudwatch/home?",
    CONDUIT_BASE_URL: "https://access.amazon.com/aws/accounts/fetchConsoleUrl?",
    ISENGARD_BASE_URL: "https://isengard.amazon.com/federate?",
    APPLICATION_LOG_KEY: "application",
    SERVICE_LOG_KEY: "service",

    setOCLIconsVisibility: function(graphArgs) {
        var graphParams = this.getDecodedGraphParams(graphArgs);
        if (OCLSettingsManager.isOCLConfigPresent(graphParams.ServiceName1, graphParams.Marketplace1, graphParams.DataSet1)) {
            $('.OCLIcons').show();
        } else {
            $('.OCLIcons').hide();
        }
    },

    getCookie: function(name) {
        var value = "; " + document.cookie;
        var parts = value.split("; " + name + "=");
        if (parts.length === 2) {
            return parts.pop().split(";").shift();
        }
    },

    getAwsUserCookie: function() {
        try {
            return JSON.parse(decodeURIComponent(this.getCookie("aws-userInfo")));
        } catch (error) {
            return undefined;
        }
    },

    getDecodedGraphParams: function(graphParamString) {
        var params = {};
        if (graphParamString) {
            graphParamString.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m, key, value) {
                params[key] = decodeURIComponent(value);
            });
        }
        return params;
    },

    generateConduitDeepLinkedUrl: function(accountName, url) {
        return this.CONDUIT_BASE_URL + "account_name=" + accountName + "&destination=" + encodeURIComponent(url);
    },

    generateIsengardDeepLinkedUrl: function(accountId, role, url) {
        // Isengard auto-appends aws-console url, hence removing it.
        var destinationUrl = url.replace(this.AWS_CONSOLE_BASE_URL, "")
        return this.ISENGARD_BASE_URL + "account=" + accountId + "&role=" + encodeURIComponent(role) + "&destination=" + encodeURIComponent(destinationUrl);
    },

    generateDeepLinkedCloudWatchUrl: function(accountType, accountName, accountId, role, cloudWatchUrl) {
        if (accountType === "Conduit") {
            return this.generateConduitDeepLinkedUrl(accountName, cloudWatchUrl);
        }
        return this.generateIsengardDeepLinkedUrl(accountId, role, cloudWatchUrl);
    },

    // How SSO works in AWS - https://tiny.amazon.com/10eu9dahs/wamazindeAWSDeveConsProjSess
    loggedIntoOtherAccount: function(expectedAwsAccountId) {
        var awsUserInfo = this.getAwsUserCookie();
        return awsUserInfo && awsUserInfo.alias !== expectedAwsAccountId;
    },

    logOutAndGoToCloudWatch: function(cloudWatchUrl) {
        GMUtils.gmXmlHttpRequest({
            method: "GET",
            url: this.AWS_ACCOUNT_SIGN_OUT_URL,
            onload: function(response) {
                window.open(cloudWatchUrl)
            }
        });
    },

    logInAndGoToCloudWatch: function(deepLinkedCloudWatchUrl, directCloudWatchUrl) {
        var awsUserInfo = this.getAwsUserCookie();
        if (awsUserInfo && awsUserInfo.keybase) {
            GMUtils.gmXmlHttpRequest({
                method: "GET",
                url: this.AWS_CONSOLE_URL,
                onload: function(response) {
                    // AWS Console returns 200 even if there is a redirect to signin.aws.amazon.com
                    if (response.status === 200 && (response.finalUrl == null || response.finalUrl.indexOf("signin") === -1)) {
                        window.open(directCloudWatchUrl)
                    } else {
                        window.open(deepLinkedCloudWatchUrl)
                    }
                },
                onerror: function (response) {
                    window.open(deepLinkedCloudWatchUrl);
                },
            });
        } else {
            window.open(deepLinkedCloudWatchUrl);
        }
    },

    generateDirectCloudWatchEventViewerUrl: function(region, logGroupName, logType, startTime, endTime, metric) {
        var cloudWatchUrl = this.CLOUDWATCH_BASE_URL + "region=" + region + "#" +
          "logEventViewer:group=" + logGroupName[logType] + ";" +
          "start=" + startTime + ";" +
          "end=" + endTime + ";";
        if (logType === this.SERVICE_LOG_KEY) {
            cloudWatchUrl = cloudWatchUrl + "filter=" + "%22" + metric + "%22"
        }
        return cloudWatchUrl;
    },

    generateDirectCloudWatchInsightsUrl: function(region, logGroupName, logType, startTime, endTime, methodName, metric) {
        var params = {
            end: endTime,
            source: logGroupName[logType],
            start: startTime,
            timeType: "ABSOLUTE",
            tz: "UTC"
        };
        // Since ALL is PMET way of aggregating the data and is not present in service logs, we can't add a filter on top of it.
        if (logType === this.SERVICE_LOG_KEY && methodName !== "ALL") {
            params.editorString = "fields @timestamp, RequestId, @message | filter Operation='" + methodName + "' and " + metric + " > 0 | sort @timestamp";
        } else if (logType === this.SERVICE_LOG_KEY) {
            params.editorString = "fields @timestamp, RequestId, @message | filter " + metric + " > 0 | sort @timestamp";
        } else {
            params.editorString = "fields @timestamp, @message | sort @timestamp";
        }
        return this.CLOUDWATCH_BASE_URL + "region=" + region + "#" + "logs-insights:queryDetail=" + JSURL.stringify(params);
    },

    generateDirectCloudWatchUrl: function(region, logGroupName, logType, startTime, endTime, methodName, metric) {
        if ((logType === this.APPLICATION_LOG_KEY && OCLSettingsManager.isTraditionalViewEnabledForApplicationLogs()) ||
          (logType === this.SERVICE_LOG_KEY && OCLSettingsManager.isTraditionalViewEnabledForServiceLogs())) {
            return this.generateDirectCloudWatchEventViewerUrl(region, logGroupName, logType, startTime, endTime, metric);
        }
        return this.generateDirectCloudWatchInsightsUrl(region, logGroupName, logType, startTime, endTime, methodName, metric);
    },

    /*
     * Takes care of below scenarios if deep linking is enabled:
     * 1. If the user is logged into correct aws account then directly go to cloudwatch.
     * 2. If the user is logged into some other aws account then log out and login.
     * 3. If the user's AWS session has expired then relogin.
     * 4. If the user never logged into AWS console before then login.
     */
    goToCloudWatchConsole: function(logType, graphArgs) {
        var graphParams = this.getDecodedGraphParams(WikiSnapshot.replaceRelativeWithFixedTime(graphArgs));
        var serviceName = graphParams.ServiceName1;
        var marketplace = graphParams.Marketplace1;
        var dataSet = graphParams.DataSet1;
        var methodName = graphParams.MethodName1;
        var startTime = graphParams.StartTime1;
        var endTime = graphParams.EndTime1;
        var metric = graphParams.Metric1;

        var cloudwatchConsoleParams = OCLSettingsManager.getOCLConfig(serviceName, marketplace, dataSet)
        var directCloudWatchUrl = this.generateDirectCloudWatchUrl(cloudwatchConsoleParams.region, cloudwatchConsoleParams.logGroupName, logType, startTime, endTime, methodName, metric);
        var deepLinkedCloudWatchUrl = this.generateDeepLinkedCloudWatchUrl(cloudwatchConsoleParams.accountType,
          cloudwatchConsoleParams.accountName,
          cloudwatchConsoleParams.accountId,
          cloudwatchConsoleParams.role,
          directCloudWatchUrl)

        if (!OCLSettingsManager.isDeepLinkEnabled()) {
            window.open(directCloudWatchUrl);
        } else if (this.loggedIntoOtherAccount(cloudwatchConsoleParams.accountId)) {
            this.logOutAndGoToCloudWatch(deepLinkedCloudWatchUrl);
        } else {
            this.logInAndGoToCloudWatch(deepLinkedCloudWatchUrl, directCloudWatchUrl);
        }
        return false;
    }

}

OCLSettingsManager = {
    REMOTE_CONFIG_ENDPOINT: 'https://ttbots.aka.amazon.com/getOCLConfigurations',

    STYLES : '\
        .OCLConfigPopup {\
            display: none; \
            position: fixed; \
            z-index: 1600; \
            padding-top: 30px; \
            width: 100%; \
            height: 100%; \
            overflow: auto; \
            background-color: rgb(0,0,0); \
            background-color: rgba(0,0,0,0.4); \
            font-family: "Amazon Ember", Helvetica, Arial, sans-serif;\
            text-align: left !important;\
         }\
        .OCLConfigPopupContent {\
            background-color: #f2f3f3;\
            margin: auto;\
            padding: 20px;\
            border: 1px solid #888;\
            width: 80%;\
        }\
        .OCLConfigPopupCloseButton {\
            color: #aaaaaa;\
            float: right;\
            font-size: 28px;\
            font-weight: bold;\
        }\
        .OCLConfigPopupCloseButton:hover,\
        .OCLConfigPopupCloseButton:focus {\
            color: #000;\
            text-decoration: none;\
            cursor: pointer;\
        }\
        .OCLConfigInput {\
            width: 100%; /* Specifying in percentage to account for variable window sizes*/\
            height: 15em; /* Specifying in em as by default the height is too low */\
            display: none;\
        }\
        .OCLConfigPopupHeader {\
            position: relative;\
            margin-bottom: 1rem;\
            border: 1px solid transparent;\
            border-radius: .25rem;\
            display: inline-block;\
            font-size: 24px;\
        }\
        .OCLConfigPopupErrorMessage {\
            color: #d13212;\
        }\
        .OCLRemoteConfigInput {\
            background-color: #eaeded;\
        }\
        .OCLFormButton {\
            background-color: #fff;\
            border-radius: 2px;\
            border: 1px solid;\
            padding: .4rem 2rem;\
            font-weight: 700;\
            letter-spacing: .25px;\
            display: inline-block;\
            cursor: pointer;\
        }\
        .OCLUserConfigToggleButton {\
            margin-top: 0.5rem;\
        }\
        .OCLFormButton:hover {\
            background-color: #f2f3f3;\
        }\
        .OCLSubmitFormButton {\
            background-color: #ec7211;\
            color: #fff;\
            font-size: small;\
        }\
        .OCLSubmitFormButton:hover {\
            background-color: #eb5f07;\
        }\
    ',

    HTML : '\
        <div id="OCLConfigPopup" class="OCLConfigPopup">\
            <div class="OCLConfigPopupContent">\
                <span id="OCLConfigPopupCloseButton" class="OCLConfigPopupCloseButton">&times;</span>\
                <h2 class="OCLConfigPopupHeader"> Go to cloudwatch logs from iGraph via single click. See video and instructions <a target="_blank" href="https://w.amazon.com/bin/view/OneClickLogs/">here</a></h2>\
                <form id="OCLConfigForm">\
                    <input type="checkbox" value="true" name="OCLAllowRemoteSyncOption" checked> Sync configurations from remote periodically <br>\
                    <input type="checkbox" value="true" name="OCLDeepLinksOption" checked> Automatically login into relevant AWS account (experimental) <br>\
                    <input type="checkbox" value="true" name="OCLApplicationLogTraditionalViewOption" checked> Use traditional CloudWatch Logs UI for Application Logs<br>\
                    <input type="checkbox" value="true" name="OCLServiceLogTraditionalViewOption"> Use traditional CloudWatch Logs UI for Service Logs<br><br>\
                    <button id="OCLToggleRemoteConfigButton" class="OCLFormButton">Remote configurations</button>\
                    <h3 id="OCLRemoteConfigSyncFailureMessage" class="OCLConfigPopupErrorMessage"> Failed refreshing config from remote, please ensure you are connected to Amazon network and signed into Midway. </h3>\
                    <textarea id="OCLRemoteConfigInput" class="OCLConfigInput OCLRemoteConfigInput" disabled></textarea><br>\
                    <button id="OCLToggleUserConfigButton" class="OCLFormButton OCLUserConfigToggleButton">Manually added configurations</button>\
                    <textarea id="OCLUserConfigInput" class="OCLConfigInput"></textarea><br>\
                    <h3 id="OCLUserConfigValidationFailureMessage" class="OCLConfigPopupErrorMessage"> Syntax validation failed, please check instructions and resubmit </h3><br>\
                    <button id="OCLFormSubmitButton" class="OCLFormButton OCLSubmitFormButton">Submit</button>\
                </form>\
            </div>\
        </div>\
    ',

    // Dummy OCL config
    DEFAULT_CLOUDWATCH_USER_CONFIG : {
        "ServiceName#Marketplace#DataSet": {
            accountId: "AWSAccountId",
            region: "AWSRegion",
            accountType: "Conduit",
            accountName: "AWSAccountName/ApplicableForConduitAWSAccounts",
            role: "AWSRole/ApplicableForIsengardAWSAccounts",
            logGroupName: {
                application : "CloudWatchLogGroupForApplicationLogs",
                service : "CloudWatchLogGroupForServiceLogs"
            }
        },
        "ServiceName2#Marketplace2#DataSet2": {
            accountId: "AWSAccountId2",
            region: "AWSRegion2",
            accountType: "Isengard",
            accountName: "AWSAccountName2/ApplicableForConduitAWSAccounts",
            role: "AWSRole2/ApplicableForIsengardAWSAccounts",
            logGroupName: {
                application : "CloudWatchLogGroupForApplicationLogs",
                service : "CloudWatchLogGroupForServiceLogs"
            }
        }
    },

    userConfig: undefined,
    remoteConfig: undefined,
    mergedConfig: undefined,

    initialize: function() {
        if (this.initialized) {
            return;
        }
        GM_addStyle(this.STYLES)
        var popupContainer = document.createElement("div");
        popupContainer.innerHTML = this.HTML
        document.body.insertBefore(popupContainer, document.body.firstChild);

        // Hide the popup when the user clicks outside of it.
        jQuery(window)[0].addEventListener("click", function(event) {
            if (event.target.id === "OCLConfigPopup") {
                jQuery("#OCLConfigPopup").hide();
            }
        })

        jQuery("#OCLConfigPopupCloseButton")[0].addEventListener("click", function() { jQuery("#OCLConfigPopup").hide(); }, false);
        jQuery("#OCLToggleRemoteConfigButton")[0].addEventListener("click", function(e) { e.preventDefault(); jQuery("#OCLRemoteConfigInput").toggle(); }, false);
        jQuery("#OCLToggleUserConfigButton")[0].addEventListener("click", function(e) { e.preventDefault(); jQuery("#OCLUserConfigInput").toggle(); }, false);
        jQuery("#OCLConfigForm")[0].addEventListener("submit", this.saveOCLConfig.bind(this), false);
        this.setOCLConfigInitialValue();
        this.initialized = true;
    },

    showSettingsPopup: function() {
        jQuery("#OCLConfigPopup").show();
        jQuery("#OCLUserConfigValidationFailureMessage").hide();
        jQuery("#OCLRemoteConfigSyncFailureMessage").hide();
    },

    decodeJSON: function(text) {
        try{
            return JSON.parse(text);
        } catch (error){
            return undefined;
        }
    },

    isValidConfig: function(userOCLConfig) {
        var configIsValid = true;
        if (userOCLConfig) {
            for(key in userOCLConfig) {
                var value = userOCLConfig[key];
                // All keys should include certain elements and # in name.
                configIsValid = configIsValid && key.indexOf("#") !== -1;
                configIsValid = configIsValid && value.region;
                configIsValid = configIsValid && value.accountId;
                configIsValid = configIsValid && value.logGroupName;
                configIsValid = configIsValid && (value.accountType === "Conduit" || value.accountType === "Isengard");

                if (value.accountType === "Conduit") {
                    configIsValid = configIsValid && value.accountName;
                } else {
                    configIsValid = configIsValid && value.role;
                }
            }
            return configIsValid;
        }
        return false;
    },

    saveOCLConfig: function(event) {
        event.preventDefault();
        var configValue = this.decodeJSON(jQuery("#OCLUserConfigInput")[0].value);
        var remoteSyncOption = document.querySelector('input[name="OCLAllowRemoteSyncOption"]').checked;
        var deepLinkOption = document.querySelector('input[name="OCLDeepLinksOption"]').checked;
        var applicationLogTraditionalViewOption = document.querySelector('input[name="OCLApplicationLogTraditionalViewOption"]').checked;
        var serviceLogTraditionalViewOption = document.querySelector('input[name="OCLServiceLogTraditionalViewOption"]').checked;

        if (this.isValidConfig(configValue)) {
            var OCLConfig = {
                cwConfig : configValue,
                options : {
                    allowRemoteSync: remoteSyncOption,
                    useDeepLinks : deepLinkOption,
                    useTraditionalViewForApplicationsLogs : applicationLogTraditionalViewOption,
                    useTraditionalViewForServiceLogs : serviceLogTraditionalViewOption
                }
            }
            GM_setValue("OCLConfig", JSON.stringify(OCLConfig));
            jQuery("#OCLConfigPopup").hide();
            location.reload();
        } else {
            jQuery("#OCLUserConfigValidationFailureMessage").show();
        }
        return false;
    },

    handleRemoteConfigSyncFailure: function() {
        // Update lastUpdated flag even in failures so that we avoid spamming remote endpoint
        this.updateRemoteConfigWithLastUpdatedTimestamp();
        jQuery("#OCLRemoteConfigSyncFailureMessage").show();
    },

    updateRemoteConfigWithLastUpdatedTimestamp: function() {
        GM_setValue("RemoteOCLConfig", JSON.stringify(Object.assign(this.remoteConfig, {lastUpdated: Date.now()})));
        // Refresh the remote config portion on OCL Settings menu.
        this.setOCLPopupRemoteConfigValue();
    },

    refreshRemoteOCLConfig: function(isUserViewingOCLSettings) {
        var lastUpdatedTime = this.remoteConfig.lastUpdated || 0;
        // Refresh once a day or when user opens up OCLSettings menu.
        if ((this.isRemoteSyncEnabled() && Date.now() - lastUpdatedTime > (24 * 60 * 60 * 1000)) || isUserViewingOCLSettings) {
            GMUtils.gmXmlHttpRequest({
                method: "GET",
                url: this.REMOTE_CONFIG_ENDPOINT,
                headers: {
                    'Referer': window.location.href
                },
                onload: function (response) {
                    var remoteConfig = this.decodeJSON(response.responseText);
                    // Only change remoteConfig if server response is valid JSON and valid OCL config
                    if (remoteConfig && this.isValidConfig(remoteConfig.cwConfig)) {
                        this.remoteConfig = remoteConfig
                        this.updateRemoteConfigWithLastUpdatedTimestamp();
                    } else {
                        this.handleRemoteConfigSyncFailure();
                    }
                }.bind(this),
                onabort: this.handleRemoteConfigSyncFailure.bind(this),
                onerror: this.handleRemoteConfigSyncFailure.bind(this),
                ontimeout: this.handleRemoteConfigSyncFailure.bind(this)
            });
        }
    },

    // Load remote and local config and then merge to use as final config.
    setOCLConfigInitialValue: function() {
        this.userConfig = this.decodeJSON(GM_getValue("OCLConfig")) || {};
        this.remoteConfig = this.decodeJSON(GM_getValue("RemoteOCLConfig")) || {};
        this.mergedConfig = {
            cwConfig: Object.assign({}, this.remoteConfig.cwConfig, this.userConfig.cwConfig),
            options: this.userConfig.options
        }
        this.setOCLConfigPopupValues();
        this.refreshRemoteOCLConfig();
    },

    setOCLConfigPopupValues: function() {
        if (this.userConfig.cwConfig && this.userConfig.options) {
            var options = this.userConfig.options;
            var userConfigButtonTextSuffix = " (" + Object.keys(this.userConfig.cwConfig).length + " services)";
            // Pretty print the value
            jQuery("#OCLUserConfigInput").val(JSON.stringify(this.userConfig.cwConfig, null, 4));
            jQuery("#OCLToggleUserConfigButton").html(jQuery("#OCLToggleUserConfigButton").html() + userConfigButtonTextSuffix);
            jQuery('input[name="OCLAllowRemoteSyncOption"]').prop('checked', options.allowRemoteSync);
            jQuery('input[name="OCLDeepLinksOption"]').prop('checked', options.useDeepLinks);
            jQuery('input[name="OCLApplicationLogTraditionalViewOption"]').prop('checked', options.useTraditionalViewForApplicationsLogs);
            jQuery('input[name="OCLServiceLogTraditionalViewOption"]').prop('checked', options.useTraditionalViewForServiceLogs);
        } else {
            jQuery("#OCLUserConfigInput").val(JSON.stringify(this.DEFAULT_CLOUDWATCH_USER_CONFIG, null, 4));
        }
        this.setOCLPopupRemoteConfigValue();
    },

    setOCLPopupRemoteConfigValue: function() {
        if (this.remoteConfig.cwConfig) {
            var remoteConfigButtonTextSuffix = " (" + Object.keys(this.remoteConfig.cwConfig).length + " services)";
            jQuery("#OCLToggleRemoteConfigButton").html("Remote configurations" + remoteConfigButtonTextSuffix);
            jQuery("#OCLRemoteConfigInput").val(JSON.stringify(this.remoteConfig, null, 4));
        }
    },

    isOCLConfigPresent: function(service, marketplace, dataset) {
        return this.mergedConfig.cwConfig && this.mergedConfig.cwConfig[service + "#" + marketplace + "#" + dataset];
    },

    getOCLConfig: function(service, marketplace, dataset) {
        return this.isOCLConfigPresent(service, marketplace, dataset) ? this.mergedConfig.cwConfig[service + "#" + marketplace + "#" + dataset] : {};
    },

    isRemoteSyncEnabled: function() {
        return this.mergedConfig.options && this.mergedConfig.options.allowRemoteSync;
    },

    isDeepLinkEnabled: function() {
        return this.mergedConfig.options && this.mergedConfig.options.useDeepLinks;
    },

    isTraditionalViewEnabledForApplicationLogs: function() {
        return this.mergedConfig.options && this.mergedConfig.options.useTraditionalViewForApplicationsLogs;
    },

    isTraditionalViewEnabledForServiceLogs: function() {
        return this.mergedConfig.options && this.mergedConfig.options.useTraditionalViewForServiceLogs;
    }

};

function fixCutOffIconsAndLinksOnEmbeddedGraphPopins() {
    // If we're running on the grapher.cgi page, inside an iFrame, then add padding
    // to the top of the documentso that the toolbar for the popin window won't cover
    // the iGraph helper icons.
    // This is to fix the case when grapher.cgi is embedded on the show servcies page
    // E.G. on this page: http://tiny/16nvko8ie/lbdaamazcgibshow )
    if (/grapher.cgi/.test(window.location.pathname) && window.parent !== window) {
        $(document.body).css({paddingTop: '25px'});
    }

    // Poll and look for graphs from grapher.cgi that are inside popin windows,
    // make the iFrame fit the jQuery dialog and increase the side of the dialog
    // a little. This prevents the links at the bottom of grapher.cgi from being
    // cut off/hidden.
    // I don't know what specific pages embed graphs like this. I know it's on
    // the showServices tool, but I don't know where else it happens. I need to
    // poll because these dialogs are added dynamically after page load. To
    // avoid too large a performance hit, I'll poll rapidly for the first five
    // seconds and then only poll every 5 seconds after that point.
    var fixGrapherPopinSizing = function(){
        $('iframe[src*="grapher.cgi"]:not(.resizeFixed)').addClass('resizeFixed').css({
            width:'100%',
            height:'100%'
        }).parents('div.ui-dialog-content').css({
            height:'500px'
        });
    }
    for(var time=0; time < 5000; time += 500) {
        window.setTimeout(fixGrapherPopinSizing,time);
    }
    window.setInterval(fixGrapherPopinSizing,5000);
}

function injectMainIGraphHelper() {

    codeWrapper(localGMCode);

    if(!allowsInlineScripts()) {
        return;
    }

    setupCloudwatchCallback();

    // Expose jQuery to page context for DOM-to-PNG snapshot to find elements
    if (typeof unsafeWindow !== 'undefined' && !unsafeWindow.jQuery) {
        unsafeWindow.jQuery = jQuery;
    }

    setTimeout(() => {
        const IGHVersion = Number(GM_info && GM_info.script ? GM_info.script.version : -1) || -1;
        console.log('IGH Version', IGHVersion);
        // Not present if blocked by Content-Security-Policy
        if(unsafeWindow.iGraphHelper) {
            unsafeWindow.iGraphHelper.IGH.version = IGHVersion;
        }
    }, 0);
}

/**
 * Fixed setupCloudwatchCallback() for iGraph Helper
 *
 * Original bugs fixed:
 *   1. Replacing `this.onload` destroys page handlers set after send()
 *   2. `Object.defineProperty(this, "response")` throws "Permission denied"
 *      on cross-origin XHRs in some browsers
 *   3. `postMessage` listener with `window.location.reload()` runs on ALL
 *      pages (outside the CloudWatch guard), causing reloads on non-CW pages
 *   4. Every XHR response is JSON-parsed even when unnecessary
 *
 * What this preserves (no regression):
 *   - GetDashboard response interception still works
 *   - Vertical line annotations from iGraph are still merged into metric widgets
 *   - EphemeralDataStore (localStorage) flow is unchanged
 *   - postMessage → store → reload → merge cycle is unchanged
 *   - _.merge() widget merging logic is identical
 */
function setupCloudwatchCallback() {

    class EphemeralDataStore {
        constructor() {
            this.key = `${window.location.href}|||mergableMetricContent`;
        }

        put(data) {
            localStorage.setItem(this.key, JSON.stringify(data));
        }

        retrieve() {
            const val = JSON.parse(localStorage.getItem(this.key));
            localStorage.removeItem(this.key);
            return val;
        }
    }

    const store = new EphemeralDataStore();

    if (onCloudWatchUI || isDashboardInternal) {
        const OPEN_ACTUAL = unsafeWindow.XMLHttpRequest.prototype.open;
        const SEND_ACTUAL = unsafeWindow.XMLHttpRequest.prototype.send;

        // Patch open() to record the request URL on the XHR instance
        unsafeWindow.XMLHttpRequest.prototype.open = function (method, url) {
            this._ighUrl = url;
            return OPEN_ACTUAL.apply(this, arguments);
        };

        unsafeWindow.XMLHttpRequest.prototype.send = function () {
            // Only intercept requests that could be GetDashboard calls
            const url = String(this._ighUrl || '');
            const mayBeDashboardReq =
                url.includes('monitoring') ||
                url.includes('cloudwatch') ||
                url.includes('GetDashboard');

            if (mayBeDashboardReq) {
                // Use readystatechange — fires BEFORE load/onload, so the
                // modified response is visible to every subsequent handler.
                this.addEventListener('readystatechange', function () {
                    try {
                        if (this.readyState !== XMLHttpRequest.DONE) return;

                        let json;
                        try {
                            json = JSON.parse(this.response);
                        } catch {
                            return; // Not JSON — nothing to do
                        }

                        if (!json.Dashboard) return; // Not a GetDashboard response

                        let data = JSON.parse(json.Dashboard);
                        unsafeWindow.mergableMetricContent =
                            store.retrieve() ?? unsafeWindow.mergableMetricContent;

                        if (!unsafeWindow.mergableMetricContent) return; // Nothing to merge

                        data.widgets.map(widget => {
                            if (widget.type === 'metric') {
                                return _.merge(widget, unsafeWindow.mergableMetricContent);
                            }
                            return widget;
                        });
                        json.Dashboard = JSON.stringify(data);

                        const modified = JSON.stringify(json);
                        try {
                            Object.defineProperty(this, 'response', {
                                writable: true, configurable: true,
                            });
                            this.response = modified;
                        } catch {
                            // Browser blocked response override — fall through
                        }
                        try {
                            Object.defineProperty(this, 'responseText', {
                                writable: true, configurable: true,
                            });
                            this.responseText = modified;
                        } catch {
                            // Browser blocked responseText override — fall through
                        }
                    } catch (error) {
                        console.warn('[iGraph Helper] Dashboard merge error:', error);
                    }
                });
            }

            SEND_ACTUAL.apply(this, arguments);
        };

        // postMessage listener INSIDE the CloudWatch guard — only runs on CW pages
        window.addEventListener('message', (event) => {
            // Validate origin - only accept messages from same origin
            if (event.origin !== window.location.origin) {
                return;
            }
            if (
                typeof event.data === 'object' &&
                !Array.isArray(event.data) &&
                event.data?.properties?.annotations
            ) {
                store.put(event.data);
                window.location.reload();
            }
        }, false);
    }
}

function initWikiSnapshot() {
    if (! this.WikiSnapshot) {
        localGMCode(window, unsafeWindow);
        WikiSnapshot.initialize();
    }
}

// Checks whether Content-Security-Policy in <meta> tag allows injecting inlines scripts.
// Covers AWS Console use cases, but best effort only. By design there is no way to test
// it without causing an actual violation.
function allowsInlineScripts() {
    var csp = document.querySelector('meta[http-equiv="Content-Security-Policy"]');
    if(!csp || !csp.content) {
        return true;
    }
    var getDirective = function(directiveName) {
        return csp.content.split(";").find(d => d.includes(directiveName + " "));
    }
    var scriptSrcElem = getDirective("script-src-elem");
    if(scriptSrcElem) {
        // CSP detection only — reading existing page policy, not setting or injecting unsafe-inline
        return scriptSrcElem.includes("'unsafe-inline'");
    }
    var scriptSrc = getDirective("script-src");
    if(scriptSrc) {
        // CSP detection only — reading existing page policy, not setting or injecting unsafe-inline
        return scriptSrc.includes("'unsafe-inline'");
    }
    var defaultSrc = getDirective("default-src");
    if(defaultSrc) {
        // CSP detection only — reading existing page policy, not setting or injecting unsafe-inline
        return defaultSrc.includes("'unsafe-inline'");
    }
    return true;
}

// Refresh Alpine link visibility on CloudWatch Console, needed in restricted regions
function refreshAlpineLinkVisibility(win) {
    if (win.CloudWatchBridge && win.CloudWatchBridge.refreshAlpineLinkVisibility) {
        win.CloudWatchBridge.refreshAlpineLinkVisibility();
    }
}

function exposeSnapshotFunction(unsafeWin) {
    if (typeof createObjectIn !== 'undefined') {
        function snapshot(selector) {
            initWikiSnapshot();
            // Try to find the graph element from the page context
            var node = unsafeWin.document.querySelector(selector);
            // Also search inside iframes
            if (!node) {
                var iframes = unsafeWin.document.querySelectorAll('iframe');
                for (var i = 0; i < iframes.length; i++) {
                    try {
                        node = iframes[i].contentDocument && iframes[i].contentDocument.querySelector(selector);
                        if (node) break;
                    } catch(e) {}
                }
            }
            if (node) {
                // Find the highcharts container (graph + legend)
                var target = node.querySelector('[data-testid="metric-widget"]') || node.querySelector('.chartContainerOfWidget') || node;
                WikiSnapshot.snapshotDisplayInPopup(Lightbox.display, null, 'Snapshot from CloudWatch graph', false, null);
                WikiSnapshot.snapshotHtmlNode(target, window.location.href);
                return;
            }
            WikiSnapshot.snapshotDisplayInPopup(Lightbox.display, null, 'Snapshot jQuery selector: ' + selector, false, selector);
        };
        const iGraphHelperSnapshot = createObjectIn(unsafeWin, {defineAs: "iGraphHelperSnapshot"});
        exportFunction(snapshot, iGraphHelperSnapshot, {defineAs: "snapshot" });
    }
}

// Check if on Wiki or Apollo
var onWiki = (null != document.body.className.match("mediawiki")) || (/http[s]*:..apollo.([a-zA-Z]{3}.)?(amazon.com|[a-zA-Z0-9]{3}-border.[.a-zA-Z0-9]+)/.test(window.location.href));
var isDashboardInternal = (/dashboardInternal/.test(window.location.pathname));
var onCloudWatchUI = (/cloudwatch\/home/.test(window.location.pathname));
var onObserve = (/(observe|observe-gamma|cw-dashboards|cw-dashboards-gamma).aka.amazon/.test(window.location.hostname));
var onPremonition = (/(premonition-ui|pui|ui.premonition|awsdashboard)/.test(window.location.hostname));
var onPipelinesRevisionUI = (/https:\/\/pipelines\.amazon\.com\/pipelines\/.+\/revisions/.test(window.location.href));
var onPipelinesDeploymentGroupUI = (/https:\/\/deployment-group\.pipelines\.a2z\.com\/deployments/.test(window.location.href));

(function() {
    iGraphHelperMain();
})();

function iGraphHelperMain() {
    try {
        GM_registerMenuCommand("iGraph Helper: snapshot settings", () => {
            const inputString = prompt(
                'To use a fixed size for snapshots please enter your desired size in the format "width,height".\n' +
                'For this value to take effect, you must uncheck "Obey Fit".\nEnter "0,0" to clear.'
            )
            console.log("Setting snapshot size from input", inputString)
            WikiSnapshot.setSnapshotSizeSettingFromString(inputString)
        });

        GM_registerMenuCommand("iGraph Helper: snapshot DOM element", () => {
            initWikiSnapshot();
            WikiSnapshot.snapshotDomElement();
        });

        GM_registerMenuCommand("iGraph Helper: snapshot clipboard image", () => {
            initWikiSnapshot();
            WikiSnapshot.snapshotDisplayInPopup(Lightbox.display, null, 'Click into box above and paste image from clipboard, or drop image files in (Chrome, FF)', false, null);
        });

        GM_registerMenuCommand("iGraph Helper: set OneClickLogs settings", () => {
            OCLSettingsManager.initialize();
            OCLSettingsManager.showSettingsPopup();
            OCLSettingsManager.refreshRemoteOCLConfig(true);
        });

        GM_registerMenuCommand("iGraph Helper: refresh graphs slowly", () => {
            RefreshGraphs.refreshSlowly();
        });

        GM_registerMenuCommand('iGraph Helper: show cart', () => {
            if (unsafeWindow.iGraphHelper && unsafeWindow.iGraphHelper.IGH) {
                unsafeWindow.iGraphHelper.IGH.WikiCart.showOpenedCart();
            } else {
                alert('Shopping cart not supported on this page');
            }
        });

        GM_registerMenuCommand("iGraph Helper: tiny current URL (Ctrl-Y)", () => {
            Tinify.tiny();
        });

        if (onWiki || onCloudWatchUI || onObserve || onPremonition || onPipelinesRevisionUI || onPipelinesDeploymentGroupUI) {
            if (onCloudWatchUI || (onObserve && !isDashboardInternal)) {
                localGMCode(window, unsafeWindow);
            } else {
                localGMCode(unsafeWindow, unsafeWindow);
            }
            WikiSnapshot.initialize();

            if (WikiSourceEditor.onEditPage()) {
                if (WikiSourceEditor.onSourceEditor()) {
                    WikiSourceEditor.initialize();
                }
            } else {

                WikiSnapshot.initialize();
                IGraphSettings.initialize();
                ApolloDeployments.initialize();
                PipelineDeployments.initialize();
                WikiVerticality.initialize();
                InteractiveWikiGraphs.initialize();
                GMUtils.initialize();
                WikiBulkSnapshot.initialize();
                if (onCloudWatchUI || onObserve) {
                    injectMainIGraphHelper();
                }
            }
        }
        else if (/^weblab.*[.]amazon[.]com$/.test(window.location.host)) {
            WebLabTimes.initialize();
        }
        else if (/http.*:[/][/]carnaval(-dr)?.([a-zA-Z]{3}.)?(amazon.com|[a-zA-Z0-9]{3}-border.[.a-zA-Z0-9]+)[/](v1)?/.test(window.location.href)) {
            Carnaval.initialize();
        }
        // Check if there are iGraphs, collections or monitors on the page
        else if ((document.images.length > 0 || (/collections|metrics\/monitors.*id=/.test(window.location.href)))
          || document.title === 'SIM Ticketing'
          || document.title === 'HALP'
        ) {
            localGMCode(unsafeWindow, unsafeWindow);
            GMUtils.initialize();
            WikiSnapshot.initialize();
            IGraphPage.initialize();
            injectMainIGraphHelper();
        } else {
            localGMCode(unsafeWindow, unsafeWindow);
        }
        if (this.Tinify) {
            Tinify.initialize();
            AsciiArtGraphGenerator.initialize();
            PipelinesRediForkIntegration.initialize();
        }

        fixCutOffIconsAndLinksOnEmbeddedGraphPopins();
        refreshAlpineLinkVisibility(unsafeWindow);
        exposeSnapshotFunction(unsafeWindow);
    }
    catch(ex) {
        if (typeof(console) !== 'undefined') {
            if (console.error) {
                console.error('iGraph Helper Error: ',ex)
            }
            else if (console.log) {
                console.log('iGraph Helper Error: ',ex);
            }
        }
    }
}
