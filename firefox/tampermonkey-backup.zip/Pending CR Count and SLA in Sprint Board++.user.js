// ==UserScript==
// @name         Pending CR Count and SLA in Sprint Board++
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  An second extension of Pending CR Count and SLA in Sprint Board - uses data from the cr events endpoint to give more insights into the state of CR's.
// @author       jackfein
// @include      https://issues.amazon.com/*
// @include      https://sim.amazon.com/*
// @include      https://i.amazon.com/*
// @include      https://issues-pdx.amazon.com/*
// @grant        GM_xmlhttpRequest
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_addStyle
// @grant        GM_getResourceText
// @grant        GM_getResourceURL
// @grant        unsafeWindow
// @connect      code.amazon.com
// @connect      maxis-service-prod-pdx.amazon.com
// @connect      axzile.corp.amazon.com
// @downloadURL  https://axzile.corp.amazon.com/-/carthamus/download_script/pending-cr-count-and-sla-in-sprint-board.user.js
// @updateURL    https://axzile.corp.amazon.com/-/carthamus/download_script/pending-cr-count-and-sla-in-sprint-board.user.js
// ==/UserScript==

(function() {
    'use strict';

    const LOOKBACK_DAYS = 90; // CR data is fetched within this time range from current date
    const CR_ENDPOINT = 'https://code.amazon.com';

    // sometimes jQuery is not ready when this script is executed
    // so checking whether jQuery is loaded, in 1s intervals.
    // Other possible solution for this problem is to use @require in the
    // script meta, however this might break when SIM updates their jQuery version.
    if (typeof jQuery === 'undefined') {
        window.setTimeout(arguments.callee, 100);
        return;
    }

    GM_addStyle(`
    .loader {
      border: 10px solid #f3f3f3;
      border-radius: 50%;
      border-top: 10px solid #3498db;
      width: 80px;
      height: 80px;
      margin-left: 50%;
      -webkit-animation: spin 2s linear infinite; /* Safari */
      animation: spin 2s linear infinite;
    }
    .approver-text-element:hover .approver-handle-text {
        text-decoration: underline;
    }
    .approver-text-element > .approver-icon + .approver-icon,
    .approver-text-element:hover > .approver-icon {
      display: none;
      color: red;
      cursor: pointer;
    }
    .approver-text-element:hover > .approver-icon + .approver-icon {
      display: inherit;
    }
    /* Safari */
    @-webkit-keyframes spin {
      0% { -webkit-transform: rotate(0deg); }
      100% { -webkit-transform: rotate(360deg); }
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }`);

    let crGroups = "";
    let crSla = 1;
    let extraAliases = ""

    let TEAMS = [];
    let CR_SLA = 1; // SLA of cr defined is 2 day, if last touched date of CR is before 2 Day's then script will flag that.

    let isCrDataFetched = false;

    let users = [];
    let container, spinner;

    /**
     * Entry point for all the function in this script. I have added document.getElementById('pending_cr_container') === null check
     * because of pageURLCheckTimer method calling init() multiple time which creates and multiple element to body.
     *
     * @returns {Promise<void>}
     */
    let init = async () => {
        if (window.location.toString().indexOf('sprints') > -1 && document.getElementById('pending_cr_container') === null) {
            await setUp();
            container = createPendingCrViewContainer();
            spinner = getSpinnerElement();
            $('body').append(container);
            container.appendChild(spinner);
            CR_SLA = crSla;
            TEAMS = crGroups.split(',');
            await getUserFromSprintBoard();
        }
    };

    /**
     * Get values from GM Store
     *
     * @returns {Promise<void>}
     */
    let setUp = async () => {
        createResetButton();
        let crGroupsValue = await GM_getValue('crGroups');
        let crSlaValue = await GM_getValue('crSla');
        let extraAliasesValue = await GM_getValue('extraAliases');

        if (!crGroupsValue || !crSlaValue) {
            prompt();
        } else {
            crGroups = crGroupsValue;
            crSla = crSlaValue;
            extraAliases = extraAliasesValue;
        }
    };

    /**
     * Open a prompt to take input for CR Groups and Cr SLA
     *
     */
    let prompt = () => {
        let prompter = document.createElement("div");
        prompter.innerHTML = '<h2>  Please enter the CR group (Like concessions-execution), SLA in days, and any extra aliases to be included on the board  </h2>' +
            '<h3 style="color: gray;">(You only need to do it once)</h3><br>' +
            '<div class="hook-group">' +
            '<label for="cr-group-input">CR Groups (Comma Separated):</label>' +
            '<input style="width: 40%" type="text" id="cr-group-input" />' +
            '</div>' +
            '<div class="hook-group">' +
            '<label for="cr-sla">SLA in Days:</label>' +
            '<input style="width: 40%" type="number" id="cr-sla" />' +
            '</div>' +
            '<div class="hook-group">' +
            '<label for="extra-aliases-input">Extra Aliases (Comma Separated):</label>' +
            '<input style="width: 40%" type="text" id="extra-aliases-input" />' +
            '</div>';
        prompter.style = "position: fixed; background-color: white; z-index:100; float: right; width: 100%; height: auto; font-size: 14pt; text-align: center; border:1px solid black; margin: 0px auto;";

        let crGroupInput = prompter.querySelector("#cr-group-input");
        crGroupInput.value = crGroups || "";

        let crSlaInput = prompter.querySelector("#cr-sla");
        crSlaInput.value = crSla || "";

        let extraAliasesInput = prompter.querySelector("#extra-aliases-input");
        extraAliasesInput.value = extraAliases || "";

        let submitHooks = document.createElement("button");
        submitHooks.innerText = "Submit";

        submitHooks.onclick = () => {
            let crGroupInputValue = document.getElementById("cr-group-input").value;
            let crSlaInputValue = document.getElementById("cr-sla").value;
            let extraAliasesInputValue = document.getElementById("extra-aliases-input").value;
            if (crGroupInputValue && crSlaInputValue) {
                crGroups = crGroupInputValue;
                crSla = crSlaInputValue;
                extraAliases = extraAliasesInputValue;
                GM_setValue("crGroups", crGroupInputValue);
                GM_setValue("crSla", crSlaInputValue);
                GM_setValue("extraAliases", extraAliasesInputValue);
                prompter.parentElement.removeChild(prompter);
            } else {
                alert("Please enter both the details or cr group will be empty and CR SLA will be set to 2 Days");
                prompter.parentElement.removeChild(prompter);
            }
        };
        prompter.appendChild(submitHooks);
        let body = document.querySelector("body");
        body.insertBefore(prompter, body.firstChild);
    };

    /**
     * Creates a reset button at top right corner for changing the CR group
     */
    let createResetButton = () => {
        let navbar = document.querySelector("nav.nav-collapse").firstChild;
        let resetHooks = document.createElement("button");
        resetHooks.style.cssFloat = 'right';
        resetHooks.style.marginTop = '10px';
        resetHooks.onclick = () => {
            navbar.removeChild(resetHooks);
            prompt();
        };
        resetHooks.innerText = "Reset CR Group";
        navbar.appendChild(resetHooks);
    };

    /**
     * it try to read all the ajax call made from the page and find the ajax which returns the list of the user in from that.
     * and after completion it calls the code.amazon.com to get the CR data and start the rendering process.
     * I was unable to waith for this method so I nested the calls
     *
     * @returns {Promise<void>}
     */
    let getUserFromSprintBoard = async () => {
        $(document).ajaxSuccess(async function(event, xhr, settings) {
            if (settings.url.indexOf('/issues?q=aggregatedLabels') > -1) {
                try {
                    var response, i, assignee, user;
                    response = JSON.parse(xhr.responseText);
                    if (!response.documents || !response.documents.length) {
                        return;
                    }
                    for (i = 0; i < response.documents.length; i++) {
                        assignee = response.documents[i].assigneeIdentity;
                        if (assignee) {
                            user = assignee.replace(/kerberos:([a-z]+)@.*/i, '$1');
                            if (users.indexOf(user) === -1) {
                                users.push(user);
                            }
                        }
                    }
                    if (extraAliases) users.push(...extraAliases.split(','));
                    if (users.length > 0 && !isCrDataFetched) {
                        isCrDataFetched = true;
                        let pendingCrCountPromises = [];
                        pendingCrCountPromises.push(getPendingCrCounts(users));
                        pendingCrCountPromises.push(getPendingCrCounts(TEAMS, true));

                        let rawCrData = await Promise.all(pendingCrCountPromises);
                        let groupCrData = rawCrData[1];

                        rawCrData = rawCrData[0].concat(rawCrData[1]);

                        // EXTENSION
                        let allCodeReviewData = {};
                        let allCodeReviewOrder = [];
                        let allCount = 0;
                        let allSlaMissed = 0;

                        rawCrData.map(item => {
                            for (let value of item.values()) {
                                if (value.isTeam) {
                                    Object.keys(value.codeReviewData).map(key => {
                                        if (!allCodeReviewData[key]) {
                                            allCodeReviewData[key] = value.codeReviewData[key];
                                            allCount++;
                                            if (value.codeReviewData[key].isSlaMissed) allSlaMissed++;
                                        }
                                    });
                                    value.codeReviewOrder.map(cr => allCodeReviewOrder.push(cr));
                                }
                            }
                        });

                        let allCrMap = new Map();
                        allCrMap.set('ALL', {
                            codeReviewData: allCodeReviewData,
                            codereviewOrder: allCodeReviewOrder,
                            count: allCount,
                            isTeam: true,
                            slaMissedCrCount: allSlaMissed
                        });
                        rawCrData.push(allCrMap);

                        const dataMap = createDataMap(rawCrData);

                        render(dataMap);
                        container.removeChild(spinner);
                    }
                } catch (e) {
                    console.log("Error occur while executing the script:\n" +
                        "Please check the wiki: https://w.amazon.com/index.php/Ranishan/Pending_CR_on_Sprint_Board and comment your issue", e);
                    container.removeChild(spinner);
                    // Borrowing SIM's undocumented "App" to display the Toast-like notification.
                    unsafeWindow.App.Lib.Notifications.error('Error occur while executing the CR script. ' +
                        'Please check the wiki: https://w.amazon.com/index.php/Ranishan/Pending_CR_on_Sprint_Board and comment your issue');
                }
            }
        });
    };

    /**
     * This handles the HTML generation part.
     *
     * @returns {HTMLDivElement}
     */
    let createPendingCrViewContainer = () => {
        let pendingCrContainer = document.createElement('div');
        pendingCrContainer.classList.add("container-fluid");
        pendingCrContainer.id = 'pending_cr_container';
        pendingCrContainer.style.padding = '4px';
        pendingCrContainer.style.background = '#fff';
        pendingCrContainer.style.marginLeft = '0.5%';
        pendingCrContainer.style.borderRadius = '5px';
        pendingCrContainer.style.width = '98.8%';

        let headerTextRow = document.createElement('div');
        headerTextRow.classList.add('row');

        let containerHeading = document.createElement("h1");
        containerHeading.textContent = 'Pending CRs on approvers';
        containerHeading.style.float = 'left';
        containerHeading.style.padding = '5px';

        headerTextRow.appendChild(containerHeading);
        pendingCrContainer.appendChild(headerTextRow);

        return pendingCrContainer;
    };

    /**
     * Render the pending CR count and the SLA information at bottom of sprint board.
     *
     * @param dataMap  the data map containing the details of the CR and the Users
     */
    let render = (dataMap) => {
        const sortedUserDataMap = new Map([...dataMap.userDataMap.entries()]
            .sort((a, b) => b[1].count - a[1].count));

        let pendingCrRow= document.createElement('div');
        pendingCrRow.classList.add('row');

        let paragraph = document.createElement('p');

        pendingCrRow.appendChild(paragraph);

        container.appendChild(pendingCrRow);

        for (let [user, data] of sortedUserDataMap.entries()) {
            let pendingCrCol = document.createElement('div');
            pendingCrCol.classList.add('col');
            pendingCrCol.style.width = '220px';
            pendingCrCol.style.float = 'left';
            pendingCrCol.style.margin = '5px';
            pendingCrCol.id = 'pending_cr_col_' + user;

            let pendingCrButton = document.createElement('button');
            pendingCrButton.classList.add('btn');
            pendingCrButton.classList.add('btn-default');
            pendingCrButton.classList.add('btn-lg');
            pendingCrButton.style.width = '100%';
            pendingCrButton.id = 'pending_cr_button_' + user;
            pendingCrButton.setAttribute('alias', user.toString());
            pendingCrButton.onclick = function (event) {
                pendingCrButtonClickHandler(event, user, dataMap);
            };

            let userImageAndAliasContainer = document.createElement('div');
            userImageAndAliasContainer.style.width = '30%';
            userImageAndAliasContainer.style.float = 'left';
            userImageAndAliasContainer.style.textOverflow = 'ellipsis';

            if (user != 'ALL') {
                let userImage = document.createElement('img');
                userImage.src = 'https://internal-cdn.amazon.com/badgephotos.amazon.com/?uid=' + (data.isTeam ? 'nobody' : user);
                userImage.title = user.toLocaleString();
                userImage.style.cssFloat = 'left';
                userImage.style.width = "60%";
                userImage.id = 'user_image_id_' + user;

                userImageAndAliasContainer.appendChild(userImage);
            }

            let userAlias = document.createElement(user == 'ALL' ? 'p' : 'a');
            userAlias.textContent = user == 'ALL' ? 'All Groups' : user.toLocaleString();
            userAlias.style.whiteSpace = "nowrap";
            if (user != 'ALL') {
                userAlias.href = getUserUrl(user, data.isTeam);
                userAlias.target = '_blank';
            }
            userAlias.style.cssFloat = 'left';
            if (user == 'ALL') {
                userAlias.style.margin = "40% 0";
            }
            userAlias.id = 'user_alias_id_' + user;

            userImageAndAliasContainer.appendChild(userAlias);

            pendingCrButton.appendChild(userImageAndAliasContainer);

            let textDetailsContainer = document.createElement('div');
            textDetailsContainer.style.width = '100px';
            textDetailsContainer.style.float = 'right';

            pendingCrButton.appendChild(getMissedSlaTextElement(data.slaMissedCrCount));
            pendingCrButton.appendChild(getPendingCrCountElement(user, data.count, data.isTeam));

            pendingCrCol.appendChild(pendingCrButton);
            paragraph.appendChild(pendingCrCol);

            if (user == 'ALL') {
                pendingCrButton.click();
            }
        }
    };

    /**
     * Generate the DOM element for displaying Pending CR count on the user inside a button.
     * It also contains element for the user badge displaying inside the button.
     *
     * @param user  the user for on whome CR is pending
     * @param pendingCrCount  the pending CR on the given user
     * @param isTeam  the flag to distinguish between team and the user
     * @returns {HTMLDivElement} which display the pending CR count on the user
     */
    let getPendingCrCountElement = (user, pendingCrCount, isTeam) => {
        let pendingCrCountDiv = document.createElement('div');
        pendingCrCountDiv.style.cssFloat = 'right';
        pendingCrCountDiv.style.marginTop = '1.1%';
        pendingCrCountDiv.style.height = '30px';

        let pendingCrCountLink = document.createElement('a');
        pendingCrCountLink.innerHTML = '<b>' + pendingCrCount + '</b>';
        pendingCrCountLink.href = getEndpoint(user, isTeam);
        pendingCrCountLink.target =  '_blank';


        let pendingCrCountDescription = document.createElement('span');
        pendingCrCountDescription.style.width = '100%';
        pendingCrCountDescription.style.cssFloat = 'right';
        pendingCrCountDescription.innerHTML = '<b>Pending CR - </b>';

        pendingCrCountDescription.appendChild(pendingCrCountLink);

        pendingCrCountDiv.appendChild(pendingCrCountDescription);
        return pendingCrCountDiv;
    };

    /**
     * Generate the missed sla count element.
     * It create a right float element which has heading as missed sla count
     *
     * @param missedSlaCount  the number of CR pending on the user and has misses the SLA
     * @returns {HTMLDivElement} containing description and missed SLA count
     */
    let getMissedSlaTextElement = (missedSlaCount) => {
        let missedSlaCrCountDiv = document.createElement('div');
        missedSlaCrCountDiv.style.cssFloat = 'right';
        missedSlaCrCountDiv.style.marginTop = '1.1%';
        missedSlaCrCountDiv.style.height = '30px';

        let missedSlaCrCountDescription = document.createElement('span');
        missedSlaCrCountDescription.style.width = '100%';
        missedSlaCrCountDescription.innerHTML = '<b>Missed SLA - </b>';


        let missedSlaCrCountHeading = document.createElement('span');
        missedSlaCrCountHeading.innerHTML = '<b>' + missedSlaCount + '</b>';
        missedSlaCrCountHeading.style.marginTop = '7%';
        missedSlaCrCountHeading.style.width = '100%';

        if (missedSlaCount > 0) {
            missedSlaCrCountHeading.style.color = 'red';
        }

        missedSlaCrCountDiv.appendChild(missedSlaCrCountDescription);
        missedSlaCrCountDiv.appendChild(missedSlaCrCountHeading);

        return missedSlaCrCountDiv;
    };

    /**
     * Pending CR button click handler.
     *
     * @param event  the click event
     * @param user  the user on which CR are pending
     * @param dataMap  the data map containing the details about CR pending on the user
     */
    let pendingCrButtonClickHandler = (event, user, dataMap) => {
        removeElementByClassName('user_cr_details_container');
        container.appendChild(getUserCrDetailsDom(user, dataMap));
    };

    /**
     * Removes all the element in the document having the given class name
     *
     * @param className  the class name of element which is to be removed
     */
    let removeElementByClassName = (className) => {
        document.querySelectorAll('.' + className).forEach(e => e.remove());
    };

    /**
     * Generates DOM for detailed displaying of the CR data which are pending on the user.
     *
     * @param user  the user for which data are to be displayed(pending CR on the user)
     * @param dataMap  the data map containing details about the user and the CRs
     * @returns {HTMLDivElement} containing the tabled element for details CR data displaying.
     */
    let getUserCrDetailsDom = (user, dataMap) => {
        let userCrDetailsContainer = document.createElement('div');
        userCrDetailsContainer.classList.add('user_cr_details_container');
        userCrDetailsContainer.id = 'user_cr_details_container_' + user;
        userCrDetailsContainer.style.border = 'thick solid #000';

        let userCrDetailsHeadingRow = document.createElement('div');
        userCrDetailsHeadingRow.classList.add('row');
        userCrDetailsHeadingRow.id = 'user_cr_details_heading_row_' + user;

        let userCrDetailsHeadingText = document.createElement('h1');
        userCrDetailsHeadingText.textContent = 'CRs pending on ' + user;
        userCrDetailsHeadingText.style.textAlign = 'center';

        userCrDetailsHeadingRow.appendChild(userCrDetailsHeadingText);

        let userCrDetailsRow = document.createElement('div');
        userCrDetailsRow.classList.add('row');
        userCrDetailsRow.id = 'user_cr_details_row_' + user;

        userCrDetailsContainer.appendChild(userCrDetailsHeadingRow);
        userCrDetailsContainer.appendChild(userCrDetailsRow);

        let table = getCrDetailsTable(user, dataMap);

        userCrDetailsRow.appendChild(table);

        return userCrDetailsContainer;
    };

    /**
     * Generates the tables containing CR details like CR id, description, SLA missed etc.
     * Please check the tables header formation for the details. Ideally that should be moved out of this method
     * but I am feeling lazy.
     *
     * @param user  the user for which data is to be displayed in the table(user on which cr is pending)
     * @param dataMap  the data map containing details about the CR and user
     * @returns {HTMLTableElement} containing tables with the details.
     */
    let getCrDetailsTable = (user, dataMap) => {
        let table = document.createElement('table');
        table.style.width = 'inherit';
        table.style.padding = '2px';
        table.style.cssFloat = 'left';
        table.style.border = 'thin solid #000';

        const userCrDetails = dataMap.userDataMap.get(user);

        let codeReviewData = userCrDetails.codeReviewData;

        const sortedUserDataMap = new Map(
            Object.keys(codeReviewData)
                .map((key) => [key, codeReviewData[key]])
                .sort(
                    (first, second) =>
                        first[1].lastTouchedTime.getTime() - second[1].lastTouchedTime.getTime()));

        let header = table.createTHead();
        let headerRow = header.insertRow(0);
        header.style.border = 'thin solid #000';
        // Tables headers
        headerRow.insertCell(0).innerHTML = '<b>Author</b>';
        headerRow.insertCell(1).innerHTML = '<b>CR Id</b>';
        headerRow.insertCell(2).innerHTML = '<b>Missed SLA</b>';
        headerRow.insertCell(3).innerHTML = '<b>Description</b>';
        headerRow.insertCell(4).innerHTML = '<b>Revision</b>';
        headerRow.insertCell(5).innerHTML = '<b>Approved By</b>';
        headerRow.insertCell(6).innerHTML = '<b>Approvers</b>';
        headerRow.insertCell(7).innerHTML = '<b>Last Event</b>';
        headerRow.style.textAlign = 'center';


        let rowIndex = 0;
        let tableBody = table.createTBody();
        let slaMissedCrs = 0;
        // Table row generation logic
        for (let [crId, value] of sortedUserDataMap.entries()) {
            let row = tableBody.insertRow(rowIndex);
            row.style.padding = '3px';
            row.style.border = 'thin solid #000';


            let authorColElement = row.insertCell(0);

            let userImage = document.createElement('img');
            userImage.src = 'https://internal-cdn.amazon.com/badgephotos.amazon.com/?uid=' + value.author;
            userImage.title = value.author;
            userImage.style.cssFloat = 'left';
            userImage.style.width = "40px";
            userImage.textContent = value.author;

            let userAliasSpan = document.createElement('span');
            userAliasSpan.appendChild(getColumnHyperLinkElement(value.author, getUserUrl(value.author, false)));

            authorColElement.appendChild(userImage);
            authorColElement.appendChild(userAliasSpan);
            authorColElement.style.width = "9ch";
            authorColElement.style.display = 'flex';
            authorColElement.style.flexDirection = 'column';
            authorColElement.style.alignItems = 'center';


            let crIdColElement = row.insertCell(1);
            crIdColElement.appendChild(getColumnHyperLinkElement(crId, getCodeReviewUrl(crId)));
            crIdColElement.style.border = 'thin solid #000';
            crIdColElement.style.width = '12ch';
            crIdColElement.style.textAlign = 'center';

            let slaMissedColElement = row.insertCell(2);
            slaMissedColElement.textContent = value.isSlaMissed ? 'Yes' : 'No';
            slaMissedColElement.style.background = value.isSlaMissed ? '#ff3333' : '#4BB543';
            slaMissedColElement.style.textAlign = 'center';

            if (value.isSlaMissed) {
                slaMissedCrs++;
            }

            let summaryColElement = row.insertCell(3);
            summaryColElement.textContent = value.summary;
            summaryColElement.style.border = 'thin solid #000';
            summaryColElement.style.width = '30%';
            summaryColElement.style.padding = '7.5px';

            let revisionColElement = row.insertCell(4);
            revisionColElement.textContent = value.revision;
            revisionColElement.style.border = 'thin solid #000';
            revisionColElement.style.width = '4%';
            revisionColElement.style.textAlign = 'center';

            let approvedByColElement = row.insertCell(5);
            approvedByColElement.textContent = value.approvedBy;
            approvedByColElement.style.border = 'thin solid #000';
            approvedByColElement.style.width = '11ch';
            approvedByColElement.style.textAlign = 'center';

            let actionColumn = row.insertCell(6);
            actionColumn.appendChild(getApproversCellElement(crId, dataMap));
            actionColumn.style.width = '12.5%';

            let lastEventColElement = row.insertCell(7);
            lastEventColElement.textContent = value.lastEventText;
            lastEventColElement.style.border = 'thin solid #000';
            lastEventColElement.style.width = '30%';
            lastEventColElement.style.padding = '7.5px';

            rowIndex++;
        }
        table.createCaption().innerHTML = '<b>Missed SLA\'s CRs(SLA:' + CR_SLA + '): '+ userCrDetails.slaMissedCrCount +'</b>';
        return table;

    };

    /**
     * Creates the approver column element with the action defined within element.
     *
     * @param crId  the cr id for the row whose action column need to be generated
     * @param dataMap  the data map containing the details about CR and the approvers.
     * @returns {HTMLDivElement} containing the cell element
     */
    let getApproversCellElement = (crId, dataMap) => {
        let actionColumnContainer = document.createElement('div');
        actionColumnContainer.id = 'action-column-container-' + crId;
        actionColumnContainer.style.width = '100%';

        let approvers = dataMap.crDataMap.get(crId).get('approvers');

        let approverRemoveActionContainer = document.createElement('div');
        approverRemoveActionContainer.style.width = '40%';
        approverRemoveActionContainer.style.padding = '5px';
        approverRemoveActionContainer.id = 'approver-remove-action-container-' + crId;

        let approverAdditionActionContainer = document.createElement('div');
        approverAdditionActionContainer.style.width = '45%';
        approverAdditionActionContainer.style.float = 'right';
        approverAdditionActionContainer.style.padding = '5px';
        approverAdditionActionContainer.style.id = 'approver-addition-action-container-' + crId;

        actionColumnContainer.appendChild(approverAdditionActionContainer);
        actionColumnContainer.appendChild(approverRemoveActionContainer);

        approvers.forEach((approver) => {
            approverRemoveActionContainer
                .appendChild(getApproverRemovalActionElement(crId, approver));
        });

        approverAdditionActionContainer
            .appendChild(getApproverAdditionActionElement(crId, dataMap, approvers));

        return actionColumnContainer;
    };

    /**
     * Creates and return the action element for the approver action column.
     * This basically creates the remove approvers from the cr action.
     *
     * @param crId  the cr id whose row is to be modified
     * @param approver  the approver for which action need to be generated
     * @returns {HTMLDivElement} the action element defining the remove approvers.
     */
    let getApproverRemovalActionElement = (crId, approver, isSpinner = false) => {
        let approverTextDiv = document.createElement('div');
        approverTextDiv.id = 'approver-text-div-' + crId + '-' + approver;
        approverTextDiv.style.width = '100%';

        let approverTextElement = document.createElement('span');
        approverTextElement.id = 'approver-text-element-' + approver;
        approverTextElement.classList.add('approver-text-element');

        if (!isSpinner) {
            approverTextElement.appendChild(getIconElement('icon-time'));
            approverTextElement.appendChild(getIconElement('icon-remove-sign'));
        } else {
            approverTextElement.appendChild(getIconElement('icon-spinner', false));
        }

        let approverHandleElement = document.createElement('span');
        approverHandleElement.id = 'approver-handle-element-' + approver;
        approverHandleElement.textContent = approver;
        approverHandleElement.style.padding = '3px';
        approverHandleElement.classList.add('approver-handle-text');

        approverTextElement.appendChild(approverHandleElement);

        if (!isSpinner) {
            approverTextElement.onclick = function(event) {
                console.log("click", event);
                handleRemoveClick(event, crId, approver);
            };
        }

        approverTextDiv.appendChild(approverTextElement);

        return approverTextDiv;
    };

    /**
     * Handle the addition of approver action.
     * 1. Add spinning element with user name to show action in progress
     * 2. Create request for removal of approvers
     * 3. After response from code browser
     * 3.1 Success
     * 3.1.1 Remove spinning user element from the container
     * 3.1.2 Remove actual alias element with remove option enabled
     * 3.1.3 Add selected user alias from the dropdown list
     * 3.2 Failure
     * 3.2.1 Remove spinning element fon the container
     *
     * @param event  the click event for change in dropdown
     * @param crId  the cr id for the row on which action is performed
     * @param approver  the approver who is to be removed
     */
    let handleRemoveClick = (event, crId, approver) => {
        let target = event.target;
        let parentElement = target.parentElement;
        let parentDiv = parentElement.parentElement;
        parentElement.remove();

        let approverActionElement = getApproverRemovalActionElement(crId, approver, true);
        parentDiv.appendChild(approverActionElement);

        let url = getModifyCrUrl(crId, false);

        let requestData = {
            "entity_id" : {
                "type":"USER",
                "id": approver
            }
        };

        // Need to do this way to fetch the CSRF token of code browser
        ajaxGetPromise(`https://code.amazon.com/reviews/${crId}/`).then(function (response) {
            let parser = new DOMParser();
            let responseDocument = parser.parseFromString(response, 'text/html');
            let csrfToken = responseDocument.querySelector("meta[name=csrf-token]").content;
            ajaxPostPromise(url, requestData, csrfToken).then(function (response) {
                approverActionElement.remove();
                // Add option to drop down
                let dropDownOption = document.createElement('option');
                dropDownOption.text = approver.toString();
                dropDownOption.value = approver.toString();
                document.getElementById('approver-addition-dropdown-' + crId).add(dropDownOption);
            }, function (response) {
                approverActionElement.remove();
                parentDiv.appendChild(getApproverRemovalActionElement(crId, approver, false));
            });
        });
    };

    /**
     * Creates the approver addition action for the approver column.
     * It generates the dropdown for the approver list(All the people in the scrum board)
     *
     * @param crId  the cr id of the row whose action column need to be generated.
     * @param dataMap  the data map containing all the details about approvers and the CR.
     * @returns {HTMLSelectElement} containing the dropdown and corresponding action
     */
    let getApproverAdditionActionElement = (crId, dataMap, approvers) => {
        let approverAdditionSelectElement = document.createElement('select');
        approverAdditionSelectElement.style.width = '100%';
        approverAdditionSelectElement.id = 'approver-addition-dropdown-' + crId;
        approverAdditionSelectElement.onchange = function(event) {
            console.log("Chnage Event:", event);
            handleAddApproverClick(event, crId);
        };

        let userList = [...dataMap.userDataMap.entries()]
            .filter(data => data[1].isTeam !== true)
            .map(data => data[0]);

        userList.sort();

        let emptySelectedOption = document.createElement('option');
        emptySelectedOption.selected = true;
        emptySelectedOption.value = "";
        emptySelectedOption.text = 'Add';

        approverAdditionSelectElement.add(emptySelectedOption);

        userList.map((user) => {
            if (approvers.indexOf(user) === -1) {
                let dropDownOption = document.createElement('option');
                dropDownOption.text = user.toString();
                dropDownOption.value = user.toString();
                approverAdditionSelectElement.add(dropDownOption);
            }
        });

        return approverAdditionSelectElement;
    };

    /**
     * Handle the addition of approver action.
     * 1. Add spinning element with user name to show action in progress
     * 2. Create request for addition of approvers
     * 3. After response from code browser
     * 3.1 Success
     * 3.1.1 Remove spinning user element from the container
     * 3.1.2 Add actual alias element with remove option enabled
     * 3.1.3 remove selected user alias from the dropdown list
     * 3.2 Failure
     * 3.2.1 Remove spinning element fon the container
     *
     * @param event  the click event for change in dropdown
     * @param crId  the cr id for the row on which action is performed
     */
    let handleAddApproverClick = (event, crId) => {
        let approver = event.target.value;

        if (approver === null || approver === undefined || approver.length === 0) {
            return;
        }

        let approverDiv = event.target.parentElement.parentElement.childNodes[1];

        let approverActionElement = getApproverRemovalActionElement(crId, approver, true);
        approverDiv.appendChild(approverActionElement);

        let url = getModifyCrUrl(crId, true);

        let requestData = {
            "entity_id" : {
                "type":"USER",
                "id": approver
            },
            "required_count" : 1
        };

        ajaxGetPromise(`https://code.amazon.com/reviews/${crId}/`).then(function (response) {
            let parser = new DOMParser();
            let responseDocument = parser.parseFromString(response, 'text/html');
            let csrfToken = responseDocument.querySelector("meta[name=csrf-token]").content;
            ajaxPostPromise(url, requestData, csrfToken).then(function (response) {
                approverActionElement.remove();
                approverDiv.appendChild(getApproverRemovalActionElement(crId, approver, false));
                // Remove option from dropdown
                for (let index = 0 ; index < event.target.length ; index++) {
                    if (event.target.options[index].value === approver) {
                        event.target.remove(index);
                    }
                }
            }, function (response) {
                approverActionElement.remove();
            });
        });
    };

    /**
     * Return the approver modification url. This can be either remove or add approver
     *
     * @param crId  the cr id for which URL need to be generated
     * @param addApproverFlag  the add approver flag deciding whether to generate addition action on remove
     * @returns {string} having URL for code browser for adding or removing the url based on the addApproverFlag flag
     */
    let getModifyCrUrl = (crId, addApproverFlag) => {
        let url = `https://code.amazon.com/reviews/${crId}/`;

        return addApproverFlag ? url + 'add-reviewer' : url + 'remove-reviewer';
    };

    /**
     * Returns the icon element with the class name provided in the input.
     *
     * @param iconClass  the icon class for which icon is to be created
     * @param hoverAction  the hover action flag to enable hover action on element
     * @returns {HTMLElement} containing icon with provided class.
     */
    let getIconElement = (iconClass, hoverAction = true) => {
        let clockIconElement = document.createElement('i');
        clockIconElement.classList.add(iconClass);
        if (hoverAction) {
            clockIconElement.classList.add('approver-icon');
        }

        return clockIconElement;
    };

    /**
     * Check is CR last event by the author and if not is the date of the last event before the SLA.
     *
     * @param crLastTouchedDate the cr last touched date in {Date()} format
     * @returns {boolean}  true of CR sla is missed, false otherwise
     */
    let isCrSlaMissed = (author, lastEvent) => {
        let currentDate = new Date();
        currentDate.setDate(currentDate.getDate() - CR_SLA);

        const body = lastEvent['event'] ? lastEvent.event : lastEvent.comment_event;

        const lastEventTimestamp = new Date(body.timestamp);

        return (author == body.entity.entity_id.id) && (lastEventTimestamp.getTime() < currentDate.getTime());
    };

    /**
     * Creates html element for hyper links.
     *
     * @param text  the text that need to be displayed in link
     * @param url  the URL for hyper link
     * @returns {HTMLAnchorElement} containing the hyper link
     */
    let getColumnHyperLinkElement = (text, url) => {
        let anchor = document.createElement('a');
        anchor.href = url;
        anchor.target = '_blank';
        anchor.textContent = text;
        return anchor;
    };

    /**
     * Return URL for the Code Browser
     *
     * @param crId  the id of the CR which need to be opened on the code browser
     * @returns {string} the string containing URL of code browser
     */
    let getCodeReviewUrl = (crId) => {
        return 'https://code.amazon.com/reviews/' + crId;
    };

    /**
     * Returns URL for the user and the group.
     * User basically displayed on the phone tool.
     * Teams are displayed on the permission portal.
     *
     * @param user  the string for user ot team name
     * @param isTeam  the flag representing if the first input is team or user
     * @returns {string} for the URL
     */
    let getUserUrl = (user, isTeam) => {
        if (isTeam) {
            return 'https://permissions.amazon.com/a/team/' + user;
        }
        return 'https://phonetool.amazon.com/users/' +  user;
    };

    /**
     * Creates the spinner element for displaying loading.
     *
     * @returns {HTMLDivElement} containing the spinner DOM element
     */
    let getSpinnerElement = () => {
        let spinner = document.createElement('div');
        spinner.classList.add('loader');
        return spinner;
    };

    /**
     * Create unique CR data map for the user/team CR details with CR_ID as the key
     * @param rawCrDataList  the code review details array for the users
     */
    let createDataMap = (rawCrDataList) => {
        let crDataMap = new Map();
        let userDataMap = new Map();

        rawCrDataList.forEach((rawCrData) => {
            for (let [user, userData] of rawCrData.entries()) {
                userDataMap.set(user, userData);
                for (let [crId, crData] of Object.entries(userData.codeReviewData)) {
                    if (crDataMap.has(crId)) {
                        if (!userData.isTeam) {
                            crDataMap.get(crId).get('approvers').push(user)
                        }
                    } else {
                        let crDetails = new Map();
                        if (!userData.isTeam) {
                            crDetails.set('approvers', [user]);
                        } else {
                            crDetails.set('approvers', []);
                        }
                        crDetails.set('revision', crData.revision);
                        crDataMap.set(crId, crDetails);
                    }
                }
            }
            // EXTENSION
        });

        return {
            'crDataMap' : crDataMap,
            'userDataMap' : userDataMap
        };
    };

    /**
     * formats the date object to its corresponding string format having YYYY-MM-DD
     *
     * @param date  the date object from which date string need to be extracted.
     * @returns {string} the date string in YYYY-MM-DD format
     */
    function formatDate(date) {
        return `${date.getFullYear()}-${((date.getMonth() + 1) + "").padStart(2, "0")}-${((date.getDate()) + "").padStart(2, "0")}`;
    }

    /**
     * Returns the URL string of code browser which the pending code review data of user and the team.
     *
     * @param alias  the string containing user alias or the team name
     * @param isTeam  the flag representing if the alias string for team or user
     * @returns {string} containing the URL of code browser
     */
    function getEndpoint(alias, isTeam) {
        let ref_date = new Date();
        let end_time = formatDate(ref_date);
        ref_date.setDate(ref_date.getDate() - LOOKBACK_DAYS);
        let start_time = formatDate(ref_date);
        if (isTeam) {
            return CR_ENDPOINT + `/reviews/to-entity/team/${alias}?utf8=%E2%9C%93&start_time=${start_time}&end_time=${end_time}&open=true&canceled=&shipped=&pending=true&commit=Go&ajax=true`;
        } else {
            return CR_ENDPOINT + `/reviews/to-user/${alias}?utf8=%E2%9C%93&start_time=${start_time}&end_time=${end_time}&open=true&canceled=&shipped=&pending=true&commit=Go&ajax=true`;
        }
    }

    /**
     * Fetches data from code browser for the pending CR on given user or team
     *
     * @param users  the list of users or team aliases for which data is to be fetched from the code browser
     * @param isTeam  the flag to distinguish between the user and the team
     * @returns {Promise<unknown[]>} for the pending cr count data map
     */
    let getPendingCrCounts = async (users, isTeam = false) => {
        if (users !== undefined && users !== null && users.length > 0) {

            let getCrData = async (user) => {
                if (user !== null && user !== undefined && user.length > 0) {
                    let crEndPoint = getEndpoint(user, isTeam);
                    let response = await ajaxGetJSONPromise(crEndPoint);
                    let crData = await parseCrData(response, user);
                    let returnDataMap = new Map();
                    let userData = {
                        'isTeam' : isTeam
                    };
                    returnDataMap.set(user, Object.assign({}, userData, crData));
                    return returnDataMap;
                } else {
                    return new Map();
                }
            };

            return await Promise.all(users.flatMap(getCrData));
        }
    };

    /**
     * Parse raw CR data to extract map from that.
     *
     * @param response  the raw response from code browser for the users.
     * @param user  the user for which response is given.
     * @returns {{codeReviewData: {}, codeReviewOrder: [], count: number, slaMissedCrCount: number}} dictionary
     */
    let parseCrData = async (response, user) => {
        let parser = new DOMParser();
        let responseDocument = parser.parseFromString(response.html, 'text/html');
        let rows = responseDocument.querySelectorAll("tr[class]");
        let reviewData = {};
        let reviewOrder = [];

        let slaMissedCrCount = 0;

        for (const row of rows) {
            let nodes = Array.from(row.querySelectorAll("td"));
            let values = nodes.map(node => node.textContent);
            const id = values[1];

            const events = await ajaxGetJSONPromise(`https://code.amazon.com/get_events_for_review?cr_id=${id}`);
            const lastEvent = events.filter(x => x['event'] || x['comment_event'])[0];
            const lastEventText = getEventText(lastEvent);

            const [author, _, revision, summary, approvedBy] = values;

            let lastTouchedTimeArray = Array.from(row.querySelectorAll("td span.absolute-time"));
            let lastTouchedTime = lastTouchedTimeArray.map(node => node.textContent)[0];
            lastTouchedTime = getDateTimeFromString(lastTouchedTime);
            let isSlaMissed = isCrSlaMissed(author, lastEvent);
            if (approvedBy.indexOf(user) === -1) {
                reviewOrder.push(id);
                if (isSlaMissed) {
                    slaMissedCrCount++;
                }
                reviewData[id] = { author, id, revision, summary, approvedBy, lastTouchedTime, lastEventText, isSlaMissed};
            }
        }

        const getReviewNumber = review => parseInt(review.split("-")[1], 10);
        reviewOrder.sort((leftReview, rightReview) => getReviewNumber(leftReview) - getReviewNumber(rightReview));

        return {
            'codeReviewData' : reviewData,
            'codeReviewOrder' : reviewOrder,
            'count' : reviewOrder.length,
            'slaMissedCrCount' : slaMissedCrCount
        };
    }

    const getEventText = (event) => {
        const eventTypeToText = {
            approve_revision: 'approved the revision',
            publish_comments: 'published comments',
            create_review: 'created the revision',
            update_revision: 'updated the revision',
            publish_revision: 'published a new revision',
            revoke_revision_approval: 'revoked approval on the revision'
        }

        const body = event['event'] ? event.event : event.comment_event;

        const time = new Date(body.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        let date = new Date(body.timestamp).toLocaleDateString();
        const today = new Date().toLocaleDateString();
        let yesterday = new Date();
        yesterday.setDate(new Date().getDate() - 1);
        yesterday = yesterday.toLocaleDateString();
        if (date == today) date = 'today';
        else if (date == yesterday) date = 'yesterday';
        else date = `on ${date}`;

        return `${body.entity.entity_id.id} ${eventTypeToText[body.type]} at ${time} ${date}`;
    }

    /**
     * Return native date for the passed date string.
     * It is expected to have date in following format:
     * YYYY-MM-DD HH:MM:SS TIMEZONE(GMT, UTC etc)
     *
     * @param dateString the input date string, should be non null or it will return unexpected behaviour
     */
        // TODO: Known bug timezone is not configured
    let getDateTimeFromString = (dateString) => {
            let b = dateString.split(/\D/);
            return new Date(b[0], b[1] - 1, b[2], b[3], b[4], b[5]);
        };

    /**
     * Generic helper function.
     * Promises to fetch and parse the JSON response from "url".
     * @param url - The URL to fetch.
     */
    function ajaxGetJSONPromise(url) {
        return new Promise(function(resolve,reject) {
            GM_xmlhttpRequest({
                method: "GET",
                url: url,
                headers: {
                    "Accept": "application/json",
                    "X-Requested-With": "XMLHttpRequest",
                    "User-Agent": "CR count/SLA Greasemonkey Script. Contact: ranishan@"
                },
                onload: function(xhr) {
                    try {
                        if (isJsonString(xhr.response)) {
                            return resolve(JSON.parse(xhr.response));
                        } else {
                            return resolve({});
                        }
                    } catch (err) {
                        return reject(err);
                    }
                },
                onerror: reject,
                ontimeout: reject,
                context: null,
                timeout: 10000
            });
        });
    }

    function ajaxGetPromise(url) {
        return new Promise(function(resolve,reject) {
            GM_xmlhttpRequest({
                method: "GET",
                url: url,
                headers: {
                    "Accept": "application/json, */*",
                    "User-Agent": "CR count/SLA Greasemonkey Script. Contact: ranishan@"
                },
                onload: function(xhr) {
                    try {
                        resolve(xhr.response);
                    } catch (err) {
                        return reject(err);
                    }
                },
                onerror: reject,
                ontimeout: reject,
                context: null,
                timeout: 10000
            });
        });
    }

    /**
     * Creates a post xhr request and return promise for the same.
     *
     * @param url  the url where post request is to be sent
     * @param data  the data that need to be sent in post request
     * @returns {Promise<unknown>} for the post request
     */
    function ajaxPostPromise(url, data, csrf) {
        return new Promise(function (resolve, reject) {
            GM_xmlhttpRequest({
                method: 'POST',
                url: url,
                data: JSON.stringify(data),
                headers: {
                    "Accept": "application/json",
                    "Content-Type" : "application/json",
                    "X-CSRF-Token": csrf,
                    "X-Requested-With": "XMLHttpRequest",
                    "User-Agent": "CR count/SLA Greasemonkey Script. Contact: ranishan@"
                },
                onload: function(xhr) {
                    if (xhr.status === 200) {
                        resolve(xhr);
                    } else {
                        reject(xhr);
                    }
                },
                onerror: reject,
                ontimeout: reject,
                context: null,
                timeout: 10000
            });
        });
    };

    /**
     * Validate if the given string is proper json or not
     *
     * @param str  the string which need to be validated
     * @returns {boolean} true if it is valid json string, false otherwise.
     */
    let isJsonString = (str) => {
        try {
            JSON.parse(str);
        } catch (e) {
            return false;
        }
        return true;
    };

    //--- Note, gmMain () will fire under all these conditions:
    //1) The page initially loads or does an HTML reload (F5, etc.).
    //2) The scheme, host, or port change.  These all cause the browser to
    //   load a fresh page.
    //3) AJAX changes the URL (even if it does not trigger a new HTML load).
    let fireOnHashChangesToo = true;
    let pageURLCheckTimer = setInterval (
        function () {
            if (   this.lastPathStr  !== location.pathname
                || this.lastQueryStr !== location.search
                || (fireOnHashChangesToo && this.lastHashStr !== location.hash)
            ) {
                this.lastPathStr  = location.pathname;
                this.lastQueryStr = location.search;
                this.lastHashStr  = location.hash;
                init();
            }
        }
        , 111
    );

})();