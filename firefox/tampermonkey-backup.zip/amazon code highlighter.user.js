// ==UserScript==
// @name         amazon code highlighter
// @namespace    https://code.amzon.com
// @version      1.1
// @description  When you highlight a selection of code, it will highlight similar selections
// @author       pikewill@
// @match        https://code.amazon.com/*
// @grant        
// @updateURL    https://code.amazon.com/packages/Pikewill-scripts/blobs/mainline/--/greasemonkey/code-highlighter.user.js
// ==/UserScript==

(function() {
  'use strict'

  const highlightAmount = .12
  const parentElement = document.getElementsByTagName('cr-diff')[0] || document.querySelector('table.code')
  const containerClass = 'highlight-container'
  const minSelectionLength = 2

  document.addEventListener("click", (e) => {
    const selection = document.getSelection ? document.getSelection().toString() : document.selection.createRange().toString()
    clearSelection()
    if (selection.length > minSelectionLength) {
      highlightSelection(parentElement, selection, e.target)
    }
  })

  function clearSelection() {
    const els = document.querySelectorAll(`.${containerClass}`)
    for (let el of els) {
      const newEl = document.createTextNode(el.innerText)
      el.parentNode.replaceChild(newEl, el)
    }
  }

  function highlightSelection(element, selection, highlightedElement) {
    if (!element || !selection || !selection.replace(/\s/g, '').length) return
    if (element === highlightedElement) return

    element.childNodes.forEach(node => {
      if (node instanceof Text) {
        if (node.textContent.indexOf(selection) > - 1) {
          const container = document.createElement('span')
          container.classList.add(containerClass)
          const replacement = `<span style="background: rgba(0, 0, 0, ${highlightAmount})">${selection}</span>`
          const html = node.textContent.replace(new RegExp(selection, "g"), replacement)
          container.innerHTML = html
          element.replaceChild(container, node)
        }
      } else if (node.innerText && node.innerText.indexOf(selection) > -1) {
        highlightSelection(node, selection, highlightedElement)
      }
    })
  }
})()