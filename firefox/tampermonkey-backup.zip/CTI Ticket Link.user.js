// ==UserScript==
// @name         CTI Ticket Link
// @namespace    http://amazon.com/
// @version      0.2
// @description  Quick link for cutting a Managed Fleets ticket to customer CTI
// @author       hardingg@
// @match        https://infrastructure.amazon.com/automation/customerHome.cgi?hostclass=*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    console.log("Starting...");

    var isDefaultCtiNode = function(o) {
        return o.textContent == "Default CTI:";
    };

    var bTags = document.getElementsByTagName("b");
    var ctiNode = Array.from(bTags).find(isDefaultCtiNode).parentElement;
    var cloneCtiNode = ctiNode.cloneNode(true);

    while (cloneCtiNode.lastElementChild) {
        cloneCtiNode.removeChild(cloneCtiNode.lastElementChild);
    }

    var cti = cloneCtiNode.textContent.trim().split("/");
    console.log("FOUND:" + cti);

    var shortDesc = "[Managed Fleets] Management of your service SERVICE_NAME is blocked";
    var details = "The following issue(s) are blocking effective automated management of your fleet. Please take corrective action ASAP.";

    var url = "https://tt.amazon.com/new" +
                "?ticket_type=Regular+Ticket" +
                "&impact=3" +
                `&category=${cti[0]}` +
                `&type=${cti[1]}` +
                `&item=${cti[2]}` +
                "&case_type=Trouble+Ticket" +
                `&short_description=${shortDesc}` +
                `&details=${details}` +
                "&tags=managed-fleets-customer-sla-ticket";

    console.log("URL:" + url);

    var link = document.createElement('a');
    link.setAttribute("href", url);
    link.innerHTML = " (Cut Managed Fleets Ticket)";

    ctiNode.appendChild(link);

})();