// ############################################################################
// ############################################################################
//
//                         !!!! READ ME FIRST !!!!!!!!
//
// PLEASE VISIT OUR WIKI IF THIS DOES NOT OPEN WITH TAMPERMONKEY OR GREASEMONKEY
// WIKI: https://w.amazon.com/bin/view/AWS_IT_Security/Isengard/Scripts#HIsengardAWSBanner
//
//
// If your script is trying to revert you back to code.amazon.com please uninstall
// the script and redownload from the proper location.
//
// ############################################################################
// ############################################################################

// ==UserScript==
// @name         Isengard AWS Console Banner
// @namespace    Isengard AWS Console Banner
// @version      2.8
// @description  Shows Isegnard account information and current LSE status within the AWS Console
// @author       CTI "AWS" -> "Isengard" -> "General"
// @match        https://*.console.aws.amazon.com/*
// @match        https://console.aws.amazon.com/*
// @match        https://*.console.amazonaws.cn/*
// @match        https://console.amazonaws.cn/*
// @match        https://console.amazonaws-us-gov.com/*
// @match        https://*.console.amazonaws-us-gov.com/*
// @match        https://console.c2shome.ic.gov/*
// @match        https://*.console.c2shome.ic.gov/*
// @match        https://console.sc2shome.sgov.gov/*
// @match        https://*.console.sc2shome.sgov.gov/*
// @match        https://*.console.amazonaws.eu/*
// @match        https://console.amazonaws.eu/*
// @match        https://*.console.amazonaws-eusc.eu/*
// @match        https://console.amazonaws-eusc.eu/*
// @match        https://*.console.csphome.adc-e.uk/*
// @match        https://console.csphome.adc-e.uk/*
// @match        https://*.console.awshome.adc-e.uk/*
// @match        https://console.awshome.adc-e.uk/*
// @match        https://*.console.csphome.hci.ic.gov/*
// @match        https://console.csphome.hci.ic.gov/*
// @match        https://*.console.awshome.hci.ic.gov/*
// @match        https://console.awshome.hci.ic.gov/*
// @match        https://isengard-beta.amazon.com/*
// @match        https://isengard-beta.dub.amazon.com/*
// @match        https://isengard-gamma.amazon.com/*
// @match        https://isengard-gamma-dub.amazon.com/*
// @match        https://isengard-gamma.pdx.amazon.com/*
// @match        https://isengard-gamma.bjs.aws-border.com/*
// @match        https://isengard-gamma.bjs.aws-border.cn/*
// @match        https://isengard-gamma.pdt.amazon.com/*
// @match        https://isengard-gamma.pdt.aws-border.com/*
// @match        https://isengard-gamma.dca.c2s-border.ic.gov/*
// @match        https://isengard-gamma.lck.aws-border.com/*
// @match        https://isengard-gamma.ncl.aws-border.adc-e.uk/*
// @match        https://isengard-gamma.ale.aws-border.hci.ic.gov/*
// @match        https://isengard.amazon.com/*
// @match        https://isengard-dub.amazon.com/*
// @match        https://isengard-pdx.aka.amazon.com/*
// @match        https://isengard.bjs.aws-border.com/*
// @match        https://isengard.bjs.aws-border.cn/*
// @match        https://isengard.pdt.amazon.com/*
// @match        https://isengard-osu.aka.amazon.com/*
// @match        https://isengard.pdt.aws-border.com/*
// @match        https://isengard.dca.c2s-border.ic.gov/*
// @match        https://isengard.lck.aws-border.com/*
// @match        https://isengard.sc2s.sgov.gov/*
// @match        https://isengard.eusc-de-east-1.amazonaws.eu/*
// @match        https://isengard.ncl.aws-border.adc-e.uk/*
// @match        https://isengard.ale.aws-border.hci.ic.gov/*
// @match        https://*.tardigrade.aws.amazon.com/*
// @match        https://*.tardigrade.amazonaws.cn/*
// @match        https://*.tardigrade.amazonaws-us-gov.com/*
// @match        https://*.tardigrade.c2shome.ic.gov/*
// @match        https://*.tardigrade.sc2shome.sgov.gov/*
// @match        https://*.tardigrade.amazonaws.eu/*
// @match        https://*.tardigrade.us-iso-east-1.c2s.ic.gov/*
// @match        https://*.tardigrade.us-isob-east-1.sc2s.sgov.gov/*
// @match        https://*.tardigrade.eu-isoe-west-1.cloud.adc-e.uk/*
// @match        https://awsc-integ.aws.amazon.com/*
// @match        https://*.awsc-integ.aws.amazon.com/*
// @grant        GM_xmlhttpRequest
// @grant        GM.xmlHttpRequest
// @grant        GM.addStyle
// @grant        GM_info
// @grant        GM.info
// @connect      isengard-service.amazon.com
// @connect      isengard-service.bjs.aws-border.com
// @connect      isengard-service.dca.c2s-border.ic.gov
// @connect      isengard-service.lck.aws-border.com
// @connect      isengard-service.sc2s.sgov.gov
// @connect      isengard-service.eusc-de-east-1.amazonaws.eu
// @connect      isengard-service.pdt.amazon.com
// @connect      isengard-service-osu.aka.amazon.com
// @connect      isengard-service.pdt.aws-border.com
// @connect      isengard-service.ncl.aws-border.adc-e.uk
// @connect      isengard-service.ale.aws-border.hci.ic.gov
// @connect      lse.amazon.com
// ==/UserScript==

// Polyfill Fix: https://greasemonkey.github.io/gm4-polyfill/gm4-polyfill.js
if (typeof GM == 'undefined') {
    this.GM = {}
}

if (typeof GM_addStyle == 'undefined') {
    this.GM_addStyle = (aCss) => {
        'use strict'
        let head = document.getElementsByTagName('head')[0]
        if (head) {
            let style = document.createElement('style')
            style.setAttribute('type', 'text/css')
            style.textContent = aCss
            head.appendChild(style)
            return style
        }
        return null
    }
}

Object.entries({
    log: console.log.bind(console), // Pale Moon compatibility.  See #13.
    info: GM_info,
}).forEach(([newKey, old]) => {
    if (old && typeof GM[newKey] == 'undefined') {
        GM[newKey] = old
    }
})

Object.entries({
    GM_addStyle: 'addStyle',
    GM_deleteValue: 'deleteValue',
    GM_getResourceURL: 'getResourceUrl',
    GM_getValue: 'getValue',
    GM_listValues: 'listValues',
    GM_notification: 'notification',
    GM_openInTab: 'openInTab',
    GM_registerMenuCommand: 'registerMenuCommand',
    GM_setClipboard: 'setClipboard',
    GM_setValue: 'setValue',
    GM_xmlhttpRequest: 'xmlHttpRequest',
    GM_getResourceText: 'getResourceText',
}).forEach(([oldKey, newKey]) => {
    let old = this[oldKey]
    if (old && typeof GM[newKey] == 'undefined') {
        GM[newKey] = function (...args) {
            return new Promise((resolve, reject) => {
                try {
                    resolve(old.apply(this, args))
                } catch (e) {
                    reject(e)
                }
            })
        }
    }
})

const MIDWAY_AUTH_HOSTS = new Set([
    'midway-auth.amazon.com',
    'midway-auth-itar.amazon.com',
    'auth.midway.aws.a2z.com',
    'auth.midway.amazon.dev',
    'auth.midway.aws.dev',
    'midway-auth.aws-border.cn',
    'midway-auth.c2s.ic.gov',
    'midway-auth.sc2s.sgov.gov',
    'auth.midway.csphome.adc-e.uk',
    'auth.midway.csphome.hci.ic.gov',
    'auth.midway.amazonaws-eusc.eu'
]);

const baseXmlHttpRequest = GM.xmlHttpRequest.bind(GM);

function getHostFromUrl(url) {
    try {
        return new URL(url).host;
    } catch (e) {
        return null;
    }
}

function isExpectedAuthorizeRedirect(authorizeUrl, expectedHost) {
    try {
        const url = new URL(authorizeUrl);

        if (!MIDWAY_AUTH_HOSTS.has(url.host)) {
            return false;
        }

        if (url.pathname !== '/SSO/redirect') {
            return false;
        }

        const redirectUri = url.searchParams.get('redirect_uri');
        if (!redirectUri) {
            return false;
        }

        return new URL(redirectUri).host === expectedHost;
    } catch (e) {
        return false;
    }
}

GM.xmlHttpRequestMcs = function (details) {
    const requestedHost = getHostFromUrl(details.url);
    const originalOnload = details.onload;
    const reportError =
        typeof details.onerror === 'function'
            ? details.onerror
            : (err) => console.error('GM.xmlHttpRequestMcs error', err);

    function attempt(hasRetried = false) {
        return baseXmlHttpRequest({
            ...details,
            onload: async function (response) {
                const shouldTryAuthorize =
                    !hasRetried &&
                    response.status === 403 &&
                    typeof response.finalUrl === 'string' &&
                    isExpectedAuthorizeRedirect(response.finalUrl, requestedHost);

                if (shouldTryAuthorize) {
                    try {
                        await callAuthorize(response.finalUrl);
                        return attempt(true);
                    } catch (err) {
                        return reportError(err);
                    }
                }

                return originalOnload?.(response);
            },
        });
    }

    return attempt(false);
};

// CSS
GM.addStyle(`
/***********************************************************
*             Standard AWS Sec UI Styling                   *
************************************************************/

.nav-menu-content {
    margin-top: -40px;
}

.asui {
    font-family: 'Open Sans', Helvetica, Arial, sans-serif;
    outline: none;
    box-sizing: border-box;
}

.asui.vertical-middle-align {
    display: inline-block;
    vertical-align: middle;
}

.asui.vertical-top-align {
    display: inline-block;
    vertical-align: top;
}

/***********************************************************
*                  AWS Sec UI Header                       *
************************************************************/

.asui.isengard-navbar {
    height: 40px;
    font-size: 16px;
    line-height: 40px;
    padding-left: 0px;
    padding-right: 30px;
    overflow: hidden;
    font-weight: 400;
    color: #f6f6f6;
    background: #232f3e;
    border-bottom: 1px solid orange;
    display: flex;
    justify-content: space-between;
    width: 100%;
    z-index: 10000;
    top: 0;
}

.asui.isengard-navbar.production {
    background: red;
}

.asui.isengard-navbar a {
    color: inherit;
    text-decoration: none;
}

.asui.isengard-navbar img.asui.isengard-navbar-logo {
    height: 40px;
    margin-right: 0.4rem;
    padding-top: 0.3rem;
    padding-bottom: 0.3rem;
}

.asui.isengard-navbar img.asui.isengard-navbar-lse {
    height: 35px;
    margin-right: 0.4rem;
    padding-top: 0.3rem;
    padding-bottom: 0.3rem;
}

.asui.isengard-navbar ul.isengard-navbar-left, .asui.isengard-navbar ul.isengard-navbar-cc {
    height: 100%;
    margin: 0px;
    list-style: none;
    display: inline-block;
}

.asui.isengard-navbar ul.isengard-navbar-cc > li > span {
    border-radius: 8px;
    width: 100%;
    text-align: center;
    background-color: #c44;
}

.asui.isengard-navbar ul.isengard-navbar-cc > li > span > a {
    width: 100%;
    color: black;
    font-weight: bold;
}

.asui.isengard-navbar ul.isengard-navbar-cc > li > span > a:hover {
    text-decoration: underline;
    cursor: pointer;
}

.asui.isengard-navbar li.nav-item {
    display: block;
    float: left;
}

.asui.isengard-navbar li.nav-item > * {
    display: block;
    padding-left: 1rem;
    padding-right: 1rem;
    line-height: 40px;
}
`)
;(function () {
    'use strict'

    var isengardConsoleRegexes = [
        /isengard.*\.amazon\.com/,
        /isengard.*\.aka\.amazon\.com/,
        /isengard.*\.bjs\.aws-border\.(com|cn)/,
        /isengard.*\.pdt\.(amazon|aws-border)\.com/,
        /isengard.*\.dca\.c2s-border\.ic\.gov/,
        /isengard.*\.lck\.aws-border\.com/,
        /isengard.*\.sc2s\.sgov\.gov/,
        /isengard.*\.amazonaws\.eu/,
        /isengard.*\.ncl\.aws-border\.adc-e\.uk/,
        /isengard.*\.ale\.aws-border\.hci\.ic\.gov/,
    ]
    var url = currentUrl()
    const checkUrl = (regex) => regex.test(url)

    if (
        /(console|awsc-integ|tardigrade)\.(amazonaws\.cn|aws\.amazon\.com|amazonaws-us-gov\.com|amazonaws(-eusc)?\.eu)\//.test(
            currentUrl()
        ) ||
        /(console|awsc-integ|tardigrade)\.(c2shome\.ic\.gov|sc2shome\.sgov\.gov|csphome\.adc-e\.uk|csphome\.hci\.ic\.gov)\//.test(
            currentUrl()
        )
    ) {
        injectOnConsolePage()
    } else if (isengardConsoleRegexes.some(checkUrl)) {
        injectOnIsengardPage()
    }

    if (
        /(console|tardigrade)\.(amazonaws\.cn|aws\.amazon\.com|amazonaws-us-gov\.com|amazonaws(-eusc)?\.eu)\/cloudformation/.test(
            currentUrl()
        ) ||
        /(console|tardigrade)\.(c2shome\.ic\.gov|sc2shome\.sgov\.gov|csphome\.adc-e\.uk|csphome\.hci\.ic\.gov)\/cloudformation/.test(
            currentUrl()
        )
    ) {
        // ensure production account restrictions are in place whenever page reloads or re-renders
        window.addEventListener(
            'load',
            async function () {
                setTimeout(protectProductionAccounts, 500)
            },
            false
        )

        // save the real open request
        var realOpen = XMLHttpRequest.prototype.open

        // when an XHR object is opened, add a listener for its load events to protect production accounts
        XMLHttpRequest.prototype.open = function () {
            this.addEventListener('load', protectProductionAccounts)

            // run the real `open`
            realOpen.apply(this, arguments)
        }

        window.addEventListener(
            'click',
            async function () {
                setTimeout(protectProductionAccounts, 500)
            },
            false
        )
    }

    if (
        /(console|tardigrade)\.(amazonaws\.cn|aws\.amazon\.com|amazonaws-us-gov\.com|amazonaws(-eusc)?\.eu)\/iam/.test(
            currentUrl()
        ) ||
        /(console|tardigrade)\.(c2shome\.ic\.gov|sc2shome\.sgov\.gov|csphome\.adc-e\.uk|csphome\.hci\.ic\.gov)\/iam/.test(
            currentUrl()
        )
    ) {
        // ensure disabling security credential restrictions are in place whenever page reloads or re-renders
        window.addEventListener(
            'load',
            async function () {
                setTimeout(disableMakeAccessKeyInactive, 500)
            },
            false
        )

        // save the real open request
        var realOpen = XMLHttpRequest.prototype.open

        // when an XHR object is opened, add a listener for its load events to protect disabling security credentials
        XMLHttpRequest.prototype.open = function () {
            this.addEventListener('load', disableMakeAccessKeyInactive)

            // run the real `open`
            realOpen.apply(this, arguments)
        }

        window.addEventListener(
            'click',
            async function () {
                setTimeout(disableMakeAccessKeyInactive, 500)
            },
            false
        )
    }
})()

// utility function to convert an ArrayBuffer to a base64 string. Useful because btoa()
// won't work directly on a binary string, see:
// https://developer.mozilla.org/en-US/docs/Web/API/WindowOrWorkerGlobalScope/btoa#Unicode_strings
function arrayBufferToBase64(buffer) {
    var binary = ''
    var bytes = new Uint8Array(buffer)

    bytes.forEach((elem) => {
        binary += String.fromCharCode(elem)
    })

    return window.btoa(binary)
}

function generateBannerInnerMarkup() {
    // Due to CSP restrictions on a lot of AWS Console pages we can't just load the image from
    // lse.amazon.com, instead we download it in the context of the extension (via GM.) and then
    // set the image source to the response.
    GM.xmlHttpRequestMcs({
        method: 'GET',
        url: 'https://lse.amazon.com/lse-check.gif',
        responseType: 'arraybuffer',
        onload: function (response) {
            // yes, even though the extension is .gif it's actually a png. The extension remains
            // .gif for legacy reasons. Unfortunately source can't be set directly to the binary
            // blob, so first it needs to be base64 encoded
            document.getElementById('lse-check').src = 'data:image/png;base64,' + arrayBufferToBase64(response.response)

            // by default we hide the image until it is loaded, otherwise it has a weird jump
            // effect due to the alt text being larger than the empty container
            document.getElementById('lse-check').style.display = 'inline-block'
        },
    })

    return `<ul class="asui isengard-navbar-left">
        <li class="nav-item">
        <span>
        <a class="asui" target="_blank" rel="noopener noreferrer" href="${getPortalUrl()}"><img class="asui isengard-navbar-logo vertical-top-align" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABBCAYAAABhNaJ7AAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAACXBIWXMAAJqPAACajwECpCB5AAABy2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS40LjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp0aWZmPSJodHRwOi8vbnMuYWRvYmUuY29tL3RpZmYvMS4wLyIKICAgICAgICAgICAgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIj4KICAgICAgICAgPHRpZmY6T3JpZW50YXRpb24+MTwvdGlmZjpPcmllbnRhdGlvbj4KICAgICAgICAgPHhtcDpDcmVhdG9yVG9vbD53d3cuaW5rc2NhcGUub3JnPC94bXA6Q3JlYXRvclRvb2w+CiAgICAgIDwvcmRmOkRlc2NyaXB0aW9uPgogICA8L3JkZjpSREY+CjwveDp4bXBtZXRhPgoE1OjLAAAcaklEQVR4Aa1bCZRUxbmuukv3dPfMsCObAZWduISRQWPyGNSoWXyKnkHjSYw75iXPk2OOUcGlNYCamPdeVgUDaqLGMHGNL8aoYTC4AQM8dUZ2AQMq+8zQ613qfV/dvjPdPT0smprpe2/fqvrr3+uvv6ql+BcXlWywmloHqZlNTV4IOp2cOkJFvMnCl3VSyolCipFKiYFSiGPQJq6Chmz/MT57hZA7pPTXSyXXuJ5qqb5jZRvaFprh4bo6WyxocaXsfheAOPor4P5rCgmXyWY3hNYxv268rawZvvC/DoK+EI8YcWEawB50+Ep4+DieEj4JU2AJSsSUaCKFxEfwg7bpHBopsQ5f/u4L46maOW8vDcdANfj52ZjwmRmgljSaoq1JySRpESI1v/5C3L4L5M+OxyxDAP+sAzaAZrwPpchxQSn+CsSzAi99/YYkdxerCmAMSwrfBSzXb0P14oQVWShvfr3zszLhUzMAGEpxXZ0lF7Y4xDU9f8pFSsnbIelTIBdKjq+pERwDotd33I6ykEWKaiOpLEaVZRoGNCWT87KOktP73Pb2WyoJfSkI4CihfzqkVDJpiGRSgTKVmz91oqfUL2JR8ywFMWccP7B9CaIL0j1apA7TPgvNqkplnMcSY0ZdIWc2QcfI8kBrip8PA0dXH7UGFNv6wXn1NwHAvfGoaUDiobTN3gamHEsKOocI6KpD1Bf65ePQ/Uza+2N89tuX8l2xCYSaUPyuZLwKX6wK73p9tQreF47OAROq03b6yXjc+nom7VLdSXxFWCHRFBF9oIEHLS4QS1MP6zmoQQeIduQD3/vQKPzrgvd5jBdJp90XErNXBMRT9eEa0ESKJLoWzADvVMiMoHfv14pIV2rOqYf2nr1nyvEZP/0S1HA0kKH9U+I94GjCQIyFWmJJj5/K+6o97YmOrKefYS4C05z24yBeRm0pEhFD1FSZohaf6ipDQLmoJXk7akZSaXdp9ZwV5xO/JY2NpkwG6i+SDXhuduGAr8a430yMGXmuNg22KZqO2a+89EC8vAG/h8QfnDf1JNdXzYmo2S+dcfOoipS3DyVqwVFRju0ZT+044Pg79jtiT8o1snllsA14wilMF4oQuuDDifoUv5TKiFqG7Bs35dA+Vn7CkFjE8tRbNWNHfkWIFYIzjyYQPqZpZqMxM9lE4mfZhnzQjlkivXHbUwB8IYk/nCYUUAgQqXQNbT5375RJjiffjNtGDaa1PPCsSDzVHIT5uztdf/3HWXPHAVe6cIuYyVAhOP8rzPNp8MYJ+KDhxECwMNGRZpGHtuDjQzscC4qB7v8X6e+cduUjW7NLEW9Mh7RJmLhTKHaBL7oZQrk3mHlULh63o6m090j1nLev5BgBU3ntWQ7JgHCw9NzTh2MaXx2PGoPTeZ9qbxeDCtU9Ygq/PeP7rTuz1va9eaq5iFhyIwh7WxpqlSfUOun6OyG4A6Avb7lQ/0hVlTLc/r5vfM6QahKwrIdV19uWMQTMFgfz/rqc6Z42q2lLe4hPsVTT86feE6sybklnPB1TgV7ajAMTtVMp5/7q21beRHNpbGryQWwPJvTKgHAQqhtUalW8yjwlnfV6qD2JNzDhwYS9rXty1prtGbE35e2IVxlPRmz/T8MnjFhFiRUz7HDPi/59XI0hvQaI90LfcO++5ukPti2AD5oFH6SK7Dozr/6Bqrh1PXwRp17SQj1jIaF+PGaaqYx3C/zGfUloDD46WNMtCpfeGVAY6ODc+kcSCes7GKQi8aYpPaiq2bYzK976ILUtFpE/mTom/ujJ97+TCgdKNjRYQzs75Uc1NWrioGbVNqlUEhNbhWzb3SDZpt/xLf7MJh01ht3h8ITJd6HtsyI9b8ofYnH7UuBF5tIRl9NCYiW0SKYd9f3EnLd/HQoV77tKeSddwenuVHD7w1sn/2jEwOh9kDyCUIFgtLtQ8nB0DqYq+9V1neK9Hdl5t/zbyLnwxlm2osT67W/xG5uwBKqget2Qej4lKcmGBmMaqpY1NPuUXOiL2Do1t/5FxAPn6VlIYgbqNeCCP4jZUTjsVYk5K6awL9Cm78UtKMU06Tch8f97+fhvTB9X+2c6GR1qFXE4IF44sG37r60dG5pa2i/9XdvONQSwpHFSpG1Sq1tJ3YIhj/4aEo97VcZOvxqLWV/sbRYqgp6H2UbSWXd1ZyT3b0NueidFDRBJOM4iBlhFHbSqUfJCDBg+enDscXrmjOtTgsXRnYKn91BnN2/ofOH8378/AzC0jXfO/8KgmtlrdqsmgZjkX1PUAsQfs5qdA/d8qV/aT78Goj5/xMTnvDXtjv/lYXPeSdN89KKtiHhiGDoNjW1jwTb/8p3Bi8cMjtbmPN8pI57tvKqoaW3clX1k+kOt50MbdOzPGMFQ9lbY5g/JYUpNA/0Ml4D4Fof5hIjKYxYC8RUccdkQBcl7a+N570vDki1p4tLUBBXWplRKcxcDFtQxzBX+j888/sqThsfPwQIH9l063WEgFxKwOjPuM2N/uvZKjSBMZHeybjJub8RsIx6LmPd3zp1yAyOzz8KEkHjmFZStVgP2KKwAezjiHsTHoPaQfGck+yVZIL5lZyfipiaPQkrbU95Uyam17AfhYc7kA5gzq4WqP7Bm4tDI/P7VpnBcZZb6VeUjOLMggX2Yo65lP3Rydt1+6hditrkcJpFAaJtnuFtdZf08Pbf++5+WCSHxqXumTLGUtRL5gEGMP4Bnj+CLeBRKHnM/bN5bE7ezX6bNL4XkSTzNOju/fiwizJfjfaL16Yh/Cfu0zKrT8ZlYWFen1fW+s2puOmlYbIgN7w7Hx5xMUZF+JGrAHau75OwVSFsJsf/u+pMRHC0HgrE8zAWvIlR/SMCPVZm/7Jw39XtHy4SQ+My8KWdJX75hY0mAJAh9jM0xeykB8RlnNYmXdHiw+YYC8R0g3vXFm1FTDnY6gaYS1xNO3cIW10jCD1D6vzpr/IBBtfb3+idM4WFeLyUedm8ZVibjbUpFc4vYeVdyyilg33KqfQ4IQp1CBLVWgQmqOmr8KjV/yneLmFAGlpCCQi2kyVCrOueeerE0jFeQHrMQEpP4Q/mTguTdlji8fUh8yytbDC7eSLypxBtI1PTPucqBgirbNCan5049jcIyhtbVaQ+fNZyrRw+K9EdM7YBbXMAVF2VgpQZMfkvVOjCvbnLMkssAtDobSL4cQTKBmqDiEes3mLevLzABuJQaFgehLWIKQlYHK7p5U6+K29afmATCwosOthw2u4SlIHl3VaednVZMPNVe/ax+rOGL1xEMDYB5UkNt0OXaWHEKw7+YQKzA9lFjiSsG1VgMaw0OW0S/T0lg6knVXDjqvx9f3TlG+uYyLFWrK60LQsxwxyjKT+c9Acf5AFZrSs5uXkApL0HWuLFRiOa23bJBd2j2uLpLz6+/MRYxfgbG8S0vxdOvbll0CYlf2e54DeFU1wR3j6jRuXb88LH/3OsuH9E/OjCV8zibBRoK02ZuEUuycwCLCR0hFs8Yd6ZU6tVzP1/jwQQMRNZdS1VwzIlVWXY+5/3+lud3/HTS4Njyk0ZU1Z48Iu5gZWfrbEQRt4oQLDwqhKTSwBSGxIk/CyHpwp5tEN3Nm3o31g+3w4lBSSD+goOu1BbvQuLf3hczpx9745sZ2vxdSM4mMZM9ecn4sXs63eVTj4sPOvnYmJN3FSUfFsDW8vU8KSZq9cp73kVDa2wkIgwfa6oS76/VEz3gAJ8ZELUmD0xYtW9tSTuwJ+vUkXENSaPbPUA4UOHOmQaakPOMeMRckJo3RfiO/axlOyeCeXF41X8qw7wCC5cb0syQaIjB7FQGKPwaEv9WvGZAQ+KGF3N6uoUGJTHQw42jhkAzl8H/DPpgb84ZNySKhSXW5+hNFMlZ3PV0nsl7dUxOcL1+VgLZFziHIFkRDoX2aE31dw+m1Lrbmrc+uj/j3XpMjW2v/TCjWranYR4BRDKh9xIwIet4SIsZCwzb3RKxzFegFc9HIubqRESCeHgejVtpoFIGMyT+jbiTmiYLxNN33JXU9MFuEshVkFwhkIwxO7NwaJzPCvhpOTFDQDYoNdlomjl6Ah7GAQkSC3JKis+cPJpu2e51bmbNlc9suBdz/ezB1bbBpe+qbWRCd56vpHfJF2lA4j4CLAWJJDC1KfgHn/seaReZZIBAc41fSbfuLyDejGQy7vK4E58mk615PWsUltpU/aUNDdY1Ta37ILYm+BKRd4QHJuj5vEQ+dLpABn5ggpEVRl0VloyQBvIVPRBQEhMiVg+bJmFALkv5uerZDfekHO82MmHt9oxatTWF9cGRMCFgMGjXrgPDcbYBJjC7nmN3k06bx8IG0/BrMedrID6IMnkvbrSs8AU8fpk7T5hYDeQfKymnDDAQIwzMsqcwFYX5vIRJIaxAVcR2fm+E6+byViWFcdUzG+el8t7tg2psc82HGf+ImRAQSqUMuH1owtlGE5/Kestic1Y0yGTSX8p4oYx4jS+WzrxLZbYgNumAUMyDCCS0j9INui5ITIFc7E9imlTjSDnW9r2rn1S7dFdMW2ikRJJ5SWrCxrmpvHsnfIJmQsu2I9aELkwO8+AiooyAeGaDGzg2iZ9eiXgAghloIV79/Hqk3cSmCBxUzlHMtgbeJRwMyspQF2UIbX44G0DTpX4VNuK9wBLYSrrstaImaCY8s+nuzpx/F5nQsi3rlTChuNPRP3vQSgtT5ysg/kx2PxTxBfB6PyB4lpsY6Hsw7B420K11JvRe9gsaME/QS6GVlhVKI2TC1c9uSHbmvB8PrbUsMmH19hRyhGUdju6rj51iE7Pi1ng+9lV2pcPrTfLFoO9qbqBQITz/Q711TB/TS2EF8FTHOLAHLH17olzoShdRCUYpEzbe0ZF355MJK7dm1Hs7M/D2QLzX4StBLHoH4PhHNLhbE1TR5ouah4/TCg9SGns4NnHozbiJP4FX0UjAhN7aEZEBhNvMS1khkC5NeGbTHExp9yEIMXZhX0ATjwafoshCkrtvh6itZn/AOipISFRnqPvMaumpplQQXNoT7C59Yx0iO74oL1AQrf/HsqJBBF62ZyOhmNXle8Myl5BwKJWko/10RccKHHpPrTj3AGFAOkcFDTMgonscP0E80EOygKV3rqTYw9qDsBUJZ1NpAMkDDmhzAoDpzUd+q0QU0918j8B7GE96YA9QcYeHKlYJcCUYxe8oPUinazFEB1hcf7hnX/oJYlqLCJcIl+AAmQbRodqJ0FftQgJEtCNgCHS2BLRkpAZRnJC9r05rAabAigwIe4FPB8hxRGByfwppJXqZktHDloe6SwPM4ywwOmW9+BJb0gHqxOahuqFuWaEePm0Q1bxPDDEWxi9GWmsTJSPEBjBA7iMDDkBinBuJfBe+mBoRUXmIEuOuK3VeHYYQdC0MFN7oB/hsWPYm+JODCCsM7A3CFAAT70OY4T3sx3uld3htph3fTcSMs7GA+hvb6Q1RZncPVQrBEFJ6I7m7TAYg1qGDIyL6owWiB5VrQYzajlQRJOarDNIliB2CSY+NA9yZHsG/cR7Hbe5lcPKNccGVTa0fY4A3OPCW3Y67dU9eYX8QKABcgVLeij8EWajqeq+RJROQBY5XWV85EiYABgJFRqpJAy549EDkNuEEKcQA62BQXJWJBCsWf2KlgaT/+3QIOHCj9qY9MIo6oDEK7mjsIqmBTl9T951Ro1UxYIxuVvki/4djRZEhfH1zSuw4kNfeWGtXgERXNw4Sfviy6zkYg18jGTIhZn/l4GE0IVwRPvHuE6NAx+ghfWxSAxvQNBVA65mBq97NdjbeClcp1pBDaCI/OuBAAsSwu6CG9oj1szUs5bg8ASbEXQ0V1ZD7d9QCBEYvYgv9iT5R0wa0/CttnWr9J3rHjLvFwUkRgAltKdQMDbvCBTAi3AxJgAnILGmfUNEcCkHQ3ow7dUQ/u2pwrc19S1BWDBT5LAYHCCwZWyADYqxGxJWPWtLCQQYsUbl+7lbJrr4Bk77PnuwIpLqq+C4soS/YfmD4d9pz3j/6VplRrPnUsvUp95V1Hf7mXVnVCYcLP6G4ICHxzCkcjgmAr5mA1Pc5qXn1f+V4mgnYxA3HDmcixBBfHz+kSsRtieV3N6J4ZNEzGzw+D1EI49o/r/8AQeC73IuH5/Y/7nD1QYUSRYDQwBgPc2p959x6ZPNQFgSpdP1cdAFXtC9INje7/zxlY0Nn3v8tVtsG7NHa1e4ZS9en5Avvdsi/tXbIF1s7/Jff71BYS3AxxtjhcIVnhHhW6FxowotsHJ4CSYIWauAP64YNHFJrnzesr81jOYDaXeCJdIiNPMTmxLhRL7NG6wKOpb7EKQNI+Jt25ZiNDT1B0DuwR+3RAXEu43KmryG1YvhdI4WmQId01TMbrnVc70sH8+oxwN8aj8ospih3f8pPpbK+sRNHZ/7+fie1Ak7pKJgQs84jE/Zil0dinImNk3Sc0L9v9JIvHp9A9k66PbPb0rOYEZbiUa092HfUDIA2Pp1GugqdTJzlUTjeArWk5+6iiQ8msjgOdmbHZiLpebpmYWUtYB2ZQO2jT7jm+c2vX/Pshm+L/fkJKicnGRF18sB+5kjEX78eXGPLfWnPexVMOKg98xExwYQmIMozz8N5hBM5XuOSVqa9jdNGxb83ol9EMLQHCcXFx3cbJ0k6EGIFidmPWjwugbVzXnzBmDejtnFae8b1jhsUNaeNrdYqWQojMAxEegiQxDk4g/OySk6KMD1VPFL5M4+otO3eDddRmsFhu0UXjHkAp8Ku34sTZ/3jpnXWhBpZjQxyha2pECynKhNmhZSXOj9x+4oXPsC2+XE4l9D0zfGzvvH5Pg/Ch7noj+NFYRd9x7EZ08aM8pP47BU3hztQRrgt5hvqIXaosk21ZXdefNTuCA5SpgUEqU0VNX9Mz51yrM7NQZVKhir7wo1JEk9mM5vET7IhCG2vfm7jdzuz7kMD45YNTXCpCcjjVzQHuEwGWybzlFh+X0biN/7n6CiJF6JfnzNOSNzFWQb5+rKNHb2vSenvycvIvRo9SJ9347qWFp1Xq7Wij2Hq2opzfTiNK3wmPJGzDNRD9+i6mOCuC6fZD5Wvql/ABukPDsME9gb39KFq2iwZAh+hTfDq5zZd15HzF4VMeOX9ThywKmeCQsiC/QVY7b6Me3n/O1f9gZIf88tNOcJuv3v0g0P7RY7hThVMS8Pl+6BIL0LbV+L2vrcu36+lDxxYRzNRPM4ys6kVE6D8GaUOU/CoAesQytI7l2kB+1kIUx2cDx6T7lRvtidP76+ZAHNg5ZEWOskuJjy74ZqOnPfIoIRl7097eTKBU3LgGEE8Cld2ezPOFQPvXPV79V+nxwLJc1NlyoLahHUpokYXRJZro4NQ3s7k3ObEbSsepOMmriGOVGkW3rXLW3ThmDYMOgFS1oefvnpirUC6S5/dI7fKigOkbCD6ITA8r2b2222cIcTEQYpetqxtr1/JBDKDDRZdOPp3faqsb+NQZX5AwoycPaHGx36lBE50llcNuHPlwx//9KREeOQlY09twjG5izTxOuormpkw46ObiUAvbShrYuy2N7ZxQVWMW6gqijn1AEOJEx74A7H4V69vSmlJMHiqoAk2NQHx9rGmUmsQql4BT+eGU4w+Vd4r2d0VJJ5M4Jurn910+YGs9wR2oCJ7DnrZV9cdxMaNkp0Z/1oST5gkPnfv6Sem7fp3C8Q7QLY8tc6gVjIhggnhck08j9uUCaZEpnRMtM1FM8bgBwnGldisyWewlvncAFtMH1ejmYI5XN+70ddP2jPjdAgPTj+HTOONVbeu3MIarRG434VkSihl3aPChUwI2yy+cMzjfWPWZTxsGbXEf8z84/oH2IX2m95jzsbjHVguG4hiqc4lak9VBmEuokbsajl3JOas/DHxoHBQVVJKGVBA4OGGUVVeX/s9aN4JPM8MFbcmDI0KBBhaCzgNlE0xBEoV9mFvFvbccjg+94Bpmj+P3frWVlayUHotO/9s1g2rUTQT0caDoUldpy+tjbJtUps5ceJEvVv80AWjn0xl1as/eGnzQ7t/dEZNvI/7TXikm5EqPx4qzy68dIXCGgYuICofw8nyfR35Pwy4c9VlnHUwTMnpsKK24WNwD7Xg0YvHneR6/mrYPQfwIAlz0rAqMfW4hG7InF0Fn8A6/pjJgoMUQDKLZfBzQOjxuOW/Jm9padedj+KCPf6TUxn1LfjAS7A7dKwLiXBxBhDEq0SAlDzsKM+9hG27s62j7l0zGa+whQZUCz4G30tKCYCwJjyWuuiCsTMilnhap7bgUFJ5ZY49JiJOP75ae+dDBCvExQODLJwog15g/y/vf4LBViipVgDv95CU2o6AZZ+Hn74g4MARcj+CsKwP1mrDsEU7Dl2YgDkNzm9MBDC4JA8IZyK3fJqDdmFETN8Otvns1p2ZffP/umvyE+9/tG0pVH96BdUPaa3IAFbSKU6HP1h8wdhrcI7/IYTBlLiXBhOG97PEGSdU62wL9t41rAomwfeaEbgZ3HnGPnWgNlAf2C5rM7jmgQTb0Y5jIED/JoiduZTjD65QKHE6SX5Kih4dF9uSDirtldvS6cfe7DzjN2u3rg0FWdKh7EuvDGC70BwWzRh7LabghXr5it30nONbOBwFTUiIkf0jEDB/BocOgFYRIAxX/4GmYPxAijShMGQjIfyFCO5s090Ouo+XFcFS6mQ81jD5VM6PvLbxYMdf1qbOfODd7S1HQjxxqQiYFYXCxYxeZiI+4JmaJVgHMN2Ux9opQoZMhHM8cXhM/8qD3zlL9MqIAlASq8niQyB9/YBLkLzoheCuxgXCYR4+xvSworT/sSm1de2HB8/7+aqd64+UeMI7HAPYptscLho9GTHZUwhHR0GFuadP2zb585YTR1SJ4wZEBfflKUmtEeyMNkc0CNv2UjSfAmZpiXPpznzKznbH2rwrL97/KPO3/Vn/kmTz1gM88Bmee+oFXMnrI8Yt5OqvGydV49TNAgQYlzGVhnkIy33fRE4RSQ9L4EiK+BzMgis6AufuPJqVy/mQTCkmmNhSzfX5AzzDEXofdThq2568tfET5i7EnBte3DSf7UKT5fORliNmAAGGjpHPD88YcxEIux/acBz3DoC0g/N1BnaYTJw10r7hWDCif8LC2QNmlYOh6C80PzSVhBTwJkSEdzal6fOZzbAoUx1p398Jwnfsy1v7Uh6TuMv64VzRZU+tfwdNun5TwOejKeG4R9yH0Rp/4MCExy++OjqKfcAbQdIPwIjB9AE4MYnf+ggfBxTo42RtzJQ8fjcI2oEfQYkEnCfDU6qxbhBiAEqpKdQqTrtM0bcjd7QXmyufQNUx+/AXZtSodxMRc+63n1q/hEgXVJ6zRBFLj5icQ2riIaEU29qCxuP72HnjKqwmr4aTnMStMc6OXE6DGUxOaOJMHEOKYLkJjWCMLrl2By/o8hScp3KwluN0i6lPUpO4qQVHpzUA5xiXVtnyN5ct2aiTmQAvmwoO+pCIHqYy5P9hmlWuJhIL8fth/pYnbLF4xuhp2Ie5GHVnA/h4aEbXQSDQpvON2LXRvoHTGEuoDbzzw9d5389gXl8LHvzFMtXT32ra1KYb41JsiuG7T3v/TAwIB9WMwIHrcu+7+ILRE5F/OxVx2ymwjPGIxofjeQAoHALCIFutt1lY+8cweeznq+2oa8X0shrHVVuuem7zh+EYNL1pyPsjOGP8X2BdWPvp7/8PMTP0Yo+m6rIAAAAASUVORK5CYII="/></a>
        <span class="asui vertical-middle-align"><span id='isengard-account-link'>Loading...</span></span>
        </span>
        </li>
        </ul>
        <ul class="asui isengard-navbar-cc">
        <li class="nav-item">
             <a class="asui" target="_blank" rel="noopener noreferrer" href="https://lse.amazon.com"><img class="asui vertical-middle-align" style="display:none" id="lse-check" src="" alt="lse"></a>
        </li>
        <li class="nav-item">
            <a class="asui" target="_blank" rel="noopener noreferrer" id="close-isengard-banner" aria-label="Close Isengard Banner">
                <svg class="asui vertical-middle-align" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" focusable="false" aria-hidden="true" style="cursor: pointer;height:1.6rem; width:2rem; stroke-width:2px; stroke:rgb(246, 246, 246)">
                    <path d="M2 2l12 12M14 2L2 14"></path>
                </svg>
            </a>
        </li>
       <div id='change-control-span' />
    </ul>`
}

function closeBanner() {
    let banner = document.getElementById('banner-container')
    if (banner) {
        banner.style.display = 'none'

        // tell the console that the window has resized so that it will fill in the
        // (now) vacant space
        try {
            window.dispatchEvent(new Event('resize'))
        } catch (e) {}
    }
}

function generateBannerElement() {
    var banner = document.createElement('div')
    banner.classList.add('asui')
    banner.classList.add('isengard-navbar')
    banner.id = 'banner-container'
    banner.innerHTML = generateBannerInnerMarkup()
    return banner
}

function injectForNewNav() {
    var consoleBody = document.getElementById('consoleNavHeader')

    if (consoleBody) {
        document.body.classList.add('isengard-banner')

        var banner = generateBannerElement()
        consoleBody.prepend(banner)

        return true
    }

    return false
}

function injectForCorrectNavVersion() {
    return injectForNewNav()
}

function injectOnConsolePage() {
    var cookieUserInfo = accountInfoFromSessionData()
    var accountId = cookieUserInfo.accountId
    var role = cookieUserInfo.role

    if (!injectForCorrectNavVersion()) return

    let closeButton = document.getElementById('close-isengard-banner')
    if (closeButton) {
        closeButton.addEventListener('click', closeBanner)
    }

    try {
        window.dispatchEvent(new Event('resize'))
    } catch (e) {}

    callIsengardForCSRF('com.amazon.isengard.coral.IsengardService.Hello', '{}', function (helloData) {
        var helloJson = JSON.parse(JSON.parse(helloData.responseText).message)
        var isChangeControlDay = helloJson.changeControlDay == 'true'
        var csrfToken = getCSRFToken(helloData)
        callIsengardFunction(
            csrfToken,
            'com.amazon.isengard.coral.IsengardService.GetAWSAccount',
            '{"AWSAccountID" : "' + accountId + '"}',
            function (accountData) {
                var parsesdResponseText = JSON.parse(accountData.responseText)
                var email =
                    parsesdResponseText && parsesdResponseText.AWSAccount && parsesdResponseText.AWSAccount.Email
                callIsengardFunction(
                    csrfToken,
                    'com.amazon.isengard.coral.IsengardService.GetAWSAccountClassification',
                    '{"AWSAccountID" : "' + accountId + '"}',
                    function (data) {
                        var resp = JSON.parse(data.responseText)
                        var isProd = false
                        if (Object.keys(resp).includes('AWSAccountClassification')) {
                            isProd = resp.AWSAccountClassification.IsProduction
                        }
                        var unclassified = !data.responseText.includes('true') && !data.responseText.includes('false')
                        var message = email + ' - ' + accountId + ' / ' + role + ' '
                        if (unclassified) {
                            message += '(Unclassified Account)'
                        } else if (isProd) {
                            GM['isProd'] = true
                            message += '(Production Account)'
                        } else {
                            message += '(Not Production Account)'
                        }
                        var changeControlSpan = document.createElement('div')
                        if (isChangeControlDay) {
                            changeControlSpan.innerHTML = `<li class="nav-item">
                        <span><a target="_blank" rel="noopener noreferrer" href="${getWikiUrl()}/index.php/AWS/ChangeControlPolicy">AWS Change Control Advisory</a></span>
                        </li>`
                            document.getElementById('change-control-span').replaceWith(changeControlSpan)
                        }

                        if (isProd) {
                            document.getElementById('banner-container').classList.add('production')
                        }
                        var link = document.createElement('a')
                        link.href = `${getPortalUrl()}/account/${accountId}`
                        link.rel = 'noopener noreferrer'
                        link.target = '_blank'
                        var linkText = document.createTextNode(message)
                        link.appendChild(linkText)

                        var banner = document.getElementById('isengard-account-link')
                        if (banner) {
                            banner.innerHTML = ''
                            banner.appendChild(link)
                        }
                    }
                )
            }
        )
    })
}

function injectOnIsengardPage() {
    localStorage.isengardAwsBannerVersion = GM.info.script.version
}

function currentUrl() {
    if (top.location != self.location) {
        // X-site security settings may make this call fail, fallback to referrer.
        try {
            return window.parent.location.href
        } catch (e) {
            return document.referrer
        }
    } else {
        return window.location.href
    }
}

function getServiceUrl() {
    var url = 'https://isengard-service.amazon.com'
    if (/console.amazonaws.cn\//.test(currentUrl())) {
        url = 'https://isengard-service.bjs.aws-border.com'
    } else if (/console.amazonaws-us-gov.com\//.test(currentUrl())) {
        url = 'https://isengard-service.pdt.aws-border.com'
    } else if (/console.amazonaws(-eusc)?.eu\//.test(currentUrl())) {
        url = 'https://isengard-service.eusc-de-east-1.amazonaws.eu'
    } else if (/console.c2shome.ic.gov\//.test(currentUrl())) {
        url = 'https://isengard-service.dca.c2s-border.ic.gov'
    } else if (/console.sc2shome.sgov.gov\//.test(currentUrl())) {
        url = 'https://isengard-service.sc2s.sgov.gov'
    } else if (/console.csphome.adc-e.uk\/|console.awshome.adc-e.uk\//.test(currentUrl())) {
        url = 'https://isengard-service.ncl.aws-border.adc-e.uk'
    } else if (/console.csphome.hci.ic.gov\/|console.awshome.hci.ic.gov\//.test(currentUrl())) {
        url = 'https://isengard-service.ale.aws-border.hci.ic.gov'
    }
    return url
}

function getPortalUrl() {
    var url = 'https://isengard.amazon.com'
    if (/console.amazonaws.cn\//.test(currentUrl())) {
        url = 'https://isengard.bjs.aws-border.com'
    } else if (/console.amazonaws-us-gov.com\//.test(currentUrl())) {
        url = 'https://isengard.pdt.aws-border.com'
    } else if (/console.amazonaws(-eusc)?.eu\//.test(currentUrl())) {
        url = 'https://isengard.eusc-de-east-1.amazonaws.eu'
    } else if (/console.c2shome.ic.gov\//.test(currentUrl())) {
        url = 'https://isengard.dca.c2s-border.ic.gov'
    } else if (/console.sc2shome.sgov.gov\//.test(currentUrl())) {
        url = 'https://isengard.sc2s.sgov.gov'
    } else if (/console.csphome.adc-e.uk\/|console.awshome.adc-e.uk\//.test(currentUrl())) {
        url = 'https://isengard.ncl.aws-border.adc-e.uk'
    } else if (/console.csphome.hci.ic.gov\/|console.awshome.hci.ic.gov\//.test(currentUrl())) {
        url = 'https://isengard.ale.aws-border.hci.ic.gov'
    }
    return url
}

function getWikiUrl() {
    let url = 'https://w.amazon.com'
    if (/(console|awsc-integ|tardigrade)\.c2shome\.ic\.gov\//.test(currentUrl())) {
        url = 'https://w.dca.c2s-border.ic.gov'
    } else if (/(console|awsc-integ|tardigrade)\.sc2shome\.sgov\.gov\//.test(currentUrl())) {
        url = 'https://w.lck.aws-border.sgov.gov'
    } else if (/(console|awsc-integ|tardigrade)\.csphome\.adc-e\.uk\//.test(currentUrl())) {
        url = 'https://w.ncl.aws-border.adc-e.uk'
    } else if (/(console|awsc-integ|tardigrade)\.csphome\.hci\.ic\.gov\//.test(currentUrl())) {
        url = 'https://w.ale.aws-border.hci.ic.gov'
    } else if (/(console|awsc-integ|tardigrade)\.amazonaws(-eusc)?\.eu\//.test(currentUrl())) {
        url = 'https://w.amazon.com'
    }
    return url
}

function accountInfoFromSessionData() {
    // Pulls account ID and role from Amazon Resource Name (ARN) listed in awsc-session-data meta tag

    let awscSessionData = document.querySelector('meta[name="awsc-session-data"]').content
    awscSessionData = JSON.parse(awscSessionData)

    let accountId = awscSessionData.accountId
    let role = awscSessionData.sessionARN.split('assumed-role/')[1].split('/')[0]

    return {
        accountId: accountId,
        role: role,
    }
}

function getCSRFToken(responseHeaders) {
    var headersSplit = responseHeaders.responseHeaders.split('\n')
    for (var i = 0; i < headersSplit.length; i++) {
        if (headersSplit[i].indexOf('anti-csrftoken-a2z') == 0) {
            return headersSplit[i].split(': ')[1]
        }
    }
    return ''
}

function callIsengardForCSRF(operation, data, successHandler) {
    var url = getServiceUrl()
    GM.xmlHttpRequestMcs({
        method: 'POST',
        url: url,
        headers: {
            'anti-csrftoken-a2z-request': true,
            'Content-Encoding': 'amz-1.0',
            'X-Amz-Target': operation,
            'Content-Type': 'application/json; charset=UTF-8',
        },
        xhrFields: {
            withCredentials: true,
        },
        data: data,
        onload: function (response) {
            successHandler(response)
        },
        onerror: (e) => {
            var cookieUserInfo = accountInfoFromSessionData()
            var accountId = cookieUserInfo.accountId
            var role = cookieUserInfo.role

            var link = document.createElement('a')
            link.href = getPortalUrl()
            link.rel = 'noopener noreferrer'
            link.target = '_blank'
            var linkText = document.createTextNode(
                ` ${accountId} - ${role} (Sign in to Isengard and refresh to get account classification details)`
            )
            link.appendChild(linkText)

            var banner = document.getElementById('isengard-account-link')
            if (banner) {
                banner.innerHTML = ''
                banner.appendChild(link)
            }
        },
    })
}

function callIsengardFunction(csrfToken, operation, data, successHandler) {
    var url = getServiceUrl()
    GM.xmlHttpRequestMcs({
        method: 'POST',
        url: url,
        headers: {
            'anti-csrftoken-a2z': csrfToken,
            'Content-Encoding': 'amz-1.0',
            'X-Amz-Target': operation,
            'Content-Type': 'application/json; charset=UTF-8',
        },
        xhrFields: {
            withCredentials: true,
        },
        data: data,
        onload: function (response) {
            successHandler(response)
        },
    })
}

/***********************************************************
 *               Account Protection Tasks                   *
 *       SEE: https://sim.amazon.com/issues/CFN-31272       *
 *           This is owned by CloufFormation                *
 *               Cut ticket to CTI:                         *
 *    AWS/CloudFormation/Amazon Internal Deployment Safety  *
 *                If Issue Arises                           *
 ************************************************************/
function setCookie(c_name, value, expiredays) {
    var exdate = new Date()
    exdate.setDate(exdate.getDate() + expiredays)
    document.cookie = c_name + '=' + escape(value) + (expiredays == null ? '' : ';expires=' + exdate.toUTCString())
}

function getCookie(name) {
    const value = `; ${document.cookie}`
    const parts = value.split(`; ${name}=`)
    if (parts.length === 2) return parts.pop().split(';').shift()
}
function protectProductionAccounts() {
    if (GM['isProd']) {
        disableCloudFormationActions()
    }
}

function disableCloudFormationActions() {
    var deleteStackButtons = document.getElementsByClassName('e2e-test-delete-stack-button')
    for (let item of deleteStackButtons) {
        if (item.component) {
            if (!item.component.disabled) {
                item.component.disabled = true
            }
            item.component.text = 'Delete - Disabled by Isengard Banner in Prod'
        } else if (!getCookie('alerted')) {
            window.alert(
                'Stack delete button was found but could not be disabled by Isengard Banner in Prod. Proceed with caution!'
            )
            setCookie('alerted', 1, 1)
        }
        item.onclick = (e) => window.alert('This action has been disabled by Isengard Banner, use an MCM')
    }
}

/*****************************************************************
 *                 Account Protection Tasks                       *
 *  SEE: https://sim.amazon.com/issues/PaymentsProcessing-14317   *
 *             This is owned by AWS Payments / IAM                *
 *                     Cut ticket to CTI:                         *
 *             AWS / Payments / Payment Processing                *
 *                       If Issue Arises                          *
 *****************************************************************/

function disableMakeAccessKeyInactive() {
    var accessKeyTable = document.getElementsByClassName('data ng-scope')
    for (let item of accessKeyTable) {
        var row = item.firstElementChild
        if (row.children.length === 5) {
            var deactivate = false

            var curDate = new Date()
            var createdDate = row.children[1].innerText
            var lastUsedDate = row.children[2].innerText

            createdDate = getDate(createdDate)
            deactivate = shouldDeactivate(curDate, createdDate)

            if (!'N/A' == lastUsedDate) {
                lastUsedDate = getDate(lastUsedDate)
                deactivate = shouldDeactivate(curDate, lastUsedDate)
            }

            if (deactivate) {
                var statusColumn = row.children[3]
                var button = statusColumn.lastElementChild
                button.style = 'pointer-events:none; text-decoration:line-through'
                var span = button.firstChild
                span.style = 'pointer-events:all'
                span.onclick = (e) => {
                    window.alert(
                        'This action has been disabled by Isengard Banner. Created or Last Used date within 30 days. Please use MCM and disable Isengard Banner Script if you would like to continue.'
                    )
                    e.stopPropagation()
                }
            }
        }
    }
}

// Parses the date / time text seen on console and creates the corresponding Date object
function getDate(text) {
    return new Date(text.slice(0, 4), text.slice(5, 7) - 1, text.slice(8, 10), text.slice(11, 13), text.slice(14, 16))
}

// Compares the current date and target date. If less than thirty days, return true and we should deactivate the ability to make Access Key inactive.
function shouldDeactivate(curDate, targetDate) {
    return (curDate.getTime() - targetDate.getTime()) / (1000 * 3600 * 24) < 30
}
