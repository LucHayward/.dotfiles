// ==UserScript==
// @name         StoreGen Browser Extension
// @namespace    http://tampermonkey.net/
// @version      0.26.0
// @description  Development tools for Amazon internal sites
// @author       StoreGen Team
// @match        https://code.amazon.com/reviews/CR-*/revisions/*
// @match        https://code.amazon.com/packages/*
// @match        https://sim.amazon.com/issues/*
// @match        https://issues.amazon.com/issues/*
// @match        https://taskei.amazon.dev/tasks/*
// @match        https://taskei.amazon.dev/rooms/*
// @match        https://*.atlassian.net/browse/*
// @match        https://*.labcollab.net/browse/*
// @match        https://app.asana.com/*
// @match        https://pipelines.amazon.dev/pipelines/*
// @match        https://pipelines.amazon.dev/pipelines-wip/*
// @updateURL    https://drive-render.corp.amazon.com/view/StoreGen-CodeGen/GreaseMonkey%20Script/storegen-browser-extension.user.js
// @downloadURL  https://drive-render.corp.amazon.com/view/StoreGen-CodeGen/GreaseMonkey%20Script/storegen-browser-extension.user.js
// @connect      amazon.com
// @connect      amazon.dev
// @connect      amazon.work
// @connect      atlassian.net
// @connect      quip-amazon.com
// @connect      aws.dev
// @connect      a2z.com
// @connect      labcollab.net
// @grant        GM_xmlhttpRequest
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_registerMenuCommand
// @grant        GM_openInTab
// @require      https://cdn.jsdelivr.net/npm/markdown-it@14.1.0/dist/markdown-it.min.js
// @require      https://cdn.jsdelivr.net/npm/turndown@7.2.0/dist/turndown.min.js
// ==/UserScript==

/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// ./src/core/logger.js
/**
 * Logging utility for StoreGen Browser Extension
 * Provides consistent, styled console logging
 */

/**
 * Logs messages with StoreGen branding
 * @param {...any} args - Arguments to log
 */
function logger_log(...args) {
  console.log(
    "%c[StoreGen]",
    "background: linear-gradient(90deg, rgba(0,0,0,1) 0%, rgba(0,49,129,1) 20%, rgba(32,116,213,1) 50%, rgba(244,110,187,1) 85%, rgba(255,173,151,1) 100%); color: white; font-weight: bold; padding: 2px 6px; border-radius: 3px;",
    ...args,
  );
}

;// ./src/core/storage.js
// Storage utilities for managing localStorage state across code reviews


const SELECTIONS_STORAGE_KEY = "codegen-selections";
const JOBS_STORAGE_KEY = "codegen-jobs";
const JOB_HISTORY_STORAGE_KEY = "storegen-job-history";
const MAX_HISTORY_JOBS = 5;

// Generic storage helpers
function getStorageItem(storageKey, codeReviewKey) {
  const allData = JSON.parse(localStorage.getItem(storageKey) || "{}");
  return allData[codeReviewKey];
}

function setStorageItem(storageKey, codeReviewKey, value) {
  const allData = JSON.parse(localStorage.getItem(storageKey) || "{}");
  if (
    value === undefined ||
    value === null ||
    (typeof value === "object" && Object.keys(value).length === 0)
  ) {
    delete allData[codeReviewKey];
  } else {
    allData[codeReviewKey] = value;
  }
  localStorage.setItem(storageKey, JSON.stringify(allData));
}

function clearStorageItem(storageKey, codeReviewKey) {
  const allData = JSON.parse(localStorage.getItem(storageKey) || "{}");
  delete allData[codeReviewKey];
  localStorage.setItem(storageKey, JSON.stringify(allData));
}

// Comment selection state
function getStoredState(codeReviewKey) {
  return getStorageItem(SELECTIONS_STORAGE_KEY, codeReviewKey) || {};
}

function setCommentSelected(codeReviewKey, commentId, selected) {
  const crData = getStorageItem(SELECTIONS_STORAGE_KEY, codeReviewKey) || {};
  
  if (selected) {
    crData[commentId] = true;
  } else {
    delete crData[commentId];
  }
  
  setStorageItem(SELECTIONS_STORAGE_KEY, codeReviewKey, crData);
  logger_log("setCommentSelected:", commentId, selected);
}

function clearStoredState(codeReviewKey) {
  logger_log("clearStoredState called");
  clearStorageItem(SELECTIONS_STORAGE_KEY, codeReviewKey);
}

// Job tracking
function getStoredJob(codeReviewKey) {
  return getStorageItem(JOBS_STORAGE_KEY, codeReviewKey);
}

function setStoredJob(codeReviewKey, jobId) {
  logger_log("setStoredJob:", jobId);
  setStorageItem(JOBS_STORAGE_KEY, codeReviewKey, jobId);
}

function clearStoredJob(codeReviewKey) {
  clearStorageItem(JOBS_STORAGE_KEY, codeReviewKey);
}

// Job history
function getJobHistory(codeReviewKey) {
  const allHistory = JSON.parse(
    localStorage.getItem(JOB_HISTORY_STORAGE_KEY) || "{}",
  );
  return allHistory[codeReviewKey] || [];
}

function saveJobToHistory(codeReviewKey, jobData) {
  const allHistory = JSON.parse(
    localStorage.getItem(JOB_HISTORY_STORAGE_KEY) || "{}",
  );
  const crHistory = allHistory[codeReviewKey] || [];

  // Check if job already exists
  const existingIndex = crHistory.findIndex(
    (job) => job.jobId === jobData.jobId,
  );
  if (existingIndex !== -1) {
    logger_log("Job already in history, skipping:", jobData.jobId);
    return;
  }

  // Add new job at beginning (newest first)
  crHistory.unshift(jobData);

  // Keep only last MAX_HISTORY_JOBS
  if (crHistory.length > MAX_HISTORY_JOBS) {
    crHistory.splice(MAX_HISTORY_JOBS);
  }

  allHistory[codeReviewKey] = crHistory;
  localStorage.setItem(JOB_HISTORY_STORAGE_KEY, JSON.stringify(allHistory));
  logger_log("Saved job to history:", jobData.jobId);
}

;// ./src/core/kiroAgent.js
// Single feature flag controlling whether jobs are routed to the Kiro agent
// (with AIM). When enabled, all outgoing CodeGen invoke requests are stamped
// with `agent: "kiro"` so the backend can dispatch them to the Kiro path.
//
// Storage strategy:
//   localStorage is the primary store because it's shared across userscripts
//   on the same origin — both this main extension and the sibling AutoSDE
//   userscript run on code.amazon.com/reviews/* and need to see the same
//   value. Tampermonkey's GM_getValue/GM_setValue are isolated per-script
//   (keyed by @name+@namespace), so they can't satisfy that.
//
//   GM_setValue is also written from the main extension as a mirror, so the
//   flag remains visible across origins where the main extension runs (SIM,
//   Taskei, Jira, Asana, Pipelines) when the user hasn't visited that origin
//   since toggling. localStorage is checked first so AutoSDE on CRUX always
//   sees the latest value.


const KIRO_AGENT_KEY = 'storegen-kiro-agent';

function isKiroAgentEnabled() {
  if (typeof localStorage !== 'undefined') {
    const ls = localStorage.getItem(KIRO_AGENT_KEY);
    if (ls === 'true') return true;
    if (ls === 'false') return false;
  }
  if (typeof GM_getValue !== 'undefined') {
    return GM_getValue(KIRO_AGENT_KEY, false);
  }
  return false;
}

function setKiroAgentEnabled(enabled) {
  if (typeof localStorage !== 'undefined') {
    localStorage.setItem(KIRO_AGENT_KEY, String(enabled));
  }
  if (typeof GM_setValue !== 'undefined') {
    GM_setValue(KIRO_AGENT_KEY, enabled);
  }
  logger_log('Kiro + AIM', enabled ? 'enabled' : 'disabled');
}

function registerKiroAgentMenu() {
  const enabled = isKiroAgentEnabled();
  const label = enabled ? '🤖 Disable Kiro + AIM' : '🤖 Enable Kiro + AIM';
  GM_registerMenuCommand(label, () => {
    setKiroAgentEnabled(!enabled);
    window.location.reload();
  });
}

;// ./src/core/config.js
/**
 * Configuration constants for StoreGen Browser Extension
 */

// API Configuration
const CODEGEN_API_BASE_URL = "https://prod.codegen.storegen.amazon.dev";
const INVOKE_ENDPOINT = `${CODEGEN_API_BASE_URL}/invoke`;
const JOB_ENDPOINT = (jobId) => `${CODEGEN_API_BASE_URL}/job/${jobId}`;
const JOBS_ENDPOINT = `${CODEGEN_API_BASE_URL}/jobs`;

// Polling Configuration
const POLLING_INTERVAL_MS = 30000; // 30 seconds
const POLLING_TIMEOUT_MINUTES = 55;
const MAX_POLL_ATTEMPTS = Math.ceil(
  (POLLING_TIMEOUT_MINUTES * 60 * 1000) / POLLING_INTERVAL_MS,
); // 110 attempts

// UI Configuration
const CHECKBOX_CHECK_INTERVAL_MS = 1000; // Check for new comments every second
const config_STATUS_CARD_REMOVE_DELAY_MS = 300; // Delay before removing hidden status card

// CSS Selectors
const SELECTORS = {
  PUBLISHED_COMMENTS: ".comment-box.published",
  CHECKED_CHECKBOXES: '.comment-box input[type="checkbox"]:checked',
  COMMENT_BODY: ".body.markdown",
  COMMENT_AUTHOR: '.entity[data-id] a, .entity[data-id], a[href*="/reviews/to-entity/"], .byline .entity a, .header .user-name, .header .name, [data-author], .comment-author',
  CHECKBOX_BANNER: ".storegen-checkbox-banner",
  CR_STATUS_BADGE: ".crux-ui-cr-status-label .awsui-badge-content",
};

// StoreGen Logo SVG
const STOREGEN_LOGO_SVG = `
  <defs>
    <linearGradient id="sg-grad1" x1="179.23" y1="309.45" x2="1103.52" y2="309.45" gradientUnits="userSpaceOnUse">
      <stop offset=".1" stop-color="#5842d6"/>
      <stop offset=".55" stop-color="#9f158f"/>
      <stop offset=".94" stop-color="#dc5f74"/>
    </linearGradient>
    <linearGradient id="sg-grad2" x1="973.67" y1="7.72" x2="263.02" y2="718.37" gradientUnits="userSpaceOnUse">
      <stop offset=".15" stop-color="#00b99e"/>
      <stop offset=".54" stop-color="#0076ff"/>
      <stop offset=".91" stop-color="#002afb"/>
    </linearGradient>
    <linearGradient id="sg-grad3" x1="953.38" y1="57.04" x2="298.27" y2="712.15" xlink:href="#sg-grad2"/>
  </defs>
  <g>
    <g>
      <path fill="url(#sg-grad1)" d="M1103.52,286.78l-2.36,317.07c-.03,3.51-2.84,6.35-6.36,6.42-27.62.56-138.81,2.59-193.1.51-113.73-4.36-216.99-30.65-283.77-150.5-28.69-51.5-19.75-97.3-90.42-115.07-73.53-18.48-156.19,8.73-228.93-14.09C116.61,274.04,150.66,22.82,346.89,9.79c65.32-4.34,142.08-1.46,208.74-2.44,29.77-.44,59.6.26,89.37.24,6.02,0,8.88,7.36,4.34,11.31-6.23,5.42-13.45,11.75-18.75,16.57-25.09,22.8-45.78,49.02-65.45,76.46l-203.4.42c-86.65,8.31-88.03,112.84-11.66,123.73,99.32,14.16,188.81-26.43,278.12,48.16,56.29,47.01,48.18,100.15,88.43,151.2,23.91,30.32,58.02,50.97,95.2,61.55,42.72,12.15,131.71,12.12,176.24,10.57,4.2-.15,6.31-.3,8.47-3.78v-124.01c0-3.58-2.92-6.47-6.51-6.47h-104.81c-3.61,0-6.53-2.92-6.51-6.51l.43-82.16c.02-3.57,2.92-6.45,6.51-6.44,63.14.11,182.5,1.69,211.47,2.09,3.58.05,6.43,2.96,6.41,6.52Z"/>
      <path fill="url(#sg-grad2)" d="M857.79,112.32c-96.67,13.24-121.15,71.26-165.54,138.02-1.4,2.1-1.73,4.66-3.94,3.51-2.42-1.26-24.16-19.24-32.18-25.18-20.52-15.2-37.26-27.33-61.04-36.9,34.2-70.57,71.91-114.52,129.68-145.71,60.12-32.46,128.29-39.16,197.5-39.53,51.04-.27,146.83.84,172.54,1.16,3.6.04,6.44,2.99,6.39,6.57l-1.4,91.69c-.05,3.54-2.95,6.38-6.51,6.38,0,0-177.16-7.99-235.48,0Z"/>
      <path fill="url(#sg-grad3)" d="M501.7,507.43c26.54-1.43,40.88-11.5,58.7-19.33,18.16,27.79,36.69,55.5,60.35,79.16l-17.94,13.76c-30.69,17.87-50.53,23.99-98.55,28.95l-267.52,1.82c-6.01.04-8.86-7.33-4.38-11.3l103.04-91.39c63.08.39,130.97.23,166.3-1.66Z"/>
    </g>
    <path fill="#002afb" d="M272.24,424.12l56.68,20.61c2.24.81,2.24,3.97,0,4.79l-56.68,20.61c-20.69,7.53-37.02,23.78-44.62,44.45l-20.7,56.22c-.82,2.22-3.96,2.22-4.78,0l-20.7-56.22c-7.61-20.66-23.93-36.92-44.62-44.45l-56.68-20.61c-2.24-.81-2.24-3.97,0-4.79l56.68-20.61c20.69-7.53,37.02-23.78,44.62-44.45l20.7-56.22c.82-2.22,3.96-2.22,4.78,0l20.7,56.22c7.61,20.66,23.93,36.92,44.62,44.45Z"/>
    <path fill="#002afb" d="M102.33,529.01l27.37-14.71c1.47-.79,3.07.82,2.27,2.28l-14.63,26.87c-6.61,12.15-6.61,26.83,0,38.97l14.63,26.87c.8,1.47-.8,3.07-2.27,2.28l-27.37-14.71c-12.05-6.48-26.55-6.48-38.6,0l-27.37,14.71c-1.47.79-3.07-.82-2.27-2.28l14.63-26.87c6.61-12.15,6.61-26.83,0-38.97l-14.63-26.87c-.8-1.47.8-3.07,2.27-2.28l27.37,14.71c12.05,6.48,26.55,6.48,38.6,0Z"/>
  </g>
  <g opacity=".1">
    <path fill="#fff" d="M272.24,424.12l56.68,20.61c2.24.81,2.24,3.97,0,4.79l-56.68,20.61c-20.69,7.53-37.02,23.78-44.62,44.45l-20.7,56.22c-.82,2.22-3.96,2.22-4.78,0l-20.7-56.22c-7.61-20.66-23.93-36.92-44.62-44.45l-56.68-20.61c-2.24-.81-2.24-3.97,0-4.79l56.68-20.61c20.69-7.53,37.02-23.78,44.62-44.45l20.7-56.22c.82-2.22,3.96-2.22,4.78,0l20.7,56.22c7.61,20.66,23.93,36.92,44.62,44.45Z"/>
    <path fill="#fff" d="M102.33,529.01l27.37-14.71c1.47-.79,3.07.82,2.27,2.28l-14.63,26.87c-6.61,12.15-6.61,26.83,0,38.97l14.63,26.87c.8,1.47-.8,3.07-2.27,2.28l-27.37-14.71c-12.05-6.48-26.55-6.48-38.6,0l-27.37,14.71c-1.47.79-3.07-.82-2.27-2.28l14.63-26.87c6.61-12.15,6.61-26.83,0-38.97l-14.63-26.87c-.8-1.47.8-3.07,2.27-2.28l27.37,14.71c12.05,6.48,26.55,6.48,38.6,0Z"/>
  </g>
`;

;// ./src/core/api.js
// CodeGen API client for job submission and polling




/**
 * Enhances error messages for authentication failures
 * @param {string} errorMessage - The original error message
 * @returns {string} Enhanced error message with authentication guidance
 */
function enhanceErrorMessage(errorMessage) {
  if (errorMessage && errorMessage.toLowerCase().includes('unauthenticated')) {
    return `${errorMessage}. Please navigate to the following URL and then retry: https://prod.codegen.storegen.amazon.dev/hello`;
  }
  return errorMessage;
}

/**
 * Submits a CodeGen job with custom instructions
 * Generic function that can be used for any CodeGen job submission
 * @param {string} instructions - Formatted instructions string
 * @param {Function} onSuccess - Callback on successful submission (jobId, jobUrl)
 * @param {Function} onError - Callback on error (errorMessage)
 * @param {string} [tag] - Optional tag for the job (max 512 chars)
 * @param {Array<{url: string, content: string}>} [referenceLinks] - Optional reference links
 */
function submitJobWithInstructions(instructions, onSuccess, onError, tag = null, referenceLinks = null) {
  const requestBody = { instructions };
  if (tag) requestBody.tag = tag;
  if (referenceLinks && referenceLinks.length > 0) requestBody.reference_links = referenceLinks;
  if (isKiroAgentEnabled()) requestBody.agent = 'kiro';

  const requestJson = JSON.stringify(requestBody);
  const requestSizeBytes = new Blob([requestJson]).size;
  logger_log("Request size:", (requestSizeBytes / 1024).toFixed(2), "KB");
  logger_log("Request body:", JSON.stringify(requestBody, null, 2));

  GM_xmlhttpRequest({
    method: "POST",
    url: INVOKE_ENDPOINT,
    headers: { "Content-Type": "application/json" },
    data: JSON.stringify(requestBody),
    withCredentials: true,
    onload: function (response) {
      logger_log("API response received, status:", response.status);
      logger_log("Raw response text:", response.responseText);
      try {
        const data = JSON.parse(response.responseText);
        logger_log("CodeGen API Response:", data);
        if (data.success === true) {
          // Check if request was rejected due to validation or guardrails
          if (data.state === "INPUT_REQUIRED" || data.state === "REJECTED") {
            const errorMsg = data.message || "Request validation failed";
            logger_log(`Request rejected with ${data.state}:`, errorMsg);
            onError(enhanceErrorMessage(errorMsg));
          } else if (!data.jobId) {
            logger_log("Request succeeded but no jobId returned");
            onError("Job was accepted but no job ID was returned. Please try again.");
          } else {
            logger_log("Request successful");
            onSuccess(data.jobId, data.jobUrl || data.viewLogsUrl);
          }
        } else {
          const errorMsg = data.error || data.message || `Server error (${response.status})`;
          logger_log("Request failed:", errorMsg);
          onError(enhanceErrorMessage(errorMsg));
        }
      } catch (e) {
        logger_log("Error parsing response:", e);
        onError(enhanceErrorMessage("Failed to parse response: " + response.responseText));
      }
    },
    onerror: function (error) {
      logger_log("API request error:", error);
      onError(enhanceErrorMessage("Network error: " + (error.statusText || "Unknown error")));
    },
  });
}

/**
 * Submits a new CodeGen job for CRUX code review comments
 * @param {string} crId - Code review ID
 * @param {Array<{revision: number, post: number}>} commentIds - Array of comment identifiers
 * @param {Function} onSuccess - Callback on successful submission (jobId, jobUrl)
 * @param {Function} onError - Callback on error (errorMessage)
 * @param {string} [tag] - Optional tag for the job (max 512 chars)
 */
function submitJob(crId, commentIds, onSuccess, onError, tag = null) {
  const commentLines = commentIds.map(c => `- revision ${c.revision} comment ${c.post}`).join("\n");
  const instructions = `Generate a new revision on ${crId} that addresses these comments:\n${commentLines}`;
  submitJobWithInstructions(instructions, onSuccess, onError, tag);
}

/**
 * Fetches job details for an existing job
 * @param {string} jobId - The CodeGen job ID
 * @param {Function} onSuccess - Callback on successful fetch (jobData)
 * @param {Function} onError - Callback on error
 */
function fetchJobDetails(jobId, onSuccess, onError) {
  logger_log("Fetching job details for:", jobId);
  GM_xmlhttpRequest({
    method: "GET",
    url: JOB_ENDPOINT(jobId),
    withCredentials: true,
    onload: function (response) {
      try {
        const data = JSON.parse(response.responseText);
        logger_log("Job details fetched:", data);
        onSuccess(data);
      } catch (e) {
        logger_log("Error parsing job details:", e);
        onError(enhanceErrorMessage(e));
      }
    },
    onerror: function (error) {
      logger_log("Error fetching job details:", error);
      onError(enhanceErrorMessage(error));
    },
  });
}

/**
 * Polls job status until completion, failure, timeout, or cancellation
 * @param {string} jobId - The CodeGen job ID
 * @param {Function} onStatusUpdate - Callback on each status update (status, data)
 * @param {Function} onComplete - Callback on job completion (finalOutput)
 * @param {Function} onFailed - Callback on job failure (finalOutput)
 * @param {Function} onTimeout - Callback on polling timeout
 * @param {Function} onError - Callback on polling error
 * @returns {Object} Controller with cancel() method to stop polling
 */
function pollJobStatus(
  jobId,
  onStatusUpdate,
  onComplete,
  onFailed,
  onTimeout,
  onError,
) {
  let pollCount = 0;
  let cancelled = false;

  const poll = () => {
    if (cancelled) {
      logger_log("Polling cancelled for job:", jobId);
      return;
    }

    pollCount++;
    logger_log(
      `Polling job status (attempt ${pollCount}/${MAX_POLL_ATTEMPTS}):`,
      jobId,
    );

    GM_xmlhttpRequest({
      method: "GET",
      url: JOB_ENDPOINT(jobId),
      withCredentials: true,
      onload: function (response) {
        if (cancelled) return;

        try {
          const data = JSON.parse(response.responseText);
          logger_log("Job status poll response:", data);

          onStatusUpdate(data.status, data);

          if (data.status === "REJECTED" || data.status === "INPUT_REQUIRED") {
            logger_log(`Job rejected with status ${data.status}:`, jobId);
            onFailed(data.message || data.finalOutput, data);
          } else if (data.status === "IN_PROGRESS") {
            if (pollCount < MAX_POLL_ATTEMPTS) {
              setTimeout(poll, POLLING_INTERVAL_MS);
            } else {
              logger_log("Max polling attempts reached for job:", jobId);
              onTimeout();
            }
          } else if (data.status === "COMPLETED") {
            logger_log("Job completed successfully:", jobId);
            onComplete(data.finalOutput, data);
          } else if (data.status === "FAILED") {
            logger_log("Job failed:", jobId);
            onFailed(data.finalOutput, data);
          }
        } catch (e) {
          logger_log("Error parsing job status for job:", jobId, e);
          onError(enhanceErrorMessage(e));
        }
      },
      onerror: function (error) {
        if (cancelled) return;
        logger_log("Job status poll error for job:", jobId, error);
        onError(enhanceErrorMessage(error));
      },
    });
  };

  poll();

  return {
    cancel: () => {
      cancelled = true;
      logger_log("Cancel requested for job polling:", jobId);
    }
  };
}

;// ./src/ui/styles.js
// Global styles for StoreGen Browser Extension

/**
 * Injects all CSS styles into the document head
 * Should be called once during initialization
 */
function injectStyles() {
  const style = document.createElement("style");
  style.textContent = `
    /* ============================================
       ANIMATIONS
       ============================================ */
    @keyframes storegenFadeIn {
      from { opacity: 0; transform: translateY(-5px); }
      to { opacity: 1; transform: translateY(0); }
    }

    @keyframes gradientShift {
      0% { background-position: 0% 0%; }
      50% { background-position: 0% 100%; }
      100% { background-position: 0% 0%; }
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.6; }
    }

    @keyframes shake {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-6px); }
    }

    @keyframes buttonPulse {
      0%, 100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(22, 25, 31, 0.7); }
      50% { transform: scale(1.05); box-shadow: 0 0 0 10px rgba(22, 25, 31, 0); }
    }

    @keyframes confetti {
      0% { transform: translateY(0) rotate(0deg); opacity: 1; }
      100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
    }

    /* ============================================
       COMMENT CHECKBOX BANNERS
       ============================================ */
    .storegen-checkbox-container {
      display: flex;
      flex-direction: column;
      padding: 0 !important;
    }

    .awsui-util-container > .storegen-checkbox-banner,
    .storegen-checkbox-container > .storegen-checkbox-banner {
      display: flex;
      align-items: center;
      width: auto;
      max-width: 100%;
      padding: 10px 12px !important;
      margin: 0 !important;
      font-size: 13px;
      color: #333333;
      cursor: pointer;
      background: #f8f9fa;
      border: 1px solid #e9ecef;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      animation: storegenFadeIn 0.3s ease-in forwards;
    }

    .storegen-checkbox-banner input[type="checkbox"] {
      margin-right: 8px;
      cursor: pointer;
    }

    .storegen-checkbox-banner input[type="checkbox"]:disabled {
      cursor: not-allowed;
      opacity: 0.5;
    }

    .storegen-checkbox-banner:has(input[type="checkbox"]:disabled) {
      opacity: 0.6;
      cursor: not-allowed;
      background: #e9ecef;
      color: #6c757d;
    }

    .storegen-label-with-tooltip {
      position: relative;
    }

    .storegen-tooltip-text {
      visibility: hidden;
      position: absolute;
      top: 50%;
      left: 100%;
      transform: translateY(-50%);
      margin-left: 8px;
      background: #16191F;
      color: white;
      padding: 8px 12px;
      border-radius: 4px;
      font-size: 12px;
      white-space: nowrap;
      z-index: 10000;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
    }

    .storegen-tooltip-text::after {
      content: '';
      position: absolute;
      top: 50%;
      right: 100%;
      transform: translateY(-50%);
      border: 6px solid transparent;
      border-right-color: #16191F;
    }

    .storegen-tooltip-text a {
      color: #7dd3fc;
      text-decoration: none;
    }

    .storegen-tooltip-text a:hover {
      text-decoration: underline;
    }

    .storegen-checkbox-banner:hover .storegen-tooltip-text {
      visibility: visible;
    }

    /* ============================================
       ACTION BUTTON
       ============================================ */
    .storegen-action-button {
      position: relative;
      display: flex;
      align-items: center;
      background: #16191F;
      color: white;
      border: none;
      padding: 6px 16px 6px 16px;
      font-size: 14px;
      font-weight: 500;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      box-shadow: none;
      cursor: pointer;
    }

    .storegen-action-button::before {
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      width: 4px;
      background: linear-gradient(180deg,
        rgba(0,0,0,1) 0%,
        rgba(0,49,129,1) 10%,
        rgba(32,116,213,1) 25%,
        rgba(244,110,187,1) 40%,
        rgba(255,173,151,1) 50%,
        rgba(244,110,187,1) 60%,
        rgba(32,116,213,1) 75%,
        rgba(0,49,129,1) 90%,
        rgba(0,0,0,1) 100%);
      background-size: 100% 200%;
      background-position: 0% 0%;
      transition: background-position 0.6s ease;
    }

    .storegen-action-button:hover:not(:disabled)::before {
      background-position: 0% 100%;
    }

    .storegen-action-button:disabled {
      opacity: 0.7;
      cursor: not-allowed;
    }

    .storegen-logo {
      width: 36px;
      height: 36px;
      flex-shrink: 0;
      margin-right: 16px;
    }

    .storegen-action-button.job-working::before {
      animation: gradientShift 2s ease infinite;
    }

    .storegen-action-button.job-working span {
      animation: pulse 2s ease infinite;
    }

    .storegen-action-button.job-completed {
      background: #1e8900;
      border-left-color: #1e8900;
    }

    .storegen-action-button.job-completed::before {
      display: none;
    }

    .storegen-action-button.job-failed {
      background: #d13212;
      border-left-color: #d13212;
    }

    .storegen-action-button.job-failed::before {
      display: none;
    }

    .storegen-action-button.loading {
      opacity: 0.7;
    }

    /* ============================================
       PACKAGE HEADER BUTTON
       ============================================ */
    .storegen-package-header-button {
      position: relative !important;
      display: inline-flex !important;
      align-items: center !important;
      background: #16191F !important;
      color: white !important;
      border: none !important;
      border-radius: 4px !important;
      padding: 5px 12px !important;
      margin-right: 8px !important;
      font-size: 13px !important;
      font-weight: 500 !important;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif !important;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3) !important;
      cursor: pointer !important;
      transition: background 0.2s ease, box-shadow 0.2s ease !important;
      overflow: hidden !important;
      height: 32px !important;
      box-sizing: border-box !important;
    }

    .storegen-package-header-button::before {
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      width: 4px;
      background: linear-gradient(180deg,
        rgba(0,0,0,1) 0%,
        rgba(0,49,129,1) 10%,
        rgba(32,116,213,1) 25%,
        rgba(244,110,187,1) 40%,
        rgba(255,173,151,1) 50%,
        rgba(244,110,187,1) 60%,
        rgba(32,116,213,1) 75%,
        rgba(0,49,129,1) 90%,
        rgba(0,0,0,1) 100%);
      background-size: 100% 200%;
      background-position: 0% 0%;
      transition: background-position 0.6s ease;
    }

    .storegen-package-header-button:hover:not(:disabled) {
      background: #2a2e38;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
    }

    .storegen-package-header-button:hover:not(:disabled)::before {
      background-position: 0% 100%;
    }

    .storegen-package-header-button:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .storegen-package-header-button.attention-shake {
      animation: shake 3s ease-in-out infinite;
    }

    /* ============================================
       JOBS CONTAINER & ACCORDION ROWS
       ============================================ */
    .storegen-jobs-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      gap: 4px;
      max-width: 500px;
      max-height: 70vh;
      overflow-y: auto;
    }

    .storegen-jobs-container.storegen-dragging {
      cursor: grabbing !important;
      user-select: none;
    }

    .storegen-job-row {
      background: #16191F;
      color: white;
      font-size: 13px;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
      transition: all 0.2s ease;
      position: relative;
    }

    .storegen-job-row::before {
      content: '';
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      width: 4px;
      background: linear-gradient(180deg,
        rgba(0,0,0,1) 0%,
        rgba(0,49,129,1) 10%,
        rgba(32,116,213,1) 25%,
        rgba(244,110,187,1) 40%,
        rgba(255,173,151,1) 50%,
        rgba(244,110,187,1) 60%,
        rgba(32,116,213,1) 75%,
        rgba(0,49,129,1) 90%,
        rgba(0,0,0,1) 100%);
      background-size: 100% 200%;
    }

    .storegen-job-row.working::before {
      animation: gradientShift 2s ease infinite;
    }

    .storegen-job-row.completed::before {
      background: #4ade80;
    }

    .storegen-job-row.failed::before,
    .storegen-job-row.cancelled::before {
      background: #f87171;
    }

    .storegen-job-row.removing {
      opacity: 0;
      transform: translateX(100px);
    }

    .storegen-job-row-header {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 10px 12px 10px 16px;
      cursor: grab;
      transition: background 0.2s ease;
    }

    .storegen-job-row:not(.working) .storegen-job-row-header:hover {
      background: rgba(255, 255, 255, 0.05);
    }

    .storegen-job-row-logo {
      width: 20px;
      height: 20px;
      flex-shrink: 0;
    }

    .storegen-job-row-status-icon {
      width: 16px;
      height: 16px;
      border-radius: 50%;
      flex-shrink: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
    }

    .storegen-job-row-status-icon.working {
      border: 2px solid rgba(255, 255, 255, 0.3);
      border-top-color: white;
      animation: spin 1s linear infinite;
    }

    .storegen-job-row-status-icon.completed::after {
      content: '✓';
      color: #4ade80;
    }

    .storegen-job-row-status-icon.failed::after,
    .storegen-job-row-status-icon.cancelled::after {
      content: '✗';
      color: #f87171;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .storegen-job-row-title {
      font-weight: 500;
      flex-shrink: 0;
    }

    .storegen-job-row.working .storegen-job-row-title {
      animation: pulse 2s ease infinite;
    }

    .storegen-job-row-id {
      color: #9ca3af;
      font-size: 11px;
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .storegen-job-row-expand {
      color: #9ca3af;
      font-size: 10px;
      transition: transform 0.2s ease;
      flex-shrink: 0;
    }

    .storegen-job-row.working .storegen-job-row-expand {
      display: none;
    }

    .storegen-job-row.expanded .storegen-job-row-expand {
      transform: rotate(180deg);
    }

    .storegen-job-row-close {
      background: none;
      border: none;
      color: white;
      font-size: 18px;
      cursor: pointer;
      padding: 0;
      width: 20px;
      height: 20px;
      display: none;
      align-items: center;
      justify-content: center;
      opacity: 0.5;
      transition: opacity 0.2s ease;
      flex-shrink: 0;
    }

    .storegen-job-row-close.visible {
      display: flex;
    }

    .storegen-job-row-close:hover {
      opacity: 1;
    }

    .storegen-job-row-header-cancel {
      background: transparent;
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: white;
      padding: 4px 10px;
      font-size: 11px;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      cursor: pointer;
      border-radius: 3px;
      transition: background 0.2s ease, border-color 0.2s ease;
      flex-shrink: 0;
    }

    .storegen-job-row-header-cancel:hover {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.5);
    }

    .storegen-job-row-header-logs {
      background: transparent;
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: white;
      padding: 4px 10px;
      font-size: 11px;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      cursor: pointer;
      border-radius: 3px;
      transition: background 0.2s ease, border-color 0.2s ease;
      flex-shrink: 0;
      text-decoration: none;
    }

    .storegen-job-row-header-logs:hover {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.5);
      text-decoration: none;
    }

    .storegen-job-row-content {
      max-height: 0;
      overflow: hidden;
      transition: max-height 0.3s ease;
    }

    .storegen-job-row.expanded .storegen-job-row-content {
      max-height: 50vh;
      overflow-y: auto;
    }

    .storegen-job-row-body {
      padding: 0 16px 12px 16px;
      font-size: 12px;
      line-height: 1.4;
      opacity: 0.9;
    }

    .storegen-job-row-body h1,
    .storegen-job-row-body h2,
    .storegen-job-row-body h3,
    .storegen-job-row-body h4,
    .storegen-job-row-body h5,
    .storegen-job-row-body h6 {
      color: white;
      font-weight: 600;
      margin: 12px 0 8px 0;
      opacity: 1;
    }

    .storegen-job-row-body h1 { font-size: 16px; }
    .storegen-job-row-body h2 { font-size: 15px; }
    .storegen-job-row-body h3 { font-size: 14px; }
    .storegen-job-row-body h4,
    .storegen-job-row-body h5,
    .storegen-job-row-body h6 { font-size: 13px; }

    .storegen-job-row-body p {
      margin: 0 0 8px 0;
    }

    .storegen-job-row-body p:last-child {
      margin-bottom: 0;
    }

    .storegen-job-row-body ul,
    .storegen-job-row-body ol {
      margin: 0 0 8px 0;
      padding-left: 20px;
    }

    .storegen-status-body code {
      background: rgba(255, 255, 255, 0.15);
      padding: 2px 6px;
      border-radius: 3px;
      font-family: monospace;
      font-size: 11px;
      color: #e0e0e0;
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .storegen-job-row-body code {
      background: rgba(255, 255, 255, 0.1);
      padding: 2px 4px;
      border-radius: 2px;
      font-family: monospace;
      font-size: 11px;
      color: #e0e0e0;
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .storegen-job-row-body pre {
      background: rgba(255, 255, 255, 0.1);
      padding: 8px;
      border-radius: 4px;
      overflow-x: auto;
      margin: 0 0 8px 0;
    }

    .storegen-job-row-body pre code {
      background: none;
      padding: 0;
    }

    .storegen-job-row-body a {
      color: #7dd3fc;
      text-decoration: none;
    }

    .storegen-job-row-body a:hover {
      text-decoration: underline;
    }

    .storegen-job-row-body strong {
      font-weight: 600;
    }

    .storegen-job-row-link {
      display: inline-block;
      padding: 4px 10px;
      margin: 0 16px 12px 16px;
      color: #7dd3fc;
      text-decoration: none;
      font-size: 12px;
      cursor: pointer;
      border: 1px solid rgba(125, 211, 252, 0.3);
      border-radius: 3px;
      transition: border-color 0.2s ease;
    }

    .storegen-job-row-link:hover {
      border-color: rgba(125, 211, 252, 0.6);
      text-decoration: none;
    }

    /* ============================================
       JOB HISTORY PILLS
       ============================================ */
    .storegen-job-pills-container {
      position: fixed;
      right: 20px;
      bottom: 20px;
      z-index: 9998;
      display: flex;
      flex-direction: column-reverse;
      gap: 8px;
      transition: bottom 0.3s ease;
    }

    .storegen-job-pills-container.button-visible {
      bottom: 90px;
    }

    .storegen-job-pill {
      background: #16191F;
      color: white;
      border: 1px solid #2a2e38;
      border-radius: 6px;
      padding: 4px 8px;
      font-size: 11px;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.4);
      transition: background 0.2s ease, border-color 0.2s ease;
      white-space: nowrap;
    }

    .storegen-job-pill-icon {
      font-size: 12px;
      font-weight: bold;
    }

    .storegen-job-pill-icon.success {
      color: #4ade80;
    }

    .storegen-job-pill-icon.failed {
      color: #f87171;
    }

    .storegen-job-pill-text {
      color: #9ca3af;
    }

    /* ============================================
       SIM/TASKEI STATUS CARD (old-style vertical card)
       ============================================ */
    .storegen-status-card {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      background: #16191F;
      color: white;
      border: none;
      font-size: 13px;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.6);
      max-width: 500px;
      max-height: 60vh;
      transition: transform 0.3s ease, opacity 0.3s ease;
    }

    .storegen-status-card.hidden {
      transform: translateY(100px);
      opacity: 0;
    }

    .storegen-status-card::before {
      content: '' !important;
      position: absolute !important;
      left: 0 !important;
      top: 0 !important;
      bottom: 0 !important;
      width: 4px !important;
      z-index: 1 !important;
      background: linear-gradient(180deg,
        rgba(0,0,0,1) 0%,
        rgba(0,49,129,1) 10%,
        rgba(32,116,213,1) 25%,
        rgba(244,110,187,1) 40%,
        rgba(255,173,151,1) 50%,
        rgba(244,110,187,1) 60%,
        rgba(32,116,213,1) 75%,
        rgba(0,49,129,1) 90%,
        rgba(0,0,0,1) 100%) !important;
      background-size: 100% 200% !important;
    }

    .storegen-status-card.working::before {
      animation: gradientShift 2s ease infinite;
    }

    .storegen-status-header {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px 16px 12px 20px;
      flex-shrink: 0;
      cursor: grab;
    }

    .storegen-status-card.storegen-dragging .storegen-status-header {
      cursor: grabbing;
    }

    .storegen-status-card.storegen-dragging {
      user-select: none;
    }

    .storegen-status-content {
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding: 0 16px 12px 20px;
      overflow-y: auto;
    }

    .storegen-status-header .storegen-logo {
      width: 24px;
      height: 24px;
      flex-shrink: 0;
      margin-right: 0;
    }

    .storegen-status-title {
      font-weight: 600;
      font-size: 14px;
      flex: 1;
    }

    .storegen-status-close {
      background: none;
      border: none;
      color: white;
      font-size: 20px;
      cursor: pointer;
      padding: 0;
      width: 24px;
      height: 24px;
      display: none;
      align-items: center;
      justify-content: center;
      opacity: 0.7;
    }

    .storegen-status-close.visible {
      display: flex;
    }

    .storegen-status-body {
      font-size: 12px;
      line-height: 1.4;
      opacity: 0.9;
    }

    .storegen-status-body h1,
    .storegen-status-body h2,
    .storegen-status-body h3,
    .storegen-status-body h4,
    .storegen-status-body h5,
    .storegen-status-body h6 {
      color: white;
      font-weight: 600;
      margin: 12px 0 8px 0;
      opacity: 1;
    }

    .storegen-status-body h1 { font-size: 16px; }
    .storegen-status-body h2 { font-size: 15px; }
    .storegen-status-body h3 { font-size: 14px; }

    .storegen-status-body p {
      margin: 0 0 8px 0;
    }

    .storegen-status-body ul,
    .storegen-status-body ol {
      margin: 0 0 8px 0;
      padding-left: 20px;
    }

    .storegen-status-body code {
      background: rgba(255, 255, 255, 0.15);
      padding: 2px 6px;
      border-radius: 3px;
      font-family: monospace;
      font-size: 11px;
      color: #e0e0e0;
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .storegen-status-body pre {
      background: rgba(255, 255, 255, 0.1);
      padding: 8px;
      border-radius: 4px;
      overflow-x: auto;
      margin: 0 0 8px 0;
    }

    .storegen-status-body pre code {
      background: none;
      padding: 0;
    }

    .storegen-status-body strong {
      font-weight: 600;
      color: white;
    }

    .storegen-status-body a {
      color: #7dd3fc;
      text-decoration: none;
    }

    .storegen-status-link {
      display: inline-block;
      padding: 4px 10px;
      color: #7dd3fc;
      text-decoration: none;
      font-size: 12px;
      cursor: pointer;
      border: 1px solid rgba(125, 211, 252, 0.3);
      border-radius: 3px;
      transition: border-color 0.2s ease;
    }

    .storegen-status-link:hover {
      border-color: rgba(125, 211, 252, 0.6);
      text-decoration: none;
    }

    .storegen-status-card.working .storegen-status-title {
      animation: pulse 2s ease infinite;
    }

    .storegen-status-cancel {
      background: transparent;
      border: 1px solid rgba(255, 255, 255, 0.3);
      color: white;
      padding: 6px 12px;
      font-size: 12px;
      border-radius: 4px;
      cursor: pointer;
      width: 100%;
    }

    .storegen-status-cancel:hover {
      background: rgba(255, 255, 255, 0.1);
      border-color: rgba(255, 255, 255, 0.5);
    }

    /* ============================================
       INSTRUCTIONS MODAL
       ============================================ */
    .storegen-modal-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: transparent;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 10000;
      pointer-events: auto;
    }

    .storegen-modal {
      position: relative !important;
      background: white !important;
      border-radius: 4px !important;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3) !important;
      border: 1px solid #e9ecef !important;
      width: 600px !important;
      max-width: 90% !important;
      display: flex !important;
      flex-direction: column !important;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif !important;
      pointer-events: auto !important;
      overflow: hidden !important;
      color: #16191F !important;
    }

    .storegen-modal::before {
      content: '' !important;
      position: absolute !important;
      left: 0 !important;
      top: 0 !important;
      right: 0 !important;
      height: 4px !important;
      z-index: 1 !important;
      background: linear-gradient(90deg,
        rgba(0,0,0,1) 0%,
        rgba(0,49,129,1) 10%,
        rgba(32,116,213,1) 25%,
        rgba(244,110,187,1) 40%,
        rgba(255,173,151,1) 50%,
        rgba(244,110,187,1) 60%,
        rgba(32,116,213,1) 75%,
        rgba(0,49,129,1) 90%,
        rgba(0,0,0,1) 100%) !important;
    }

    .storegen-modal-header {
      display: flex !important;
      align-items: center !important;
      justify-content: space-between !important;
      padding: 16px 20px !important;
      border-bottom: 1px solid #e9ecef !important;
      position: relative !important;
      background: white !important;
    }

    .storegen-modal-header h3 {
      margin: 0 !important;
      font-size: 18px !important;
      font-weight: 600 !important;
      color: #16191F !important;
    }

    .storegen-modal-close {
      background: none;
      border: none;
      font-size: 28px;
      color: #6c757d;
      cursor: pointer;
      padding: 0;
      width: 32px;
      height: 32px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: color 0.2s ease;
    }

    .storegen-modal-close:hover {
      color: #16191F;
    }

    .storegen-modal-body {
      padding: 20px !important;
      flex: 1 !important;
      display: flex !important;
      flex-direction: column !important;
      gap: 8px !important;
      background: white !important;
      -ms-overflow-style: none;
      scrollbar-width: none;
    }

    /* Hide scrollbar for modal body */
    .storegen-modal-body::-webkit-scrollbar {
      display: none;
    }

    .storegen-modal-body label {
      font-size: 14px;
      font-weight: 500;
      color: #16191F;
      text-transform: none !important;
    }

    .storegen-security-banner {
      padding: 8px 12px;
      background: #fff3cd;
      border: 1px solid #ffc107;
      border-radius: 4px;
      margin-bottom: 8px;
      font-size: 13px;
      color: #664d03;
      white-space: nowrap;
    }

    .storegen-security-banner a {
      color: #664d03;
      text-decoration: underline;
      margin-left: 4px;
    }

    .storegen-security-banner a:hover {
      color: #3d2e02;
    }

    .storegen-modal-body input[type="text"] {
      width: 100%;
      box-sizing: border-box;
      padding: 10px;
      font-size: 14px;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      border: 1px solid #ced4da;
      border-radius: 4px;
    }

    .storegen-modal-body input[type="text"]:focus {
      outline: none;
      border-color: #2074d5;
      box-shadow: 0 0 0 3px rgba(32, 116, 213, 0.1);
    }

    .storegen-modal-file-context {
      padding: 10px 12px;
      background: #f8f9fa;
      border: 1px solid #e9ecef;
      border-radius: 4px;
      margin-bottom: 8px;
    }

    .storegen-modal-file-context label {
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      font-weight: 400;
      margin: 0;
    }

    .storegen-modal-file-context input[type="checkbox"] {
      cursor: pointer;
      margin: 0;
    }

    .storegen-file-path {
      margin-top: 8px;
      padding-top: 8px;
      border-top: 1px solid #e9ecef;
      font-size: 12px;
      color: #6c757d;
    }

    .storegen-file-path code {
      background: white;
      padding: 2px 6px;
      border-radius: 3px;
      font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
      font-size: 11px;
      color: #16191F;
    }

    .storegen-modal-body textarea {
      width: 100%;
      box-sizing: border-box;
      padding: 10px;
      font-size: 14px;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      border: 1px solid #ced4da;
      border-radius: 4px;
      resize: vertical;
      min-height: 120px;
    }

    .storegen-modal-body textarea:focus {
      outline: none;
      border-color: #2074d5;
      box-shadow: 0 0 0 3px rgba(32, 116, 213, 0.1);
    }

    .storegen-modal-message {
      font-size: 13px;
      padding: 8px 12px;
      border-radius: 4px;
    }

    .storegen-modal-error {
      color: #d13212;
      background: #fef2f2;
      border: 1px solid #fecaca;
    }

    .storegen-modal-info {
      color: #37474f;
      background: #e3f2fd;
      border: 1px solid #90caf9;
    }

    .storegen-modal-info::before {
      content: 'ⓘ ';
      margin-right: 4px;
    }

    .storegen-modal-footer {
      display: flex !important;
      justify-content: space-between !important;
      align-items: center !important;
      padding: 16px 20px !important;
      background: white !important;
    }

    .storegen-modal-footer-buttons {
      display: flex;
      gap: 12px;
    }

    .storegen-modal-footer button {
      padding: 8px 16px;
      font-size: 14px;
      font-weight: 500;
      border-radius: 4px;
      cursor: pointer;
      transition: background 0.2s ease;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
    }

    .storegen-modal-cancel {
      background: white;
      color: #16191F;
      border: 1px solid #ced4da;
    }

    .storegen-modal-cancel:hover {
      background: #f8f9fa;
    }

    .storegen-modal-submit {
      background: #16191F;
      color: white;
      border: none;
    }

    .storegen-modal-submit:hover:not(:disabled) {
      background: #2a2e38;
    }

    .storegen-modal-submit:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    /* Pulse animation for Generate CR button in CodeGenGuestBook */
    .storegen-modal-submit.attention-pulse {
      animation: buttonPulse 2s ease-in-out infinite;
    }

    /* Confetti particles */
    .storegen-confetti {
      position: fixed;
      width: 10px;
      height: 10px;
      z-index: 10001;
      pointer-events: none;
      animation: confetti 3s ease-out forwards;
    }

    /* ============================================
       URL REFERENCE SECTION (for future feature)
       ============================================ */
    .storegen-url-section {
      margin-top: 16px;
      padding: 12px;
      background: #f8f9fa;
      border: 1px solid #e9ecef;
      border-radius: 4px;
    }

    .storegen-url-section label {
      display: block;
      margin-bottom: 4px;
    }

    .storegen-url-description {
      font-size: 12px;
      color: #6c757d;
      margin: 0 0 12px 0;
    }

    .storegen-url-input-row {
      display: flex;
      gap: 8px;
    }

    .storegen-url-input-row input {
      flex: 1;
      padding: 8px 10px;
      font-size: 13px;
      border: 1px solid #ced4da;
      border-radius: 4px;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
    }

    .storegen-url-input-row input:focus {
      outline: none;
      border-color: #2074d5;
      box-shadow: 0 0 0 3px rgba(32, 116, 213, 0.1);
    }

    .storegen-url-add-btn {
      padding: 8px 16px;
      background: white;
      color: #16191F;
      border: 1px solid #ced4da;
      border-radius: 4px;
      font-size: 13px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.2s ease;
    }

    .storegen-url-add-btn:hover:not(:disabled) {
      background: #f8f9fa;
    }

    .storegen-url-add-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .storegen-url-list {
      margin-top: 12px;
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .storegen-url-item {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 6px 10px;
      background: white;
      border: 1px solid #e9ecef;
      border-radius: 4px;
      font-size: 12px;
    }

    .storegen-url-text {
      flex: 1;
      color: #16191F;
      font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .storegen-url-size {
      color: #6c757d;
      font-size: 11px;
    }

    .storegen-url-remove {
      background: none;
      border: none;
      color: #6c757d;
      font-size: 16px;
      cursor: pointer;
      padding: 0 4px;
      line-height: 1;
    }

    .storegen-url-remove:hover {
      color: #d13212;
    }

    .storegen-url-toggle-link {
      color: #5f6b7a;
      text-decoration: none;
      font-size: 13px;
      cursor: pointer;
    }

    .storegen-url-toggle-link:hover {
      color: #2074d5;
      text-decoration: underline;
    }

    .storegen-url-title {
      font-weight: 600;
      font-size: 14px;
      color: #16191F;
    }

    .storegen-url-subtitle {
      font-size: 13px;
      color: #6c757d;
      margin: 4px 0 12px 0;
    }

    .storegen-url-error-text {
      color: #d13212;
    }

    /* ============================================
       QUIP TOKEN MODAL
       ============================================ */
    .storegen-quip-token-modal {
      max-width: 550px;
    }

    .storegen-quip-token-warning {
      padding: 12px 16px;
      background: #fce8e6;
      border-radius: 4px;
      margin-bottom: 12px;
      font-size: 14px;
      color: #c5221f;
      line-height: 1.4;
    }

    .storegen-quip-token-help {
      font-size: 13px;
      color: #6c757d;
      margin-top: 8px;
      line-height: 1.4;
    }

    .storegen-quip-token-link {
      display: inline-block;
      padding: 8px 16px;
      background: white;
      border: 1px solid #2074d5;
      border-radius: 4px;
      color: #2074d5;
      font-size: 14px;
      font-weight: 500;
      text-decoration: none;
    }

    .storegen-quip-token-link:hover {
      background: #f0f7ff;
    }

    .storegen-quip-token-error {
      padding: 8px 12px;
      background: #fce8e6;
      border-radius: 4px;
      margin-top: 8px;
      font-size: 13px;
      color: #c5221f;
    }

    /* ============================================
       TASKEI / CLOUDSCAPE OVERRIDES
       High-specificity selectors to beat Cloudscape
       ============================================ */
    .storegen-modal-overlay .storegen-modal .storegen-modal-body input[type="text"] {
      display: block !important;
      width: 100% !important;
      box-sizing: border-box !important;
      padding: 10px !important;
      font-size: 14px !important;
      border: 1px solid #ced4da !important;
      border-radius: 4px !important;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif !important;
      color: #16191F !important;
      background: white !important;
    }

    .storegen-modal-overlay .storegen-modal .storegen-modal-body label {
      display: block !important;
    }

    /* ============================================
       DARK MODE SUPPORT
       Uses Asana's theme classes for detection
       ============================================ */
    
    /* Apply dark mode styles when modal has dark class */
    .storegen-modal--dark {
      background: #252628 !important;
      color: #f5f4f3 !important;
      border: 1px solid #3a3a3a !important;
    }

    /* Modal header */
    .storegen-modal--dark .storegen-modal-header {
      background: #252628 !important;
      border-bottom: 1px solid #3a3a3a !important;
    }

    .storegen-modal--dark .storegen-modal-header h3 {
      color: #f5f4f3 !important;
    }

    .storegen-modal--dark .storegen-modal-close {
      color: #a2a0a2;
    }

    .storegen-modal--dark .storegen-modal-close:hover {
      color: #f5f4f3;
    }

    /* Modal body */
    .storegen-modal--dark .storegen-modal-body {
      background: #252628 !important;
    }

    .storegen-modal--dark .storegen-modal-body label {
      color: #f5f4f3 !important;
    }

    /* Text inputs */
    .storegen-modal--dark .storegen-modal-body input[type="text"],
    .storegen-modal-overlay .storegen-modal--dark .storegen-modal-body input[type="text"] {
      background: #1e1f21 !important;
      color: #f5f4f3 !important;
      border: 1px solid #4a4a4a !important;
    }

    .storegen-modal--dark .storegen-modal-body input[type="text"]:focus {
      border-color: #689af3 !important;
      box-shadow: 0 0 0 3px rgba(104, 154, 243, 0.2) !important;
    }

    /* Textarea */
    .storegen-modal--dark .storegen-modal-body textarea {
      background: #1e1f21 !important;
      color: #f5f4f3 !important;
      border: 1px solid #4a4a4a !important;
    }

    .storegen-modal--dark .storegen-modal-body textarea:focus {
      border-color: #689af3 !important;
      box-shadow: 0 0 0 3px rgba(104, 154, 243, 0.2) !important;
    }

    /* File context section */
    .storegen-modal--dark .storegen-modal-file-context {
      background: #1e1f21 !important;
      border: 1px solid #3a3a3a !important;
    }

    .storegen-modal--dark .storegen-modal-file-context label {
      color: #f5f4f3 !important;
    }

    .storegen-modal--dark .storegen-file-path {
      border-top: 1px solid #3a3a3a !important;
      color: #a2a0a2 !important;
    }

    .storegen-modal--dark .storegen-file-path code {
      background: #252628 !important;
      color: #f5f4f3 !important;
    }

    /* URL section */
    .storegen-modal--dark .storegen-url-section {
      background: #1e1f21 !important;
      border: 1px solid #3a3a3a !important;
    }

    .storegen-modal--dark .storegen-url-description {
      color: #a2a0a2 !important;
    }

    .storegen-modal--dark .storegen-url-input-row input {
      background: #252628 !important;
      color: #f5f4f3 !important;
      border: 1px solid #4a4a4a !important;
    }

    .storegen-modal--dark .storegen-url-input-row input:focus {
      border-color: #689af3 !important;
      box-shadow: 0 0 0 3px rgba(104, 154, 243, 0.2) !important;
    }

    .storegen-modal--dark .storegen-url-add-btn {
      background: #1e1f21 !important;
      color: #f5f4f3 !important;
      border: 1px solid #4a4a4a !important;
    }

    .storegen-modal--dark .storegen-url-add-btn:hover:not(:disabled) {
      background: #2a2b2d !important;
    }

    .storegen-modal--dark .storegen-url-item {
      background: #252628 !important;
      border: 1px solid #3a3a3a !important;
    }

    .storegen-modal--dark .storegen-url-text {
      color: #f5f4f3 !important;
    }

    .storegen-modal--dark .storegen-url-size {
      color: #a2a0a2 !important;
    }

    .storegen-modal--dark .storegen-url-remove {
      color: #a2a0a2 !important;
    }

    .storegen-modal--dark .storegen-url-remove:hover {
      color: #f87171 !important;
    }

    .storegen-modal--dark .storegen-url-toggle-link {
      color: #a2a0a2 !important;
    }

    .storegen-modal--dark .storegen-url-toggle-link:hover {
      color: #689af3 !important;
    }

    .storegen-modal--dark .storegen-url-title {
      color: #f5f4f3 !important;
    }

    .storegen-modal--dark .storegen-url-subtitle {
      color: #a2a0a2 !important;
    }

    /* Modal footer */
    .storegen-modal--dark .storegen-modal-footer {
      background: #252628 !important;
    }

    .storegen-modal--dark .storegen-modal-cancel {
      background: #1e1f21 !important;
      color: #f5f4f3 !important;
      border: 1px solid #4a4a4a !important;
    }

    .storegen-modal--dark .storegen-modal-cancel:hover {
      background: #2a2b2d !important;
    }

    /* Security banner */
    .storegen-modal--dark .storegen-security-banner {
      background: #3a2f1f !important;
      border: 1px solid #5a4a2f !important;
      color: #ffd699 !important;
    }

    .storegen-modal--dark .storegen-security-banner a {
      color: #ffd699 !important;
    }

    .storegen-modal--dark .storegen-security-banner a:hover {
      color: #ffe5b3 !important;
    }

    /* Error messages */
    .storegen-modal--dark .storegen-modal-error {
      color: #f87171 !important;
      background: #2d1f1f !important;
      border: 1px solid #4a2a2a !important;
    }

    /* Info messages */
    .storegen-modal--dark .storegen-modal-info {
      color: #7dd3fc !important;
      background: #1f2a3a !important;
      border: 1px solid #2a3a5a !important;
    }

    /* Quip token modal */
    .storegen-modal--dark .storegen-quip-token-warning {
      background: #2d1f1f !important;
      color: #f87171 !important;
    }

    .storegen-modal--dark .storegen-quip-token-help {
      color: #a2a0a2 !important;
    }

    .storegen-modal--dark .storegen-quip-token-link {
      background: #1e1f21 !important;
      border: 1px solid #689af3 !important;
      color: #689af3 !important;
    }

    .storegen-modal--dark .storegen-quip-token-link:hover {
      background: #2a2b2d !important;
    }

    .storegen-modal--dark .storegen-quip-token-error {
      background: #2d1f1f !important;
      color: #f87171 !important;
    }

    /* ============================================
       VOICE INPUT
       ============================================ */
    .storegen-voice-row {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-top: 4px;
    }

    .storegen-voice-btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 5px 12px;
      background: #f8f9fa;
      border: 1px solid #ced4da;
      border-radius: 20px;
      cursor: pointer;
      font-size: 12px;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      color: #6c757d;
      transition: all 0.2s ease;
    }

    .storegen-voice-btn:hover {
      background: #e9ecef;
      border-color: #adb5bd;
      color: #495057;
    }

    .storegen-voice-btn.listening {
      background: #16191F;
      border-color: #16191F;
      color: white;
      animation: voicePulse 1.5s ease-in-out infinite;
    }

    .storegen-voice-btn-label {
      line-height: 1;
    }

    @keyframes voicePulse {
      0%, 100% { box-shadow: 0 0 0 0 rgba(22, 25, 31, 0.4); }
      50% { box-shadow: 0 0 0 6px rgba(22, 25, 31, 0); }
    }

    .storegen-voice-status {
      font-size: 11px;
      color: #6c757d;
      background: white;
      border: 1px solid #e9ecef;
      border-radius: 4px;
      padding: 4px 8px;
      white-space: nowrap;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
      display: none;
    }

    .storegen-modal--dark .storegen-voice-btn {
      background: #2a2b2d;
      border-color: #4a4a4a;
      color: #a2a0a2;
    }

    .storegen-modal--dark .storegen-voice-btn:hover {
      background: #3a3b3d;
      border-color: #666;
      color: #ccc;
    }

    .storegen-modal--dark .storegen-voice-btn.listening {
      background: #16191F;
      border-color: #16191F;
      color: white;
    }

    .storegen-modal--dark .storegen-voice-status {
      color: #a2a0a2;
      background: #1e1f21;
      border-color: #4a4a4a;
    }

    /* ============================================
       SPEC STUDIO CHAT
       ============================================ */
    .storegen-spec-chat-panel {
      position: fixed;
      bottom: 24px;
      right: 24px;
      width: 500px;
      height: 670px;
      max-height: calc(100vh - 48px);
      z-index: 9999;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
      background: #fff;
      display: none;
      flex-direction: column;
    }

    .storegen-spec-chat-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 12px 10px 16px;
      background: #007e94;
      color: #fff;
      font-size: 14px;
      font-weight: 600;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      flex-shrink: 0;
    }

    .storegen-spec-chat-close {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 28px;
      height: 28px;
      border-radius: 50%;
      border: none;
      background: rgba(255, 255, 255, 0.2);
      color: #fff;
      font-size: 18px;
      line-height: 1;
      cursor: pointer;
      transition: background 0.2s ease;
    }

    .storegen-spec-chat-close:hover {
      background: rgba(255, 255, 255, 0.35);
    }

    .storegen-spec-chat-bar {
      position: fixed;
      bottom: 24px;
      right: 40px;
      z-index: 9999;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }

    .storegen-spec-chat-btn {
      padding: 6px 24px;
      border-radius: 0.5rem;
      border: none;
      background: #007e94;
      color: #fff;
      font-size: 14px;
      font-weight: 600;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      transition: background 0.2s ease;
    }

    .storegen-spec-chat-btn:hover {
      background: #009ab3;
    }

    .storegen-spec-chat-dismiss {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 28px;
      height: 28px;
      border-radius: 50%;
      border: none;
      background: rgba(0, 0, 0, 0.15);
      color: #666;
      font-size: 18px;
      line-height: 1;
      cursor: pointer;
      transition: background 0.2s ease, color 0.2s ease;
    }

    .storegen-spec-chat-dismiss:hover {
      background: rgba(0, 0, 0, 0.25);
      color: #333;
    }

    .storegen-spec-chat-iframe {
      width: 100%;
      flex: 1;
      border: none;
    }

    .storegen-spec-chat-disclaimer {
      padding: 6px 12px;
      background: #f8f9fa;
      border-top: 1px solid #e9ecef;
      font-size: 11px;
      color: #6c757d;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      flex-shrink: 0;
      text-align: center;
    }

    /* ============================================
       ACTION BUTTON CONTAINER
       ============================================ */
    .storegen-action-button-container {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 9999;
      display: flex;
      align-items: stretch;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.6);
      transform: translateY(100px);
      opacity: 0;
      transition: transform 0.3s ease, opacity 0.3s ease;
    }
    .storegen-action-button-container.visible {
      transform: translateY(0);
      opacity: 1;
    }
    .storegen-action-button-container.hidden {
      transform: translateY(100px);
      opacity: 0;
    }

    /* ============================================
       CONTEXT PANEL
       ============================================ */
    #storegen-context-panel {
      position: fixed;
      bottom: 60px;
      right: 20px;
      width: 420px;
      max-height: 70vh;
      z-index: 10000;
      background: #fff;
      border-radius: 8px;
      box-shadow: 0 8px 30px rgba(0,0,0,0.25);
      display: flex;
      flex-direction: column;
      font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
      font-size: 13px;
    }
    .storegen-context-panel-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 10px 14px;
      background: #16191f;
      color: #fff;
      font-weight: 600;
      border-radius: 8px 8px 0 0;
    }
    .storegen-context-panel-close {
      background: none; border: none; color: #fff; font-size: 16px; cursor: pointer;
    }
    .storegen-context-panel-list {
      overflow-y: auto;
      padding: 10px;
      flex: 1;
    }
    .storegen-context-card {
      border: 1px solid #e0e0e0;
      border-radius: 6px;
      padding: 10px;
      margin-bottom: 8px;
    }
    .storegen-context-card-comment {
      font-size: 12px;
      color: #333;
      margin-bottom: 6px;
      line-height: 1.4;
    }
    .storegen-context-card-actions {
      display: flex;
      gap: 10px;
      font-size: 12px;
      margin-bottom: 4px;
    }
    .storegen-context-card-actions label { cursor: pointer; }
    .storegen-context-card-input {
      width: 100%;
      min-height: 50px;
      margin-top: 6px;
      padding: 6px 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
      font-size: 12px;
      font-family: inherit;
      resize: vertical;
    }
    .storegen-context-panel-footer {
      padding: 10px 14px;
      border-top: 1px solid #e0e0e0;
    }
    .storegen-context-panel-send {
      width: 100%;
      padding: 8px;
      background: #007e94;
      color: #fff;
      border: none;
      border-radius: 4px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
    }
    .storegen-context-panel-send:hover { background: #009ab3; }
    .storegen-context-panel-send:disabled { opacity: 0.6; cursor: not-allowed; }
  `;
  document.head.appendChild(style);
}

;// ./src/ui/components/logo.js
// StoreGen logo component


/**
 * Creates a StoreGen logo SVG element
 * @param {string} className - CSS class to apply to the logo
 * @returns {SVGElement} The logo SVG element
 */
function logo_createStoreGenLogo(className = "storegen-logo") {
  const logo = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  logo.setAttribute("class", className);
  logo.setAttribute("viewBox", "0 0 1110.78 622.57");
  logo.innerHTML = STOREGEN_LOGO_SVG;
  return logo;
}

;// ./src/ui/components/actionButton.js
// Action button component for CodeGen job submission






/**
 * Creates and manages the floating action button for CodeGen job submission
 * @param {string} crId - Code review ID
 * @param {string} codeReviewKey - Unique key for this CR+revision
 * @param {Function} onJobSubmitted - Callback when job is successfully submitted (jobId, jobUrl)
 * @param {Function} updatePillsPosition - Callback to update job pills position
 * @returns {Object} Button controller with button element and update function
 */
function createActionButton(
  crId,
  codeReviewKey,
  onJobSubmitted,
  updatePillsPosition,
  onDiscussClick,
) {
  let isSubmittingJob = false;
  let lastButtonStateSignature = null;

  // Create main button
  const mainButton = document.createElement("button");
  mainButton.className = "storegen-action-button";
  mainButton.title = "Send selected comments to CodeGen";

  // Add StoreGen logo
  const logo = logo_createStoreGenLogo();

  const buttonText = document.createElement("span");
  buttonText.textContent = "Send comments to CodeGen";

  mainButton.appendChild(logo);
  mainButton.appendChild(buttonText);

  // Discuss button (sibling next to send)
  const discussBtn = document.createElement("button");
  discussBtn.className = "storegen-discuss-inline-btn";
  discussBtn.title = "Add context before sending to CodeGen";
  discussBtn.textContent = "💬";
  discussBtn.style.cssText = "padding:0 10px;background:#007e94;color:#fff;border:none;border-left:1px solid rgba(255,255,255,0.2);font-size:14px;cursor:pointer;";
  discussBtn.onclick = (e) => { e.stopPropagation(); if (onDiscussClick) onDiscussClick(); };

  // Container wrapping both buttons as siblings
  const buttonContainer = document.createElement("div");
  buttonContainer.className = "storegen-action-button-container";
  buttonContainer.appendChild(mainButton);
  buttonContainer.appendChild(discussBtn);

  /**
   * Updates the main action button visibility and text based on selected comments
   * Shows button when comments are selected, hides when none selected
   * Updates button text with count of selected comments
   */
  function updateMainButtonState() {
    const checkedBoxes = document.querySelectorAll(
      SELECTORS.CHECKED_CHECKBOXES,
    );
    const count = checkedBoxes.length;
    const newState = `${isSubmittingJob}-${count}`;

    // Only log if state changed
    if (lastButtonStateSignature !== newState) {
      logger_log(
        "updateMainButtonState - isSubmittingJob:",
        isSubmittingJob,
        "count:",
        count,
      );
      lastButtonStateSignature = newState;
    }

    // Only update text and transform if not loading
    if (!isSubmittingJob) {
      const buttonText = mainButton.querySelector("span");
      if (count > 0) {
        buttonContainer.classList.add("visible");
        buttonContainer.classList.remove("hidden");
        buttonText.textContent = `Send ${count} comment${count > 1 ? "s" : ""} to CodeGen`;
      } else {
        buttonContainer.classList.remove("visible");
        buttonContainer.classList.add("hidden");
      }

      // Reset button state
      mainButton.disabled = false;
      mainButton.classList.remove("loading");
    }

    // Update pills position based on button visibility
    updatePillsPosition();
  }

  /**
   * Hides the action button (used when job is submitted)
   */
  function hideButton() {
    buttonContainer.classList.remove("visible");
    buttonContainer.classList.add("hidden");
  }

  // Button click handler
  mainButton.onclick = function () {
    logger_log("Main button clicked");
    const checkedBoxes = document.querySelectorAll(
      SELECTORS.CHECKED_CHECKBOXES,
    );
    logger_log("Checked boxes on click:", checkedBoxes.length);
    if (checkedBoxes.length === 0) return;

    // Set loading state
    logger_log("Setting loading state");
    isSubmittingJob = true;
    mainButton.disabled = true;
    mainButton.classList.add("loading");
    const buttonText = mainButton.querySelector("span");
    buttonText.textContent = "Sending to CodeGen...";

    // Disable all checkboxes
    document
      .querySelectorAll('.storegen-checkbox-banner input[type="checkbox"]')
      .forEach((cb) => {
        cb.disabled = true;
      });

    const commentIds = Array.from(checkedBoxes)
      .map((checkbox) => {
        const commentBox = checkbox.closest(".comment-box");
        const commentId = commentBox.getAttribute("comment-id");
        if (!commentId) return null;
        const match = commentId.match(/\.(\d+)\.(-?\d+)$/);
        if (!match) return null;
        return { revision: parseInt(commentId.match(/#\w+\.\w+\.(\d+)\./)?.[1], 10), post: parseInt(match[1], 10) };
      })
      .filter(Boolean);

    logger_log("Comment IDs:", commentIds);

    submitJob(
      crId,
      commentIds,
      (jobId, jobUrl) => {
        // onSuccess
        logger_log("Request successful, clearing state");
        isSubmittingJob = false;
        clearStoredState(codeReviewKey);
        checkedBoxes.forEach((cb) => (cb.checked = false));

        // Store job and create status card
        setStoredJob(codeReviewKey, jobId);
        onJobSubmitted(jobId, jobUrl);
      },
      (errorMessage) => {
        // onError
        logger_log("Request failed:", errorMessage);
        isSubmittingJob = false;
        updateMainButtonState();
        alert(`CodeGen request failed: ${errorMessage}`);
      },
      "browserextension-comments"
    );
  };

  return {
    element: buttonContainer,
    updateState: updateMainButtonState,
    hide: hideButton,
  };
}

;// ./src/ui/components/statusCard.js
// Status card component for displaying CodeGen job status






/**
 * Makes an element draggable by a handle.
 * Converts bottom/right positioning to top/left on first drag.
 * Clamps position to viewport bounds.
 * Uses a 5px threshold to distinguish drag from click.
 * @param {HTMLElement} element - The element to make draggable
 * @param {HTMLElement} handle - The drag handle element
 */
function makeDraggable(element, handle) {
  let startX, startY, startLeft, startTop, isDragging = false;
  let activeCleanup = null;

  const onMouseDown = (e) => {
    // Don't drag if clicking on buttons, links, or inputs
    if (e.target.closest('button, a, input')) return;

    e.preventDefault(); // Prevent text selection during drag

    const rect = element.getBoundingClientRect();
    startX = e.clientX;
    startY = e.clientY;
    startLeft = rect.left;
    startTop = rect.top;
    isDragging = false;

    const onMouseMove = (e) => {
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;

      if (!isDragging && Math.abs(dx) < 5 && Math.abs(dy) < 5) return;

      if (!isDragging) {
        isDragging = true;
        element.classList.add('storegen-dragging');
        // Convert to top/left positioning only when actual drag starts
        element.style.top = startTop + 'px';
        element.style.left = startLeft + 'px';
        element.style.bottom = 'auto';
        element.style.right = 'auto';
      }

      const elRect = element.getBoundingClientRect();
      let newLeft = startLeft + dx;
      let newTop = startTop + dy;

      // Clamp to viewport
      newLeft = Math.max(0, Math.min(newLeft, window.innerWidth - elRect.width));
      newTop = Math.max(0, Math.min(newTop, window.innerHeight - elRect.height));

      element.style.left = newLeft + 'px';
      element.style.top = newTop + 'px';
    };

    const onMouseUp = () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
      element.classList.remove('storegen-dragging');
      activeCleanup = null;
    };

    activeCleanup = () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  };

  handle.addEventListener('mousedown', onMouseDown);

  // When expanded, reposition so content doesn't overflow below viewport
  const observer = new MutationObserver(() => {
    // Only adjust if using top/left positioning (i.e. has been dragged)
    if (element.style.top === '' || element.style.bottom !== 'auto') return;
    // Wait for CSS max-height transition to finish (0.3s in styles)
    setTimeout(() => {
      const rect = element.getBoundingClientRect();
      if (rect.bottom > window.innerHeight) {
        const newTop = Math.max(0, window.innerHeight - rect.height);
        element.style.top = newTop + 'px';
      }
    }, 350);
  });
  observer.observe(element, { subtree: true, attributeFilter: ['class'] });

  // Return cleanup function to remove all listeners
  return () => {
    handle.removeEventListener('mousedown', onMouseDown);
    if (activeCleanup) activeCleanup();
    observer.disconnect();
  };
}

/**
 * Gets or creates the jobs container element
 * All job rows live inside this single container
 */
function getOrCreateJobsContainer() {
  let container = document.querySelector('.storegen-jobs-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'storegen-jobs-container';
    document.body.appendChild(container);
  }
  return container;
}

/**
 * Collapses all expanded job rows except the specified one
 * @param {HTMLElement} exceptRow - Row to keep expanded (optional)
 */
function collapseOtherRows(exceptRow = null) {
  const rows = document.querySelectorAll('.storegen-job-row.expanded');
  rows.forEach(row => {
    if (row !== exceptRow) {
      row.classList.remove('expanded');
    }
  });
}

/**
 * Creates and displays a status card for a CodeGen job
 * Starts polling for job status and updates the card accordingly
 * @param {string} jobId - The CodeGen job ID to track
 * @param {string} jobUrl - The Harmony job dashboard URL from API response
 * @param {string} codeReviewKey - Unique key for this CR+revision
 * @param {Function} renderMarkdown - Function to render markdown to HTML
 * @param {Function} onClose - Callback when status card is closed
 * @param {string} workingTitle - Title to show while job is in progress (default: "Working...")
 * @returns {HTMLElement} The job row element
 */
function createJobBanner(
  jobId,
  jobUrl,
  codeReviewKey,
  renderMarkdown,
  onClose,
  workingTitle = "Working...",
) {
  logger_log("Creating job row for job:", jobId);

  const container = getOrCreateJobsContainer();

  const existingRow = container.querySelector(`[data-job-id="${jobId}"]`);
  if (existingRow) {
    logger_log("Job row already exists for:", jobId);
    return existingRow;
  }

  const jobRow = document.createElement("div");
  jobRow.className = "storegen-job-row working";
  jobRow.dataset.jobId = jobId;

  // Create row header (always visible)
  const rowHeader = document.createElement("div");
  rowHeader.className = "storegen-job-row-header";

  const logo = logo_createStoreGenLogo();
  logo.classList.add('storegen-job-row-logo');

  const statusIcon = document.createElement("span");
  statusIcon.className = "storegen-job-row-status-icon working";

  const titleText = document.createElement("span");
  titleText.className = "storegen-job-row-title";
  titleText.textContent = workingTitle;

  const jobIdText = document.createElement("span");
  jobIdText.className = "storegen-job-row-id";
  jobIdText.textContent = jobId;

  const expandIcon = document.createElement("span");
  expandIcon.className = "storegen-job-row-expand";
  expandIcon.textContent = "▼";

  let cleanupDrag;
  const closeBtn = document.createElement("button");
  closeBtn.className = "storegen-job-row-close";
  closeBtn.textContent = "\u00d7";
  closeBtn.onclick = (e) => {
    e.stopPropagation();
    logger_log("User dismissed job row for job:", jobId);
    if (cleanupDrag) cleanupDrag();
    jobRow.classList.add("removing");
    setTimeout(() => {
      jobRow.remove();
      if (container.children.length === 0) {
        container.remove();
      }
    }, config_STATUS_CARD_REMOVE_DELAY_MS);
    clearStoredJob(codeReviewKey);

    document
      .querySelectorAll('.storegen-checkbox-banner input[type="checkbox"]')
      .forEach((cb) => {
        cb.disabled = false;
      });

    if (onClose) onClose();
  };

  const logsBtn = document.createElement("a");
  logsBtn.className = "storegen-job-row-header-logs";
  logsBtn.textContent = "View job";
  logsBtn.onclick = (e) => {
    e.stopPropagation();
    GM_openInTab(jobUrl, { active: true });
  };

  const cancelBtn = document.createElement("button");
  cancelBtn.className = "storegen-job-row-header-cancel";
  cancelBtn.textContent = "Cancel";

  rowHeader.appendChild(logo);
  rowHeader.appendChild(statusIcon);
  rowHeader.appendChild(titleText);
  rowHeader.appendChild(jobIdText);
  rowHeader.appendChild(expandIcon);
  rowHeader.appendChild(logsBtn);
  rowHeader.appendChild(cancelBtn);
  rowHeader.appendChild(closeBtn);

  // Create expandable content area
  const rowContent = document.createElement("div");
  rowContent.className = "storegen-job-row-content";

  const body = document.createElement("div");
  body.className = "storegen-job-row-body";
  body.textContent = `Job ID: ${jobId}`;

  const logsLink = document.createElement("a");
  logsLink.className = "storegen-job-row-link";
  logsLink.textContent = "View job";
  logsLink.onclick = (e) => {
    e.stopPropagation();
    GM_openInTab(jobUrl, { active: true });
  };

  rowContent.appendChild(body);
  rowContent.appendChild(logsLink);

  jobRow.appendChild(rowHeader);
  jobRow.appendChild(rowContent);

  // Click header to expand/collapse (only when completed/failed)
  rowHeader.onclick = () => {
    if (!jobRow.classList.contains('working')) {
      const isExpanded = jobRow.classList.contains('expanded');
      if (isExpanded) {
        jobRow.classList.remove('expanded');
      } else {
        collapseOtherRows(jobRow);
        jobRow.classList.add('expanded');
      }
    }
  };

  container.appendChild(jobRow);
  cleanupDrag = makeDraggable(container, rowHeader);

  logger_log("Starting job polling for:", jobId);
  const pollController = pollJobStatus(
    jobId,
    (status, data) => {
      if (status === "IN_PROGRESS") {
        titleText.textContent = workingTitle;
      }
    },
    (finalOutput, data) => {
      jobRow.classList.remove("working");
      jobRow.classList.add("completed");
      statusIcon.className = "storegen-job-row-status-icon completed";
      titleText.textContent = "Completed";
      body.innerHTML = renderMarkdown(finalOutput) || "Job completed successfully";
      closeBtn.classList.add("visible");
      cancelBtn.style.display = "none";
      logsBtn.style.display = "none";

      const stored = localStorage.getItem(codeReviewKey);
      if (stored) {
        try {
          const jobData = JSON.parse(stored);
          jobData.status = 'COMPLETED';
          localStorage.setItem(codeReviewKey, JSON.stringify(jobData));
          logger_log("Updated job status to COMPLETED in localStorage");
        } catch (e) {
          logger_log("Error updating job status:", e);
        }
      }

      saveJobToHistory(codeReviewKey, {
        jobId: jobId,
        status: "COMPLETED",
        finalOutput: finalOutput,
        timestamp: Date.now(),
        commentIds: Object.keys(getStoredState(codeReviewKey)),
        jobUrl: jobUrl,
        viewLogsUrl: jobUrl,
      });
    },
    (finalOutput, data) => {
      jobRow.classList.remove("working");
      jobRow.classList.add("failed");
      statusIcon.className = "storegen-job-row-status-icon failed";
      titleText.textContent = "Failed";
      body.innerHTML = renderMarkdown(finalOutput) || "Job failed. Check logs for details.";
      closeBtn.classList.add("visible");
      cancelBtn.style.display = "none";
      logsBtn.style.display = "none";

      const stored = localStorage.getItem(codeReviewKey);
      if (stored) {
        try {
          const jobData = JSON.parse(stored);
          jobData.status = 'FAILED';
          localStorage.setItem(codeReviewKey, JSON.stringify(jobData));
          logger_log("Updated job status to FAILED in localStorage");
        } catch (e) {
          logger_log("Error updating job status:", e);
        }
      }

      saveJobToHistory(codeReviewKey, {
        jobId: jobId,
        status: "FAILED",
        finalOutput: finalOutput,
        timestamp: Date.now(),
        commentIds: Object.keys(getStoredState(codeReviewKey)),
        jobUrl: jobUrl,
        viewLogsUrl: jobUrl,
      });
    },
    () => {
      jobRow.classList.remove("working");
      jobRow.classList.add("failed");
      statusIcon.className = "storegen-job-row-status-icon failed";
      titleText.textContent = "Timed out";
      body.textContent = "The job exceeded the maximum wait time.";
      closeBtn.classList.add("visible");
      cancelBtn.style.display = "none";
      logsBtn.style.display = "none";
    },
    (error) => {
      jobRow.classList.remove("working");
      jobRow.classList.add("failed");
      statusIcon.className = "storegen-job-row-status-icon failed";
      titleText.textContent = "Error";
      body.textContent = "Failed to check job status";
      closeBtn.classList.add("visible");
      cancelBtn.style.display = "none";
      logsBtn.style.display = "none";
    },
  );

  cancelBtn.onclick = (e) => {
    e.stopPropagation();
    logger_log("User cancelled job:", jobId);
    pollController.cancel();
    jobRow.classList.remove("working");
    jobRow.classList.add("cancelled");
    statusIcon.className = "storegen-job-row-status-icon cancelled";
    titleText.textContent = "Cancelled";
    body.textContent = "Job monitoring stopped. The job may still be running on the server.";
    closeBtn.classList.add("visible");
    cancelBtn.style.display = "none";
    logsBtn.style.display = "none";
    clearStoredJob(codeReviewKey);
    localStorage.removeItem(codeReviewKey);

    document
      .querySelectorAll('.storegen-checkbox-banner input[type="checkbox"]')
      .forEach((cb) => {
        cb.disabled = false;
      });

    if (onClose) onClose();
  };

  return jobRow;
}

/**
 * Reopens a status card for a completed job from history
 * @param {Object} job - Job data from history
 * @param {Function} renderMarkdown - Function to render markdown to HTML
 * @returns {HTMLElement} The status card element
 */
function reopenJobStatusCard(job, renderMarkdown) {
  logger_log("Reopening job from history:", job.jobId);

  const container = getOrCreateJobsContainer();

  // Check if this job is already displayed
  const existingRow = container.querySelector(`[data-job-id="${job.jobId}"]`);
  if (existingRow) {
    collapseOtherRows(existingRow);
    existingRow.classList.add('expanded');
    return existingRow;
  }

  // Create job row
  const jobRow = document.createElement("div");
  jobRow.className = `storegen-job-row ${job.status === "COMPLETED" ? "completed" : "failed"}`;
  jobRow.dataset.jobId = job.jobId;

  // Create row header
  const rowHeader = document.createElement("div");
  rowHeader.className = "storegen-job-row-header";

  const logo = logo_createStoreGenLogo();
  logo.classList.add('storegen-job-row-logo');

  const statusIcon = document.createElement("span");
  statusIcon.className = `storegen-job-row-status-icon ${job.status === "COMPLETED" ? "completed" : "failed"}`;

  const titleText = document.createElement("span");
  titleText.className = "storegen-job-row-title";
  titleText.textContent = job.status === "COMPLETED" ? "Completed" : "Failed";

  const jobIdText = document.createElement("span");
  jobIdText.className = "storegen-job-row-id";
  jobIdText.textContent = job.jobId;

  const expandIcon = document.createElement("span");
  expandIcon.className = "storegen-job-row-expand";
  expandIcon.textContent = "▼";

  let cleanupDrag;
  const closeBtn = document.createElement("button");
  closeBtn.className = "storegen-job-row-close visible";
  closeBtn.textContent = "\u00d7";
  closeBtn.onclick = (e) => {
    e.stopPropagation();
    logger_log("User closed reopened job row for job:", job.jobId);
    if (cleanupDrag) cleanupDrag();
    jobRow.classList.add("removing");
    setTimeout(() => {
      jobRow.remove();
      if (container.children.length === 0) {
        container.remove();
      }
    }, config_STATUS_CARD_REMOVE_DELAY_MS);
  };

  rowHeader.appendChild(logo);
  rowHeader.appendChild(statusIcon);
  rowHeader.appendChild(titleText);
  rowHeader.appendChild(jobIdText);
  rowHeader.appendChild(expandIcon);
  rowHeader.appendChild(closeBtn);

  // Create expandable content area
  const rowContent = document.createElement("div");
  rowContent.className = "storegen-job-row-content";

  const body = document.createElement("div");
  body.className = "storegen-job-row-body";
  body.innerHTML = renderMarkdown(job.finalOutput) ||
    (job.status === "COMPLETED" ? "Job completed successfully" : "Job failed");

  const logsLink = document.createElement("a");
  logsLink.className = "storegen-job-row-link";
  logsLink.textContent = "View job";
  logsLink.onclick = (e) => {
    e.stopPropagation();
    GM_openInTab(job.jobUrl || job.viewLogsUrl, { active: true });
  };

  rowContent.appendChild(body);
  rowContent.appendChild(logsLink);

  jobRow.appendChild(rowHeader);
  jobRow.appendChild(rowContent);

  // Click header to expand/collapse
  rowHeader.onclick = () => {
    const isExpanded = jobRow.classList.contains('expanded');
    if (isExpanded) {
      jobRow.classList.remove('expanded');
    } else {
      collapseOtherRows(jobRow);
      jobRow.classList.add('expanded');
    }
  };

  container.appendChild(jobRow);
  cleanupDrag = makeDraggable(container, rowHeader);

  // Auto-expand this reopened job
  collapseOtherRows(jobRow);
  jobRow.classList.add('expanded');

  return jobRow;
}

;// ./src/ui/components/jobPills.js
// Job history pills component



/**
 * Formats a timestamp into a time string
 * @param {number} timestamp - Unix timestamp in milliseconds
 * @returns {string} Formatted time string (e.g., "2:34 PM")
 */
function formatRelativeTime(timestamp) {
  const date = new Date(timestamp);
  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });
}

/**
 * Renders job history pills for the current CR+revision
 * Creates a container with stacked pills that slide up when button is visible
 * @param {string} codeReviewKey - Unique key for this CR+revision
 * @param {Function} onPillClick - Callback when pill is clicked (job)
 */
function renderJobPills(codeReviewKey, onPillClick) {
  // Remove existing container if present
  const existingContainer = document.querySelector(
    ".storegen-job-pills-container",
  );
  if (existingContainer) {
    existingContainer.remove();
  }

  const history = getJobHistory(codeReviewKey);
  if (history.length === 0) return;

  // Create container
  const container = document.createElement("div");
  container.className = "storegen-job-pills-container";

  // Add pills for each job (newest first, displayed at bottom)
  history.forEach((job) => {
    const pill = document.createElement("div");
    pill.className = "storegen-job-pill";

    const icon = document.createElement("span");
    icon.className = `storegen-job-pill-icon ${job.status === "COMPLETED" ? "success" : "failed"}`;
    icon.textContent = job.status === "COMPLETED" ? "✓" : "✗";

    const text = document.createElement("span");
    text.className = "storegen-job-pill-text";
    text.textContent = `${formatRelativeTime(job.timestamp)} • ${job.jobId}`;

    pill.appendChild(icon);
    pill.appendChild(text);

    // Make pill clickable to reopen status card
    pill.onclick = () => {
      logger_log("Reopening job from history:", job.jobId);
      if (onPillClick) onPillClick(job);
    };

    container.appendChild(pill);
  });

  document.body.appendChild(container);

  return container;
}

/**
 * Updates pills container position based on button visibility
 * @param {HTMLElement} mainButton - The main action button element
 */
function updatePillsPosition(mainButton) {
  const container = document.querySelector(".storegen-job-pills-container");
  if (!container) return;

  if (mainButton.classList.contains("visible")) {
    container.classList.add("button-visible");
  } else {
    container.classList.remove("button-visible");
  }
}

;// ./src/features/crux/crux-comments/standardUI.js
// Standard UI Components for CRUX Code Reviews



/**
 * Creates a standard CodeGen checkbox banner for a comment.
 * 
 * @param {string} commentId - The unique identifier of the comment
 * @param {Object} options - Configuration options
 * @param {boolean} options.disabled - Whether the checkbox should be disabled
 * @param {boolean} options.checked - Initial checked state
 * @param {Function} options.onChange - Callback when checkbox state changes (commentId, checked)
 * @returns {HTMLElement} The checkbox banner element
 */
function createStandardCheckbox(commentId, options = {}) {
  const { disabled = false, checked = false, onChange = null } = options;

  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.checked = checked;
  checkbox.disabled = disabled;
  checkbox.dataset.commentId = commentId;
  checkbox.dataset.checkboxType = 'standard';

  const label = document.createElement('label');
  label.className = 'storegen-checkbox-banner';

  label.appendChild(checkbox);

  const labelText = document.createElement('span');
  labelText.textContent = 'Address comment with CodeGen';
  label.appendChild(labelText);

  // Set up change handler
  if (onChange) {
    checkbox.addEventListener('change', () => {
      logger_log('Standard checkbox changed for comment:', commentId, 'checked:', checkbox.checked);
      onChange(commentId, checkbox.checked);
    });
  }

  return label;
}

;// ./src/features/crux/crux-comments/standardCheckboxes.js
// Standard Comment Checkbox Management for CRUX Code Reviews





/**
 * Sets up standard CodeGen checkbox functionality
 * @param {string} codeReviewKey - The CR-revision key for storage
 * @param {boolean} hasActiveJob - Whether there's an active job running
 * @param {Function} updateMainButtonState - Callback to update standard button state
 */
function setupStandardCheckboxes(
  codeReviewKey,
  hasActiveJob,
  updateMainButtonState
) {

  function processCommentBox(commentBox) {
    const commentId = commentBox.getAttribute("comment-id");
    if (!commentId) return;
    
    const body = commentBox.querySelector(SELECTORS.COMMENT_BODY);
    if (!body) return;

    const flexContainer = body.parentElement;
    const parentContainer = flexContainer?.parentElement;
    if (!flexContainer || !parentContainer || 
        parentContainer.querySelector(SELECTORS.CHECKBOX_BANNER)) {
      return;
    }

    const checkboxContainer = document.createElement('div');
    checkboxContainer.className = 'storegen-checkbox-container';
    checkboxContainer.dataset.commentId = commentId;
    checkboxContainer.dataset.standardOnly = 'true';

    const savedState = getStoredState(codeReviewKey);
    const standardCheckbox = createStandardCheckbox(commentId, {
      disabled: hasActiveJob,
      checked: savedState[commentId] || false,
      onChange: (id, checked) => {
        setCommentSelected(codeReviewKey, id, checked);
        updateMainButtonState();
      }
    });
    checkboxContainer.appendChild(standardCheckbox);

    flexContainer.parentElement.insertBefore(checkboxContainer, flexContainer);
  }

  function processAllComments() {
    document.querySelectorAll(SELECTORS.PUBLISHED_COMMENTS).forEach(processCommentBox);
    updateMainButtonState();
  }

  processAllComments();

  const observer = new MutationObserver((mutations) => {
    let hasNewComments = false;
    
    for (const mutation of mutations) {
      if (mutation.type === 'childList') {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            if (node.matches?.(SELECTORS.PUBLISHED_COMMENTS)) {
              processCommentBox(node);
              hasNewComments = true;
            } else if (node.querySelectorAll) {
              const comments = node.querySelectorAll(SELECTORS.PUBLISHED_COMMENTS);
              comments.forEach(processCommentBox);
              if (comments.length > 0) hasNewComments = true;
            }
          }
        }
      }
    }
    
    if (hasNewComments) updateMainButtonState();
  });

  observer.observe(document.body, { childList: true, subtree: true });
  logger_log('Standard checkbox observer started');
}

/**
 * Hides self-promotional comments about installing the extension
 */
function hidePromotionalComments() {
  const observer = new MutationObserver(() => {
    document.querySelectorAll(SELECTORS.PUBLISHED_COMMENTS).forEach((box) => {
      const body = box.querySelector(SELECTORS.COMMENT_BODY);
      if (body?.textContent.includes("💡 Tip: Install CodeGen")) {
        box.style.display = "none";
      }
    });
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

;// ./src/features/crux/crux-comments/contextPanel.js
// Context Panel - lets owner add guidance per comment before sending to CodeGen




/**
 * Opens the context panel showing selected comments with agree/context/skip options.
 * @param {string} crId
 * @param {Function} onJobSubmitted - (jobId, jobUrl) callback
 */
function openContextPanel(crId, onJobSubmitted) {
  // Remove existing panel if any
  document.getElementById('storegen-context-panel')?.remove();

  // Gather selected comments from DOM
  const checkedBoxes = document.querySelectorAll(SELECTORS.CHECKED_CHECKBOXES);
  if (checkedBoxes.length === 0) return;

  const comments = Array.from(checkedBoxes).map((cb) => {
    const box = cb.closest('.comment-box');
    if (!box) return null;
    const cid = box.getAttribute('comment-id');
    if (!cid) return null;
    const match = cid.match(/\.(\d+)\.(-?\d+)$/);
    const revMatch = cid.match(/#\w+\.\w+\.(\d+)\./);
    if (!match || !revMatch) return null;
    const authorEl = box.querySelector(SELECTORS.COMMENT_AUTHOR);
    const bodyEl = box.querySelector(SELECTORS.COMMENT_BODY);
    return {
      revision: parseInt(revMatch[1], 10),
      post: parseInt(match[1], 10),
      author: authorEl?.textContent?.trim() || 'Unknown',
      text: bodyEl?.textContent?.trim()?.substring(0, 300) || '',
    };
  }).filter(Boolean);

  if (comments.length === 0) return;

  // Build panel
  const panel = document.createElement('div');
  panel.id = 'storegen-context-panel';

  const header = document.createElement('div');
  header.className = 'storegen-context-panel-header';
  header.innerHTML = `<span>💬 Add context for ${comments.length} comment${comments.length > 1 ? 's' : ''}</span>`;
  const closeBtn = document.createElement('button');
  closeBtn.className = 'storegen-context-panel-close';
  closeBtn.innerHTML = '✕';
  closeBtn.onclick = () => panel.remove();
  header.appendChild(closeBtn);
  panel.appendChild(header);

  // Comment cards
  const list = document.createElement('div');
  list.className = 'storegen-context-panel-list';

  const cardStates = comments.map((c) => ({ comment: c, action: 'agree', context: '' }));

  cardStates.forEach((state, i) => {
    const card = document.createElement('div');
    card.className = 'storegen-context-card';

    const commentDiv = document.createElement('div');
    commentDiv.className = 'storegen-context-card-comment';
    const strong = document.createElement('strong');
    strong.textContent = `#${state.comment.post}`;
    const commentText = document.createTextNode(
      ` (${state.comment.author}): "${state.comment.text.substring(0, 120)}${state.comment.text.length > 120 ? '...' : ''}"`
    );
    commentDiv.appendChild(strong);
    commentDiv.appendChild(commentText);
    card.appendChild(commentDiv);

    const textarea = document.createElement('textarea');
    textarea.className = 'storegen-context-card-input';
    textarea.placeholder = 'Add context: corrections, approach, requirements... (optional)';
    card.appendChild(textarea);

    const actionsDiv = document.createElement('div');
    actionsDiv.className = 'storegen-context-card-actions';
    const label = document.createElement('label');
    const skipCb = document.createElement('input');
    skipCb.type = 'checkbox';
    skipCb.className = 'storegen-skip-checkbox';
    label.appendChild(skipCb);
    label.appendChild(document.createTextNode(' No additional context needed'));
    actionsDiv.appendChild(label);
    card.appendChild(actionsDiv);

    textarea.addEventListener('input', () => { state.context = textarea.value; });
    skipCb.addEventListener('change', () => {
      if (skipCb.checked) state.context = '';
      textarea.disabled = skipCb.checked;
      textarea.style.opacity = skipCb.checked ? '0.4' : '1';
    });

    list.appendChild(card);
  });
  panel.appendChild(list);

  // Footer
  const footer = document.createElement('div');
  footer.className = 'storegen-context-panel-footer';
  const sendBtn = document.createElement('button');
  sendBtn.className = 'storegen-context-panel-send';
  sendBtn.textContent = '🚀 Send to CodeGen with context';
  sendBtn.onclick = () => {
    const instructions = buildInstructions(crId, cardStates);
    if (!instructions) { alert('No comments selected to address.'); return; }
    sendBtn.disabled = true;
    sendBtn.textContent = 'Sending...';
    submitJobWithInstructions(
      instructions,
      (jobId, jobUrl) => { panel.remove(); onJobSubmitted(jobId, jobUrl); },
      (err) => { sendBtn.disabled = false; sendBtn.textContent = '🚀 Send to CodeGen with context'; alert('Failed: ' + err); },
      'browserextension-comments',
    );
  };
  footer.appendChild(sendBtn);
  panel.appendChild(footer);

  document.body.appendChild(panel);
  logger_log('Context panel opened with', comments.length, 'comments');
}

function buildInstructions(crId, cardStates) {
  if (cardStates.length === 0) return null;

  let instructions = `Generate a new revision on ${crId} that addresses these comments:\n\n`;

  cardStates.forEach(s => {
    instructions += `- revision ${s.comment.revision} comment ${s.comment.post}`;
    if (s.context.trim()) {
      instructions += `\n  OWNER CONTEXT: ${s.context.trim()}`;
    }
    instructions += '\n';
  });

  return instructions;
}

;// ./src/features/crux/crux-comments/index.js
// CRUX Comments Feature - Code Review Comment Integration (Standard CodeGen only)










/**
 * Initializes the standard CodeGen integration for CRUX code reviews
 * Sets up comment checkboxes, action button, and job status tracking
 * @param {Function} renderMarkdown - Function to render markdown to HTML
 */
function initCruxComments(renderMarkdown) {
  const crId = window.location.pathname.match(/\/reviews\/(CR-\d+)/)?.[1];
  const revision = window.location.pathname.match(/\/revisions\/(\d+)/)?.[1] || "1";

  if (!crId) return;

  const codeReviewKey = `${crId}-${revision}`;
  logger_log("Initialized for", codeReviewKey);

  injectStyles();

  function createJobBannerWrapper(jobId, jobUrl) {
    actionButtonController.hide();
    createJobBanner(jobId, jobUrl, codeReviewKey, renderMarkdown, () => {
      renderJobPillsWrapper();
      updateMainButtonState();
    });
  }

  function renderJobPillsWrapper() {
    renderJobPills(codeReviewKey, (job) => reopenJobStatusCard(job, renderMarkdown));
    updatePillsPosition(mainButton);
  }

  const actionButtonController = createActionButton(
    crId,
    codeReviewKey,
    createJobBannerWrapper,
    () => updatePillsPosition(mainButton),
    () => openContextPanel(crId, createJobBannerWrapper),
  );
  const mainButton = actionButtonController.element;
  const updateMainButtonState = actionButtonController.updateState;

  document.body.appendChild(mainButton);

  const existingJobId = getStoredJob(codeReviewKey);
  const hasActiveJob = !!existingJobId;

  if (hasActiveJob) {
    logger_log("Found existing job:", existingJobId);
    fetchJobDetails(
      existingJobId,
      (data) => createJobBannerWrapper(existingJobId, data.jobUrl || data.viewLogsUrl),
      () => createJobBannerWrapper(existingJobId),
    );
  } else {
    renderJobPillsWrapper();
  }

  setupStandardCheckboxes(codeReviewKey, hasActiveJob, updateMainButtonState);
  hidePromotionalComments();
}

;// ./src/features/crux/crux-homepage/packageContext.js
// Package context utilities for extracting package information


/**
 * Checks if the package is public by looking for the public badge
 * @returns {boolean} True if package is public, false if private or unknown
 */
function isPackagePublic() {
  // Look for any label elements and check their text
  const labels = document.querySelectorAll('.label');
  
  for (const label of labels) {
    const text = label.textContent.trim().toLowerCase();
    
    if (text === 'public') {
      return true;
    }
    if (text === 'private' || text === 'protected') {
      return false;
    }
  }
  
  return false;
}

/**
 * Gets the package name from the current page
 * Tries DOM extraction first, falls back to URL parsing
 * @returns {string|null} Package name or null if not found
 */
function getPackageName() {
  const fromDOM = getPackageNameFromDOM();
  if (fromDOM) {
    return fromDOM;
  }

  const fromURL = getPackageNameFromURL();
  if (fromURL) {
    return fromURL;
  }

  logger_log("Could not extract package name");
  return null;
}

/**
 * Extracts package name from page DOM
 * Looks for <h1> element in .page-header
 * @returns {string|null} Package name or null if not found
 */
function getPackageNameFromDOM() {
  const h1 = document.querySelector('.page-header h1');
  if (!h1) return null;

  const packageName = h1.textContent.trim();
  return validatePackageName(packageName) ? packageName : null;
}

/**
 * Extracts package name from URL path
 * Matches pattern: /packages/{packageName} or /packages/{packageName}/...
 * @returns {string|null} Package name or null if not found
 */
function getPackageNameFromURL() {
  const match = window.location.pathname.match(/^\/packages\/([^\/]+)/);
  if (!match) return null;

  const packageName = match[1];
  return validatePackageName(packageName) ? packageName : null;
}

/**
 * Validates that a package name is non-empty and reasonable
 * @param {string} name - Package name to validate
 * @returns {boolean} True if valid
 */
function validatePackageName(name) {
  return name && name.length > 0 && name.length < 256;
}

/**
 * Extracts the file path from the current URL if viewing a file
 * Matches pattern: /packages/{package}/blobs/{branch}/--/{filepath}
 * @returns {string|null} File path or null if not viewing a file
 */
function getCurrentFilePath() {
  // Match file blob URLs: /packages/{package}/blobs/{branch}/--/{filepath}
  const match = window.location.pathname.match(/^\/packages\/[^\/]+\/blobs\/[^\/]+\/--\/(.+)$/);
  if (!match) return null;

  const filePath = match[1];
  return filePath && filePath.length > 0 ? filePath : null;
}

;// ./src/features/crux/crux-homepage/codegenButton.js
// CodeGen button component for package home page header



/**
 * Creates a prominent CodeGen button for the package header
 * @param {string} packageName - Name of the package
 * @param {Function} onClick - Callback when button is clicked
 * @returns {HTMLElement} Button element
 */
function createCodeGenButton(packageName, onClick) {
  const button = document.createElement('button');
  button.id = 'storegen-codegen-button';
  button.className = 'storegen-package-header-button';
  
  // Add attention-grabbing shake animation for CodeGenGuestBook
  if (packageName === 'CodeGenGuestBook') {
    button.classList.add('attention-shake');
  }
  
  // Create logo
  const logo = logo_createStoreGenLogo();
  logo.style.width = '24px';
  logo.style.height = '24px';
  logo.style.marginRight = '8px';
  
  // Create text
  const text = document.createElement('span');
  text.textContent = 'Generate Code';
  
  button.appendChild(logo);
  button.appendChild(text);
  
  button.onclick = (e) => {
    e.preventDefault();
    onClick();
  };
  
  return button;
}

/**
 * Inserts the CodeGen button into the package header next to the package name
 * @param {HTMLElement} button - The button element to insert
 * @returns {boolean} True if insertion succeeded
 */
function insertCodeGenButton(button) {
  const pageHeader = document.querySelector('.page-header');
  if (!pageHeader) {
    return false;
  }

  // Find the h1 element (package name)
  const h1 = pageHeader.querySelector('h1');
  if (!h1) {
    return false;
  }

  // Create a wrapper div to hold h1 and button side by side
  const wrapper = document.createElement('div');
  wrapper.style.display = 'flex';
  wrapper.style.alignItems = 'center';
  wrapper.style.gap = '16px';
  
  // Move h1 into wrapper
  h1.parentNode.insertBefore(wrapper, h1);
  wrapper.appendChild(h1);
  wrapper.appendChild(button);

  return true;
}

/**
 * Removes the CodeGen button from the page
 */
function removeCodeGenButton() {
  const button = document.getElementById('storegen-codegen-button');
  if (button) {
    button.remove();
  }
}

;// ./src/core/user.js
// User information utilities


/**
 * Extracts the current user's alias from the CRUX page
 * @returns {string|null} User alias or null if not found
 */
function getCurrentUserAlias() {
  // Strategy 1: Look for the Workspaces link which contains the user's alias
  // Format: https://code.amazon.com/workspaces/{alias}
  const workspacesLink = document.querySelector('a[href*="/workspaces/"]');
  if (workspacesLink) {
    const href = workspacesLink.getAttribute('href');
    const match = href?.match(/\/workspaces\/([a-z][a-z0-9-]+)/i);
    if (match) {
      const alias = match[1].toLowerCase();
      logger_log('Found alias from workspaces link:', alias);
      return alias;
    }
  }
  
  // Strategy 2: Check for user menu/profile elements
  const userMenuSelectors = [
    '[data-testid="user-menu-trigger"]',
    '[data-testid="user-menu"]',
    '.user-menu',
    '.user-profile',
    '#user-menu',
    '[aria-label*="user" i]',
    '[aria-label*="profile" i]'
  ];
  
  for (const selector of userMenuSelectors) {
    const element = document.querySelector(selector);
    if (element) {
      const text = element.textContent?.trim();
      if (text && /^[a-z][a-z0-9-]*$/.test(text) && text.length > 2 && text.length < 20) {
        logger_log('Found alias from user menu:', text);
        return text;
      }
    }
  }
  
  // Strategy 3: Look in the page header for username patterns
  const header = document.querySelector('header');
  if (header) {
    const headerText = header.textContent || '';
    const aliasMatch = headerText.match(/\b([a-z][a-z0-9-]{2,19})\b/);
    if (aliasMatch) {
      logger_log('Found alias in header:', aliasMatch[1]);
      return aliasMatch[1];
    }
  }
  
  // Strategy 4: Check localStorage for user info
  try {
    const keys = Object.keys(localStorage);
    for (const key of keys) {
      if (key.toLowerCase().includes('user') || key.toLowerCase().includes('alias')) {
        const value = localStorage.getItem(key);
        if (value) {
          try {
            const parsed = JSON.parse(value);
            if (parsed.alias || parsed.username || parsed.user) {
              const alias = parsed.alias || parsed.username || parsed.user;
              logger_log('Found alias in localStorage:', key, alias);
              return alias;
            }
          } catch {
            // Not JSON, check if the value itself is an alias
            if (/^[a-z][a-z0-9-]{2,19}$/.test(value)) {
              logger_log('Found alias in localStorage value:', key, value);
              return value;
            }
          }
        }
      }
    }
  } catch (e) {
    logger_log('Error checking localStorage:', e);
  }
  
  // Strategy 5: Check for meta tags
  const metaUser = document.querySelector('meta[name="user"], meta[name="username"], meta[name="alias"]');
  if (metaUser) {
    const alias = metaUser.getAttribute('content');
    if (alias) {
      logger_log('Found alias in meta tag:', alias);
      return alias;
    }
  }

  logger_log('Could not find user alias');
  return null;
}

;// ./src/core/urlUtils.js
// Shared URL utility functions used across features

/**
 * Escapes HTML special characters to prevent XSS when interpolating into innerHTML
 * @param {string} str - String to escape
 * @returns {string} Escaped string safe for HTML insertion
 */
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Sanitizes a URL to prevent javascript: and other dangerous protocol injections.
 * Only allows http: and https: URLs. Returns empty string for unsafe values.
 * @param {string} url - URL to sanitize
 * @returns {string} The original URL if safe, or empty string if unsafe/missing
 */
function sanitizeUrl(url) {
  if (!url) return '';
  try {
    const parsed = new URL(url);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
      return url;
    }
  } catch {
    // invalid URL
  }
  return '';
}

// Constants for URL reference feature
const MAX_URLS = 5;
const MAX_CONTENT_CHARS = 200000; // ~50k tokens, safe within 256KB SQS limit

/**
 * Validates if a URL belongs to an allowed internal Amazon domain
 * @param {string} url - URL to validate
 * @returns {boolean} True if URL is from an allowed domain
 */
function isAllowedDomain(url) {
  const ALLOWED_DOMAINS = ['amazon.com', 'amazon.dev', 'amazon.work', 'aws.dev', 'a2z.com', 'quip-amazon.com'];
  try {
    const hostname = new URL(url).hostname.toLowerCase();
    return ALLOWED_DOMAINS.some(domain =>
      hostname === domain || hostname.endsWith('.' + domain)
    );
  } catch {
    return false;
  }
}

/**
 * Formats byte size to human readable string
 * @param {number} bytes - Size in bytes
 * @returns {string} Formatted size string (e.g., "70.92KB")
 */
function formatSize(bytes) {
  if (bytes < 1024) return bytes + 'B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + 'KB';
  return (bytes / (1024 * 1024)).toFixed(2) + 'MB';
}

/**
 * Truncates URL for display purposes
 * @param {string} url - URL to truncate
 * @param {number} maxLength - Maximum length before truncation
 * @returns {string} Truncated URL
 */
function truncateUrl(url, maxLength = 40) {
  try {
    const parsed = new URL(url);
    const display = parsed.hostname + parsed.pathname;
    return display.length > maxLength ? display.substring(0, maxLength - 3) + '...' : display;
  } catch {
    return url.length > maxLength ? url.substring(0, maxLength - 3) + '...' : url;
  }
}

/**
 * Returns the maximum number of URLs allowed
 * @returns {number} Maximum URL count
 */
function getMaxUrls() {
  return MAX_URLS;
}

/**
 * Returns the maximum content size in characters
 * @returns {number} Maximum content characters
 */
function getMaxContentChars() {
  return MAX_CONTENT_CHARS;
}

;// ./src/ui/components/url/urlSectionUi.js
// URL section UI creation and DOM manipulation

// Note: getMaxUrls removed as count display was removed from UI

/**
 * Creates the URL reference section HTML
 * @returns {string} HTML string for URL section
 */
function createUrlSectionHtml() {
  return `
    <div class="storegen-url-section" style="display: none;">
      <div class="storegen-url-header">
        <span class="storegen-url-title">Reference Links</span>
      </div>
      <div class="storegen-url-subtitle">Add links to internal pages as context for code generation</div>
      <div class="storegen-security-banner">
        CodeGen is ORANGE certified. Take care not to include RED classified data.
        <a href="https://prod.dace.infosec.amazon.dev/" target="_blank" rel="noopener">Learn more</a>
      </div>
      <div class="storegen-url-input-row">
        <input type="text" class="storegen-url-input"
               placeholder="https://quip-amazon.com/abc123" />
        <button type="button" class="storegen-url-add-btn">Add</button>
      </div>
      <div class="storegen-url-list"></div>
      <div class="storegen-url-error" style="display: none;"></div>
    </div>
  `;
}



/**
 * Adds a URL item to the list in loading state
 * @param {HTMLElement} modal - Modal element
 * @param {string} url - URL being added
 * @param {Function} onRemove - Callback when remove button clicked
 */
function addUrlItem(modal, url, onRemove) {
  const list = modal.querySelector('.storegen-url-list');
  if (!list) return;

  const item = document.createElement('div');
  item.className = 'storegen-url-item storegen-url-loading';
  item.dataset.url = url;
  item.innerHTML = `
    <span class="storegen-url-text">${escapeHtml(truncateUrl(url, 45))}</span>
    <span class="storegen-url-size"></span>
    <button type="button" class="storegen-url-remove">×</button>
  `;

  item.querySelector('.storegen-url-remove').addEventListener('click', () => onRemove(url));
  list.appendChild(item);
}

/**
 * Updates URL item status and size
 * @param {HTMLElement} modal - Modal element
 * @param {string} url - URL to update
 * @param {string} status - 'success' | 'error'
 * @param {string} errorOrSize - Error message if error, or content size in bytes if success
 */
function updateUrlItemStatus(modal, url, status, errorOrSize = '') {
  const item = modal.querySelector(`.storegen-url-item[data-url="${CSS.escape(url)}"]`);
  if (!item) return;

  item.className = `storegen-url-item storegen-url-${status}`;
  const sizeEl = item.querySelector('.storegen-url-size');
  if (status === 'success' && typeof errorOrSize === 'number') {
    sizeEl.textContent = formatSize(errorOrSize);
  } else if (status === 'error') {
    sizeEl.textContent = errorOrSize;
    sizeEl.classList.add('storegen-url-error-text');
  }
}

/**
 * Removes URL item from list
 * @param {HTMLElement} modal - Modal element
 * @param {string} url - URL to remove
 */
function removeUrlItem(modal, url) {
  const item = modal.querySelector(`.storegen-url-item[data-url="${CSS.escape(url)}"]`);
  if (item) item.remove();
}

/**
 * Shows an error message in the URL section
 * @param {HTMLElement} modal - Modal element
 * @param {string} message - Error message
 */
function showUrlError(modal, message) {
  const errorEl = modal.querySelector('.storegen-url-error');
  if (errorEl) {
    errorEl.textContent = message;
    errorEl.style.display = 'block';
  }
}

/**
 * Hides the error message
 * @param {HTMLElement} modal - Modal element
 */
function hideUrlError(modal) {
  const errorEl = modal.querySelector('.storegen-url-error');
  if (errorEl) errorEl.style.display = 'none';
}

;// ./src/ui/components/url/simTaskeiUtils.js
// SIM/Taskei URL parsing and formatting utilities

// Patterns for SIM/Taskei URLs that need Maxis API
const SIM_TASKEI_PATTERNS = [
  { regex: /sim\.amazon\.com\/issues\/([A-Za-z0-9-]+)/, idGroup: 1 },
  { regex: /t\.corp\.amazon\.com\/([A-Za-z0-9-]+)/, idGroup: 1 },
  { regex: /issues\.amazon\.com\/issues\/([A-Za-z0-9-]+)/, idGroup: 1 },
  { regex: /taskei\.amazon\.dev\/tasks\/([A-Za-z0-9-]+)/, idGroup: 1 }
];

/**
 * Extracts issue ID from SIM/Taskei/t.corp URLs
 * @param {string} url - URL to check
 * @returns {{isSimTaskei: boolean, issueId: string|null}} Result object
 */
function extractSimTaskeiId(url) {
  for (const pattern of SIM_TASKEI_PATTERNS) {
    const match = url.match(pattern.regex);
    if (match) {
      return { isSimTaskei: true, issueId: match[pattern.idGroup] };
    }
  }
  return { isSimTaskei: false, issueId: null };
}

/**
 * Checks if a URL is a SIM/Taskei/t.corp URL
 * @param {string} url - URL to check
 * @returns {boolean} True if SIM/Taskei URL
 */
function isSimTaskeiUrl(url) {
  return SIM_TASKEI_PATTERNS.some(pattern => pattern.regex.test(url));
}

;// ./src/ui/components/url/simTaskeiApi.js
// SIM/Taskei API module using Maxis API


const MAXIS_API_URL = 'https://maxis-service-prod-pdx.amazon.com/issues';

/**
 * Converts Maxis API response to markdown
 * @param {Object} data - Maxis API response
 * @param {string} issueId - Issue ID
 * @returns {string} Formatted markdown
 */
function maxisResponseToMarkdown(data, issueId) {
  // Maxis API returns 'documents' array, not 'issues'
  const documents = data.documents || [];
  if (documents.length === 0) {
    return `Issue ${issueId}: No data found`;
  }

  const doc = documents[0];
  const lines = [];

  // Title
  lines.push(`# ${doc.title || issueId}`);
  lines.push('');

  // Metadata
  if (doc.status) lines.push(`**Status:** ${doc.status}`);
  if (doc.assigneeIdentity) {
    // Extract username from "kerberos:username@ANT.AMAZON.COM"
    const assignee = doc.assigneeIdentity.replace(/^kerberos:/, '').replace(/@ANT\.AMAZON\.COM$/i, '');
    lines.push(`**Assignee:** ${assignee}`);
  }
  if (doc.createDate) lines.push(`**Created:** ${doc.createDate}`);
  if (doc.lastUpdatedDate) lines.push(`**Updated:** ${doc.lastUpdatedDate}`);

  // Description
  if (doc.description) {
    lines.push('');
    lines.push('## Description');
    lines.push(doc.description);
  }

  // Comments from conversation array
  if (doc.conversation && doc.conversation.length > 0) {
    lines.push('');
    lines.push('## Comments');
    doc.conversation.forEach((comment, i) => {
      // Extract author username
      let author = comment.authorIdentity || '';
      if (author.startsWith('kerberos:')) {
        author = author.replace(/^kerberos:/, '').replace(/@ANT\.AMAZON\.COM$/i, '');
      }

      lines.push(`### Comment ${i + 1}`);
      if (author) lines.push(`**Author:** ${author}`);
      if (comment.createDate) lines.push(`**Date:** ${comment.createDate}`);
      if (comment.message) lines.push(comment.message);
      lines.push('');
    });
  }

  return lines.join('\n');
}

/**
 * Fetches issue details from Maxis API
 * @param {string} originalUrl - Original SIM/Taskei URL for reference
 * @param {string} issueId - Issue ID (SIM, Taskei, t.corp)
 * @returns {Promise<{url: string, content: string, size: number}>}
 */
function fetchFromMaxis(originalUrl, issueId) {
  const apiUrl = `${MAXIS_API_URL}?id.1=${issueId}`;

  return new Promise((resolve, reject) => {
    if (typeof GM_xmlhttpRequest === 'undefined') {
      reject(new Error('GM_xmlhttpRequest not available'));
      return;
    }

    logger_log(`Fetching from Maxis: ${issueId}`);

    GM_xmlhttpRequest({
      method: 'GET',
      url: apiUrl,
      withCredentials: true,
      timeout: 30000,
      onload: (response) => {
        if (response.status >= 200 && response.status < 300) {
          try {
            const data = JSON.parse(response.responseText);
            const content = maxisResponseToMarkdown(data, issueId);
            resolve({
              url: originalUrl,
              content: content,
              size: new Blob([content]).size
            });
          } catch (e) {
            reject(new Error('Failed to parse Maxis API response'));
          }
        } else {
          reject(new Error(`Failed to fetch from Maxis: ${response.status} ${response.statusText}`));
        }
      },
      onerror: () => reject(new Error('Network error: Unable to fetch from Maxis API')),
      ontimeout: () => reject(new Error('Maxis API request timed out'))
    });
  });
}

;// ./src/ui/components/url/quipApi.js
// Quip API module for fetching document content


const QUIP_API_BASE = 'https://platform.quip-amazon.com/1';
const QUIP_TOKEN_KEY = 'storegen_quip_token';

/**
 * Checks if a URL is a Quip document URL
 * @param {string} url - URL to check
 * @returns {boolean} True if Quip URL
 */
function isQuipUrl(url) {
  return url.includes('quip-amazon.com/');
}

/**
 * Extracts thread ID from a Quip URL
 * @param {string} url - Quip URL
 * @returns {string|null} Thread ID or null
 */
function extractQuipThreadId(url) {
  // Quip URLs: https://quip-amazon.com/AbCdEfGhIjKl/Document-Title
  const match = url.match(/quip-amazon\.com\/([a-zA-Z0-9]+)/);
  return match ? match[1] : null;
}

/**
 * Gets the stored Quip API token
 * @returns {string|null} Token or null if not set
 */
function getQuipToken() {
  if (typeof GM_getValue === 'undefined') {
    return null;
  }
  return GM_getValue(QUIP_TOKEN_KEY, null);
}

/**
 * Stores the Quip API token
 * @param {string} token - Token to store
 */
function setQuipToken(token) {
  if (typeof GM_setValue !== 'undefined') {
    GM_setValue(QUIP_TOKEN_KEY, token);
  }
}

/**
 * Clears the stored Quip API token
 */
function clearQuipToken() {
  if (typeof GM_deleteValue !== 'undefined') {
    GM_deleteValue(QUIP_TOKEN_KEY);
  }
}

/**
 * Validates a Quip API token format
 * Token format: <base64>|<timestamp>|<base64_signature>
 * @param {string} token - Token to validate
 * @returns {boolean} True if valid format
 */
function isValidTokenFormat(token) {
  // Quip tokens contain base64 strings, pipe separators, and numbers
  return token && typeof token === 'string' && token.length >= 20 && /^[A-Za-z0-9=+/|]+$/.test(token);
}

/**
 * Fetches Quip document content using the API
 * @param {string} threadId - Quip thread/document ID
 * @returns {Promise<{success: boolean, content?: string, error?: string, needsToken?: boolean}>}
 */
function fetchQuipDocument(threadId) {
  return new Promise((resolve) => {
    const token = getQuipToken();
    if (!token) {
      resolve({ success: false, error: 'Quip token not configured', needsToken: true });
      return;
    }

    if (typeof GM_xmlhttpRequest === 'undefined') {
      resolve({ success: false, error: 'GM_xmlhttpRequest not available' });
      return;
    }

    const apiUrl = `${QUIP_API_BASE}/threads/${threadId}`;
    logger_log(`Fetching Quip document: ${threadId}, token length: ${token.length}`);

    GM_xmlhttpRequest({
      method: 'GET',
      url: apiUrl,
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000,
      onload: (response) => {
        if (response.status === 401 || response.status === 403) {
          resolve({ success: false, error: 'Invalid or expired token', needsToken: true });
          return;
        }
        if (response.status >= 200 && response.status < 300) {
          try {
            const data = JSON.parse(response.responseText);
            const content = formatQuipDocument(data);
            resolve({ success: true, content });
          } catch (error) {
            logger_log('Error parsing Quip response:', error);
            resolve({ success: false, error: 'Failed to parse response' });
          }
        } else if (response.status === 400) {
          // Check if it's a token-related error
          logger_log('Quip API error:', response.status, response.responseText);
          const isTokenError = response.responseText &&
            (response.responseText.includes('invalid') || response.responseText.includes('expired'));
          if (isTokenError) {
            clearQuipToken();
            resolve({ success: false, error: 'Quip token is invalid or expired. Please reconfigure.', needsToken: true });
          } else {
            resolve({ success: false, error: `HTTP ${response.status}: Bad request` });
          }
        } else {
          logger_log('Quip API error:', response.status, response.responseText);
          resolve({ success: false, error: `HTTP ${response.status}: ${response.statusText || 'Unknown error'}` });
        }
      },
      onerror: () => resolve({ success: false, error: 'Network error' }),
      ontimeout: () => resolve({ success: false, error: 'Request timed out' })
    });
  });
}

/**
 * Formats Quip document data as markdown
 * @param {Object} data - Quip API response
 * @returns {string} Formatted markdown
 */
function formatQuipDocument(data) {
  const thread = data.thread || {};
  const title = thread.title || 'Untitled Document';
  const html = data.html || '';

  // Convert HTML to plain text (basic conversion)
  const content = html
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n\n')
    .replace(/<[^>]+>/g, '')
    .trim();

  return `# ${title}\n\n${content}`;
}

;// ./src/ui/components/url/htmlToMarkdown.js
// HTML to Markdown conversion module


/**
 * Converts HTML content to Markdown using TurndownService
 * @param {string} html - HTML content to convert
 * @returns {string} Markdown content
 */
function htmlToMarkdown(html) {
  // TurndownService is loaded via @require in the userscript header
  if (typeof TurndownService === 'undefined') {
    logger_log('TurndownService not available, returning raw HTML');
    return html;
  }

  const turndownService = new TurndownService({
    headingStyle: 'atx',
    codeBlockStyle: 'fenced',
    emDelimiter: '_'
  });

  // Remove script and style tags before conversion
  const cleanHtml = html
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '');

  try {
    return turndownService.turndown(cleanHtml);
  } catch (error) {
    logger_log('Error converting HTML to Markdown:', error);
    return html;
  }
}

/**
 * Extracts the main content from an HTML document
 * @param {string} html - Full HTML document
 * @returns {string} Extracted main content HTML
 */
function extractMainContent(html) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');

  // Try to find the main content area
  const mainSelectors = [
    'main', 'article', '[role="main"]', '#content',
    '#main-content', '.content', '.main-content'
  ];

  let mainContent = null;
  for (const selector of mainSelectors) {
    mainContent = doc.querySelector(selector);
    if (mainContent) break;
  }

  if (!mainContent) {
    mainContent = doc.body;
  }

  // Remove unwanted elements
  const unwantedSelectors = [
    'nav', 'header', 'footer', 'aside', '.sidebar',
    '.navigation', '.menu', '.comments', '.ads'
  ];

  for (const selector of unwantedSelectors) {
    mainContent.querySelectorAll(selector).forEach(el => el.remove());
  }

  return mainContent.innerHTML;
}

;// ./src/ui/components/url/urlFetcher.js
// URL fetching module using GM_xmlhttpRequest



/**
 * Checks if URL is a code.amazon.com blob URL and needs raw=1 param
 * @param {string} url - URL to check
 * @returns {string} URL with raw=1 appended if needed
 */
function normalizeCodeUrl(url) {
  // Match code.amazon.com blob URLs
  if (url.includes('code.amazon.com/packages/') && url.includes('/blobs/')) {
    const urlObj = new URL(url);
    if (!urlObj.searchParams.has('raw')) {
      urlObj.searchParams.set('raw', '1');
      return urlObj.toString();
    }
  }
  return url;
}

/**
 * Checks if content looks like HTML (has HTML tags)
 * @param {string} content - Content to check
 * @returns {boolean} True if content appears to be HTML
 */
function looksLikeHtml(content) {
  // Check for common HTML indicators
  return /<(!DOCTYPE|html|head|body|div|p|span)\b/i.test(content.slice(0, 1000));
}

/**
 * Fetches content from a URL using GM_xmlhttpRequest
 * @param {string} url - URL to fetch
 * @returns {Promise<{success: boolean, content?: string, error?: string, contentType?: string}>}
 */
function fetchUrlContent(url) {
  return new Promise((resolve) => {
    if (typeof GM_xmlhttpRequest === 'undefined') {
      resolve({ success: false, error: 'GM_xmlhttpRequest not available' });
      return;
    }

    // Normalize code.amazon.com URLs to get raw content
    const fetchUrl = normalizeCodeUrl(url);
    logger_log(`Fetching URL: ${fetchUrl}`);

    GM_xmlhttpRequest({
      method: 'GET',
      url: fetchUrl,
      headers: {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
      },
      timeout: 30000,
      onload: (response) => {
        if (response.status >= 200 && response.status < 300) {
          const contentType = getContentType(response.responseHeaders);
          let content = response.responseText;

          // Only convert to Markdown if content is actually HTML
          // Skip conversion for raw text files (code, yaml, json, etc.)
          const isHtmlType = contentType.includes('text/html') || contentType.includes('application/xhtml');
          if (isHtmlType && looksLikeHtml(content)) {
            content = extractMainContent(content);
            content = htmlToMarkdown(content);
          }

          resolve({ success: true, content, contentType });
        } else {
          resolve({ success: false, error: `HTTP ${response.status}: ${response.statusText}` });
        }
      },
      onerror: (error) => {
        logger_log('Error fetching URL:', error);
        resolve({ success: false, error: 'Network error occurred' });
      },
      ontimeout: () => {
        resolve({ success: false, error: 'Request timed out' });
      }
    });
  });
}

/**
 * Extracts content-type from response headers
 * @param {string} headers - Response headers string
 * @returns {string} Content type
 */
function getContentType(headers) {
  return headers
    .split('\n')
    .find(h => h.toLowerCase().startsWith('content-type:'))
    ?.split(':')[1]
    ?.trim() || 'text/html';
}

;// ./src/ui/components/url/quipTokenModal.js
// Quip token configuration modal


const QUIP_TOKEN_PAGE = 'https://quip-amazon.com/dev/token';

/**
 * Shows a modal to configure the Quip API token
 * @returns {Promise<string>} Resolves with the token when user submits, rejects if cancelled
 */
function showQuipTokenModal() {
  return new Promise((resolve, reject) => {
    const overlay = document.createElement('div');
    overlay.className = 'storegen-modal-overlay';

    const modal = document.createElement('div');
    modal.className = 'storegen-modal storegen-quip-token-modal';

    const existingToken = getQuipToken();
    const hasToken = existingToken && isValidTokenFormat(existingToken);

    modal.innerHTML = `
      <div class="storegen-modal-header">
        <h3>Configure Quip API Token</h3>
        <button class="storegen-modal-close">×</button>
      </div>
      <div class="storegen-modal-body">
        <div class="storegen-quip-token-notice ${hasToken ? 'storegen-quip-token-configured' : 'storegen-quip-token-missing'}">
          ${hasToken
            ? 'Quip API token is configured. You can update it below if needed.'
            : 'Missing Quip API Token! Please generate and enter a token to fetch Quip documents.'}
        </div>
        <div class="storegen-quip-token-field">
          <label for="storegen-quip-token-input"><strong>Quip API Token:</strong></label>
          <input
            type="text"
            id="storegen-quip-token-input"
            placeholder="Enter your Quip API token..."
            value="${hasToken ? '••••••••••••••••••••' : ''}"
            autocomplete="off"
          />
          <div class="storegen-quip-token-validation" style="display: none;"></div>
        </div>
        <p class="storegen-quip-token-help">
          To generate a Quip API token, click the button below. Copy the token from that page and paste it here.
        </p>
        <div class="storegen-modal-message" style="display: none;"></div>
      </div>
      <div class="storegen-modal-footer">
        <button class="storegen-quip-open-page-btn">Open Quip API Token Page</button>
        <div class="storegen-modal-footer-buttons">
          <button class="storegen-modal-cancel">Cancel</button>
          <button class="storegen-modal-submit">Save Token</button>
        </div>
      </div>
    `;

    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    // Force-apply styles to resist Cloudscape/Taskei CSS overrides
    forceQuipModalStyles(overlay);

    const tokenInput = modal.querySelector('#storegen-quip-token-input');
    const validationDiv = modal.querySelector('.storegen-quip-token-validation');
    const openPageBtn = modal.querySelector('.storegen-quip-open-page-btn');
    const submitBtn = modal.querySelector('.storegen-modal-submit');
    const cancelBtn = modal.querySelector('.storegen-modal-cancel');
    const closeBtn = modal.querySelector('.storegen-modal-close');
    const messageDiv = modal.querySelector('.storegen-modal-message');

    // Clear placeholder when user focuses input
    tokenInput.onfocus = () => {
      if (tokenInput.value === '••••••••••••••••••••') {
        tokenInput.value = '';
      }
    };

    // Validate token as user types
    tokenInput.oninput = () => {
      const token = tokenInput.value.trim();
      if (!token || token === '••••••••••••••••••••') {
        validationDiv.style.display = 'none';
        return;
      }

      if (isValidTokenFormat(token)) {
        validationDiv.textContent = 'Token format looks valid';
        validationDiv.className = 'storegen-quip-token-validation storegen-quip-token-valid';
        validationDiv.style.display = 'block';
      } else {
        validationDiv.textContent = "This doesn't look like a Quip API token...";
        validationDiv.className = 'storegen-quip-token-validation storegen-quip-token-invalid';
        validationDiv.style.display = 'block';
      }
    };

    // Open token generation page
    openPageBtn.onclick = () => {
      window.open(QUIP_TOKEN_PAGE, '_blank');
    };

    // Close handlers
    const closeModal = (success, token) => {
      overlay.remove();
      if (success) {
        resolve(token);
      } else {
        reject(new Error('Quip token configuration cancelled'));
      }
    };

    closeBtn.onclick = () => closeModal(false);
    cancelBtn.onclick = () => closeModal(false);
    overlay.onclick = (e) => {
      if (e.target === overlay) closeModal(false);
    };

    // Submit handler
    submitBtn.onclick = () => {
      const token = tokenInput.value.trim();

      // If unchanged placeholder, use existing token
      if (token === '••••••••••••••••••••' && hasToken) {
        closeModal(true, existingToken);
        return;
      }

      if (!token) {
        messageDiv.textContent = 'Please enter a Quip API token';
        messageDiv.className = 'storegen-modal-message storegen-modal-error';
        messageDiv.style.display = 'block';
        return;
      }

      if (!isValidTokenFormat(token)) {
        messageDiv.textContent = 'Invalid token format. Quip tokens are alphanumeric strings.';
        messageDiv.className = 'storegen-modal-message storegen-modal-error';
        messageDiv.style.display = 'block';
        return;
      }

      // Save token and resolve
      setQuipToken(token);
      closeModal(true, token);
    };

    tokenInput.focus();
  });
}


/**
 * Force-applies inline styles to the Quip token modal to resist Cloudscape/Taskei CSS overrides.
 * Without this, Taskei's Cloudscape styles overpower the modal and render it as a black block.
 */
function forceQuipModalStyles(overlay) {
  const s = (el, styles) => { for (const [p, v] of Object.entries(styles)) el.style.setProperty(p, v, 'important'); };

  s(overlay, {
    'position': 'fixed', 'top': '0', 'left': '0', 'right': '0', 'bottom': '0',
    'background': 'rgba(0,0,0,0.5)', 'display': 'flex', 'align-items': 'center',
    'justify-content': 'center', 'z-index': '10001', 'pointer-events': 'auto',
  });

  const modal = overlay.querySelector('.storegen-modal');
  if (modal) {
    s(modal, {
      'position': 'relative', 'background': 'white', 'border-radius': '4px',
      'box-shadow': '0 4px 20px rgba(0,0,0,0.3)', 'border': '1px solid #e9ecef',
      'width': '500px', 'max-width': '90%', 'display': 'flex', 'flex-direction': 'column',
      'font-family': '"Amazon Ember","Helvetica Neue",Roboto,Arial,sans-serif',
      'pointer-events': 'auto', 'overflow': 'hidden', 'color': '#16191F',
    });
  }

  const header = overlay.querySelector('.storegen-modal-header');
  if (header) {
    s(header, {
      'display': 'flex', 'align-items': 'center', 'justify-content': 'space-between',
      'padding': '16px 20px', 'border-bottom': '1px solid #e9ecef', 'background': 'white',
    });
    const h3 = header.querySelector('h3');
    if (h3) s(h3, { 'margin': '0', 'font-size': '18px', 'font-weight': '600', 'color': '#16191F' });
  }

  const body = overlay.querySelector('.storegen-modal-body');
  if (body) {
    s(body, {
      'padding': '20px', 'display': 'flex', 'flex-direction': 'column',
      'gap': '12px', 'background': 'white',
    });
  }

  // Notice banner
  const notice = overlay.querySelector('.storegen-quip-token-notice');
  if (notice) {
    const isMissing = notice.classList.contains('storegen-quip-token-missing');
    s(notice, {
      'padding': '10px 14px', 'border-radius': '4px', 'font-size': '13px',
      'background': isMissing ? '#fff3cd' : '#d4edda',
      'color': isMissing ? '#664d03' : '#155724',
      'border': isMissing ? '1px solid #ffc107' : '1px solid #c3e6cb',
    });
  }

  // Labels and inputs
  overlay.querySelectorAll('.storegen-modal-body label').forEach(label => {
    s(label, { 'display': 'block', 'font-size': '14px', 'font-weight': '500', 'color': '#16191F' });
  });
  overlay.querySelectorAll('.storegen-modal-body input[type="text"]').forEach(input => {
    s(input, {
      'display': 'block', 'width': '100%', 'box-sizing': 'border-box',
      'padding': '10px', 'font-size': '14px', 'border': '1px solid #ced4da',
      'border-radius': '4px', 'font-family': 'inherit', 'color': '#16191F', 'background': 'white',
    });
  });

  // Help text
  const help = overlay.querySelector('.storegen-quip-token-help');
  if (help) s(help, { 'font-size': '13px', 'color': '#6c757d', 'margin': '0' });

  // Footer
  const footer = overlay.querySelector('.storegen-modal-footer');
  if (footer) {
    s(footer, {
      'display': 'flex', 'justify-content': 'space-between', 'align-items': 'center',
      'padding': '16px 20px', 'background': 'white', 'gap': '12px',
    });
  }

  // All footer buttons
  overlay.querySelectorAll('.storegen-modal-footer button').forEach(btn => {
    s(btn, {
      'padding': '8px 16px', 'font-size': '14px', 'font-weight': '500',
      'border-radius': '4px', 'cursor': 'pointer', 'font-family': 'inherit',
    });
  });
  const openPageBtn = overlay.querySelector('.storegen-quip-open-page-btn');
  if (openPageBtn) s(openPageBtn, { 'background': 'white', 'color': '#2074d5', 'border': '1px solid #2074d5' });
  const cancelBtn = overlay.querySelector('.storegen-modal-cancel');
  if (cancelBtn) s(cancelBtn, { 'background': 'white', 'color': '#16191F', 'border': '1px solid #ced4da' });
  const submitBtn = overlay.querySelector('.storegen-modal-submit');
  if (submitBtn) s(submitBtn, { 'background': '#16191F', 'color': 'white', 'border': 'none' });

  // Close button
  const closeBtn = overlay.querySelector('.storegen-modal-close');
  if (closeBtn) {
    s(closeBtn, {
      'background': 'none', 'border': 'none', 'font-size': '28px', 'color': '#6c757d',
      'cursor': 'pointer', 'padding': '0', 'width': '32px', 'height': '32px',
      'display': 'flex', 'align-items': 'center', 'justify-content': 'center',
    });
  }
}

;// ./src/ui/components/url/urlSection.js
// URL section coordination and fetching logic









// Store for fetched URL contents: [{url, content, size}]
const addedUrls = [];

/**
 * Initializes URL section event handlers
 * @param {HTMLElement} modal - Modal element
 */
function initUrlSection(modal) {
  const input = modal.querySelector('.storegen-url-input');
  const addBtn = modal.querySelector('.storegen-url-add-btn');
  if (!input || !addBtn) return;

  addBtn.addEventListener('click', () => handleAddUrl(modal));
  input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddUrl(modal);
    }
  });
}

async function handleAddUrl(modal) {
  const input = modal.querySelector('.storegen-url-input');
  const addBtn = modal.querySelector('.storegen-url-add-btn');
  const url = input.value.trim();

  // Validation
  if (!url) {
    showUrlError(modal, 'Please enter a URL');
    return;
  }
  if (!isValidUrl(url)) {
    showUrlError(modal, 'Please enter a valid URL');
    return;
  }
  if (!isAllowedDomain(url)) {
    showUrlError(modal, 'URL must be from an internal Amazon domain');
    return;
  }
  if (addedUrls.some(item => item.url === url)) {
    showUrlError(modal, 'This URL has already been added');
    return;
  }
  if (addedUrls.length >= getMaxUrls()) {
    showUrlError(modal, `Maximum ${getMaxUrls()} URLs allowed`);
    return;
  }

  // Show loading state
  addBtn.disabled = true;
  addBtn.textContent = 'Fetching...';
  hideUrlError(modal);

  try {
    const result = await urlSection_fetchUrlContent(url);

    // Check content size limit
    const maxSize = getMaxContentChars();
    const currentSize = getTotalContentSize();
    const newTotalSize = currentSize + result.content.length;
    if (newTotalSize > maxSize) {
      const maxKB = Math.round(maxSize / 1024);
      const currentKB = Math.round(currentSize / 1024);
      const newKB = Math.round(result.content.length / 1024);
      showUrlError(modal, `Content limit exceeded (${maxKB}KB max). Current: ${currentKB}KB, this URL: ${newKB}KB. Remove a URL or use smaller documents.`);
      return;
    }

    addedUrls.push(result);
    input.value = '';
    addUrlItem(modal, url, (u) => handleRemoveUrl(modal, u));
    updateUrlItemStatus(modal, url, 'success', result.size);
    logger_log('URL content fetched successfully:', url, 'Size:', result.size);
  } catch (error) {
    logger_log('Error fetching URL:', url, error);
    showUrlError(modal, `Failed to fetch URL: ${error.message}`);
  } finally {
    addBtn.disabled = false;
    addBtn.textContent = 'Add';
  }
}

/**
 * Fetches content from a URL
 * For SIM/Taskei URLs, uses Maxis API
 * For Quip URLs, uses Quip API with token authentication
 * @param {string} url - URL to fetch
 * @returns {Promise<{url: string, content: string, size: number}>}
 */
async function urlSection_fetchUrlContent(url) {
  // Check if this is a SIM/Taskei URL that needs Maxis API
  const { isSimTaskei, issueId } = extractSimTaskeiId(url);
  if (isSimTaskei && issueId) {
    return fetchFromMaxis(url, issueId);
  }

  // Check if this is a Quip URL that needs Quip API
  const threadId = extractQuipThreadId(url);
  if (isQuipUrl(url) && threadId) {
    // Check for existing token or prompt user
    let token = getQuipToken();

    if (!token || !isValidTokenFormat(token)) {
      // Show token configuration modal
      token = await showQuipTokenModal();
    }

    let result = await fetchQuipDocument(threadId);

    // If token was invalid/expired, prompt for new token and retry
    if (!result.success && result.needsToken) {
      logger_log('Quip token invalid, prompting for new token');
      token = await showQuipTokenModal();
      result = await fetchQuipDocument(threadId);
    }

    if (!result.success) {
      throw new Error(result.error || 'Failed to fetch Quip document');
    }
    return {
      url: url,
      content: result.content,
      size: new Blob([result.content]).size
    };
  }

  // Standard HTML fetch for other URLs
  const result = await fetchUrlContent(url);
  if (!result.success) {
    throw new Error(result.error || 'Failed to fetch URL');
  }
  return {
    url: url,
    content: result.content,
    size: new Blob([result.content]).size
  };
}

/**
 * Calculates total size of all stored content
 * @returns {number} Total content size in characters
 */
function getTotalContentSize() {
  return addedUrls.reduce((total, item) => total + item.content.length, 0);
}

function handleRemoveUrl(modal, url) {
  removeUrlItem(modal, url);
  const index = addedUrls.findIndex(item => item.url === url);
  if (index !== -1) {
    addedUrls.splice(index, 1);
  }
}

function isValidUrl(s) {
  try { new URL(s); return true; } catch { return false; }
}

/**
 * Gets all fetched URL contents as an array for API submission
 * @returns {Array<{url: string, content: string}>} Array of URL references (empty array if none)
 */
function getUrlContentsArray() {
  return addedUrls.map(item => ({
    url: item.url,
    content: item.content
  }));
}

/** Clears all URL contents */
function clearUrlContents() {
  addedUrls.length = 0;
}

/**
 * Programmatically adds a URL to the reference links section
 * Used for auto-loading scraped links from SIM pages
 * @param {HTMLElement} modal - Modal element
 * @param {string} url - URL to add
 */
async function addUrlProgrammatically(modal, url) {
  if (!isValidUrl(url) || !isAllowedDomain(url)) return;
  if (addedUrls.some(item => item.url === url)) return;
  if (addedUrls.length >= getMaxUrls()) return;

  // Add loading item to UI
  addUrlItem(modal, url, (u) => handleRemoveUrl(modal, u));

  try {
    const result = await urlSection_fetchUrlContent(url);

    const maxSize = getMaxContentChars();
    const currentSize = getTotalContentSize();
    if (currentSize + result.content.length > maxSize) {
      removeUrlItem(modal, url);
      logger_log('Auto-add skipped (content limit):', url);
      return;
    }

    addedUrls.push(result);
    updateUrlItemStatus(modal, url, 'success', result.size);
    logger_log('Auto-added URL:', url, 'Size:', result.size);
  } catch (error) {
    logger_log('Error auto-adding URL:', url, error);
    updateUrlItemStatus(modal, url, 'error', error.message);
    // Remove failed item after a moment
    setTimeout(() => removeUrlItem(modal, url), 3000);
  }
}

;// ./src/ui/components/voiceInput.js
// Voice input component using Web Speech API


const SpeechRecognition = typeof window !== 'undefined'
  ? window.SpeechRecognition || window.webkitSpeechRecognition
  : null;

// Auto-stop after this many seconds of silence
const SILENCE_TIMEOUT_MS = 7000;

/**
 * Checks if speech recognition is supported in the current browser
 * @returns {boolean}
 */
function isSpeechSupported() {
  return !!SpeechRecognition;
}

/**
 * Creates a mic button that toggles speech-to-text into a textarea
 * @param {HTMLTextAreaElement} textarea - Target textarea to fill
 * @returns {HTMLButtonElement|null} Mic button element, or null if unsupported
 */
function createVoiceInputButton(textarea) {
  if (!isSpeechSupported()) {
    logger_log('Speech recognition not supported in this browser');
    return null;
  }

  let recognition = null;
  let isListening = false;
  let silenceTimer = null;
  let statusTimer = null;

  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'storegen-voice-btn';
  button.title = 'Click to dictate (speech-to-text)';
  button.innerHTML = getMicIcon(false) + '<span class="storegen-voice-btn-label">Voice input</span>';

  /** Resets the silence timeout timer */
  function resetSilenceTimer() {
    if (silenceTimer) clearTimeout(silenceTimer);
    silenceTimer = setTimeout(() => {
      if (isListening) {
        logger_log('Silence timeout reached, stopping voice input');
        stop();
        showStatus('Stopped Listening');
      }
    }, SILENCE_TIMEOUT_MS);
  }

  /** Clears the silence timeout timer */
  function clearSilenceTimer() {
    if (silenceTimer) {
      clearTimeout(silenceTimer);
      silenceTimer = null;
    }
  }

  /** Shows a temporary status message below the mic button */
  function showStatus(message) {
    // Find or create status element as sibling of button
    let statusEl = button.parentElement?.querySelector('.storegen-voice-status');
    if (!statusEl) {
      statusEl = document.createElement('div');
      statusEl.className = 'storegen-voice-status';
      button.parentElement?.appendChild(statusEl);
    }
    statusEl.textContent = message;
    statusEl.style.display = 'block';
    if (statusTimer) clearTimeout(statusTimer);
    statusTimer = setTimeout(() => {
      statusEl.style.display = 'none';
      statusTimer = null;
    }, 3000);
  }

  function start() {
    recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    // Track what was in the textarea before we started, plus finalized speech
    let baseText = textarea.value;

    recognition.onresult = (event) => {
      // Got speech — reset silence timer
      resetSilenceTimer();

      let interim = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        } else {
          interim += transcript;
        }
      }

      if (finalTranscript) {
        const separator = baseText && !baseText.endsWith(' ') && !baseText.endsWith('\n') ? ' ' : '';
        baseText = baseText + separator + finalTranscript;
        textarea.value = baseText;
      }

      if (interim) {
        const separator = baseText && !baseText.endsWith(' ') && !baseText.endsWith('\n') ? ' ' : '';
        textarea.value = baseText + separator + interim;
      }
    };

    recognition.onerror = (event) => {
      logger_log('Speech recognition error:', event.error);
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        stop();
        showStatus('Microphone access denied — check browser permissions');
      } else if (event.error === 'no-speech') {
        // No speech detected, silence timer will handle this
      } else if (event.error !== 'aborted') {
        stop();
        showStatus('Voice input error — please try again');
      }
    };

    recognition.onend = () => {
      if (isListening) {
        try {
          recognition.start();
        } catch (e) {
          logger_log('Could not restart recognition:', e);
          stop();
          showStatus('Voice input stopped unexpectedly');
        }
      }
    };

    try {
      recognition.start();
      isListening = true;
      textarea.disabled = true;
      button.classList.add('listening');
      button.innerHTML = getStopIcon() + '<span class="storegen-voice-btn-label">Listening...</span>';
      button.title = 'Click to stop dictation';
      resetSilenceTimer();
    } catch (e) {
      logger_log('Failed to start speech recognition:', e);
      showStatus('Could not start voice input');
    }
  }

  function stop() {
    isListening = false;
    clearSilenceTimer();
    textarea.disabled = false;
    if (recognition) {
      recognition.onend = null;
      recognition.abort();
      recognition = null;
    }
    button.classList.remove('listening');
    button.innerHTML = getMicIcon(false) + '<span class="storegen-voice-btn-label">Voice input</span>';
    button.title = 'Click to dictate (speech-to-text)';
  }

  button.onclick = (e) => {
    e.preventDefault();
    if (isListening) {
      stop();
    } else {
      start();
    }
  };

  // Expose stop so the modal can clean up on close
  button._stopListening = stop;

  return button;
}

/**
 * Returns an SVG mic icon
 * @param {boolean} active - Whether mic is currently active
 * @returns {string} SVG markup
 */
function getMicIcon(active) {
  const color = active ? '#d13212' : '#6c757d';
  return `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
    <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
    <line x1="12" y1="19" x2="12" y2="23"/>
    <line x1="8" y1="23" x2="16" y2="23"/>
  </svg>`;
}

/**
 * Returns an SVG stop icon for the listening state
 * @returns {string} SVG markup
 */
function getStopIcon() {
  return `<svg width="12" height="12" viewBox="0 0 24 24" fill="white" stroke="none">
    <rect x="4" y="4" width="16" height="16" rx="2"/>
  </svg>`;
}

;// ./src/features/crux/crux-homepage/instructionsModal.js
// Instructions modal component for package home CodeGen







// Re-export for backwards compatibility (urlSection.js and urlSectionUi.js import from here)


/**
 * Detects if Asana is in dark mode
 * Checks for Asana's theme classes on the body element
 * @returns {boolean} True if dark mode is active
 */
function detectAsanaDarkMode() {
  const body = document.body;
  
  // Check for Asana's dark mode classes
  const hasDarkClass = body.classList.contains('DesignTokenThemeSelectors-theme--darkMode');
  const hasSystemDarkClass = body.classList.contains('DesignTokenThemeSelectors-theme--systemDarkMode');
  
  const isDark = hasDarkClass || hasSystemDarkClass;
  
  // Log for debugging
  logger_log('[StoreGen] Dark mode detection:', {
    isDark,
    hasDarkClass,
    hasSystemDarkClass,
    bodyClasses: body.className.split(' ').filter(c => c.includes('Theme')).join(', ')
  });
  
  return isDark;
}

/**
 * Creates an instructions modal for CodeGen job submission
 * @param {string} packageName - Name of the package
 * @param {string|null} currentFilePath - Current file path if viewing a file
 * @param {Function} onSubmit - Callback when instructions are submitted (instructions, includeFileContext, referenceLinks)
 * @param {Function} onCancel - Callback when modal is cancelled
 * @param {string|null} initialPrompt - Optional initial prompt to prefill the textarea
 * @returns {HTMLElement} Modal overlay element
 */
function createInstructionsModal(packageName, currentFilePath, onSubmit, onCancel, initialPrompt = null) {
  const overlay = document.createElement('div');
  overlay.className = 'storegen-modal-overlay';
  
  const modal = document.createElement('div');
  modal.className = 'storegen-modal';
  
  // Detect and apply dark mode if needed
  if (detectAsanaDarkMode()) {
    modal.classList.add('storegen-modal--dark');
    logger_log('[StoreGen] Applied dark mode class to modal');
  }
  
  // Build file context section if viewing a file
  const fileContextSection = currentFilePath ? `
    <div class="storegen-modal-file-context">
      <label>
        <input type="checkbox" id="storegen-include-file" checked />
        Include current file context
      </label>
      <div class="storegen-file-path">
        User is viewing file: <code>${escapeHtml(currentFilePath)}</code>
      </div>
    </div>
  ` : '';
  
  // Set package-specific placeholder text and default value
  const placeholderText = packageName === 'CodeGenGuestBook' 
    ? 'Add my name to the guestbook entries'
    : 'Describe the changes you want CodeGen to make...';
  
  // Determine the default value for the textarea
  // Priority: initialPrompt > CodeGenGuestBook special case > empty
  let defaultValue = '';
  if (initialPrompt) {
    // Use the provided initial prompt (e.g., from query string)
    defaultValue = initialPrompt;
  } else if (packageName === 'CodeGenGuestBook') {
    // Get current user alias for CodeGenGuestBook
    const userAlias = getCurrentUserAlias();
    defaultValue = userAlias 
      ? `Add my name ${userAlias} to the guestbook entries`
      : 'Add my name to the guestbook entries';
  }
  
  modal.innerHTML = `
    <div class="storegen-modal-header">
      <h3>Generate Code Review for ${escapeHtml(packageName)}</h3>
      <button class="storegen-modal-close">×</button>
    </div>
    <div class="storegen-modal-body">
      <label for="storegen-instructions"><strong>Instructions:</strong></label>
      <textarea 
        id="storegen-instructions" 
        placeholder="${placeholderText}"
        rows="8"
      ></textarea>
      ${fileContextSection}
      ${createUrlSectionHtml()}
      <div class="storegen-modal-message" style="display: none;"></div>
    </div>
    <div class="storegen-modal-footer">
      <a href="#" class="storegen-url-toggle-link">▶ Attach references (optional)</a>
      <div class="storegen-modal-footer-buttons">
        <button class="storegen-modal-cancel">Cancel</button>
        <button class="storegen-modal-submit">Generate CR</button>
      </div>
    </div>
  `;
  
  // Set textarea value programmatically to prevent XSS injection
  // This avoids HTML injection through the defaultValue which may come from URL parameters
  const instructionsTextarea = modal.querySelector('#storegen-instructions');
  if (instructionsTextarea && defaultValue) {
    instructionsTextarea.value = defaultValue;
  }

  // Add voice input button below textarea if speech is supported
  const voiceBtn = createVoiceInputButton(instructionsTextarea);
  if (voiceBtn) {
    const voiceRow = document.createElement('div');
    voiceRow.className = 'storegen-voice-row';
    voiceRow.appendChild(voiceBtn);

    // Insert the voice row right after the textarea
    instructionsTextarea.parentNode.insertBefore(voiceRow, instructionsTextarea.nextSibling);
  }
  
  overlay.appendChild(modal);
  
  // Add pulse animation to submit button for CodeGenGuestBook
  if (packageName === 'CodeGenGuestBook') {
    const submitBtn = modal.querySelector('.storegen-modal-submit');
    if (submitBtn) {
      submitBtn.classList.add('attention-pulse');
    }
  }
  
  // Event handlers
  const closeBtn = modal.querySelector('.storegen-modal-close');
  const cancelBtn = modal.querySelector('.storegen-modal-cancel');
  const submitBtn = modal.querySelector('.storegen-modal-submit');
  const textarea = modal.querySelector('#storegen-instructions');
  
  closeBtn.onclick = () => {
    closeModal(overlay);
    if (onCancel) onCancel();
  };
  
  cancelBtn.onclick = () => {
    closeModal(overlay);
    if (onCancel) onCancel();
  };
  
  overlay.onclick = (e) => {
    if (e.target === overlay) {
      closeModal(overlay);
      if (onCancel) onCancel();
    }
  };
  
  submitBtn.onclick = () => {
    const instructions = textarea.value.trim();
    if (!instructions) {
      showError(overlay, 'Please enter instructions');
      return;
    }

    // Trigger confetti celebration for CodeGenGuestBook
    if (packageName === 'CodeGenGuestBook') {
      createConfetti();
    }

    // Check if file context should be included
    const includeFileCheckbox = modal.querySelector('#storegen-include-file');
    const includeFileContext = includeFileCheckbox ? includeFileCheckbox.checked : false;

    // Get URL references as array (empty array if none)
    const referenceLinks = getUrlContentsArray();

    onSubmit(instructions, includeFileContext, referenceLinks);
  };
  
  // Toggle file path visibility when checkbox changes
  const includeFileCheckbox = modal.querySelector('#storegen-include-file');
  const filePathDiv = modal.querySelector('.storegen-file-path');
  if (includeFileCheckbox && filePathDiv) {
    includeFileCheckbox.addEventListener('change', () => {
      filePathDiv.style.display = includeFileCheckbox.checked ? 'block' : 'none';
    });
  }

  // Toggle URL section visibility
  const urlToggleLink = modal.querySelector('.storegen-url-toggle-link');
  const urlSection = modal.querySelector('.storegen-url-section');
  if (urlToggleLink && urlSection) {
    urlToggleLink.addEventListener('click', (e) => {
      e.preventDefault();
      const isHidden = urlSection.style.display === 'none';
      urlSection.style.display = isHidden ? 'block' : 'none';
      urlToggleLink.textContent = isHidden ? '▼ Attach references (optional)' : '▶ Attach references (optional)';
    });
  }

  // Initialize URL section event handlers
  initUrlSection(overlay);

  return overlay;
}

/**
 * Opens the modal by appending it to the document body
 * @param {HTMLElement} modal - Modal overlay element
 */
function openModal(modal) {
  document.body.appendChild(modal);
  const textarea = modal.querySelector('#storegen-instructions');
  if (textarea) textarea.focus();
  
  // Stop the shake animation on the CodeGen button when modal opens
  const codegenButton = document.getElementById('storegen-codegen-button');
  if (codegenButton && codegenButton.classList.contains('attention-shake')) {
    codegenButton.classList.remove('attention-shake');
  }
}

/**
 * Closes the modal by removing it from the DOM
 * @param {HTMLElement} modal - Modal overlay element
 */
function closeModal(modal) {
  // Stop any active voice input
  const voiceBtn = modal.querySelector('.storegen-voice-btn');
  if (voiceBtn && voiceBtn._stopListening) {
    voiceBtn._stopListening();
  }

  // Clear URL contents when modal closes
  clearUrlContents();

  modal.remove();

  // Restart the shake animation on the CodeGen button when modal closes
  const codegenButton = document.getElementById('storegen-codegen-button');
  if (codegenButton && !codegenButton.classList.contains('attention-shake')) {
    // Check if this was a CodeGenGuestBook modal by looking for the pulse class on submit button
    const submitBtn = modal.querySelector('.storegen-modal-submit.attention-pulse');
    if (submitBtn) {
      codegenButton.classList.add('attention-shake');
    }
  }
}

/**
 * Displays an error message in the modal
 * @param {HTMLElement} modal - Modal overlay element
 * @param {string} message - Error message to display
 */
function showError(modal, message) {
  const messageDiv = modal.querySelector('.storegen-modal-message');
  messageDiv.textContent = message;
  messageDiv.className = 'storegen-modal-message storegen-modal-error';
  messageDiv.style.display = 'block';
}

/**
 * Displays an info message in the modal
 * @param {HTMLElement} modal - Modal overlay element
 * @param {string} message - Info message to display
 */
function showInfo(modal, message) {
  const messageDiv = modal.querySelector('.storegen-modal-message');
  messageDiv.textContent = message;
  messageDiv.className = 'storegen-modal-message storegen-modal-info';
  messageDiv.style.display = 'block';
}

/**
 * Sets the loading state of the modal
 * @param {HTMLElement} modal - Modal overlay element
 * @param {boolean} isLoading - Whether the modal is in loading state
 */
function setLoading(modal, isLoading) {
  const submitBtn = modal.querySelector('.storegen-modal-submit');
  submitBtn.disabled = isLoading;
  submitBtn.textContent = isLoading ? 'Submitting...' : 'Generate CR';
}

/**
 * Creates a confetti celebration effect
 * Spawns colorful confetti particles that fall from the top of the screen
 */
function createConfetti() {
  const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E2'];
  const confettiCount = 100;
  
  for (let i = 0; i < confettiCount; i++) {
    const confetti = document.createElement('div');
    confetti.className = 'storegen-confetti';
    confetti.style.left = Math.random() * 100 + 'vw';
    confetti.style.top = '-10px';
    confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
    confetti.style.animationDelay = Math.random() * 1 + 's';
    confetti.style.animationDuration = (Math.random() * 3 + 4) + 's';
    
    document.body.appendChild(confetti);
    
    // Remove confetti after animation completes
    setTimeout(() => {
      confetti.remove();
    }, 8000);
  }
}

;// ./src/features/crux/crux-homepage/specStudioChat.js
// Spec Studio Embedded Chat - FAB + iframe panel for package pages


const SPEC_STUDIO_CHAT_URL = 'https://specs.harmony.a2z.com/actions/chat';
const STORAGE_PREFIX = 'storegen_spec_chat_';
const GM_HIDDEN_KEY = 'spec_chat_hidden';
const SESSION_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

function getSessionKey(packageName) {
  return `${STORAGE_PREFIX}${packageName}`;
}

function getOpenKey(packageName) {
  return `${STORAGE_PREFIX}${packageName}_open`;
}

function loadSession(packageName) {
  let conversationId = null;
  const stored = localStorage.getItem(getSessionKey(packageName));
  if (stored) {
    try {
      const data = JSON.parse(stored);
      if (Date.now() - data.timestamp < SESSION_TTL_MS) {
        conversationId = data.conversationId;
      } else {
        localStorage.removeItem(getSessionKey(packageName));
      }
    } catch {
      localStorage.removeItem(getSessionKey(packageName));
    }
  }
  const open = localStorage.getItem(getOpenKey(packageName)) === '1';
  return { conversationId, open };
}

function saveSession(packageName, conversationId) {
  localStorage.setItem(getSessionKey(packageName), JSON.stringify({
    conversationId,
    timestamp: Date.now(),
  }));
}

function saveOpenState(packageName, open) {
  if (open) {
    localStorage.setItem(getOpenKey(packageName), '1');
  } else {
    localStorage.removeItem(getOpenKey(packageName));
  }
}

function cleanupStaleSessions() {
  for (let i = localStorage.length - 1; i >= 0; i--) {
    const key = localStorage.key(i);
    if (!key || !key.startsWith(STORAGE_PREFIX) || key.endsWith('_open')) continue;
    const stored = localStorage.getItem(key);
    if (!stored) continue;
    try {
      const data = JSON.parse(stored);
      if (Date.now() - data.timestamp >= SESSION_TTL_MS) {
        localStorage.removeItem(key);
        localStorage.removeItem(key + '_open');
      }
    } catch {
      localStorage.removeItem(key);
      localStorage.removeItem(key + '_open');
    }
  }
}

function buildIframeSrc(packageName, conversationId) {
  const params = new URLSearchParams({ 'nav-hidden': '1', package: packageName });
  if (conversationId) params.set('conversationId', conversationId);
  return `${SPEC_STUDIO_CHAT_URL}?${params}`;
}

/**
 * Registers a Tampermonkey menu command to toggle Spec Studio chat visibility.
 */
function registerSpecChatMenuCommand() {
  const hidden = GM_getValue(GM_HIDDEN_KEY, false);
  GM_registerMenuCommand(
    hidden ? 'Show Spec Studio Chat' : 'Hide Spec Studio Chat',
    () => {
      GM_setValue(GM_HIDDEN_KEY, !hidden);
      location.reload();
    }
  );
}

/**
 * Creates the Spec Studio chat panel and toggle button.
 * Restores previous chat session and open state from localStorage.
 * Listens for postMessage from the iframe to capture the conversation ID.
 * @param {string} packageName - Current package name
 * @returns {{ panel: HTMLElement, button: HTMLElement }}
 */
function createSpecStudioChat(packageName) {
  const session = loadSession(packageName);

  const panel = document.createElement('div');
  panel.id = 'spec-studio-chat-panel';
  panel.className = 'storegen-spec-chat-panel';
  panel.setAttribute('role', 'dialog');

  // Panel header with close button
  const header = document.createElement('div');
  header.className = 'storegen-spec-chat-header';

  const title = document.createElement('span');
  title.id = 'spec-studio-chat-title';
  title.textContent = 'Ask Spec Studio';
  panel.setAttribute('aria-labelledby', 'spec-studio-chat-title');

  const closeBtn = document.createElement('button');
  closeBtn.className = 'storegen-spec-chat-close';
  closeBtn.setAttribute('aria-label', 'Close Spec Studio chat');
  closeBtn.addEventListener('click', () => setOpen(false));
  const closeIcon = document.createElement('span');
  closeIcon.setAttribute('aria-hidden', 'true');
  closeIcon.textContent = '\u00d7';
  closeBtn.appendChild(closeIcon);

  header.appendChild(title);
  header.appendChild(closeBtn);
  panel.appendChild(header);

  // Close on Escape
  panel.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      setOpen(false);
    }
  });

  const disclaimer = document.createElement('div');
  disclaimer.className = 'storegen-spec-chat-disclaimer';
  disclaimer.textContent = 'AI can make mistakes. Use the thumbs up/thumbs down feature to help it get better.';

  let iframe = null;

  function ensureIframe() {
    if (iframe) return;
    iframe = document.createElement('iframe');
    iframe.src = buildIframeSrc(packageName, session.conversationId);
    iframe.className = 'storegen-spec-chat-iframe';
    iframe.setAttribute('title', `Spec Studio chat for ${packageName}`);
    panel.appendChild(iframe);
    panel.appendChild(disclaimer);
  }

  // Listen for conversation ID from the iframe
  const messageController = new AbortController();
  window.addEventListener('message', (event) => {
    if (!event.origin.endsWith('.a2z.com')) return;
    if (!event.data || typeof event.data !== 'object') return;
    if (event.data.type === 'conversationStarted' && event.data.conversationId) {
      logger_log('Received Spec Studio conversation ID:', event.data.conversationId);
      session.conversationId = event.data.conversationId;
      saveSession(packageName, event.data.conversationId);
    }
  }, { signal: messageController.signal });

  // FAB bar with button and dismiss
  const bar = document.createElement('div');
  bar.id = 'spec-studio-chat-button';
  bar.className = 'storegen-spec-chat-bar';
  bar.setAttribute('role', 'group');
  bar.setAttribute('aria-label', 'Spec Studio chat controls');

  const btn = document.createElement('button');
  btn.className = 'storegen-spec-chat-btn';
  btn.textContent = 'Ask Specs';
  btn.addEventListener('click', () => setOpen(true));

  const dismissBtn = document.createElement('button');
  dismissBtn.className = 'storegen-spec-chat-dismiss';
  dismissBtn.setAttribute('aria-label', 'Dismiss Spec Studio chat');
  const dismissIcon = document.createElement('span');
  dismissIcon.setAttribute('aria-hidden', 'true');
  dismissIcon.textContent = '\u00d7';
  dismissBtn.appendChild(dismissIcon);
  dismissBtn.addEventListener('click', () => {
    messageController.abort();
    panel.style.display = 'none';
    bar.style.display = 'none';
    saveOpenState(packageName, false);
    logger_log('Spec Studio chat dismissed');
  });

  bar.appendChild(btn);
  bar.appendChild(dismissBtn);

  function setOpen(open) {
    panel.style.display = open ? 'flex' : 'none';
    bar.style.display = open ? 'none' : '';
    saveOpenState(packageName, open);
    if (open) {
      ensureIframe();
      closeBtn.focus();
    } else {
      btn.focus();
    }
  }

  // Restore open state from previous session
  if (session.open) {
    setOpen(true);
  }

  return { panel, button: bar };
}

/**
 * Injects the Spec Studio chat panel and FAB into the page.
 * @param {string} packageName - Current package name
 */
function injectSpecStudioChat(packageName) {
  if (document.getElementById('spec-studio-chat-button')) return;
  // Skip injection in CodeTree sidebar iframe
  if (window.location.href.includes('#treeSidebar')) return;
  // Respect Tampermonkey menu toggle
  if (GM_getValue(GM_HIDDEN_KEY, false)) return;

  cleanupStaleSessions();

  const { panel, button } = createSpecStudioChat(packageName);
  document.body.appendChild(panel);
  document.body.appendChild(button);

  logger_log('Spec Studio chat injected for package:', packageName);
}

;// ./src/features/crux/crux-homepage/index.js
// Package Home CodeGen Feature - Main Entry Point










// Constants for polling configuration
const MAX_BADGE_CHECK_ATTEMPTS = 10;
const BADGE_CHECK_INTERVAL_MS = 200;
const INITIAL_BADGE_CHECK_DELAY_MS = 100;
const BUTTON_INSERT_RETRY_DELAY_MS = 500;

/**
 * Gets the codegenPrompt query string parameter if present
 * @returns {string|null} The prompt from query string, or null if not present
 */
function getCodegenPromptFromQueryString() {
  const urlParams = new URLSearchParams(window.location.search);
  const prompt = urlParams.get('codegenPrompt');
  return prompt ? decodeURIComponent(prompt) : null;
}

/**
 * Gets the storage key for a package's jobs list
 * @param {string} packageName - Package name
 * @returns {string} Storage key
 */
function getStorageKey(packageName) {
  return `storegen_package_home_${packageName}_jobs`;
}

/**
 * Gets the storage key for a specific job
 * @param {string} packageName - Package name
 * @param {string} jobId - Job ID
 * @returns {string} Storage key for the specific job
 */
function getJobStorageKey(packageName, jobId) {
  return `storegen_package_home_${packageName}_job_${jobId}`;
}

/**
 * Gets all active jobs for a package
 * @param {string} packageName - Package name
 * @returns {Array} Array of active job data objects
 */
function getActiveJobs(packageName) {
  const key = getStorageKey(packageName);
  const stored = localStorage.getItem(key);
  if (!stored) return [];
  
  try {
    const jobIds = JSON.parse(stored);
    const activeJobs = [];
    
    for (const jobId of jobIds) {
      const jobKey = getJobStorageKey(packageName, jobId);
      const jobData = localStorage.getItem(jobKey);
      if (jobData) {
        try {
          const data = JSON.parse(jobData);
          if (data.status === 'IN_PROGRESS') {
            activeJobs.push(data);
          }
        } catch (e) {
          logger_log("Error parsing job data:", e);
        }
      }
    }
    
    return activeJobs;
  } catch (e) {
    logger_log("Error getting active jobs:", e);
    return [];
  }
}

/**
 * Adds a job to the package's job list
 * @param {string} packageName - Package name
 * @param {string} jobId - Job ID
 * @param {Object} jobData - Job data to store
 */
function addJob(packageName, jobId, jobData) {
  // Store job data
  const jobKey = getJobStorageKey(packageName, jobId);
  localStorage.setItem(jobKey, JSON.stringify(jobData));
  
  // Add to jobs list
  const listKey = getStorageKey(packageName);
  const stored = localStorage.getItem(listKey);
  let jobIds = [];
  
  try {
    if (stored) {
      jobIds = JSON.parse(stored);
    }
  } catch (e) {
    logger_log("Error parsing job list:", e);
  }
  
  if (!jobIds.includes(jobId)) {
    jobIds.push(jobId);
    localStorage.setItem(listKey, JSON.stringify(jobIds));
  }
}

/**
 * Removes a job from the package's job list
 * @param {string} packageName - Package name
 * @param {string} jobId - Job ID
 */
function removeJob(packageName, jobId) {
  // Remove job data
  const jobKey = getJobStorageKey(packageName, jobId);
  localStorage.removeItem(jobKey);
  
  // Remove from jobs list
  const listKey = getStorageKey(packageName);
  const stored = localStorage.getItem(listKey);
  
  try {
    if (stored) {
      let jobIds = JSON.parse(stored);
      jobIds = jobIds.filter(id => id !== jobId);
      if (jobIds.length > 0) {
        localStorage.setItem(listKey, JSON.stringify(jobIds));
      } else {
        localStorage.removeItem(listKey);
      }
    }
  } catch (e) {
    logger_log("Error removing job from list:", e);
  }
}

/**
 * Submits a CodeGen job for package home
 * @param {string} packageName - Package name
 * @param {string} instructions - User instructions
 * @param {string|null} currentFilePath - Current file path if context should be included
 * @param {Array<{url: string, content: string}>} referenceLinks - URL references (empty array if none)
 * @param {Function} renderMarkdown - Markdown renderer
 * @param {HTMLElement} modal - Modal element to close on success
 * @param {boolean} shouldShowStatusCard - Whether to show status card in this frame
 */
function submitCodeGenJob(packageName, instructions, currentFilePath, referenceLinks, renderMarkdown, modal, shouldShowStatusCard) {
  // Format instructions with package name and optional file context
  let formattedInstructions = `Package name: ${packageName}`;
  
  if (currentFilePath) {
    formattedInstructions += `\nContext: User is viewing file ${currentFilePath}`;
  }
  
  formattedInstructions += `

Instructions:
${instructions}`;
  
  logger_log("Submitting job with instructions:", formattedInstructions);
  if (referenceLinks.length > 0) {
    logger_log("Reference links:", referenceLinks.length);
  }

  submitJobWithInstructions(
    formattedInstructions,
    (jobId, jobUrl) => {
      logger_log("Job submitted successfully:", jobId);
      
      // Store job info using new multi-job storage
      const jobData = {
        jobId,
        jobUrl,
        timestamp: Date.now(),
        status: 'IN_PROGRESS'
      };
      addJob(packageName, jobId, jobData);
      
      if (shouldShowStatusCard) {
        const jobStorageKey = getJobStorageKey(packageName, jobId);
        createJobBanner(
          jobId,
          jobUrl,
          jobStorageKey,
          renderMarkdown,
          () => {
            logger_log("Status card closed for job:", jobId);
            removeJob(packageName, jobId);
          },
          "Creating a Code Review",
          true
        );
      }
      
      // Close modal after status card is created
      closeModal(modal);
    },
    (errorMessage) => {
      logger_log("Job submission failed:", errorMessage);
      setLoading(modal, false);
      showError(modal, `Failed to submit job: ${errorMessage}`);
    },
    "browserextension-homepage",
    referenceLinks
  );
}

/**
 * Initializes the CodeGen integration for package home pages
 * Adds CodeGen button to navigation bar
 * @param {Function} renderMarkdown - Function to render markdown to HTML
 */
function initCruxHome(renderMarkdown) {
  // Simple guard to prevent multiple initializations in same execution context
  if (window.__storegenCruxHomeInitialized) {
    return; // Silent return, no logging
  }
  window.__storegenCruxHomeInitialized = true;

  // Inject styles once
  injectStyles();

  // Extract package name
  const packageName = getPackageName();
  if (!packageName) {
    logger_log("Could not extract package name, skipping initialization");
    return;
  }

  logger_log(`Initializing CodeGen for ${packageName}`);

  // Poll for badge to appear
  let checkAttempts = 0;
  
  const checkForBadge = () => {
    checkAttempts++;
    
    if (isPackagePublic()) {
      logger_log(`Package is public (found on attempt ${checkAttempts})`);
      initializeFeature(packageName, renderMarkdown);
      return;
    }
    
    // If we've checked enough times and still no public badge, assume private
    if (checkAttempts >= MAX_BADGE_CHECK_ATTEMPTS) {
      logger_log("Max attempts reached, package is private or badge not found");
      return;
    }
    
    // Log progress on later attempts
    if (checkAttempts >= 4) {
      logger_log(`Checking package visibility (attempt ${checkAttempts})`);
    }
    
    // Try again
    setTimeout(checkForBadge, BADGE_CHECK_INTERVAL_MS);
  };
  
  // Start checking
  setTimeout(checkForBadge, INITIAL_BADGE_CHECK_DELAY_MS);
}

/**
 * Initializes the feature after public/private check passes
 * Sets up status card restoration and button insertion
 * @param {string} packageName - Package name
 * @param {Function} renderMarkdown - Markdown renderer
 */
function initializeFeature(packageName, renderMarkdown) {
  // Only show status cards in one frame when Code Tree is active
  // Code Tree creates multiple iframes - we only want the main content one
  // Tree sidebar has #treeSidebar in URL
  const isTreeSidebar = window.location.hash === '#treeSidebar' || window.location.href.includes('#treeSidebar');
  const shouldShowStatusCard = !isTreeSidebar;
  
  // Check for active jobs and restore status cards (only in main content frame)
  if (shouldShowStatusCard) {
    const activeJobs = getActiveJobs(packageName);
    if (activeJobs.length > 0) {
      logger_log(`Restoring ${activeJobs.length} active job(s)`);
      for (const jobData of activeJobs) {
        const jobStorageKey = getJobStorageKey(packageName, jobData.jobId);
        logger_log("Restoring active job:", jobData.jobId);
        const restoredJobUrl = sanitizeUrl(jobData.jobUrl || jobData.viewLogsUrl);
        createJobBanner(
          jobData.jobId,
          restoredJobUrl,
          jobStorageKey,
          renderMarkdown,
          () => {
            removeJob(packageName, jobData.jobId);
          },
          "Creating a Code Review",
          true
        );
      }
    }
  }

  // Check for codegenPrompt query string parameter
  const queryStringPrompt = getCodegenPromptFromQueryString();
  if (queryStringPrompt) {
    logger_log("Found codegenPrompt in query string:", queryStringPrompt);
  }

  /**
   * Creates and opens the instructions modal
   * @param {string|null} initialPrompt - Optional initial prompt to prefill
   */
  const openInstructionsModal = (initialPrompt = null) => {
    // Get current file path if viewing a file
    const currentFilePath = getCurrentFilePath();
    if (currentFilePath) {
      logger_log("Detected current file:", currentFilePath);
    }
    
    // Create and open modal with optional initial prompt
    const modal = createInstructionsModal(
      packageName,
      currentFilePath,
      (instructions, includeFileContext, referenceLinks) => {
        logger_log("Instructions submitted:", instructions);
        logger_log("Include file context:", includeFileContext);
        logger_log("Reference links count:", referenceLinks.length);

        // Multiple jobs are now supported - no need to check for active jobs
        setLoading(modal, true);

        // Only pass file path if checkbox was checked
        const filePathToInclude = includeFileContext ? currentFilePath : null;
        submitCodeGenJob(packageName, instructions, filePathToInclude, referenceLinks, renderMarkdown, modal, shouldShowStatusCard);
      },
      () => {
        logger_log("Modal cancelled");
      },
      initialPrompt
    );
    
    openModal(modal);
  };

  // Wait a bit for navigation bar to load, then insert button
  const tryInsertButton = () => {
    // Check if button already exists
    if (document.getElementById('storegen-codegen-button')) {
      return;
    }

    // Create CodeGen button
    const button = createCodeGenButton(packageName, () => {
      logger_log("CodeGen button clicked for package:", packageName);
      openInstructionsModal();
    });

    // Insert button into navigation bar
    const inserted = insertCodeGenButton(button);
    if (inserted) {
      logger_log("CodeGen button inserted successfully");
      
      // Auto-open modal if codegenPrompt query string is present
      if (queryStringPrompt) {
        logger_log("Auto-opening modal with query string prompt");
        openInstructionsModal(queryStringPrompt);
      }
    }
  };

  // Try immediately
  tryInsertButton();

  // Also try after a short delay in case nav bar loads late
  setTimeout(tryInsertButton, BUTTON_INSERT_RETRY_DELAY_MS);

  // Inject Spec Studio chat FAB and menu command
  registerSpecChatMenuCommand();
  injectSpecStudioChat(packageName);
}

;// ./src/features/sim/sim-issue/codegenButton.js
// CodeGen button component for SIM issue page



/**
 * Creates a CodeGen button for the SIM issue page action bar
 * @param {string} issueId - ID of the issue
 * @param {Function} onClick - Callback when button is clicked
 * @returns {HTMLElement} Button element
 */
function codegenButton_createCodeGenButton(issueId, onClick) {
  const button = document.createElement('button');
  button.id = 'storegen-codegen-button';
  button.className = 'storegen-package-header-button';
  
  // Create logo
  const logo = logo_createStoreGenLogo();
  logo.style.width = '16px';
  logo.style.height = '16px';
  logo.style.marginRight = '5px';
  logo.style.flexShrink = '0';
  
  // Create text
  const text = document.createElement('span');
  text.textContent = 'Generate Code';
  text.style.fontSize = '13px';
  text.style.lineHeight = '1';
  
  button.appendChild(logo);
  button.appendChild(text);
  
  button.onclick = (e) => {
    e.preventDefault();
    onClick();
  };
  
  return button;
}

/**
 * Inserts the CodeGen button next to the Resolve button in the action bar
 * @param {HTMLElement} button - The button element to insert
 * @returns {boolean} True if insertion succeeded
 */
function codegenButton_insertCodeGenButton(button) {
  // Try multiple selectors to find the Resolve button
  const selectors = [
    'button[data-testid="resolve-button"]',
    'button:contains("Resolve")',
    'button[aria-label*="Resolve"]',
    '.awsui-button:contains("Resolve")',
    '[class*="resolve" i] button',
    '[class*="action" i] button:first-of-type'
  ];
  
  let resolveButton = null;
  for (const selector of selectors) {
    try {
      // For :contains selector, we need to manually search
      if (selector.includes(':contains')) {
        const buttons = document.querySelectorAll('button');
        for (const btn of buttons) {
          if (btn.textContent.includes('Resolve')) {
            resolveButton = btn;
            break;
          }
        }
      } else {
        resolveButton = document.querySelector(selector);
      }
      
      if (resolveButton) {
        break;
      }
    } catch (e) {
      // Selector might not be valid, continue
    }
  }
  
  if (!resolveButton) {
    const actionBar = document.querySelector('[class*="action" i], [class*="header" i] [class*="button" i]');
    if (actionBar) {
      actionBar.appendChild(button);
      return true;
    }
    return false;
  }
  
  resolveButton.parentNode.insertBefore(button, resolveButton);
  return true;
}

/**
 * Removes the CodeGen button from the page
 */
function codegenButton_removeCodeGenButton() {
  const button = document.getElementById('storegen-codegen-button');
  if (button) {
    button.remove();
  }
}

;// ./src/features/sim/sim-issue/instructionsModal.js
// Instructions modal component for SIM issue CodeGen





/**
 * Creates an instructions modal for CodeGen job submission on SIM
 * @param {string} issueId - ID of the issue
 * @param {string} defaultInstructions - Default instructions to populate (e.g., issue description)
 * @param {Function} onSubmit - Callback when submitted (packageNames, simUrl, referenceLinks)
 * @param {Function} onCancel - Callback when modal is cancelled
 * @param {string[]} scrapedLinks - URLs scraped from the SIM page to auto-load
 * @returns {HTMLElement} Modal overlay element
 */
function instructionsModal_createInstructionsModal(issueId, defaultInstructions, onSubmit, onCancel, scrapedLinks = []) {
  // Try to detect package name from the issue description
  const detectedPackage = detectPackageName(issueId, defaultInstructions);
  
  // Get the current SIM URL
  const simUrl = window.location.href;
  
  const overlay = document.createElement('div');
  overlay.className = 'storegen-modal-overlay';
  
  const modal = document.createElement('div');
  modal.className = 'storegen-modal';
  
  // Build URL section HTML
  const urlSectionHtml = createUrlSectionHtml();
  
  modal.innerHTML = `
    <div class="storegen-modal-header">
      <h3>Generate Code for Issue ${escapeHtml(issueId)}</h3>
      <button class="storegen-modal-close">×</button>
    </div>
    <div class="storegen-modal-body">
      <label for="storegen-package-name">
        <strong>Package Name(s):</strong> 
        <span style="color: #d13212; font-weight: bold;">*</span>
        <span style="color: #666; font-weight: normal; font-size: 12px;">(comma-separated)</span>
      </label>
      <input 
        type="text"
        id="storegen-package-name" 
        placeholder="e.g., MyPackage or MyPackage1, MyPackage2"
        value="${escapeHtml(detectedPackage || '')}"
        required
      />
      <label for="storegen-sim-url">
        <strong>SIM:</strong>
      </label>
      <input 
        type="text"
        id="storegen-sim-url" 
        value="${escapeHtml(simUrl)}"
        readonly
        style="background: #f5f5f5 !important; color: #555 !important; cursor: not-allowed !important;"
      />
      ${urlSectionHtml}
    </div>
    <div class="storegen-modal-footer">
      <a href="#" class="storegen-url-toggle-link">▶ Attach references (optional)</a>
      <div class="storegen-modal-footer-buttons">
        <button class="storegen-modal-cancel">Cancel</button>
        <button class="storegen-modal-submit">Generate CR</button>
      </div>
    </div>
  `;
  
  overlay.appendChild(modal);
  
  // Initialize URL section
  initUrlSection(overlay);
  
  // Toggle URL section visibility
  const urlToggleLink = modal.querySelector('.storegen-url-toggle-link');
  const urlSection = modal.querySelector('.storegen-url-section');
  if (urlToggleLink && urlSection) {
    // Auto-expand if there are scraped links
    if (scrapedLinks.length > 0) {
      urlSection.style.display = 'block';
      urlToggleLink.textContent = '▼ Attach references (optional)';
    }
    
    urlToggleLink.addEventListener('click', (e) => {
      e.preventDefault();
      const isHidden = urlSection.style.display === 'none';
      urlSection.style.display = isHidden ? 'block' : 'none';
      urlToggleLink.textContent = isHidden ? '▼ Attach references (optional)' : '▶ Attach references (optional)';
    });
  }
  
  // Auto-load scraped links
  if (scrapedLinks.length > 0) {
    scrapedLinks.forEach(url => {
      addUrlProgrammatically(overlay, url);
    });
  }
  
  // Event handlers
  const closeBtn = modal.querySelector('.storegen-modal-close');
  const cancelBtn = modal.querySelector('.storegen-modal-cancel');
  const submitBtn = modal.querySelector('.storegen-modal-submit');
  const packageNameInput = modal.querySelector('#storegen-package-name');
  
  const cleanup = () => {
    clearUrlContents();
    instructionsModal_closeModal(overlay);
  };
  
  closeBtn.onclick = () => {
    cleanup();
    if (onCancel) onCancel();
  };
  
  cancelBtn.onclick = () => {
    cleanup();
    if (onCancel) onCancel();
  };
  
  overlay.onclick = (e) => {
    if (e.target === overlay) {
      cleanup();
      if (onCancel) onCancel();
    }
  };
  
  submitBtn.onclick = () => {
    const packageName = packageNameInput.value.trim();
    
    if (!packageName) {
      instructionsModal_showError(overlay, 'Package name is required');
      packageNameInput.focus();
      return;
    }
    
    const referenceLinks = getUrlContentsArray();
    onSubmit([packageName], simUrl, referenceLinks);
  };
  
  return overlay;
}

/**
 * Attempts to detect package name(s) from issue description
 * Handles various formats: "Package:", "Packages:", "Package name:", "PackageName:", etc.
 * @param {string} issueId - The issue ID (unused, kept for API compatibility)
 * @param {string} description - The issue description
 * @returns {string|null} Detected package name(s) or null
 */
function detectPackageName(issueId, description) {
  if (!description) {
    return null;
  }
  
  // Flexible pattern to handle all variations:
  // - "Package", "Packages", "PackageName", "PackageNames" (case-insensitive)
  // - Optional spaces around separator
  // - Separator can be ":", "-", or nothing
  // - Captures until newline, period, or sentence break
  const pattern = /packages?(?:\s*names?)?\s*[:\-]?\s*([A-Za-z0-9,\s._-]+?)(?:\n|\.(?:\s)|\s+-\s+|$)/i;
  
  const match = description.match(pattern);
  if (match) {
    // Return the captured package name(s), trimmed and stripped of trailing punctuation
    return match[1].trim().replace(/[.,;:]+$/, '');
  }
  
  // No explicit package declaration found - leave empty
  return null;
}

/**
 * Opens the modal by appending it to the document body
 * @param {HTMLElement} modal - Modal overlay element
 */
function instructionsModal_openModal(modal) {
  document.body.appendChild(modal);
  const packageNameInput = modal.querySelector('#storegen-package-name');
  if (packageNameInput) {
    packageNameInput.focus();
  }
}

/**
 * Closes the modal by removing it from the DOM
 * @param {HTMLElement} modal - Modal overlay element
 */
function instructionsModal_closeModal(modal) {
  modal.remove();
}

/**
 * Displays an error message in the modal
 * @param {HTMLElement} modal - Modal overlay element
 * @param {string} message - Error message to display
 */
function instructionsModal_showError(modal, message) {
  let messageDiv = modal.querySelector('.storegen-modal-message');
  if (!messageDiv) {
    messageDiv = document.createElement('div');
    messageDiv.className = 'storegen-modal-message';
    const modalBody = modal.querySelector('.storegen-modal-body');
    modalBody.appendChild(messageDiv);
  }
  messageDiv.textContent = message;
  messageDiv.className = 'storegen-modal-message storegen-modal-error';
  messageDiv.style.display = 'block';
}

/**
 * Displays an info message in the modal
 * @param {HTMLElement} modal - Modal overlay element
 * @param {string} message - Info message to display
 */
function instructionsModal_showInfo(modal, message) {
  let messageDiv = modal.querySelector('.storegen-modal-message');
  if (!messageDiv) {
    messageDiv = document.createElement('div');
    messageDiv.className = 'storegen-modal-message';
    const modalBody = modal.querySelector('.storegen-modal-body');
    modalBody.appendChild(messageDiv);
  }
  messageDiv.textContent = message;
  messageDiv.className = 'storegen-modal-message storegen-modal-info';
  messageDiv.style.display = 'block';
}

/**
 * Sets the loading state of the modal
 * @param {HTMLElement} modal - Modal overlay element
 * @param {boolean} isLoading - Whether the modal is in loading state
 */
function instructionsModal_setLoading(modal, isLoading) {
  const submitBtn = modal.querySelector('.storegen-modal-submit');
  submitBtn.disabled = isLoading;
  submitBtn.textContent = isLoading ? 'Submitting...' : 'Generate Code';
}

;// ./src/core/jobsSearch.js
// Job search/list endpoints. Split out from core/api.js so the AutoSDE
// userscript bundle (which doesn't call these) doesn't carry them as dead
// code. Webpack tree-shaking is module-level for our setup, so anything
// exported from a module the entry imports gets bundled even if unused;
// keeping these in their own module makes them tree-shakable at file
// granularity instead.



/**
 * Fetches jobs by tag from the API
 * @param {string} tag - Tag to filter by
 * @param {number} limit - Max results (default 1)
 * @param {Function} onSuccess - Callback with jobs array
 * @param {Function} onError - Callback with error message
 */
function fetchJobsByTag(tag, limit, onSuccess, onError) {
  const url = `${JOBS_ENDPOINT}?tag=${encodeURIComponent(tag)}&limit=${limit}`;
  logger_log('Fetching jobs by tag:', tag);

  GM_xmlhttpRequest({
    method: "GET",
    url: url,
    withCredentials: true,
    onload: function (response) {
      try {
        const data = JSON.parse(response.responseText);
        logger_log('Jobs response:', data);
        onSuccess(data.jobs || []);
      } catch (e) {
        logger_log('Error parsing jobs response:', e);
        onError('Failed to parse jobs response');
      }
    },
    onerror: function (error) {
      logger_log('Error fetching jobs:', error);
      onError('Network error fetching jobs');
    },
  });
}

/**
 * Fetches child jobs for a given parent job ID
 * @param {string} jobId - Parent job ID
 * @param {Function} onSuccess - Callback with children array
 * @param {Function} onError - Callback with error message
 */
function fetchJobChildren(jobId, onSuccess, onError) {
  const url = `${JOB_ENDPOINT(jobId)}/children`;
  logger_log('Fetching job children for:', jobId);

  GM_xmlhttpRequest({
    method: "GET",
    url: url,
    withCredentials: true,
    onload: function (response) {
      try {
        const data = JSON.parse(response.responseText);
        logger_log('Children response:', data);
        onSuccess(data.children || []);
      } catch (e) {
        logger_log('Error parsing children response:', e);
        onError('Failed to parse children response');
      }
    },
    onerror: function (error) {
      logger_log('Error fetching children:', error);
      onError('Network error fetching children');
    },
  });
}

;// ./src/ui/components/simTaskeiStatusCard.js
// Status card component for displaying CodeGen job status






/**
 * Makes an element draggable by a handle.
 * Converts bottom/right positioning to top/left on first drag.
 * Clamps position to viewport bounds.
 * Uses a 5px threshold to distinguish drag from click.
 * @param {HTMLElement} element - The element to make draggable
 * @param {HTMLElement} handle - The drag handle element
 */
function simTaskeiStatusCard_makeDraggable(element, handle) {
  let startX, startY, startLeft, startTop, isDragging = false;
  let activeCleanup = null;

  const onMouseDown = (e) => {
    // Don't drag if clicking on buttons, links, or inputs
    if (e.target.closest('button, a, input')) return;

    e.preventDefault(); // Prevent text selection during drag

    const rect = element.getBoundingClientRect();
    startX = e.clientX;
    startY = e.clientY;
    startLeft = rect.left;
    startTop = rect.top;
    isDragging = false;

    const onMouseMove = (e) => {
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;

      if (!isDragging && Math.abs(dx) < 5 && Math.abs(dy) < 5) return;

      if (!isDragging) {
        isDragging = true;
        element.classList.add('storegen-dragging');
        // Convert to top/left positioning only when actual drag starts
        element.style.top = startTop + 'px';
        element.style.left = startLeft + 'px';
        element.style.bottom = 'auto';
        element.style.right = 'auto';
      }

      const elRect = element.getBoundingClientRect();
      let newLeft = startLeft + dx;
      let newTop = startTop + dy;

      // Clamp to viewport
      newLeft = Math.max(0, Math.min(newLeft, window.innerWidth - elRect.width));
      newTop = Math.max(0, Math.min(newTop, window.innerHeight - elRect.height));

      element.style.left = newLeft + 'px';
      element.style.top = newTop + 'px';
    };

    const onMouseUp = () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
      element.classList.remove('storegen-dragging');
      activeCleanup = null;
    };

    activeCleanup = () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  };

  handle.addEventListener('mousedown', onMouseDown);

  // When expanded, reposition so content doesn't overflow below viewport
  const observer = new MutationObserver(() => {
    // Only adjust if using top/left positioning (i.e. has been dragged)
    if (element.style.top === '' || element.style.bottom !== 'auto') return;
    // Wait for CSS max-height transition to finish (0.3s in styles)
    setTimeout(() => {
      const rect = element.getBoundingClientRect();
      if (rect.bottom > window.innerHeight) {
        const newTop = Math.max(0, window.innerHeight - rect.height);
        element.style.top = newTop + 'px';
      }
    }, 350);
  });
  observer.observe(element, { subtree: true, attributeFilter: ['class'] });

  // Return cleanup function to remove all listeners
  return () => {
    handle.removeEventListener('mousedown', onMouseDown);
    if (activeCleanup) activeCleanup();
    observer.disconnect();
  };
}

/**
 * Creates and displays a status card for a CodeGen job
 * Starts polling for job status and updates the card accordingly
 * @param {string} jobId - The CodeGen job ID to track
 * @param {string} jobUrl - The Harmony job dashboard URL from API response
 * @param {string} codeReviewKey - Unique key for this CR+revision
 * @param {Function} renderMarkdown - Function to render markdown to HTML
 * @param {Function} onClose - Callback when status card is closed
 * @param {string} workingTitle - Title to show while job is in progress (default: "Working...")
 * @param {boolean} allowCancel - Whether to show cancel button (default: false)
 * @returns {HTMLElement} The status card element
 */
function simTaskeiStatusCard_createJobBanner(
  jobId,
  jobUrl,
  codeReviewKey,
  renderMarkdown,
  onClose,
  workingTitle = "Working...",
  allowCancel = false,
) {
  logger_log("Creating status card for job:", jobId);

  // Create status card
  const statusCard = document.createElement("div");
  statusCard.className = "storegen-status-card working";

  // Create logo
  const logo = logo_createStoreGenLogo();

  // Create header
  const header = document.createElement("div");
  header.className = "storegen-status-header";

  const title = document.createElement("div");
  title.className = "storegen-status-title";
  title.textContent = workingTitle;

  const closeBtn = document.createElement("button");
  closeBtn.className = "storegen-status-close";
  closeBtn.innerHTML = "×";
  closeBtn.onclick = () => {
    logger_log("User dismissed status card for job:", jobId);
    cleanupDrag();
    statusCard.classList.add("hidden");
    setTimeout(() => statusCard.remove(), config_STATUS_CARD_REMOVE_DELAY_MS);
    clearStoredJob(codeReviewKey);

    // Re-enable checkboxes
    document
      .querySelectorAll('.storegen-checkbox-banner input[type="checkbox"]')
      .forEach((cb) => {
        cb.disabled = false;
      });

    // Call onClose callback
    if (onClose) onClose();
  };

  header.appendChild(logo);
  header.appendChild(title);
  header.appendChild(closeBtn);

  // Create scrollable content wrapper
  const content = document.createElement("div");
  content.className = "storegen-status-content";

  // Create body
  const body = document.createElement("div");
  body.className = "storegen-status-body";
  body.textContent = `Job ID: ${jobId}`;

  // Create job link
  const logsLink = document.createElement("a");
  logsLink.className = "storegen-status-link";
  logsLink.textContent = "View job";
  logsLink.onclick = (e) => {
    e.stopPropagation();
    GM_openInTab(jobUrl, { active: true });
  };

  const cancelBtn = document.createElement("button");
  cancelBtn.className = "storegen-status-cancel";
  cancelBtn.textContent = "Cancel";
  if (!allowCancel) {
    cancelBtn.style.display = "none";
  }

  content.appendChild(body);
  content.appendChild(logsLink);
  content.appendChild(cancelBtn);

  statusCard.appendChild(header);
  statusCard.appendChild(content);
  const cleanupDrag = simTaskeiStatusCard_makeDraggable(statusCard, header);

  document.body.appendChild(statusCard);

  logger_log("Starting job polling for:", jobId);
  const pollController = pollJobStatus(
    jobId,
    (status, data) => {
      if (status === "IN_PROGRESS") {
        title.textContent = workingTitle;
      }
    },
    (finalOutput, data) => {
      statusCard.className = "storegen-status-card completed";
      title.textContent = "Completed";
      body.innerHTML =
        renderMarkdown(finalOutput) || "Job completed successfully";
      closeBtn.classList.add("visible");
      cancelBtn.style.display = "none";

      const stored = localStorage.getItem(codeReviewKey);
      if (stored) {
        try {
          const jobData = JSON.parse(stored);
          jobData.status = 'COMPLETED';
          localStorage.setItem(codeReviewKey, JSON.stringify(jobData));
          logger_log("Updated job status to COMPLETED in localStorage");
        } catch (e) {
          logger_log("Error updating job status:", e);
        }
      }

      saveJobToHistory(codeReviewKey, {
        jobId: jobId,
        status: "COMPLETED",
        finalOutput: finalOutput,
        timestamp: Date.now(),
        commentIds: Object.keys(getStoredState(codeReviewKey)),
        jobUrl: jobUrl,
        viewLogsUrl: jobUrl,
      });
    },
    (finalOutput, data) => {
      statusCard.className = "storegen-status-card failed";
      title.textContent = "Failed";
      body.innerHTML =
        renderMarkdown(finalOutput) || "Job failed. Check logs for details.";
      closeBtn.classList.add("visible");
      cancelBtn.style.display = "none";

      const stored = localStorage.getItem(codeReviewKey);
      if (stored) {
        try {
          const jobData = JSON.parse(stored);
          jobData.status = 'FAILED';
          localStorage.setItem(codeReviewKey, JSON.stringify(jobData));
          logger_log("Updated job status to FAILED in localStorage");
        } catch (e) {
          logger_log("Error updating job status:", e);
        }
      }

      saveJobToHistory(codeReviewKey, {
        jobId: jobId,
        status: "FAILED",
        finalOutput: finalOutput,
        timestamp: Date.now(),
        commentIds: Object.keys(getStoredState(codeReviewKey)),
        jobUrl: jobUrl,
        viewLogsUrl: jobUrl,
      });
    },
    () => {
      statusCard.className = "storegen-status-card failed";
      title.textContent = "Job timed out";
      body.textContent = "The job exceeded the maximum wait time.";
      closeBtn.classList.add("visible");
      cancelBtn.style.display = "none";
    },
    (error) => {
      statusCard.className = "storegen-status-card failed";
      title.textContent = "Error";
      body.textContent = "Failed to check job status";
      closeBtn.classList.add("visible");
      cancelBtn.style.display = "none";
    },
  );

  cancelBtn.onclick = () => {
    logger_log("User cancelled job:", jobId);
    pollController.cancel();
    statusCard.className = "storegen-status-card cancelled";
    title.textContent = "Cancelled";
    body.textContent = "Job monitoring stopped. The job may still be running on the server.";
    closeBtn.classList.add("visible");
    cancelBtn.style.display = "none";
    clearStoredJob(codeReviewKey);
    localStorage.removeItem(codeReviewKey);

    document
      .querySelectorAll('.storegen-checkbox-banner input[type="checkbox"]')
      .forEach((cb) => {
        cb.disabled = false;
      });

    if (onClose) onClose();
  };

  return statusCard;
}

/**
 * Reopens a status card for a completed job from history
 * @param {Object} job - Job data from history
 * @param {Function} renderMarkdown - Function to render markdown to HTML
 * @returns {HTMLElement} The status card element
 */
function simTaskeiStatusCard_reopenJobStatusCard(job, renderMarkdown) {
  // Remove any existing status card
  const existingCard = document.querySelector(".storegen-status-card");
  if (existingCard) {
    existingCard.remove();
  }

  // Create status card
  const statusCard = document.createElement("div");
  statusCard.className = `storegen-status-card ${job.status === "COMPLETED" ? "completed" : "failed"}`;

  // Create logo
  const logo = createStoreGenLogo();

  // Create header
  const header = document.createElement("div");
  header.className = "storegen-status-header";

  const title = document.createElement("div");
  title.className = "storegen-status-title";
  title.textContent = job.status === "COMPLETED" ? "Completed" : "Failed";

  const closeBtn = document.createElement("button");
  closeBtn.className = "storegen-status-close visible";
  closeBtn.textContent = "\u00d7";

  header.appendChild(logo);
  header.appendChild(title);
  header.appendChild(closeBtn);

  // Create scrollable content wrapper
  const content = document.createElement("div");
  content.className = "storegen-status-content";

  // Create body
  const body = document.createElement("div");
  body.className = "storegen-status-body";
  body.innerHTML =
    renderMarkdown(job.finalOutput) ||
    (job.status === "COMPLETED"
      ? "Job completed successfully"
      : "Job failed");

  // Create job link
  const logsLink = document.createElement("a");
  logsLink.className = "storegen-status-link";
  logsLink.textContent = "View job";
  logsLink.onclick = (e) => {
    e.stopPropagation();
    GM_openInTab(job.jobUrl || job.viewLogsUrl, { active: true });
  };

  content.appendChild(body);
  content.appendChild(logsLink);

  statusCard.appendChild(header);
  statusCard.appendChild(content);
  const cleanupDrag = simTaskeiStatusCard_makeDraggable(statusCard, header);

  closeBtn.onclick = () => {
    log("User closed reopened status card for job:", job.jobId);
    cleanupDrag();
    statusCard.classList.add("hidden");
    setTimeout(() => statusCard.remove(), STATUS_CARD_REMOVE_DELAY_MS);
  };

  document.body.appendChild(statusCard);

  return statusCard;
}

;// ./src/core/packageVisibility.js
// Package visibility checker via Bindles API


const BINDLES_URL = 'https://bindles.amazon.com/resource/builder-tools/package';

/**
 * Checks if a package is public by querying the Bindles API
 * @param {string} packageName - Package name to check
 * @returns {Promise<{isPublic: boolean, error: string|null}>}
 */
function checkPackageVisibility(packageName) {
  const url = `${BINDLES_URL}/${encodeURIComponent(packageName)}`;

  return new Promise((resolve) => {
    if (typeof GM_xmlhttpRequest === 'undefined') {
      logger_log('GM_xmlhttpRequest not available, skipping visibility check');
      resolve({ isPublic: true, error: null });
      return;
    }

    logger_log('Checking package visibility via Bindles:', packageName);

    GM_xmlhttpRequest({
      method: 'GET',
      url: url,
      withCredentials: true,
      timeout: 10000,
      onload: (response) => {
        if (response.status >= 200 && response.status < 300) {
          try {
            const data = JSON.parse(response.responseText);
            const visibility = data?.resource?.visibility;
            if (visibility === 'PUBLIC') {
              logger_log('Package is public:', packageName);
              resolve({ isPublic: true, error: null });
            } else if (visibility === 'PRIVATE') {
              logger_log('Package is private:', packageName);
              resolve({ isPublic: false, error: null });
            } else {
              logger_log('Unknown visibility for:', packageName, ':', visibility, '— assuming public');
              resolve({ isPublic: true, error: null });
            }
          } catch (e) {
            logger_log('Error parsing Bindles response:', e);
            resolve({ isPublic: true, error: null });
          }
        } else if (response.status === 404) {
          logger_log('Package not found in Bindles:', packageName, '— allowing through');
          resolve({ isPublic: true, error: null });
        } else {
          logger_log('Bindles API error:', response.status);
          resolve({ isPublic: true, error: null });
        }
      },
      onerror: () => {
        logger_log('Network error checking Bindles');
        resolve({ isPublic: true, error: null });
      },
      ontimeout: () => {
        logger_log('Bindles API timeout');
        resolve({ isPublic: true, error: null });
      }
    });
  });
}

/**
 * Checks visibility for multiple packages
 * @param {string[]} packageNames - Array of package names
 * @returns {Promise<{allPublic: boolean, privatePackages: string[]}>}
 */
async function checkMultiplePackages(packageNames) {
  const results = await Promise.all(packageNames.map(name => checkPackageVisibility(name.trim())));
  
  const privatePackages = [];
  
  for (let i = 0; i < packageNames.length; i++) {
    if (!results[i].isPublic) {
      privatePackages.push(packageNames[i].trim());
    }
  }

  return {
    allPublic: privatePackages.length === 0,
    privatePackages
  };
}

;// ./src/core/cancelledJobs.js
// Cancelled job tracking using GM storage
// Shared across SIM and Taskei features


/**
 * Checks if a job was previously cancelled by the user
 * @param {string} jobId - Job ID to check
 * @returns {boolean} True if job was cancelled
 */
function isCancelledJob(jobId) {
  try {
    const cancelled = JSON.parse(GM_getValue('storegen_cancelled_jobs', '[]'));
    logger_log('isCancelledJob check for:', jobId, 'cancelled list:', cancelled);
    return cancelled.includes(jobId);
  } catch (e) { logger_log('Error in isCancelledJob:', e); return false; }
}

/**
 * Marks a job as cancelled so it won't restore on page refresh
 * @param {string} jobId - Job ID to mark as cancelled
 */
function markJobCancelled(jobId) {
  try {
    const cancelled = JSON.parse(GM_getValue('storegen_cancelled_jobs', '[]'));
    logger_log('markJobCancelled called for:', jobId, 'existing:', cancelled);
    if (!cancelled.includes(jobId)) {
      cancelled.push(jobId);
      if (cancelled.length > 20) cancelled.shift();
      GM_setValue('storegen_cancelled_jobs', JSON.stringify(cancelled));
      logger_log('Job marked as cancelled:', jobId);
    }
  } catch (e) { logger_log('Error in markJobCancelled:', e); }
}

;// ./src/features/sim/sim-issue/index.js
// SIM issue page integration










let activeJobId = null;
let retryIntervalId = null;
let statusObserver = null;

/**
 * Gets the user alias from cookies or page
 * @returns {string|null} User alias or null
 */
function getUserAlias() {
  try {
    // Extract from aws-userInfo cookie (contains ARN with alias)
    const match = document.cookie.match(/aws-userInfo=([^;]+)/);
    if (match) {
      const decoded = decodeURIComponent(match[1]);
      // ARN contains alias as last segment after "P-" or "Fleet+P-"
      const arnMatch = decoded.match(/P-([a-z][a-z0-9]+)/i);
      if (arnMatch) {
        return arnMatch[1].toLowerCase();
      }
    }
  } catch (e) {
    logger_log('Error extracting alias from cookie:', e);
  }
  
  return null;
}

/**
 * Builds the tag for a SIM job
 * @param {string} issueId - Issue ID
 * @returns {string} Tag string
 */
function buildTag(issueId) {
  return `browserextension-sim:${issueId}`;
}

/**
 * Checks if there's an active job (in-memory check)
 * @returns {boolean} True if active job exists
 */
function hasActiveJob() {
  return activeJobId !== null;
}

/**
 * Initializes the SIM issue page functionality
 */
function initSimIssue() {
  logger_log('Initializing SIM issue page');

  // Clean up previous invocation (SPA re-entry)
  codegenButton_removeCodeGenButton();
  if (retryIntervalId) {
    clearInterval(retryIntervalId);
    retryIntervalId = null;
  }
  if (statusObserver) {
    statusObserver.disconnect();
    statusObserver = null;
  }
  activeJobId = null;

  // Inject styles
  injectStyles();
  
  // SIM-specific: plain link style for View logs (no box)
  if (!document.getElementById('storegen-sim-link-styles')) {
    const simStyle = document.createElement('style');
    simStyle.id = 'storegen-sim-link-styles';
    simStyle.textContent = `.storegen-status-link { border: none !important; padding: 0 !important; border-radius: 0 !important; }`;
    document.head.appendChild(simStyle);
  }
  
  // Extract issue ID from URL (may be null in folder/search view)
  let issueId = extractIssueId();
  
  // In folder/search view, issueId will be null at init time.
  // We'll re-extract from DOM when the user clicks the button.
  const isSearchView = window.location.pathname.match(/\/issues\/search/);
  
  if (!issueId && !isSearchView) {
    return;
  }
  
  logger_log('SIM issue page:', issueId || '(search/folder view - will extract on click)');
  
  // Markdown renderer
  const renderMarkdown = window.markdownit ? 
    (md) => window.markdownit({ linkify: true }).render(md) :
    (md) => md;
  
  // Get user alias for tag-based job tracking
  const alias = getUserAlias();
  
  // Check for active job via API, with localStorage fallback
  if (alias && issueId) {
    const tag = buildTag(issueId);
    fetchJobsByTag(tag, 1,
      (jobs) => {
        if (jobs.length > 0 && jobs[0].status === 'IN_PROGRESS') {
          const job = jobs[0];
          logger_log('Found active job from API:', job.jobId);
          activeJobId = job.jobId;
          simTaskeiStatusCard_createJobBanner(
            job.jobId,
            job.jobUrl || job.viewLogsUrl,
            null,
            renderMarkdown,
            () => {
              markJobCancelled(job.jobId);
              activeJobId = null;
            },
            "Creating a Code Review...",
            true
          );
        }
      },
      (error) => {
        logger_log('Error checking for active jobs:', error);
      }
    );
  } else {
    // Fallback: check localStorage when alias is unavailable
    const storageKey = `storegen_sim_issue_${issueId}`;
    const stored = localStorage.getItem(storageKey);
    if (stored) {
      try {
        const data = JSON.parse(stored);
        if (data.status === 'IN_PROGRESS') {
          logger_log('Restoring active job from localStorage (no alias):', data.jobId);
          activeJobId = data.jobId;
          simTaskeiStatusCard_createJobBanner(
            data.jobId,
            data.jobUrl || data.viewLogsUrl,
            storageKey,
            renderMarkdown,
            () => {
              logger_log('localStorage fallback: status card closed');
              markJobCancelled(data.jobId);
              activeJobId = null;
              localStorage.removeItem(storageKey);
            },
            "Creating a Code Review...",
            true
          );
        }
      } catch (e) {
        logger_log('Error restoring job from localStorage:', e);
        localStorage.removeItem(storageKey);
      }
    }
  }
  
  // Wait for page to be ready and try to insert button
  const tryInsert = () => {
    // Skip if button already exists (prevents duplicates on SPA re-entry)
    if (document.getElementById('storegen-codegen-button')) {
      return true;
    }

    // Check if issue is closed - but only if page content is loaded with full status
    const docView = document.querySelector('.document-view');
    const classes = docView ? (docView.getAttribute('class') || '') : '';
    // Wait until status is fully loaded (not just "status-" prefix)
    if (!docView || !classes.match(/status-(open|resolved|closed)/)) {
      return false;
    }
    
    if (isIssueClosed()) {
      return true;
    }
    
    const button = codegenButton_createCodeGenButton(issueId, () => handleCodeGenClick(issueId, renderMarkdown));
    const inserted = codegenButton_insertCodeGenButton(button);
    
    if (!inserted) {
      return false;
    }
    return true;
  };
  
  // Try immediately
  if (tryInsert()) {
    return;
  }
  
  // If failed, wait for DOM changes and retry
  let retryCount = 0;
  const maxRetries = 10;
  retryIntervalId = setInterval(() => {
    retryCount++;
    if (tryInsert() || retryCount >= maxRetries) {
      clearInterval(retryIntervalId);
      retryIntervalId = null;
      if (retryCount >= maxRetries) {
        logger_log('SIM: Max retries for button insertion');
      }
    }
  }, 500);
  
  // Watch for status changes (e.g., user clicks Resolve or Reopen)
  // Use a flag to skip the initial class change during page load
  let initialLoadComplete = false;
  setTimeout(() => { initialLoadComplete = true; }, 3000);
  
  const observeDocView = () => {
    const dv = document.querySelector('.document-view');
    if (!dv) return;

    statusObserver = new MutationObserver(() => {
      if (!initialLoadComplete) return;

      if (isIssueClosed()) {
        codegenButton_removeCodeGenButton();
      } else if (!document.getElementById('storegen-codegen-button')) {
        const button = codegenButton_createCodeGenButton(issueId, () => handleCodeGenClick(issueId, renderMarkdown));
        codegenButton_insertCodeGenButton(button);
      }
    });
    statusObserver.observe(dv, { attributes: true, attributeFilter: ['class'] });
  };
  observeDocView();
}

/**
 * Checks if the issue is closed
 * @returns {boolean} True if issue is closed
 */
function isIssueClosed() {
  const docView = document.querySelector('.document-view');
  if (docView) {
    const classes = docView.getAttribute('class') || '';
    if (classes.includes('status-resolved') || classes.includes('status-closed')) {
      return true;
    }
  }
  if (document.querySelector('.status-resolved')) {
    return true;
  }
  return false;
}

/**
 * Shows a temporary toast notification
 * @param {string} message - Message to display
 */
function showToast(message) {
  const existing = document.querySelector('.storegen-toast');
  if (existing) existing.remove();
  
  const toast = document.createElement('div');
  toast.className = 'storegen-toast';
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed; bottom: 220px; right: 20px; z-index: 10001;
    background: #16191F; color: white; padding: 12px 20px; border-radius: 4px;
    font-size: 13px; font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4); opacity: 0; transition: opacity 0.3s ease;
  `;
  document.body.appendChild(toast);
  requestAnimationFrame(() => { toast.style.opacity = '1'; });
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

/**
 * Extracts the issue ID from the current URL
 * @returns {string|null} Issue ID or null if not found
 */
function extractIssueId() {
  const pathname = window.location.pathname;
  const match = pathname.match(/\/issues\/([A-Za-z0-9-]+)/);
  const idFromUrl = match ? match[1] : null;
  
  // In folder/search view, the URL path is /issues/search — not a real issue ID
  if (idFromUrl && idFromUrl.toLowerCase() !== 'search' && idFromUrl.toLowerCase() !== 'create') {
    return idFromUrl;
  }
  
  // Fallback: use selectedDocument URL param to find the issue ID from the page
  const params = new URLSearchParams(window.location.search);
  const selectedDoc = params.get('selectedDocument');
  if (selectedDoc) {
    const links = document.querySelectorAll('a[href*="' + selectedDoc + '"]');
    for (const link of links) {
      const row = link.closest('tr, li, div');
      if (row) {
        const rowMatch = row.textContent.match(/([A-Z][a-zA-Z]+-\d+|P\d{9,})/);
        if (rowMatch) {
          return rowMatch[1];
        }
      }
    }
  }
  
  return null;
}

/**
 * Extracts the issue description from the SIM page
 * @returns {string} Issue description or empty string if not found
 */
function extractIssueDescription() {
  // Find the Edit link first, then get its parent container
  const editLink = document.querySelector('a.editable-field-edit, a.editable-field-view');
  
  if (editLink) {
    // Get the parent div that contains both the edit link and the description
    const container = editLink.parentElement;
    
    if (container) {
      // Clone to avoid modifying the page
      const clone = container.cloneNode(true);
      
      // Remove the edit link and any scripts
      const elementsToRemove = clone.querySelectorAll('a, script, button');
      elementsToRemove.forEach(el => el.remove());
      
      // Get all paragraph text
      const paragraphs = clone.querySelectorAll('p');
      
      if (paragraphs.length > 0) {
        // Combine all paragraphs with newlines
        const text = Array.from(paragraphs)
          .map(p => {
            // Replace <br> tags with newlines so textContent preserves line breaks
            p.querySelectorAll('br').forEach(br => br.replaceWith('\n'));
            return p.textContent.trim();
          })
          .filter(t => t.length > 0)
          .join('\n\n')
          .trim();
        
        if (text && text.length > 10) {
          return text;
        }
      }
    }
  }
  
  return '';
}

/**
 * Scrapes internal Amazon links from the SIM page description and comments only
 * @param {string} currentIssueId - Current issue ID to exclude self-references
 * @returns {string[]} Array of unique internal URLs found
 */
function scrapeLinksFromPage(currentIssueId) {
  const ALLOWED_DOMAINS = ['amazon.com', 'amazon.dev', 'amazon.work', 'aws.dev', 'a2z.com', 'quip-amazon.com'];
  const MAX_AUTO_LINKS = 5;
  
  // URLs to exclude - navigation/UI links that aren't real references
  const EXCLUDED_PATHS = [
    '/issues/search',
    '/issues/create',
    '/issues/$',
    '/login',
    '/logout',
    '/index.php/sim/',
  ];
  
  const isAllowed = (url) => {
    try {
      const parsed = new URL(url);
      const hostname = parsed.hostname.toLowerCase();
      const pathname = parsed.pathname.toLowerCase();
      
      // Must be from allowed domain
      if (!ALLOWED_DOMAINS.some(domain => hostname === domain || hostname.endsWith('.' + domain))) {
        return false;
      }
      
      // Exclude navigation/UI links
      if (EXCLUDED_PATHS.some(p => pathname.startsWith(p))) {
        return false;
      }
      
      // Exclude root pages (just the domain with no meaningful path)
      if (pathname === '/' || pathname === '') {
        return false;
      }
      
      // Exclude AWS Console URLs (not readable content)
      if (hostname.includes('console.aws.amazon.com')) {
        return false;
      }
      
      // Exclude CodeGen job URLs (self-generated by this extension)
      if (hostname.includes('codegen.harmony.a2z.com')) {
        return false;
      }
      
      return true;
    } catch { return false; }
  };
  
  const isSelfReference = (url) => {
    // Check if URL contains the issue ID
    if (currentIssueId && url.includes(currentIssueId)) return true;
    // Check if URL matches the current page URL
    if (url === window.location.href) return true;
    // Exclude SIM/issues UUID links on the same hostname (auto-generated self-links)
    try {
      const parsed = new URL(url);
      const currentHostname = window.location.hostname;
      if (parsed.hostname === currentHostname && parsed.pathname.match(/\/issues\/[0-9a-f]{8}-[0-9a-f]{4}-/)) {
        return true;
      }
    } catch { /* ignore */ }
    return false;
  };
  
  // Only scrape from user-authored content areas
  const contentSelectors = [
    '.document-description-container',  // Issue description
    '.activity-body.rich-text',         // Comment/activity bodies
  ];
  
  // System activity patterns to skip (UI elements, audit trail)
  const isSystemActivity = (element) => {
    const text = element.textContent.trim();
    // Skip SIM action panels and audit trail entries
    if (text.startsWith('Mark As') || text.startsWith('path/') || text.startsWith('editActio')) return true;
    // Skip elements with buttons (action panels)
    if (element.querySelector('button')) return true;
    return false;
  };
  
  const seen = new Set();
  const urls = [];
  
  for (const selector of contentSelectors) {
    const sections = document.querySelectorAll(selector);
    for (const section of sections) {
      // Skip system-generated activities (audit trail)
      if (isSystemActivity(section)) continue;
      
      const links = section.querySelectorAll('a[href]');
      for (const link of links) {
        const href = link.href;
        if (!href || href.startsWith('javascript:') || href.startsWith('#')) continue;
        if (seen.has(href)) continue;
        seen.add(href);
        
        if (isAllowed(href) && !isSelfReference(href)) {
          urls.push(href);
          if (urls.length >= MAX_AUTO_LINKS) break;
        }
      }
      if (urls.length >= MAX_AUTO_LINKS) break;
    }
    if (urls.length >= MAX_AUTO_LINKS) break;
  }
  
  return urls;
}

/**
 * Handles the CodeGen button click
 * @param {string} issueId - The issue ID
 * @param {Function} renderMarkdown - Markdown renderer
 */
function handleCodeGenClick(issueId, renderMarkdown) {
  // Re-extract issue ID from DOM in case we're in folder/search view
  const resolvedIssueId = issueId || extractIssueId();
  if (!resolvedIssueId) {
    showToast('Could not determine the issue ID. Try opening the issue directly.');
    return;
  }
  
  const existingCard = document.querySelector('.storegen-status-card');
  
  // If a job is still actively in progress (card has 'working' class), block
  if (activeJobId && existingCard && existingCard.classList.contains('working')) {
    showToast('A job is already in progress. Please wait for it to finish.');
    return;
  }
  
  // Close any existing results card (completed/failed/cancelled) and reset state
  if (existingCard) {
    existingCard.remove();
    activeJobId = null;
  }
  
  // Extract the issue description for package name detection
  const issueDescription = extractIssueDescription();
  
  // Scrape links from the SIM page
  const scrapedLinks = scrapeLinksFromPage(resolvedIssueId);
  
  // Create modal (detection happens inside)
  const modal = instructionsModal_createInstructionsModal(
    resolvedIssueId,
    issueDescription,
    (packageNames, simUrl, referenceLinks) => handleSubmit(resolvedIssueId, packageNames, simUrl, referenceLinks, modal, renderMarkdown),
    () => logger_log('Modal cancelled'),
    scrapedLinks
  );
  
  instructionsModal_openModal(modal);
}

/**
 * Handles the modal submission
 * @param {string} issueId - The issue ID
 * @param {string[]} packageNames - Array of package names
 * @param {string} simUrl - The SIM issue URL
 * @param {HTMLElement} modal - The modal element
 * @param {Function} renderMarkdown - Markdown renderer
 */
async function handleSubmit(issueId, packageNames, simUrl, referenceLinks, modal, renderMarkdown) {
  logger_log('Submitting CodeGen job for issue:', issueId);
  
  // Check for active job
  if (hasActiveJob()) {
    instructionsModal_showInfo(modal, 'Another job is still in progress. Please wait for it to finish before submitting a new one.');
    return;
  }
  
  instructionsModal_setLoading(modal, true);
  
  // Check package visibility before submitting
  const visibility = await checkMultiplePackages(packageNames);
  if (!visibility.allPublic) {
    instructionsModal_setLoading(modal, false);
    instructionsModal_showError(modal, `Private package(s) detected: ${visibility.privatePackages.join(', ')}. CodeGen only supports public packages.`);
    return;
  }
  
  // Close any existing status card
  const existingCard = document.querySelector('.storegen-status-card');
  if (existingCard) {
    existingCard.remove();
  }
  
  // Format instructions: reference the SIM ticket with concrete framing
  const formattedInstructions = `
Package(s): ${packageNames.join(', ')}

Read the SIM ticket at ${simUrl} and implement the code changes described in its description and comments.
  `.trim();
  
  // Build tag for server-side job tracking
  const alias = getUserAlias();
  const tag = buildTag(issueId);
  const storageKey = !alias ? `storegen_sim_issue_${issueId}` : null;
  
  submitJobWithInstructions(
    formattedInstructions,
    (jobId, jobUrl) => {
      logger_log('Job submitted successfully:', jobId);
      
      // Track active job in memory
      activeJobId = jobId;
      
      // Fallback: store in localStorage if no alias
      if (storageKey) {
        localStorage.setItem(storageKey, JSON.stringify({
          jobId, jobUrl, timestamp: Date.now(), status: 'IN_PROGRESS'
        }));
      }
      
      // Close the input modal
      instructionsModal_closeModal(modal);
      
      // Create status card with polling
      simTaskeiStatusCard_createJobBanner(
        jobId,
        jobUrl,
        storageKey,
        renderMarkdown,
        () => {
          markJobCancelled(jobId);
          activeJobId = null;
          if (storageKey) localStorage.removeItem(storageKey);
        },
        "Creating a Code Review...",
        true
      );
    },
    (errorMessage) => {
      logger_log('Error submitting CodeGen job:', errorMessage);
      instructionsModal_showError(modal, `Failed to submit job: ${errorMessage}`);
      instructionsModal_setLoading(modal, false);
    },
    tag,
    referenceLinks.length > 0 ? referenceLinks : null
  );
}

;// ./src/features/taskei/taskei-task/codegenButton.js
// CodeGen button component for Taskei task page



/**
 * Creates a CodeGen button for the Taskei task page action bar
 * @param {string} taskId - ID of the task
 * @param {Function} onClick - Callback when button is clicked
 * @returns {HTMLElement} Button element
 */
function taskei_task_codegenButton_createCodeGenButton(taskId, onClick) {
  const button = document.createElement('button');
  button.id = 'storegen-codegen-button';
  
  // Use inline styles to match Taskei's button design with gradient bar
  button.style.cssText = `
    position: relative !important;
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    background: #16191F !important;
    color: white !important;
    border: 1px solid #16191F !important;
    border-radius: 20px !important;
    padding: 4px 16px 4px 20px !important;
    margin-right: 8px !important;
    font-size: 14px !important;
    font-weight: 500 !important;
    font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif !important;
    cursor: pointer !important;
    transition: background 0.2s ease !important;
    height: 32px !important;
    line-height: 1 !important;
    white-space: nowrap !important;
    vertical-align: middle !important;
    overflow: hidden !important;
    box-sizing: border-box !important;
  `;
  
  // Create gradient bar
  const gradientBar = document.createElement('div');
  gradientBar.style.cssText = `
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
    background: linear-gradient(180deg,
      rgba(0,0,0,1) 0%,
      rgba(0,49,129,1) 10%,
      rgba(32,116,213,1) 25%,
      rgba(244,110,187,1) 40%,
      rgba(255,173,151,1) 50%,
      rgba(244,110,187,1) 60%,
      rgba(32,116,213,1) 75%,
      rgba(0,49,129,1) 90%,
      rgba(0,0,0,1) 100%);
    background-size: 100% 200%;
    background-position: 0% 0%;
    transition: background-position 0.6s ease;
  `;
  
  button.appendChild(gradientBar);
  
  // Create logo
  const logo = logo_createStoreGenLogo();
  logo.style.width = '22px';
  logo.style.height = '22px';
  logo.style.marginRight = '8px';
  logo.style.flexShrink = '0';
  
  // Create text
  const text = document.createElement('span');
  text.textContent = 'Generate Code';
  text.style.lineHeight = '1';
  
  button.appendChild(logo);
  button.appendChild(text);
  
  button.onmouseover = () => {
    button.style.background = '#2a2e38 !important';
    gradientBar.style.backgroundPosition = '0% 100%';
  };
  
  button.onmouseout = () => {
    button.style.background = '#16191F !important';
    gradientBar.style.backgroundPosition = '0% 0%';
  };
  
  button.onclick = (e) => {
    e.preventDefault();
    onClick();
  };
  
  return button;
}

/**
 * Inserts the CodeGen button next to the Actions button in the task header
 * @param {HTMLElement} button - The button element to insert
 * @returns {boolean} True if insertion succeeded
 */
function taskei_task_codegenButton_insertCodeGenButton(button) {
  // Determine if we're in sidebar mode (URL has ?task= param but path is /rooms/)
  const isSidebarMode = window.location.pathname.startsWith('/rooms/') && 
                        new URLSearchParams(window.location.search).has('task');
  
  // Scope our search to the sidebar panel if in sidebar mode
  let searchRoot = document;
  if (isSidebarMode) {
    // Try various selectors for Cloudscape/Taskei sidebar panels
    const sidebarSelectors = [
      '[class*="awsui_drawer-content"]',
      '[class*="awsui_panel"]',
      '[class*="drawer-content"]',
      '[class*="split-panel"]',
      '[class*="side-panel"]',
      '[data-testid*="task-detail"]',
      '[data-testid*="drawer"]',
      '[class*="awsui_drawer"]',
      // Cloudscape AppLayout drawer
      '[class*="awsui_tools-container"]',
      '[class*="awsui_content-side"]',
    ];
    
    let sidebarPanel = null;
    for (const selector of sidebarSelectors) {
      sidebarPanel = document.querySelector(selector);
      if (sidebarPanel) {
        logger_log('Found sidebar panel with selector:', selector);
        break;
      }
    }
    
    if (sidebarPanel) {
      searchRoot = sidebarPanel;
    } else {
      // Fallback: find the Actions button that's NOT in the main header
      // by looking for the one closest to the task detail content
      const allActionsButtons = Array.from(document.querySelectorAll('button'))
        .filter(btn => btn.textContent.trim() === 'Actions');
      
      if (allActionsButtons.length > 1) {
        // Use the last Actions button (typically the sidebar one)
        const targetButton = allActionsButtons[allActionsButtons.length - 1];
        targetButton.parentNode.insertBefore(button, targetButton);
        logger_log('Inserted button before last Actions button (sidebar fallback)');
        return true;
      }
      
      logger_log('Sidebar mode but panel not found, available classes on body children:');
      document.body.querySelectorAll('[class*="awsui"]').forEach(el => {
        logger_log('  -', el.className.split(' ').slice(0, 3).join(' '));
      });
      return false;
    }
  }
  
  // Look for the Actions button within our search scope
  let targetButton = null;
  const buttons = searchRoot.querySelectorAll('button');
  
  for (const btn of buttons) {
    const text = btn.textContent.trim();
    if (text === 'Actions') {
      targetButton = btn;
      logger_log('Found Actions button');
      break;
    }
  }
  
  // Fallback: Look for Reopen task button
  if (!targetButton) {
    for (const btn of buttons) {
      const text = btn.textContent.trim();
      if (text === 'Reopen task' || text === 'Resolve task') {
        targetButton = btn;
        logger_log('Found Reopen/Resolve button');
        break;
      }
    }
  }
  
  if (!targetButton) {
    logger_log('Could not find insertion point for CodeGen button');
    logger_log('Available buttons:', Array.from(buttons).map(b => b.textContent.trim()).filter(t => t));
    return false;
  }
  
  // Insert the CodeGen button before the target button
  targetButton.parentNode.insertBefore(button, targetButton);
  
  logger_log('CodeGen button inserted successfully before:', targetButton.textContent.trim());
  return true;
}

/**
 * Removes the CodeGen button from the page
 */
function taskei_task_codegenButton_removeCodeGenButton() {
  const button = document.getElementById('storegen-codegen-button');
  if (button) {
    button.remove();
  }
}

;// ./src/features/taskei/taskei-task/specStudioButton.js



const SPEC_STUDIO_FAVORITES_URL = 'https://prod.spec-studio.storegen.amazon.dev/favorites';

let dropdownOpen = false;
let clickAbortController = null;

function createSpecStudioButton() {
  if (clickAbortController) clickAbortController.abort();
  clickAbortController = new AbortController();

  const wrapper = document.createElement('div');
  wrapper.id = 'storegen-spec-studio-wrapper';
  wrapper.style.cssText = `position: relative !important; display: inline-block !important; margin-right: 8px !important; vertical-align: middle !important;`;

  const button = document.createElement('button');
  button.id = 'storegen-spec-studio-button';
  button.style.cssText = `
    position: relative !important;
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    background: #16191F !important;
    color: white !important;
    border: 1px solid #16191F !important;
    border-radius: 20px !important;
    padding: 4px 16px 4px 20px !important;
    font-size: 14px !important;
    font-weight: 500 !important;
    font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif !important;
    cursor: pointer !important;
    transition: background 0.2s ease !important;
    height: 32px !important;
    line-height: 1 !important;
    white-space: nowrap !important;
    overflow: hidden !important;
    box-sizing: border-box !important;
  `;

  const gradientBar = document.createElement('div');
  gradientBar.style.cssText = `
    position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
    background: linear-gradient(180deg,
      rgba(0,0,0,1) 0%, rgba(0,49,129,1) 10%, rgba(32,116,213,1) 25%,
      rgba(244,110,187,1) 40%, rgba(255,173,151,1) 50%, rgba(244,110,187,1) 60%,
      rgba(32,116,213,1) 75%, rgba(0,49,129,1) 90%, rgba(0,0,0,1) 100%);
    background-size: 100% 200%; background-position: 0% 0%;
    transition: background-position 0.6s ease;
  `;
  button.appendChild(gradientBar);

  const logo = logo_createStoreGenLogo();
  logo.style.width = '22px';
  logo.style.height = '22px';
  logo.style.marginRight = '8px';
  logo.style.flexShrink = '0';

  const text = document.createElement('span');
  text.textContent = 'Open in Spec Studio';
  text.style.lineHeight = '1';

  const arrow = document.createElement('span');
  arrow.textContent = ' ▾';
  arrow.style.cssText = 'margin-left: 4px; font-size: 10px;';

  button.appendChild(logo);
  button.appendChild(text);
  button.appendChild(arrow);

  button.onmouseover = () => {
    button.style.setProperty('background', '#2a2e38', 'important');
    gradientBar.style.backgroundPosition = '0% 100%';
  };
  button.onmouseout = () => {
    button.style.setProperty('background', '#16191F', 'important');
    gradientBar.style.backgroundPosition = '0% 0%';
  };

  button.onclick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    toggleDropdown(wrapper);
  };

  wrapper.appendChild(button);

  document.addEventListener('click', (e) => {
    if (dropdownOpen && !wrapper.contains(e.target)) {
      closeDropdown(wrapper);
    }
  }, { signal: clickAbortController.signal });

  return wrapper;
}

function toggleDropdown(wrapper) {
  if (dropdownOpen) {
    closeDropdown(wrapper);
  } else {
    openDropdown(wrapper);
  }
}

function closeDropdown(wrapper) {
  const dropdown = wrapper.querySelector('.storegen-spec-studio-dropdown');
  if (dropdown) dropdown.remove();
  dropdownOpen = false;
}

async function openDropdown(wrapper) {
  closeDropdown(wrapper);
  dropdownOpen = true;

  const dropdown = document.createElement('div');
  dropdown.className = 'storegen-spec-studio-dropdown';
  dropdown.style.cssText = `
    position: absolute !important; top: 100% !important; left: 0 !important;
    margin-top: 4px !important; min-width: 240px !important; max-width: 360px !important;
    background: #16191F !important; border: 1px solid rgba(255,255,255,0.15) !important;
    border-radius: 8px !important; box-shadow: 0 8px 24px rgba(0,0,0,0.5) !important;
    z-index: 10000 !important; overflow: hidden !important;
    font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif !important;
  `;

  dropdown.innerHTML = `<div style="padding: 12px 16px; color: rgba(255,255,255,0.6); font-size: 12px;">Loading favorites…</div>`;
  wrapper.appendChild(dropdown);

  try {
    const favorites = await fetchFavorites();
    dropdown.innerHTML = '';

    if (!favorites || favorites.length === 0) {
      dropdown.innerHTML = `<div style="padding: 12px 16px; color: rgba(255,255,255,0.6); font-size: 13px;">No favorites. <a href="https://specs.harmony.a2z.com/collections" target="_blank" style="color: #7dd3fc; text-decoration: none;">Favorite collections</a> to open in chat</div>`;
      return;
    }

    favorites.forEach((fav) => {
      const item = document.createElement('div');
      item.style.cssText = `
        padding: 10px 16px !important; cursor: pointer !important; color: white !important;
        font-size: 13px !important; transition: background 0.15s ease !important;
        border-bottom: 1px solid rgba(255,255,255,0.06) !important;
        white-space: nowrap !important; overflow: hidden !important; text-overflow: ellipsis !important;
      `;
      item.textContent = fav.entityName || fav.name || fav.entityId || 'Untitled';
      item.onmouseover = () => { item.style.background = 'rgba(255,255,255,0.08)'; };
      item.onmouseout = () => { item.style.background = 'transparent'; };
      item.onclick = (e) => {
        e.stopPropagation();
        closeDropdown(wrapper);
        handleFavoriteClick(fav);
      };
      dropdown.appendChild(item);
    });
  } catch (err) {
    logger_log('Failed to fetch Spec Studio favorites:', err);
    dropdown.innerHTML = `<div style="padding: 12px 16px; color: #ff6b6b; font-size: 13px;">Failed to load favorites</div>`;
  }
}

function fetchFavorites() {
  return new Promise((resolve, reject) => {
    GM_xmlhttpRequest({
      method: 'GET',
      url: SPEC_STUDIO_FAVORITES_URL,
      withCredentials: true,
      onload: (response) => {
        try {
          if (response.status < 200 || response.status >= 300) {
            reject(new Error(`HTTP ${response.status}`));
            return;
          }
          const data = JSON.parse(response.responseText);
          resolve(data.collections || []);
        } catch (e) {
          reject(e);
        }
      },
      onerror: (error) => {
        reject(new Error('Network error: ' + (error.statusText || 'Unknown error')));
      },
    });
  });
}

function handleFavoriteClick(favorite) {
  logger_log('Spec Studio favorite selected:', favorite);
  const rawName = favorite.entityName || favorite.name || favorite.entityId || '';
  const collectionSlug = rawName.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-');
  const revisionId = favorite.latestRevisionId;
  if (!collectionSlug || !revisionId) {
    logger_log('Missing collection identifier or revision, cannot open Spec Studio');
    return;
  }
  const title = extractTaskTitle();
  const description = extractTaskDescriptionText();
  const message = [title, description].filter(Boolean).join('\n\n');
  const url = `https://specs.harmony.a2z.com/collections/${encodeURIComponent(collectionSlug)}/${encodeURIComponent(revisionId)}/chat?message=${encodeURIComponent(message)}`;
  window.open(url, '_blank');
}

function extractTaskTitle() {
  const heading = document.querySelector('h1');
  return heading ? heading.textContent.trim() : '';
}

function extractTaskDescriptionText() {
  const section = document.querySelector('[data-testid="description-section"]');
  if (!section) return '';
  const clone = section.cloneNode(true);
  clone.querySelectorAll('button, [role="button"]').forEach(el => el.remove());
  let text = clone.textContent.trim();
  text = text.replace(/^Description\s*/i, '');
  return text.length > 10 ? text : '';
}

function insertSpecStudioButton(button) {
  const codegenBtn = document.getElementById('storegen-codegen-button');
  if (codegenBtn && codegenBtn.parentNode) {
    codegenBtn.parentNode.insertBefore(button, codegenBtn.nextSibling);
    logger_log('Spec Studio button inserted after CodeGen button');
    return true;
  }
  logger_log('Could not find CodeGen button to insert Spec Studio button after');
  return false;
}

function removeSpecStudioButton() {
  const wrapper = document.getElementById('storegen-spec-studio-wrapper');
  if (wrapper) wrapper.remove();
  dropdownOpen = false;
  if (clickAbortController) {
    clickAbortController.abort();
    clickAbortController = null;
  }
}

;// ./src/features/taskei/taskei-task/instructionsModal.js
// Instructions modal component for Taskei task CodeGen




/**
 * Detects package names from description text
 */
function instructionsModal_detectPackageName(description) {
  if (!description) return null;
  const pattern = /packages?(?:\s*names?)?\s*[:\-]?\s*([A-Za-z0-9,\s._-]+?)(?:\n|\.(?:\s)|\s+-\s+|$)/i;
  const match = description.match(pattern);
  return match ? match[1].trim().replace(/[.,;:]+$/, '') : null;
}

/**
 * Validates that a URL is a safe HTTPS Taskei URL
 * Prevents javascript: URLs and other malicious schemes
 * @param {string} url - URL to validate
 * @returns {boolean} True if URL is safe to use
 */
function isValidTaskeiUrl(url) {
  if (!url) return false;
  try {
    const parsed = new URL(url);
    // Only allow https: protocol and taskei.amazon.dev domain
    return parsed.protocol === 'https:' && 
           parsed.hostname === 'taskei.amazon.dev' &&
           parsed.pathname.includes('/tasks/');
  } catch {
    return false;
  }
}

/**
 * Extracts the canonical task URL from the sidebar's "Full screen" button
 * Returns null if no valid URL is found or if URL fails security validation
 */
function extractTaskUrlFromSidebar() {
  // Find the "Full screen" link in the sidebar - it has the canonical task URL
  const drawer = document.querySelector('[class*="awsui_drawer-content"]');
  if (!drawer) return null;
  
  const links = drawer.querySelectorAll('a[href*="/tasks/"]');
  for (const link of links) {
    if (link.textContent.includes('Full screen') || 
        link.getAttribute('aria-label')?.includes('Full screen')) {
      // Validate URL before returning to prevent javascript: or other malicious schemes
      if (isValidTaskeiUrl(link.href)) {
        return link.href;
      }
    }
  }
  
  // Fallback: any link with /tasks/ pattern in the drawer
  for (const link of links) {
    // Validate URL before returning
    if (isValidTaskeiUrl(link.href)) {
      return link.href;
    }
  }
  
  return null;
}

/**
 * Force-applies styles to an element using setProperty with !important priority.
 * This beats Cloudscape because JS setProperty('...', '...', 'important') 
 * always wins over stylesheet !important rules.
 */
function forceStyles(el, styles) {
  for (const [prop, val] of Object.entries(styles)) {
    el.style.setProperty(prop, val, 'important');
  }
}

/**
 * Force-applies Cloudscape-resistant styles to all modal elements.
 * Called after the modal is appended to the DOM.
 */
function applyTaskeiOverrides(overlay) {
  // Overlay
  forceStyles(overlay, {
    'position': 'fixed', 'top': '0', 'left': '0', 'right': '0', 'bottom': '0',
    'background': 'rgba(0,0,0,0.5)', 'display': 'flex', 'align-items': 'center',
    'justify-content': 'center', 'z-index': '10000', 'pointer-events': 'auto',
  });

  const modal = overlay.querySelector('.storegen-modal');
  if (modal) {
    forceStyles(modal, {
      'position': 'relative', 'background': 'white', 'border-radius': '4px',
      'box-shadow': '0 4px 20px rgba(0,0,0,0.3)', 'border': '1px solid #e9ecef',
      'width': '600px', 'max-width': '90%', 'display': 'flex', 'flex-direction': 'column',
      'font-family': '"Amazon Ember","Helvetica Neue",Roboto,Arial,sans-serif',
      'pointer-events': 'auto', 'overflow': 'hidden', 'color': '#16191F',
    });
  }

  // Gradient bar
  const gradientBar = overlay.querySelector('.storegen-modal-gradient-bar');
  if (gradientBar) {
    forceStyles(gradientBar, {
      'height': '4px', 'width': '100%', 'flex-shrink': '0',
      'background': 'linear-gradient(90deg, rgba(0,0,0,1) 0%, rgba(0,49,129,1) 10%, rgba(32,116,213,1) 25%, rgba(244,110,187,1) 40%, rgba(255,173,151,1) 50%, rgba(244,110,187,1) 60%, rgba(32,116,213,1) 75%, rgba(0,49,129,1) 90%, rgba(0,0,0,1) 100%)',
    });
  }

  // Header
  const header = overlay.querySelector('.storegen-modal-header');
  if (header) {
    forceStyles(header, {
      'display': 'flex', 'align-items': 'center', 'justify-content': 'space-between',
      'padding': '16px 20px', 'border-bottom': '1px solid #e9ecef', 'background': 'white',
    });
    const h3 = header.querySelector('h3');
    if (h3) forceStyles(h3, { 'margin': '0', 'font-size': '18px', 'font-weight': '600', 'color': '#16191F' });
  }

  // Body
  const body = overlay.querySelector('.storegen-modal-body');
  if (body) {
    forceStyles(body, {
      'padding': '20px', 'display': 'flex', 'flex-direction': 'column',
      'gap': '8px', 'background': 'white',
    });
  }

  // All labels
  overlay.querySelectorAll('.storegen-modal-body label').forEach(label => {
    forceStyles(label, { 'display': 'block', 'font-size': '14px', 'font-weight': '500', 'color': '#16191F' });
  });

  // All text inputs in body
  overlay.querySelectorAll('.storegen-modal-body > input[type="text"]').forEach(input => {
    forceStyles(input, {
      'display': 'block', 'width': '100%', 'box-sizing': 'border-box',
      'padding': '10px', 'font-size': '14px', 'border': '1px solid #ced4da',
      'border-radius': '4px', 'font-family': 'inherit', 'color': '#16191F', 'background': 'white',
    });
  });

  // Readonly input override
  const readonlyInput = overlay.querySelector('#storegen-task-url');
  if (readonlyInput) {
    forceStyles(readonlyInput, { 'background': '#f5f5f5', 'color': '#555', 'cursor': 'not-allowed' });
  }

  // Footer
  const footer = overlay.querySelector('.storegen-modal-footer');
  if (footer) {
    forceStyles(footer, {
      'display': 'flex', 'justify-content': 'flex-end', 'gap': '12px',
      'padding': '16px 20px', 'background': 'white',
    });
  }

  // Footer buttons
  overlay.querySelectorAll('.storegen-modal-footer button').forEach(btn => {
    forceStyles(btn, {
      'padding': '8px 16px', 'font-size': '14px', 'font-weight': '500',
      'border-radius': '4px', 'cursor': 'pointer', 'font-family': 'inherit',
    });
  });
  const cancelBtn = overlay.querySelector('.storegen-modal-cancel');
  if (cancelBtn) forceStyles(cancelBtn, { 'background': 'white', 'color': '#16191F', 'border': '1px solid #ced4da' });
  const submitBtn = overlay.querySelector('.storegen-modal-submit');
  if (submitBtn) forceStyles(submitBtn, { 'background': '#16191F', 'color': 'white', 'border': 'none' });

  // Close button
  const closeBtn = overlay.querySelector('.storegen-modal-close');
  if (closeBtn) {
    forceStyles(closeBtn, {
      'background': 'none', 'border': 'none', 'font-size': '28px', 'color': '#6c757d',
      'cursor': 'pointer', 'padding': '0', 'width': '32px', 'height': '32px',
      'display': 'flex', 'align-items': 'center', 'justify-content': 'center',
    });
  }

  // Toggle link
  const toggleLink = overlay.querySelector('.storegen-url-toggle');
  if (toggleLink) {
    forceStyles(toggleLink, {
      'display': 'inline-flex', 'margin-top': '8px', 'color': '#2074d5',
      'text-decoration': 'none', 'font-size': '13px', 'align-items': 'center', 'gap': '4px',
    });
  }

  // URL section
  const urlSection = overlay.querySelector('.storegen-url-section');
  if (urlSection) {
    // Ensure it starts hidden unless scraped links expanded it
    if (urlSection.style.display !== 'block') {
      forceStyles(urlSection, { 'display': 'none' });
    }
    forceStyles(urlSection, {
      'margin-top': '16px', 'padding': '12px', 'background': '#f8f9fa',
      'border': '1px solid #e9ecef', 'border-radius': '4px',
    });
    // Title
    const urlTitle = urlSection.querySelector('.storegen-url-title');
    if (urlTitle) forceStyles(urlTitle, { 'font-weight': '600', 'font-size': '14px', 'color': '#16191F', 'display': 'block' });
    // Subtitle
    const urlSubtitle = urlSection.querySelector('.storegen-url-subtitle');
    if (urlSubtitle) forceStyles(urlSubtitle, { 'font-size': '13px', 'color': '#6c757d', 'margin': '4px 0 12px 0', 'display': 'block' });
    // URL input row
    const urlInputRow = urlSection.querySelector('.storegen-url-input-row');
    if (urlInputRow) forceStyles(urlInputRow, { 'display': 'flex', 'gap': '8px', 'margin-top': '8px' });
    // URL input
    const urlInput = urlSection.querySelector('.storegen-url-input');
    if (urlInput) {
      forceStyles(urlInput, {
        'flex': '1', 'padding': '8px 10px', 'font-size': '13px',
        'border': '1px solid #ced4da', 'border-radius': '4px', 'font-family': 'inherit',
        'display': 'block', 'box-sizing': 'border-box', 'background': 'white', 'color': '#16191F',
      });
    }
    // URL add button
    const urlAddBtn = urlSection.querySelector('.storegen-url-add-btn');
    if (urlAddBtn) {
      forceStyles(urlAddBtn, {
        'padding': '8px 16px', 'background': 'white', 'color': '#16191F',
        'border': '1px solid #ced4da', 'border-radius': '4px', 'font-size': '13px',
        'font-weight': '500', 'cursor': 'pointer',
      });
    }
    // Security banner
    const banner = urlSection.querySelector('.storegen-security-banner');
    if (banner) {
      forceStyles(banner, {
        'padding': '8px 12px', 'background': '#fff3cd', 'border': '1px solid #ffc107',
        'border-radius': '4px', 'margin-bottom': '8px', 'font-size': '13px', 'color': '#664d03',
        'white-space': 'nowrap',
      });
      const bannerLink = banner.querySelector('a');
      if (bannerLink) forceStyles(bannerLink, { 'color': '#664d03', 'text-decoration': 'underline', 'margin-left': '4px' });
    }

    // Force styles on existing URL items and watch for new ones
    const urlList = urlSection.querySelector('.storegen-url-list');
    if (urlList) {
      forceStyles(urlList, { 'margin-top': '12px', 'display': 'flex', 'flex-direction': 'column', 'gap': '6px' });
      const styleUrlItem = (item) => {
        forceStyles(item, {
          'display': 'flex', 'align-items': 'center', 'gap': '8px',
          'padding': '6px 10px', 'background': 'white', 'border': '1px solid #e9ecef',
          'border-radius': '4px', 'font-size': '12px',
        });
        const text = item.querySelector('.storegen-url-text');
        if (text) forceStyles(text, { 'flex': '1', 'color': '#16191F', 'font-family': "'Monaco','Menlo','Ubuntu Mono',monospace", 'overflow': 'hidden', 'text-overflow': 'ellipsis', 'white-space': 'nowrap' });
        const size = item.querySelector('.storegen-url-size');
        if (size) forceStyles(size, { 'color': '#6c757d', 'font-size': '11px' });
        const remove = item.querySelector('.storegen-url-remove');
        if (remove) forceStyles(remove, { 'background': 'none', 'border': 'none', 'color': '#6c757d', 'font-size': '16px', 'cursor': 'pointer', 'padding': '0 4px' });
      };
      // Style existing items
      urlList.querySelectorAll('.storegen-url-item').forEach(styleUrlItem);
      // Watch for new items
      new MutationObserver((mutations) => {
        for (const m of mutations) {
          for (const node of m.addedNodes) {
            if (node.nodeType === 1 && node.classList?.contains('storegen-url-item')) styleUrlItem(node);
          }
        }
      }).observe(urlList, { childList: true });
    }
  }
}

/**
 * Creates an instructions modal for CodeGen job submission on Taskei
 */
function taskei_task_instructionsModal_createInstructionsModal(taskId, taskDescription, onSubmit, onCancel, scrapedLinks = []) {
  const detectedPackage = instructionsModal_detectPackageName(taskDescription);
  
  // Build canonical task URL - always use /tasks/ format
  let taskUrl;
  if (window.location.pathname.startsWith('/tasks/')) {
    // Already on full task page - validate before using
    taskUrl = isValidTaskeiUrl(window.location.href) ? window.location.href : '';
  } else {
    // Sidebar mode - get URL from "Full screen" button (already validated in extractTaskUrlFromSidebar)
    const sidebarTaskUrl = extractTaskUrlFromSidebar();
    if (sidebarTaskUrl) {
      taskUrl = sidebarTaskUrl;
    } else {
      // Fallback to UUID-based URL - sanitize taskId to prevent injection
      // Only allow alphanumeric, hyphens (UUID format)
      const sanitizedTaskId = taskId ? taskId.replace(/[^a-zA-Z0-9-]/g, '') : '';
      taskUrl = sanitizedTaskId ? `https://taskei.amazon.dev/tasks/${sanitizedTaskId}` : '';
    }
  }
  
  const urlSectionHtml = createUrlSectionHtml();

  const overlay = document.createElement('div');
  overlay.className = 'storegen-modal-overlay';

  const modal = document.createElement('div');
  modal.className = 'storegen-modal';

  modal.innerHTML = `
    <div class="storegen-modal-gradient-bar"></div>
    <div class="storegen-modal-header">
      <h3>Generate Code for Task ${escapeHtml(taskId)}</h3>
      <button class="storegen-modal-close">×</button>
    </div>
    <div class="storegen-modal-body">
      <label for="storegen-package-name">
        <strong>Package Name(s):</strong>
        <span style="color: #d13212; font-weight: bold;">*</span>
        <span style="color: #666; font-weight: normal; font-size: 12px;">(comma-separated)</span>
      </label>
      <input
        type="text"
        id="storegen-package-name"
        placeholder="e.g., MyPackage or MyPackage1, MyPackage2"
        value="${escapeHtml(detectedPackage || '')}"
        required
      />
      <label for="storegen-task-url">
        <strong>Taskei:</strong>
      </label>
      <input
        type="text"
        id="storegen-task-url"
        value="${escapeHtml(taskUrl)}"
        readonly
      />
      <a href="#" class="storegen-url-toggle" style="margin-top: 8px;">
        <span class="storegen-url-toggle-arrow">▶</span> Add reference links
      </a>
      ${urlSectionHtml}
    </div>
    <div class="storegen-modal-footer">
      <button class="storegen-modal-cancel">Cancel</button>
      <button class="storegen-modal-submit">Generate CR</button>
    </div>
  `;

  overlay.appendChild(modal);
  initUrlSection(overlay);

  // Toggle URL section
  const toggle = modal.querySelector('.storegen-url-toggle');
  const urlSection = modal.querySelector('.storegen-url-section');
  if (toggle && urlSection) {
    if (scrapedLinks.length > 0) {
      urlSection.style.display = 'block';
      toggle.querySelector('.storegen-url-toggle-arrow').textContent = '▼';
    }
    toggle.onclick = (e) => {
      e.preventDefault();
      const arrow = toggle.querySelector('.storegen-url-toggle-arrow');
      if (urlSection.style.display === 'none') {
        urlSection.style.display = 'block';
        arrow.textContent = '▼';
      } else {
        urlSection.style.display = 'none';
        arrow.textContent = '▶';
      }
    };
  }

  // Auto-load scraped links
  if (scrapedLinks.length > 0) {
    scrapedLinks.forEach(url => addUrlProgrammatically(overlay, url));
  }

  const closeBtn = modal.querySelector('.storegen-modal-close');
  const cancelBtn = modal.querySelector('.storegen-modal-cancel');
  const submitBtn = modal.querySelector('.storegen-modal-submit');
  const packageInput = modal.querySelector('#storegen-package-name');

  const cleanup = () => { clearUrlContents(); taskei_task_instructionsModal_closeModal(overlay); };

  closeBtn.onclick = () => { cleanup(); if (onCancel) onCancel(); };
  cancelBtn.onclick = () => { cleanup(); if (onCancel) onCancel(); };
  overlay.onclick = (e) => { if (e.target === overlay) { cleanup(); if (onCancel) onCancel(); } };

  submitBtn.onclick = () => {
    const packageName = packageInput.value.trim();
    if (!packageName) { taskei_task_instructionsModal_showError(overlay, 'Package name is required'); packageInput.focus(); return; }
    const referenceLinks = getUrlContentsArray();
    onSubmit([packageName], taskUrl, referenceLinks);
  };

  return overlay;
}

function taskei_task_instructionsModal_openModal(modal) {
  document.body.appendChild(modal);
  // Apply Cloudscape-resistant styles after DOM insertion
  applyTaskeiOverrides(modal);
  const input = modal.querySelector('#storegen-package-name');
  if (input) input.focus();
}

function taskei_task_instructionsModal_closeModal(modal) { modal.remove(); }

function taskei_task_instructionsModal_showError(modal, message) {
  let div = modal.querySelector('.storegen-modal-message');
  if (!div) {
    div = document.createElement('div');
    div.className = 'storegen-modal-message';
    modal.querySelector('.storegen-modal-body')?.appendChild(div);
  }
  div.textContent = message;
  forceStyles(div, {
    'display': 'block', 'font-size': '13px', 'padding': '8px 12px',
    'border-radius': '4px', 'color': '#d13212', 'background': '#fef2f2', 'border': '1px solid #fecaca',
  });
}

function taskei_task_instructionsModal_showInfo(modal, message) {
  let div = modal.querySelector('.storegen-modal-message');
  if (!div) {
    div = document.createElement('div');
    div.className = 'storegen-modal-message';
    modal.querySelector('.storegen-modal-body')?.appendChild(div);
  }
  div.textContent = message;
  forceStyles(div, {
    'display': 'block', 'font-size': '13px', 'padding': '8px 12px',
    'border-radius': '4px', 'color': '#37474f', 'background': '#e3f2fd', 'border': '1px solid #90caf9',
  });
}

function taskei_task_instructionsModal_setLoading(modal, isLoading) {
  const btn = modal.querySelector('.storegen-modal-submit');
  btn.disabled = isLoading;
  btn.textContent = isLoading ? 'Submitting...' : 'Generate CR';
}

;// ./src/features/taskei/taskei-task/index.js
// Taskei task page integration












let taskei_task_activeJobId = null;

/**
 * Force-applies styles to beat Cloudscape on the status card
 */
function forceStatusCardStyles() {
  const s = (el, styles) => { for (const [p, v] of Object.entries(styles)) el.style.setProperty(p, v, 'important'); };

  // Style the jobs container
  const container = document.querySelector('.storegen-jobs-container');
  if (container) {
    s(container, {
      'position': 'fixed', 'bottom': '20px', 'right': '20px', 'z-index': '9999',
      'max-width': '500px', 'min-width': '400px', 'display': 'flex', 'flex-direction': 'column', 'gap': '8px',
    });
  }

  // Style each job row
  const rows = document.querySelectorAll('.storegen-job-row');
  rows.forEach(row => {
    s(row, {
      'background': '#16191F', 'color': 'white', 'border': 'none', 'border-radius': '4px',
      'font-family': '"Amazon Ember","Helvetica Neue",Roboto,Arial,sans-serif',
      'box-shadow': '0 8px 24px rgba(0,0,0,0.6)', 'overflow': 'hidden', 'position': 'relative',
    });

    // Add gradient bar on the left if not already present
    if (!row.querySelector('.storegen-taskei-gradient-bar')) {
      const bar = document.createElement('div');
      bar.className = 'storegen-taskei-gradient-bar';
      s(bar, {
        'position': 'absolute', 'left': '0', 'top': '0', 'bottom': '0', 'width': '4px',
        'background': 'linear-gradient(180deg, rgba(0,0,0,1) 0%, rgba(0,49,129,1) 10%, rgba(32,116,213,1) 25%, rgba(244,110,187,1) 40%, rgba(255,173,151,1) 50%, rgba(244,110,187,1) 60%, rgba(32,116,213,1) 75%, rgba(0,49,129,1) 90%, rgba(0,0,0,1) 100%)',
        'background-size': '100% 200%', 'z-index': '1',
      });
      row.insertBefore(bar, row.firstChild);
    }

    // Animate gradient bar when working
    const bar = row.querySelector('.storegen-taskei-gradient-bar');
    if (bar && row.classList.contains('working') && !row._storegenBarAnimating) {
      row._storegenBarAnimating = true;
      const animateBar = () => {
        if (!row.classList.contains('working')) { row._storegenBarAnimating = false; return; }
        const t = (Date.now() % 2000) / 2000;
        const pos = t < 0.5 ? t * 2 * 100 : (1 - (t - 0.5) * 2) * 100;
        bar.style.setProperty('background-position', `0% ${pos}%`, 'important');
        requestAnimationFrame(animateBar);
      };
      requestAnimationFrame(animateBar);
    }

    // Hide expand arrow
    const expand = row.querySelector('.storegen-job-row-expand');
    if (expand) s(expand, { 'display': 'none' });

    // Header
    const header = row.querySelector('.storegen-job-row-header');
    if (header) s(header, { 'display': 'flex', 'align-items': 'center', 'gap': '8px', 'padding': '10px 12px 10px 20px', 'cursor': 'pointer' });

    // Logo
    row.querySelectorAll('.storegen-job-row-logo, svg.storegen-logo').forEach(svg => {
      s(svg, { 'width': '20px', 'height': '20px', 'max-width': '20px', 'max-height': '20px', 'flex-shrink': '0' });
      svg.setAttribute('width', '20');
      svg.setAttribute('height', '20');
    });

    // Title
    const title = row.querySelector('.storegen-job-row-title');
    if (title) s(title, { 'font-weight': '600', 'font-size': '13px', 'color': 'white', 'flex': '1', 'white-space': 'nowrap', 'overflow': 'hidden', 'text-overflow': 'ellipsis' });

    // Hide job ID from header (shown in content)
    const jobId = row.querySelector('.storegen-job-row-id');
    if (jobId) s(jobId, { 'display': 'none' });

    // Close button — hide while working, show when done
    const closeBtn = row.querySelector('.storegen-job-row-close');
    if (closeBtn) {
      if (row.classList.contains('working')) {
        s(closeBtn, { 'display': 'none' });
      } else {
        s(closeBtn, { 'background': 'none', 'border': 'none', 'color': 'rgba(255,255,255,0.7)', 'font-size': '18px', 'cursor': 'pointer', 'padding': '0', 'width': '24px', 'height': '24px', 'display': 'flex', 'align-items': 'center', 'justify-content': 'center' });
      }
    }

    // Cancel button — move from header to content area
    const cancelBtn = row.querySelector('.storegen-job-row-header-cancel');
    const content = row.querySelector('.storegen-job-row-content');
    if (cancelBtn && content && cancelBtn.parentElement !== content) {
      content.appendChild(cancelBtn);
    }
    if (cancelBtn) {
      s(cancelBtn, { 'background': 'transparent', 'color': 'white', 'border': '1px solid rgba(255,255,255,0.3)', 'border-radius': '4px', 'padding': '8px 16px', 'font-size': '13px', 'cursor': 'pointer', 'font-family': 'inherit', 'margin-top': '8px', 'display': 'block', 'width': '100%', 'text-align': 'center', 'box-sizing': 'border-box' });
      cancelBtn.onmouseenter = () => cancelBtn.style.setProperty('background', 'rgba(255,255,255,0.1)', 'important');
      cancelBtn.onmouseleave = () => cancelBtn.style.setProperty('background', 'transparent', 'important');
    }

    // Content area
    if (content) s(content, { 'padding': '0 16px 12px 20px' });

    // Body
    const body = row.querySelector('.storegen-job-row-body');
    if (body) {
      s(body, { 'font-size': '12px', 'line-height': '1.4', 'color': 'rgba(255,255,255,0.9)' });
      body.querySelectorAll('a').forEach(a => s(a, { 'color': '#7dd3fc' }));
    }

    // Links
    const link = row.querySelector('.storegen-job-row-link');
    if (link) s(link, { 'display': 'inline-block', 'padding': '4px 10px', 'margin': '0 16px 12px 16px', 'color': '#7dd3fc', 'font-size': '12px', 'text-decoration': 'none', 'cursor': 'pointer', 'border': '1px solid rgba(125, 211, 252, 0.3)', 'border-radius': '3px' });
  });

  // Also handle legacy .storegen-status-card if present
  const card = document.querySelector('.storegen-status-card');
  if (!card) return;

  // Inject keyframes if not already present (Cloudscape/CSP may strip stylesheet ones)
  if (!document.getElementById('storegen-taskei-keyframes')) {
    const kf = document.createElement('style');
    kf.id = 'storegen-taskei-keyframes';
    kf.textContent = `
      @keyframes storegenGradientShift { 0% { background-position: 0% 0%; } 50% { background-position: 0% 100%; } 100% { background-position: 0% 0%; } }
      @keyframes storegenPulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.6; } }
    `;
    // Try appending to head, and also try adoptedStyleSheets as fallback
    document.head.appendChild(kf);
  }

  // JS-driven gradient animation fallback (CSS keyframes may not work in userscript context)
  if (!card._storegenAnimating && card.classList.contains('working')) {
    card._storegenAnimating = true;
    const animateGradient = () => {
      const bar = card.querySelector('.storegen-taskei-gradient-bar');
      if (!bar || !card.classList.contains('working')) {
        card._storegenAnimating = false;
        return;
      }
      const t = (Date.now() % 2000) / 2000;
      const pos = t < 0.5 ? t * 2 * 100 : (1 - (t - 0.5) * 2) * 100;
      bar.style.setProperty('background-position', `0% ${pos}%`, 'important');
      requestAnimationFrame(animateGradient);
    };
    requestAnimationFrame(animateGradient);
  }

  // JS-driven pulse animation for title
  if (!card._storegenTitleAnimating && card.classList.contains('working')) {
    card._storegenTitleAnimating = true;
    const animatePulse = () => {
      const titleEl = card.querySelector('.storegen-status-title');
      if (!titleEl || !card.classList.contains('working')) {
        if (titleEl) titleEl.style.setProperty('opacity', '1', 'important');
        card._storegenTitleAnimating = false;
        return;
      }
      const t = (Date.now() % 2000) / 2000;
      const opacity = t < 0.5 ? 1 - t * 0.8 : 0.6 + (t - 0.5) * 0.8;
      titleEl.style.setProperty('opacity', String(opacity), 'important');
      requestAnimationFrame(animatePulse);
    };
    requestAnimationFrame(animatePulse);
  }

  s(card, {
    'position': 'fixed', 'bottom': '20px', 'right': '20px', 'z-index': '9999',
    'display': 'flex', 'flex-direction': 'column', 'background': '#16191F', 'color': 'white',
    'border': 'none', 'font-size': '13px',
    'font-family': '"Amazon Ember","Helvetica Neue",Roboto,Arial,sans-serif',
    'box-shadow': '0 8px 24px rgba(0,0,0,0.6)', 'max-width': '500px', 'max-height': '60vh',
    'overflow': 'hidden', 'transition': 'transform 0.3s ease, opacity 0.3s ease',
  });

  // Add gradient bar on the left if not already present
  if (!card.querySelector('.storegen-taskei-gradient-bar')) {
    const bar = document.createElement('div');
    bar.className = 'storegen-taskei-gradient-bar';
    s(bar, {
      'position': 'absolute', 'left': '0', 'top': '0', 'bottom': '0', 'width': '4px',
      'background': 'linear-gradient(180deg, rgba(0,0,0,1) 0%, rgba(0,49,129,1) 10%, rgba(32,116,213,1) 25%, rgba(244,110,187,1) 40%, rgba(255,173,151,1) 50%, rgba(244,110,187,1) 60%, rgba(32,116,213,1) 75%, rgba(0,49,129,1) 90%, rgba(0,0,0,1) 100%)',
      'background-size': '100% 200%', 'z-index': '1',
    });
    card.insertBefore(bar, card.firstChild);
  }

  // Update gradient bar color based on card state
  const bar = card.querySelector('.storegen-taskei-gradient-bar');
  if (bar) {
    if (card.classList.contains('working')) {
      // Animation handled by JS above
      bar.style.removeProperty('display');
    } else if (card.classList.contains('completed')) {
      s(bar, { 'background': '#1e8900', 'background-size': 'auto' });
    } else if (card.classList.contains('failed')) {
      s(bar, { 'background': '#d13212', 'background-size': 'auto' });
    }
  }

  const header = card.querySelector('.storegen-status-header, .storegen-job-row-header');
  if (header) s(header, { 'display': 'flex', 'align-items': 'center', 'gap': '12px', 'padding': '12px 16px 12px 20px', 'flex-shrink': '0' });

  // Fix logo sizing: wrap SVG in a fixed-size container to prevent Cloudscape from blowing it up
  card.querySelectorAll('.storegen-logo, .storegen-job-row-logo').forEach(svg => {
    if (svg.parentElement && svg.parentElement.classList.contains('storegen-logo-wrapper')) return;
    const wrapper = document.createElement('div');
    wrapper.className = 'storegen-logo-wrapper';
    s(wrapper, { 'width': '24px', 'height': '24px', 'min-width': '24px', 'min-height': '24px', 'max-width': '24px', 'max-height': '24px', 'flex-shrink': '0', 'overflow': 'hidden', 'display': 'flex', 'align-items': 'center', 'justify-content': 'center' });
    svg.parentElement.insertBefore(wrapper, svg);
    wrapper.appendChild(svg);
    s(svg, { 'width': '100%', 'height': '100%', 'display': 'block' });
  });

  const title = card.querySelector('.storegen-status-title');
  if (title) {
    s(title, { 'font-weight': '600', 'font-size': '14px', 'flex': '1', 'color': 'white' });
  }

  const closeBtn = card.querySelector('.storegen-status-close');
  if (closeBtn) {
    s(closeBtn, {
      'background': 'none', 'border': 'none', 'color': 'white', 'font-size': '20px',
      'cursor': 'pointer', 'padding': '0', 'width': '24px', 'height': '24px',
      'opacity': '0.7', 'align-items': 'center', 'justify-content': 'center',
      'transition': 'opacity 0.2s ease',
    });
    // Show/hide based on .visible class
    if (closeBtn.classList.contains('visible')) {
      closeBtn.style.setProperty('display', 'flex', 'important');
    } else {
      closeBtn.style.setProperty('display', 'none', 'important');
    }
    closeBtn.onmouseenter = () => closeBtn.style.setProperty('opacity', '1', 'important');
    closeBtn.onmouseleave = () => closeBtn.style.setProperty('opacity', '0.7', 'important');
  }

  const content = card.querySelector('.storegen-status-content');
  if (content) s(content, { 'display': 'flex', 'flex-direction': 'column', 'gap': '8px', 'padding': '0 16px 12px 20px', 'overflow-y': 'auto' });

  const body = card.querySelector('.storegen-status-body');
  if (body) {
    s(body, { 'font-size': '12px', 'line-height': '1.4', 'opacity': '0.9', 'color': 'white' });
    // Style markdown content inside body
    body.querySelectorAll('h1,h2,h3,h4,h5,h6').forEach(h => s(h, { 'color': 'white', 'font-weight': '600', 'margin': '12px 0 8px 0', 'opacity': '1' }));
    body.querySelectorAll('p').forEach(p => s(p, { 'margin': '0 0 8px 0', 'color': 'white' }));
    body.querySelectorAll('ul,ol').forEach(l => s(l, { 'margin': '0 0 8px 0', 'padding-left': '20px', 'color': 'white' }));
    body.querySelectorAll('code').forEach(c => s(c, { 'background': 'rgba(255,255,255,0.15)', 'padding': '2px 6px', 'border-radius': '3px', 'font-family': 'monospace', 'font-size': '11px', 'color': '#e0e0e0', 'border': '1px solid rgba(255,255,255,0.2)' }));
    body.querySelectorAll('pre').forEach(p => s(p, { 'background': 'rgba(255,255,255,0.1)', 'padding': '8px', 'border-radius': '4px', 'overflow-x': 'auto', 'margin': '0 0 8px 0' }));
    body.querySelectorAll('pre code').forEach(c => s(c, { 'background': 'none', 'padding': '0', 'border': 'none' }));
    body.querySelectorAll('strong').forEach(el => s(el, { 'font-weight': '600', 'color': 'white' }));
    body.querySelectorAll('a').forEach(a => {
      s(a, { 'color': '#7dd3fc', 'text-decoration': 'none' });
      a.onmouseenter = () => a.style.setProperty('text-decoration', 'underline', 'important');
      a.onmouseleave = () => a.style.setProperty('text-decoration', 'none', 'important');
    });
  }

  const link = card.querySelector('.storegen-status-link');
  if (link) {
    s(link, { 'color': '#7dd3fc', 'text-decoration': 'none', 'font-size': '12px', 'cursor': 'pointer' });
    link.onmouseenter = () => link.style.setProperty('text-decoration', 'underline', 'important');
    link.onmouseleave = () => link.style.setProperty('text-decoration', 'none', 'important');
  }

  const cancelBtn = card.querySelector('.storegen-status-cancel');
  if (cancelBtn) {
    s(cancelBtn, {
      'background': 'transparent', 'color': 'white', 'border': '1px solid rgba(255,255,255,0.3)',
      'border-radius': '4px', 'padding': '6px 16px', 'font-size': '12px', 'font-weight': '500',
      'cursor': 'pointer', 'font-family': '"Amazon Ember","Helvetica Neue",Roboto,Arial,sans-serif',
      'margin-top': '4px', 'width': 'auto',
    });
    cancelBtn.onmouseenter = () => s(cancelBtn, { 'background': 'rgba(255,255,255,0.1)' });
    cancelBtn.onmouseleave = () => s(cancelBtn, { 'background': 'transparent' });
  }
}

function taskei_task_getUserAlias() {
  // Try aws-userInfo cookie first (works on SIM/amazon.com domains)
  try {
    const match = document.cookie.match(/aws-userInfo=([^;]+)/);
    if (match) {
      const decoded = decodeURIComponent(match[1]);
      const arnMatch = decoded.match(/P-([a-z][a-z0-9]+)/i);
      if (arnMatch) return arnMatch[1].toLowerCase();
    }
  } catch { /* ignore */ }

  // Fallback: extract from Taskei profile button "(alias)" pattern
  try {
    const buttons = document.querySelectorAll('button');
    for (const btn of buttons) {
      const match = btn.textContent.match(/\(([a-z][a-z0-9]+)\)$/i);
      if (match) return match[1].toLowerCase();
    }
  } catch { /* ignore */ }

  return null;
}

function taskei_task_buildTag(taskId) {
  return `browserextension-taskei:${taskId}`;
}

function taskei_task_hasActiveJob() { return taskei_task_activeJobId !== null; }

function extractTaskId() {
  // First check for full task page URL: /tasks/Glue-12345
  const pathMatch = window.location.pathname.match(/\/tasks\/([A-Za-z0-9-]+)/);
  if (pathMatch) return pathMatch[1];
  
  // Check for sidebar panel: /rooms/...?task=UUID
  const urlParams = new URLSearchParams(window.location.search);
  const taskParam = urlParams.get('task');
  if (taskParam) return taskParam;
  
  return null;
}

function taskei_task_showToast(message) {
  const existing = document.querySelector('.storegen-toast');
  if (existing) existing.remove();
  const toast = document.createElement('div');
  toast.className = 'storegen-toast';
  toast.textContent = message;
  toast.style.cssText = `position:fixed;bottom:220px;right:20px;z-index:10001;background:#16191F;color:white;padding:12px 20px;border-radius:4px;font-size:13px;font-family:"Amazon Ember",sans-serif;box-shadow:0 4px 12px rgba(0,0,0,0.4);opacity:0;transition:opacity 0.3s ease;`;
  document.body.appendChild(toast);
  requestAnimationFrame(() => { toast.style.opacity = '1'; });
  setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 300); }, 3000);
}

// Track current task ID to detect navigation between tasks
let currentInitializedTaskId = null;
let specStudioRetryInterval = null;

function initTaskeiTask() {
  const taskId = extractTaskId();
  
  // If no task ID (e.g., sidebar closed), clean up and return
  if (!taskId) {
    if (currentInitializedTaskId) {
      logger_log('Task sidebar closed, cleaning up');
      taskei_task_codegenButton_removeCodeGenButton();
      if (specStudioRetryInterval) { clearInterval(specStudioRetryInterval); specStudioRetryInterval = null; }
      removeSpecStudioButton();
      currentInitializedTaskId = null;
    }
    return;
  }

  // Skip if already initialized for this task
  if (currentInitializedTaskId === taskId) {
    logger_log('Taskei task already initialized for:', taskId);
    return;
  }

  // Clean up previous task's button if navigating between tasks
  if (currentInitializedTaskId && currentInitializedTaskId !== taskId) {
    logger_log('Navigating from task', currentInitializedTaskId, 'to', taskId);
    taskei_task_codegenButton_removeCodeGenButton();
    if (specStudioRetryInterval) { clearInterval(specStudioRetryInterval); specStudioRetryInterval = null; }
    removeSpecStudioButton();
  }

  currentInitializedTaskId = taskId;
  logger_log('Initializing Taskei task page:', taskId);
  injectStyles();

  // Watch for status cards being added to body and force-style them (only once)
  if (!window._storegenTaskeiObserver) {
    window._storegenTaskeiObserver = new MutationObserver(() => forceStatusCardStyles());
    window._storegenTaskeiObserver.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
  }

  // Inject high-specificity CSS to constrain job row elements on Cloudscape
  if (!document.getElementById('storegen-taskei-job-styles')) {
    const style = document.createElement('style');
    style.id = 'storegen-taskei-job-styles';
    style.textContent = `
      .storegen-jobs-container { position: fixed !important; bottom: 20px !important; right: 20px !important; z-index: 9999 !important; max-width: 500px !important; }
      .storegen-job-row { background: #16191F !important; color: white !important; font-family: "Amazon Ember","Helvetica Neue",Roboto,Arial,sans-serif !important; box-shadow: 0 8px 24px rgba(0,0,0,0.6) !important; overflow: hidden !important; border-radius: 4px !important; margin-bottom: 8px !important; }
      .storegen-job-row-header { display: flex !important; align-items: center !important; gap: 8px !important; padding: 10px 12px 10px 16px !important; cursor: pointer !important; }
      .storegen-job-row-logo, .storegen-job-row svg.storegen-logo { width: 20px !important; height: 20px !important; max-width: 20px !important; max-height: 20px !important; flex-shrink: 0 !important; }
      .storegen-job-row-title { font-weight: 600 !important; font-size: 13px !important; color: white !important; flex: 1 !important; white-space: nowrap !important; }
      .storegen-job-row-id { display: none !important; }
      .storegen-job-row-expand { color: rgba(255,255,255,0.5) !important; font-size: 10px !important; }
      .storegen-job-row-content { padding: 0 16px 12px 16px !important; }
      .storegen-job-row-body { font-size: 12px !important; color: rgba(255,255,255,0.9) !important; line-height: 1.4 !important; }
      .storegen-job-row-body a { color: #7dd3fc !important; }
      .storegen-job-row-link { display: inline-block !important; padding: 4px 10px !important; margin: 0 16px 12px 16px !important; color: #7dd3fc !important; font-size: 12px !important; text-decoration: none !important; cursor: pointer !important; border: 1px solid rgba(125, 211, 252, 0.3) !important; border-radius: 3px !important; }
      .storegen-job-row-link:hover { border-color: rgba(125, 211, 252, 0.6) !important; }
      .storegen-job-row-close { background: none !important; border: none !important; color: rgba(255,255,255,0.7) !important; font-size: 18px !important; cursor: pointer !important; padding: 0 !important; width: 24px !important; height: 24px !important; display: flex !important; align-items: center !important; justify-content: center !important; }
      .storegen-job-row-close:hover { color: white !important; }
      .storegen-job-row-header-cancel { background: transparent !important; color: white !important; border: 1px solid rgba(255,255,255,0.3) !important; border-radius: 4px !important; padding: 4px 12px !important; font-size: 12px !important; cursor: pointer !important; font-family: inherit !important; }
      .storegen-job-row-header-cancel:hover { background: rgba(255,255,255,0.1) !important; }
      .storegen-job-row-status-icon { font-size: 12px !important; }
      .storegen-job-row-status-icon.working::after { content: "⏳" !important; }
      .storegen-job-row-status-icon.completed::after { content: "✅" !important; }
      .storegen-job-row-status-icon.failed::after { content: "❌" !important; }
      .storegen-job-row-status-icon.cancelled::after { content: "⚪" !important; }
    `;
    document.head.appendChild(style);
  }

  logger_log('Taskei task:', taskId);

  const renderMarkdown = window.markdownit
    ? (md) => window.markdownit({ linkify: true }).render(md)
    : (md) => md;

  const alias = taskei_task_getUserAlias();

  // Check for active job via API using task-based tag (no alias needed on Taskei)
  const tag = taskei_task_buildTag(taskId);
  const storageKey = `storegen_taskei_task_${taskId}`;
  fetchJobsByTag(tag, 1,
    (jobs) => {
      if (jobs.length > 0 && jobs[0].status === 'IN_PROGRESS') {
        const job = jobs[0];
        if (isCancelledJob(job.jobId)) {
          logger_log('Skipping cancelled job:', job.jobId);
        } else {
          logger_log('Found active job from API:', job.jobId);
          taskei_task_activeJobId = job.jobId;
          simTaskeiStatusCard_createJobBanner(job.jobId, sanitizeUrl(job.jobUrl || job.viewLogsUrl), storageKey, renderMarkdown,
            () => { markJobCancelled(job.jobId); taskei_task_activeJobId = null; localStorage.removeItem(storageKey); },
            "Creating a Code Review...", true);
        }
      }
    },
    (error) => {
      logger_log('Error checking active jobs:', error);
      // Fallback to localStorage if API fails
      const stored = localStorage.getItem(storageKey);
      if (stored) {
        try {
          const data = JSON.parse(stored);
          if (data.status === 'IN_PROGRESS') {
            if (isCancelledJob(data.jobId)) {
              logger_log('Skipping cancelled job from localStorage:', data.jobId);
              localStorage.removeItem(storageKey);
            } else {
              logger_log('Restoring from localStorage fallback:', data.jobId);
              taskei_task_activeJobId = data.jobId;
              simTaskeiStatusCard_createJobBanner(data.jobId, sanitizeUrl(data.jobUrl || data.viewLogsUrl), storageKey, renderMarkdown,
                () => { markJobCancelled(data.jobId); taskei_task_activeJobId = null; localStorage.removeItem(storageKey); },
                "Creating a Code Review...", true);
            }
          }
        } catch (e) {
          localStorage.removeItem(storageKey);
        }
      }
    }
  );

  // Insert button with retries
  const tryInsert = () => {
    const button = taskei_task_codegenButton_createCodeGenButton(taskId, () => taskei_task_handleCodeGenClick(taskId, renderMarkdown));
    return taskei_task_codegenButton_insertCodeGenButton(button);
  };

  if (!tryInsert()) {
    let retryCount = 0;
    const retryInterval = setInterval(() => {
      retryCount++;
      if (tryInsert() || retryCount >= 10) clearInterval(retryInterval);
    }, 500);
  }

  const specBtn = createSpecStudioButton();
  if (!insertSpecStudioButton(specBtn)) {
    let specStudioRetryCount = 0;
    specStudioRetryInterval = setInterval(() => {
      specStudioRetryCount++;
      if (insertSpecStudioButton(specBtn)) {
        clearInterval(specStudioRetryInterval);
        specStudioRetryInterval = null;
        return;
      }
      if (specStudioRetryCount >= 20) {
        clearInterval(specStudioRetryInterval);
        specStudioRetryInterval = null;
        removeSpecStudioButton();
      }
    }, 500);
  }
}

/**
 * Scrapes internal Amazon links from the Taskei task description and comments
 * @param {string} currentTaskId - Current task ID to exclude self-references
 * @returns {string[]} Array of unique internal URLs found
 */
function taskei_task_scrapeLinksFromPage(currentTaskId) {
  const ALLOWED_DOMAINS = ['amazon.com', 'amazon.dev', 'amazon.work', 'aws.dev', 'a2z.com', 'quip-amazon.com'];
  const MAX_AUTO_LINKS = 5;

  // Taskei navigation paths to exclude
  const EXCLUDED_PATHS = [
    '/dashboard', '/changes', '/retrospectives', '/rooms/', '/login', '/logout',
  ];

  const isAllowed = (url) => {
    try {
      const parsed = new URL(url);
      const hostname = parsed.hostname.toLowerCase();
      const pathname = parsed.pathname.toLowerCase();

      if (!ALLOWED_DOMAINS.some(d => hostname === d || hostname.endsWith('.' + d))) return false;
      if (EXCLUDED_PATHS.some(p => pathname.startsWith(p))) return false;
      if (pathname === '/' || pathname === '') return false;
      // Exclude Taskei task self-references
      if (hostname.includes('taskei.amazon.dev') && pathname.startsWith('/tasks/')) return false;
      // Exclude AWS Console URLs (not readable content)
      if (hostname.includes('console.aws.amazon.com')) return false;
      // Exclude CodeGen job URLs (self-generated by this extension)
      if (hostname.includes('codegen.harmony.a2z.com')) return false;
      return true;
    } catch { return false; }
  };

  const seen = new Set();
  const urls = [];

  // Scrape from description and comments
  const contentSelectors = [
    '[data-testid="description-section"]',
    '[data-testid*="comment"]',
  ];

  for (const selector of contentSelectors) {
    const sections = document.querySelectorAll(selector);
    for (const section of sections) {
      const links = section.querySelectorAll('a[href]');
      for (const link of links) {
        const href = link.href;
        if (!href || href.startsWith('javascript:') || href.startsWith('#')) continue;
        if (seen.has(href)) continue;
        seen.add(href);
        if (isAllowed(href)) {
          urls.push(href);
          if (urls.length >= MAX_AUTO_LINKS) return urls;
        }
      }
    }
  }

  return urls;
}

function taskei_task_handleCodeGenClick(taskId, renderMarkdown) {
  const existingCard = document.querySelector('.storegen-status-card');
  
  // If a job is still actively in progress (card has 'working' class), block
  if (taskei_task_activeJobId && existingCard && existingCard.classList.contains('working')) {
    taskei_task_showToast('A job is already in progress. Please wait for it to finish.');
    return;
  }
  
  // Close any existing results card (completed/failed/cancelled) and reset state
  if (existingCard) {
    existingCard.remove();
    taskei_task_activeJobId = null;
  }

  const taskDescription = extractTaskDescription();
  const scrapedLinks = taskei_task_scrapeLinksFromPage(taskId);

  const modal = taskei_task_instructionsModal_createInstructionsModal(
    taskId,
    taskDescription,
    (packageNames, taskUrl, referenceLinks) => taskei_task_handleSubmit(taskId, packageNames, taskUrl, referenceLinks, modal, renderMarkdown),
    () => {},
    scrapedLinks
  );

  taskei_task_instructionsModal_openModal(modal);
}

function extractTaskDescription() {
  const section = document.querySelector('[data-testid="description-section"]');
  if (section) {
    // Clone to avoid modifying the page
    const clone = section.cloneNode(true);
    // Remove buttons, links that are UI chrome (Edit, Description label, etc.)
    clone.querySelectorAll('button, [role="button"]').forEach(el => el.remove());
    // Get the text, stripping the "Description" heading if present
    let text = clone.textContent.trim();
    // Remove leading "Description" label that Cloudscape prepends
    text = text.replace(/^Description\s*/i, '');
    if (text && text.length > 10) return text;
  }
  return '';
}

async function taskei_task_handleSubmit(taskId, packageNames, taskUrl, referenceLinks, modal, renderMarkdown) {
  logger_log('Submitting CodeGen job for task:', taskId);

  if (taskei_task_hasActiveJob()) {
    taskei_task_instructionsModal_showInfo(modal, 'Another job is still in progress.');
    return;
  }

  taskei_task_instructionsModal_setLoading(modal, true);

  // Check package visibility before submitting
  const visibility = await checkMultiplePackages(packageNames);
  if (!visibility.allPublic) {
    taskei_task_instructionsModal_setLoading(modal, false);
    taskei_task_instructionsModal_showError(modal, `Private package(s) detected: ${visibility.privatePackages.join(', ')}. CodeGen only supports public packages.`);
    return;
  }

  const formattedInstructions = `
Package(s): ${packageNames.join(', ')}

Read the Taskei ticket at ${taskUrl} and implement the code changes described in its description and comments.
  `.trim();

  const tag = taskei_task_buildTag(taskId);
  const storageKey = `storegen_taskei_task_${taskId}`;

  submitJobWithInstructions(
    formattedInstructions,
    (jobId, jobUrl) => {
      logger_log('Job submitted:', jobId);
      taskei_task_activeJobId = jobId;

      // Save to localStorage for restore on refresh
      localStorage.setItem(storageKey, JSON.stringify({
        jobId, jobUrl, timestamp: Date.now(), status: 'IN_PROGRESS'
      }));

      taskei_task_instructionsModal_closeModal(modal);
      simTaskeiStatusCard_createJobBanner(jobId, sanitizeUrl(jobUrl), storageKey, renderMarkdown,
        () => {
          markJobCancelled(jobId);
          taskei_task_activeJobId = null;
          localStorage.removeItem(storageKey);
        }, "Creating a Code Review...", true);
    },
    (errorMessage) => {
      logger_log('Error:', errorMessage);
      taskei_task_instructionsModal_showError(modal, `Failed to submit job: ${errorMessage}`);
      taskei_task_instructionsModal_setLoading(modal, false);
    },
    tag,
    referenceLinks.length > 0 ? referenceLinks : null
  );
}

;// ./src/features/jira/jira-issue/codegenButton.js
// CodeGen button for Jira issues



/**
 * Creates the CodeGen button element
 * @param {Function} onClick - Click handler
 * @returns {HTMLElement} Button element
 */
function jira_issue_codegenButton_createCodeGenButton(onClick) {
  const button = document.createElement('button');
  button.id = 'storegen-codegen-button';
  button.className = 'storegen-package-header-button';
  button.style.marginLeft = '8px';
  
  const logo = logo_createStoreGenLogo();
  logo.style.width = '16px';
  logo.style.height = '16px';
  logo.style.marginRight = '5px';
  logo.style.flexShrink = '0';
  
  const text = document.createElement('span');
  text.textContent = 'Generate Code';
  text.style.fontSize = '13px';
  text.style.lineHeight = '1';
  
  button.appendChild(logo);
  button.appendChild(text);
  
  button.addEventListener('click', onClick);
  
  return button;
}

/**
 * Inserts the button into the Jira page
 * @param {HTMLElement} button - Button element to insert
 */
function jira_issue_codegenButton_insertCodeGenButton(button) {
  const existing = document.getElementById('storegen-codegen-button');
  if (existing) {
    return;
  }

  // Atlassian Cloud selector, then JIRA Server selectors
  const container = document.querySelector('.css-1pjflpu') ||
                    document.querySelector('#opsbar-operations') ||
                    document.querySelector('#stalker .aui-toolbar2');
  if (container) {
    container.appendChild(button);
    logger_log('CodeGen button inserted');
  }
}

/**
 * Removes the CodeGen button from the page
 */
function jira_issue_codegenButton_removeCodeGenButton() {
  const button = document.getElementById('storegen-codegen-button');
  if (button) {
    button.remove();
    logger_log('CodeGen button removed');
  }
}

;// ./src/features/jira/jira-issue/instructionsModal.js
// Instructions modal for Jira issues


let modal = null;
let instructionsModal_textarea = null;
let submitButton = null;
let errorDiv = null;
let infoDiv = null;

/**
 * Creates the instructions modal
 * @param {Function} onSubmit - Submit handler
 * @param {Function} onCancel - Cancel handler
 */
function jira_issue_instructionsModal_createInstructionsModal(onSubmit, onCancel) {
  if (modal) {
    return;
  }
  
  modal = document.createElement('div');
  modal.id = 'storegen-instructions-modal';
  modal.style.cssText = `
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 10000;
    justify-content: center;
    align-items: center;
  `;
  
  const content = document.createElement('div');
  content.style.cssText = `
    background: white;
    padding: 24px;
    border-radius: 8px;
    width: 600px;
    max-width: 90%;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  `;
  
  const title = document.createElement('h2');
  title.textContent = 'Generate Code for Jira Issue';
  title.style.cssText = 'margin: 0 0 16px 0; font-size: 20px;';
  
  const description = document.createElement('p');
  description.textContent = 'Describe what code changes you want CodeGen to make:';
  description.style.cssText = 'margin: 0 0 12px 0; color: #666;';
  
  instructionsModal_textarea = document.createElement('textarea');
  instructionsModal_textarea.placeholder = 'Example: Fix the bug described in this Jira issue';
  instructionsModal_textarea.style.cssText = `
    width: 100%;
    height: 150px;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-family: inherit;
    font-size: 14px;
    resize: vertical;
    box-sizing: border-box;
  `;
  
  errorDiv = document.createElement('div');
  errorDiv.style.cssText = `
    display: none;
    margin-top: 12px;
    padding: 12px;
    background: #fee;
    border: 1px solid #fcc;
    border-radius: 4px;
    color: #c00;
  `;
  
  infoDiv = document.createElement('div');
  infoDiv.style.cssText = `
    display: none;
    margin-top: 12px;
    padding: 12px;
    background: #e7f3ff;
    border: 1px solid #b3d9ff;
    border-radius: 4px;
    color: #004085;
  `;
  
  const buttonContainer = document.createElement('div');
  buttonContainer.style.cssText = 'margin-top: 16px; display: flex; gap: 8px; justify-content: flex-end;';
  
  const cancelButton = document.createElement('button');
  cancelButton.textContent = 'Cancel';
  cancelButton.style.cssText = `
    padding: 8px 16px;
    background: #f0f0f0;
    border: 1px solid #ddd;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
  `;
  cancelButton.addEventListener('click', () => {
    jira_issue_instructionsModal_closeModal();
    onCancel();
  });
  
  submitButton = document.createElement('button');
  submitButton.textContent = 'Submit';
  submitButton.style.cssText = `
    padding: 8px 16px;
    background: linear-gradient(90deg, #003181 0%, #2074d5 50%, #f46ebb 85%, #ffad97 100%);
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
  `;
  submitButton.addEventListener('click', () => {
    const instructions = instructionsModal_textarea.value.trim();
    if (!instructions) {
      jira_issue_instructionsModal_showError('Please enter instructions');
      return;
    }
    onSubmit(instructions);
  });
  
  buttonContainer.appendChild(cancelButton);
  buttonContainer.appendChild(submitButton);
  
  content.appendChild(title);
  content.appendChild(description);
  content.appendChild(instructionsModal_textarea);
  content.appendChild(errorDiv);
  content.appendChild(infoDiv);
  content.appendChild(buttonContainer);
  
  modal.appendChild(content);
  document.body.appendChild(modal);
  
  logger_log('Instructions modal created');
}

/**
 * Opens the modal
 * @param {string} initialText - Initial text to populate in textarea
 */
function jira_issue_instructionsModal_openModal(initialText = '') {
  if (modal) {
    modal.style.display = 'flex';
    instructionsModal_textarea.value = initialText;
    errorDiv.style.display = 'none';
    infoDiv.style.display = 'none';
    instructionsModal_textarea.focus();
  }
}

/**
 * Closes the modal
 */
function jira_issue_instructionsModal_closeModal() {
  if (modal) {
    modal.style.display = 'none';
  }
}

/**
 * Shows an error message
 * @param {string} message - Error message
 */
function jira_issue_instructionsModal_showError(message) {
  if (errorDiv) {
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    infoDiv.style.display = 'none';
  }
}

/**
 * Shows an info message
 * @param {string} message - Info message
 */
function jira_issue_instructionsModal_showInfo(message) {
  if (infoDiv) {
    infoDiv.textContent = message;
    infoDiv.style.display = 'block';
    errorDiv.style.display = 'none';
  }
}

/**
 * Sets loading state
 * @param {boolean} loading - Loading state
 */
function jira_issue_instructionsModal_setLoading(loading) {
  if (submitButton) {
    submitButton.disabled = loading;
    submitButton.textContent = loading ? 'Submitting...' : 'Submit';
  }
}

;// ./src/features/jira/jira-issue/index.js
// Jira issue page integration










let jira_issue_activeJobId = null;

/**
 * Gets the user alias from cookies or page
 * @returns {string|null} User alias or null
 */
function jira_issue_getUserAlias() {
  try {
    // Atlassian Cloud: extract from aws-userInfo cookie
    const match = document.cookie.match(/aws-userInfo=([^;]+)/);
    if (match) {
      const decoded = decodeURIComponent(match[1]);
      const arnMatch = decoded.match(/P-([a-z][a-z0-9]+)/i);
      if (arnMatch) {
        return arnMatch[1].toLowerCase();
      }
    }

    // JIRA Server (labcollab.net): extract from meta tag
    const remoteUser = document.querySelector('meta[name="ajs-remote-user"]');
    if (remoteUser && remoteUser.getAttribute('content')) {
      return remoteUser.getAttribute('content').toLowerCase();
    }
  } catch (e) {
    logger_log('Error extracting alias from cookie:', e);
  }

  return null;
}

/**
 * Builds the tag for a Jira job
 * @param {string} issueKey - Issue key (e.g., PROJ-123)
 * @returns {string} Tag string
 */
function jira_issue_buildTag(issueKey) {
  return `browserextension-jira:${issueKey}`;
}

/**
 * Checks if there's an active job (in-memory check)
 * @returns {boolean} True if active job exists
 */
function jira_issue_hasActiveJob() {
  return jira_issue_activeJobId !== null;
}

/**
 * Gets the Jira issue description
 * @returns {string} Issue description text
 */
function getIssueDescription() {
  const descElement = document.querySelector('[data-testid="issue.views.field.rich-text.description"]') ||
                      document.querySelector('.description-field') ||
                      document.querySelector('#description-val');
  return descElement ? descElement.innerText.trim() : '';
}

/**
 * Initializes the Jira issue page functionality
 */
function initJiraIssue() {
  logger_log('Initializing Jira issue page');
  
  injectStyles();
  
  if (!document.getElementById('storegen-jira-link-styles')) {
    const jiraStyle = document.createElement('style');
    jiraStyle.id = 'storegen-jira-link-styles';
    jiraStyle.textContent = `.storegen-status-link { border: none !important; padding: 0 !important; border-radius: 0 !important; }`;
    document.head.appendChild(jiraStyle);
  }
  
  const issueKey = extractIssueKey();
  if (!issueKey) {
    return;
  }
  
  logger_log('Jira issue page:', issueKey);
  
  const renderMarkdown = window.markdownit ? 
    (md) => window.markdownit({ linkify: true }).render(md) :
    (md) => md;
  
  const alias = jira_issue_getUserAlias();
  
  if (alias) {
    const tag = jira_issue_buildTag(issueKey);
    fetchJobsByTag(tag, 1,
      (jobs) => {
        if (jobs.length > 0 && jobs[0].status === 'IN_PROGRESS') {
          const job = jobs[0];
          logger_log('Found active job from API:', job.jobId);
          jira_issue_activeJobId = job.jobId;
          simTaskeiStatusCard_createJobBanner(
            job.jobId,
            job.jobUrl || job.viewLogsUrl,
            null,
            renderMarkdown,
            () => {
              markJobCancelled(job.jobId);
              jira_issue_activeJobId = null;
            },
            "Creating a Code Review...",
            true
          );
        }
      },
      (error) => {
        logger_log('Error checking for active jobs:', error);
      }
    );
  } else {
    const storageKey = `storegen_jira_issue_${issueKey}`;
    const stored = localStorage.getItem(storageKey);
    if (stored) {
      try {
        const data = JSON.parse(stored);
        if (data.status === 'IN_PROGRESS') {
          logger_log('Restoring active job from localStorage (no alias):', data.jobId);
          jira_issue_activeJobId = data.jobId;
          simTaskeiStatusCard_createJobBanner(
            data.jobId,
            data.jobUrl || data.viewLogsUrl,
            storageKey,
            renderMarkdown,
            () => {
              logger_log('localStorage fallback: status card closed');
              markJobCancelled(data.jobId);
              jira_issue_activeJobId = null;
              localStorage.removeItem(storageKey);
            },
            "Creating a Code Review...",
            true
          );
        }
      } catch (e) {
        logger_log('Error restoring job from localStorage:', e);
        localStorage.removeItem(storageKey);
      }
    }
  }
  
  const tryInsert = () => {
    // Atlassian Cloud selector, then JIRA Server selectors
    const container = document.querySelector('.css-1pjflpu') ||
                      document.querySelector('#opsbar-operations') ||
                      document.querySelector('#stalker .aui-toolbar2');
    if (!container) {
      return false;
    }

    if (document.getElementById('storegen-codegen-button')) {
      return true;
    }

    if (jira_issue_hasActiveJob()) {
      return true;
    }

    const button = jira_issue_codegenButton_createCodeGenButton(() => {
      const description = getIssueDescription();
      jira_issue_instructionsModal_openModal(description);
    });

    jira_issue_codegenButton_insertCodeGenButton(button);
    return true;
  };
  
  // Keep observing to re-insert if removed
  const observer = new MutationObserver(() => {
    tryInsert();
  });
  
  observer.observe(document.body, { childList: true, subtree: true });
  tryInsert();
  
  jira_issue_instructionsModal_createInstructionsModal(
    (instructions) => jira_issue_handleSubmit(issueKey, instructions, renderMarkdown),
    () => jira_issue_instructionsModal_closeModal()
  );
}

/**
 * Extracts the issue key from the URL
 * @returns {string|null} Issue key or null
 */
function extractIssueKey() {
  const match = window.location.pathname.match(/\/browse\/([A-Z]+-\d+)/);
  return match ? match[1] : null;
}

/**
 * Handles job submission
 */
function jira_issue_handleSubmit(issueKey, instructions, renderMarkdown) {
  if (jira_issue_hasActiveJob()) {
    jira_issue_instructionsModal_showError('A job is already in progress for this issue.');
    return;
  }
  
  jira_issue_instructionsModal_setLoading(true);
  
  const issueUrl = window.location.href;
  const tag = jira_issue_buildTag(issueKey);
  const alias = jira_issue_getUserAlias();
  
  const fullInstructions = `${instructions}\n\nJira Issue: ${issueUrl}`;
  
  submitJobWithInstructions(
    fullInstructions,
    (jobId, jobUrl) => {
      logger_log('Job submitted:', jobId);
      jira_issue_activeJobId = jobId;
      
      const storageKey = `storegen_jira_issue_${issueKey}`;
      if (!alias) {
        localStorage.setItem(storageKey, JSON.stringify({
          jobId,
          jobUrl,
          status: 'IN_PROGRESS'
        }));
      }
      
      jira_issue_instructionsModal_closeModal();
      jira_issue_codegenButton_removeCodeGenButton();
      
      simTaskeiStatusCard_createJobBanner(
        jobId,
        jobUrl,
        alias ? null : storageKey,
        renderMarkdown,
        () => {
          logger_log('Job banner closed');
          markJobCancelled(jobId);
          jira_issue_activeJobId = null;
          if (!alias) {
            localStorage.removeItem(storageKey);
          }
          
          const button = jira_issue_codegenButton_createCodeGenButton(() => {
            jira_issue_instructionsModal_openModal();
          });
          jira_issue_codegenButton_insertCodeGenButton(button);
        },
        "Creating a Code Review...",
        true
      );
    },
    (error) => {
      logger_log('Error submitting job:', error);
      jira_issue_instructionsModal_showError(`Failed to submit job: ${error}`);
      jira_issue_instructionsModal_setLoading(false);
    },
    tag
  );
}

;// ./src/features/asana/asana-tasks/pageDetection.js
/**
 * Asana Page Detection Module
 * 
 * This module handles detection of Asana task pages and extraction of task
 * identifiers from URLs. It determines when the CodeGen integration should
 * be activated based on the current page context.
 * 
 * @module features/asana/asana-tasks/pageDetection
 */

/**
 * Checks if current page is an Asana task page
 * @returns {boolean} True if on Asana task page
 */
function isAsanaTaskPage() {
  const hostname = window.location.hostname;
  const pathname = window.location.pathname;
  
  // Check for app.asana.com hostname (exact match, no subdomains)
  if (hostname !== 'app.asana.com') {
    return false;
  }
  
  // Verify URL path contains "/task/" pattern
  // Asana task URLs follow patterns like:
  // - /0/{workspace_id}/task/{task_id}
  // - /0/{workspace_id}/{project_id}/task/{task_id}
  if (!pathname.includes('/task/')) {
    return false;
  }
  
  return true;
}

/**
 * Extracts task ID from Asana URL
 * @returns {string|null} Task ID or null if not found
 */
function getTaskId() {
  const pathname = window.location.pathname;
  
  // Asana task URLs follow patterns like:
  // - /0/{workspace_id}/task/{task_id}
  // - /0/{workspace_id}/{project_id}/task/{task_id}
  // Extract the task ID that appears after "/task/"
  
  const taskMatch = pathname.match(/\/task\/(\d+)/);
  
  if (taskMatch && taskMatch[1]) {
    return taskMatch[1];
  }
  
  return null;
}

/**
 * Gets the full task URL for context
 * @returns {string} Current page URL
 */
function getTaskUrl() {
  return window.location.href;
}

;// ./src/features/asana/asana-tasks/taskExtraction.js
/**
 * Asana Task Extraction Module
 * 
 * This module handles extraction of task information from the Asana DOM.
 * It retrieves task names, descriptions, and formats them for CodeGen prompts.
 * 
 * @module features/asana/asana-tasks/taskExtraction
 */

/**
 * Extracts task name from Asana DOM
 * @returns {string} Task name or empty string
 */
function extractTaskName() {
  try {
    const titleInput = document.querySelector('.TitleInput textarea.AutogrowTextarea-input');
    if (titleInput && titleInput.value) {
      return titleInput.value.trim();
    }
    return '';
  } catch (error) {
    console.error('Error extracting task name:', error);
    return '';
  }
}

/**
 * Extracts task description from Asana DOM
 * @returns {string} Task description or empty string
 */
function taskExtraction_extractTaskDescription() {
  try {
    // Look for the ProseMirror editor in the TaskDescription section
    const descriptionEditor = document.querySelector('.TaskDescription .ProsemirrorEditor');
    if (descriptionEditor) {
      // Extract plain text content from the editor
      const textContent = descriptionEditor.textContent || descriptionEditor.innerText;
      if (textContent) {
        return textContent.trim();
      }
    }
    return '';
  } catch (error) {
    console.error('Error extracting task description:', error);
    return '';
  }
}

/**
 * Formats task information for CodeGen prompt
 * @param {string} taskName - Task name
 * @param {string} taskDescription - Task description
 * @param {string} taskUrl - Task URL
 * @returns {string} Formatted prompt text
 */
function formatTaskPrompt(taskName, taskDescription, taskUrl) {
  const parts = [];
  
  // Add task name if present
  if (taskName && taskName.trim()) {
    parts.push(`Task: ${taskName.trim()}`);
  }
  
  // Add description if present
  if (taskDescription && taskDescription.trim()) {
    parts.push(taskDescription.trim());
  }
  
  // Always add package prompt
  parts.push(`Package name: <INSERT PACKAGE>`);

  // Always add task URL
  parts.push(`Asana Task: ${taskUrl}`);
  
  return parts.join('\n\n');
}

;// ./src/features/asana/asana-tasks/buttonInsertion.js
/**
 * Asana Button Insertion Module
 * 
 * This module handles insertion of the CodeGen button into the Asana task pane UI.
 * It finds the appropriate insertion point and manages button placement.
 * 
 * @module features/asana/asana-tasks/buttonInsertion
 */

/**
 * Finds the appropriate insertion point in task pane
 * @returns {HTMLElement|null} Container element or null
 */
function findInsertionPoint() {
  // Query DOM for task pane container
  const container = document.querySelector('.TaskPaneFields');
  
  // Return null if not found
  if (!container) {
    return null;
  }
  
  return container;
}

/**
 * Inserts CodeGen button into Asana task pane
 * @param {HTMLElement} button - Button element to insert
 * @returns {boolean} True if insertion succeeded
 */
function insertButtonIntoAsana(button) {
  // Find the insertion point
  const container = findInsertionPoint();
  if (!container) {
    return false;
  }
  
  // Create wrapper div for button
  const wrapper = document.createElement('div');
  wrapper.id = 'storegen-asana-button-wrapper';
  wrapper.style.marginBottom = '16px';
  wrapper.style.paddingBottom = '16px';
  wrapper.style.borderBottom = '1px solid #e0e0e0';
  
  // Add button to wrapper
  wrapper.appendChild(button);
  
  // Insert button at top of task pane (beginning of container)
  container.insertBefore(wrapper, container.firstChild);
  
  return true;
}

;// ./src/features/asana/asana-tasks/index.js
/**
 * Asana Tasks Integration - Main Entry Point
 * 
 * This module initializes the CodeGen integration for Asana task pages.
 * It coordinates page detection, button insertion, and task data extraction
 * to enable code generation from Asana tasks.
 * 
 * @module features/asana/asana-tasks
 */













// Constants for button insertion retry
const asana_tasks_BUTTON_INSERT_RETRY_DELAY_MS = 500;
const MAX_BUTTON_INSERT_ATTEMPTS = 10;

// Track current task ID to detect navigation
let currentTaskId = null;
// Track current job banner to remove it when navigating away
let currentJobBanner = null;

/**
 * Initializes Asana task integration
 * @param {Function} renderMarkdown - Markdown renderer from core
 */
function initAsanaTasks(renderMarkdown) {
  // Initialization guard to prevent duplicate observers
  if (window.__storegenAsanaTasksInitialized) {
    return;
  }
  window.__storegenAsanaTasksInitialized = true;

  logger_log("Initializing CodeGen for Asana (SPA-aware)");

  // Inject shared styles once
  injectStyles();

  /**
   * Gets the storage key for the current Asana task
   * @returns {string} Storage key in format "asana-task-{taskId}"
   */
  const getAsanaStorageKey = () => {
    const taskId = getTaskId();
    return `asana-task-${taskId}`;
  };

  /**
   * Renders job history pills for the current task
   */
  const renderJobPillsWrapper = () => {
    const storageKey = getAsanaStorageKey();
    renderJobPills(storageKey, (job) => reopenJobStatusCard(job, renderMarkdown));
  };

  /**
   * Opens the instructions modal with task information prefilled
   */
  const openInstructionsModal = () => {
    // Extract task information
    const taskName = extractTaskName();
    const taskDescription = taskExtraction_extractTaskDescription();
    const taskUrl = getTaskUrl();

    logger_log("Extracted task info:", { taskName, taskDescription, taskUrl });

    // Format initial prompt
    const initialPrompt = formatTaskPrompt(taskName, taskDescription, taskUrl);

    // Create and open modal with prefilled prompt
    const modal = createInstructionsModal(
      'Asana Task',
      null, // No file context for Asana
      (instructions, includeFileContext, referenceLinks) => {
        logger_log("Instructions submitted:", instructions);
        logger_log("Reference links count:", referenceLinks.length);

        setLoading(modal, true);

        const storageKey = getAsanaStorageKey();

        // Submit CodeGen job
        submitJobWithInstructions(
          instructions,
          (jobId, jobUrl) => {
            logger_log("Job submitted successfully:", jobId);
            closeModal(modal);
            
            // Store job ID for persistence
            setStoredJob(storageKey, jobId);
            
            // Create status banner to track job progress
            currentJobBanner = createJobBanner(
              jobId,
              jobUrl,
              storageKey,
              renderMarkdown,
              () => {
                logger_log("Status banner closed for Asana task");
                currentJobBanner = null;
                renderJobPillsWrapper();
              },
              "Processing Asana task..."
            );
          },
          (errorMessage) => {
            logger_log("Job submission failed:", errorMessage);
            setLoading(modal, false);
            showError(modal, `Failed to submit job: ${errorMessage}`);
          },
          "browserextension-asana",
          referenceLinks
        );
      },
      () => {
        logger_log("Modal cancelled");
      },
      initialPrompt
    );

    openModal(modal);
  };

  /**
   * Attempts to insert the CodeGen button into Asana UI
   * @param {number} attemptCount - Current attempt number
   */
  const tryInsertButton = (attemptCount = 1) => {
    // Check if button already exists
    if (document.getElementById('storegen-codegen-button')) {
      logger_log("Button already exists, skipping insertion");
      return;
    }

    // Create CodeGen button
    const button = createCodeGenButton('Asana Task', () => {
      logger_log("CodeGen button clicked for Asana task");
      openInstructionsModal();
    });

    // Attempt to insert button
    const inserted = insertButtonIntoAsana(button);
    
    if (inserted) {
      logger_log("CodeGen button inserted successfully");
    } else if (attemptCount < MAX_BUTTON_INSERT_ATTEMPTS) {
      logger_log(`Button insertion failed, retrying (attempt ${attemptCount + 1}/${MAX_BUTTON_INSERT_ATTEMPTS})`);
      setTimeout(() => tryInsertButton(attemptCount + 1), asana_tasks_BUTTON_INSERT_RETRY_DELAY_MS);
    } else {
      logger_log("Failed to insert button after maximum attempts");
    }
  };

  /**
   * Handles task page changes (initial load or SPA navigation)
   */
  const handleTaskPage = () => {
    if (!isAsanaTaskPage()) {
      currentTaskId = null;
      // Remove banner when navigating away from task pages
      if (currentJobBanner) {
        logger_log("Navigating away from task page, removing banner");
        currentJobBanner.remove();
        currentJobBanner = null;
      }
      // Remove pills when navigating away
      const pillsContainer = document.querySelector('.storegen-job-pills-container');
      if (pillsContainer) {
        pillsContainer.remove();
      }
      return;
    }

    const newTaskId = getTaskId();
    
    // Only re-insert if task changed or button is missing
    if (newTaskId !== currentTaskId || !document.getElementById('storegen-codegen-button')) {
      logger_log(`Task changed: ${currentTaskId} -> ${newTaskId}`);
      
      // Remove previous task's banner when navigating to a different task
      if (currentTaskId && newTaskId !== currentTaskId && currentJobBanner) {
        logger_log("Navigating to different task, removing previous banner");
        currentJobBanner.remove();
        currentJobBanner = null;
      }
      
      currentTaskId = newTaskId;
      tryInsertButton();
      
      // Check if there's a stored job for this task and restore the status banner
      const storageKey = getAsanaStorageKey();
      const storedJobId = getStoredJob(storageKey);
      if (storedJobId && !currentJobBanner) {
        logger_log("Found stored job for Asana task:", storedJobId);
        // Fetch job details to get the jobUrl
        fetchJobDetails(
          storedJobId,
          (data) => {
            // Recreate the status banner with the fetched jobUrl
            currentJobBanner = createJobBanner(
              storedJobId,
              data.jobUrl || data.viewLogsUrl,
              storageKey,
              renderMarkdown,
              () => {
                logger_log("Restored status banner closed for Asana task");
                currentJobBanner = null;
                renderJobPillsWrapper();
              },
              "Processing Asana task..."
            );
          },
          () => {
            // Fallback if fetch fails - create banner without jobUrl
            logger_log("Failed to fetch job details, creating banner without jobUrl");
            currentJobBanner = createJobBanner(
              storedJobId,
              null,
              storageKey,
              renderMarkdown,
              () => {
                logger_log("Restored status banner closed for Asana task");
                currentJobBanner = null;
                renderJobPillsWrapper();
              },
              "Processing Asana task..."
            );
          }
        );
      } else {
        // No active job, just render pills if any exist
        renderJobPillsWrapper();
      }
    }
  };

  // Initial button insertion
  handleTaskPage();

  // Watch for SPA navigation via URL changes
  // Asana uses History API for navigation
  const originalPushState = history.pushState;
  const originalReplaceState = history.replaceState;

  history.pushState = function(...args) {
    originalPushState.apply(this, args);
    setTimeout(handleTaskPage, asana_tasks_BUTTON_INSERT_RETRY_DELAY_MS);
  };

  history.replaceState = function(...args) {
    originalReplaceState.apply(this, args);
    setTimeout(handleTaskPage, asana_tasks_BUTTON_INSERT_RETRY_DELAY_MS);
  };

  window.addEventListener('popstate', () => {
    setTimeout(handleTaskPage, asana_tasks_BUTTON_INSERT_RETRY_DELAY_MS);
  });

  // Watch for DOM changes that might remove/replace the button container
  // This handles cases where Asana re-renders the task pane
  const observer = new MutationObserver((mutations) => {
    // Only check if we're on a task page and button is missing
    if (isAsanaTaskPage() && !document.getElementById('storegen-codegen-button')) {
      logger_log("Button missing after DOM mutation, re-inserting");
      tryInsertButton();
    }
  });

  // Observe the body for structural changes
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

;// ./src/features/pipelines/specStudioButton.js



const SPEC_STUDIO_API = 'https://prod.spec-studio.storegen.amazon.dev';
const SPEC_STUDIO_UI = 'https://specs.harmony.a2z.com';

function specStudioButton_createSpecStudioButton(pipelineName) {
  const button = document.createElement('button');
  button.id = 'storegen-pipelines-button';
  button.type = 'button';
  button.style.cssText = `
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
    background: #16191F !important;
    color: white !important;
    border: 1px solid #16191F !important;
    border-radius: 20px !important;
    padding: 4px 14px 4px 10px !important;
    font-size: 14px !important;
    font-weight: 500 !important;
    font-family: "Amazon Ember", "Helvetica Neue", Roboto, Arial, sans-serif !important;
    cursor: pointer !important;
    height: 28px !important;
    white-space: nowrap !important;
    transition: background 0.2s ease !important;
    position: relative !important;
    overflow: hidden !important;
    margin-right: 8px !important;
    box-sizing: border-box !important;
    vertical-align: middle !important;
  `;

  const gradientBar = document.createElement('div');
  gradientBar.style.cssText = `
    position: absolute; left: 0; top: 0; bottom: 0; width: 4px;
    background: linear-gradient(180deg,
      rgba(0,0,0,1) 0%, rgba(0,49,129,1) 10%, rgba(32,116,213,1) 25%,
      rgba(244,110,187,1) 40%, rgba(255,173,151,1) 50%, rgba(244,110,187,1) 60%,
      rgba(32,116,213,1) 75%, rgba(0,49,129,1) 90%, rgba(0,0,0,1) 100%);
    background-size: 100% 200%; background-position: 0% 0%;
    transition: background-position 0.6s ease;
  `;
  button.appendChild(gradientBar);

  const logo = logo_createStoreGenLogo();
  logo.style.width = '16px';
  logo.style.height = '16px';
  logo.style.flexShrink = '0';
  button.appendChild(logo);

  const text = document.createElement('span');
  text.textContent = 'Spec Studio';
  button.appendChild(text);

  button.onmouseover = () => {
    button.style.setProperty('background', '#2a2e38', 'important');
    gradientBar.style.backgroundPosition = '0% 100%';
  };
  button.onmouseout = () => {
    button.style.setProperty('background', '#16191F', 'important');
    gradientBar.style.backgroundPosition = '0% 0%';
  };

  button.onclick = () => {
    const normalizedName = pipelineName.toLowerCase().replace(/\s+/g, '-');
    window.open(`${SPEC_STUDIO_UI}/pipelines/${normalizedName}/overview`, '_blank');
    GM_xmlhttpRequest({
      method: 'POST',
      url: `${SPEC_STUDIO_API}/collections`,
      headers: { 'Content-Type': 'application/json' },
      withCredentials: true,
      data: JSON.stringify({
        name: pipelineName,
        description: `Pipeline collection for ${pipelineName}`,
        collectionType: 'pipeline',
        metadata: { pipelineName },
        ignorePrivatePackages: true,
      }),
      onload: (res) => { logger_log('Collection response:', res.status, 'for:', pipelineName); },
      onerror: () => { /* best-effort */ },
    });
  };

  return button;
}

function specStudioButton_insertSpecStudioButton(button, container) {
  container.prepend(button);
  logger_log('Spec Studio button inserted');
  return true;
}

function specStudioButton_removeSpecStudioButton() {
  const existing = document.getElementById('storegen-pipelines-button');
  if (existing) existing.remove();
}

;// ./src/features/pipelines/fixTestButton.js


const CODEGEN_UI_BASE = 'https://codegen.harmony.a2z.com';

/**
 * Creates a StoreGen-styled "View Fix" button for a fixtest job.
 * Matches the Code Review page button style (square corners, box shadow, gradient bar via ::before).
 * @param {string} jobId - The CodeGen fixtest job ID
 * @param {string} todId - The ToD ID (used for deduplication)
 * @returns {HTMLElement} Button element
 */
function createFixTestButton(jobId, todId) {
  const button = document.createElement('button');
  button.id = `storegen-fixtest-${todId}`;
  button.type = 'button';
  button.className = 'storegen-package-header-button';
  button.style.cssText = `
    margin-right: 0 !important;
    margin-top: 6px !important;
  `;

  const logo = logo_createStoreGenLogo();
  logo.style.width = '18px';
  logo.style.height = '18px';
  logo.style.marginRight = '6px';
  button.appendChild(logo);

  const text = document.createElement('span');
  text.textContent = 'Automated Fix Available';
  button.appendChild(text);

  button.onclick = () => {
    window.open(`${CODEGEN_UI_BASE}/job/${jobId}`, '_blank');
  };

  return button;
}

;// ./src/features/pipelines/fixTestLink.js





let stylesInjected = false;
const pendingLookups = new Set();

/**
 * Scans the pipeline page for failing ADAM test steps and injects
 * "View Fix" buttons for any that have a matching CodeGen fixtest job.
 */
function initFixTestLinks() {
  const steps = findFailingAdamSteps();
  const sparklineSteps = findInProgressStepsWithLastFailedRun();
  const allSteps = [...steps, ...sparklineSteps];

  if (allSteps.length === 0) return;

  if (!stylesInjected) {
    injectStyles();
    stylesInjected = true;
  }

  logger_log(`Found ${allSteps.length} failing ADAM step(s), checking for fixtest jobs`);

  for (const { viewResultsLink, todId } of allSteps) {
    if (document.getElementById(`storegen-fixtest-${todId}`)) continue;
    if (pendingLookups.has(todId)) continue;
    pendingLookups.add(todId);

    fetchJobsByTag(`adam:${todId}`, 1, (jobs) => {
      if (jobs.length > 0 && jobs[0].jobType === 'fix_test_package_id' && jobs[0].status === 'COMPLETED') {
        fetchJobChildren(jobs[0].jobId, (children) => {
          if (children.length > 0) {
            injectFixButton(viewResultsLink, jobs[0].jobId, todId);
          }
        }, (error) => {
          logger_log('FixTest children lookup failed for', todId, error);
        });
      }
    }, (error) => {
      logger_log('FixTest link lookup failed for', todId, error);
    });
  }
}

/**
 * Finds all failing workflow steps that have a ToD "View results" link.
 * @returns {Array<{viewResultsLink: HTMLElement, todId: string}>}
 */
function findFailingAdamSteps() {
  const results = [];

  // Find all ToD "View results" links on the page
  const todLinks = document.querySelectorAll('a[href*="tod.amazon.com/test_runs/"]');

  for (const link of todLinks) {
    const todId = extractTodId(link.href);
    if (!todId) continue;
    if (document.getElementById(`storegen-fixtest-${todId}`)) continue;

    // Only include links whose URL contains "status-failed" (pipelines appends this for failed runs)
    if (!link.href.includes('status-failed')) continue;

    results.push({ viewResultsLink: link, todId });
  }

  return results;
}

/**
 * For steps where the latest run is in-progress, checks the sparkline to find
 * the latest completed run. If it was a failure, extracts its ToD ID by simulating
 * a click on the sparkline bar (which triggers window.open with the ToD URL).
 * @returns {Array<{viewResultsLink: HTMLElement, todId: string}>}
 */
function findInProgressStepsWithLastFailedRun() {
  const results = [];
  const steps = document.querySelectorAll('[data-testid="workflow-step-details"]');

  for (const step of steps) {
    const viewLink = step.querySelector('a[data-testid="workflow-step-instance-link"]');
    if (!viewLink || !viewLink.href.includes('status-in-progress')) continue;

    const sparkline = step.querySelector('.sparkline-container');
    if (!sparkline) continue;

    const bars = sparkline.querySelectorAll('.sparkline-bar.test-run');
    if (bars.length < 2) continue;

    let latestCompleted = null;
    for (let i = bars.length - 1; i >= 0; i--) {
      if (bars[i].classList.contains('in-progress')) continue;
      latestCompleted = bars[i];
      break;
    }

    if (!latestCompleted || !latestCompleted.classList.contains('failed')) continue;

    const todUrl = extractTodUrlFromFiber(latestCompleted);
    if (!todUrl) continue;

    const todId = extractTodId(todUrl);
    if (!todId || pendingLookups.has(todId)) continue;
    if (document.getElementById(`storegen-fixtest-${todId}`)) continue;

    results.push({ viewResultsLink: viewLink, todId });
  }

  return results;
}

/**
 * Reads the testReportUrl from a sparkline bar's React fiber parent props.
 * Uses unsafeWindow context to bypass Tampermonkey's sandbox isolation.
 * @param {HTMLElement} barElement - A .sparkline-bar.test-run DOM element
 * @returns {string|null} The ToD URL or null
 */
function extractTodUrlFromFiber(barElement) {
  try {
    // In Tampermonkey, Object.keys on a DOM element from the extension context
    // won't see React's __reactFiber$ properties. We need to enumerate keys
    // through the page's context.
    const keys = Object.getOwnPropertyNames(barElement);
    let reactKey = keys.find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'));

    if (!reactKey) {
      // Try accessing via the element's wrappedJSObject (Firefox Tampermonkey)
      const unwrapped = barElement.wrappedJSObject || barElement;
      const unwrappedKeys = Object.getOwnPropertyNames(unwrapped);
      reactKey = unwrappedKeys.find(k => k.startsWith('__reactFiber$') || k.startsWith('__reactInternalInstance$'));
      if (reactKey) {
        const fiber = unwrapped[reactKey];
        const testResult = fiber?.return?.memoizedProps?.testResult;
        return testResult?.testReportUrl || null;
      }
      return null;
    }

    const fiber = barElement[reactKey];
    const testResult = fiber?.return?.memoizedProps?.testResult;
    return testResult?.testReportUrl || null;
  } catch (e) {
    logger_log(`  extractTodUrlFromFiber error: ${e.message}`);
    return null;
  }
}

/**
 * Extracts the ToD ID from a ToD test_runs URL.
 * @param {string} href - Full URL like "https://tod.amazon.com/test_runs/<id>?..."
 * @returns {string|null}
 */
function extractTodId(href) {
  const match = href.match(/\/test_runs\/([^?]+)/);
  return match ? match[1] : null;
}

/**
 * Injects the "View Fix" button below the "View results" link.
 * @param {HTMLElement} viewResultsLink - The "View results" anchor element
 * @param {string} jobId - The CodeGen fixtest job ID
 * @param {string} todId - The ToD ID (for deduplication)
 */
function injectFixButton(viewResultsLink, jobId, todId) {
  if (document.getElementById(`storegen-fixtest-${todId}`)) return;

  const button = createFixTestButton(jobId, todId);

  // Find the horizontal container holding "View results" + "View test cases"
  // and insert the button after it (below both links)
  const horizontalContainer = viewResultsLink.closest('[class*="awsui_horizontal_"]');
  if (horizontalContainer) {
    horizontalContainer.parentElement.insertBefore(button, horizontalContainer.nextSibling);
    logger_log('Injected View Fix button for ToD:', todId);
  } else {
    viewResultsLink.parentElement.appendChild(button);
    logger_log('Injected View Fix button (fallback) for ToD:', todId);
  }
}

;// ./src/features/pipelines/index.js




let currentPipelineName = null;
let currentInterval = null;
let currentObserver = null;
let debounceTimer = null;

function initPipelines() {
  const pipelineName = extractPipelineName();
  if (!pipelineName) {
    logger_log('Could not extract pipeline name, skipping');
    return;
  }

  if (pipelineName === currentPipelineName && document.getElementById('storegen-pipelines-button')) {
    return;
  }

  if (currentInterval) {
    clearInterval(currentInterval);
    currentInterval = null;
  }

  if (currentObserver) {
    currentObserver.disconnect();
    currentObserver = null;
  }

  specStudioButton_removeSpecStudioButton();
  currentPipelineName = pipelineName;
  logger_log('Initializing Spec Studio for pipeline:', pipelineName);

  const tryInsert = () => {
    const target = findInsertionTarget();
    if (target) {
      const button = specStudioButton_createSpecStudioButton(pipelineName);
      specStudioButton_insertSpecStudioButton(button, target);
      return true;
    }
    return false;
  };

  if (!tryInsert()) {
    let retryCount = 0;
    currentInterval = setInterval(() => {
      retryCount++;
      if (tryInsert() || retryCount >= 20) {
        clearInterval(currentInterval);
        currentInterval = null;
      }
    }, 500);
  }

  // Observe DOM for workflow sections being expanded (they load lazily).
  // When new content appears, scan for failing ADAM steps and inject "View Fix" buttons.
  logger_log('Starting fixtest MutationObserver');
  initFixTestLinks();
  currentObserver = new MutationObserver(() => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => initFixTestLinks(), 300);
  });
  currentObserver.observe(document.body, { childList: true, subtree: true });
}

function extractPipelineName() {
  const match = window.location.pathname.match(/\/pipelines(?:-wip)?\/([^/]+)/);
  return match ? match[1] : null;
}

function findInsertionTarget() {
  const selectors = [
    '[data-testid="settings-button"]',
    '[data-testid="feedback-button"]',
    '[class*="header-actions"]',
    '[class*="HeaderActions"]',
  ];

  for (const selector of selectors) {
    const el = document.querySelector(selector);
    if (el) return el.closest('[class*="actions"]') || el.parentElement;
  }

  return null;
}

;// ./src/core/experimentalMode.js


const EXPERIMENTAL_MODE_KEY = 'storegen-experimental-mode';

function isExperimentalMode() {
  return GM_getValue(EXPERIMENTAL_MODE_KEY, false);
}

function setExperimentalMode(enabled) {
  GM_setValue(EXPERIMENTAL_MODE_KEY, enabled);
  logger_log('Experimental mode', enabled ? 'enabled' : 'disabled');
}

function registerExperimentalModeMenu() {
  const enabled = isExperimentalMode();
  const label = enabled ? '⚗️ Disable Experimental Mode' : '⚗️ Enable Experimental Mode';
  GM_registerMenuCommand(label, () => {
    setExperimentalMode(!enabled);
    window.location.reload();
  });
}

;// ./src/main-codegen.js
// StoreGen Browser Extension - Main Entry Point










(function () {
  "use strict";

  registerExperimentalModeMenu();
  registerKiroAgentMenu();

  // Initialize markdown-it (loaded via @require in Tampermonkey header)
  const md = window.markdownit({ linkify: true });

  /**
   * Renders markdown text to HTML
   * @param {string} markdown - The markdown text to render
   * @returns {string} HTML string
   */
  function renderMarkdown(markdown) {
    if (!markdown) return "";
    return md.render(markdown);
  }

  // Track last URL to detect SPA navigation
  let lastUrl = window.location.href;

  // Wait for page to load
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      init();
      setupSpaNavigation();
    });
  } else {
    init();
    setupSpaNavigation();
  }

  // ============================================
  // SPA NAVIGATION DETECTION
  // ============================================

  /**
   * Sets up detection for SPA (Single Page Application) navigation
   * Uses multiple strategies since different frameworks handle routing differently
   */
  function setupSpaNavigation() {
    // Strategy 1: Handle browser back/forward navigation
    window.addEventListener('popstate', handleUrlChange);

    // Strategy 2: Intercept pushState and replaceState
    const originalPushState = history.pushState;
    const originalReplaceState = history.replaceState;

    history.pushState = function(...args) {
      originalPushState.apply(this, args);
      handleUrlChange();
    };

    history.replaceState = function(...args) {
      originalReplaceState.apply(this, args);
      handleUrlChange();
    };

    // Strategy 3: Poll for URL changes (catches all edge cases like React Router)
    setInterval(() => {
      if (window.location.href !== lastUrl) {
        handleUrlChange();
      }
    }, 500);
  }

  /**
   * Handles URL changes from SPA navigation
   */
  function handleUrlChange() {
    const currentUrl = window.location.href;
    
    // Only re-init if URL actually changed
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      // Small delay to let the SPA render the new page content
      setTimeout(init, 150);
    }
  }

  // ============================================
  // INITIALIZATION
  // ============================================

  /**
   * Main initialization function
   * Determines which site we're on and initializes appropriate functionality
   */
  function init() {
    const hostname = window.location.hostname;
    const pathname = window.location.pathname;

    if (hostname === "code.amazon.com") {
      if (pathname.includes("/reviews/")) {
        initCruxComments(renderMarkdown);
      } else if (pathname.startsWith("/packages/")) {
        initCruxHome(renderMarkdown);
      }
    } else if (hostname === "sim.amazon.com" || hostname === "issues.amazon.com") {
      if (pathname.startsWith("/issues/")) {
        initSimIssue();
      }
    } else if (hostname === "taskei.amazon.dev") {
      // Handle both /tasks/ID pages and /rooms/ pages with ?task= sidebar
      if (pathname.startsWith("/tasks/") || pathname.startsWith("/rooms/")) {
        initTaskeiTask();
      }
    } else if (hostname.includes("atlassian.net")) {
      if (pathname.startsWith("/browse/")) {
        initJiraIssue();
      }
    } else if (hostname.includes("labcollab.net")) {
      if (pathname.startsWith("/browse/")) {
        initJiraIssue();
      }
    } else if (hostname === "app.asana.com") {
      initAsanaTasks(renderMarkdown);
    } else if (hostname === "pipelines.amazon.dev") {
      if (pathname.startsWith("/pipelines")) {
        initPipelines();
      }
    }
  }
})();

/******/ })()
;