// ==UserScript==
// @name         Pipeline OnCall Helper
// @namespace    S3Gur-Engineering
// @version      1.2
// @description  Adds a Pipeline's On-call information/link! https://w.amazon.com/bin/view/S3/Teams/MVP_Engineering/Runbooks/Pipeline-Oncall-Helper/
// @author       chrcavan@amazon.com
// @match        https://pipelines.amazon.com/pipelines/*
// @connect      cti.amazon.com
// @connect      bindles.amazon.com
// @connect      oncall-api.corp.amazon.com
// @updateURL    https://improvement-ninjas.amazon.com/GreaseMonkey/pipeline-oncall-helper.user.js
// @downloadURL  https://improvement-ninjas.amazon.com/GreaseMonkey/pipeline-oncall-helper.user.js
// @grant        GM_xmlhttpRequest
// @run-at       document-end
// ==/UserScript==
//ToDo
//make a way to report bad links or missing links
(function () {
    debug("START");
    const today = currentDate();
    run();


    // The core of the script
    async function run() {
        // Get the pipeline from the current page (if on pipelines.amazon.com)
        const pipeName = getPipelineName()
        debug(`Pipeline Name: ${pipeName}`)
        // Get Owner for Pipeline from Bindles site
        var owner = await getOwner(pipeName);
        debug(`Owner or Owner array: ${owner}`)
        // Get the Oncall Aliases for the bindle Owner
        const getOncallTeamAliasData = await getOncallTeamAlias(owner);
        // Pull the info from above and Build the html to display the oncall badges properly
        await getOncallMemberAlias(getOncallTeamAliasData)
        debug(`COMPLETE`)
    }

    // Returns current page's pipeline [https://pipelines.amazon.com/pipelines/*]
    function getPipelineName() {
        const currentPage = window.location.href;
        let pipeline = currentPage.replace("https://pipelines.amazon.com/pipelines/", "");
        const index = pipeline.indexOf("/");
        if (index > -1) {
            pipeline = pipeline.substring(0, index);
        }
        return pipeline
    }
    // Returns Software Owner and/or Pipeline owner from Bindle
    async function getOwner(pipes) {
        // Get owner of the pipe if possible, pipeOwner is generally more accurate than software app owner
        const bindleUrl = `https://bindles.amazon.com/resource/Pipelines/pipeline/${pipes}`
        const bindleHtml = await getContentOf(bindleUrl)
        const bindleHtmlParse = getParsedHTML(bindleHtml.responseText)
        var pipeOwner = ''
        if (bindleHtmlParse.getElementById("view-resource-metadata") !== null) {
            const pipeOwnerData = bindleHtmlParse.getElementById("view-resource-metadata").textContent
            pipeOwner = pipeOwnerData.split("\n")[5]
        } else {
            pipeOwner = null
        }
        // Get owner of the software app regardless of whether the pipeOwner exists
        const parentApp = bindleHtmlParse.getElementById("main-container").getElementsByTagName("li")[1].textContent.split("\n")[1]
        const appBinUrl = `https://bindles.amazon.com/software_app/${parentApp}`;
        const appHtml = await getContentOf(appBinUrl)
        const appHtmlParse = getParsedHTML(appHtml.responseText)
        const appOwnerData = appHtmlParse.getElementById("view-resource-metadata").textContent
        const appOwner = appOwnerData.split("\n")[5];
        const ctiRaw = appHtmlParse.getElementById("bindle-view").attributes.getNamedItem("data-ng-init").textContent;
        const ctiData = ctiRaw.slice(ctiRaw.indexOf('{'), ctiRaw.lastIndexOf('}')+1)
        const resolverGroup = JSON.parse(ctiData).contact.cti.resolver_group
        // Either return the appowner, or the pipeowner AND appowner
        if (pipeOwner == null && resolverGroup == null) {
            return appOwner
        } else if (pipeOwner == null) {
            return [appOwner, resolverGroup]
        } else {
            return [pipeOwner, appOwner, resolverGroup]
        }
    }
    // Gathers teams and aliases related to the Owner and places them in a Map for use in the next function
    async function getOncallTeamAlias(owningTeam) {
        var oncallTeamAliasDict = new Map();
        if (Array.isArray(owningTeam) == true) {
            for (var team of owningTeam) {
                const onCallDomain = "https://oncall-api.corp.amazon.com"
                const onCallTeamUri = `${onCallDomain}/teams?q=${team}&start=0&size=5`
                const encoded_TeamUri = encodeURI(onCallTeamUri);
                const oncallJSON = await getContentOf(encoded_TeamUri)
                if (oncallJSON.status === 404) { return; }
                const teamJSON = JSON.parse(oncallJSON.responseText)
                teamJSON.forEach(function(teamArray){
                    oncallTeamAliasDict.set(teamArray.teamName, {"aliases": teamArray.aliases, "owner": owningTeam[0]})
                });
            }
        } else {
            const onCallDomain = "https://oncall-api.corp.amazon.com"
            const onCallTeamUri = `${onCallDomain}/teams?q=${owningTeam}&start=0&size=5`
            const encoded_TeamUri = encodeURI(onCallTeamUri);
            const oncallJSON = await getContentOf(encoded_TeamUri)
            if (oncallJSON.status === 404) { return; }
            const teamJSON = JSON.parse(oncallJSON.responseText)
            teamJSON.forEach(async function(teamArray){
                oncallTeamAliasDict.set(teamArray.teamName, {"aliases": teamArray.aliases, "owner": owningTeam[0]})
            });

        }
        return oncallTeamAliasDict
    };

    // takes a given team and pulls the current oncall for today, and adds it to the teamOutputDict
    async function getOncallMemberAlias(oncallTeamData) {
        // for each team name in the above list
        // tinyurl to ticket for pipeline Oncall Helper Issues: https://tiny.amazon.com/1j9hsjdwu/Pipeline-Oncall-Helper
        var onCallMainDIV = domCreate('div', 'Oncall-Badges');
        onCallMainDIV.style.cssText = 'padding-top: 4px; padding-bottom: 2px'
        var badgeFixLink = domCreate('a', '', {
            href: `https://tiny.amazon.com/1j9hsjdwu/Pipeline-Oncall-Helper`,
                target: '_blank',
                title: `Open a ticket`,
                textContent: `Help! My Oncall Badge is...`,
        });
        document.querySelector(".extra-info").insertAdjacentElement("afterend", onCallMainDIV);
        oncallTeamData.forEach(function(teamData, oncallTeam) {
            var ownerCheckLock = 0
            teamData.aliases.split(" ").forEach(async function(teamAlias){
                // get the oncall member
                const onCallDomain = "https://oncall-api.corp.amazon.com"
                var onCallMemberUri = `${onCallDomain}/teams/${teamAlias}/aliases_schedules/page-${teamAlias}?from=${today}&to=${today}`
                var encoded_MemberUri = encodeURI(onCallMemberUri);
                var oncallJSON = await getContentOf(encoded_MemberUri)
                if (oncallJSON.status === 404 && ownerCheckLock == 0) {
                    ownerCheckLock = 1
                    debug(`Team Alias [${teamAlias}] unable to find oncall groups, attempting owner...`);
                    onCallMemberUri = `${onCallDomain}/teams/${oncallTeam}/aliases_schedules/page-${oncallTeam}?from=${today}&to=${today}`
                    encoded_MemberUri = encodeURI(onCallMemberUri);
                    oncallJSON = await getContentOf(encoded_MemberUri)
                    teamAlias = oncallTeam
                } else if (oncallJSON.status === 404) {
                    debug(`Team Alias [${teamAlias}] unable to find oncall groups`)
                    return
                } else if (teamAlias == oncallTeam) {
                    return
                }
                const memberAlias = JSON.parse(oncallJSON.response)
                memberAlias.forEach(async function(currentMemberAliases){
                    // skip entries marked historical
                    if (currentMemberAliases.shiftType == "historical") { debug(`${currentMemberAliases.oncallMember[0]} is historical oncall`); return; }
                    const currentMemberAlias = currentMemberAliases.oncallMember[0]
                    // skip empty (null/undefined) entries
                    if (currentMemberAlias == null) { return;}
                    // Base html creation
                    // var onCallMainDIV = domCreate('div', 'Oncall-Badges');
                    // document.querySelector(".extra-info").insertAdjacentElement("afterend", onCallMainDIV);
                    //var onCallList = domCreate('li')
                    var baseOncallStyle = 'opacity: 0.9; text-shadow: 0px 1px rgba(1, 1, 1, 0.3); padding: 2px 5px; color: #fff;';
                    //onCallMainDIV.append(onCallList)
                    if (oncallTeam == teamData.owner || oncallTeam.includes("primary")) {
                        var ownerOnCallTeamDOM = domCreate('a', '', {
                            href: `https://oncall.corp.amazon.com/#/view/${teamAlias}`,
                                target: '_blank',
                                title: `Oncall Schedule for ${teamAlias}`,
                                textContent: `${teamAlias}`,
                                onmouseenter: function() { ownerOnCallTeamDOM.style.opacity = 1.0; },
                                onmouseleave: function() { ownerOnCallTeamDOM.style.opacity = 0.9; }
                        })
                        ownerOnCallTeamDOM.style.cssText = baseOncallStyle + 'border-top-left-radius: 4px; border-bottom-left-radius: 4px; background-image: linear-gradient(0deg, #4C4C4C, #5F5F5F);';
                        var ownerOncallUserDOM = domCreate('a', '', {
                            target: '_blank',
                                textContent: 'Loading...',
                                onmouseenter: function() { ownerOncallUserDOM.style.opacity = 1.0; },
                                onmouseleave: function() { ownerOncallUserDOM.style.opacity = 0.9; }
                        });
                        ownerOncallUserDOM.style.cssText = baseOncallStyle + 'border-top-right-radius: 4px; border-bottom-right-radius: 4px; background-image: linear-gradient(0deg, #3cbf31, #3cae31);';
        
                        ownerOncallUserDOM.textContent = currentMemberAlias
                        ownerOncallUserDOM.href = `https://slack.com/app_redirect?channel=@${currentMemberAlias}`
                        ownerOncallUserDOM.title = `Slack DM with ${currentMemberAlias}@`
        
                        var onCallBadge = domCreate('a');
                        onCallBadge.style.cssText = 'padding-right: 4px; word-break: keep-all;';
                        onCallBadge.appendChild(ownerOnCallTeamDOM)
                        onCallBadge.appendChild(ownerOncallUserDOM)
                        //onCallList.appendChild(onCallBadge)
                        document.querySelector(".Oncall-Badges").appendChild(onCallBadge);
                    } else if (oncallTeam.includes("secondary")) {
                        var ownerOnCallTeamDOM = domCreate('a', '', {
                            href: `https://oncall.corp.amazon.com/#/view/${teamAlias}`,
                                target: '_blank',
                                title: `Oncall Schedule for ${teamAlias}`,
                                textContent: `${teamAlias}`,
                                onmouseenter: function() { ownerOnCallTeamDOM.style.opacity = 1.0; },
                                onmouseleave: function() { ownerOnCallTeamDOM.style.opacity = 0.9; }
                        })
                        ownerOnCallTeamDOM.style.cssText = baseOncallStyle + 'border-top-left-radius: 4px; border-bottom-left-radius: 4px; background-image: linear-gradient(0deg, #4C4C4C, #5F5F5F);';
                        var ownerOncallUserDOM = domCreate('a', '', {
                            target: '_blank',
                                textContent: 'Loading...',
                                onmouseenter: function() { ownerOncallUserDOM.style.opacity = 1.0; },
                                onmouseleave: function() { ownerOncallUserDOM.style.opacity = 0.9; }
                        });
                        ownerOncallUserDOM.style.cssText = baseOncallStyle + 'border-top-right-radius: 4px; border-bottom-right-radius: 4px; background-image: linear-gradient(0deg, #2767c4, #0e50b2);';
        
                        ownerOncallUserDOM.textContent = currentMemberAlias
                        ownerOncallUserDOM.href = `https://slack.com/app_redirect?channel=@${currentMemberAlias}`
                        ownerOncallUserDOM.title = `Slack DM with ${currentMemberAlias}@`
        
                        var onCallBadge = domCreate('a');
                        onCallBadge.style.cssText = 'padding-right: 4px; word-break: keep-all;';
                        onCallBadge.appendChild(ownerOnCallTeamDOM)
                        onCallBadge.appendChild(ownerOncallUserDOM)
                       //onCallList.appendChild(onCallBadge)
                        console.log(onCallBadge)
                        document.querySelector(".Oncall-Badges").appendChild(onCallBadge);
                    } else {
                        var ownerOnCallTeamDOM = domCreate('a', '', {
                            href: `https://oncall.corp.amazon.com/#/view/${teamAlias}`,
                                target: '_blank',
                                title: `Oncall Schedule for ${teamAlias}`,
                                textContent: `${teamAlias}`,
                                onmouseenter: function() { ownerOnCallTeamDOM.style.opacity = 1.0; },
                                onmouseleave: function() { ownerOnCallTeamDOM.style.opacity = 0.9; }
                        })
                        ownerOnCallTeamDOM.style.cssText = baseOncallStyle + 'border-top-left-radius: 4px; border-bottom-left-radius: 4px; background-image: linear-gradient(0deg, #4C4C4C, #5F5F5F);';
                        var ownerOncallUserDOM = domCreate('a', '', {
                            target: '_blank',
                                textContent: 'Loading...',
                                onmouseenter: function() { ownerOncallUserDOM.style.opacity = 1.0; },
                                onmouseleave: function() { ownerOncallUserDOM.style.opacity = 0.9; }
                        });
                        ownerOncallUserDOM.style.cssText = baseOncallStyle + 'border-top-right-radius: 4px; border-bottom-right-radius: 4px; background-image: linear-gradient(0deg, #E47031, #F78344);';
        
                        ownerOncallUserDOM.textContent = currentMemberAlias
                        ownerOncallUserDOM.href = `https://slack.com/app_redirect?channel=@${currentMemberAlias}`
                        ownerOncallUserDOM.title = `Slack DM with ${currentMemberAlias}@`
        
                        var onCallBadge = domCreate('a');
                        onCallBadge.style.cssText = 'padding-right: 4px; word-break: keep-all;';
                        onCallBadge.appendChild(ownerOnCallTeamDOM)
                        onCallBadge.appendChild(ownerOncallUserDOM)
                        //onCallList.appendChild(onCallBadge)
                        document.querySelector(".Oncall-Badges").appendChild(onCallBadge);
                    }
                });
            });
        });
        //document.querySelector(".extra-info").insertAdjacentElement("afterend", onCallMainDIV);
        document.querySelector(".Oncall-Badges").insertAdjacentElement("afterend", badgeFixLink);
    }

    // borrowed from CTI Helper
    // by dseek@
    // Provides a programmatic and async way to parse the contesnts of a url 
    async function getContentOf(url, headers = {}) {
        debug("getContentOf ", url, headers)
        return new Promise(async (resolve, reject) => {
            await GM_xmlhttpRequest({
                method: "GET",
                url: url,
                headers: headers,
                onloadend: async (response) => {
                    resolve(response);
                },
                onerror: (error) => {
                    debug('Error in getContentOf onerror', error);
                    reject(error)
                },
                onabort: (error) => {
                    debug('Error in getContentOf onabort', error);
                    reject(error)
                },
                ontimeout: (error) => {
                    debug('Error in getContentOf ontimeout', error);
                    reject(error)
                }
            });
        });
    }

    // Borrowed from Phonetool Oncall Badges
    // by kmmcclai@ | kheraf@
    // Provides console ouput to the Browser for local logging
    function debug() {
        var args = Array.from(arguments);
        args.splice(0, 0, '[Pipeline OnCall Helper]');
        console.log.apply(console.log, args);
    };
    // Returns a parsed DOM element from the get request's responseString
    function getParsedHTML(responseString) {
        // Init a parser
        const parser = new DOMParser()
        // And return the parsed document
        return parser.parseFromString(responseString, "text/html");
    }
    // Gets today's date w/ format YYYY-MM-DD
    function currentDate() {
        var currentDate =new Date()
        // Adding 1 to the month because months list starts at 0
        var month = ( '0' + (currentDate.getMonth() + 1)).slice(-2)
        var today = ( '0' + (currentDate.getDate())).slice(-2)
        var year = currentDate.getFullYear()
        var now = `${year}-${month}-${today}`
        return [now]
    }
    // Borrowed from PhoneTool Oncall Badges with light modifications
    // by kmmcclai@ | kheraf@
    // Provides a function to create the html formatting for clean output
    function domCreate(tag, classes, attrs) {
        var node = document.createElement(tag);
        if (attrs) {
            Object.assign(node, attrs);
        }
        if (typeof(classes) === 'string') {
            classes = classes.replace(/^\s*|\s*$/g, '').split(/\s+/g);
        }
        if (classes instanceof Array) {
            classes.forEach(function(clazz) {
                if (clazz !== '') {
                node.classList.add(clazz);
                }
            });
        }
        return node;
    }

})();
