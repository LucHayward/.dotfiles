// ==UserScript==
// @name         Amazon Internal Chatbot
// @namespace    https://chat.com.amazon.dev
// @version      0.2
// @description  Reads data from Amazon wiki pages to add as context to Amazon Internal Chatbot
// @author       Vishnu Krishnaprasad
// @match        https://chat.com.amazon.dev/*
// @match        http://localhost:8080/*
// @grant        GM_xmlhttpRequest
// @grant        GM_xmlHttpRequest
// @grant        GM.xmlHttpRequest
// ==/UserScript==

(function() {
    'use strict';

    const initializeWebsiteLoader = () => {
        const websiteLoader = document.getElementById('website-loader');

        // Identify the right xmlHttpRequest function to use for the version of Greasemonkey or Tampermonkey in use
        let xmlHttpRequest;
        if (typeof GM_xmlhttpRequest === 'function') {
          xmlHttpRequest = GM_xmlhttpRequest;
        } else if (typeof GM_xmlHttpRequest === 'function') {
          xmlHttpRequest = GM_xmlHttpRequest;
        } else if (typeof GM.xmlHttpRequest === 'function') {
          xmlHttpRequest = GM.xmlHttpRequest;
        } else {
          throw new Error('Incompatible with this version of Greasemonkey or Tampermonkey');
        }

        // If the div element exists, append the textarea, button, and loader
        if (websiteLoader) {
            // Add styles for the website-loader div
            websiteLoader.style.display = 'flex';
            websiteLoader.style.flexDirection = 'column';
            websiteLoader.style.alignItems = 'center';
            websiteLoader.style.padding = '10px';

            // Add a textarea for inputting URLs
            const textarea = document.createElement('textarea');
            textarea.placeholder = `Optional: Add urls to read before answering (one per line)\n\nhttps://w.amazon.com/1\nhttps://w.amazon.com/2\n...\n\nBuilderhub/Quip urls don't work.`;
            textarea.style.width = '50vw';
            textarea.style.height = '20vh';
            textarea.style.marginBottom = '10px';
            websiteLoader.appendChild(textarea);

            // Add a loader element
            const loader = document.createElement('div');
            loader.style.width = '50vw';
            loader.style.height = '20px';
            loader.style.backgroundColor = '#ddd';
            loader.style.borderRadius = '4px';
            websiteLoader.appendChild(loader);

            const loaderBar = document.createElement('div');
            loaderBar.style.width = '0%';
            loaderBar.style.height = '100%';
            loaderBar.style.backgroundColor = '#4CAF50';
            loaderBar.style.borderRadius = '4px';
            loader.appendChild(loaderBar);

            // Add a button to read websites
            const button = document.createElement('button');
            button.textContent = 'Read Documentation';
            button.style.marginTop = '10px';
            websiteLoader.appendChild(button);

            // Attach a click event listener to the button
            button.addEventListener('click', () => {
                const urlRegex = /^(https?:\/\/)([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w\.-]*)*\/?(\?[^#]*)?(#.*)?$/;
                let urls = textarea.value
                    .split(/\r?\n/) // Split by newlines
                    .filter(url => urlRegex.test(url.trim())) // Filter out invalid URLs
                    .map(url => url.trim()); // Trim remaining URLs

                // Filter out URLs from builderhub.corp.amazon.com and quip-amazon.com
                urls = urls.filter(url => {
                    const hostname = new URL(url).hostname;
                    return hostname !== 'builderhub.corp.amazon.com' && !hostname.endsWith('quip-amazon.com');
                });

                let parsedData = '';
                console.log(urls);

                let urlsProcessed = 0;

                const processUrl = () => {
                    if (urlsProcessed < urls.length) {
                        const url = urls[urlsProcessed];
                        xmlHttpRequest({
                            method: 'GET',
                            url: url,
                            headers: {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
                            },
                            onload: function(response) {
                                // Parse the HTML response
                                const parser = new DOMParser();
                                let doc = parser.parseFromString(response.responseText, 'text/html');

                                // Extract the text content
                                let textContent = doc.body.textContent;
                                textContent = textContent.replace(/\s+/g, ' ').trim(); // Replace multiple spaces with a single space and trim leading/trailing spaces
                                textContent = textContent.replace(/[\r\n]+/g, '\n'); // Replace carriage returns and newlines with a single newline
                                textContent = textContent.replace(/<!--[\s\S]*?-->/g, ''); // Remove HTML comments
                                textContent = textContent.replace(/<script[\s\S]*?<\/script>/g, ''); // Remove <script> tags and content
                                textContent = textContent.replace(/<style[\s\S]*?<\/style>/g, ''); // Remove <style> tags and content

                                parsedData += `Url ${url} has data: ${textContent}\n\n`;

                                urlsProcessed++;
                                const percentage = Math.round((urlsProcessed / urls.length) * 100);
                                loaderBar.style.width = `${percentage}%`;

                                // Check if all URLs have been processed
                                if (urlsProcessed === urls.length) {
                                    console.log(parsedData)
                                    // Dispatch a custom event with the parsed data
                                    const event = new CustomEvent('setWebsiteData', { detail: parsedData });
                                    window.dispatchEvent(event);
                                } else {
                                    // Wait for 250ms before processing the next URL
                                    setTimeout(processUrl, 250);
                                }
                            }
                        });
                    }
                };

                // Start processing the URLs
                processUrl();
            });
        }
    }

    // Try to find the element initially
    let attempts = 0;
    const maxAttempts = 20; // 2 seconds (20 * 100ms)

    const tryFindElement = () => {
        const websiteLoader = document.getElementById('website-loader');
        if (websiteLoader) {
            initializeWebsiteLoader();
        } else {
            attempts++;
            if (attempts < maxAttempts) {
                setTimeout(tryFindElement, 100);
            } else {
                console.error("Unable to find 'website-loader' element after 2 seconds.");
            }
        }
    }

    tryFindElement();
})();
