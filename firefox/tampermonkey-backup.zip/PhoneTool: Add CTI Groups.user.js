// ==UserScript==
// @name        PhoneTool: Add CTI Groups
// @downloadURL https://improvement-ninjas.amazon.com/GreaseMonkey/phonetool-cti-list-add.user.js
// @updateURL https://improvement-ninjas.amazon.com/GreaseMonkey/phonetool-cti-list-add.user.js
// @namespace   markcunn
// @author      aletraa@
// @description Adds cti-groups to phonetool. Why? Because phonetool is terrible at telling you what team someone is one, so this should help. Unfortunately lots of people are still members of old groups that are not relevant to them any more.
// @include     https://phonetool.amazon.com/users/*
// @grant       GM_xmlhttpRequest
// @grant       GM_addStyle
// @connect     sim-ticketing-graphql-fleet.corp.amazon.com
// @version     1.2
// ==/UserScript==

(function() {
    "use strict";

    function escapeHtml(str) {
        const div = document.createElement("div");
        div.textContent = str;
        return div.innerHTML;
    }

    const detailsTableWrapper = document.querySelector(".UserDetailsTable>.optional-wrapper");
    if (!detailsTableWrapper) {
        console.error("CTI Groups: Could not find details table");
        return;
    }

    const match = document.location.pathname.match(/users\/(\w+)/);
    if (!match) {
        console.error("CTI Groups: Could not extract userId from URL");
        return;
    }
    const userId = match[1];

    const ctiGroupsRow = document.createElement("div");
    ctiGroupsRow.setAttribute("class", "TableRow CTIGroupsRow");

    const propertyDiv = document.createElement("div");
    propertyDiv.className = "TableProperty";
    propertyDiv.textContent = "CTI Groups:";

    const valueDiv = document.createElement("div");
    valueDiv.id = "ctigroups";
    valueDiv.className = "TableValue";
    valueDiv.textContent = "Loading...";

    ctiGroupsRow.appendChild(propertyDiv);
    ctiGroupsRow.appendChild(valueDiv);
    detailsTableWrapper.appendChild(ctiGroupsRow);

    const errStart = '<span style="color:#900">';
    const errEnd = '</span>';

    GM_addStyle(".TableValue { width: min-content; } .TableRow { margin-right: 2em; }");

    const query = `
      query searchResolverGroupsTickety($args: SearchResolverGroupsTicketyInput!) {
        searchResolverGroupsTickety(args: $args) {
          resolverGroups {
            id
            name
            status
          }
          totalCount
        }
      }
    `;

    GM_xmlhttpRequest({
        method: "POST",
        url: "https://sim-ticketing-graphql-fleet.corp.amazon.com/graphql",
        headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Origin": "https://phonetool.amazon.com"
        },
        data: JSON.stringify({
            operationName: "searchResolverGroupsTickety",
            query: query,
            variables: {
                args: {
                    maxResults: 50,
                    member: {
                        namespace: "MIDWAY",
                        value: userId
                    },
                    status: "Active"
                }
            }
        }),
        anonymous: false,
        onload: function(response) {
            let ctiGroupsString = "";

            try {
                if (response.status === 200) {
                    const result = JSON.parse(response.responseText);
                    const data = Array.isArray(result) ? result[0]?.data : result.data;

                    if (result.errors || (Array.isArray(result) && result[0]?.errors)) {
                        const errors = result.errors || result[0].errors;
                        console.error("GraphQL Errors:", errors);
                        ctiGroupsString = `${errStart}Error: ${escapeHtml(errors[0].message)}${errEnd}`;
                    } else if (data?.searchResolverGroupsTickety?.resolverGroups) {
                        const groups = data.searchResolverGroupsTickety.resolverGroups;

                        if (groups.length === 0) {
                            ctiGroupsString = "None";
                        } else {
                            const uniqueNames = [...new Set(groups.map(group => group.name))];
                            ctiGroupsString = uniqueNames
                                .map(name => `<a href="https://t.corp.amazon.com/settings/resolver-groups/${encodeURIComponent(name)}" target="_blank">${escapeHtml(name)}</a>`)
                                .join(", ");
                        }
                    } else {
                        ctiGroupsString = "None";
                    }
                } else {
                    console.error("Non-200 Status:", response.status);
                    ctiGroupsString = `${errStart}Error ${escapeHtml(String(response.status || "Unknown"))}${errEnd}`;
                }
            } catch(err) {
                console.error("CTI Groups Error:", err);
                if (err instanceof SyntaxError) {
                    ctiGroupsString = `${errStart}Error: Unrecognized data returned by server${errEnd}`;
                } else if (err instanceof Error || err instanceof DOMException) {
                    ctiGroupsString = `${errStart}JavaScript error: ${escapeHtml(err.name || "Unknown")} - ${escapeHtml(err.message || "No message")}${errEnd}`;
                } else {
                    ctiGroupsString = `${errStart}Unknown error occurred${errEnd}`;
                }
            }

            valueDiv.innerHTML = ctiGroupsString;
        },
        onerror: function() {
            valueDiv.innerHTML = `${errStart}Network error occurred${errEnd}`;
        },
        ontimeout: function() {
            valueDiv.innerHTML = `${errStart}Request timed out${errEnd}`;
        }
    });
})();