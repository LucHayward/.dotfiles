/* eslint-disable no-bitwise */

(async function () {
    if (parseInt(await GM.getValue("lastLog", "0"), 10) < Date.now() - 86400000) {
        // This API GW & Lambda lives in this AWS Account: 597964962110
        // New scripts names must be manually added to a DDB table otherwise the logs will be discarded to avoid spam.
        // The aggregated data from these logs is viewable here: https://w.amazon.com/bin/view/Users/oneijaso/UserScriptMetrics/
        GM.xmlHttpRequest({
            url: "https://fd2ovzypf8.execute-api.us-east-1.amazonaws.com/Prod",
            method: "POST",
            data: JSON.stringify({
                name: GM.info.script.name,
                page: location.href,
                uuid: await getUUID()
            }),
            onload: function () {
                GM.setValue("lastLog", Date.now());
            }
        });
    }

    async function getUUID () {
        let uuid = await GM.getValue("uuid", null);
        if (uuid) {
            return uuid;
        }
        uuid = uuidv4();
        await GM.setValue("uuid", uuid);
        return uuid;
    }

    function uuidv4 () {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
            const r = Math.random() * 16 | 0;
            const v = c === "x" ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }
})();