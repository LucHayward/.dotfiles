// ==UserScript==
// @name        Pipelines Heatmap in Overview
// @description Displays the heatmap in the Pipelines overview (with ticket and CR links in diff)
// @include     /^https://pipelines.amazon.com\/pipelines\/[\w-]+\/?(\?.*)?$/
// @version     9001.0.0
// @updateURL   https://code.amazon.com/packages/GreasemonkeyScripts/blobs/mainline/--/Pipelines/heatmap-in-overview/embedded-heatmap.user.js?raw=1
// @downloadURL https://code.amazon.com/packages/GreasemonkeyScripts/blobs/mainline/--/Pipelines/heatmap-in-overview/embedded-heatmap.user.js?raw=1
// ==/UserScript==

alert("The 'Pipelines Heatmap in Overview' script has been deprecated due to throttling concerns. Consider the following alternative if you are interested in this functionality:\n\nhttps://code.amazon.com/packages/DavworthTamperScripts/blobs/mainline/--/pipelines/prism.user.js?raw=1");
