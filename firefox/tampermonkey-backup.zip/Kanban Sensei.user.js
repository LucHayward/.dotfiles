// ==UserScript==
// @name            Kanban Sensei
// @author          ashams & kanbansensei-dev team
// @description     One stop shop script for turning SIM into a Kanban board
// @connect         https://sim.amazon.com/*
// @connect         https://issues.amazon.com/*
// @connect         https://issues.cn-northwest-1.amazonaws.cn/*
// @connect         *
// @include         /^https://(issues|i|sim)(-\w+)?\.amazon\.com/sprints/.*/
// @include         /^https://issues.cn-northwest-1.amazonaws.cn/sprints/.*/
// @version         5.55
// @downloadURL     https://axzile.corp.amazon.com/-/carthamus/download_script/kanban-sensei.user.js
// @updateURL       https://axzile.corp.amazon.com/-/carthamus/download_script/kanban-sensei.user.js
// @require         https://cdn.jsdelivr.net/npm/lodash@4.17.4/lodash.min.js
// @grant           unsafeWindow
// @grant           GM_xmlhttpRequest
// @grant           GM_addStyle
// @grant           GM_getResourceText
// @grant           GM_getValue
// @grant           GM_setValue
// @grant           GM_deleteValue
// @grant           GM_listValues
// @website         https://w?Greasemonkey/KanbanSensei
// @run-at          document-start
// ==/UserScript==

/*jshint multistr: true */
/* globals App kanbanSensei $ _ nv d3 canvg Backbone Maxis moment */

// Restricts usage to browsers with a Promise implementation. That's probably fine for our use case,
// given implementation status of ES6.
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise#Browser_compatibility
if (!("Promise" in window)) {
    console.log("Missing Promise implementation!");
}

Date.prototype.withoutTime = function () {
    this.setHours(0, 0, 0, 0);
    return this;
};
Object.defineProperty(unsafeWindow, 'App', {
    get: function() { return this._App; },
    set: function(app) {
        this._App = app;

        // create KanbanSensei object
        unsafeWindow.kanbanSensei = new KanbanSensei();

        // overrides
        this._App.Models = {
            get SprintBoardModel() { return this._SprintBoardModel; },
            set SprintBoardModel(model) {
                // override prototype functions here
                var _initialize = model.prototype.initialize;
                model.prototype.initialize = function() {
                    // add ks hook
                    kanbanSensei.setSprintModel(this);

                    // call super
                    _initialize.apply(this, arguments);
                };

                var _initializeSprint = model.prototype.initializeSprint;
                model.prototype.initializeSprint = function(options, latencyMetric) {
                    // on first load, don't fetch resolved issues!
                    this._fetchResolvedIssues = false;

                    // call super
                    return _initializeSprint.apply(this, arguments);
                };

                // this additional trigger is to identify when the resolved issues have been processed after being fetched
                var __processIssueStateRecalculationQueue = model.prototype._processIssueStateRecalculationQueue;
                model.prototype._processIssueStateRecalculationQueue = function(options) {
                    // call super
                    __processIssueStateRecalculationQueue.apply(this, arguments);

                    this.trigger('issue-state-updated');
                };

                var __fetchSprintIssues = model.prototype._fetchSprintIssues;
                model.prototype._fetchSprintIssues = function(initialFetch) {
                    // remove the omitPath to allow retrieving issue conversations
                    delete this._query.omitPath;

                    const calculateDaysBeforeTodayExcludingWeekends = (days) => {
                        let daysWithoutWeekends = 0;
                        let currentDay = new Date().getDay();
                        let daysBeforeToday = 0;
                        while (daysWithoutWeekends < days) {
                            daysBeforeToday++;
                            currentDay = ((currentDay - 1) + 7) % 7;
                            if (currentDay !== 0 && currentDay !== 6) {
                                daysWithoutWeekends++;
                            }
                        }
                        return daysBeforeToday;
                    }
                    const calculateDaysBeforeToday = (days) => {
                        if (kanbanSensei.getValue('excludeWeekendsFromResolvedIssues', true)) {
                            return calculateDaysBeforeTodayExcludingWeekends(days);
                        } else {
                            return days;
                        }
                    };

                    // how many days of resolved issues to load initially, default 0
                    const resolvedIssueDays = kanbanSensei.getValue('resolvedIssueDays', 0);
                    const daysToShow = resolvedIssueDays !== 0 ? calculateDaysBeforeToday(resolvedIssueDays) : 0;

                    // adjust query string
                    const filterOldResolved = ` AND -(-status:Open AND lastResolvedDate:[* TO NOW-${daysToShow}DAYS])`;
                    this._query.q = `aggregatedLabels:${this._sprintId}${!this._fetchResolvedIssues ? filterOldResolved : ''}`;

                    // add sprint folder filter condition if the feature is turned on
                    if (kanbanSensei.getValue('hideIssuesOutsideSprintFolder', false)) {
                        this._query.q += ` AND containingFolder:(${this._sprintDocumentModel.attributes["assignedFolder"]})`;
                    }

                    return __fetchSprintIssues.apply(this, arguments);
                };

                var __updateSprintIssues = model.prototype._updateSprintIssues;
                model.prototype._updateSprintIssues = function() {
                    for (let id in this._sprintIssuesUpdatesQueue) {
                        let conversation = this._sprintIssuesUpdatesQueue[id].conversation;
                        // if any conversation item has been updated within the last hour
                        if (_.find(conversation, (c) => moment(c.lastUpdatedDate).isAfter(moment().subtract(1, 'hours')))) {
                            kanbanSensei.crManager.processCodeReviewLinks(this._sprintIssuesUpdatesQueue[id]);
                        }
                    }

                    __updateSprintIssues.apply(this, arguments);
                };

                var _changeSprintIssueField = model.prototype.changeSprintIssueField;
                model.prototype.changeSprintIssueField = function(issueId, o) {
                    // call super
                    var superOutput = _changeSprintIssueField.apply(this, arguments);

                    kanbanSensei.processSprintIssueFieldChange(issueId, o);

                    return superOutput;
                };

                this._SprintBoardModel = model;
            }
        };

        this._App.Views = {
            get SprintBoardChartsModal() { return this._SprintBoardChartsModal; },
            set SprintBoardChartsModal(view) {
                // override prototypes
                var _initialize = view.prototype.initialize;
                view.prototype.initialize = function() {
                    // call super
                    _initialize.apply(this, arguments);

                    // add ks hook
                    kanbanSensei.chartsModal = this;
                };

                this._SprintBoardChartsModal = view;
            },

            get SprintBoardLanes() { return this._SprintBoardLanes; },
            set SprintBoardLanes(view) {
                var __onSprintItemsUpdated = view.prototype._onSprintItemsUpdated;
                view.prototype._onSprintItemsUpdated = function(changes) {
                    // call super
                    __onSprintItemsUpdated.apply(this, arguments);

                    kanbanSensei.onSprintItemsUpdated(changes);
                };

                var __onSprintLoad = view.prototype._onSprintLoad;
                view.prototype._onSprintLoad = function(manualTrigger) {
                    // call super
                    try {
                        __onSprintLoad.apply(this, arguments);
                    }
                    catch(e) {
                        console.log(`Error ignored by KanbanSensei`);
                        throw e;
                    }
                    finally {
                        if (this.stateModel.get('sprintState') === 'initialized') {
                            kanbanSensei.onSprintLoad();
                        }
                    }
                };

                this._SprintBoardLanes = view;
            }
        }
    }
});
class CR {
    getId() {
        return this.id;
    }

    getReviewers() {
        return this.reviewers;
    }

    isOpen() {
        return this._isOpen;
    }

    getStatus() {
        return this.status;
    }

    getAuthor() {
        return this.author;
    }

    getSummary() {
        return this.summary;
    }

    getUrl() {
        if (!this.baseUrl) {
            throw new Error('Undefined baseUrl!');    
        }

        return `${this.baseUrl}${this.getId()}`;
    }

    // add constructor with id

    // add fetch function
}
class CruxCR extends CR {
	constructor(rawCr) {
		super();
		this.baseUrl = 'https://code.amazon.com/reviews/';

		let crRevision = rawCr.revision.cr_revision;

	    this.id = crRevision.id.review_revision_id.cr;
	    this.status = crRevision.status;
	    this.author = crRevision.author.entity_id.id;
	    this.summary = crRevision.summary;
	    this._isOpen = crRevision.status === 'OPEN';

	    let approvers = crRevision.approved_by.map((approver) => approver.split(':')[1]);
	    this.reviewers = crRevision.reviewers.map((reviewer) => reviewer.interested_entity)
	    	.filter((reviewer) => reviewer.type === 'USER')
	    	.map((reviewer) => {
	    		return {
	    			name: reviewer.id, 
	    			necessity: `${reviewer.required_count > 0 ? 'required' : 'optional'}`,
	    			status: `${approvers.indexOf(reviewer.id) !== -1 ? 'shipit' : 'pending'}`
	    		};
	    	});
	}
}
class KSBlockedIssuesManager {

    // only called at sprint load time
    processBlockedIssues(task, change) {
        if (change.hasOwnProperty('blocked') && change.blocked) {
            var reason = task.next_step.exceptions.length ? task.next_step.exceptions[0].reasonMessage[0].text : "Blocked";
            this.addBlocked(task.id, reason);
        }

        // there's no `else` here because when we toggle the blocked status of a task to `off`,
        // the `change` passed is just an empty object {}, and the issue data itsels still has
        // the blocked reason populated. That is why I've overridden the _changeSprintIssueField
        // method in MaxisOverrides. That calls KanbanSensei#processSprintIssueFieldChange,
        // which calls the add/remove methods directly.
    }

    removeBlocked(taskId) {
        kanbanSensei.getTaskDom(taskId).find('.ks-blocked-info').remove();
    }

    addBlocked(taskId, reason) {
        // capturing this class object so it can be called from the anonymous function
        var _this = this;

        var blocked = this.ISSUE_BLOCKED_TEMPLATE(reason).click(function(e) {
            // ignore links that are in a blocked reason
            if($(e.target).is("a")) return;

            // TODO: this uses the browser text prompt, which works, but isn't as pretty
            //       as a custom modal would be.
            var updateReason = prompt('Enter new blocked reason...', $(this).find('.ks-blocked-reason').data('rawReason'));

            // this covers the user cancelling out of the prompt
            if (updateReason === null) return;

            var pathEdits = [{
              "path":"/next_step/exceptions",
              "editAction":"PUT",
              "data":[{
                "id": moment().toISOString(),
                "reasonMessage":[{"id":"en-US","text": updateReason}]
              }]
            }];

            App.maxisAPI.issues.createDocumentEdit(taskId, { pathEdits: pathEdits });

            // finally, update the existing blocked info with the new reason
            _this.updateBlockedReason($(this), updateReason);
        });

        kanbanSensei.getTaskDom(taskId).find('.sprint-task-detail-row').first().after(blocked);
    }

    ISSUE_BLOCKED_TEMPLATE(rawReason) {
        var $blockedInfo = $(`
            <div class="ks-blocked-info sprint-task-detail-row">
                <i class="icon-blocked"></i> <span class="ks-blocked-reason"></span>
            </div>
        `);

        this.updateBlockedReason($blockedInfo, rawReason);

        return $blockedInfo;
    }

    URL_LINK_TEMPLATE(url) {
        return `
            <a href="${url}" target="_blank">${url}</a>
        `;
    }

    updateBlockedReason($blockedInfo, rawReason) {
        // perform any mutations to the blocked status here
        var formattedReason = this.replaceTextUrlsWithHyperlinks(rawReason);

        // we add the raw reason to the element data so it can be referred to elsewhere
        $($blockedInfo).find('.ks-blocked-reason')
                .data('rawReason', rawReason)
                .html(formattedReason);
    }

    replaceTextUrlsWithHyperlinks(text) {
        // regex for any URL starting with http or https
        var expression = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)?/gi;

        return text.replace(expression, this.URL_LINK_TEMPLATE);
    }

}
class KSCodeReviewManager {
	constructor() {
        this.crMap = {};
        this.countMap = {};
        // Set of task IDs that are pending a response from the "related resources service""
        this.pendingRelatedItems = new Set();
        this.relatedItemsTimer = undefined;

        // Constants
        this.PICO_IMG_URL = "https://drive.corp.amazon.com/view/ashams@/pico.jpg";

        // cr.amazon.com api URLs. Yes, the trailing slashes matter.
        // A ReviewBoard 'review request' is a code review, and a 'review' is what happens when someone
        // publishes a response.
        this.CR_REVIEW_REQUEST_API_URL = (id) => `https://cr.amazon.com/api/review-requests/${id}/`;
        this.CR_REVIEWS_API_URL = (id) => `https://cr.amazon.com/api/review-requests/${id}/reviews/`;
        this.CRUX_REQUEST_URL = (id) => `https://code.amazon.com/r/${id}`;
        this.SIM_ISSUE_URL = (id) => `https://issues.amazon.com/issues/${id}`;
        this.CRUX_LINK_REGEX = new RegExp(/https:\/\/code.amazon.com\/r(?:eviews)?\/(CR-[0-9]+)/g);
        this.REVIEWBOARD_LINK_REGEX = new RegExp(/https:\/\/cr.amazon.com\/r\/([0-9]+)/g);
	}

	processCodeReviewLinks(task) {
        if (!(task.id in this.crMap)) {
            this.crMap[task.id] = {};
        }
        this.countMap[task.id] = (this.countMap[task.id] || 0) + 1;

        const handleCruxSuccess = (rawCr) => {
            this.fetchCodeReviewDetailsSuccess(task.id, new CruxCR(rawCr));
        };

        const handleReviewBoardSuccess = (results) => {
            this.fetchCodeReviewDetailsSuccess(task.id, new ReviewBoardCR(results[0], results[1]));
        };

        // fetch details for any cr link found in task conversation
        let cruxIds = new Set(), reviewboardIds = new Set();
        for (var k=0; k < task.conversation.length; k++) {
            var entry = task.conversation[k];
            var matches;

            while ((matches = this.CRUX_LINK_REGEX.exec(entry.message)) !== null) {
                cruxIds.add(matches[1]);
            }
            while ((matches = this.REVIEWBOARD_LINK_REGEX.exec(entry.message)) !== null) {
                reviewboardIds.add(matches[1]);
            }
        }

        // remove CRs from the map that may have been deleted from comments
        var deletedCRs = Object.keys(this.crMap[task.id]).filter((id) => !cruxIds.has(id) && !reviewboardIds.has(id));
        _.forEach(deletedCRs, (crId) => {
            delete this.crMap[task.id][crId];
            this.removeCodeReviewLinkFromIssue(task.id, crId);
        });

        // fetch all new and existing CRs for updating
        for (let id of cruxIds.values()) {
            kanbanSensei.makeHttpRequest(this.CRUX_REQUEST_URL(id)).then(handleCruxSuccess);
        }

        for (let id of reviewboardIds.values()) {
            // Yes, the trailing slash matters.
            var review = kanbanSensei.makeHttpRequest(this.CR_REVIEW_REQUEST_API_URL(id));
            var reviewComments = kanbanSensei.makeHttpRequest(this.CR_REVIEWS_API_URL(id));

            Promise.all([review, reviewComments]).then(handleReviewBoardSuccess);
        }

        this.processRelatedItemsThrottled(task.id);
    }

    // This method will schedule a task to be verified for CRs in the related-items service
    // we throttle this call in order to optimize the number of http requests. Since this
    // service supports bulk queries, we can issue a single http request to query all issues
    // in a single shot for better performance
    processRelatedItemsThrottled(taskId) {
        this.pendingRelatedItems.add(taskId);
        if (this.relatedItemsTimer) return;

        this.relatedItemsTimer = setTimeout(() => {
            const taskIds = this.pendingRelatedItems;
            this.pendingRelatedItems = new Set();
            this.relatedItemsTimer = undefined;
            const resources = _.map([...taskIds], this.SIM_ISSUE_URL);
            
            // fetch all related items for those issues
            App.rrsAPI.bulkListDirectRelationships(resources).then(rrsResponse => {
                const allRelated = [];
                for (const related of rrsResponse.Output.relationships) {
                    for (const relationship of related.relationships) {
                        allRelated.push({taskId: relationship.normalized_parent_uri.split('/').pop(), relatedTo: relationship.normalized_child_uri});
                    }
                }
                for (const item of allRelated) {
                    let curCrId = null;
                    let matches = null;
                    while ((matches = this.CRUX_LINK_REGEX.exec(item.relatedTo)) !== null) {
                        curCrId = matches[1];
                    }
                    if (curCrId == null) continue;
                    
                    // Found a CR in the related items - retrieve its details
                    const taskId = item.taskId;
                    kanbanSensei.makeHttpRequest(this.CRUX_REQUEST_URL(curCrId))
                        .then(rawCr => {
                            if(rawCr){
                                this.fetchCodeReviewDetailsSuccess(taskId, new CruxCR(rawCr));
                            }
                        });
                }
            });
        }, 1500);
    }

    fetchCodeReviewDetailsSuccess(taskId, cr) {
        const prevCR = this.crMap[taskId][cr.getId()];
        if (prevCR && _.isEqual(prevCR.getReviewers(), cr.getReviewers()) && prevCR.getStatus() === cr.getStatus()) {
            // we already have details for this CR
            // if the status and reviewers have not changed, return
            return;
        }

        // update CR map
        this.crMap[taskId][cr.getId()] = cr;

        // add to task card
        this.addCodeReviewLink(taskId, cr);

        // Only notify about new CRs if this is a task that we have already processed at least once before
        // This is because CRs from related items can be received asynchronously, and we don't
        // want to trigger a notification during the initial page load
        const shouldNotify = prevCR == null && this.countMap[taskId] > 1;
        
        // display notification if new
        if (shouldNotify && cr.isOpen()) {
            var title = `New Code Review by ${cr.getAuthor()}`;
            var options = {
                body: cr.getSummary(),
                data: {
                    url: cr.getUrl()
                },
                icon: this.PICO_IMG_URL
            };
            kanbanSensei.displayNotification(title, options);
        }
    }

    removeCodeReviewLinkFromIssue(taskId, crId) {
        kanbanSensei.getTaskDom(taskId).find(`.${crId}`).remove();
    }

    addCodeReviewLink(taskId, cr) {
        // remove if already exists
        this.removeCodeReviewLinkFromIssue(taskId, cr.getId());

        // add new link
        kanbanSensei.getTaskDom(taskId).find('.sprint-task-detail-row:first, .ks-blocked-info').last().after(this.CR_LINK_TEMPLATE(cr));

        // tell the wip limit manager to update
        kanbanSensei.wipLimitManager.updatePersonalWipLimits();
    }

    CR_LINK_TEMPLATE(cr) {
        let reviewers = cr.getReviewers().map((r) => this.CR_REVIEWER_TEMPLATE(r)).join(', ');
        let pendingReviewers = cr.getReviewers().filter((r) => r.status === 'pending').map((r) => r.name).join(' ');
        return `
             <div class="cr-link ${cr.getId()} sprint-task-detail-row ${cr.getStatus()}" data-pending-reviewers="${pendingReviewers}">
                <a ${cr.getStatus() == 'CANCELED' ? 'style="color:red"' : ''} target=_blank href="${cr.getUrl()}">${cr.getId()}</a> - <span class="reviewers">${reviewers}</span>
             </div>
        `;
    }

    CR_REVIEWER_TEMPLATE(reviewer) {
        return `
            <span class="cr-reviewer ${reviewer.necessity} ${reviewer.status}">${reviewer.name}</span>
        `;
    }
}
class KSFeatureAlertManager {
    constructor() {
        let alerts = this.FEATURE_ALERT_CONTENT();
        for (let version in alerts) {
          if (parseInt(GM_info.script.version * 10, 10) >= parseInt(version * 10, 10) && !GM_getValue(`featurealert-${version}`)) {
                let $alert = $(this.FEATURE_ALERT_MODAL(version, alerts[version]));
                $('body').append($alert);
                $alert.modal();
                GM_setValue(`featurealert-${version}`, true);
            }
        }
    }

    FEATURE_ALERT_MODAL(version, alertContent) {
        return `
            <div class="modal fade" id="ks-settings-modal" tabindex="-1" role="dialog" aria-labelledby="ksSettingsModalLabel">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="ksSettingsModalLabel">What's new in KanbanSensei ${version}</h4>
                  </div>
                  <div class="modal-body">
                      ${alertContent}
                  </div>
                </div>
              </div>
            </div>
        `
    }

    FEATURE_ALERT_CONTENT() {
        return {
          "4.10": `
          <div>
            <h2>KanbanSensei adds Swim Lane support!</h2>
            <br/>
            SIM Stories (Issues Marked as a Story) that have no parent issues create a Swim Lane within a Sprint Board. Any issues in a Swim Lane were
            previously ignored by KanbanSensei's WIP Limit & resolved issue metrics calculations.  New menu items have been added to the Swimlane's context menu to include
            issues within that lane for Column or Personal WIP Calculations.
            <br/>
            <br/>
            <div style="margin-bottom:10px;text-align:center">
                <img style="margin-bottom:10px" src="https://drive.corp.amazon.com/view/KanbanSensei/feature-alert-images/ks-4.5-1.png" />
                <img src="https://drive.corp.amazon.com/view/KanbanSensei/feature-alert-images/ks-4.5-2.png" />
            </div>
            <br/>
            <br/>
            <h2>Other changes in this release:</h2>
            <ul>
              <li>Added a Menu dropdown to all task cards for taking quick action on issues</li>
              <li>Fixed issue coloring and highlighting when using Swim Lanes</li>
              <li>Fixed a bug when tracking WIP on grouped columns</li>
              <li>Additional settings to enable including blocked issues in column and personal WIP calculations</li>
            </ul>
          </div>
          `,
          "4.22": `
          <div>
            <h2>KanbanSensei can now backup & restore board settings!</h2>
            <br/>
            You can now create a local backup file of your board settings so it can be restored later
            or even shared with other team members to ensure that everyone is using the same Kanban board settings.
            <br/>
            <br/>
            Go ahead and open the KanbanSensei settings to check it out:
            <br/>
            <div style="margin-bottom:10px;text-align:center">
                <img src="https://drive.corp.amazon.com/view/KanbanSensei/feature-alert-images/ks-4.22.png" style="border:1px solid lightgray" />
            </div>
          </div>
          `,
          "5.0": `
          <div>
            <h2>KanbanSensei now stores board settings in the server!</h2>
            <br/>
            KanbanSensei will safely store your board settings in the SIM server, and they will be shared by all users.
            <br/>
            <br/>
            You can opt-out for this feature by selecting "OFFLINE SETTINGS" in the KS configuration screen.
            <br/>
            <div style="margin-bottom:10px;text-align:center">
                <img src="https://drive.corp.amazon.com/view/KanbanSensei/feature-alert-images/ks-5.0.png" style="border:1px solid lightgray" />
            </div>
          </div>
          `,
          "5.28": `
          <div>
            <h2>KanbanSensei metrics modal improved!</h2>
            <br/>
            KanbanSensei now calculates velocity/throughput based on SDE days entered and shows percentage of time spent in each column in a table.
            <br/>
            <br/>
            <div style="margin-bottom:10px;text-align:center">
                <img src="https://drive-render.corp.amazon.com/view/KanbanSensei/feature-alert-images/ks-5.28-1.png" style="border:1px solid lightgray" />
            </div>
            <br/>
            <br/>
            <h2>Other changes in this release:</h2>
            <ul>
              <li>Added estimated points column to resolved tasks and stories</li>
              <li>Added total resolved points to resolved issues metrics table</li>
            </ul>
          </div>
          `,
            "5.34": `
          <div>
            <h2>KanbanSensei can now display task rank</h2>
            <br/>
            Very useful for teams who prioritize tasks using the Rank field
            <br/>
            You can enable it in the board settings.
            <br/>
          </div>
          `,
            "5.35": `
          <div>
            <h2>KanbanSensei can now display task points</h2>
            <br/>
            This surfaces additional context at a glance, and can help catch unestimated tasks.
            <br/>
            Check it out in the KanbanSensei settings:
            <br/>
            <br/>
            <div style="margin-bottom:10px;text-align:center">
                <img src="https://drive-render.corp.amazon.com/view/KanbanSensei/feature-alert-images/ks-5.35-displayEstimateTaskPoints.png" style="border:1px solid lightgray" />
            </div>
          </div>
          `,
            "5.36": `
          <div>
            <h2>KanbanSensei can now display the estimated start date</h2>
            <br/>
            Having tasks with an estimated start date helps teams to know if a task should have already been started. 
            <br/>
            Now this information can be shown on the kanban card, increasing its visibility.
            <br/>
            You can enable it in the board KanbanSensei settings.
            <br/>
            <div style="margin-bottom:10px;text-align:center">
                <img src="https://drive-render.corp.amazon.com/view/KanbanSensei/feature-alert-images/ks-5.36-estimatedStartDate.png" style="border:1px solid lightgray" />
            </div>
          </div>
          `,
            "5.39": `
          <div>
            <h2>KanbanSensei can now display the estimated completion date</h2>
            <br/>
            Having tasks with an estimated completion date helps teams to know if they are on track to complete a task at a glance. 
            <br/>
            Now this information can be shown on the kanban card, increasing its visibility.
            <br/>
            You can enable it in the board KanbanSensei settings.
            <br/>
            <div style="margin-bottom:10px;text-align:center">
                <img src="https://drive-render.corp.amazon.com/view/KanbanSensei/feature-alert-images/ks-5.38-estimatedCompletionDate.png" style="border:1px solid lightgray" />
            </div>
          </div>
          `,
          "5.44": `
         <div>
           <h2>KanbanSensei can now display custom fields</h2>
           <br/>
           You can enter a list of custom fields to show right on the kanban card. 
           <br/>
           You can enable it in the board KanbanSensei settings.
           <br/>
           <div style="margin-bottom:10px;text-align:center">
               <img src="https://drive-render.corp.amazon.com/view/KanbanSensei/feature-alert-images/ks-5.44-displayCustomFields.png" style="border:1px solid lightgray" />
           </div>
         </div>
         `,
         "5.45": `
        <div>
          <h2>KanbanSensei card colors are now stable</h2>
          <br/>
          Previously, card colors could change if the board was updated, but now the colors for a given issue will remain the same troughout its lifetime.
          <br/>
          (You still need to enable card coloring in the settings)
          <br/>
          <div style="margin-bottom:10px;text-align:center">
            <img src="https://drive-render.corp.amazon.com/view/KanbanSensei/feature-alert-images/ks-5.45.png" style="border:1px solid lightgray" />
          </div>
        </div>
        `,
         "5.47": `
          <div>
            <h2>KanbanSensei can now display all resolvers in the Personal WIP Limits row</h2>
            <br/>
            This can be useful in a standup setting, as someone with zero WIP may still have assigned or blocked items on the board.
            <br/>
            You can enable it in the board KanbanSensei settings.
            <br/>
          </div>
        `,
         "5.54": `
          <div>
            <h2>KanbanSensei can hide the stories and tasks that are located outside the sprint folder</h2>
            <br/>
            This can be useful in scenarios where tickets are organized in a hierarchy Epic -> User story -> Engineering story (part of the user story that fits the sprint) -> Implementation task.
            <br/>
            <pre>
\
 |- Backlog -
             |- Product -
                         |- Epic1
                         |- [Epic1] User story 1
             |- Engineering -
                             |- [Story1] Scoped down story part 1
                             |- [Story1] Scoped down story part 2
                             |- Implementation subtask 1
                             |- Implementation subtask 2
             
            </pre>
            In such setup product tickets (epics and user stories) can live in a different backlog folder (let's call it product folder) than the engineering sprint folder (it contains engineering stories and tasks).  
            An SDE sprint board can be assigned to the engineering sprint folder, a product milestone board can be assigned to the product folder.
            <br/>
            Product User stories can now also be assigned to the engineering sprint, giving more context for PMTs or sister-team members. When this additional context is not needed, a new setting can be turned on to filter them out from the engineering sprint-board.    
            <br/>
            Milestone board can also be viewed with or without engineering tickets, toggling the setting. This would allow to start with an overview and then drill-down to the most interesting part along with detailed view that contains engineering tasks.
            <br/>
            Another scenario is when the tickets are organized using multiple parents, e.g. for tracking purposes (sometimes they are called umbrella stories). 
            Umbrella stories also can be part of the board, serving as a container that can be expanded or collapsed to focus on particular part of the board.
            While having such containers is helpful for transparency and certain way of working, it ruins some sprint-board capabilities, like adding a task to the story, and adds some noise for engineers (sprint-board does not support nested stories well). 
            By organizing umbrella tickets outside the sprint folder and toggling the new setting, engineers can focus on sprint stories. 
            <br/>
            You can enable this feature in the board KanbanSensei settings, <code>Hide issues outside the sprint folder</code>.
            <br/>
          </div>
          `,
          "5.55": `
          <div>
            <h2>KanbanSensei now allows you open the interface in focus-mode and configure which columns should be hidden when focus-mode is enabled</h2>
            <br/>
            Focus-mode hides by default the first and last column (typically the large "input queue" and "done") so that the team can focus on the currently "on-going" tasks (very useful for the daily Kanban meetings)
            <br/>
            You can configure it in the board KanbanSensei setting.
            <br/>
          </div>
          `
       }
    }
}
class KSIssueDetailsModal {
    init() {
        if (!this.initPromise) {
            let deferred = $.Deferred();

            this.$issueDetailsModal = $(this.ISSUE_DETAILS_MODAL_TEMPLATE());
            $('body').append(this.$issueDetailsModal);

            // fixes nested modal issues
            this.$issueDetailsModal.on('hidden.bs.modal', () => {
                if($('.modal').hasClass('in')) {
                    $('body').addClass('modal-open');
                }
            });

            // setup sort click handlers
            this.$issueDetailsModal.find('a.sortBy').click((e) => {
                var target = $(e.currentTarget);
                if (this.sortField === target.attr('sort-field')) {
                    // flip order
                    this.sortOrderAsc = !this.sortOrderAsc;
                } else {
                    // change sortByField & make order asc
                    this.sortField = target.attr('sort-field');
                    this.sortOrderAsc = true;
                }
                this.renderIssueTable();
            });

            // nothing else to wait on, immediate resolve
            this.initPromise = deferred.resolve();
        }

        return this.initPromise;
    }

    launch(issues) {
        this.init().then(() => {
            // store the issues for rerendering on sort
            this.issues = issues;

            // defaults
            this.sortField = 'cycleTime';
            this.sortOrderAsc = true;

            this.renderIssueTable();

            this.$issueDetailsModal.modal();
        });
    }

    renderIssueTable() {
        let rows = _.orderBy(this.issues,(issue) => issue[this.sortField], this.sortOrderAsc ? 'asc' : 'desc')
                    .map((issue) => this.ISSUE_DETAIL_ROW_TEMPLATE(issue));

        // set the sort order icon
        this.$issueDetailsModal.find('th i')
            .removeAttr('class')
            .filter((index, el) => $(el).attr('sort-field') === this.sortField)
            .addClass(`${this.sortOrderAsc ? 'icon-arrow-up' : 'icon-arrow-down'}`);

        this.$issueDetailsModal.find('tbody').empty().append(rows);
    }

    ISSUE_DETAIL_ROW_TEMPLATE(issue) {
        return `
            <tr>
                <td><a href="https://sim.amazon.com/${issue.id}" target="_blank" style="white-space: nowrap">${issue.alias}</a></td>
                <td class="title">${issue.title}</td>
                <td class="assignee">${issue.assignee}</td>
                <td>${issue.createDate.toLocaleDateString()}</td>
                <td>${issue.startDate.toLocaleDateString()}</td>
                <td>${issue.endDate.toLocaleDateString()}</td>
                <td>${issue.cycleTime}</td>
                <td>${issue.leadTime}</td>
                <td>${issue.points}</td>
            </tr>
        `;
    }

    ISSUE_DETAILS_MODAL_TEMPLATE() {
        return `
            <div class="modal fade" id="ks-issue-details-modal" tabindex="-1" role="dialog" aria-labelledby="ksIssueDetailsModalLabel">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                      <h4 class="modal-title" id="ksIssueDetailsModalLabel">Issue Details</h4>
                    </div>
                    <div class="modal-body">
                        <table id='ks-issue-details-table' class='table table-striped table-condensed' cellpadding='5' style="width:100%">
                            <thead style="white-space: nowrap">
                                <tr>
                                    <th><a class='sortBy' sort-field='alias' href="javascript://">ID </a><i sort-field='alias'/></th>
                                    <th><a class='sortBy' sort-field='title' href="javascript://">Title </a><i sort-field='title'/></th>
                                    <th><a class='sortBy' sort-field='assignee' href="javascript://">Assignee </a><i sort-field='assignee'/></th>
                                    <th><a class='sortBy' sort-field='createDate' href="javascript://">Create Date </a><i sort-field='createDate'/></th>
                                    <th><a class='sortBy' sort-field='startDate' href="javascript://">Start Date </a><i sort-field='startDate'/></th>
                                    <th><a class='sortBy' sort-field='endDate' href="javascript://">End Date </a><i sort-field='endDate'/></th>
                                    <th><a class='sortBy' sort-field='cycleTime' href="javascript://">Cycle Time (days) </a><i sort-field='cycleTime'/></th>
                                    <th><a class='sortBy' sort-field='leadTime' href="javascript://">Lead Time (days) </a><i sort-field='leadTime'/></th>
                                    <th><a class='sortBy' sort-field='points' href="javascript://">Estimated effort (points) </a><i sort-field='points'/></th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Filled in by js -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    }
}
class KSMCMManager {
    constructor() {
        this.mcmMap = {};
        this.countMap = {};
        this.approversStatus = [];
        this.MCM_REQUEST_API_URL = (id) => `https://mcm.amazon.com/cms/${id}#approvers`;
        this.MCM_LINK_REGEX = new RegExp(/https:\/\/mcm.amazon.com\/cms\/(MCM-[0-9]+)/g);
        this.MCM_COMPLETE_STATUS_LIST = [
            'Completed',
            'Cancelled',
            'Aborted',
            'Closed',
            'Discarded',
        ];
    }

    processMCMLinks(task) {
        if (!(task.id in this.mcmMap)) {
            this.mcmMap[task.id] = {};
        }
        this.countMap[task.id] = (this.countMap[task.id] || 0) + 1;

        // fetch details for any mcm link found in task description
        let mcmIds = new Set();
        var matches;
        while ((matches = this.MCM_LINK_REGEX.exec(task.description)) !== null) {
            mcmIds.add(matches[1]);
        }

        // fetch details for any mcm link found in task conversation
        for (var k=0; k < task.conversation.length; k++) {
            var entry = task.conversation[k];

            while ((matches = this.MCM_LINK_REGEX.exec(entry.message)) !== null) {
                mcmIds.add(matches[1]);
            }
        }

        for (const mcmId of mcmIds) {
            this.addMCMLink(task.id, mcmId);
        }
    }

    removeMCMLinkFromIssue(taskId, mcmId) {
        kanbanSensei.getTaskDom(taskId).find(`.${mcmId}`).remove();
    }

    makeHttpRequest(url, data) {
        return new Promise((resolve, reject) => {
            var request = {
                method: 'GET',
                url: url,
                onerror: reject,
                ontimeout: reject,
                context: null
            };

            request.onload = (response) => {
                 if (response && response.status >= 200 && response.status < 300) {
                     if (request.method === 'GET') {
                        resolve(response);
                     } else {
                        resolve(response);
                     }
                 } else {
                     reject(response);
                 }
             };

            GM_xmlhttpRequest(request);
        }).catch((err) => console.error(err));
    }

    getMcmDetails(response) {
        var parser = new DOMParser();
        var htmlDoc = parser.parseFromString(response.responseText, 'text/html');
        var data = {
            'approvers': this.getMcmApprovers(htmlDoc),
            'status': this.getMcmStatus(htmlDoc)
        };
        return data;
    }

    getMcmApprovers(htmlDoc) {
        var approvers = htmlDoc.getElementById('approversTable').rows;
        var data = [];

        for (var i = 1; i < approvers.length; i++){
            var approverId = approvers.item(i).cells.item(0).textContent.trim();
            var s = approvers.item(i).cells.item(3).textContent.trim();
            var status = s.startsWith("Approved") ? "shipit" : "pending";
            data.push({'id': approverId, 'necessity': 'required', 'status': status});
        }

        return data;
    }

    getMcmStatus(htmlDoc) {
        // Trim off the status suffix (e.g. Completed: Successful > Completed) and trim whitespace 
        return htmlDoc.querySelector('.page-header .label').textContent.split(':')[0].trim()
    }

    addMCMLink(taskId, mcmId) {
        this.removeMCMLinkFromIssue(taskId, mcmId);
        var approvers = [];

        const handleMcmApproversSuccess = (approvers) => {
            this.buildMCMLink(taskId, mcmId, approvers);
        };

        const handleMcmResponse = (response) => {
            return this.getMcmDetails(response);
        }

        this.makeHttpRequest(this.MCM_REQUEST_API_URL(mcmId)).then(handleMcmResponse).then(handleMcmApproversSuccess);
    }

    buildMCMLink(taskId, mcmId, approvers) {
        kanbanSensei.getTaskDom(taskId).find('.sprint-task-detail-row:first, .ks-blocked-info').last().after(this.MCM_LINK_TEMPLATE(mcmId, approvers));
    }

    MCM_LINK_TEMPLATE(mcmId, data) {
        let reviewers = data.approvers.map((r) => this.MCM_REVIEWER_TEMPLATE(r)).join(', ');
        let pendingReviewers = data.approvers.filter((r) => r.status === 'pending').map((r) => r.id).join(' ');
        let status = this.MCM_COMPLETE_STATUS_LIST.includes(data.status) ? "SHIPPED" : "OPEN";
        return `
             <div class="cr-link sprint-task-detail-row ${status}" data-pending-reviewers="${pendingReviewers}">
                <a target=_blank href="https://mcm.amazon.com/cms/${mcmId}">${mcmId}</a> - <span class="reviewers">${reviewers}</span>
             </div>
        `;
    }

    MCM_REVIEWER_TEMPLATE(reviewer) {
        return `
            <span class="cr-reviewer ${reviewer.necessity} ${reviewer.status}">${reviewer.id}</span>
        `;
    }
}
// Defined outside of this class to avoid arrow function unbound 'this' issue
function isResolvedIssue(issue, startDate, endDate) {
    return issue.isResolved
        && issue.endDate >= startDate 
        && issue.endDate <= endDate;
}

function isInProgressOrResolvedIssue(issue, startDate, endDate) {
    if (isResolvedIssue(issue, startDate, endDate)) {
        return true;
    }

    // get startLane for this issue
    return issue.currentLane >= issue.startLane && issue.endDate >= startDate && issue.startDate <= endDate;
}

class KSMetricsModal {
    constructor() {
        this.SVG_CHART_SELECTOR = "#kanban-sensei-chart-svg";
        this.SVG_CHART_IMAGE_SELECTOR = "#kanban-sensei-chart-image-svg";

        this.VELOCITY = 'velocity';
        this.THROUGHPUT = 'throughput';
    }

    init() {
        // all the one time setup stuff here
        // one time setup of modals
        if (!this.initPromise) {
            // grab the metrics modal html and append to body
            this.$metricsModal = $(this.METRICS_MODAL_TEMPLATE());
            $('body').append(this.$metricsModal);

            // setup nested modals
            this.issueDetailsModal = new KSIssueDetailsModal();
            this.$metricsModal.find('button#ksm-story-details').click(() => {
                this.issueDetailsModal.launch(this.stories);
            });
            this.$metricsModal.find('button#ksm-task-details').click(() => {
                this.issueDetailsModal.launch(this.tasks);
            });

            // setup dateRangePicker
            this.dateRangePicker = this.$metricsModal.find('.ks-daterangepicker').daterangepicker();
            this.resetDateRangePicker(); // first initial setting of options

            // setup all the click handlers
            this.dateRangePicker.on('clear.daterangepicker', () => {
                this.resetDateRangePicker();
                this.updateMetricsModal();
            });
            this.dateRangePicker.on('apply.daterangepicker', () => {
                this.updateMetricsModal();
            });

            // override text for 'Clear date range' to say 'Reset date range'
            $('.daterangepicker a.clearDateRange').text('Reset date range');

            this.$metricsModal.find('a#ks-save-image').click((e) => this.saveChartAsImage(e));

            // setup velocity/throughput
            this.$metricsModal.find('button[name="applySdeDays"]').click(() => this.calculateMetric());
            this.$metricsModal.find('#metricToggle').change(evt => this.changeMetric());

            this.initPromise = kanbanSensei.chartsModal._loadChartingLibrary();
        }

        return this.initPromise;
    }

    launch() {
        // initial renderings
        this.init().then(() => {
            if (kanbanSensei.sprintModel._sprintDates.length === 1) {
                // the dates aren't set correctly, warn user
                this.$metricsModal.find('#ks-date-warning').show();
            }

            // show the loading spinner
            this.$metricsModal.find('#ks-metrics-loading').show();
            this.$metricsModal.find('#ks-metrics-content').hide();

            // make sure resolved issues have been fetched
            kanbanSensei.fetchResolvedIssues().then(() => {
                this.$metricsModal.find('#ks-metrics-loading').hide();
                this.$metricsModal.find('#ks-metrics-content').show();
                this.updateMetricsModal();
            });

            // hack to fix daterangepicker positioning
            // if the page was scrolled at all, the calendar popover is positioned incorrectly
            window.scrollTo(0, 0);

            this.$metricsModal.modal();
        });
    }

    resetDateRangePicker() {
        let startDate = new Date(kanbanSensei.sprintModel._sprintDates[0]).withoutTime();
        let endDate = new Date(kanbanSensei.sprintModel._currentDate).withoutTime();
        let dateRangeString = `${moment(startDate).format('MM/DD/YYYY')} - ${moment(endDate).format('MM/DD/YYYY')}`;
        this.dateRangePicker.val(dateRangeString).data('daterangepicker').setOptions({
            startDate: startDate,
            endDate: endDate,
            minDate: startDate,
            maxDate: endDate,
            format: 'MM/DD/YYYY',
            ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
            }
        });
    }

    async updateMetricsModal() {
        // grab dates from picker
        let dateRangePickerData = this.dateRangePicker.data('daterangepicker');
        let startDate = new Date(dateRangePickerData.startDate.format('MM/DD/YYYY'));
        let endDate = new Date(dateRangePickerData.endDate.format('MM/DD/YYYY'));

        const shouldShowTotalPoints = kanbanSensei.getValue('showTotalPointsSpent', false);
        const issueFilter = shouldShowTotalPoints ? isInProgressOrResolvedIssue : isResolvedIssue;
        const issueLabel = shouldShowTotalPoints ? '' : ' Resolved';

        const issueMetrics = (await Promise.all(kanbanSensei.sprintModel._sprintIssues.models // get all issues
            .filter(model => !kanbanSensei.issueIsSwimlane(model)) // filter out swimlane issues
            .map((issue) => kanbanSensei.calculateKanbanMetricsForIssue(issue)))) // calculate metrics
            .filter(i => i)
            .filter(issue => issueFilter(issue, startDate, endDate));

        [this.stories, this.tasks] = _.partition(issueMetrics, 'isStory');

        let taskLeadTime = (_.sumBy(this.tasks, 'leadTime') / this.tasks.length) || -1;
        let storyLeadTime = (_.sumBy(this.stories, 'leadTime') / this.stories.length) || -1;

        const get_spent_points = (sim) => {
            let filtered_efforts = _.sumBy(sim.effortSpent
                .filter((effort) => {
                    const loggedDate = new Date(effort.effortLoggedDate);
                    return loggedDate >= startDate && loggedDate <= endDate
                }), 'effort');

            if (sim.isResolved) {
                filtered_efforts = Math.max(filtered_efforts, sim.points)
            }

            // Default to one point of effort if none logged
            return Math.max(filtered_efforts, 1);
        };

        const aggregator = shouldShowTotalPoints ? get_spent_points : 'points'

        let storyPoints = _.sumBy(this.stories, aggregator);
        let taskPoints = _.sumBy(this.tasks, aggregator);

        let storyCycleTime = this.cycleTime(this.stories);
        let taskCycleTime = this.cycleTime(this.tasks);

        let storyStandardDeviation = this.standardDeviation(this.stories);
        let taskStandardDeviation = this.standardDeviation(this.tasks);

        let storyMeanExcludeOutliers = this.meanExcludingOutliers(this.stories);
        let taskMeanExcludeOutliers = this.meanExcludingOutliers(this.tasks);

        // display data
        this.$metricsModal.find('.story-cycle-time').html(this.NUM_DAYS_STRING_TEMPLATE(storyCycleTime));
        this.$metricsModal.find('.task-cycle-time').html(this.NUM_DAYS_STRING_TEMPLATE(taskCycleTime));

        this.$metricsModal.find('.story-lead-time').html(this.NUM_DAYS_STRING_TEMPLATE(storyLeadTime));
        this.$metricsModal.find('.task-lead-time').html(this.NUM_DAYS_STRING_TEMPLATE(taskLeadTime));

        this.$metricsModal.find('.story-standard-deviation').html(this.NUM_DAYS_STRING_TEMPLATE (storyStandardDeviation));
        this.$metricsModal.find('.task-standard-deviation').html(this.NUM_DAYS_STRING_TEMPLATE (taskStandardDeviation));

        this.$metricsModal.find('.story-exclude-outliers').html(this.NUM_DAYS_STRING_TEMPLATE (storyMeanExcludeOutliers));
        this.$metricsModal.find('.task-exclude-outliers').html(this.NUM_DAYS_STRING_TEMPLATE (taskMeanExcludeOutliers));

        this.$metricsModal.find('.story-display').html(this.stories.length);
        this.$metricsModal.find('.task-display').html(this.tasks.length);

        this.$metricsModal.find('.story-display-points').html(storyPoints);
        this.$metricsModal.find('.task-display-points').html(taskPoints);

        this.$metricsModal.find('.issue-label').html(issueLabel);

        // render the chart
        this.renderCumulativeFlowChart(startDate, endDate);

        // update % time spent in each column
        this.updateTimeSpentInEachColumn();

        //calculate velocity/throughput
        this.calculateMetric();
    }

    standardDeviation(tasks) {
      return Math.sqrt (_.sumBy (tasks, i => Math.pow ((i.cycleTime - this.cycleTime(tasks)), 2)) / tasks.length);
    }

    cycleTime(tasks){
      return (_.sumBy(tasks, 'cycleTime') / tasks.length) || -1;
    }

    meanExcludingOutliers(tasks) {
      let sortedCycleTime = tasks.map(task => task.cycleTime).sort((a, b) => a - b);
      let firstQuartile = sortedCycleTime[Math.floor(sortedCycleTime.length / 4)];
      let thirdQuartile = sortedCycleTime[Math.floor(sortedCycleTime.length / 4) * 3];
      let interquartileRange = (thirdQuartile - firstQuartile) * 1.5;
      let tasksExcludeOutliers = sortedCycleTime.filter(
        i => (i > firstQuartile - interquartileRange) && (i < thirdQuartile + interquartileRange)
      );
      let mean = _.sum(tasksExcludeOutliers) / tasksExcludeOutliers.length;
      if (isNaN(mean)) {
        return 0;
      } else {
        return mean;
      }
    }

    renderCumulativeFlowChart(startDate, endDate) {
        var dates = kanbanSensei.sprintModel.getDates().map((x) => new Date(x).withoutTime());
        var data = kanbanSensei.sprintModel.getCumulativeFlowMetrics();

        dates = dates.slice(0, dates.map(Number).indexOf(+endDate)+1);
        var startIndex = dates.map(Number).indexOf(+startDate);

        // create series data
        var series = [];
        for (var lane in data) {
         var s = { key: lane, values: [] };
         series.push(s);

         // add data
         var laneData = data[lane];
         var doneOffset = 0;
         if (lane === 'Done') {
            doneOffset = laneData[startIndex];
         }

         for (var i = startIndex, l = dates.length; i < l; ++i) {
           s.values.push({ x: dates[i].getTime(), y: (laneData[i]-doneOffset) });
         }
        }
        series.reverse(); // draw done first...

        // graph
        nv.addGraph(() => {
         var chart = nv.models.stackedAreaChart()
            .height(500)
           .color(["#2ca02c", "#ffbb78", "#ff7f0e", "#aec7e8", "#1f77b4", "#6600cc"]);

         chart.xAxis
           .showMaxMin(false)
           .tickFormat((d) => d3.time.format('%x')(new Date(d)));

         chart.yAxis
           .tickFormat(d3.format(',.2f'));

         // draw chart
         var svg = d3.select(this.SVG_CHART_SELECTOR);

         // show chart
         svg.datum(series)
          .transition().duration(500)
          .call(chart)
          .style({'height':500});

         // save chart for image save
         this._drawnChart = {
          chart: chart,
          series: series,
         };

         nv.utils.windowResize(chart.update);

         return chart;
        });
    }

    // generate image of chart to be downloaded
    saveChartAsImage(e) {
        // don't continue if we've already been clicked
        if (this._pendingSaveChart === 'ready') return;
        e.preventDefault();
        if (this._pendingSaveChart === 'pending') return;

        // get svg contents
        this._pendingSaveChart = 'pending';
        var $svg = $(this.SVG_CHART_IMAGE_SELECTOR);
        $svg.empty();

        /** drawChartAsImage **/
        var svgImage = d3.select(this.SVG_CHART_IMAGE_SELECTOR);
        // add white background for save as image
        svgImage.append('svg:rect')
         .attr('width', '100%')
         .attr('height', '100%')
         .attr('fill', '#FFF');

        // show chart
        var chart = this._drawnChart;
        svgImage.datum(chart.series).call(chart.chart);

        // make axis lines black for save as image
        svgImage.selectAll('.nv-axis path').attr('stroke', '#000');

        // don't fill in point paths
        svgImage.selectAll('path.nv-line').attr('fill-opacity', 0);
        /** drawChartAsImage end **/

        setTimeout(() => {
            var svg;
            try {
                svg = $svg[0].outerHTML;
            } catch (ex) {
                // fall back to XMLSerializer for browsers that don't support html()
                var serializer = new XMLSerializer();
                svg = serializer.serializeToString($svg[0]);
            }

            // generate image
            var canvas = document.getElementById('ks-sprint-board-charts-canvas');
            canvg(canvas, svg, {});
            var img = canvas.toDataURL();

            // set uri
            $(e.currentTarget).attr('download', 'kanban-sensei-cmd.png').attr('href', img);

            // trigger click to actually save (need to go native to trigger event)
            this._pendingSaveChart = 'ready';
            e.currentTarget.click();
            this._pendingSaveChart = false;
        }, 500);
    }

    calculateMetric() {
        let sdeDays = this.$metricsModal.find('#sdeDays').val();
        if (sdeDays.length == 0) {
            this.$metricsModal.find('#metricValue').html('Please enter SDE days');
            return;
        }
        let metric = this.$metricsModal.find('#metricHidden').val();
        let result;
        if (metric == this.VELOCITY) {
            let storyPoints = this.$metricsModal.find('.story-display-points').html();
            result = storyPoints / sdeDays;
        } else if (metric == this.THROUGHPUT) {
            let tasks = this.$metricsModal.find('.task-display').html();
            result = tasks / sdeDays;
        }
        this.$metricsModal.find('#metricValue').html(this.NUM_TO_FIXED_DECIMALS(result, 5));
    }

    changeMetric() {
        let val = this.$metricsModal.find('#metricHidden').val();
        let metricChanged;
        if (val == this.VELOCITY) {
            metricChanged = this.THROUGHPUT;
        } else if (val == this.THROUGHPUT) {
            metricChanged = this.VELOCITY;
        }
        this.$metricsModal.find('#metricHidden').val(metricChanged);
        this.calculateMetric();
    }

    updateTimeSpentInEachColumn() {
        let dateRangePickerData = this.dateRangePicker.data('daterangepicker');
        let startDate = new Date(dateRangePickerData.startDate.format('MM/DD/YYYY'));
        let endDate = new Date(dateRangePickerData.endDate.format('MM/DD/YYYY'));

        let dates = kanbanSensei.sprintModel.getDates().map((x) => new Date(x).withoutTime());
        let data = kanbanSensei.sprintModel.getCumulativeFlowMetrics();

        dates = dates.slice(0, dates.map(Number).indexOf(+endDate) + 1);
        let startIndex = dates.map(Number).indexOf(+startDate);

        const DIV = 100;
        let labels = Object.keys(data);
        let percentages = {};
        let length = dates.length;

        labels = labels.slice(1, -1);

        for (let i = startIndex; i < length; i++) {
            let sum = 0;
            labels.forEach(label => {
                sum += data[label][i];
            });
            labels.forEach(label => {
                if (!percentages[label]) {
                    percentages[label] = 0;
                }
                percentages[label] += data[label][i] * DIV / sum;
            });
        }
        labels.forEach(label => {
            percentages[label] /= length - startIndex;
        });

        let rows = labels.map((label) => this.PERCENTAGE_OF_TIME_SPENT_TEMPLATE(label, percentages[label]));
        this.$metricsModal.find('#ks-columns-metrics-table').find('tbody').empty().append(rows);
    }

    NUM_TO_FIXED_DECIMALS(num, dec) {
        return num.toFixed(dec);
    }

    NUM_DAYS_STRING_TEMPLATE(num) {
        return `${num < 0 ? 'n/a' : `${num.toFixed(2)} ${num === 1 ? 'day' : 'days'}`}`;
    }

    RESET_DATE_RANGE_TEMPLATE() {
        return `<a class="resetDateRange">Reset Date Range</a>`;
    }

    METRICS_MODAL_TEMPLATE() {
        return `
            <div class="modal fade" id="ks-metrics-modal" tabindex="-1" role="dialog" aria-labelledby="ksMetricsModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="ksMetricsModalLabel">KanbanSensei Metrics</h4>
                        </div>
                        <div class="modal-body">
                            <h4 id="ks-date-warning" style="display:none;">*** PLEASE SET SPRINT START & END DATES TO ENSURE PROPER KANBAN SENSEI METRICS. SEE <a href='http://w?Greasemonkey/KanbanSensei#HSetup' target='_blank'>WIKI PAGE</a> FOR MORE DETAILS ***</h4>
                            <h2 id="ks-metrics-loading">Loading... <i class="icon-spinner"></i></h2>
                            <div id="ks-metrics-content" style="display:none;">
                                <div class="pull-right">
                                    <svg autofocus id="kanban-sensei-chart-svg" xmlns="http://www.w3.org/2000/svg"/>
                                    <svg class="offscreen" id="kanban-sensei-chart-image-svg" style="width:800px; height: 600px"></svg>
                                    <canvas class='offscreen' height='600px' id='ks-sprint-board-charts-canvas' width='800px'></canvas>

                                    <table id="ks-chart-footer">
                                        <tr>
                                            <td style="text-align:left">
                                                <b><i>*Note: The graph above does not filter out issues that should not be counted in WIP.</i></b>
                                            </td>
                                            <td style="text-align:right">
                                                <a id="ks-save-image" href="javascript://" target="_blank">Download as an image</a>
                                            </td>
                                        </tr>
                                    </table>
                                </div>

                                <form class="form-horizontal">
                                    <fieldset>
                                        <div class="control-group">
                                          <label class="control-label">
                                            Date Range
                                          </label>
                                          <div class="controls">
                                            <span class="input-append">
                                                <input autocomplete="off" class="input-large ks-daterangepicker" name="dateRange" type="text">
                                                <span class="add-on">
                                                  <i class="icon-calendar"></i>
                                                </span>
                                            </span>
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label">
                                            SDE Days
                                          </label>
                                          <div class="controls">
                                            <span class="input-append">
                                                <input autocomplete="off" class="input-large" id="sdeDays" type="text">
                                                <button type="button" class="btn btn-primary save" name="applySdeDays">Apply</button>
                                            </span>
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label">
                                            <span class="issue-label"/> Issue Metrics
                                          </label>
                                          <div class="controls">
                                            <table id="ks-metrics-table" class="table table-condensed table-striped">
                                                <thead>
                                                    <tr>
                                                        <td><!-- empty cell --></td>
                                                        <td><!-- empty cell --></td>
                                                        <th>Stories</th>
                                                        <th>Tasks</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <th>Total <span class="issue-label"/></th>
                                                        <td><!-- empty cell --></td>
                                                        <td class="story-display"></td>
                                                        <td class="task-display"></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Total <span class="issue-label"/> Points</th>
                                                        <td><!-- empty cell --></td>
                                                        <td class="story-display-points"></td>
                                                        <td class="task-display-points"></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Avg Cycle Time</th>
                                                        <td><!-- empty cell --></td>
                                                        <td class="story-cycle-time"></td>
                                                        <td class="task-cycle-time"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><!-- empty cell --></td>
                                                        <th>Standard Deviation</th>
                                                        <td class="story-standard-deviation"></td>
                                                        <td class="task-standard-deviation"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><!-- empty cell --></td>
                                                        <th>Mean Excluding Outliers</th>
                                                        <td class="story-exclude-outliers"></td>
                                                        <td class="task-exclude-outliers"></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Avg Lead Time</th>
                                                        <td><!-- empty cell --></td>
                                                        <td class="story-lead-time"></td>
                                                        <td class="task-lead-time"></td>
                                                    </tr>
                                                    <tr>
                                                        <td><!-- empty cell --></td>
                                                        <td><!-- empty cell--></td>
                                                        <td>
                                                            <button type="button" class="ks-btn-sm btn btn-default" id='ksm-story-details'>View story details</button>
                                                        </td>
                                                        <td>
                                                            <button type="button" class="ks-btn-sm btn btn-default" id='ksm-task-details'>View task details</button>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label style="display: inline-block; padding-left: 2%">
                                            Velocity
                                          </label>
                                          <label class="ks-switch">
                                           <input type="checkbox" id="metricToggle">
                                           <span class="ks-slider ks-round"></span>
                                          </label>
                                          <input type="hidden" id="metricHidden" value="velocity"></input>
                                          <label style="display: inline-block;">
                                            Throughput
                                          </label>
                                          <div class="controls" style="display: inline-block">
                                            <span id="metricValue"></span>
                                          </div>
                                        </div>
                                        <div class="control-group">
                                          <label class="control-label">
                                            Percentage of time spent in each column
                                          </label>
                                          <div class="controls">
                                            <table id="ks-columns-metrics-table" class="table table-condensed table-striped" align="left">
                                                <thead>
                                                    <tr>
                                                        <td><!-- empty cell --></td>
                                                        <th>%</th>
                                                    </tr>
                                                </thead>
                                                <tbody/>
                                            </table>
                                          </div>
                                        </div>
                                    </fieldset>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    PERCENTAGE_OF_TIME_SPENT_TEMPLATE(label, value) {
        return `
             <tr>
               <th>${label}</th>
               <td class="input-queue">${this.NUM_TO_FIXED_DECIMALS(value, 2)}</td>
             </tr>
        `;
    }
}
class KSSettingsModal {
    init() {
        if (!this.initPromise) {
            let deferred = $.Deferred();

            this.$modal = $(this.SETTINGS_MODAL_TEMPLATE());
            $('body').append(this.$modal);

            this.$modal.find('select[name="displayAvatars"]').change(evt => this.onDisplayAvatarsChanged(evt));
            this.$modal.find('button.save').click(() => this.onSave());
            // Backup & restore hooks
            this.$modal.find('button[name="downloadSettings"]').click(() => this.onDownloadSettings());
            this.$modal.find('span[name="restoreFileButton"]').click(() => this.$modal.find('input[name="restoreFile"]').click());
            this.$modal.find('input[name="restoreFile"]').change(evt => this.onRestoreFile(evt));
            this.$modal.find('input[name="offlineSettings"]').change(evt => {
              const isChecked = $(evt.target).is(':checked');
              const isOffline = kanbanSensei.getValue('offlineSettings', false);
              const hasServerSettings = kanbanSensei.hasServerSettings();
              if (!isChecked && isOffline && hasServerSettings) {
                // When un-checking this box, as if the user wants to reload settings from the server
                // otherwise, they could replace the shared server settings with their own by mistake
                if (confirm('Are you sure you’d like to switch to online settings? All local changes will be replaced with this board’s online settings')) {
                  kanbanSensei.setValue('offlineSettings', false);
                  kanbanSensei.loadSettingsFromServer();
                } else {
                  $(evt.target).prop("checked", true);
                }
              } else if (isChecked && !isOffline) {
                if (!confirm('You’re about to switch to offline settings, any changes to settings will not be persisted')) {
                  $(evt.target).prop("checked", false);
                }
              }
            });

            this.initPromise = deferred.resolve();
        }

        return this.initPromise;
    }

    // Show additional input if "custom" is selected
    onDisplayAvatarsChanged(evt) {
      $("#customAvatarUrlInput").toggle(evt.currentTarget.value == "custom");
    }

    onSave() {
        this.$modal.find('#ks-sprint-lanes-table input:checked').each((index, el) => {
            kanbanSensei.setValue($(el).attr('name'), parseInt($(el).val()));
        });

        kanbanSensei.setValue('columnChecksum', kanbanSensei.columnChecksum());

        // this will exclude the Done lane, as tasks in the Done lane are never allowed to be included in the
        // personal WIP limits.
        var personalWipColumnInclusionMask = $.map(this.$modal.find('#ks-columns-personal-wip-inclusion input'),
                (el, index) => $(el).prop("checked"));
        kanbanSensei.setValue('personalWipColumnsIncluded', personalWipColumnInclusionMask);

        kanbanSensei.setValue('personalWipDisplay', this.$modal.find('select[name="personalWipDisplay"]').val());
        kanbanSensei.setValue('personalWipLimit', this.$modal.find('input[name="personalWip"]').val());
        kanbanSensei.setValue('personalWipIncludeStories', this.$modal.find('input[name="personalWipIncludeStories"]').is(':checked'));
        kanbanSensei.setValue('personalWipIncludeCRs', this.$modal.find('input[name="personalWipIncludeCRs"]').is(':checked'));
        kanbanSensei.setValue('personalWipIncludeBlocked', this.$modal.find('input[name="personalWipIncludeBlocked"]').is(':checked'));
        kanbanSensei.setValue('columnWipIncludeBlocked', this.$modal.find('input[name="columnWipIncludeBlocked"]').is(':checked'));
        kanbanSensei.setValue('columnWipIncludeStories', this.$modal.find('input[name="columnWipIncludeStories"]').is(':checked'));
        kanbanSensei.setValue('additionalCountersIncludeOthers', this.$modal.find('input[name="additionalCountersIncludeOthers"]').is(':checked'));
        kanbanSensei.setValue('additionalCountersIncludeNobody', this.$modal.find('input[name="additionalCountersIncludeNobody"]').is(':checked'));
        kanbanSensei.setValue('additionalCountersIncludeBlocked', this.$modal.find('input[name="additionalCountersIncludeBlocked"]').is(':checked'));
        kanbanSensei.setValue('hideIssuesOutsideSprintFolder', this.$modal.find('input[name="hideIssuesOutsideSprintFolder"]').is(':checked'));
        kanbanSensei.setValue('excludeWeekends', this.$modal.find('input[name="excludeWeekends"]').is(':checked'));
        kanbanSensei.setValue('showTotalPointsSpent', this.$modal.find('input[name="showTotalPointsSpent"]').is(':checked'));
        kanbanSensei.setValue('resolvedIssueDays', this.$modal.find('input[name="resolvedIssueDays"]').val());
        kanbanSensei.setValue('excludeWeekendsFromResolvedIssues', this.$modal.find('input[name="excludeWeekendsFromResolvedIssues"]').is(':checked'));
        kanbanSensei.setValue('colorizeTasks', this.$modal.find('select[name="colorizeTasks"]').val());
        kanbanSensei.setValue('displayAvatars', this.$modal.find('select[name="displayAvatars"]').val());
        kanbanSensei.setValue('customAvatarBaseUrl', this.$modal.find('input[name="customAvatarBaseUrl"]').val());
        kanbanSensei.setValue('storiesProgressBar', this.$modal.find('input[name="storiesProgressBar"]').is(':checked'));
        kanbanSensei.setValue('taskRank', this.$modal.find('input[name="taskRank"]').is(':checked'));
        kanbanSensei.setValue('displayEstimateTaskPoints', this.$modal.find('select[name="displayEstimateTaskPoints"]').val());
        kanbanSensei.setValue('displayEstimatedStartDate', this.$modal.find('input[name="displayEstimatedStartDate"]').is(':checked'));
        kanbanSensei.setValue('displayEstimatedCompletionDate', this.$modal.find('input[name="displayEstimatedCompletionDate"]').is(':checked'));
        kanbanSensei.setValue('displayPointCounter', this.$modal.find('input[name="displayPointCounter"]').is(':checked'));
        kanbanSensei.setValue('offlineSettings', this.$modal.find('input[name="offlineSettings"]').is(':checked'));
        kanbanSensei.setValue('displayCustomFields', this.$modal.find('textarea[name="displayCustomFields"]').val());
        kanbanSensei.setValue('openInFocusMode', this.$modal.find('input[name="openInFocusMode"]').is(':checked'));
        kanbanSensei.setValue('focusModeHideColumns', this.$modal.find('input[name="focusModeHideColumns"]').val());

        [
            'trackingAllSwimLaneColumnWIP',
            'trackingAllSwimLanePersonalWIP'
        ].forEach(key => {
            kanbanSensei.setValue(key, this.$modal.find(`input[name="${key}"]`).is(':checked'));
        });

        kanbanSensei.updateKanbanMetricsForOpenIssues();
        kanbanSensei.addRankForIssues();
        kanbanSensei.wipLimitManager.updatePersonalWipLimits();
        kanbanSensei.wipLimitManager.updateHeaders();

        this.$modal.modal('hide');
        kanbanSensei.saveSettingsToServer();
    }

    onDownloadSettings() {
      function download(filename, text) {
        const element = document.createElement('a');
        element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
        element.setAttribute('download', filename);
        element.style.display = 'none';
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
      }
      const settingsString = kanbanSensei.getBackupSettingsJSON();
      const fileName = `KanbanSensei-${kanbanSensei.sprintModel._sprintId}.json`;
      download(fileName, settingsString);
    }

    onRestoreFile(evt) {
      const files = evt.target.files;
      if (!files.length) {
        return;
      }
      const file = files[0];
      const reader = new FileReader();
      reader.onloadend = read => {
        if (read.target.readyState == FileReader.DONE) {
          const data = read.target.result;
          evt.target.value = null;
          try {
            kanbanSensei.restoreSettingsFromJSON(data, true);
          } catch (error) {
            console.log(error);
            alert("Invalid file selected. Please try again")
          }
        }
      };
      reader.readAsBinaryString(file);
    }

    launch() {
        this.init().then(() => {
          // setup sprint lanes
          let storyStart = kanbanSensei.getValue('storyStart', 1);
          let taskStart = kanbanSensei.getValue('taskStart', 1);
          let sprintLanesTable = this.$modal.find('#ks-sprint-lanes-table').find('tbody');

          let lanes = kanbanSensei.sprintModel._sprintLanes.map((lane, index) => {
              return this.SPRINT_LANE_TABLE_ROW_TEMPLATE(
                  index,
                  lane.label[0] ? lane.label[0].text : lane.shortName,
                  storyStart === index ? 'checked' : '',
                  taskStart === index ? 'checked' : ''
              );
          }).slice(1, kanbanSensei.sprintModel._sprintLanes.length-1); // get rid of backlog & done lanes
          sprintLanesTable.empty().append(lanes);

          // setup personal WIP limits inclusion table
          let wipColumnsIncluded = kanbanSensei.areColumnSettingsStale() ? [] : kanbanSensei.getValue('personalWipColumnsIncluded', []);
          let personalWipColumnsTable = this.$modal.find('#ks-columns-personal-wip-inclusion').find('tbody');
          let wipColumnTableRows = kanbanSensei.sprintModel._sprintLanes.map((lane, index) => {
              return this.COLUMN_PERSONAL_WIP_INCLUSION_TABLE_ROW_TEMPLATE(
                  index,
                  lane.label[0] ? lane.label[0].text : lane.shortName,
                  wipColumnsIncluded.length == 0 || wipColumnsIncluded[index] ? 'checked' : ''
              );
          }).slice(0, kanbanSensei.sprintModel._sprintLanes.length-1); // get rid of 'Done' lane; tasks in 'Done' should never be counted
          personalWipColumnsTable.empty().append(wipColumnTableRows);

          // Set personal WIP limit options
          this.$modal.find('select[name="personalWipDisplay"]').val(kanbanSensei.getValue('personalWipDisplay', 'activeResolvers'));
          this.$modal.find('input[name="personalWip"]').val(kanbanSensei.getValue('personalWipLimit', 3));
          this.$modal.find('input[name="personalWipIncludeStories"]').prop('checked', kanbanSensei.getValue('personalWipIncludeStories', true));
          this.$modal.find('input[name="personalWipIncludeCRs"]').prop('checked', kanbanSensei.getValue('personalWipIncludeCRs', true));
          this.$modal.find('input[name="personalWipIncludeBlocked"]').prop('checked', kanbanSensei.getValue('personalWipIncludeBlocked', false));
          this.$modal.find('input[name="columnWipIncludeBlocked"]').prop('checked', kanbanSensei.getValue('columnWipIncludeBlocked', false));
          this.$modal.find('input[name="columnWipIncludeStories"]').prop('checked', kanbanSensei.getValue('columnWipIncludeStories', true));

          var that = this;
          [
              'trackingAllSwimLaneColumnWIP',
              'trackingAllSwimLanePersonalWIP'
          ].forEach(key => {
              that.$modal.find(`input[name="${key}"]`).prop('checked', kanbanSensei.getValue(key, false));
          });

          // Set additional counters options
          this.$modal.find('input[name="additionalCountersIncludeOthers"]').prop('checked', kanbanSensei.getValue('additionalCountersIncludeOthers', false));
          this.$modal.find('input[name="additionalCountersIncludeNobody"]').prop('checked', kanbanSensei.getValue('additionalCountersIncludeNobody', false));
          this.$modal.find('input[name="additionalCountersIncludeBlocked"]').prop('checked', kanbanSensei.getValue('additionalCountersIncludeBlocked', false));

          // Set metrics options
          this.$modal.find('input[name="excludeWeekends"]').prop('checked', kanbanSensei.getValue('excludeWeekends', false));
          this.$modal.find('input[name="showTotalPointsSpent"]').prop('checked', kanbanSensei.getValue('showTotalPointsSpent', false));

          // Set display options
          this.$modal.find('input[name="hideIssuesOutsideSprintFolder"]').prop('checked', kanbanSensei.getValue('hideIssuesOutsideSprintFolder', false));
          this.$modal.find('input[name="resolvedIssueDays"]').val(kanbanSensei.getValue('resolvedIssueDays', 0));
          this.$modal.find('input[name="excludeWeekendsFromResolvedIssues"]').prop('checked', kanbanSensei.getValue('excludeWeekendsFromResolvedIssues', true));
          this.$modal.find('select[name="colorizeTasks"]').val(kanbanSensei.getValue('colorizeTasks', 'all'));
          this.$modal.find('select[name="displayAvatars"]').val(kanbanSensei.getValue('displayAvatars', 'off')).trigger('change');
          this.$modal.find('input[name="customAvatarBaseUrl"]').val(kanbanSensei.getValue('customAvatarBaseUrl', ''));
          this.$modal.find('input[name="storiesProgressBar"]').prop('checked', kanbanSensei.getValue('storiesProgressBar', true));
          this.$modal.find('input[name="taskRank"]').prop('checked', kanbanSensei.getValue('taskRank', false));
          this.$modal.find('select[name="displayEstimateTaskPoints"]').val(kanbanSensei.getValue('displayEstimateTaskPoints', 'never'));
          this.$modal.find('input[name="displayEstimatedStartDate"]').prop('checked', kanbanSensei.getValue('displayEstimatedStartDate', false));
          this.$modal.find('input[name="displayEstimatedCompletionDate"]').prop('checked', kanbanSensei.getValue('displayEstimatedCompletionDate', false));
          this.$modal.find('input[name="displayPointCounter"]').prop('checked', kanbanSensei.getValue('displayPointCounter', false));
          this.$modal.find('textarea[name="displayCustomFields"]').val(kanbanSensei.getValue('displayCustomFields', ""));
          this.$modal.find('input[name="openInFocusMode"]').prop('checked', kanbanSensei.getValue('openInFocusMode', false));
          this.$modal.find('input[name="focusModeHideColumns"]').val(kanbanSensei.getValue('focusModeHideColumns', ""));

          // Settings sync options
          this.$modal.find('input[name="offlineSettings"]').prop('checked', kanbanSensei.getValue('offlineSettings', false));

          this.$modal.modal();
      });
    }

    SETTINGS_MODAL_TEMPLATE() {
      return `
          <div class="modal fade" id="ks-settings-modal" tabindex="-1" role="dialog" aria-labelledby="ksSettingsModalLabel">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title" id="ksSettingsModalLabel">KanbanSensei Settings</h4>
                </div>
                <div class="modal-body">
                  <form class="form-horizontal">
                    <legend style="margin-bottom:0">Work In Progress (WIP) Calculations</legend>
                    <div class="control-group">
                      <label class="control-label">
                        Display Personal WIP
                      </label>
                      <div class="controls">
                        <select class="input-large" name="personalWipDisplay">
                          <option value="none">None</option>
                          <option value="activeResolvers">Active resolvers</option>
                          <option value="allResolvers">All resolvers</option>
                        </select>
                        <div class="help-block">
                          Choose what to display in the Personal WIP.<br/>
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Personal WIP Limit
                      </label>
                      <div class="controls">
                        <input class="input-mini" name="personalWip" value="" min="1" type="number">
                        <div class="help-block">
                          Must be a number &gt;= 1
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Inclusion Options
                      </label>
                      <div class="controls">
                        <table id="ks-personal-wip-table" class="table table-condensed" cellpadding="5" style="width:100%">
                          <thead>
                            <tr>
                              <th>WIP Calculation</th>
                              <th>Assignee Type</th>
                              <th>Include?</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>Personal WIP</td>
                              <td>Stories</td>
                              <td><input type="checkbox" name="personalWipIncludeStories"></td>
                            </tr>
                            <tr>
                              <td>Personal WIP</td>
                              <td>Code Reviews and MCMs</td>
                              <td><input type="checkbox" name="personalWipIncludeCRs"></td>
                            </tr>
                            <tr>
                              <td>Personal WIP</td>
                              <td>Blocked Issues</td>
                              <td><input type="checkbox" name="personalWipIncludeBlocked"></td>
                            </tr>
                            <tr>
                              <td>Column WIP</td>
                              <td>Blocked Issues</td>
                              <td><input type="checkbox" name="columnWipIncludeBlocked"></td>
                            </tr>
                            <tr>
                              <td>Column WIP</td>
                              <td>Stories</td>
                              <td><input type="checkbox" name="columnWipIncludeStories"></td>
                            </tr>
                          </tbody>
                        </table>

                        <table id="ks-personal-wip-table" class="table table-condensed" cellpadding="5" style="width:100%">
                          <thead>
                            <tr>
                              <th>WIP Calculation</th>
                              <th>Include All Stories By Default?</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>Personal WIP</td>
                              <td><input type="checkbox" name="trackingAllSwimLanePersonalWIP"></td>
                            </tr>
                            <tr>
                              <td>Column WIP</td>
                              <td><input type="checkbox" name="trackingAllSwimLaneColumnWIP"></td>
                            </tr>
                          </tbody>
                        </table>

                        <div class="help-block">
                            Personal WIP counts the total issues per assignee, which may include code review tasks. <br/>
                            Column WIP counts the total issues in a WIP assigned column, regardless of ownership. <br/>
                            Use the checkboxes above to toggle filters on the WIP calculation.
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label hint-bottom-left" data-hint="Select which column(s) count towards a user's personal WIP limit">
                          Personal WIP Count Column Inclusion
                        </label>
                        <div class="controls">
                          <table id="ks-columns-personal-wip-inclusion" class="table table-striped table-condensed" cellpadding="5" style="width:100%">
                            <thead>
                              <tr>
                                <th>Lane</th>
                                <th>Include?</th>
                              </tr>
                            </thead>
                            <tbody>
                              <!-- Gets filled in by js -->
                            </tbody>
                          </table>
                          <div class="help-block">
                              You can exclude specific column(s) from personal WIP limits by unchecking the corresponding boxes
                              in the table above. <b>Note:</b> if you change your Kanban columns in any way, you must reconfigure
                              these settings.
                          </div>
                        </div>
                      </div>
                      <label class="control-label">
                        Additional Counters
                      </label>
                      <div class="controls">
                        <table id="ks-additional-counters-table" class="table table-condensed" cellpadding="5" style="width:100%">
                          <thead>
                            <tr>
                              <th>Type</th>
                              <th>Description</th>
                              <th>Include?</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>Others</td>
                              <td>Issues assigned to users not on the board's team</td>
                              <td><input type="checkbox" name="additionalCountersIncludeOthers"></td>
                            </tr>
                            <tr>
                              <td>Nobody</td>
                              <td>Issues that are assigned to nobody</td>
                              <td><input type="checkbox" name="additionalCountersIncludeNobody"></td>
                            </tr>
                            <tr>
                              <td>Blocked</td>
                              <td>Issues that are blocked</td>
                              <td><input type="checkbox" name="additionalCountersIncludeBlocked"></td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <legend style="margin-bottom:0">Metrics</legend>
                    <div class="control-group">
                      <label class="control-label hint-bottom-left" data-hint="Select a lane for Story/Task start (affects cycle time)">
                        Cycle Time Start Lanes
                      </label>
                      <div class="controls">
                        <table id="ks-sprint-lanes-table" class="table table-striped table-condensed" cellpadding="5" style="width:100%">
                          <thead>
                            <tr>
                              <th>Lane</th>
                              <th>Story Start</th>
                              <th>Task Start</th>
                            </tr>
                          </thead>
                          <tbody>
                            <!-- Gets filled in by js -->
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Exclude Weekends
                      </label>
                      <div class="controls">
                        <input name="excludeWeekends" type="checkbox">
                        <div class="help-block">
                          Checking this box will exclude weekends from cycle &amp; lead time metrics.
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Show Total Points Spent
                      </label>
                      <div class="controls">
                        <input name="showTotalPointsSpent" type="checkbox">
                        <div class="help-block">
                          Checking this box will display total points spent for all issues worked within timeframe rather than only resolved issues. 
                        </div>
                      </div>
                    </div>
                    <legend style="margin-bottom:0">Display</legend>
                    <div class="control-group">
                      <label class="control-label">
                        Hide issues outside the sprint folder
                      </label>
                      <div class="controls">
                        <input name="hideIssuesOutsideSprintFolder" type="checkbox">
                        <div class="help-block">
                          Checking this box will exclude issues outside the sprint folder (and its subfolders).<br/>
                          <b>* Requires page reload to take effect *</b>
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Last X Days of Resolved Issues
                      </label>
                      <div class="controls">
                        <input class="input-mini" name="resolvedIssueDays" value="" min="0" type="number">
                        <div class="help-block">
                          This is the number of days, prior to today, of resolved issues to load on initial page load. Defaults to 0.<br/>
                          You can load ALL resolved issues by clicking the button in the Done column header.<br/>
                          <b>* Requires page reload to take effect *</b>
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Exclude Weekends
                      </label>
                      <div class="controls">
                        <input name="excludeWeekendsFromResolvedIssues" type="checkbox">
                        <div class="help-block">
                          Checking this box will exclude weekends from the number of days to show resolved issues for.
                          <b>* Requires page reload to take effect *</b>
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Colorize cards
                      </label>
                      <div class="controls">
                        <select class="input-large" name="colorizeTasks">
                          <option value="all">All cards</option>
                          <option value="stories">Stories and sub-tasks</option>
                          <option value="none">None (do not colorize)</option>
                        </select>
                        <div class="help-block">
                          Choose which task cards to be colorized.<br/>
                          <b>* Requires page reload to take effect *</b>
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Display assignee avatars
                      </label>
                      <div class="controls">
                        <select class="input-large" name="displayAvatars">
                          <option value="off">Off</option>
                          <option value="phonetool">PhoneTool</option>
                          <option value="custom">Custom</option>
                        </select>
                        <div class="help-block">
                          Choose if you want to display avatars.<br/>
                          <b>* Requires page reload to take effect *</b>
                        </div>
                        <div id="customAvatarUrlInput" class="custom-field input-wrapper" style="padding:10px;">
                          <input class="input-medium" name="customAvatarBaseUrl" value="">
                          <div class="help-block">
                            <i class='icon-info-sign'></i>
                            To show custom avatars, add photos to a public Amazon Drive folder where each avatar is named "&lt;alias&gt.jpg".<br/>
                            Then place the URL of that folder here.<br/>
                            <i>ex. https://drive.corp.amazon.com/personal/&lt;your_alias&gt;/CustomAvatars</i></br>
                            <i>ex. https://drive.corp.amazon.com/folders/&lt;team_name&gt;/TeamPics</i></br>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Display progress bars on SIM stories
                      </label>
                      <div class="controls">
                        <input type="checkbox" name="storiesProgressBar">
                        <div class="help-block">
                            Choose if you want to see progress bar in SIM stories<br/>
                            <b>* Requires page reload to take effect *</b>
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Display Rank
                      </label>
                      <div class="controls">
                        <input type="checkbox" name="taskRank">
                        <div class="help-block">
                            Choose if you want to see rank of tasks<br/>
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Show Task Points
                      </label>
                      <div class="controls">
                        <select class="input-large" name="displayEstimateTaskPoints">
                          <option value="never">Never</option>
                          <option value="start">Started tasks</option>
                          <option value="open">All open tasks</option>
                        </select>
                        <div class="help-block">
                          Choose when to display estimated task points in addition to the default task metrics.<br/>
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Show Estimated Start Date
                      </label>
                      <div class="controls">
                        <input type="checkbox" name="displayEstimatedStartDate">
                        <div class="help-block">
                            Choose if you want to see the estimated start date.<br/>
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Show Estimated Completion Date
                      </label>
                      <div class="controls">
                        <input type="checkbox" name="displayEstimatedCompletionDate">
                        <div class="help-block">
                            Choose if you want to see the estimated completion date.<br/>
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Show Point Counter
                      </label>
                      <div class="controls">
                        <input type="checkbox" name="displayPointCounter">
                        <div class="help-block">
                            Choose if you want to see the point counter to the right of the assignee.<br/>
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                      <label class="control-label">
                        Custom Fields
                      </label>
                      <div class="controls">
                        <textarea name="displayCustomFields" rows="4" cols="50" />
                        <div class="help-block">
                          Comma seperated List of Custom Fields to display in the card<br/>
                          <b>* Requires page reload to take effect *</b>
                        </div>
                      </div>
                    </div>
                    <div class="control-group">
                    <label class="control-label">
                      Open in Focus Mode
                    </label>
                    <div class="controls">
                      <input type="checkbox" name="openInFocusMode" />
                      <div class="help-block">
                        Open the interface in focus-mode<br/>
                        <b>* Requires page reload to take effect *</b>
                      </div>
                    </div>
                  </div>
                    <div class="control-group">
                      <label class="control-label">
                        Focus Mode - Hide Columns
                      </label>
                      <div class="controls">
                        <input name="focusModeHideColumns" />
                        <div class="help-block">
                          Comma seperated List of Column indexes (starting with 1) to hide in focus mode<br/>
                          <b>* Requires page reload to take effect *</b>
                        </div>
                      </div>
                    </div>
                    <legend style="margin-bottom:0">Backup, restore & synchronize settings</legend>
                    <div class="control-group">
                      <div class="controls">
                        <button type="button" name="downloadSettings" class="btn btn-default">
                          <span class="icon-download-alt"></span> Download board settings
                        </button>
                        <span class="fileinput-button">
                          <input name="restoreFile" type="file" style="position:absolute;z-index:-999">
                          <span class="btn btn-default" name="restoreFileButton">
                            <i class="icon-paper-clip"></i>
                            Restore board settings...
                          </span>
                        </span>
                        <div class="help-block">
                          Backup & restore KanbanSensei settings for this board.
                        </div>
                      </div>
                    </div>
                    <label class="control-label">
                    Offline settings
                    </label>
                    <div class="controls">
                      <input name="offlineSettings" type="checkbox">
                      <div class="help-block">
                        Settings will not be synchronized with the server and will be stored locally only.
                      </div>
                    </div>
                  </form>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-primary save">Save changes</button>
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>
            </div>
          </div>
        `;
    }

    SPRINT_LANE_TABLE_ROW_TEMPLATE(index, lane, storyStartChecked, taskStartChecked) {
        return `
            <tr>
                <td>${lane}</td>
                <td><input type="radio" id="storyStart${index}" name="storyStart" value="${index}" ${storyStartChecked}></td>
                <td><input type="radio" id="taskStart${index}" name="taskStart" value="${index}" ${taskStartChecked}></td>
            </tr>
        `;
    }

    COLUMN_PERSONAL_WIP_INCLUSION_TABLE_ROW_TEMPLATE(index, lane, checked) {
        return `
            <tr>
                <td>${lane}</td>
                <td><input type="checkbox" id="personalWipColumn${index}" name="personalWipColumn" value="${index}" ${checked}></td>
            </tr>
        `;
    }
}
class KSWIPLimitManager {
	constructor() {
		this.headersLinks = [];
        this.subHeadersLinks = [];
        this.$activeUser = undefined;

        // used for "others" additional counter
        this.notMyTeamMembers = [];

        this.ADDITIONAL_COUNTERS_COLOR = 'blue';
        this.OTHERS_ASSIGNEE = "others";
        this.BLOCKED_ASSIGNEE = "blocked";

        // debounce methods
        this.updateHeaders = _.debounce(this.updateHeaders_debounceImpl, 250);
        this.updatePersonalWipLimits = _.debounce(this.updatePersonalWipLimits_debounceImpl, 250);

        kanbanSensei.sprintModel.on('sprint-resolvers-updated', _.once(() => {
            this.updatePersonalWipLimits();
        }));

		this.SECTION_MARGIN = 5;
		this.TITLE_REGEX = new RegExp(/([\w\s\-]+)[^\(\d\)]*(\((\d+)\))?/);
		this.REPLACE_REGEX = new RegExp(/::([\w\s\-]+)/);
		this.LABEL_REGEX = new RegExp(/([a-zA-Z\s\-]+)/);
		this.SPLIT_REGEX = new RegExp(/::/);

		this.initColumnHeaders();
	}

	initColumnHeaders() {
        this.$headers = $('.sprint-section-headings .sprint-section h4');

        var $headersWrapper = $('.sprint-board-contents-header');
        var $contentWrapper = $('.sprint-board-contents-inner');

        var headersText = $.makeArray(this.$headers.map((index, el) => $(el).text()));

        var $newHeaders = this.buildNewHeaders(headersText);

        $contentWrapper.css("margin-top", "0px");
        $headersWrapper.css('position', 'static');

        $headersWrapper.height(50).prepend($newHeaders);

        $(window).resize((e) => this.resizeHeaders());

        var headersOffset = $headersWrapper.offset().top - 50;

        $(window).scroll(function () {
            var currentPosition = $(window).scrollTop();

            if (currentPosition > headersOffset) {
                $headersWrapper.css('position', 'fixed');
            } else {
                $headersWrapper.css('position', 'static');
            }
        });
    }

    buildNewHeaders(headers) {
        var $newHeaders = $("<div />").css("height","15px");
        var parsedHeaders = this.parseHeaders(headers);
        var sectionWidth = $('.sprint-section').width();

        for (var i = 0, l = parsedHeaders.length; i < l; i++) {
            var parsedHeader = parsedHeaders[i];

            var newHeaderText = '';
            var color = 'black';

            if (parsedHeader.total > 0) {
                newHeaderText = this.HEADER_TITLE_WIP_TEMPLATE(parsedHeader);

                if (parsedHeader.count > parsedHeader.total) {
                    color = 'red';
                } else if (parsedHeader.count == parsedHeader.total) {
                    color = 'orange';
                }
            } else if (parsedHeader.span > 1) {
                newHeaderText = parsedHeader.title;
            }

            var width = (sectionWidth + 2 * this.SECTION_MARGIN) * parsedHeader.span - 2 * this.SECTION_MARGIN;
            var $header = $(this.HEADER_TEMPLATE(newHeaderText, color, width));
            $header.appendTo($newHeaders);
            parsedHeader.$element = $header;

            this.headersLinks.push(parsedHeader);
        }

        return $newHeaders;
    }

    parseHeaders(headers) {
        var parsedHeaders = [];
        var currentBlock;

        for (var i = 0, l = headers.length; i < l; i++) {
            var isHierarchical = this.SPLIT_REGEX.test(headers[i]);
            var topLevelHeader, secondLevelHeader;

            if (isHierarchical) {
                var headerTokens = headers[i].split(this.SPLIT_REGEX);
                topLevelHeader = this.parseTitle(headerTokens[0]);
                secondLevelHeader = this.parseTitle(headerTokens[1]);
            } else {
                topLevelHeader = this.parseTitle(headers[i]);
            }

            var currentCount = this.getTaskCount(i);
            var headerText = topLevelHeader.title;
            var totalTasks = topLevelHeader.totalTasks;

            currentBlock = currentBlock || { title: headerText, span: 0, count: 0, total: totalTasks, columns: [i], countColumns: [] };

            if (headerText === currentBlock.title) {
                currentBlock.columns.push(i);
                currentBlock.span++;
                if (totalTasks) {
                    // keep track of which columns to include in the grouping count
                    currentBlock.countColumns.push(i);
                    currentBlock.count += currentCount;
                }
            } else {
                parsedHeaders.push(currentBlock);
                if (totalTasks) {
                    currentBlock = { title: headerText, span: 1, count: currentCount, total: totalTasks, columns: [i], countColumns: [i] };
                } else {
                    currentBlock = { title: headerText, span: 1, count: 0, total: totalTasks, columns: [i], countColumns: [] };
                }
            }

            // simplify current headers
            if (isHierarchical && secondLevelHeader.totalTasks > 0) {
                this.cleanHeaderWithLimit(headers[i], i, currentCount, secondLevelHeader.totalTasks);
                this.subHeadersLinks.push({
                    $element: this.$headers.eq(i),
                    title: this.cleanHeaderTitle(headers[i]),
                    column: i,
                    total: secondLevelHeader.totalTasks,
                    count: currentCount});
            } else {
                this.cleanHeader(headers[i], i);
            }
        }

        parsedHeaders.push(currentBlock);

        return parsedHeaders;
    }

    cleanHeaderWithLimit(header, index, count, limit) {
        this.$headers.eq(index).text(`${this.cleanHeaderTitle(header)} (${count}/${limit})`);
    }

    cleanHeaderTitle(header) {
        var replaceText = header;
        var replaceMatches = header.match(this.REPLACE_REGEX);
        if (replaceMatches) {
            replaceText = replaceMatches[1];
        } else {
            var labelMatches = header.match(this.LABEL_REGEX);
            if (labelMatches) {
                replaceText = labelMatches[1];
            }
        }
        return replaceText;
    }

    parseTitle(title) {
        var titleMatches = title.match(this.TITLE_REGEX);
        var titleText = titleMatches && titleMatches[1] ? titleMatches[1] : title;
        var totalTasks = titleMatches && titleMatches[3] ? titleMatches[3] : 0;

        return {title:titleText, totalTasks:totalTasks};
    }

    /**
     * Gets the number of tasks is a specific column for tracking WIP.  The count includes
     * "other-tasks" and any SwimLanes where tracking is enabled.
     * @param {*} columnIndex Column to count
     * @return number of tracked tasks in that column across swim lanes
     */
    getTaskCount(columnIndex) {
        const blockedIssuesFilter = !kanbanSensei.getValue('columnWipIncludeBlocked', false) ? `[data-blocked!="true"]` : '';
        const storiesFilter = !kanbanSensei.getValue('columnWipIncludeStories', true) ? `[data-ks-story!="true"]` : '';
        const filters = blockedIssuesFilter + storiesFilter;

        return $('.sprint-story[data-ks-swimlane-tracking-column-wip="true"], .sprint-story[data-id="other"]') // get stories & other
            .find(`.sprint-section:eq(${columnIndex})`) // get specific column within story
            .find(`.sprint-task${filters}`) // get tasks
            .size();
    }

    cleanHeaderTitle(header) {
        var replaceText = header;
        var replaceMatches = header.match(this.REPLACE_REGEX);
        if (replaceMatches) {
            replaceText = replaceMatches[1];
        } else {
            var labelMatches = header.match(this.LABEL_REGEX);
            if (labelMatches) {
                replaceText = labelMatches[1];
            }
        }
        return replaceText;
    }

    cleanHeader(header, index) {
        this.$headers.eq(index).text(this.cleanHeaderTitle(header));
    }

    resizeHeaders() {
        var sectionWidth = $('.sprint-section:visible').width();
        for (var i = 0; i < this.headersLinks.length; i++) {
            var header = this.headersLinks[i];

            // update width for underline
            var newWidth = (sectionWidth + 2 * this.SECTION_MARGIN) * header.span - 2 * this.SECTION_MARGIN;
            header.$element.css({width: newWidth});
        }
    }

    updateHeaders_debounceImpl() {
        var i,j;

        var $section = $('<div />');

        for (i = 0; i < this.headersLinks.length; i++) {
            var header = this.headersLinks[i];
            var updatedCount = 0;

            for (j = 0; j < header.countColumns.length; j++) {
                updatedCount += this.getTaskCount(header.columns[j]);
            }

            header.count = updatedCount;
            if (header.total > 0) {
                var newHeaderText = this.HEADER_TITLE_WIP_TEMPLATE(header);
                header.$element.text(newHeaderText);
            }

            var color = 'black';
            if (header.count > header.total) {
                color = 'red';
            } else if (header.count == header.total) {
                color = 'orange';
            }
            header.$element.css({color: color});
        }

        for (j = 0; j < this.subHeadersLinks.length; j++) {
            var subHeader = this.subHeadersLinks[j];
            subHeader.count = this.getTaskCount(subHeader.column);
            var newSubHeaderText = this.HEADER_TITLE_WIP_TEMPLATE(subHeader);
            subHeader.$element.text(newSubHeaderText);

            var color = 'black';
            if (subHeader.count > subHeader.total) {
                color = 'red';
            } else if (subHeader.count == subHeader.total) {
                color = 'orange';
            }

            subHeader.$element.css({color: color});
        }
    }

    isInTeam(name) {
        // if the sprint resolvers haven't been fetched yet, don't filter out anyone
        return (name in kanbanSensei.sprintModel._sprintResolversMap)
            || Object.keys(kanbanSensei.sprintModel._sprintResolversMap).length === 0;
    }

    updatePersonalWipLimits_debounceImpl() {
        let personalWipMap = {};
        const personalWipDisplaySetting = kanbanSensei.getValue('personalWipDisplay', 'activeResolvers');
        if (personalWipDisplaySetting === 'allResolvers') {
            Object.keys(kanbanSensei.sprintModel._sprintResolversMap).forEach(resolver => personalWipMap[resolver] = 0);
        }

        let personalWipColumnInclusionMask = kanbanSensei.areColumnSettingsStale() ? [] : kanbanSensei.getValue('personalWipColumnsIncluded', []);

        let blockedSelector = !kanbanSensei.getValue('personalWipIncludeBlocked', false) ? '[data-blocked!="true"]' : '';
        let storySelector = !kanbanSensei.getValue('personalWipIncludeStories', true) ? '[data-ks-story!="true"]' : '';
        const openCRsSelector = this.getOpenCRsSelector()

        // get all lanes that should be included, plus the other-tasks lane
        var personalWipSwimlanes = $(`.sprint-story[data-ks-swimlane-tracking-personal-wip="true"], .sprint-story[data-id="other"]`);

        // if the inclusion mask is present, filter only for columns that have been explicitly included
        if (personalWipColumnInclusionMask.length > 0) {
            var personalWipColumnSelector = personalWipColumnInclusionMask.map((el, index) => {
                return el ? `.sprint-sections>.sprint-section:eq(${index})` : "";
            }).filter((el) => el).join(', ');

            personalWipSwimlanes = personalWipSwimlanes.find(personalWipColumnSelector);
        }

        personalWipSwimlanes
            .find(`.sprint-task[data-resolved="false"][data-assignee!="nobody"]${blockedSelector}${storySelector}`) // get wip limited tasks
            .each((index, element) => {
                var assignee = $(element).attr('data-assignee');
                personalWipMap[assignee] = personalWipMap[assignee] ? (personalWipMap[assignee] + 1) : 1;
            });

        if (kanbanSensei.getValue('personalWipIncludeCRs', true)) {
            // add counts for CodeReviews on open issues
            personalWipSwimlanes
                .find(`.sprint-task[data-resolved="false"]${blockedSelector} ${openCRsSelector}`)
                .each((index, element) => {
                    _.forEach(($(element).attr('data-pending-reviewers') || '').split(' '), (reviewer) => {
                        if (reviewer) { // some crs have no reviewers
                            personalWipMap[reviewer] = personalWipMap[reviewer] ? (personalWipMap[reviewer] + 1) : 1;
                        }
                    });
                });
        }

        // build html for personal wip limits
        var limit = kanbanSensei.getValue('personalWipLimit', 3);
        var personalWipLimits = Object.keys(personalWipMap)
            .filter((name) => this.isInTeam(name))
            .sort()
            .map((name) => {
                var count = personalWipMap[name];
                var color = 'green';
                if (count > limit) {
                    color = 'red';
                } else if (count === limit) {
                    color = 'orange';
                } else if (count === 0) {
                    color = 'blue'
                }
                return this.PERSONAL_WIP_LIMIT_TEMPLATE(name, color, count);
            });

        // OTHERS
        if (kanbanSensei.getValue('additionalCountersIncludeOthers', false)) {
            this.notMyTeamMembers = Object.keys(personalWipMap).filter((name) => !this.isInTeam(name));
            let othersTaskCount = 0;
            this.notMyTeamMembers.forEach(function(assignee) {
                othersTaskCount = othersTaskCount + ($('.sprint-section[column-name!="Selected"]').find(`[data-resolved="false"][data-assignee="${assignee}"]`).length); })
            if (othersTaskCount > 0) {
                personalWipLimits.push(this.PERSONAL_WIP_LIMIT_TEMPLATE(this.OTHERS_ASSIGNEE, this.ADDITIONAL_COUNTERS_COLOR, othersTaskCount));
            }
        }

        // get all lanes
        let allWipSwimlanes = $(`.sprint-story`);

        // BLOCKED
        if (kanbanSensei.getValue('additionalCountersIncludeBlocked', false)) {
            let blockedTaskCount = allWipSwimlanes
                .find(`.sprint-task[data-resolved="false"][data-blocked="true"]`).length;
            if (blockedTaskCount > 0) {
                personalWipLimits.push(this.PERSONAL_WIP_LIMIT_TEMPLATE(this.BLOCKED_ASSIGNEE, this.ADDITIONAL_COUNTERS_COLOR, blockedTaskCount));
            }
        }

        // NOBODY
        if (kanbanSensei.getValue('additionalCountersIncludeNobody', false)) {
            let nobodyTaskCount = allWipSwimlanes
                .find(`.sprint-task[data-resolved="false"][data-assignee="nobody"]`).length;
            if (nobodyTaskCount > 0) {
                personalWipLimits.push(this.PERSONAL_WIP_LIMIT_TEMPLATE('nobody', this.ADDITIONAL_COUNTERS_COLOR, nobodyTaskCount));
            }
        }

        $(document).find('.document-header').find('div.row:eq(1)').replaceWith(personalWipDisplaySetting === 'none'
            ? `<div class="row personal-wip-limits"></div>`
            : this.WIP_LIMIT_TEMPLATE(personalWipLimits));

        $('span.personal-wip').click((e) => this.onPersonalWipAssigneeClick(e));

        $('.clear-button').click((e) => {
            this.$activeUser = undefined;
            kanbanSensei.showAllTasks();
            $(e.target).hide();
        });
    }

    onPersonalWipAssigneeClick(e) {
        let $clickedUser = $(e.currentTarget);

        if(this.$activeUser && this.$activeUser.attr("data-assignee") === $clickedUser.attr("data-assignee") ) {
            kanbanSensei.showAllTasks();
            $('.clear-button').hide();
            this.$activeUser = undefined;
            return;
        }


        let assignee = $clickedUser.attr('data-assignee');

        let taskSelectors;
        switch(assignee) {
           case this.OTHERS_ASSIGNEE:
               taskSelectors = this.getOthersTasksSelector();
               break;
           case this.BLOCKED_ASSIGNEE:
               taskSelectors = this.getBlockedTasksSelector();
               break;
           default:
               taskSelectors = this.getAssigneeTasksSelector(assignee);
               break;
        }

        // hide all
        $('.sprint-task[data-resolved="false"]').hide();
        $('.sprint-story').hide();


        taskSelectors.forEach(selector => {
            $('.sprint-story').has(selector).show(); //display swimlanes with at least one visible task
            $(selector).show(); //display the tasks
        });


        $('.clear-button').show();
        this.$activeUser = $clickedUser;
    }

    getAssigneeTasksSelector(assignee) {
        const openCRsSelector = this.getOpenCRsSelector()
        return [`.sprint-task[data-assignee="${assignee}"][data-resolved="false"]`, `.sprint-task:has(${openCRsSelector}[data-pending-reviewers*="${assignee}"])`];
    }

    // used for additional counter - blocked
    getBlockedTasksSelector() {
        return ['.sprint-task[data-blocked="true"][data-resolved="false"]']
    }

    // used for additional counter - others
    getOthersTasksSelector() {
       return this.notMyTeamMembers.map(assignee => `.sprint-task[data-assignee="${assignee}"]`)
    }

    // used for personal wip
    getOpenCRsSelector() {
        return '.cr-link.OPEN'
    }

    HEADER_TITLE_WIP_TEMPLATE(header) {
        return `${header.title} (${header.count}/${header.total})`;
    }

    HEADER_TEMPLATE(title, color, width) {
        return `<div class="section-header" style="color:${color};width:${width}px">${title}</div>`;
    }

    PERSONAL_WIP_LIMIT_TEMPLATE(name, color, count) {
    	return `
	    	<span class="personal-wip" data-assignee="${name}" style="color:${color}">
	    		${name}: ${count}
	    	</span>
    	`;
    }

    WIP_LIMIT_TEMPLATE(personalWipLimits) {
    	return `
	    	<div class="row personal-wip-limits">
			    <h3>
			        Personal WIP Limits: ${personalWipLimits.join(', ')}
			        <span class="clear-button" style="display:none;">&#10006;</span>
			    </h3>
			</div>
		`;
    }
}
class KanbanSensei {
    constructor() {
        this.KS_USER_DATA_URL = 'https://drive.corp.amazon.com/mnt/KanbanSensei/ks-user-data.json';
        this.storyColors = ['GreenYellow','LemonChiffon','Lavender','PaleTurquoise','Pink','LightCyan','Wheat','PaleGreen','Salmon','Gold','Aquamarine','DarkOrange','MediumSpringGreen','Peru','Thistle','YellowGreen','CadetBlue','GoldenRod','HotPink','Khaki','LightCoral','MistyRose','SkyBlue'];
        this.haveSeenSprintBefore = true;
        this.hasServerSideSettings = false;
        this.colorNameToRGBA = _.memoize(this.colorNameToRGBA);

        // init things that only need to happen once per page load
        $('head').prepend(this.CSS_OVERRIDES());
        this.enableHoverBehavior();

        this.init = _.once(() => {
            // log page load metric
            App.Helpers.Metrics.count("KanbanSenseiPageLoad", 1);

            // setup toolbar button for KS
            const listViewButton = $('.document-header .btn-toolbar button[data-set-sprint-mode=list]');
            listViewButton.removeClass('btn-group-first');
            listViewButton.before(this.KS_TOOLBAR_BUTTON_TEMPLATE());

            this.featureAlertManager = new KSFeatureAlertManager();

            this.metricsModal = new KSMetricsModal(this);
            $('.ks-metrics').click(() => this.metricsModal.launch());

            this.settingsModal = new KSSettingsModal(this);
            $('.ks-settings').click(() => this.settingsModal.launch());
            $('.ks-focus').click(() => this.toggleFocusMode());

            // backdrop fix for modals
            // see https://stackoverflow.com/questions/19305821/multiple-modals-overlay
            $(document).on('show.bs.modal', '.modal', function () {
                var zIndex = 2000 + (10 * $('.modal:visible').length);
                $(this).css('z-index', zIndex);
                setTimeout(function() {
                    $('.modal-backdrop').not('.modal-stack').css('z-index', zIndex - 1).addClass('modal-stack');
                }, 0);
            });
        });
    }

    setSprintModel(sprintModel) {
        this.sprintModel = sprintModel;
    }

    onSprintLoad() {
        this.fetchResolvedIssuesPromise = false;
        this.processedIssues = new Set();

        // add ks user data
        this.addSprintToUserDataFile()
            .finally(() => { 
                this.loadSettingsFromServer().then(() => this.isInFocusMode());
            });

        this.wipLimitManager = new KSWIPLimitManager(this);
        this.crManager = new KSCodeReviewManager(this);
        this.mcmManager = new KSMCMManager(this);
        this.blockedIssueManager = new KSBlockedIssuesManager(this);
        this.addDoneColumnToggle();

        this.addSwimlaneOptionsToReusableMenu(); // adds menu options and binds click handlers

        this.addHiddenIssuesOutsideSprintFolderWarning();
        
        this.init();
    }

    isInFocusMode() {
        if (kanbanSensei.getValue('openInFocusMode', false)) {
            this.toggleFocusMode();
        }
    }

    /**
     * Calculate a 32 bit FNV-1a hash
     * Found here: https://gist.github.com/vaiorabbit/5657561
     * Ref.: http://isthe.com/chongo/tech/comp/fnv/
     * Used due to good distribution, which matters a lot here for color differentiation.
     */
    hashFnv32a(str, seed) {
        var i, l, hval = (seed === undefined) ? 0x811c9dc5 : seed;

        for (i = 0, l = str.length; i < l; i++) {
            hval ^= str.charCodeAt(i);
            hval += (hval << 1) + (hval << 4) + (hval << 7) + (hval << 8) + (hval << 24);
        }
        return Math.abs(hval >>> 0);
    }

    /**
     *
     * @param color name of the color, e.g. "red"
     * @returns array in the form of RGBA, e.g. [255, 0, 0, 255]
     */
    colorNameToRGBA(color) {
        var ctx = document.createElement('canvas').getContext('2d');
        ctx.fillStyle = color;
        ctx.fillRect(0, 0, 1, 1);
        return ctx.getImageData(0, 0, 1, 1).data;
    }

    onSprintItemsUpdated(changes) {
        this.wipLimitManager.updateHeaders();
        this.wipLimitManager.updatePersonalWipLimits();

        for (let issueId in changes) {
            var change = changes[issueId];
            var $issue = this.getTaskDom(issueId);
            var issueModel = this.sprintModel._sprintIssues.get(issueId);

            // initial processing of issue
            if (!this.processedIssues.has(issueId)) {
                if (this.issueIsSwimlane(issueModel)) {
                    // these issues don't show as cards on a board
                    this.addSwimlaneMenuClickHandler(issueId);
                    this.setSwimlaneAttributes(issueId);
                    continue;
                }

                if (this.issueIsStory(issueModel)) {
                    // set story attribute
                    this.setStoryAttribute(issueId);
                    if (kanbanSensei.getValue('storiesProgressBar', true)) {
                        this.attachProgressBar($issue, issueId);
                    }
                }

                var rootTaskId = this.getRootTaskId(issueId);
                this.setRootTaskAttribute($issue, rootTaskId);

                // color the task, according to configuration
                const colorizeTasks = kanbanSensei.getValue('colorizeTasks', 'all');
                const isStoryOrSubtask = this.issueIsStory(issueModel) || rootTaskId != issueId;
                if (colorizeTasks == 'all' || (colorizeTasks == 'stories' && isStoryOrSubtask)) {
                    // Allow customizing the color using an optional "Card Color" custom field
                    var rootModel = this.sprintModel._sprintIssues.get(rootTaskId);
                    var color = this.getCustomField(rootModel, 'card_color');
                    if (!color) {
                        // use hash of parent ID to make color determinate so it doesn't change on refresh
                        // also convert to rgba to set opacity for more gentle pastel version of colors
                        // must use rgba as jquery.css removes alpha from hex values for some reason.
                        var colorIndex = this.hashFnv32a(rootTaskId) % this.storyColors.length;
                        color = this.storyColors[colorIndex];
                    }
                    var rgba = this.colorNameToRGBA(color);
                    var colorCSS = "rgba(" + rgba[0] + ", " + rgba[1] + ", " + rgba[2] + ", 0.6)"
                    this.setTaskColor($issue, colorCSS);
                }

                // display configured avatar on task
                this.loadConfiguredAssigneeAvatar($issue);

                // Add the context menu to the issue card
                this.addTaskDropdownMenuButton($issue);

                // only for open issues
                if (change.resolved === false) {
                    this.crManager.processCodeReviewLinks(issueModel.attributes);
                    this.mcmManager.processMCMLinks(issueModel.attributes);
                    this.blockedIssueManager.processBlockedIssues(issueModel.attributes, change);
                    this.addTaskDropdownMenuButton($issue);
                    this.addTaskFilterButton($issue, rootTaskId);
                }

                var conversation = issueModel.get('conversation');
                if (conversation && conversation.length) {
                    this.addLastCommentToIssue(issueId, conversation);
                }

                if (kanbanSensei.getValue('taskRank', false)) {
                    this.addRankForIssue(issueId);
                }

                this.processedIssues.add(issueId);
            } else {
                // Not the initial processing (dynamic updates)
                let rootTaskId = this.getRootTaskId(issueId);

                // Update story progress bar if a task is resolved or re-opened
                if (typeof(change.resolved) !== 'undefined' && rootTaskId && rootTaskId !== issueId && kanbanSensei.getValue('storiesProgressBar', true)) {
                    issueModel.attributes.status = change.resolved ? 'Resolved' : 'Open';
                    this.attachProgressBar(this.getTaskDom(rootTaskId), rootTaskId);
                }
            }

            // only for open issues with certain changes
            if (change.resolved !== true && (change.nextStep || change.blocked)) {
                this.addKanbanMetricsForIssue(issueModel);
            }
            // Update the avatar if the assignee changes
            if (change.assignee) {
                this.loadConfiguredAssigneeAvatar($issue);
            }
        }
    }

    processSprintIssueFieldChange(issueId, changeInfo) {
        if (changeInfo.field.includes("blocked")) {
            // process change for (un)blocked issues
            var index = changeInfo.field.indexOf("blocked");

            if (changeInfo.overrideValue[index]) {
                this.blockedIssueManager.addBlocked(issueId, changeInfo.value[index][0].reasonMessage[0].text);
            } else {
                this.blockedIssueManager.removeBlocked(issueId)
            }
        }
    }

    addLastCommentToIssue(issueId, conversation) {
        this.getTaskDom(issueId).find('.sprint-task-description').first().before(this.LAST_COMMENT_TEMPLATE(conversation[conversation.length-1]));
    }

    async addSprintToUserDataFile() {
        const data = await this.makeHttpRequest(this.KS_USER_DATA_URL);
        // do a null check on data, in case the request fails.
        if (!data) {
            return
        }
        data.sprintBoards = data.sprintBoards || {};
        data.users = data.users || [];

        var changed = false;
        if (!data.sprintBoards[this.sprintModel._sprintId]) {
            this.haveSeenSprintBefore = false;
            // let's parse the sprint name
            var spDocModel = this.sprintModel._sprintDocumentModel;
            var sprintTitle = "unknown";
            if (spDocModel.attributes.label && spDocModel.attributes.label.length) {
                sprintTitle = spDocModel.attributes.label[0].text;
            }
            data.sprintBoards[this.sprintModel._sprintId] = sprintTitle;
            changed = true;
        }
        var currentUser = Maxis.APP_CONFIG.remote_user;
        if (currentUser) {
            if (!data.userDataMap[currentUser]) {
                // new user
                data.userDataMap[currentUser] = {
                    version: GM_info.script.version
                };
                changed = true;
            } else {
                // user object exists, check version
                if (data.userDataMap[currentUser].version !== GM_info.script.version) {
                    data.userDataMap[currentUser].version = GM_info.script.version;
                    changed = true;
                }
            }
        }

        if (changed) {
            // only make call if something changed
            this.makeHttpRequest(this.KS_USER_DATA_URL, 'PUT', data);
        }

        this.userData = data;
    }

    /**
     * Since SIM uses 1 reusable menu dropdown for all issues, we need to add these options just once
     * When the menu opens, another handler will check the boxes accordingly for the active swimlane
     */
    addSwimlaneOptionsToReusableMenu() {
        $('#sprint-board-task-reusable-menu').children('ul').append(this.SWIM_LANE_MENU);
        $('.ks-sprint-swimlane-toggle-menu a').click((e) => this.onSwimlaneMenuItemClick(e));
    }

    addSwimlaneMenuClickHandler(issueId) {
        // Capture the click on the menu item that displays the context window,
        // so we can get the story associated with it
        // the data-name has a type-o (reusable), so incase they fix the spelling, select on both
        // the |= selector selects elements whose values match exactly OR start with the value followed by a hyphen
        this.getSwimlaneDom(issueId)
            .find('.sprint-story-header .dropdown-toggle[data-name|="sprint-board-task"]')
            .click((e) => this.onDropdownMenuButtonClick(e, true));
    }

    /**
     * The Swimlane Menu Button is the button that brings up the context menu ... we need to capture this event, so that
     * we can get the Sprint Item from the click event
     * @param {*} event
     */
    onDropdownMenuButtonClick(event, isSwimlane) {
        let swimlaneCheckboxes = $('.ks-sprint-swimlane-toggle-menu a');

        if (!isSwimlane) {
            // get rid of the swimlane id data entry so that the checkboxes do not display
            swimlaneCheckboxes.removeAttr('data-ks-swimlane-id');
            return;
        }

        // figure out which swimlane this menu was called for, since it's a reusable menu
        var swimLaneStoryId = $(event.target).closest('.sprint-story').data('id');

        // add the active swimlane id to both checkboxes to use in onClick handler
        // and set the icon according to stored values
        swimlaneCheckboxes.attr('data-ks-swimlane-id', swimLaneStoryId)
            .each((index, element) => {
                let $el = $(element);
                let key = $el.attr('data-ks-checkbox-key');
                let checked = this.getValue(key, []).includes(swimLaneStoryId);
                $el.find('i').attr('class', checked ? 'icon-check' : 'icon-check-empty');
            });
    }

    /**
     * When the SwimLane Menu Item checkbox for Column/Personal WIP is clicked.
     * @param {*} event
     */
    onSwimlaneMenuItemClick(event) {
        // use currentTarget so this works even when the user clicks on the icon inside of the 'a' element
        var swimLaneStoryId = $(event.currentTarget).attr('data-ks-swimlane-id');
        var key = $(event.currentTarget).attr('data-ks-checkbox-key');
        var trackingSwimLaneArray = this.getValue(key, []);

        this.setValue(key, _.xor(trackingSwimLaneArray, [swimLaneStoryId]));

        // set the new swimlane attributes
        this.setSwimlaneAttributes(swimLaneStoryId);

        this.wipLimitManager.updateHeaders();
        this.wipLimitManager.updatePersonalWipLimits();
        this.updateKanbanMetricsForOpenIssues();
        if (this.hasServerSideSettings) {
            kanbanSensei.saveSettingsToServer();
        }
    }

    loadConfiguredAssigneeAvatar($task) {
        const displayAvatars = kanbanSensei.getValue('displayAvatars', 'off');
        if(displayAvatars == 'off'){
            return;
        }

        // Remove any current image or icon
        this.getTaskAssigneeDropdownDom($task).find("i, img").remove();

        let assignee = $task.attr('data-assignee');
        let $avatarImage = $('<img style="max-width:25px;max-height:25px;" alt=""></img>');
        let phonetoolImageUrl = "https://internal-cdn.amazon.com/badgephotos.amazon.com/?uid=" + assignee;

        if(displayAvatars == 'phonetool'){
            $avatarImage.attr('src', phonetoolImageUrl);
        } else if (displayAvatars == 'custom') {
            let customAvatarUrl = this.createCustomAvatarUrl(assignee);
            $avatarImage.attr('src', customAvatarUrl);

            // default to phonetool photo if no custom image is configured
            $avatarImage.on('error', function(){
                $(this).unbind("error").attr('src', phonetoolImageUrl);
            });
        }

        this.getTaskAssigneeDropdownDom($task).prepend($avatarImage);
    }

    /*
    * Create Url of image to embed for the assignee
    */
    createCustomAvatarUrl(assignee) {
        // Get base url and ensure there is a trailing '/'
        const customAvatarBaseUrl = kanbanSensei.getValue('customAvatarBaseUrl', '').replace(/\/?$/, '/');
        let embeddableBaseUrl = this.transformFolderUrlToEmbeddableBaseUrl(customAvatarBaseUrl);
        return embeddableBaseUrl + assignee + '.jpg';
    }

    /*
    * Given the Url of the folder that is provided by the user,
    * create a base url that, with only the appending of the image file name,
    * can be embedded as an image.
    */
    transformFolderUrlToEmbeddableBaseUrl(baseUrl) {
        let embeddableBaseUrl = baseUrl;

        // Match case when provided Url is an Amazon Drive personal folder
        embeddableBaseUrl = embeddableBaseUrl.replace(/drive.corp.amazon.com\/personal\/(\w+)\//, 'drive-render.corp.amazon.com/view/$1@/');
        // Match case when provided Url is an Amazon Drive team folder
        embeddableBaseUrl = embeddableBaseUrl.replace(/drive.corp.amazon.com\/folders\/(\w+)\//, 'drive-render.corp.amazon.com/view/$1/');

        return embeddableBaseUrl;
    }


    /** GM local storage **/
    getValue(key, defaultValue) {
        var value = GM_getValue(`${this.sprintModel._sprintId}-${key}`);
        // need to check value types, in order to support booleans, 0s and 1s
        if ((typeof value === 'undefined') && (typeof defaultValue !== 'undefined')) {
            // default the value if null
            this.setValue(key, defaultValue, false);
            return defaultValue;
        }
        return value;
    }

    getAllValues() {
        const prefix = this.sprintModel._sprintId + '-';
        const prefixLen = prefix.length;
        const allKeys = GM_listValues().filter(key => key.startsWith(prefix));
        const values = {};
        for (const key of allKeys) {
            values[key.slice(prefixLen)] = GM_getValue(key);
        }
        return values;
    }

    setAllValues(values) {
        const prefix = this.sprintModel._sprintId + '-';
        const prefixLen = prefix.length;
        // List all keys that are not present in "values" (and thus need to be deleted)
        const keysToDelete = GM_listValues().filter(key => key.startsWith(prefix) && !(key.slice(prefixLen) in values));
        for (const key of keysToDelete) {
            GM_deleteValue(key);
        }
        for (const key in values) {
            this.setValue(key, values[key], false);
        }
        if (!values.ksConfigTimestamp) {
            this.setValue('ksConfigTimestamp', new Date().toISOString(), false);
        }
    }

    getBackupSettingsJSON() {
        const settings = this.getAllValues();
        settings.ksConfigVersion = 1;
        return JSON.stringify(settings, null, 2);
    }

    async restoreSettingsFromJSON(jsonSettings, saveToServer = false) {
        const settings = JSON.parse(jsonSettings);
        if (!settings.ksConfigVersion) throw new Error('Invalid KS settings JSON (missing ksConfigVersion)');
        if (this.getValue('ksConfigTimestamp') === settings.ksConfigTimestamp) {
            // Nothing to do (timestamps match)
            console.log('KanbanSensei settings timestamp match - nothing to load');
            return;
        }
        delete settings.ksConfigVersion;
        this.setAllValues(settings);
        if (saveToServer) {
            await this.saveSettingsToServer();
        }
        window.location.reload();
    }

    async saveSettingsToServer() {
        if (this.getValue('offlineSettings', false)) {
            // User has chosen to use offline settings - do not save settings to server
            this.hasServerSideSettings = false;
            return;
        }
        try {
            this.hasServerSideSettings = true;
            const jsonSettings = this.getBackupSettingsJSON();
            const descriptions = this.sprintModel._sprintDocumentModel.attributes.description || [];
            if (!descriptions.some(d => d.id == "en-US")) {
                // If this label does not have an english description yet, create an empty one
                const edit = { pathEdits: [{ path: '/description/en-US/text', editAction: 'PUT', data: " " }] };
                await App.maxisAPI.labels.createLabelEdit(this.sprintModel._sprintId, edit);
            }
            // Here we use a clever hack to store the settings in the server:
            // There is no way to store custom configuration in SIM/Maxis, but sprint boards are essentially special
            // labels, and labels can have custom descriptions in multiple languages. So, we use that functionality
            // to store our configuration as a description in the "en-KS" language :)
            const edit = { pathEdits: [{ path: '/description/en-KS/text', editAction: 'PUT', data: jsonSettings }] };
            await App.maxisAPI.labels.createLabelEdit(this.sprintModel._sprintId, edit);
            console.log('KanbanSensei settings saved to server with success');
        } catch (error) {
            console.error('Error saving KanbanSensei settings to server', error);
        }
    }

    hasServerSettings() {
        const labelAttributes = this.sprintModel._sprintDocumentModel.attributes;
        const description = (labelAttributes.description || []).filter(d => d.id == "en-KS");
        return description.length > 0;
    }

    async loadSettingsFromServer() {
        if (this.getValue('offlineSettings', false)) {
            // User has chosen to use offline settings - do not load settings from server
            return;
        }
        try {
            const descriptions = this.sprintModel._sprintDocumentModel.attributes.description || [];
            const description = descriptions.filter(d => d.id == "en-KS");
            if (description.length && description[0].text) {
                this.hasServerSideSettings = true;
                this.restoreSettingsFromJSON(description[0].text);
                return;
            }
            // KS settings are not stored in the server yet
            this.askUserToStoreSettings();
        } catch (error) {
            console.error('Error loading KanbanSensei settings from server', error);
        }
    }

    askUserToStoreSettings() {
        if (!this.haveSeenSprintBefore) {
            // If we have never seen this board board, there is no need to ask
            this.saveSettingsToServer();
            return;
        }
        // If this is not a new board, ask the user's permission to store settings in the server.
        try {
            const $banner = $(`<div class="ks-banner document-view view-content-card">
                <div class="inner-container" style="min-width: 1921px;padding: 15px;background-color: pink;">
                    <header class="document-header" style="padding:0;">
                        <h2>KanbanSensei Board Settings</h2>
                        <h3>This board does not yet have have a remote settings file. Would you like to create one now?</h3>
                        <h4><i>(This will allow all users to share settings rather than configuring on their own.)</i></h4>
                        <br/>
                        <button name="yes" class="btn btn-primary" type="button" style="margin-right: 10px;">Yes</button>
                        <button name="no" class="btn" type="button" style="">No</button>
                    </header>
                </div>
            </div>`);
            $('#application-content-wrapper').prepend($banner);
            // This instance should map to this class here:
            // https://code.amazon.com/packages/MaxisWebsite/blobs/mainline/--/source/javascripts/views/sprint-board-lanes-view.js
            // In order to fix the header position, we will customize the 'margin-top'
            const view = App.applicationLayoutManager.regionManagers.content.currentView.sprintBoardVisualization.currentView;
            const ksHeight = $('.ks-banner').outerHeight();
            view.$boardHeader.css('margin-top', ksHeight);
            const BOARD_HEADER_HEIGHT = 147;
            const moveBanner = () => {
                const marginHeight = window.scrollY <= BOARD_HEADER_HEIGHT ? ksHeight : Math.max(0, ksHeight - window.scrollY + BOARD_HEADER_HEIGHT);
                view.$boardHeader.css('margin-top', marginHeight);
            };
            const viewCid = 'scroll.view-' + view.cid;
            $(window).on(viewCid, moveBanner);
            const closeBanner = () => {
                $banner.remove();
                $(window).off(viewCid, moveBanner);
                view.$boardHeader.css('margin-top', 0);
            };
            $banner.find('button[name="yes"]').click(() => {
                closeBanner();
                this.saveSettingsToServer();
            });
            $banner.find('button[name="no"]').click(() => {
                closeBanner();
                this.setValue('offlineSettings', true);
            });
        } catch (err) {
            console.error('Error hooking KanbanSensei banner customizations', err.stack);
        }
    }

    setValue(key, value, updateTimestamp = true) {
        GM_setValue(`${this.sprintModel._sprintId}-${key}`, value);
        if (updateTimestamp) {
            GM_setValue(`${this.sprintModel._sprintId}-ksConfigTimestamp`, new Date().toISOString());
        }
    }

    deleteAllValues() {
        for (let key of GM_listValues()) {
            GM_deleteValue(key);
        }
    }

    listValues() {
        _.forEach(GM_listValues(), function(key) {
            console.log(key + " = " + GM_getValue(key));
        });
    }

    fetchResolvedIssues() {
        if (!this.fetchResolvedIssuesPromise) {
            // create deferred
            this.fetchResolvedIssuesPromise = $.Deferred();

            // init loading spinners
            var $toggleButton = this.$doneColumnHeaderSpan.find('button');
            var $loadingIcon = this.$doneColumnHeaderSpan.find('.icon-spinner');
            $toggleButton.attr('disabled', true).text('Loading');
            $loadingIcon.show();

            // tell the model to load resolved issues and re-init
            this.sprintModel._fetchResolvedIssues = true;
            this.sprintModel._initializeSprintIssueEdits(); //needed to reprocess edits
            this.sprintModel._fetchSprintIssues(true).then(() => {
                this.sprintModel.on('issue-state-updated', _.once(() => {
                    // wait for the issue state to be processed before removing spinner and resolve
                    $loadingIcon.hide();
                    this.fetchResolvedIssuesPromise.resolve();
                }));

                this.sprintModel.on('sprint-items-updated', _.once(() => {
                    // the issues are now added to the DOM, show the toggle button again
                    $toggleButton.attr('disabled', false).text('Hide');
                }));
            });
        }

        return this.fetchResolvedIssuesPromise;
    }

    updateKanbanMetricsForOpenIssues() {
        this.sprintModel._sprintIssues.models
            .filter((issue) => issue.attributes.status === 'Open')
            .filter((issue) => !this.issueIsSwimlane(issue))
            .forEach((issue) => this.addKanbanMetricsForIssue(issue));
    }

    async addKanbanMetricsForIssue(issueModel) {
        var $issue = this.getTaskDom(issueModel.attributes.id);
        $issue.find('.sprint-task-detail-row.issue-metrics').remove(); // remove all existing metrics
        $issue.find('.sprint-task-detail-row.need-by-date').remove(); // remove existing needByDate
        $issue.find('.sprint-task-detail-row.estimated-start-date').remove(); // remove existing estimatedStartDate
        $issue.find('.sprint-task-detail-row.estimated-completion-date').remove(); // remove existing estimatedCompletionDate

        var displayEstimateTaskPoints = kanbanSensei.getValue('displayEstimateTaskPoints', 'never');
        var metrics = await this.calculateKanbanMetricsForIssue(issueModel);
        if (metrics) {
            if ($issue.find('.sprint-task-detail-row.cr-link, .sprint-task-detail-row.ks-blocked-info').length) {
                // place after the CR links and blocked reason
                $issue.find('.sprint-task-detail-row.cr-link, .sprint-task-detail-row.ks-blocked-info').last().after(
                    this.ISSUE_METRICS_TIMES_TEMPLATE(metrics, displayEstimateTaskPoints));
            } else {
                // place after title
                $issue.find('.sprint-task-detail-row').first().after(
                    this.ISSUE_METRICS_TIMES_TEMPLATE(metrics, displayEstimateTaskPoints));
            }
            $issue.find('.sprint-task-description').first().before(this.ISSUE_METRICS_DATES_TEMPLATE(metrics));
        } else if (displayEstimateTaskPoints === 'open') {
            // Task is not yet in a started lane, so the default metrics are not shown
            // This setting instructs us to display points for all open tasks regardless
            $issue.find('.sprint-task-detail-row').first().after(this.ISSUE_METRICS_POINTS_ONLY_TEMPLATE(
                _.get(issueModel, "attributes.extensions.effort.effortEstimatedRecursiveSum.effort")));
        }

        // metrics only returns for issues that are already started on, but we should have need by for things in input queue
        var needByDate = this.calculateNeedByDateForIssue(issueModel);
        if (needByDate) {
            $issue.find('.sprint-task-detail-row').first().after(this.ISSUE_NEED_BY_TEMPLATE(needByDate));
        }

        var displayEstimatedStartDate = kanbanSensei.getValue('displayEstimatedStartDate', false);
        if (displayEstimatedStartDate){
            var estimatedStartDate = this.calculateEstimatedStartDateForIssue(issueModel);
            if (estimatedStartDate) {
                $issue.find('.sprint-task-detail-row').first().after(this.ISSUE_ESTIMATED_START_TEMPLATE(estimatedStartDate));
            }
        }

        var displayEstimatedCompletionDate = kanbanSensei.getValue('displayEstimatedCompletionDate', false);
        if (displayEstimatedCompletionDate) {
            var estimatedCompletionDate = this.calculateEstimatedCompletionDateForIssue(issueModel);
            if (estimatedCompletionDate) {
                $issue.find('.sprint-task-detail-row').first().after(this.ISSUE_ESTIMATED_COMPLETION_TEMPLATE(estimatedCompletionDate));
            }
        }

        var displayPointCounter = kanbanSensei.getValue('displayPointCounter', false);
        if (displayPointCounter) {
            $issue.find('.sprint-task-detail-row .pull-right').show();
        }

        var displayCustomFields = kanbanSensei.getValue('displayCustomFields', "");
        if (displayCustomFields != "") {
            var fieldsToShow = [];
            var fields = displayCustomFields.split(",");
            
            for (var i = 0; i < fields.length; i++) {
                var value = this.getCustomField(issueModel,fields[i]);
                if(value){
                    fieldsToShow = fieldsToShow.concat({"key" : fields[i], "value" : value});
                }
                
            }
           
            $issue.find('.sprint-task-detail-row').first().after(this.ISSUE_CUSTOM_FIELDS_TEMPLATE(fieldsToShow));
        }
    }

    addRankForIssues() {
        if (!kanbanSensei.getValue('taskRank', false)) return;
        this.sprintModel._sprintIssues.models
            .forEach((issue) => this.addRankForIssue(issue.attributes.id));
    }

    async addRankForIssue(issueId) {
        var $issue = this.getTaskDom(issueId);
        var rank = this.sprintModel.getIssueData(issueId).attributes.rank;
        if(rank) {
            $issue.find('.sprint-task-detail-row.rank').remove(); // remove all rank details
            $issue.find('.sprint-task-detail-row').first().after(this.ISSUE_RANK_TEMPLATE(rank));
        }
    }

    getCustomField(issue,field){
        var value = null;
        var fieldInSnakeCase = field.trim().replace(/\W+/g, " ")
            .split(/ |\B(?=[A-Z])/)
            .map(word => word.toLowerCase())
            .join('_');

        if(issue.attributes.hasOwnProperty('customFields') ){
            if(issue.attributes.customFields.hasOwnProperty('string')){
                var fields = issue.attributes.customFields.string;
                for (var i = 0; i < fields.length; i++) {
                    if(fields[i]["id"] === fieldInSnakeCase){
                        value = fields[i]["value"];
                    }
                }
            }

            if(value === null && issue.attributes.customFields.hasOwnProperty('boolean')){
                var fields = issue.attributes.customFields.boolean;
                for (var i = 0; i < fields.length; i++) {
                    if(fields[i]["id"] === fieldInSnakeCase){
                        value = fields[i]["value"] ? "True" : "False";
                    }
                }
            }

            if(value === null && issue.attributes.customFields.hasOwnProperty('checkbox')){
                var fields = issue.attributes.customFields.checkbox;
                for (var i = 0; i < fields.length; i++) {
                    if(fields[i]["id"] === fieldInSnakeCase){
                        var checkboxValues = fields[i]["value"];
                        var consolidatedValues = [];
                        for (var j = 0; j < checkboxValues.length; j++) {
                            if(checkboxValues[j]["checked"]){
                                consolidatedValues = consolidatedValues.concat(checkboxValues[j]["value"]);
                            }
                        }
                        value = consolidatedValues.join(",");
                    }
                }
            }
           
        } 
        return value;
    }

    calculateNeedByDateForIssue(issue) {
        return issue.attributes.hasOwnProperty('schedule') && issue.attributes.schedule.hasOwnProperty('needByDate') ? new Date(issue.attributes.schedule.needByDate).withoutTime() : null;
    }

    calculateEstimatedStartDateForIssue(issue) {
        return issue.attributes.hasOwnProperty('schedule') && issue.attributes.schedule.hasOwnProperty('estimatedStartDate') ? new Date(issue.attributes.schedule.estimatedStartDate).withoutTime() : null;
    }

    calculateEstimatedCompletionDateForIssue(issue) {
        return issue.attributes.hasOwnProperty('schedule') && issue.attributes.schedule.hasOwnProperty('estimatedCompletionDate') ? new Date(issue.attributes.schedule.estimatedCompletionDate).withoutTime() : null;
    }

    async calculateKanbanMetricsForIssue(issue) {
        var issueId = issue.attributes.id;
        // get startLane and data for this issue
        var startLane = this.issueIsStory(issue) ? this.getValue('storyStart', 1) : this.getValue('taskStart', 1);
        var issueData = this.sprintModel._issueData[issueId];

        // if the current lane is not >= startLane, the issue has not started yet or hasn't been calculated, return.
        var calculated = issueData.calculated[this.sprintModel._currentDate];
        var currentLane = calculated.lane;
        if (currentLane < startLane) {
            return;
        }

        // Retrieve all issue edits, so we can calculate the "time in column"
        await kanbanSensei.sprintModel._sprintIssueEditsRequest;
        var edits = kanbanSensei.sprintModel._sprintIssueEdits.models;
        var nextStepEdits = edits.filter(edit => edit.id.startsWith(issueId)
            && edit.attributes.pathEdits.filter(pEdit => pEdit.path === '/next_step').length > 0);
        var nextStepEditDates = nextStepEdits.map(edit => edit.attributes.actualCreateDate);
        var blockEdits = edits.filter(edit => edit.id.startsWith(issueId)
            && edit.attributes.pathEdits.filter(pEdit => pEdit.path === '/next_step/exceptions' && pEdit.editAction === 'PUT' && pEdit.data.length > 0).length > 0);
        var blockEditDates = blockEdits.map(edit => edit.attributes.actualCreateDate);

        // key dates
        var createDate = new Date(issue.attributes.createDate).withoutTime();
        var startDate = this.getStartDateForIssue(issueData, startLane);
        var endDate = issue.attributes.status === 'Resolved' ? new Date(issue.attributes.lastResolvedDate).withoutTime() : new Date().withoutTime();
        var columnDate = nextStepEdits.length ? new Date(nextStepEditDates.sort().pop()).withoutTime() : new Date().withoutTime();
        var blockedDate = blockEditDates.length ? new Date(blockEditDates.sort().pop()).withoutTime() : new Date().withoutTime();

        // compute times
        var excludeWeekends = this.getValue('excludeWeekends', false);
        const calculateDays = date => {
            var weekendDaysSinceDate = excludeWeekends ? this.calculateNumWeekendDays(date, endDate) : 0;
            return parseInt(((endDate - date)/(1000*60*60*24)) + 1 - weekendDaysSinceDate, 10);
        };
        var cycleTime = calculateDays(startDate);
        var leadTime = calculateDays(createDate);
        var timeInColumn = calculateDays(columnDate);
        var timeBlocked = calculated.blocked ? calculateDays(blockedDate) : 0;

        return {
            id: issueId,
            alias: issue.attributes.aliases[0].id,
            title: issue.attributes.title,
            isStory: this.issueIsStory(issue),
            isResolved: issue.attributes.status === 'Resolved',
            assignee: App.Helpers.UserHelpers.getIdentityLabel(issue.attributes.assigneeIdentity),
            cycleTime,
            leadTime,
            createDate,
            startDate,
            endDate,
            timeInColumn,
            timeBlocked,
            points: _.get(issue, "attributes.extensions.effort.effortEstimatedRecursiveSum.effort"),
            startLane,
            currentLane,
            effortSpent: _.get(issue, "attributes.extensions.effort.effortSpent") ?? [],
        };
    }

    /**
     * In KanbanSensei, we define a swimlane as an issue that has a story marker and no parent issue.
     * On a SIM sprint board, these show up as their own swimlanes.
     * @param issue SIM issue to determine if it is a Swimlane or not
     */
    issueIsSwimlane(issue) {
        if (typeof issue === 'string') {
            // get the issue model
            issue = this.sprintModel._sprintIssues.get(issue);
        }

        return !!this.sprintModel._stories[issue.attributes.id];
    }

    /**
     * In KanbanSensei, we define a story as either a Task with Children, OR,
     * an Issue marked as a story but is not a swimlane.
     * The problem with relying solely on the children logic, is that a "story" that has not been flagged as such, and has no
     * children are then also included in the metrics, which is wrong.
     * The problem with flagging stories on the SprintBoard is that they are automatically added as a SwimLane IF they are
     * parent-less.  However, if a Story is a child of another Story, then it shows up as a card on the board.
     * @param {*} issue SIM issue to determine if it is a Story or not
     * @returns boolean
     */
    issueIsStory(issue) {
        if (typeof issue === 'string') {
            // get the issue model
            issue = this.sprintModel._sprintIssues.get(issue);
        }

        return issue.attributes.subtasks.length !== 0 || (this.issueHasStoryMarker(issue) && !this.issueIsSwimlane(issue));
    }

    /**
     * Checks to see if the Planning Level attribute has been set to Story on a given Issue
     * @param {*} issue SIM Issue to check if it has been marked as a Story (planning level)
     * @returns boolean
     */
    issueHasStoryMarker(issue) {
        if (typeof issue === 'string') {
            // get the issue model
            issue = this.sprintModel._sprintIssues.get(issue);
        }

        return issue.get('extensions.backlog.planningLevel') === 'Story';
    }

    // https://stackoverflow.com/questions/6210906/how-to-determine-number-saturdays-and-sundays-comes-between-two-dates-in-java-sc
    calculateNumWeekendDays(fromDate, toDate) {
        var ndays = 1 + Math.round((toDate.getTime() - fromDate.getTime())/(24*3600*1000));
        var nsaturdays = Math.floor((fromDate.getDay() + ndays) / 7);
        return 2*nsaturdays + (fromDate.getDay() === 0) - (toDate.getDay() === 6);
    }

    getStartDateForIssue(issueData, startLane) {
        var calculatedStartDate = this.findCalculatedStartDate(issueData, startLane);
        if (calculatedStartDate) {
            return new Date(calculatedStartDate).withoutTime();
        } else if (issueData.attributes.schedule && issueData.attributes.schedule.actualStartDate) {
            return new Date(issueData.attributes.schedule.actualStartDate).withoutTime();
        } else {
            // we don't know the start date
            // this is probably because the sprint start/end dates are not set correctly
            return new Date().withoutTime();
        }
    }

    findCalculatedStartDate(issueData, startLane) {
        let dates = kanbanSensei.sprintModel._sprintDates;

        // filter to dates where the lane is >= startLane and (if not the first date) the previous date's lane is < startLane
        let startDates = dates.filter((date, index) => {
            return issueData.calculated[date].lane >= startLane &&
                (index === 0 || issueData.calculated[dates[index - 1]].lane < startLane);
        });

        // return the last startDate
        return startDates.pop();
    }

    addDoneColumnToggle() {
        this.$doneColumnHeaderSpan = $(this.DONE_COLUMN_HEADER_TEMPLATE());
        $('.sprint-section-headings .sprint-section h4').last().append(this.$doneColumnHeaderSpan);

        this.$doneColumnHeaderSpan.find('button').click(() => this.toggleDoneColumn());
    }

    toggleDoneColumn() {
        var $toggleButton = this.$doneColumnHeaderSpan.find('button');

        if (!this.fetchResolvedIssuesPromise) {
            this.fetchResolvedIssues();
        } else {
            // just toggle show/hide
            $('.sprint-section:last-of-type .sprint-task[data-resolved="true"]').toggle();
            $toggleButton.text($toggleButton.text() === 'Hide' ? 'Show' : 'Hide');
        }
    }

    toggleFocusMode() {
        // Focus mode hides by default the first and last column (typically the large "input queue" and "done")
        // so that the team can focus on the currently "on-going" tasks (very useful for the daily Kanban meetings)
        var focusModeHideColumns = kanbanSensei.getValue('focusModeHideColumns', "");
        
        if (focusModeHideColumns != '') {
            var columns = focusModeHideColumns.split(",");
            var hideSection = columns.map(column => '.sprint-section:nth-of-type(' + column.trim() + '), .section-header:nth-of-type(' + column.trim() + ')').join(', ');
            $(hideSection).toggle();
        } else {
            $('.sprint-section:first-of-type, .sprint-section:last-of-type').toggle();
            $('.section-header:first-of-type, .section-header:last-of-type').toggle();
        }

        this.wipLimitManager.resizeHeaders();
    }

    // Makes cross origin http request and JSON parses the response, returns promise
    makeHttpRequest(url, httpMethod, data) {
        return new Promise((resolve, reject) => {
            var request = {
                method: httpMethod || 'GET',
                url: url,
                headers: {
                    'Accept': 'application/json'
                },
                onerror: reject,
                ontimeout: reject,
                context: null
            };

            request.onload = (response) => {
                 if (response && response.status >= 200 && response.status < 300) {
                     if (request.method === 'GET') {
                        resolve(JSON.parse(response.responseText) || $.parseJSON(response.responseText));
                     } else {
                        resolve(response);
                     }
                 } else {
                     reject(response);
                 }
             };

            if (httpMethod === 'POST' || httpMethod === 'PUT') {
                data = data || {};
                request.data = JSON.stringify(data);
                request.headers = { 'Content-Type': 'application/json' };
            }

            GM_xmlhttpRequest(request);
        }).catch((err) => console.error(err));
    }

    displayNotification(title, options) {
        if (!("Notification" in window)) {
            if (window.confirm(title)) {
                window.open(options.data.url, '_blank');
            }
        } else if (Notification.permission === "granted") {
            // If it's okay let's create a notification
            var notification = new Notification(title, options);
            notification.onclick = this.notificationOnClick;
        } else if (Notification.permission !== "denied") {
            Notification.requestPermission((permission) => {
                // If the user accepts, let's create a notification
                if (permission === "granted") {
                    var notification = new Notification(title, options);
                    notification.onclick = this.notificationOnClick;
                }
            });
        }
    }

    notificationOnClick(event) {
        var notification = event.target;
        notification.close();
        window.open(notification.data.url, '_blank');
    }

    attachProgressBar($task, taskId) {
        let taskAttributes = kanbanSensei.sprintModel._sprintIssues.get(taskId).attributes;
        let allSubTasks = taskAttributes.subtasks;
        if (!allSubTasks || allSubTasks.length == 0) return; // not a story
        $task.find('.ks-story-progressbar').remove();

        let resolvedSubTasks = 0;

        for (let subTask of allSubTasks) {
            let subTaskStatus = kanbanSensei.sprintModel._sprintIssues.get(subTask.id);
            if (!subTaskStatus || subTaskStatus.attributes.status === 'Resolved') {
                resolvedSubTasks++;
            }
        }

        let progress = 100 * resolvedSubTasks / allSubTasks.length;
        let progressBar = `<div class="ks-story-progressbar" style="height:5px; border: 1px solid black">
            <div style="float:left; width:${progress}%;background-color: blue; height: 100%;"></div>
            <div style="float:right; width:${100 - progress}%;background-color: white; height: 100%;"></div>
        </div>`;
        if (taskAttributes.status === 'Resolved') {
            // Resolved stories tasks have a different layout
            $task.find('.sprint-task-title').after(progressBar);
        } else {
            $task.find('.sprint-task-detail-row').first().before(progressBar);
        }
    }

    getTaskDom(taskId) {
        return $(`.sprint-task[data-id=${taskId}]`);
    }

    getTaskAssigneeDropdownDom($task) {
        return $task.find(".sprint-task-assignee");
    }

    setTaskColor($task, color) {
        $task.css('backgroundColor', color);
    }

    setRootTaskAttribute($task, rootTaskId) {
        $task.attr('data-root-task-id', rootTaskId);
    }

    setSwimlaneAttributes(issueId) {
        let isTrackingColumnWIP = this.getValue('trackingAllSwimLaneColumnWIP', false)
            || this.getValue('trackingSwimLaneColumnWIP', []).includes(issueId);
        let isTrackingPersonalWIP = this.getValue('trackingAllSwimLanePersonalWIP', false)
            || this.getValue('trackingSwimLanePersonalWIP', []).includes(issueId);

        this.getSwimlaneDom(issueId)
            .attr('data-ks-swimlane', Boolean(true).toString())
            .attr('data-ks-swimlane-tracking-column-wip',
                Boolean(isTrackingColumnWIP).toString())
            .attr('data-ks-swimlane-tracking-personal-wip',
                Boolean(isTrackingPersonalWIP).toString());
    }

    getSwimlaneDom(issueId) {
        return $(`.sprint-story.collapsible[data-id=${issueId}]`);
    }

    setStoryAttribute(taskId) {
        this.getTaskDom(taskId).attr('data-ks-story', Boolean(true).toString());
    }

    addTaskFilterButton($task, rootTaskId) {
        // add the filter button to the task if it does not already have it
        $task.find('.sprint-task-hover-visible:not(:has(button.sprint-task-filter-tasks))')
            .append($(this.TASK_FILTER_BUTTON_TEMPLATE()).click((e) => this.onTaskFilterButtonClick(e, rootTaskId)))
    }

    addTaskDropdownMenuButton($task) {
        // add the task dropdown menu button to the task if it does not already have it
        $task.find('.sprint-task-hover-visible:not(:has(button.dropdown-toggle))')
            .append($(this.TASK_DROPDOWN_MENU_BUTTON_TEMPLATE()).click((e) => this.onDropdownMenuButtonClick(e, false)));
    }

    onTaskFilterButtonClick(event, taskId) {
        let $target = $(event.currentTarget);
        if($target.hasClass("clicked")) {
            this.showAllTasks();
            $target.removeClass("clicked");
        } else {
            this.showOnlyTasksFor(taskId);
            $target.addClass("clicked");
        }
    }

    showOnlyTasksFor(id) {
        if (id) {
            $(`[class^="sprint-task "][data-root-task-id][data-root-task-id!=${id}][data-resolved="false"]`).hide();
        } else {
            this.showAllTasks();
        }

    }

    showAllTasks() {
        $('.sprint-story').show();
        $('[class^="sprint-task "][data-root-task-id][data-resolved="false"]').show();
    }

    /**
     * Get the Root Parent for a task, ignoring top level Stories, as they are SwimLanes ...
     * @param {*} taskId the top most "Task" in the given task's hierarchy
     */
    getRootTaskId(taskId) {
        var parentId = this.sprintModel._relationshipMap[taskId].parent;

        while (!this.issueIsStory(taskId) &&  // issue not a story
                parentId && !this.issueIsSwimlane(parentId)) { // has a parent that is not a swimlane

            // move up the relationship map
            taskId = parentId;
            parentId = this.sprintModel._relationshipMap[taskId].parent;
        }

        // return story root
        return taskId;
    }

    // Adds mouseenter and mouseleave events for .sprint-task
    enableHoverBehavior() {
        const HOVER_TASK_DELAY = 250;
        const SELECTED_TASK = 'selected_task';
        const SELECTED_TASK_CLASS = `.${SELECTED_TASK}`;
        let hideTask;
        let unhideTask;

        // Only do some of this on the task board, not the list view, as it makes the list view unusable
        $(document).on({
            mouseenter: (e) => {
                var taskId = $(e.currentTarget).attr('data-root-task-id');
                if (taskId !== undefined) {
                    window.clearTimeout(unhideTask);
                    let timeout = $(SELECTED_TASK_CLASS).length > 0 ? 0 : HOVER_TASK_DELAY;
                    hideTask = window.setTimeout(() => {
                        $('#sprint-board-visualization').addClass('hideTasks');
                        $(SELECTED_TASK_CLASS).removeClass(SELECTED_TASK);
                        $(`[data-root-task-id="${taskId}"]`).addClass(SELECTED_TASK);
                    }, timeout);
                }
            },
            mouseleave: (e) => {
                var taskId = $(e.currentTarget).attr('data-root-task-id');
                if (taskId !== undefined) {
                    window.clearTimeout(hideTask);
                    unhideTask = window.setTimeout(() => {
                        $('#sprint-board-visualization').removeClass('hideTasks');
                        $(SELECTED_TASK_CLASS).removeClass(SELECTED_TASK);
                    }, HOVER_TASK_DELAY);
                }
            }
        }, '#sprint-view[data-sprint-mode="lanes"] .sprint-task');

        $(document).on({
            mouseenter: (e) => {
                var assignee = $(e.currentTarget).attr('data-assignee');
                if (assignee !== undefined) {
                    window.clearTimeout(unhideTask);
                    let timeout = $(SELECTED_TASK_CLASS).length > 0 ? 0 : HOVER_TASK_DELAY;
                    hideTask = window.setTimeout(() => {
                        $('#sprint-board-visualization').addClass('hideTasks');
                        $(SELECTED_TASK_CLASS).removeClass(SELECTED_TASK);
                        $('.sprint-section').find(`[data-assignee="${assignee}"][data-resolved="false"]`).addClass(SELECTED_TASK);
                        $(`.sprint-task:has(.cr-link[data-pending-reviewers*="${assignee}"])`).addClass(SELECTED_TASK);
                    }, timeout);
                }
            },
            mouseleave: (e) => {
                var assignee = $(e.currentTarget).attr('data-assignee');
                if (assignee !== undefined) {
                    window.clearTimeout(hideTask);
                    unhideTask = window.setTimeout(() => {
                        $('#sprint-board-visualization').removeClass('hideTasks');
                        $(SELECTED_TASK_CLASS).removeClass(SELECTED_TASK);
                    }, HOVER_TASK_DELAY);
                }
            }
        }, ".personal-wip");
    }

    // checksum helper methods to determine if the board model (column count + names) has changed since settings were last saved
    areColumnSettingsStale() {
        var previousColumnChecksum = this.getValue('columnChecksum');
        var currentColumnChecksum = this.columnChecksum();
        return (previousColumnChecksum != currentColumnChecksum);
    }

    columnChecksum() {
        var columnNames = this.sprintModel._sprintLanes.map((lane, index) => {
            return lane.label[0] ? lane.label[0].text : lane.shortName;
        }).slice(0, kanbanSensei.sprintModel._sprintLanes.length-1).join(',');
        return this.checksum(columnNames);
    }

    // This is essentially a JavaScript implementation of Java's String#hashCode
    checksum(s) {
      var hash = 0, strlen = s.length, i, c;
      if ( strlen === 0 ) {
        return hash;
      }
      for ( i = 0; i < strlen; i++ ) {
        c = s.charCodeAt(i);
        hash = ((hash << 5) - hash) + c;
        hash = hash & hash; // Convert to 32bit integer
      }
      return hash;
    }

    addHiddenIssuesOutsideSprintFolderWarning() {
        const $warn = $('#hidden-issues-outside-sprint-folder-warning');
        if (kanbanSensei.getValue('hideIssuesOutsideSprintFolder', false) && !$warn.length) {
            $('.document-header .row.sprint-board-actions').prepend($(this.WARNING_HIDDEN_ISSUES_OUTSIDE_SPRINT_FOLDER_TEMPLATE()));
        } else {
            $warn.remove();
        }
    }

    LAST_COMMENT_TEMPLATE(comment) {
        var message = comment.message;
        var author = App.Helpers.UserHelpers.getIdentityLabel(comment.authorIdentity);
        var date = new Date(comment.createDate).toLocaleString();
        const $el = $(`<div class="ks-comment sprint-task-description sprint-task-detail-row"><p>Latest comment by ${author} on ${date}:</p><p class="ks-comment-message"></p></div><hr class="sprint-task-description">`);
        $el.find('.ks-comment-message').text(message);
        return $el;
    }

    ISSUE_METRICS_DATES_TEMPLATE(issueMetrics) {
        return `
            <div class="create-date sprint-task-description sprint-task-detail-row issue-metrics">CreateDate: ${issueMetrics.createDate.toLocaleDateString()}</div>
            <div class="start-date sprint-task-description sprint-task-detail-row issue-metrics">StartDate: ${issueMetrics.startDate.toLocaleDateString()}</div>
            <hr class="sprint-task-description">
        `;
    }

    ISSUE_NEED_BY_TEMPLATE(needByDate) {
        var needByDateDisplay = '';

        if(needByDate){
            var cssClass = needByDate > new Date() ? "need-by-date-upcoming" : "need-by-date-late";
            needByDateDisplay = `<div class="${cssClass} sprint-task-detail-row need-by-date">Need By Date: ${needByDate.toLocaleDateString()}</div>`
        }

        return `${needByDateDisplay}`;
    }

    ISSUE_ESTIMATED_START_TEMPLATE(estimatedStartDate) {
        var estimatedStartDateDisplay = '';

        if(estimatedStartDate){
            var cssClass = estimatedStartDate > new Date() ? "estimated-start-date-upcoming" : "estimated-start-date-late";
            estimatedStartDateDisplay = `<div class="${cssClass} sprint-task-detail-row estimated-start-date">Estimated Start Date: ${estimatedStartDate.toLocaleDateString()}</div>`
        }

        return `${estimatedStartDateDisplay}`;
    }

    ISSUE_ESTIMATED_COMPLETION_TEMPLATE(estimatedCompletionDate) {
        var estimatedCompletionDateDisplay = '';

        if(estimatedCompletionDate){
            var cssClass = estimatedCompletionDate > new Date() ? "estimated-completion-date-upcoming" : "estimated-completion-date-late";
            estimatedCompletionDateDisplay = `<div class="${cssClass} sprint-task-detail-row estimated-completion-date">Estimated Completion Date: ${estimatedCompletionDate.toLocaleDateString()}</div>`
        }

        return `${estimatedCompletionDateDisplay}`;
    }

    ISSUE_CUSTOM_FIELDS_TEMPLATE(customFieldsArray) {
        if (!customFieldsArray.length) {
            return '';
        }

        var customFieldsDisplay = '<TABLE class="ks-custom-fields" border="1" style="border-collapse:collapse">';

        customFieldsArray.forEach(function (item, index) {
            customFieldsDisplay +=  `<tr><td><b>${item["key"]}</b></td> <td>${item["value"]}</td>`
          });

        return `${customFieldsDisplay}</TABLE>`;
    }

    ISSUE_METRICS_POINTS_ONLY_TEMPLATE(points) {
        return `
            <div class="ks-metrics-times sprint-task-detail-row issue-metrics">
                Points: ${points}
            </div>
        `;
    }

    ISSUE_METRICS_TIMES_TEMPLATE(issueMetrics, displayEstimateTaskPoints) {
        return `
            <div class="ks-metrics-times sprint-task-detail-row issue-metrics">
                ${displayEstimateTaskPoints !== 'never' ? `Points: ${issueMetrics.points} | ` : ''}
                CycleTime: ${issueMetrics.cycleTime}d | LeadTime: ${issueMetrics.leadTime}d | TimeInColumn: ${issueMetrics.timeInColumn}d
                ${issueMetrics.timeBlocked ? ` | Blocked: ${issueMetrics.timeBlocked}d` : ''}
            </div>
        `;
    }

    ISSUE_RANK_TEMPLATE(rank) {
        return `
            <div class="ks-metrics-times sprint-task-detail-row rank">
                Rank: ${rank}
            </div>
        `;
    }

    KS_MENU_ITEMS() {
        return `
            <li class='divider'/>
            <li class='ks-settings'>
                <a>KanbanSensei Settings</a>
            </li>
            <li class='ks-metrics'>
                <a>KanbanSensei Metrics Dashboard</a>
            </li>
            <li class='ks-focus'>
                <a>Toggle focus-mode</a>
            </li>
        `;
    }

    KS_TOOLBAR_BUTTON_TEMPLATE() {
        return `
            <div class="btn-group" style="margin-right: -1px">
                <button class="ks-dropdown-btn btn dropdown-toggle" data-toggle="dropdown" title="KanbanSensei Settings & Metrics Modals" type="button">
                    <i class="icon-star"></i>
                                    KanbanSensei
                    <span class="caret"></span>
                </button>
                <ul class="dropdown-menu pull-left">
                  <li class="ks-settings"><a>Settings</a></li>
                  <li class="ks-metrics"><a>Metrics Dashboard</a></li>
                  <li class="ks-focus" title="Focus-mode hides the first and last columns of the board so that you can focus only in the ongoing tasks. Very useful for daily meetings, for example">
                    <a>Toggle focus-mode 💡</a>
                  </li>
                </ul>
            </div>
        `;
    }

    TASK_FILTER_BUTTON_TEMPLATE() {
        return `
            <button class="unstyled sprint-task-filter-tasks" title="Toggle tasks" type="button">
                <i class="icon-tasks"></i>
            </button>
        `;
    }

    DONE_COLUMN_HEADER_TEMPLATE() {
        return `
            <span id="ks-done">
                <button class="ks-btn-sm btn" type="button" style="margin-left:10px;">Load All</button>
                <i class="icon-spinner" style="margin-left:10px;display:none;"></i>
            </span>
        `;
    }

    SWIM_LANE_MENU() {
        return `
            <li class="sprint-planning-hidden ks-sprint-swimlane-toggle-menu" 
                    data-reusable-item-status-hidden="Resolved" 
                    data-reusable-item-type-visible="Story">
                <a class="ks-sprint-swimlane-column-wip" href="javascript://" 
                    data-ks-checkbox-key="trackingSwimLaneColumnWIP">
                    <i class="icon-check-empty"></i>
                    Include Swim Lane in Column WIP
                </a>
            </li>
            <li class="sprint-planning-hidden ks-sprint-swimlane-toggle-menu" 
                    data-reusable-item-status-hidden="Resolved" 
                    data-reusable-item-type-visible="Story">
                <a class="ks-sprint-swimlane-personal-wip" href="javascript://" 
                    data-ks-checkbox-key="trackingSwimLanePersonalWIP">
                    <i class="icon-check-empty"></i>
                    Include Swim Lane in Personal WIP
                </a>
            </li>
        `;
    }

    TASK_DROPDOWN_MENU_BUTTON_TEMPLATE() {
        return `
            <button class="unstyled dropdown-toggle" 
                    data-name="sprint-board-task-resusable-menu-toggle" 
                    data-target="#sprint-board-task-reusable-menu" 
                    data-toggle="reusablemenu" 
                    title="More actions..." 
                    type="button">
                <i class="icon-collapse" tabindex="0"></i>
            </button>
        `;
    }

    WARNING_HIDDEN_ISSUES_OUTSIDE_SPRINT_FOLDER_TEMPLATE() {
        return `
            <div id="hidden-issues-outside-sprint-folder-warning" style="color: red">
                KanbanSensei setting <code>Hide issues outside the sprint folder</code> is enabled
            </div>
        `;
    }

    CSS_OVERRIDES() {
        return `
            <style type="text/css">
                .need-by-date {
                    color: #fff;
                    font-weight: bold;
                    padding: 2px;
                }

                .need-by-date-upcoming {
                    background-color: #f89406;
                }

                .need-by-date-late {
                    background-color: #dc4c41;
                }

                .estimated-start-date {
                    color: #fff;
                    font-weight: bold;
                    padding: 2px;
                }

                .estimated-start-date-upcoming {
                    background-color: #629957;
                }

                .estimated-start-date-late {
                    background-color: #f89406;
                }

                .estimated-completion-date {
                    color: #fff;
                    font-weight: bold;
                    padding: 2px;
                }

                .estimated-completion-date-upcoming {
                    background-color: #f89406;
                }

                .estimated-completion-date-late {
                    background-color: #dc4c41;
                }

                .dropdown-menu li.ks-sprint-swimlane-toggle-menu a:not([data-ks-swimlane-id]) {
                    display: none;
                }
            
                #sprint-view .sprint-board-contents .sprint-task[data-ks-story="true"] .sprint-task-content .sprint-task-header {
                    background-color: darkslategrey;
                }
            
                #sprint-view .sprint-board-contents .sprint-task.selected_task {
                    border: 1px solid Lime;
                    zoom: 1;
                    filter: alpha(opacity=100);
                    opacity: 1;
                }

                /* This override helps making the KanbanSensei button clickable*/
                #sprint-view .document-header .document-view-title {
                    margin-right: 420px !important;
                }

                #sprint-board-visualization.hideTasks .sprint-task {
                    zoom: 1;
                    background-color: rgba(0,0,0,0.2);
                    filter: alpha(opacity=20);
                    opacity: 0.2;
                    -webkit-transition: opacity .3s ease-in-out;
                    -moz-transition: opacity .3s ease-in-out;
                    -ms-transition: opacity .3s ease-in-out;
                    -o-transition: opacity .3s ease-in-out;
                    transition: opacity .3s ease-in-out;
                }

                span[data-sprint-task-field=title] {
                    color: black;
                }

                .section-header {
                    margin: 0 5px;
                    text-align: center;
                    font-weight: bold;
                    display: inline-block;

                    :not(:empty) {
                        border-bottom: 1px solid #333;
                    }
                }

                .section-header:not(:empty) {
                    border-bottom: 1px solid #333;
                }

                .cr-link.sprint-task-detail-row:not(.OPEN) {
                    text-decoration: line-through;
                }

                .cr-reviewer.required {
                    font-weight: bold;
                }

                .cr-reviewer.shipit {
                    color: green;
                    font-weight: bold;
                }

                .cr-reviewer {
                    overflow-wrap: break-word;
                }

                .personal-wip-limits {
                    cursor: pointer;
                }
                
                button.ks-btn-sm {
                    font-size: .7em;
                    padding: .25rem .5rem;
                    line-height: 1.5;
                }

                #ks-metrics-modal td, #ks-metrics-modal th {
                    text-align: center;
                }
                
                #ks-issue-details-modal td, #ks-issue-details-modal th {
                    text-align: center;
                }

                #ks-issue-details-modal td.title {
                    max-width: 500px;
                    overflow-wrap: break-word;
                }

                #ks-metrics-modal #ks-date-warning {
                    color:red;
                    display:none;
                    margin-bottom:20px;
                }
                
                .sprint-task-detail-row .pull-right {
                    display:none;
                }
                
                /* card assignee image, make it a set size for consistent icon view */
                .sprint-task-assignee img {
                    width: 20px;
                    height: 25px;
                    border: 1px solid #AAA;
                    margin-right: 3px;
                    border-radius: 3px;
                }

                body.modal-open .daterangepicker {
                    z-index: 3000 !important;
                }

                #ks-metrics-modal .modal-dialog, #ks-issue-details-modal .modal-dialog {
                    width: 90vw;
                    height: 90vh;
                }

                #ks-metrics-modal form {
                    float: left;
                    width: 34vw;
                }

                #ks-metrics-table {
                    width: auto;
                }

                #kanban-sensei-chart-svg {
                    width: 50vw;
                }

                #ks-metrics-modal #ks-chart-footer {
                    position: absolute;
                    width: 50vw;
                    right: 5px;
                    bottom: 5px;
                }

                .ks-dropdown-btn {
                    border-top-right-radius: 0 !important;
                    border-bottom-right-radius: 0 !important;
                }

                .document-header .btn-toolbar .btn-group > .btn:first-child:not(.ks-dropdown-btn) {
                    border-top-left-radius: 0;
                    border-bottom-left-radius: 0;
                }

                .ks-blocked-info {
                    color: white;
                    background-color: #9d261d;
                    padding-left: 5px;
                    padding-right: 5px;
                    border-radius: 3px;
                    cursor: pointer;
                    word-break: break-word;
                    overflow-wrap: break-word;
                    hyphens: auto;
                }

                .ks-blocked-info .icon-blocked {
                    color: white;
                    vertical-align: baseline;
                }

                .ks-blocked-info:hover {
                    opacity: 0.85;
                    box-shadow: 0px 0px 0px 1px #cacaca;
                }

                .ks-blocked-info a {
                    color: white;
                    text-decoration: underline;
                }

                .ks-blocked-info a:hover {
                    color: #ffdfb2;
                }
                
                .ks-switch {
                    position: relative;
                    display: inline-block;
                    height: 34px;
                    width: 60px;
                }
                
                .ks-switch input { 
                  opacity: 0;
                  width: 0;
                  height: 0;
                }
                
                .ks-slider {
                  position: absolute;
                  cursor: pointer;
                  top: 0;
                  left: 0;
                  right: 0;
                  bottom: 0;
                  background-color: #2196F3;
                  -webkit-transition: .4s;
                  transition: .4s;
                }
                
                .ks-slider:before {
                  position: absolute;
                  content: "";
                  height: 26px;
                  width: 26px;
                  left: 4px;
                  bottom: 4px;
                  background-color: white;
                  -webkit-transition: .4s;
                  transition: .4s;
                }

                input:checked + .ks-slider {
                  background-color: #2196F3;
                }
                
                input:focus + .ks-slider {
                  box-shadow: 0 0 1px #2196F3;
                }
                
                input:checked + .ks-slider:before {
                  -webkit-transform: translateX(26px);
                  -ms-transform: translateX(26px);
                  transform: translateX(26px);
                }
                
                /* Rounded sliders */
                .ks-slider.ks-round {
                  border-radius: 34px;
                }
                
                .ks-slider.ks-round:before {
                  border-radius: 50%;
                }
            </style>
        `;
    }
}

class ReviewBoardCR extends CR {
    constructor(review, reviewComments) {
        super();
        this.baseUrl = 'https://cr.amazon.com/r/';

        this.cruxStatuses = {
            'pending': 'OPEN',
            'submitted': 'SHIPPED'
        };

        let reviewRequest = review.review_request;
        this.id = reviewRequest.id;
        this.status = this.cruxStatuses[reviewRequest.status] || reviewRequest.status;
        this.author = reviewRequest.links.submitter.title;
        this.summary = reviewRequest.summary;
        this._isOpen = reviewRequest.status !== 'submitted';

        // target reviewers or actual reviewers?
        this.reviewers = reviewRequest.target_people.map((reviewer) => {
            // a ReviewBoard 'review request' is a code review, and a 'review' is what happens when
            // someone publishes a response.
            let hasShipped = reviewComments.reviews.some((reviewResponse) => {
                return reviewResponse.ship_it && reviewResponse.links.user.title === reviewer.title;
            });

            return {
                name: reviewer.title,
                necessity: 'optional',
                status: hasShipped ? 'shipit' : 'pending'
            };
        });
    }
}
