// ==UserScript==
// @name        Nuke Custom Photos
// @downloadURL https://improvement-ninjas.amazon.com/GreaseMonkey/nuke-custom-photos.user.js
// @updateURL https://improvement-ninjas.amazon.com/GreaseMonkey/nuke-custom-photos.user.js
// @description Change custom photos to not custom photos, everywhere, now and forever - by kamling@
// @include     http*://*.amazon.com/*
// @include     http*://*.amazon.com:*/*
// @version     1.1
// ==/UserScript==
// $Revision: #8 $

function nuke_custom_photos()
{
    // This is purposefully brutal, in order to try to prevent circumvention
    var reInternal = new RegExp("^(?:https?://(internal-cdn.amazon.com/)?[^/]*)?/phone/phone-image.cgi\\?(?:.*&|)uid=([^&]*)");
    var reConnect = new RegExp("^(?:https?://(internal-cdn.amazon.com/)?[^/]*)?/people/([^/]*)/(?:custom_)?photo(\\?.*)?$");
    var imgs = document.getElementsByTagName('img');

    for(var i = 0; i < imgs.length; ++i)
    {
        var img = imgs[i];
        if(reInternal.test(img.src))
        {
            img.src = "https://" + RegExp.$1 + "badgephotos.amazon.com/?uid=" + RegExp.$2;
        }
        if(reConnect.test(img.src))
        {
            img.src = "https://" + RegExp.$1 + "connect.amazon.com/people/" + RegExp.$2 + "/badge_photo" + RegExp.$3;
        }
    }
}

nuke_custom_photos();
