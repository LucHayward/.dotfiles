// ==UserScript==
// @name           PipelinesPackageSort
// @downloadURL    https://improvement-ninjas.amazon.com/GreaseMonkey/pipelinesPackageSort.user.js
// @updateURL      https://improvement-ninjas.amazon.com/GreaseMonkey/pipelinesPackageSort.user.js
// @match          https://pipelines.amazon.com/pipelines/*
// @description    Sort packages in pipelines by change date, package name, author name
// @version        1.2
// @namespace      https://amazon.com
// @author         huesch@, gruenem@, chowes@, deguzim@, hugocost@
// @grant          none
// ==/UserScript==

(function () {
    'use strict';
    console.log('PipelinesPackageSort script started');

    // Get the sorting order from local storage:
    let sortby = localStorage.getItem('PipelineSort') || 'date';

    // Functions to get values for each package:
    function find_date(item) {
        const timeElement = item.querySelector(".relative-time");
        return parseInt(timeElement.getAttribute("data-millis"));
    }

    function find_package_name(item) {
        return item.querySelector(".name a").textContent.trim();
    }

    function find_author_name(item) {
        const authors = item.querySelectorAll(".latest-rev a");
        return authors[1] ? authors[1].textContent.trim() : '';
    }

    // Sort the packages:
    function pipelineResort() {
        console.log('Resorting packages...');
        const container = document.querySelector('#stage-name-Packages ul.targets');
        const items = Array.from(container.querySelectorAll('.target'));

        items.sort(function (a, b) {
            if (sortby === "pname") return find_package_name(a).localeCompare(find_package_name(b));
            if (sortby === "revpname") return find_package_name(b).localeCompare(find_package_name(a));
            if (sortby === "aname") return find_author_name(a).localeCompare(find_author_name(b));
            if (sortby === "revaname") return find_author_name(b).localeCompare(find_author_name(a));
            if (sortby === "revdate") return find_date(a) - find_date(b);
            return find_date(b) - find_date(a);
        });

        items.forEach(item => container.appendChild(item));
    }

    // Create and add dropdown menu
    function createDropdown() {
        const select = document.createElement('select');
        select.id = 'pipelineSort';

        const options = [
            ['date', 'Date - newest first'],
            ['revdate', 'Date - oldest first'],
            ['pname', 'Package name - A-Z'],
            ['revpname', 'Package name - Z-A'],
            ['aname', 'Author name - A-Z'],
            ['revaname', 'Author name - Z-A']
        ];

        options.forEach(([value, text]) => {
            const option = document.createElement('option');
            option.value = value;
            option.textContent = text;
            select.appendChild(option);
        });

        select.value = sortby;
        select.addEventListener('change', function () {
            sortby = this.value;
            localStorage.setItem('PipelineSort', sortby);
            pipelineResort();
        });

        const titleElement = document.querySelector('#stage-name-Packages .stage_info h3 .name').parentElement;
        titleElement.appendChild(select);
    }

    // Style time elements
    function styleTimeElements() {
        document.querySelectorAll('.relative-time').forEach(el => {
            el.style.float = 'right';
            el.style.borderRadius = '5px';
            el.style.padding = '3px';

            const text = el.textContent;
            if (text.includes('m ago') || text.includes('h ago')) {
                el.style.backgroundColor = '#ccffcc'; // Greenish
            } else if (text.includes('d ago')) {
                el.style.backgroundColor = '#fff7cd'; // Yellowish
            } else if (text.includes('mo ago')) {
                el.style.backgroundColor = '#ffddcc'; // Orangish
            } else if (text.includes('y ago')) {
                el.style.backgroundColor = '#ffcccc'; // Reddish
            }
        });
    }

    createDropdown();
    pipelineResort();
    styleTimeElements();

    console.log('PipelinesPackageSort script completed');
})();

