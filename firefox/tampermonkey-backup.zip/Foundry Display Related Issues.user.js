// ==UserScript==
// @name         Foundry Display Related Issues
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Display issues related to the service being viewed on Foundry website in a dropdown.
// @author       Renato Besen
// @include      https://foundry-*.aka.amazon.com/services/*
// @grant        GM_xmlhttpRequest
// @connect      maxis-service-prod-dub.amazon.com
// ==/UserScript==

(function($) {
    'use strict';

    var navBar = $('.navbar-nav:first');
    var serviceName = navBar.children()[0].textContent;
    var searchUrl = 'https://maxis-service-prod-dub.amazon.com/issues?q=status:Open+AND+containingFolder:(1f1d5696-d284-47d0-8f5d-6eec78b87ea0+OR+6d4e44ed-82a8-45c3-aec7-9fbe1f46947f+OR+f268b9f0-c9dd-460d-baf6-1ce7bc331c70+OR+2a1aab7c-4251-43dc-9f2e-3f0935d15426)+AND+full_text:%22' + serviceName + '%22&sort=lastUpdatedConversationDate+desc&rows=20&omitPath=conversation&';

    GM_xmlhttpRequest( {
        method: 'GET',
        url: searchUrl,
        onload: function (responseDetails) {
            console.log('got response');
            var dropdownLi = $('<li class="dropdown">');
            dropdownLi.append($('<a href="#" data-toggle="dropdown">').text('Issues').append($('<span class="caret"></span>')));
            navBar.append(dropdownLi);

            var issues = $('<ul class="dropdown-menu" style="width: 400px;">');
            var documents = $.parseJSON(responseDetails.responseText).documents;
            documents.forEach(function(e) {
                issues.append(
                    $("<li>")
                        .append($("<a style='white-space: normal;'>")
                                .attr('href','https://issues.amazon.com/issues/'+e.id)
                                .append($('<span class="fa fa-tag"></span>'))
                                .append(" "+e.title))
                );
            });
            dropdownLi.append(issues);
        }
    });
})(jQuery);

