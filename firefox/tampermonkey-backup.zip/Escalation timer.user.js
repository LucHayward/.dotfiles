// ==UserScript==
// @name         Escalation timer
// @namespace    http://tampermonkey.net/
// @version      2.18
// @description  Escalation timer for high sev.
// @author       https://phonetool.amazon.com/users/arunkar
// @match        https://t.corp.amazon.com/*
// @match        https://tt.amazon.com/*
// @downloadURL  https://code.amazon.com/packages/ArunkarScripts/blobs/mainline/--/scripts/ticketing/EscalationTimerForSev2.user.js?raw=1
// @updateURL    https://code.amazon.com/packages/ArunkarScripts/blobs/mainline/--/scripts/ticketing/EscalationTimerForSev2.user.js?raw=1
// @require      https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.2/moment.min.js
// @require      https://m.media-amazon.com/images/I/61N6qD3NeaL.js#ver=jquery-1.9.1.min.js
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_getResourceText
// @grant        GM.xmlHttpRequest
// @grant        GM_addStyle
// @grant        GM_openInTab
// ==/UserScript==

var debugEnabled = false;
var collectAnalytics = true;
var version = GM_info.script.version;


var mutated = false;
var hasMutationOccurred = false;
var tableQuery = "#sim-issueListContent table tbody"
const maxisEndpoint = "https://maxis-service-prod-pdx.amazon.com";
const gmReq = GM.xmlHttpRequest;
var mutationObserver = new MutationObserver(function (mutations) {
    hasMutationOccurred = true;
    // Reset on page navigation (new ticket IDs detected)
    var currentIds = $('table > tbody > tr [data-sid]').map(function() { return this.dataset.sid; }).get().join(',');
    if (window._lastTicketIds && window._lastTicketIds !== currentIds) {
        mutated = false;
    }
    window._lastTicketIds = currentIds;
    if ($('table > tbody > tr').length > 1 && !mutated) {
        debug("calling the main method");
        mutated = true;
        updateHomePage();
    } else if (!mutated && $('table > tbody > tr').length <= 1) {
        mutated = false;
    }

    if ($('table > tbody > tr').length < 1) {
        mutated = false;
    }

    if (!mutated) {
        //This case is to ensure that the table has proper data. especially with one row.
        if (tableHasData()) {
            mutated = true;
            updateHomePage();
        }
    }

});

function tableHasData() {
    if (document.querySelector(tableQuery) == null) {
        return;
    }
    var table = Array.from(document.querySelector(tableQuery).querySelectorAll('tr'))
    var ticketData = []
    for (var i = 0; i < table.length; i++) {
        var cols = table[i].querySelectorAll('td');
        if (cols[1]) {
            debug("Data is found");
            return true;
        }
    }
    return false;
}

var detailPageMutationObserver = new MutationObserver(function (mutations) {
    debug("seen mutation");
    let statusElement = $('.issue-summary-status .display-mode');
    let sevElement = $('issue-summary-severity .display-mode');
    if (statusElement && sevElement) {
        removeEscalationTimer();
        updateDp();
    }
});

function removeEscalationTimer() {
    // clear the escalation time if exist
    debug("clear the escalation time if exist");
    if (timer != null) {
        clearInterval(timer);
        timer = null;
    }

    const count_down_timer = document.querySelector("#count_down_timer");
    if (count_down_timer) {
        count_down_timer.parentNode.removeChild(count_down_timer)
    }
}


function updateDp() {
    addSIMMetrics();
    let status = $('.issue-summary-status .info-value')[0].innerText;
    let sev = $('.issue-summary-severity .info-value')[0].innerText;
    let group = $('.issue-summary-cti .group .info-value')[0].innerText;
    if (sev <= 2) {
        let ticketId = $('.ticket-id')[0].innerText;
        debug(ticketId);
        let issue = {
            id: ticketId.trim(),
            sev: sev,
            status: status,
            group: group,
        }
        getEditsAndRender(issue, false)
    }
}

function observeMutation(selector) {
    debug("setting observer on " + selector)
    mutationObserver.observe(document.querySelector(selector), { childList: true, subtree: true });
    //Calling the below method with timed delay to update the UI, even if there is no mutation observed but the data is already available.
    setTimeout(hackForAlreadyMutated, 1000);
}

function observeMutationDp(selector) {
    debug("setting dp observer on " + selector)
    detailPageMutationObserver.observe(document.querySelector(selector), { attributes: true });
}

function waitForElementToDisplay(selector, callback, checkFrequencyInMs, timeoutInMs) {
    var startTimeInMs = Date.now();
    (function loopSearch() {
        if (document.querySelector(selector) != null) {
            callback(selector);
            return;
        } else {
            setTimeout(function () {
                if (timeoutInMs && Date.now() - startTimeInMs > timeoutInMs) {
                    return;
                }
                loopSearch();
            }, checkFrequencyInMs);
        }
    })();
}


function getShortId(html) {
    return html.dataset.sid
}

async function updateHomePage() {
    addSIMMetrics();
    var table = Array.from(document.querySelector(tableQuery).querySelectorAll('tr'))
    var ticketData = []
    var promiseArray = []
    for (var i = 0; i < table.length; i++) {
        var cols = $(table[i].querySelectorAll('td'));
        let val = {
            sev: cols.find('.severity').text(),
            id: getShortId(cols.find('.sim-list--shortId')[0]), // guranteed to exist
            status: cols.find('.sim-table--status').text(),
            group: cols.find('.sim-table--assignedGroup').text(),
        }
        if (!val.sev || !val.status || !val.group) {
            promiseArray.push(getTicketInfo(val).then(finalizedVal => ticketData.push(finalizedVal)));
        } else {
            ticketData.push(val);
        }
    }


    // allow some time for getTicketInfo() requests to be returned
    if (ticketData.length != table.length) {
        await Promise.all(promiseArray)
        filterAndOrchestrate(ticketData);
    } else {
        filterAndOrchestrate(ticketData);
    }
}

async function filterAndOrchestrate(issues) {
    debug(issues)
    for (let i = 0; i < issues.length; i++) {
        await getCTIPreferences(issues[i]) // preload CTI preferences
    }

    for (let i = 0; i < issues.length; i++) {
        if (issues[i].sev <= 2) {
            getEditsAndRender(issues[i], true);
        }
    }
}

const TICKET_STATUS_TO_ESCALATION_MINUTES = {
    'Assigned': () => 30,
    'Researching': () => 90,
    'Work In Progress': () => 480, // 8 hours
    'Work in Progress': () => 480, // 8 hours
    'Pending': (group) => getPendingTime(group),
}

function getEditsAndRender(issue, renderOnHome) {
    debug(maxisEndpoint + "/issues/" + issue.id + "/edits");
    gmReq({
        method: "GET",
        url: maxisEndpoint + "/issues/" + issue.id + "/edits",
        onload: function wrapper(editResponse) { getCTIPreferences(issue).then(() => updateEscalationTime(editResponse, issue, renderOnHome)); },
        onerror: function wrapper(editResponse) { getCTIPreferences(issue).then(() => updateEscalationTime(editResponse, issue, renderOnHome)); }
    });
}

function getTicketInfo(issue) {
    console.log("Calling ticketinfo " + issue.id + " " + new Date().getTime());
    return new Promise((resolve, reject) => {
        gmReq({
            method: "GET",
            url: maxisEndpoint + "/issues/" + issue.id,
            onload: function wrapper(issueResponse) {
                issueResponse = JSON.parse(issueResponse.responseText);
                issue.sev = issueResponse.extensions.tt.impact;
                issue.status = issueResponse.extensions.tt.status;
                issue.group = issueResponse.extensions.tt.assignedGroup;
                console.log(new Date().getTime() + " - Got response " + issue.id);
                resolve(issue);
            },
            onerror: function wrapper(issueResponse) { reject(); }
        });
    })
}

var groupPreferences = {};
var groupMetadata = {};
var emailAliasMapping = {};

function getCTIPreferences(issue) {
    debug("Calling CTI " + issue.group);
    return new Promise((resolve, reject) => {
        if (groupPreferences[issue.group]) {
            return resolve()
        }
        gmReq({
            url: maxisEndpoint + '/groups?q=label:"' + issue.group + '"&rows=1&sort=createDate asc',
            xhrFields: { withCredentials: true },
            onload: function (data) {
                data = JSON.parse(data.responseText);
                var group = data.documents[0];
                groupMetadata[issue.group] = group;
                gmReq({
                    url: maxisEndpoint + '/grouppreferences/' + group?.preferences,
                    xhrFields: { withCredentials: true },
                    onload: function wrapper(preferences) {
                        preferences = JSON.parse(preferences.responseText);
                        groupPreferences[issue.group] = preferences;
                        resolve();
                    },
                    onerror: function () { reject(); }
                });
                if(group?.manager?.split(':')?.[0] == "email-alias"){
                    gmReq({
                        url: maxisEndpoint + '/emailAliases?q=' + group?.manager?.split(':')?.[1],
                        xhrFields: { withCredentials: true },
                        onload: function wrapper(response) {
                            let emailData = JSON.parse(response.responseText);
                            emailAliasMapping[group?.manager?.split(':')?.[1]] = emailData.documents[0].email[0].id;
                            resolve();
                        },
                        onerror: function () { reject(); }
                    });
                }
            },
            onerror: function () { reject(); }
        });
    }
    )
}

// defaults to 1 week
function getPendingTime(group) {
    let escalationTime = groupPreferences[group]?.customRules?.highSev?.pendingEscalationTime / 60;
    return typeof escalationTime === "undefined" ? 10080 : escalationTime;
}

// defaults to undefined
function getIsBusinessHours(group) {
    return groupPreferences[group]?.daytimeOnlyPendingEscalation;
}

function getEscalatesTo(group) {
    let manager = groupMetadata[group]?.manager?.split(':');
    if (manager && manager[0] == 'email-alias') {
        manager = emailAliasMapping[manager[1]];
    } else if (manager && manager.length == 2) {
       manager = manager[1].split('@')?.[0] + '@';
    }
    debug(manager)
    return manager;
}

function updateEscalationTime(editresponse, issue, renderOnHome) {
    debug(groupPreferences);
    let jsonResponse = JSON.parse(editresponse.responseText);
    let statusUpdates = parseEdits(jsonResponse.edits);
    debug(statusUpdates);
    let statusChanges = statusUpdates.auditTrailStatusChanges.sort((a, b) => b.createDate - a.createDate); //Sort in descending order i.e with latest on the top
    let currentStatus = issue.status;
    debug(currentStatus, "CurrentStatus");
    if (TICKET_STATUS_TO_ESCALATION_MINUTES[currentStatus] == null) {
        debug("Couldn't find the status. The ticket could be resolved");
        return;
    }
    let lastStatus = null;
    //Pick the farthest status. This is to avoid multipe same status changes at once. i.e pending to pending change
    for (let i = 0; i < statusChanges.length; i++) {
        if (lastStatus == null) {
            lastStatus = statusChanges[i];
        } else if (lastStatus.datum == statusChanges[i].datum) {
            lastStatus = statusChanges[i];
        } else {
            break;
        }
    }
    debug(lastStatus);
    let lastStatusChangeTime = moment(lastStatus.createDate);
    debug(lastStatusChangeTime);
    let escalationTime = lastStatusChangeTime.add(TICKET_STATUS_TO_ESCALATION_MINUTES[currentStatus](issue.group), 'm');
    debug(escalationTime);
    let minutesUntilEscalation = escalationTime.diff(moment(), 'minutes');
    debug(minutesUntilEscalation);
    if (renderOnHome) {
        renderInHomePage(issue, minutesUntilEscalation, escalationTime)
    } else {
        renderInDp(issue, minutesUntilEscalation, escalationTime)
    }
}

function renderInHomePage(issue, minutesUntilEscalation, escalationTime) {
    debug(issue)
    let query = "[data-sid=" + issue.id + "]";
    debug(query);
    let escalationWindow = TICKET_STATUS_TO_ESCALATION_MINUTES[issue.status](issue.group) * .66; // color based on the current status' escalation time (Pending is unique to CTI).
    if (minutesUntilEscalation <= escalationWindow) {
        var opacity = (escalationWindow - minutesUntilEscalation) / escalationWindow;
        debug(opacity, "opacity");
        $(query)[0].closest('tr').style.backgroundColor = 'rgba(255, 107, 107, ' + opacity + ')';
    }
    let manager = getEscalatesTo(issue.group);
    let localDateStr = convertTimeToLocalDate(escalationTime)
    if (manager) {
        manager = 'to ' + manager + ' ';
    }
    $(query).closest('tr').find('.title-wrapper')[0].innerHTML += '<span style="margin-left: 5px;"><br/> 🕧 Escalates ' + manager + escalationTime.fromNow() + " (" + localDateStr + ") " + getBusinessHoursOnlyMessage(issue) + '</span>';
}

function convertTimeToLocalDate(escalationTime) {
    let localDateStr = new Date(escalationTime).toLocaleString(undefined, { timeZoneName: 'short' })
    return localDateStr;
}

function createElement(elementId) {
    var countDown = document.createElement("p");
    countDown.id = elementId;
    document.querySelector(".issue-detail-content").before(countDown);
    return countDown;
}


function getNumberAsTwoDigits(number) {
    if (number < 10) {
        return "0" + number.toString();
    }

    return number.toString();
}

String.prototype.format = function () {
    var content = this;
    for (var i = 0; i < arguments.length; i++) {
        var replacement = '{' + i + '}';
        content = content.replace(replacement, arguments[i]);
    }
    return content;
};


var TIME_REMAINING_DIV = '<div style="margin: 0 auto 0 auto; margin-bottom: 5px; font-size: 24px; text-align: center; color: #ff0000;"><p> Time to escalation: {0} days {1} hours {2} minutes {3} seconds {4} {5}</p></div>';
var ESCLATES_TO_STRING = '<br><br> Escalates to {0} at {1}';
var ESCALATING_DIV = '<div style="margin: 0 auto 0 auto; margin-bottom: 5px; font-size: 24px; text-align: center; color: #ff0000;"><p>Escalating {0}</p></div>';

function updateTimer(countDown, days, hours, mins, sec, issue, escalationTime) {
    if (days == 0 && hours == 0 && mins == 0 && sec == 0) {
        countDown.innerHTML = ESCALATING_DIV.format(getBusinessHoursOnlyMessage(issue));
        return false;
    }
    let escalatesTo = '';
    if (getEscalatesTo(issue.group)) {
        escalatesTo = ESCLATES_TO_STRING.format(getEscalatesTo(issue.group), convertTimeToLocalDate(escalationTime))
    }
    countDown.innerHTML = TIME_REMAINING_DIV.format(days, hours, mins, sec, getBusinessHoursOnlyMessage(issue), escalatesTo);
    return true;
}

function getBusinessHoursOnlyMessage(issue) {
    return getIsBusinessHours(issue.group) && issue.status === 'Pending' ? 'during business hours only' : '';
}


var timer;
function renderInDp(issue, minutesUntilEscalation, escalationTime) {
    removeEscalationTimer();
    let countDown = createElement("count_down_timer");
    let days = Math.floor((minutesUntilEscalation / 60 / 24));
    let hours = Math.floor(((minutesUntilEscalation - (days * 60 * 24)) / 60));
    let mins = Math.floor((minutesUntilEscalation - (days * 60 * 24) - (hours * 60)))
    let sec = 59;
    function checkAndUpdateTimer() {
        if (updateTimer(countDown, days, hours, mins, sec, issue, escalationTime)) {
            sec--;
            if (sec < 0) {
                sec = 59;
                mins--;
            }
            if (mins < 0) {
                mins = 59;
                hours--;
            }
            if (hours < 0) {
                hours = 23;
                days = 0;
            }
            if (days < 0) {
                days = 0;
                hours = 0;
                mins = 0;
                sec = 0;
            }
        }
    }

    checkAndUpdateTimer();
    timer = setInterval(checkAndUpdateTimer, 1000);
}


function debug(value) {
    if (debugEnabled) {
        if (arguments.length > 1) {
            console.log(arguments[1] + " : " + JSON.stringify(value));
        } else {
            console.log(value);
        }
    }
}

function parseEdits(edits) {
    let parsedData = {
        auditTrailStatusChanges: [],
        severityChanges: [],
        resolverGroupChanges: []
    }
    debug(edits)
    for (let i = 0; i < edits.length; i++) {
        let edit = edits[i];
        // Always include the first audit trail entry so we show when the ticket started
        if (i === 0 && edit.pathEdits.length > 0) {
            let pathEdit = edit.pathEdits[0];
            if (pathEdit.hasOwnProperty('data')) {
                let data = pathEdit.data;
                if (data.hasOwnProperty('extensions') && data.extensions.hasOwnProperty('tt')) {
                    let createDate = new Date(edit.actualCreateDate);
                    parsedData.auditTrailStatusChanges.push({
                        datum: 'Assigned',
                        createDate
                    });
                    parsedData.severityChanges.push({
                        datum: data.extensions.tt.impact + "",
                        createDate
                    });
                    parsedData.resolverGroupChanges.push({
                        datum: data.extensions.tt.assignedGroup,
                        createDate
                    });
                }
            }
        }
        for (let j = 0; j < edit.pathEdits.length; j++) {
            let pathEdit = edit.pathEdits[j];
            // Status
            if (pathEdit.hasOwnProperty('data')) {
                let pathEditData = pathEdit.data;
                if (typeof pathEditData === 'object') {
                    if (pathEditData.hasOwnProperty('action') && pathEditData.hasOwnProperty('owner')) {
                        let datum;
                        if (pathEditData.action === 'Comment') {
                            datum = 'Assigned';
                        } else if (pathEditData.action === 'Research') {
                            datum = 'Researching';
                        } else if (pathEditData.action === 'Implementation') { // Implementation can either be actual 'Implementation' or 'Pending'
                            if (pathEditData.hasOwnProperty('exceptions') && pathEditData.exceptions.length != 0) {
                                datum = 'Pending';
                            } else {
                                datum = 'Work In Progress';
                            }
                        } else {
                            datum = pathEditData.action;
                        }
                        let auditTrailChange = {
                            datum,
                            createDate: new Date(edit.actualCreateDate)
                        };
                        parsedData.auditTrailStatusChanges.push(auditTrailChange);
                    }
                }
            }
            // Resolved status is different
            if (pathEdit.hasOwnProperty('path') && pathEdit.path === '/status' && pathEdit.hasOwnProperty('data') && pathEdit.data === 'Resolved') {
                let auditTrailChange = {
                    datum: 'Resolved',
                    createDate: new Date(edit.actualCreateDate)
                };
                parsedData.auditTrailStatusChanges.push(auditTrailChange);
            }
            // Escalated
            if (pathEdit.hasOwnProperty('path') && pathEdit.path === '/extensions/notifications/timesEscalated' && pathEdit.hasOwnProperty('data')) {
                let auditTrailChange = {
                    datum: 'Escalated@' + pathEdit.data,
                    createDate: new Date(edit.actualCreateDate)
                };
                parsedData.auditTrailStatusChanges.push(auditTrailChange);
            }

            //Ticket Upgraded / Downgraded - This is to ensure that the timer is reset.
            if (pathEdit.hasOwnProperty('path') && pathEdit.path === '/extensions/tt/impact') {
                //Get the old severity
                let previousSeverity = 2;
                if (parsedData.severityChanges.length > 0) {
                    previousSeverity = parsedData.severityChanges[parsedData.severityChanges.length - 1].datum;
                }
                let currentSev = pathEdit.data;
                previousSeverity = parseInt(previousSeverity);
                debug("Previous sev: " + previousSeverity + " Current sev " + currentSev);
                if (currentSev < previousSeverity) { // Upgraded
                    let auditTrailChange = {
                        datum: 'UpgradedToSev' + pathEdit.data,
                        createDate: new Date(edit.actualCreateDate)
                    };
                    parsedData.auditTrailStatusChanges.push(auditTrailChange);
                } else if (currentSev > previousSeverity) { // Downgraded
                    let auditTrailChange = {
                        datum: 'DowngradedToSev' + pathEdit.data,
                        createDate: new Date(edit.actualCreateDate)
                    };
                    parsedData.auditTrailStatusChanges.push(auditTrailChange);
                }
            }

            // Severity
            if (pathEdit.hasOwnProperty('path') && pathEdit.path === '/extensions/tt/impact') {
                let severityChange = {
                    datum: pathEdit.data + "",
                    createDate: new Date(edit.actualCreateDate)
                };
                parsedData.severityChanges.push(severityChange);
            }
            // Group
            if (pathEdit.hasOwnProperty('path') && pathEdit.path === '/extensions/tt/assignedGroup') {
                let groupChange = {
                    datum: pathEdit.data,
                    createDate: new Date(edit.actualCreateDate)
                };
                parsedData.resolverGroupChanges.push(groupChange);
            }
        }
    }
    return parsedData;
}

function addSIMMetrics() {
    if (collectAnalytics) {
        var email = "";
        $('[class*="awsui_description"]').each(function(i,ele) {
            var inner = ele.innerHTML.trim();
            if (/\S*@\S*/.test(inner)) {
                email = inner;
                return false;
            }
        });
        var userName = email.slice(0, email.lastIndexOf('@'));
        var attributes = "&login=" + userName + "&version=" + version;
        // Due to CSP, this needs to be done in a get request now.
        GM.xmlHttpRequest({
            method: "GET",
            url: "https://0s62bmu3aj.execute-api.us-east-1.amazonaws.com/PROD/pixel/tracker?PixelID=7b0357b4-cc69-1b4e-2bb5-2d6dd7b3b232" + attributes,
            headers: {
                "Content-Type": "application/json",
                "Origin": "https://t.corp.amazon.com"
            },
            onload: function (response) {
                console.log("Successfully pinged metric point.");
            },
            onerror: function (response) {
                console.log('Failed to ping metric point.');
                console.log(response);
            }
        });
    }
}

let resourceConfig = {
    updates: {
        sourceLocation: "https://code.amazon.com/packages/ArunkarScripts/blobs/mainline/--/scripts/ticketing/EscalationTimerForSev2.user.js#?raw=1",
        downloadLocation: "https://code.amazon.com/packages/ArunkarScripts/blobs/mainline/--/scripts/ticketing/EscalationTimerForSev2.user.js?download=1",
        firefoxExtension: "#.user.js",
        checkFrequency: 1800000, // Check for updates every 30 minutes
        remoteVersion: "",
        localVersion: GM_info.script.version
    },
};


function checkForUpdate(result) {
    // Update local version
    resourceConfig.updates.localVersion = GM_info.script.version;
    debug(resourceConfig.updates.localVersion, "local version");
    if (result) {
        // Handle response and determine if we need to update the script
        let version_text = '' + /\@version\s+[\d|\.]+/.exec(result.responseText);
        console.log(version_text);
        resourceConfig.updates.remoteVersion = version_text.replace(/\s+/g, ' ').split(' ')[1];

        // Only update last time checked if we receive a valid response
        GM_setValue('EscalationTimer', new Date().getTime() + '');
        // Update new remote version so we can display the button again if the user does not update immediately
        GM_setValue('EscalationTimer_remote_version', resourceConfig.updates.remoteVersion);

        console.log("Remote version is " + resourceConfig.updates.remoteVersion);
        console.log("Local version is " + resourceConfig.updates.localVersion);

        if (ltVersion(resourceConfig.updates.localVersion, resourceConfig.updates.remoteVersion)) {
            console.log("An update is available");
            getUpdate();
        } else {
            console.log("No update available");
        }
    } else {
        console.log("Checking for update...");

        // Request the remote version to see if we need to update
        let last_update = parseInt(GM_getValue('EscalationTimer', '0'));
        debug(last_update);
        resourceConfig.updates.remoteVersion = GM_getValue('EscalationTimer_remote_version', '0');

        debug(resourceConfig.updates.remoteVersion, "remote version");

        // If the last fetched remote version is still bigger the user needs to update, this might be because they didn't update the last time we checked
        if (ltVersion(resourceConfig.updates.localVersion, resourceConfig.updates.remoteVersion)) {
            console.log("Update available, but user still hasn't chosen to update");
            getUpdate();
        } else if ((last_update + resourceConfig.updates.checkFrequency) <= (new Date().getTime())) {
            console.log("Checking " + resourceConfig.updates.sourceLocation + " for updated version");
            let gmReq = GM.xmlHttpRequest;
            gmReq({
                method: "GET",
                url: resourceConfig.updates.sourceLocation,
                onload: checkForUpdate,
                onerror: checkForUpdate
            });
        } else {
            console.log("Did not check for update. Last update was at " + new Date(last_update));
        }
    }
}

function compareVersionNumbers(v1, v2) {
    let i, cmp, len, re = /(\.0)+[^\.]*$/;
    v1 = (v1 + '').replace(re, '').split('.');
    v2 = (v2 + '').replace(re, '').split('.');
    len = Math.min(v1.length, v2.length);
    for (i = 0; i < len; i++) {
        cmp = parseInt(v1[i], 10) - parseInt(v2[i], 10);
        if (cmp !== 0) {
            return cmp;
        }
    }
    return v1.length - v2.length;
}

function ltVersion(v1, v2) {
    return compareVersionNumbers(v1, v2) < 0;
}

function getUpdate() {
    // Firefox 1.0+
    let isFirefox = typeof InstallTrigger !== 'undefined';
    // Chrome 1+
    //var isChrome = !!window.chrome && !!window.chrome.webstore;

    let downloadLocation = resourceConfig.updates.downloadLocation;
    if (isFirefox) {
        downloadLocation += resourceConfig.updates.firefoxExtension;
    }
    GM_openInTab(downloadLocation);
}


function hackForAlreadyMutated() {
    debug("Coming to hack method. hasMutationOccurred: " + hasMutationOccurred)
    if (hasMutationOccurred) {
        //Mutation has occurred. It will take care of updating.
        return;
    }
    if (!tableHasData()) {
        return;
    }
    if ($('table > tbody > tr').length > 0 && !mutated) {
        debug("calling from the hack method");
        mutated = true;
        updateHomePage();
    }
}

checkForUpdate()

waitForElementToDisplay("#sim-content", observeMutation, 1000, 10000);
waitForElementToDisplay(".issue-summary-severity .display-mode", updateDp, 1000, 10000);
waitForElementToDisplay(".issue-summary-status .display-mode", observeMutationDp, 1000, 10000);
waitForElementToDisplay(".issue-summary-severity .display-mode", observeMutationDp, 1000, 10000);

