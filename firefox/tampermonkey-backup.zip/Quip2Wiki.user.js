// ==UserScript==
// @name         Quip2Wiki
// @namespace    com.amazon.corp.quip2wiki
// @website      https://w.amazon.com/bin/view/Quip2Wiki
// @downloadURL  https://w.amazon.com/rest/wikis/xwiki/spaces/Quip2Wiki/spaces/Releases/pages/WebHome/attachments/Quip2Wiki.user.js
// @updateURL    https://w.amazon.com/rest/wikis/xwiki/spaces/Quip2Wiki/spaces/Releases/pages/WebHome/attachments/Quip2Wiki.user.js
// @version      1.29.11
// @description  TamperMonkey script for exporting Quip documents to Amazon Wiki
// @author       Jorge Miguel Ribeiro (jorgemrb@amazon.com)
// @match        https://quip-amazon.com/*
// @match        https://*.quip-amazon.com/*
// @match        https://*.quip-amazon-elements.com/*
// @match        https://w.amazon.com/bin/view/*
// @match        https://w.amazon.com/bin/viewrev/*
// @match        https://w.amazon.com/index.php/*
// @connect      quip-amazon.com
// @connect      platform.quip-amazon.com
// @connect      w.amazon.com
// @connect      maxis-service-prod-iad.amazon.com
// @connect      idp-us-west-2.federate.amazon.com
// @connect      idp.federate.amazon.com
// @connect      kerberizer-prod.corp.amazon.com
// @connect      w-main.corp.amazon.com
// @connect      midway-auth.amazon.com
// @connect      axzile.corp.amazon.com
// @connect      drive.corp.amazon.com
// @connect      drive-render.corp.amazon.com
// @connect      drive-webdav.corp.amazon.com
// @connect      phonetool.amazon.com
// @connect      aea.aka.amazon.com
// @connect      0s62bmu3aj.execute-api.us-east-1.amazonaws.com
// @connect      document-versions-production.s3.us-west-2.amazonaws.com
// @connect      cloudfront.net
// @require      https://m.media-amazon.com/images/I/6122cXQRH3L.js#ver=jquery-3.6.0.min.js
// @require      https://m.media-amazon.com/images/I/71nb5TqP9pL.js#ver=jquery-ui-1.12.1.min.js
// @resource     jquery-ui-css https://m.media-amazon.com/images/I/41AE8Qt0umL.css#ver=jquery-ui-1.12.1.min.css
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_xmlhttpRequest
// @grant        GM.xmlHttpRequest
// @grant        GM_openInTab
// @grant        GM_addStyle
// @grant        GM_getResourceText
// @grant        GM_registerMenuCommand
// @grant        unsafeWindow
// ==/UserScript==

/** FORCE_UPDATE = false */

/**
 * Releases:
 * 1.29.11 - Sanitize XHTML in bullet points.
 * 1.29.10 - Fixed filter to remove unselected sheet ids in --wiki-sheets--.
 * 1.29.9 - Update param for disabling Miki redirect for Quip calls.
 * 1.29.8 - Disable Miki redirect for Quip calls.
 * 1.29.7 - Added progress bar to folder export.
 * 1.29.6 - Added a filter to remove empty sheet titles from the list of sheets to export.
 * 1.29.5 - Improved the token update modal to warn the user when they have not changed the token. Improved the missing permission error message so it has a link to the wiki permissions page. Added detection for when a user needs to "join" a document to be able to export it. Added a better error message when a domain is blocked.
 * 1.29.4 - Recreated the XHTML exporting tab feature to be easier to reason about.
 * 1.29.3 - Fixed another failure mode for exporting tabs in the wrong order. Improved handling of errors when checking token validity.
 * 1.29.2 - Errors 400 and 429 in the Quip API when checking token validity now triggers the modal to update the token. Added custom delay strategy when the Quip API doesn't return rate-limit headers.
 * 1.29.1 - Allowed redirects from w.amazon.com to the new w-main.corp.amazon.com domain to happen without errors.
 * 1.29.0 - Recursive folder export feature released (thanks rowskib@!). Improved the Quip token check flow to ask the user for a new token when it doesn't exist or when it has become invalid. Added a fallback to get the base position for the export button.
 * 1.28.5 - Added an easier way to replace the Quip API token (click on the cog icon -> Update Quip Token)
 * 1.28.4 - Added the w-main.corp.amazon.com to the domains allowed for use by Quip2Wiki
 * 1.28.3 - Fixed folder conversion, which had been broken in the beta since the TS conversion. Also fixed some error messages that were being lost, and improved transitive token handling.
 * 1.28.2 - Fixed an issue which caused some incomplete content to be exported to the wiki, causing error: 'Failed to render content' when accessing the wiki page. Added clearer messages when the user doesn't have permission to change the page and when the file size is too big.
 * 1.28.1 - Added a way to globally change the link targets in the content exported (tag wiki-link-target, thanks portelaa@!). Fixed an issue introduced after refactoring when checking the Quip API token validity.
 * 1.28.0 - Fixed an issue when downloading Quip attachments with a transitive authorization token. Removed a no-longer necessary sleep call. Improved the attachment naming strategy: now we remove non-alphanumeric chars and remove the middle of the string if it is too big. Quip API token is now sanitized when downloading logs.
 * 1.27.9 - Fixed an issue that happened when trying to show the export button when it was already visible but its anchor was not visible. Improved several logging messages and API throttling strategies.
 * 1.27.8 - Fixed an error where some sheet tabs had their names and contents mixed up
 * 1.27.7 - Fixed an error when downloading attachments, which caused the fetch API to be used instead of the Tampermonkey API.
 * 1.27.6 - Added the possibility of recording network events to submit for evidence for tickets.
 * 1.27.5 - Fixed XWiki conversion code that had been broken during the conversion to Typescript. Various small fixes in the custom logger rendering, as well as improvements to the XWiki conversion code.
 * 1.27.4 - Improved empty column handling when exporting spreadsheets
 * 1.27.3 - Added "Download logs" button and Tampermonkey action. Improved error handling when downloading attachments from the Quip API.
 * 1.27.2 - Most of the code was refactored to TS.
 * 1.27.1 - Added throttling of 500ms to the pageObserver (prevents infinite loops in some edge cases in Firefox). Added escape for chars `<` and `>` in the XWiki format.
 * 1.27.0 - Quip2Wiki code has moved to a TS compiler + webpack as the bundler.
 * 1.26.5 - Improved logger and added a in-page log visualizer. Added ability to copy improved log to clipboard or download it to a file.
 * 1.26.4 - Added version information to dialog title bars. Improved performance of toolbar creation and removed no longer necessary retries.
 * 1.26.3 - Improved creation and placement of the export button. Fixed close button in dialog modals, improved resize handling and removed delay to adding the export button. Replaced resource URLs with their corresponding asset freeze URLs
 * 1.26.2 - Fixed "email is undefined" error (thanks huijbers@!). Added workaround for export button not showing in certain documents and spreadsheets.
 * 1.26.1 - Added workaround for space-like chars that are not supported by the Amazon wiki. Thanks xuyuhui@!
 * 1.26.0 - Added error extraction for errors that happen in the wiki. This should show the actual error cause more frequently. Also highlights any unusual chars that may not be supported by the wiki.
 * 1.25.6 - Added workaround to "too much recursion" error when processing "--wiki-ignore--" tags. Not a complete solution, since the complete solution will require refactoring the XHtmlConverter completely to use a DOMParser.
 * 1.25.5 - Fix duplicated HTML content when a column is completely encapsulated in a code block.
 * 1.25.4 - Added an easier way to add a tracker pixel to the exported wiki page. Removed unused toolbox related functions. Removed all uses of the Kerberos service.
 * 1.25.3 - Fix transient error calling the registerQuipUserApiError function. Fixed small bugs with the new option tag.
 * 1.25.2 - Added image size override option. This is useful when putting images inside table cells, to control their size.
 * 1.25.1 - Improved the update behavior with the new authentication error handling - now we only try to update after an export process (whether it succeeded or not)
 * 1.25.0 - Improved authentication error handling. Now when an authentication error happens, we ask the user to click a link to authenticate in the specific website and then continue the exporting process.
 * 1.24.8 - Added better support for Safari
 * 1.24.7 - Handle tilde '~' characters correctly when the syntax is XWiki
 * 1.24.6 - Improve image centering with the tag '--wiki-options:"fixImageCentering"--'
 * 1.24.5 - Fix "RangeError: invalid date" that happened in some cases.
 * 1.24.4 - Fix possible "Too much recursion" error in Regex. Fixed alt update endpoints.
 * 1.24.3 - Fix edge-case of video blob IDs which break wiki rendering
 * 1.24.2 - Reduce max attachment size to a little bit under 1.9MB (new limit from the wiki since around 2023-07-27). Update prod and beta update endpoints and increased update request timeout (from tests the scripts usually take more than 5 seconds to load)
 * 1.24.1 - Fix invalid XHTML in some cases when aligning images in lists. (beta)
 * 1.24.0 - Improve the conversion of Quip mentions to Phonetool mentions, with a LRU local data cache. Fixed handling attachments with URI-encodable characters in their name. Updated trackers and added trackers to the Quip User API. (beta)
 * 1.23.15 - Add option to fix image centering in some wiki styles (by adding the tag '--wiki-options:"fixImageCentering"--')
 * 1.23.14 - Fix folder export
 * 1.23.13 - Fix image upload
 * 1.23.12 - Retrieve username from midway instead of kerberos, which makes it compatible with AEA / Unfabric
 * 1.23.11 - fix DI inspector issue, prompt for large file attachments, minor bug fixes
 * 1.23.10 - switch to internal CDN, allow dialog close button, fix attachments file ext
 * 1.23.9 - fix minor bugs
 * 1.23.8 - fix tab order, xwiki spreadsheet with tabs, move to how-many metrics
 * 1.23.7 - fix tag change, sort folder index, remove daily ping
 * 1.23.6 - improve recovery from backup, make videos embedded
 * 1.23.5 - fix adding wiki-sync tag on doc, support for di-inspector
 * 1.23.2 - fix api token storage, xwiki styling, and other fixes
 * 1.23.0 - fix folder index export, comments with unescaped chars, math formulas, list continuation, added support to XWiki syntax via --wiki-syntax-- tag (experimental)
 * 1.22.8 - Fix wiki API endpoint
 * 1.22.7 - Fix image url attachment regex (Q2W-146)
 * 1.22.5/1.22.6 - fix issue with JSON parsing (Q2W-135) and table regex matching
 * 1.22.4 - fix issue with new Drive's webdav endpoints (Q2W-114)
 * 1.22.3 - disable change monitor which was causing Quip backend to throttle API calls (Q2W-110)
 * 1.22.2 - fix empty export, change monitor, quip rate limiter, multiple header/footer, adds wiki-banner, classic toc, syntax fixes
 * 1.22.1 - replaceAll bug fix (Q2W-64)
 * 1.22.0 - adds --wiki-comments-- tag for exporting comments, reduce table output size
 * 1.21.0/1.21.1/1.21.2/1.21.3 - adds --wiki-sheets-- and --wiki-sortable-tables-- tags, fix image and code blocks in lists, change default user space, connection check improvements, add multi-column support
 * 1.20.0/1.20.1 - better dialogs/messages, retry logic, sheets as tabs, better network check, Maxis API over Phonetool API (no Midway required).
 * 1.19.2/1.19.3 - adds --wiki-tracker-- tag (beta), --wiki-toc-- customizations (beta), mentions as link to Phonetool, bug fixes
 * 1.19.0/1.19.1 - adds --wiki-header-- tag, improves macros, and minor fixes
 * 1.18.0 - fix embedded videos, stats helpers at console
 * 1.17/1.17.1/1.17.2 (beta) - adds --wiki-toc-- tag and minor fixes
 * 1.16/1.16.1 (beta) - file/image upload as attachments, image layout, and log dump telemetry
 * 1.14/1.14.1/1.15/1.15.1 (beta) - fix anchors and table improvements (header, styling, remove empty cols/rows)
 * 1.12/1.13 (beta) - adds telemetry and bug fixes
 * 1.11 (beta) - bug fixes and improved folder export experience
 * 1.10 (beta) - improved banner, better folder index appearance, hide banner from print
 * 1.9 (beta) - added support for exporting folder indexes and *wiki-macro* tag (soon)
 * 1.8 (beta) - transition from code.amazon.com (http://code.amazon.com/) to drive.corp.amazon.com (http://drive.corp.amazon.com/) download source
 * 1.7 (beta) - transition from jsbin to code.amazon.com (http://code.amazon.com/)
 * 1.6 (beta) - fixed issues with monospace text, bullet/numbered lists, tag removal
 * 1.5 (beta) - embed images as URI data in base64
 * 1.4 (preview) - first version available
 */

'use strict';

class StructuredLog {
    constructor(id, timestamp, level, location, locationStackTrace, args) {
        this.id = id;
        this.timestamp = timestamp;
        this.level = level;
        this.location = location;
        this.locationStackTrace = locationStackTrace;
        this.args = args;
    }
}
class CustomLogger {
    constructor(c) {
        this.logEntries = [];
        this.logCallbacks = [];
        this.clearCallbacks = [];
        if (c === undefined) {
            this.console = console;
        }
        else {
            this.console = c;
        }
        this.startTime = new Date();
    }
    getStartTime() {
        return this.startTime;
    }
    getStackTraceEntriesToIgnore() {
        return 2;
    }
    log(...args) {
        this.console.log(...args);
        this.saveLogEntry("INFO", ...args);
    }
    trace(...args) {
        this.console.trace(...args);
        this.saveLogEntry("TRACE", ...args);
    }
    debug(...args) {
        this.console.debug(...args);
        this.saveLogEntry("DEBUG", ...args);
    }
    _debugRaw(...args) {
        this.console.debug(...args);
    }
    info(...args) {
        this.console.info(...args);
        this.saveLogEntry("INFO", ...args);
    }
    warn(...args) {
        this.console.warn(...args);
        this.saveLogEntry("WARN", ...args);
    }
    error(...args) {
        this.console.error(...args);
        this.saveLogEntry("ERROR", ...args);
    }
    getLogEntries() {
        return this.logEntries; // TODO: return copy?
    }
    addLogCallback(callback) {
        this.logCallbacks.push(callback);
    }
    getNextCallbackIndex() {
        return this.logCallbacks.length + 1;
    }
    clear() {
        this.logEntries = [];
        this.console.clear();
        for (let i = 0; i < this.clearCallbacks.length; i++) {
            const callback = this.clearCallbacks[i];
            callback(i + 1);
        }
    }
    addClearCallback(callback) {
        this.clearCallbacks.push(callback);
    }
    saveLogEntry(level, ...args) {
        const id = `q2w-log-${this.logEntries.length + 1}`;
        const timestamp = new Date();
        let location = "[undefined]";
        if (args.length > 1 && typeof args[0] === "string") {
            const possibleLocation = args[0];
            if (possibleLocation.startsWith("[") && possibleLocation.endsWith("]")) {
                args = args.slice(1);
                location = possibleLocation;
            }
        }
        const locationStackTrace = Error();
        const entry = new StructuredLog(id, timestamp, level, location, locationStackTrace, args);
        this.logEntries.push(entry);
        this.invokeCallbacks(entry);
    }
    invokeCallbacks(entry) {
        for (let i = 0; i < this.logCallbacks.length; i++) {
            const callback = this.logCallbacks[i];
            callback(entry, i + 1, true);
        }
    }
}
function convertMilissecondsToMinutesSeconds(milliseconds) {
    const millis = (milliseconds % 1000).toString();
    const totalSeconds = Math.floor(milliseconds / 1000);
    const seconds = (totalSeconds % 60).toString();
    const minutes = (Math.floor(totalSeconds / 60)).toString();
    return `${minutes.padStart(2, "0")}:${seconds.padStart(2, "0")}.${millis.padStart(3, "0")}`;
}
const logger = new CustomLogger();

/**
 * Regex pattern that matches all wiki url, including view/edit pages and different viewers and sections.
 *
 * The regex should match all the following links:
 *
 * https://w.amazon.com/index.php/Quip2Wiki
 * https://w.amazon.com/index.php/Quip2Wiki/Test
 *
 * https://w.amazon.com/index.php/Quip2Wiki/
 * https://w.amazon.com/index.php/Quip2Wiki/Test/
 *
 * https://w.amazon.com/bin/view/Quip2Wiki/
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/#Comments
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/#Attachments
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/#History
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/#Information
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/#HSomesectioninwikipage
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/WebHome/#HSomesectioninwikipage
 *
 * https://w.amazon.com/bin/view/Quip2Wiki
 * https://w.amazon.com/bin/view/Quip2Wiki/Test
 * https://w.amazon.com/bin/view/Quip2Wiki#Comments
 * https://w.amazon.com/bin/view/Quip2Wiki#Attachments
 * https://w.amazon.com/bin/view/Quip2Wiki#History
 * https://w.amazon.com/bin/view/Quip2Wiki#Information
 * https://w.amazon.com/bin/view/Quip2Wiki/Test#HSomesectioninwikipage
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/WebHome#HSomesectioninwikipage
 *
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/?viewer=comments
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/?viewer=attachments
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/?viewer=history
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/?viewer=information
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/?viewer=children
 * https://w.amazon.com/bin/view/Quip2Wiki/Test/?viewer=code
 *
 * https://w.amazon.com/bin/view/Quip2Wiki/Test?viewer=comments
 * https://w.amazon.com/bin/view/Quip2Wiki/Test?viewer=attachments
 * https://w.amazon.com/bin/view/Quip2Wiki/Test?viewer=history
 * https://w.amazon.com/bin/view/Quip2Wiki/Test?viewer=information
 * https://w.amazon.com/bin/view/Quip2Wiki/Test?viewer=children
 * https://w.amazon.com/bin/view/Quip2Wiki/Test?viewer=code
 *
 * https://w.amazon.com/bin/edit/Quip2Wiki/Test/WebHome/
 * https://w.amazon.com/bin/edit/Quip2Wiki/Test/WebHome/?editor=wysiwyg
 * https://w.amazon.com/bin/edit/Quip2Wiki/Test/WebHome/?editor=wiki
 *
 * https://w.amazon.com/bin/edit/Quip2Wiki/Test/WebHome
 * https://w.amazon.com/bin/edit/Quip2Wiki/Test/WebHome?editor=wysiwyg
 * https://w.amazon.com/bin/edit/Quip2Wiki/Test/WebHome?editor=wiki
 *
 * https://w.amazon.com/bin/preview/Quip2Wiki/Test/WebHome/
 * https://w.amazon.com/bin/preview/Quip2Wiki/Test/WebHome
 *
 * https://w.amazon.com/bin/viewrev/Quip2Wiki/Test/WebHome/?rev=10.1
 * https://w.amazon.com/bin/viewrev/Quip2Wiki/Test/WebHome/?viewer=code&rev=10.1
 *
 * https://w.amazon.com/bin/viewrev/Quip2Wiki/Test/WebHome?rev=10.1
 * https://w.amazon.com/bin/viewrev/Quip2Wiki/Test/WebHome?viewer=code&rev=10.1
 *
 */
const WIKI_URL_PAGE_REGEX = /https:\/\/w\.amazon\.com\/(?:index\.php|bin\/(view|viewrev|edit|preview))\/([^#?\s]+[^/#?\s])(?:\/WebHome|\/)?(#[^#?\s]*)?(?:\?(&?(?:editor|viewer|rev)=.*)*)?/;
const WIKI_URL_PARAMS_REGEX = /&?(?:editor=(wiki|wysiwyg)|viewer=(comments|attachments|history|information|children|code)|rev=(\d+\.\d+))/g;
const DISABLED_EDIT_BUTTON_TOOLTIP = 'The Wiki editor is disabled because the content was generated from a Quip document. To edit in Wiki, use the Tools menu (not recommended)';
const EDIT_IN_QUIP_BUTTON_TOOLTIP = 'Edit in Quip as the content of this page was generated from a Quip document. To edit in Wiki, use the Tools menu (not recommended)';
const EDIT_IN_QUIP_BUTTON_ICON = '/bin/download/Favicons/WebHome/quip.png';
async function hasQuip2WikiTag(wikiClient) {
    try {
        const urlInfo = getWikiUrlInfo();
        if (!urlInfo)
            return false;
        const page = urlInfo.page;
        const viewer = urlInfo.viewer;
        const isView = (page == 'view' || page === 'viewrev') && !viewer;
        if (isView) {
            return [...document.querySelectorAll('#xdocTags > span.tag-wrapper > span.tag > a')]
                .map(a => a.innerText)
                .some(tagName => tagName === 'Quip2Wiki');
        }
        else {
            return (await wikiClient.getTags(urlInfo.addr)).includes('Quip2Wiki');
        }
    }
    catch (e) {
        logger.warn("[src/amzn/WikiEditor.ts:88:9]", `Unexpected exception while checking if Quip2Wiki tag exists: ${e}`);
        return false;
    }
}
async function getOriginalDocUrl() {
    try {
        const urlInfo = getWikiUrlInfo();
        if (!urlInfo)
            return null;
        const isSourceViewer = urlInfo.viewer === 'code';
        let quipUrl;
        if (isSourceViewer) {
            const codeElement = document.querySelector('textarea.wiki-code');
            const pageSourceCode = codeElement ? (codeElement.textContent || '') : '';
            const match = pageSourceCode.match(/<(div|p) [^<>]*class=["']hidden-print["'][^<>]*>[\s\S]*?<a href="(https:\/\/quip-amazon.com\/[\w-_]{11,12})">See original<\/a>[\s\S]*?<\/\1>/) ||
                pageSourceCode.match(/\(% class=["']hidden-print["'] %\)\(\(\([\s\S]*?\[\[See original>>(https:\/\/quip-amazon.com\/[\w-_]{11,12})\]\][\s\S]*?\)\)\)/);
            quipUrl = match && match[2] ? match[2] : null;
        }
        else {
            quipUrl = [...document.querySelectorAll('p.hidden-print *, div.hidden-print *, span.hidden-print *')]
                .filter((element) => element.tagName === 'A')
                .map(a => a.href)
                .find(url => url.startsWith('https://quip-amazon.com'));
        }
        logger.debug("[src/amzn/WikiEditor.ts:114:9]", `Original quip doc URL: ${quipUrl || 'not found'}`);
        return quipUrl;
    }
    catch (e) {
        logger.warn("[src/amzn/WikiEditor.ts:117:9]", `Unexpected exception while getting original doc URL: ${e}`);
        return null;
    }
}
function disableButton(id) {
    const buttonSpan = document.querySelector(`#contentmenu > #${id}`);
    const buttonLink = document.querySelector(`#contentmenu > #${id} > a.btn`);
    if (!buttonSpan)
        return;
    if (!buttonLink)
        return;
    buttonSpan.setAttribute('data-toggle', 'tooltip');
    buttonSpan.setAttribute('data-original-title', DISABLED_EDIT_BUTTON_TOOLTIP);
    buttonSpan.removeAttribute('data-title');
    buttonLink.classList.toggle('disabled', true);
    buttonLink.setAttribute('title', DISABLED_EDIT_BUTTON_TOOLTIP);
}
function changeButton(id, linkUrl, name, iconUrl, tooltip) {
    const buttonSpan = document.querySelector(`#contentmenu > #${id}`);
    const buttonLink = document.querySelector(`#contentmenu > #${id} > a.btn`);
    if (!buttonSpan)
        return;
    if (!buttonLink)
        return;
    // enable link
    buttonLink.classList.toggle('disabled', false);
    // set link
    if (linkUrl)
        buttonLink.href = linkUrl;
    // set name
    const label = buttonLink.querySelector('span:nth-child(2)');
    if (label == null)
        return;
    label.textContent = name;
    // set icon
    const icon = buttonLink.querySelector('span:nth-child(1)');
    if (icon && iconUrl) {
        const img = document.createElement('img');
        img.src = iconUrl;
        img.style.width = '12px';
        img.style.marginRight = '4px';
        buttonLink.removeChild(icon);
        buttonLink.insertBefore(img, label);
    }
    const tooltipValue = tooltip;
    // set title
    buttonLink.setAttribute('title', tooltipValue);
    // set tooltip
    buttonSpan.setAttribute('data-toggle', 'tooltip');
    buttonSpan.setAttribute('data-original-title', tooltipValue);
    buttonSpan.removeAttribute('data-title');
}
function copyButtonAsToolsMenu(id) {
    const buttonSpan = document.querySelector(`#contentmenu > #${id}`);
    const buttonLink = document.querySelector(`#contentmenu > #${id} > a.btn`);
    if (!buttonSpan)
        return;
    if (!buttonLink)
        return;
    const isDisabled = buttonLink.classList.contains('disabled');
    const menuItem = document.createElement('li');
    menuItem.id = id + '-menu';
    menuItem.classList.toggle('disabled', isDisabled);
    const menuLink = document.createElement('a');
    menuLink.href = buttonLink.href;
    menuLink.target = '_blank';
    menuLink.title = isDisabled ? (buttonSpan.getAttribute('data-title') || "") : buttonLink.innerText;
    const glyphSel = buttonLink.querySelector('span.glyphicon, span.fa');
    const glyph = glyphSel ? glyphSel.cloneNode() : null;
    const label = document.createElement('span');
    label.innerText = buttonLink.innerText;
    if (glyph)
        menuLink.appendChild(glyph);
    menuLink.appendChild(label);
    menuItem.appendChild(menuLink);
    return menuItem;
}
async function blockEdit(wikiClient) {
    // check if valid wiki page
    const urlInfo = getWikiUrlInfo();
    if (!urlInfo) {
        return;
    }
    // there are only 3 wiki pages in which we can change edit buttons:
    // - view: no viewer or viewer=code
    // - viewrev: no viewer or viewers=code (only latest revision)
    const page = urlInfo.page;
    const viewer = urlInfo.viewer;
    const pageHasButtons = (page === 'view' || page === 'viewrev') && (!viewer || viewer === 'code');
    if (!pageHasButtons) {
        return;
    }
    // check if page is generated by Quip2Wiki
    const isGeneratedByQuip2Wiki = await hasQuip2WikiTag(wikiClient);
    if (!isGeneratedByQuip2Wiki) {
        return;
    }
    // find tools menu
    const toolsMenu = document.querySelector('#contentmenu > #tmMoreActions > ul.dropdown-menu');
    if (!toolsMenu)
        return;
    if (!toolsMenu.children)
        return;
    const firstMenu = toolsMenu.children[0];
    // copy of edit and edit-source buttons as tools menu
    const editMenu = copyButtonAsToolsMenu('tmEdit');
    if (editMenu) {
        toolsMenu.insertBefore(editMenu, firstMenu);
    }
    const editSourceMenu = copyButtonAsToolsMenu('tmEditWiki');
    if (editSourceMenu) {
        toolsMenu.insertBefore(editSourceMenu, firstMenu);
    }
    // create separator
    if (editMenu || editSourceMenu) {
        const separator = document.createElement('li');
        separator.classList.add('divider');
        separator.setAttribute('role', 'separator');
        toolsMenu.insertBefore(separator, firstMenu);
    }
    // disable edit-source button
    disableButton('tmEditWiki');
    // change edit button to edit in Quip
    const quipUrl = await getOriginalDocUrl();
    if (quipUrl) {
        changeButton('tmEdit', quipUrl, 'Edit in Quip', EDIT_IN_QUIP_BUTTON_ICON, EDIT_IN_QUIP_BUTTON_TOOLTIP);
    }
    else {
        disableButton('tmEdit');
    }
    // run script to update tooltips
    // the below code was extracted from a <script> tag: document.querySelector('#contentmenu > script')
    // the reason we are pasting the code is that the tag may not be added to page
    eval(`
        require(['jquery', 'jquery-ui', 'bootstrap'], function ($) {
            $(document).ready(function () {
                $('[data-toggle="tooltip"]').tooltip();
            });
        });`);
}
function getWikiUrlInfo() {
    const match = window.location.href.match(WIKI_URL_PAGE_REGEX);
    if (!match) {
        return null;
    }
    const page = match[1] || 'view'; // if missing we have 'index.php' which is a 'view'
    const addr = match[2].replace('/WebHome', '');
    const section = match[3] || '';
    const parameters = match[4] || '';
    const regex = WIKI_URL_PARAMS_REGEX;
    let pmatch = regex.exec(parameters);
    let editor = '';
    let viewer = '';
    let revision = '';
    while (pmatch) {
        editor = pmatch[1] || editor;
        viewer = pmatch[2] || viewer;
        revision = pmatch[3] || revision;
        pmatch = regex.exec(parameters);
    }
    return {
        page: page,
        addr: addr,
        section: section,
        editor: editor,
        viewer: viewer,
        revision: revision
    };
}
function isWikiPage() {
    return window.location.href.startsWith('https://w.amazon.com/');
}

/**
 * Helper methods.
 */
class UtilsImpl {
    /**
     * Check if two arrays are equal (same content), regardless of the order.
     * @param {Array} _arr1
     * @param {Array} _arr2
     */
    arraysEqual(_arr1, _arr2) {
        if (!Array.isArray(_arr1) || !Array.isArray(_arr2) || _arr1.length !== _arr2.length) {
            return false;
        }
        const arr1 = _arr1.concat().sort();
        const arr2 = _arr2.concat().sort();
        for (let i = 0; i < arr1.length; i++) {
            if (arr1[i] !== arr2[i]) {
                return false;
            }
        }
        return true;
    }
    arraysEqualSameOrder(arr1, arr2) {
        return Array.isArray(arr1) &&
            Array.isArray(arr2) &&
            arr1.length === arr2.length &&
            arr1.every((val, index) => val === arr2[index]);
    }
    /**
     * Recursively finds a parent of a given element that contains the given attribute. When attributeValue is null, will match if attribute exists.
     * Returns null if no parent is found.
     *
     * @param {*} element the base element
     * @param {string} attributeName the attribute name to match
     * @param {*} attributeValue (optional) the attribute value to match
     */
    getAncestorWithAttribute(element, attributeName, attributeValue = null) {
        let node = element.parentNode;
        while (node) {
            if (node.hasAttribute(attributeName) && (!attributeValue || node.getAttribute(attributeName) === attributeValue)) {
                return node;
            }
            node = node.parentNode;
        }
        return null;
    }
    // ignore coverage
    async sleep(milliseconds) {
        await new Promise(resolve => setTimeout(resolve, milliseconds));
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async replaceAsyncSequence(str, regex, asyncFn) {
        const promises = [];
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        str.replace(regex, (match, ...args) => {
            promises.push(asyncFn(match, ...args));
            return match;
        });
        const data = await Promise.all(promises);
        return str.replace(regex, () => data.shift() || '');
    }
    /**
     * Tests if a certain regex pattern matches in given string. Given regex can have state,
     * this method makes sure previous state is cleared.
     */
    test(regex, text) {
        regex.lastIndex = 0;
        return regex.test(text);
    }
}
const Utils = new UtilsImpl();

const SUMMARIES_TO_IGNORE = [
    'Added tag',
    'Removed tag',
    'Added comment',
    'Edited comment',
    'Deleted object',
    'Added annotation on',
    'Updated annotations',
    'Deleted annotation',
];
/**
 * This is magic number to indicate page was just created, but failed first update for some reason.
 */
const PAGE_CREATED_TIMESTAMP = 1;
/**
 * Basic operations associated to for extracting information from a XML document obtained from WikiClient.
 */
class WikiClientHelper {
    static getLastUpdated(wikiXml) {
        const historyEntries = wikiXml.getElementsByTagName('comment');
        for (const item of historyEntries) {
            const wikiComment = item.innerHTML;
            const isSummaryToIgnore = (summary) => wikiComment.includes(summary);
            if (SUMMARIES_TO_IGNORE.some(isSummaryToIgnore)) {
                continue;
            }
            if (wikiComment.includes('Created with Quip2Wiki')) {
                return PAGE_CREATED_TIMESTAMP;
            }
            const commentMatch = wikiComment.match(/\(timestamp=(.*?)\)/);
            if (commentMatch && commentMatch[1]) {
                return parseInt(commentMatch[1]);
            }
            else {
                return null;
            }
        }
        return null;
    }
    static getAttchments(wikiXml) {
        const output = new Map();
        const items = wikiXml.getElementsByTagName('attachment');
        for (const item of items) {
            const name = item.getElementsByTagName('name')[0].textContent;
            const links = item.getElementsByTagName('link');
            let url = '';
            for (const link of links) {
                if (link.getAttribute('rel') == 'http://www.xwiki.org/rel/attachmentData') {
                    url = link.getAttribute('href');
                    break;
                }
            }
            output.set(name, url);
        }
        return output;
    }
    static getSearchResult(wikiXml) {
        const output = [];
        const resultEntries = wikiXml.getElementsByTagName('searchResult');
        for (const item of resultEntries) {
            output.push({
                id: item.getElementsByTagName('id')[0].innerHTML,
                title: item.getElementsByTagName('title')[0].innerHTML,
                type: item.getElementsByTagName('type')[0].innerHTML,
                syntax: item.getElementsByTagName('wiki')[0].innerHTML,
                space: item.getElementsByTagName('space')[0].innerHTML,
            });
        }
        logger.log("[src/client/WikiClientHelper.ts:86:9]", `[wiki-client] search result: found ${output.length} pages`);
        return output;
    }
}

const GIT_HASH = "4efff6d8045a9a17237e7281113e8e3e9a1d6092";
const BUTTON_TEXT = 'Export to Wiki';
const BUTTON_ID = 'export-wiki-button';
const BUTTON_LABEL_ID = 'export-wiki-button-text';
const LABEL_ID = 'export-wiki-label';
const IN_SYNC_FAQ_URL = 'https://tiny.amazon.com/x9wk3li7/DocumentInSyncAfterChanges';
const UPDATE_CHECK_URL = (() => ["https://w.amazon.com/rest/wikis/xwiki/spaces/Quip2Wiki/spaces/Releases/pages/WebHome/attachments/Quip2Wiki.user.js","https://axzile.corp.amazon.com/-/carthamus/download_script/quip2-wiki.user.js"])();
const TICKET_URL = 'https://tiny.amazon.com/13hdclxxy/Quip2WikiCreateIssue';
const QUIP_LINK_REGEX = /https?:\/\/.*quip-amazon.com\/(\w{12})\/?/;
const WIKI_SYNC_VALID_REGEX = /^(?:(?:https?:\/\/)?w\.amazon\.com\/(?:bin\/view|bin\/edit|index\.php)\/|w\?)?([^#?\s]*[^#?\s/])\/?/;
const VIDEO_POSTER = 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPCFET0NUWVBFIHN2ZyBQVUJMSUMgIi0vL1czQy8vRFREIFNWRyAxLjEvL0VOIiAiaHR0cDovL3d3dy53My5vcmcvR3JhcGhpY3MvU1ZHLzEuMS9EVEQvc3ZnMTEuZHRkIj4KPHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHdpZHRoPSIxMDAzcHgiIGhlaWdodD0iNTIzcHgiIHZpZXdCb3g9Ii0wLjUgLTAuNSAxMDAzIDUyMyIgc3R5bGU9ImJhY2tncm91bmQtY29sb3I6IHJnYigyNTUsIDI1NSwgMjU1KTsiPjxkZWZzLz48Zz48cmVjdCB4PSIxLjI1IiB5PSIwLjc1IiB3aWR0aD0iMTAwMCIgaGVpZ2h0PSI1MjAiIGZpbGw9IiNlNmU2ZTYiIHN0cm9rZT0ibm9uZSIgcG9pbnRlci1ldmVudHM9ImFsbCIvPjxlbGxpcHNlIGN4PSI1MDEuMjUiIGN5PSIyNjAuNzUiIHJ4PSIxMjEuMjUiIHJ5PSIxMjEuMjUiIGZpbGw9IiNmZmZmZmYiIHN0cm9rZT0iIzk5OTk5OSIgc3Ryb2tlLXdpZHRoPSI4IiBwb2ludGVyLWV2ZW50cz0iYWxsIi8+PHBhdGggZD0iTSA0NDkuNjEgMTkxLjE0IEwgNTc0LjkgMjYwLjc1IEwgNDQ5LjYxIDMzMC4zNiBaIiBmaWxsPSIjOTk5OTk5IiBzdHJva2U9Im5vbmUiIHBvaW50ZXItZXZlbnRzPSJhbGwiLz48L2c+PC9zdmc+';
const QUIP_URL = 'https://quip-amazon.com';
const TOKEN_PAGE_URL = 'https://quip-amazon.com/dev/token';
/**
 * Determines basic position for placing auto-generated messages.
 */
const BannerPosition = {
    TOP: 0,
    BOTTOM: 1,
    HIDDEN: 2,
    NONE: 3
};
const MIDWAY_REDIRECT_URL = "https://midway-auth.amazon.com/SSO/redirect?";
const ABORTED_BY_USER = "Aborted by user when asking for authentication";
const MAXIS_SERVICE = "MAXIS_SERVICE";
const AXZILE_SERVICE = "AXZILE_SERVICE";
const WIKI_SERVICE = "WIKI_SERVICE";
const SERVICE_NAME_MAPPING = {
    MAXIS_SERVICE: "SIM/Maxis",
    PHONETOOL_SERVICE: "Phonetool",
    AXZILE_SERVICE: "Axzile",
    WIKI_SERVICE: "Amazon Wiki",
};
const SERVICE_URL_MAPPING = {
    MAXIS_SERVICE: "https://issues.amazon.com/issues/Q2W-343",
    PHONETOOL_SERVICE: "https://phonetool.amazon.com/",
    AXZILE_SERVICE: "https://axzile.corp.amazon.com/-/carthamus/script/quip2-wiki",
    WIKI_SERVICE: "https://w.amazon.com/bin/view/Quip2Wiki/AuthenticateWithMidway/",
};
const SERVICE_CANCEL_OPERATION_MAPPING = {
    MAXIS_SERVICE: "Continue without authenticating",
    PHONETOOL_SERVICE: "Continue without authenticating",
    AXZILE_SERVICE: "Abort",
    WIKI_SERVICE: "Abort",
};

class RetryableError extends Error {
}
class RemoteRequestAbortedError extends Error {
}
class RemoteRequestError extends RetryableError {
}
class RawError extends Error {
}
class RemoteRequestTimeoutError extends RetryableError {
}
class RemoteRequestStandardError extends RemoteRequestError {
    constructor(code, message) {
        super(message);
        this.code = code;
    }
}
function isResponseError(response) {
    return 'error' in response;
}
function isTimeoutError(response) {
    if ('error' in response)
        return false;
    if ('finalUrl' in response)
        return false;
    return true;
}
function throwIfStatusIsZero(request, response) {
    if (response.status == 0) {
        const domain = new URL(`${request.url}`).host;
        throw new RawError(`Failed to connect to <b>${domain}</b><br>
Please check:<br>
<b>1.</b> if the domain <i>${domain}</i> can be accessed by the TamperMonkey extension<br>
&nbsp;&nbsp;&nbsp;&nbsp;<b>Instructions for Chrome</b>: Extension icon (puzzle piece) -> 3 dots next to TamperMonkey -> Manage Extension -> Site Access -> On All Sites<br>
<b>2.</b> if the domain <i>${domain}</i> is blacklisted (TamperMonkey dashboard -> Settings -> Security).<br>
&nbsp;&nbsp;&nbsp;&nbsp;<b>IMPORTANT</b>: If the Security section doesn't appear for you, change the config mode (Settings -> General) from Novice to Beginner.<br>
`);
    }
}
const DEFAULT_SUCCESS_CODES = [200, 304];
const DEFAULT_RETRYABLE_CODES = [401, 403, 408, 409, 429, 500, 502, 503, 504];
class RemoteClient {
    constructor(singletons, readTps, writeTps, beforeRetry, serviceName) {
        this.addUserAgent = true;
        this.retries = 2;
        this.waitUntil = null;
        this.lastCallStart = null;
        this.singletons = singletons;
        this.serviceName = serviceName;
        this.readWaitMs = Math.ceil(1000 / readTps);
        this.writeWaitMs = Math.ceil(1000 / writeTps);
        this.beforeRetry = beforeRetry;
    }
    getLastCallStart() {
        // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
        return this.lastCallStart;
    }
    enrichRequestDetails(req, customResponseHandling = {}) {
        const request = req;
        const userAgentHeaders = {
            'User-Agent': 'Quip2Wiki/' + this.singletons.session.version
        };
        if (this.addUserAgent)
            request.headers = request.headers ? { ...request.headers, ...userAgentHeaders } : userAgentHeaders;
        const onLoad = (response) => {
            if (isResponseError(response)) {
                logger.error("[src/client/RemoteClient.ts:114:17]", `Error: status=${response.status}, responseText=${response.responseText}`);
                this.processResponseHeaders(response);
                throw new RemoteRequestError(`Unexpected error "${response.error}" (status code: ${response.status}) for request ${request.method} ${request.url}`);
            }
            throwIfStatusIsZero(request, response);
            if (isTimeoutError(response))
                throw new RemoteRequestTimeoutError(`Request ${request.method} ${request.url} timed-out or aborted`);
            this.processResponseHeaders(response);
            const acceptedResponseStatus = customResponseHandling.acceptedResponseStatus || DEFAULT_SUCCESS_CODES;
            const retryableErrorCodes = customResponseHandling.retryableErrorCodes || DEFAULT_RETRYABLE_CODES;
            if (response.finalUrl != request.url) {
                logger.log("[src/client/RemoteClient.ts:130:17]", `Request ${request.method} ${request.url} redirected to ${response.finalUrl}`);
                if (response.finalUrl.startsWith(MIDWAY_REDIRECT_URL))
                    throw new RetryableError(response.finalUrl);
                if (!acceptedResponseStatus.includes(304))
                    throw new RemoteRequestError(`Unexpected redirect: expected "${req.url}" but got "${response.finalUrl}"`);
            }
            if (!acceptedResponseStatus.includes(response.status)) {
                if (customResponseHandling.customErrorMessages) {
                    const messageBuilder = customResponseHandling.customErrorMessages.get(response.status);
                    if (messageBuilder) {
                        if (retryableErrorCodes.includes(response.status))
                            throw new RetryableError(`Error ${response.status}: ${messageBuilder(response)}`);
                        throw new RemoteRequestStandardError(response.status, messageBuilder(response));
                    }
                }
                throw new RemoteRequestError(`Unexpected error for request ${request.method} ${request.url}: ${response.status} ${response.responseText}`);
            }
            if (request.onload)
                request.onload.call(response, response);
        };
        const enrichedRequest = {
            ...request,
            onload: () => {
            },
            ontimeout: () => {
            },
            onabort: () => {
                throw new RemoteRequestAbortedError(`Request ${request.method} ${request.url} was aborted`);
            },
            onerror: () => {
            },
        };
        return {
            request: enrichedRequest,
            actions: {
                onLoad
            }
        };
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    processResponseHeaders(response) {
    }
    async rawExecute(enrichedRequest) {
        const requestDetails = enrichedRequest.request;
        const startTime = new Date();
        this.lastCallStart = startTime;
        logger.debug("[src/client/RemoteClient.ts:186:9]", `Starting call to ${requestDetails.method} ${requestDetails.url}...`);
        const promise = this.singletons.tampermonkey.asyncXmlHttpRequest(requestDetails);
        let res;
        try {
            res = await promise;
            logger.debug("[src/client/RemoteClient.ts:192:13]", `Call to ${requestDetails.method} ${requestDetails.url} completed (status: ${res.status})`);
        }
        catch (e) {
            logger.log("[src/client/RemoteClient.ts:194:13]", `Call to ${requestDetails.method} ${requestDetails.url} had an error: ${e}`);
            if (e instanceof Error)
                throw e;
            if (isResponseError(e)) {
                const request = enrichedRequest.request;
                const response = e;
                try {
                    this.processResponseHeaders(response);
                }
                catch (e1) {
                    logger.warn("[src/client/RemoteClient.ts:205:21]", `Error processing response headers: ${e1}`);
                }
                throw new RemoteRequestError(`Unexpected error "${response.error}" (status code: ${response.status}) for request ${request.method} ${request.url}`);
            }
            throw new RemoteRequestError(`Unknown error "${e}"  for request ${enrichedRequest.request.method} ${enrichedRequest.request.url}`);
        }
        finally {
            const elapsedTime = new Date().getTime() - startTime.getTime();
            this.waitUntil = null;
            logger.debug("[src/client/RemoteClient.ts:216:13]", `Call to ${requestDetails.method} ${requestDetails.url} took ${elapsedTime}ms to execute`);
        }
        return res;
    }
    async execute(callType, details, customResponseHandling = {}) {
        const enrichedRequest = this.enrichRequestDetails(details, customResponseHandling);
        return await this.retry(async () => {
            await this.waitToLimitTps(callType);
            const response = await this.rawExecute(enrichedRequest);
            enrichedRequest.actions.onLoad(response);
            return response;
        }, this.retries);
    }
    async retry(fn, retriesLeft) {
        try {
            return await fn();
        }
        catch (e) {
            if (e instanceof RetryableError && retriesLeft > 0) {
                logger.log("[src/client/RemoteClient.ts:238:17]", `Retryable error to ${this.serviceName}. Checking if we should continue...`);
                if (e.message.startsWith(MIDWAY_REDIRECT_URL)) {
                    // if this is a Midway redirect, we show the auth message to the user before proceeding.
                    // However, note that the user can cancel the export.
                    const shouldContinue = await this.beforeRetry(this.singletons, e, this.serviceName);
                    if (!shouldContinue)
                        throw new Error(ABORTED_BY_USER);
                }
                logger.log("[src/client/RemoteClient.ts:248:17]", `Retrying call to ${this.serviceName} (${retriesLeft} attempts left)...`);
                return this.retry(fn, retriesLeft - 1);
            }
            throw e;
        }
    }
    async waitToLimitTps(callType) {
        if (!this.lastCallStart)
            return;
        const now = new Date();
        if (this.waitUntil) { // waitUntil takes precedence if it is set
            const msUntilSpecifiedWaitTime = this.waitUntil.getTime() - now.getTime();
            if (msUntilSpecifiedWaitTime <= 0)
                return;
            logger.log("[src/client/RemoteClient.ts:265:13]", `Throttling remote client call (waitUntil): waiting ${msUntilSpecifiedWaitTime}ms before calling ${this.serviceName}`);
            await Utils.sleep(msUntilSpecifiedWaitTime);
        }
        const msSinceLastCall = now.getTime() - this.lastCallStart.getTime();
        const minMsInterval = callType == 'read' ? this.readWaitMs : this.writeWaitMs;
        if (msSinceLastCall >= minMsInterval)
            return;
        const wait = minMsInterval - msSinceLastCall;
        logger.log("[src/client/RemoteClient.ts:275:9]", `Throttling remote client call: waiting ${wait}ms before calling ${this.serviceName}`);
        await Utils.sleep(wait);
    }
}

/**
 * Encodes parameters as an encoded URI.
 * @param {*} data binary content to be encoded
 */
function getEncodedQueryData(data) {
    return Object.entries(data || {}).map(kv => kv.map(encodeURIComponent).join("=")).join("&");
}
/**
 * Transforms the input text (arbitrarily large block of data) into a fixed-size output using the SHA-256 hash function.
 * Source: https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/digest
 *
 * @param {*} message arbitrarily large block of data
 */
async function digestMessage(message) {
    const msgUint8 = new TextEncoder().encode(message);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) {
        return '0 Bytes';
    }
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}
function colorRgbToHex(attrValue) {
    return attrValue.replace(/rgb\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*\)/, (m, r, g, b) => {
        let rHex = (+r).toString(16), gHex = (+g).toString(16), bHex = (+b).toString(16);
        if (rHex.length == 1)
            rHex = "0" + r;
        if (gHex.length == 1)
            gHex = "0" + g;
        if (bHex.length == 1)
            bHex = "0" + b;
        return '#' + rHex + gHex + bHex;
    });
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function mapToString(map) {
    const output = [];
    for (const [k, v] of map) {
        output.push(`${JSON.stringify(k)}: ${JSON.stringify(v)}`);
    }
    return '{' + output.join(', ') + '}';
}

const TIMEOUT$1 = 15000;
const TEST_TIMEOUT = 7500;
const ATTACH_TIMEOUT = 30000;
const UPLOAD_SIZE_LIMIT = 1.9 * 1024 * 1024; // The limit was 2MB, but was changed to 1.9MB some day around 2023-07-27
// other constants
const API_URL$1 = 'https://w.amazon.com/rest/wikis/xwiki/spaces/';
const VIEW_URL = 'https://w.amazon.com/bin/view/';
const PERMISSION_URL = 'https://w.amazon.com/bin/owner/';
const DOWNLOAD_URL = 'https://w.amazon.com/bin/download/';
const UPLOAD_URL = 'https://w.amazon.com/bin/upload/';
const DELETE_ATTACHMENT_URL = 'https://w.amazon.com/bin/delattachment/';
const WIKI_TAG = "Quip2Wiki";
const SYNTAX = {
    'xwiki': 'xwiki/2.1',
    'xwiki/2.0': 'xwiki/2.0',
    'xwiki/2.1': 'xwiki/2.1',
    'xhtml': 'xhtml/1.0',
    'xhtml/1.0': 'xhtml/1.0',
    'markdown': 'markdown/1.2',
    'markdown/1.2': 'markdown/1.2',
    'mediawiki': 'mediawiki/1.16',
    'mediawiki/1.16': 'mediawiki/1.16'
};
const IMAGE_FORMATS = ['jpeg', 'bmp', 'tiff', 'png']; // we will not add 'gif' to avoid resizing and losing animation
const DEFAULT_USER_SPACE = 'Users/';
const MIKI_FLAG = 'disableMiki';
function getPermissionDisclaimer(wikiAddress) {
    const relativeAddress = extractWikiRelativeAddr(wikiAddress);
    const permissionAddress = PERMISSION_URL + relativeAddress;
    return `You don't have permission to change the page. This error is NOT related to Quip2Wiki.<br><br>
<i>You can check the permissions necessary by clicking <b><a href="${permissionAddress}" style="text-decoration: underline" rel="noopener">here</a></b></i>.<br><br>

If you need permissions to edit the page, contact the owners in the link above.<br>
If you already belong to one of the groups that has write permissions, please note that it may take up to 4 hours for permissions to propagate to the Wiki.`;
}
const FILE_SIZE_DISCLAIMER = `The file is too big.
This error is NOT related to Quip2Wiki. This file hit the file size limit set by the Wiki administrators.

Please identify the file and remove it as an attachment, or upload it in another service and replace the attachment with a link to it.`;
/**
 * Extracts the destination wiki relative address from a user input or full wiki URL (enconded or not).
 * Reference from Wiki: https://tiny.amazon.com/2wsxuzu7
 *
 * Valid chars: ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~:/?#[]@!$&'()*+,;=
 *
 * @param {*} wikiAddr destination wiki address (full or relative, encoded or not)
 */
function extractWikiRelativeAddr(wikiAddr) {
    // user:         /Quip2Wiki/SpecialChars_~!@$%&*()-_=+{}|.,<>'"`
    // wiki-created: /Quip2Wiki/SpecialChars_~!@$%5E%25&*()-_=+%7B%7D%7C.,<>'"%60
    // encodeURI:    /Quip2Wiki/SpecialChars_~!@$%5E%25&*()-_=+%7B%7D%7C.,%3C%3E'%22%60
    const decodedAndSanitized = wikiAddr
        .replace(/^\//g, '') // remove '/' at the beginning
        .replace(/\s+/g, '') // remove spaces
        .replace(/\\/g, '/')
        .replace(/%[0-9A-Fa-f]{2}/g, m => decodeURIComponent(m))
        .replace(/&amp;/g, '&') // remove temporarily to avoid having ';' removed
        .replace(/[^a-zA-Z0-9._~:/?#@!$&()*,=-]/g, '') // clean up undesired chars
        .replace(/&/g, '&amp;'); // reinstate '&amp;' to avoid issues in wiki
    const match = decodedAndSanitized.match(WIKI_SYNC_VALID_REGEX);
    if (match == null)
        throw new Error(`Invalid wiki address (null match): ${wikiAddr}`);
    if (match[1] == null)
        throw new Error(`Invalid wiki address: ${wikiAddr}`);
    return encodeURI(match[1])
        .trim()
        .replace(/^User:(.*)/, 'Users/$1')
        .replace(/\/+/g, '/')
        .replace(/\/$/, '');
}
/**
 * Returns the Wiki URL for Page requests as an URI. The 'type' parameter defines the different pages
 * interfaces for requests.
 *
 * @param {string} wikiAddr wiki url address (or relative address)
 * @param {string} type of request such as 'view', 'upload', 'download', and 'delattachment'
 * @param {string} subPage sub page name or section
 */
function getWikiEndpoint(wikiAddr, type, subPage) {
    const relativeUrl = wikiAddr.replace(/&amp;/g, '&'); // Quip saves '&' in content as '&amp;' including URLs. Calls should use '&' instead
    if (type == 'view') {
        return VIEW_URL + encodeURI(relativeUrl) + '/' + subPage;
    }
    else if (type == 'upload') {
        return UPLOAD_URL + encodeURI(relativeUrl) + '/' + subPage;
    }
    else if (type == 'download') {
        return DOWNLOAD_URL + encodeURI(relativeUrl) + '/' + subPage;
    }
    else if (type == 'delattachment') {
        return DELETE_ATTACHMENT_URL + encodeURI(relativeUrl) + '/' + subPage;
    }
    else {
        throw 'Invalid wiki page type';
    }
}
function createXmlPageDocument(title, content, syntax, comment) {
    logger.log("[src/client/WikiClient.ts:115:5]", '[wiki-client] creating page...');
    const xmlDoc = new DOMParser().parseFromString('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
        '<page xmlns="http://www.xwiki.org">' +
        '  <title></title>' +
        '  <content></content>' +
        '  <comment></comment>' +
        '  <syntax></syntax>' +
        '</page>', 'application/xml');
    const titleCData = xmlDoc.createCDATASection(title);
    const contentCData = xmlDoc.createCDATASection(content);
    xmlDoc.getElementsByTagName('title')[0].appendChild(titleCData);
    xmlDoc.getElementsByTagName('content')[0].appendChild(contentCData);
    xmlDoc.getElementsByTagName('comment')[0].textContent = comment;
    xmlDoc.getElementsByTagName('syntax')[0].textContent = SYNTAX[syntax];
    return new XMLSerializer().serializeToString(xmlDoc);
    // return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    //     '<page xmlns="http://www.xwiki.org">' +
    //     '  <title><![CDATA[' + title + ']]></title>' +
    //     '  <content><![CDATA[' + content + ']]></content>' +
    //     '  <comment>' + comment + '</comment>' +
    //     '  <syntax>' + SYNTAX[syntax] + '</syntax>' +
    //     '</page>';
}
function createXmlTagsDocument(tags) {
    logger.log("[src/client/WikiClient.ts:146:5]", '[wiki-client] creating tags page...');
    if (!tags) {
        tags = [];
    }
    let content = '';
    tags.forEach(tag => {
        content += `<tag name="${tag}" />`;
    });
    return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
        '<tags xmlns="http://www.xwiki.org">' + content + '</tags>';
}
/**
 * Amazon Wiki API client, with basic operations such as get and save wiki pages.
 */
class WikiClient extends RemoteClient {
    constructor(singletons, beforeRetry) {
        super(singletons, 3, 1, beforeRetry, WIKI_SERVICE);
    }
    async getWikiPageXml(wikiAddr, typeLabel, timeout) {
        // TODO check if typelabel root should be used... home may be the correct value?
        const requestUrl = this.getRestEndpoint(wikiAddr, typeLabel);
        const response = await this.execute('read', {
            method: 'GET',
            url: requestUrl,
            headers: {
                'Content-Type': 'application/xml',
            },
            timeout: timeout,
        });
        try {
            const parser = new DOMParser();
            return parser.parseFromString(response.responseText, "text/xml");
        }
        catch (err) {
            logger.error("[src/client/WikiClient.ts:185:13]", 'getWikiPageXml error: ' + err);
            throw new Error("Error occurred while retrieving Wiki page XML: " + err);
        }
    }
    /**
     * Retrieves the form token from a existing Wiki Page. The token is required for attachment uploads.
     *
     * The token is extracted from the 'attachment' section of the wiki page, defined by the following URL:
     * https://w.amazon.com/bin/view/Quip2Wiki/?viewer=attachments
     *
     * The token is extracted from the following HTML tag pattern:
     * > <html data-xwiki-form-token="cbKxheYoR12LlTnkcQeIAg">
     * > <input type="hidden" name="form_token" value="cbKxheYoR12LlTnkcQeIAg">
     *
     * @param {string} wikiAddr wiki url address (or relative address)
     * @retuns the wiki page's form token
     */
    async getFormToken(wikiAddr) {
        const requestUrl = getWikiEndpoint(wikiAddr, 'view', `?viewer=attachments&${MIKI_FLAG}`);
        const response = await this.execute('read', {
            method: 'GET',
            url: requestUrl,
            headers: {
                'Content-Type': 'application/html',
            },
        }, {
            acceptedResponseStatus: [200, 304]
        });
        const parser = new DOMParser();
        const document = parser.parseFromString(response.responseText, "text/html");
        const token = document.getElementsByTagName("html")[0]?.getAttribute("data-xwiki-form-token");
        logger.debug("[src/client/WikiClient.ts:218:9]", `Wiki form token: ${token}`);
        if (!token) { // TODO test if this variable can actually be null or empty
            throw new Error("Empty form token");
        }
        return token;
    }
    /**
     * Creates or saves a wiki page using Wiki API.
     *
     * - HTTP 201 CREATED if page doesn't exist
     * - HTTP 202 ACCEPTED if page exists
     * - HTTP 400 BAD REQUEST if validation of page path failed
     * - HTTP 401 UNAUTHORIZED if permission check failed
     * - HTTP 500 SERVER ERROR probably content bigger than 2 MB
     */
    async putXmlContent(wikiAddr, content, pageType) {
        const writingWhat = pageType == 'tags' ? 'tags to the wiki page' : 'wiki page content';
        const providedWhat = pageType == 'tags' ? 'one of the tags' : 'the page address';
        const sizeLimit = formatBytes(UPLOAD_SIZE_LIMIT);
        const requestUrl = this.getRestEndpoint(wikiAddr, pageType);
        await this.execute('write', {
            method: 'PUT',
            url: requestUrl,
            data: content,
            headers: {
                'Content-Type': 'application/xml',
            },
            timeout: 3 * TIMEOUT$1,
        }, {
            acceptedResponseStatus: [201, 202, 304],
            customErrorMessages: new Map([
                [400, () => `Error occurred while writing ${writingWhat}: ${providedWhat} you have provided contains an invalid character`],
                [401, () => `Error 401 occurred while writing ${writingWhat}: \n${getPermissionDisclaimer(wikiAddr)}`],
                [403, () => `Error 403 occurred while writing ${writingWhat}: \n${getPermissionDisclaimer(wikiAddr)}`],
                [500, () => `Error occurred while writing ${writingWhat}: the document is too big and exceeds Wiki ${sizeLimit} limit`],
                [504, () => `Error occurred while writing ${writingWhat}: did not get a response in time from server`]
            ])
        });
    }
    async uploadAttachmentBlob(blob, wikiAddr, formToken, attachmentName) {
        // kcurl -X POST -F 'form_token=ShJF3DN84tijQuX7zI2EWA' -F 'filepath=@amazon.png'  https://w.amazon.com/bin/upload/Quip2Wiki/HTML/WebHome
        logger.log("[src/client/WikiClient.ts:262:9]", `Started uploading attachment '${attachmentName}'...`);
        const name = attachmentName.substring(23); // friendly name
        if (blob.size > UPLOAD_SIZE_LIMIT) {
            const limitStr = formatBytes(UPLOAD_SIZE_LIMIT);
            logger.error("[src/client/WikiClient.ts:266:13]", `[wiki-client] attachment '${attachmentName}' upload error: above ${limitStr} limit`);
            throw `The attachment '${name}' is too large (above the ${limitStr} limit imposed by Amazon Wiki).`;
        }
        // create form data
        const formData = new FormData();
        formData.append('form_token', formToken);
        formData.append('filepath', blob, attachmentName);
        formData.append('extravar', 'extravar'); // TODO remove this extra var?? It seems to have been left unintentionally
        // upload to wiki
        const requestUrl = getWikiEndpoint(wikiAddr, 'upload', `WebHome?${MIKI_FLAG}`);
        await this.execute('write', {
            method: "POST",
            url: requestUrl,
            data: formData,
            timeout: ATTACH_TIMEOUT,
        }, {
            acceptedResponseStatus: [200, 304],
            customErrorMessages: new Map([
                [401, () => `Error 401 occurred while uploading attachment '${name}': \n${getPermissionDisclaimer(wikiAddr)}`],
                [403, () => `Error 403 occurred while uploading attachment '${name}': \n${getPermissionDisclaimer(wikiAddr)}`],
                [413, () => `Error 403 occurred while uploading attachment '${name}': \n${FILE_SIZE_DISCLAIMER}`],
                [500, (r) => `[wiki-client] attachment '${attachmentName}' upload error: ${r.responseText}`]
            ])
        });
        // TODO: replace the error 500 message with fixed error extraction below, as it was broken by changes in the wiki error structure
        // try {
        //     const parser = new DOMParser();
        //     const internalPageError = parser.parseFromString(response.responseText, "text/html");
        //     let errorElement = internalPageError.children[0].children.body.firstElementChild.firstElementChild.children.contentcontainer.firstElementChild.firstElementChild.firstElementChild.children[1];
        //     errorElement = errorElement.firstElementChild.children.latestRevisionSummaryStore.nextElementSibling.nextElementSibling;
        //     const innerErrorMessage = tagSpecialChars(errorElement.innerText);
        //     if (errorElement) {
        //         rej(`Error occurred while uploading attachment '${name}': ${innerErrorMessage}`);
        //         return;
        //     }
        // } catch (e) {
        //     log.info(`Failure while extracting internal error message: ${e}`);
        // }
        logger.log("[src/client/WikiClient.ts:307:9]", `Upload of '${attachmentName}' completed`);
    }
    async deleteAttachment(wikiAddr, formToken, attachmentName) {
        // https://w.amazon.com/bin/delattachment/Quip2Wiki/HTML/WebHome/amazon.png?form_token=ShJF3DN84tijQuX7zI2EWA&xredirect=%2Fbin%2Fview%2FQuip2Wiki%2FHTML%2F%23Attachments
        const name = attachmentName.substring(23); // friendly name
        logger.log("[src/client/WikiClient.ts:313:9]", `[wiki-client] start delete of '${attachmentName}'...`);
        const requestUrl = getWikiEndpoint(wikiAddr, 'delattachment', 'WebHome') + `/${attachmentName}?form_token=${formToken}&${MIKI_FLAG}`;
        await this.execute('write', {
            method: "POST",
            url: requestUrl,
            timeout: ATTACH_TIMEOUT,
        }, {
            acceptedResponseStatus: [200, 202, 204, 304],
            customErrorMessages: new Map([
                [401, () => `Error 401 occurred while deleting attachment '${name}': \n${getPermissionDisclaimer(wikiAddr)}`],
                [403, () => `Error 403 occurred while deleting attachment '${name}': \n${getPermissionDisclaimer(wikiAddr)}`]
            ])
        });
    }
    /**
     * Search template: https://w.amazon.com/rest/wikis/xwiki/search?q={keywords}(&scope={content|name|title|spaces|objects})*(&number={number})(&start={start})(&orderField={fieldname}(&order={asc|desc}))(&prettyNames={false|true})
     */
    async search(keywords, scope = 'spaces', number) {
        logger.log("[src/client/WikiClient.ts:333:9]", `[wiki-client] searching: keyword='${keywords}', scope=${scope}...`);
        const requestUrl = API_URL$1 + 'search/search?' + getEncodedQueryData({
            q: keywords,
            scope: scope,
            number: number,
            // start: start, // TODO: check if this continues working without the undefined keywords
            // orderField: orderField,
            // order: order,
            // prettyNames: prettyNames
        });
        logger.log("[src/client/WikiClient.ts:343:9]", `[wiki-client] search endpoint: ${requestUrl}`);
        const response = await this.execute('read', {
            method: 'GET',
            url: requestUrl,
            headers: {
                'Content-Type': 'application/xml',
            },
            timeout: 2 * TIMEOUT$1,
        });
        try {
            logger.log("[src/client/WikiClient.ts:354:13]", '[wiki-client] search result: ' + response.status);
            const parser = new DOMParser();
            const xml = parser.parseFromString(response.responseText, "text/xml");
            return WikiClientHelper.getSearchResult(xml);
        }
        catch (err) {
            logger.error("[src/client/WikiClient.ts:359:13]", '[wiki-client] search error: ' + err);
            throw new Error("Error occurred while searching");
        }
    }
    async testConnection() {
        const xml = await this.getWikiPageXml('Quip2Wiki', 'root', TEST_TIMEOUT);
        return !!xml; // valid XML means we can connect to Wiki API
    }
    async wikiPageExists(wikiAddr) {
        logger.log("[src/client/WikiClient.ts:370:9]", `Checking if page ${wikiAddr} exists...`);
        const wikiXml = await this.getWikiPageXml(wikiAddr, 'root');
        if (wikiXml == null)
            throw new Error(`No XML content for wiki address ${wikiAddr}`); // TODO test if this variable can actually be null
        return wikiXml.getElementsByTagName('home').length > 0;
    }
    async getLastUpdated(wikiAddr) {
        const wikiXml = await this.getWikiPageXml(wikiAddr, 'history', TIMEOUT$1);
        if (wikiXml == null)
            throw new Error("No XML content (getLastUpdated)"); // TODO test if this variable can actually be null
        const timestamp = WikiClientHelper.getLastUpdated(wikiXml);
        logger.log("[src/client/WikiClient.ts:384:9]", `[wiki-client] wiki page timestap: ${timestamp || 'none (page changed)'}`);
        return timestamp;
    }
    async getTags(wikiAddr) {
        const wikiXml = await this.getWikiPageXml(wikiAddr, 'tags', TIMEOUT$1);
        if (wikiXml == null)
            throw "No XML content (getTags)"; // TODO test if this variable can actually be null
        const tags = [];
        for (const element of wikiXml.getElementsByTagName('tag')) {
            const tagName = element.getAttribute('name');
            tags.push(tagName);
        }
        logger.log("[src/client/WikiClient.ts:398:9]", 'Tags extracted:', tags.join(', '));
        return tags;
    }
    /**
     * Retrieves the list of attachments from an existing Wiki Page.
     */
    async getAttachmentsList(wikiAddr) {
        const wikiXml = await this.getWikiPageXml(wikiAddr, 'attachments', TIMEOUT$1);
        if (wikiXml == null) // TODO test if this variable can actually be null
            throw new Error("No XML content (getAttachmentsList)");
        return WikiClientHelper.getAttchments(wikiXml);
    }
    enrichRequestDetails(req, customResponseHandling = {}) {
        const enrichedRequest = super.enrichRequestDetails(req, customResponseHandling);
        const updatedReq = enrichedRequest.request;
        if (updatedReq.timeout == undefined)
            updatedReq.timeout = TIMEOUT$1;
        return enrichedRequest;
    }
    /**
     * Returns the Wiki API endpoint for Page requests as a URI. The 'type' parameter defines the different pages
     * for the Wiki API endpoint.
     *
     * @param {string} wikiAddr wiki url address (or relative address)
     * @param {string} type the page type, such as home, tags, history, comments, or attachments
     */
    getRestEndpoint(wikiAddr, type) {
        const page = extractWikiRelativeAddr(wikiAddr).replace(/&amp;/g, '&'); // Quip saves '&' in content as '&amp;' including URLs. API calls should use '&' instead
        const pathParts = page.includes('/') ? page.split('/') : [page];
        // base page target
        let targetPath = API_URL$1 + pathParts.join('/spaces/');
        // other page types
        if (type === 'home') {
            targetPath += '/pages/WebHome';
        }
        else if (type === 'tags') {
            targetPath += '/pages/WebHome/tags'; // does not work!
        }
        else if (type === 'history') {
            targetPath += '/pages/WebHome/history';
        }
        else if (type === 'comments') {
            targetPath += '/pages/WebHome/comments';
        }
        else if (type === 'attachments') {
            targetPath += '/pages/WebHome/attachments';
        }
        logger.log("[src/client/WikiClient.ts:451:9]", `Wiki address '${wikiAddr}' transformed into wiki endpoint ${targetPath}`);
        return targetPath;
    }
}

function sanitizeHTMLText(unsafe) {
    return unsafe
        .replace(/&(?!amp;|lt;|gt;|quot|#039;)/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
function sanitizeHTMLAttribute(attrValue) {
    return attrValue
        .replace(/[&<>"']/g, '')
        .replace(/-/g, '&#45;')
        .trim();
}
function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // $& means the whole matched string
}

function base64ToBytes(base64) {
    const binString = atob(base64);
    return Uint8Array.from(binString, (m) => m.codePointAt(0) ?? 0);
}
function base64ToObj(b64) {
    return JSON.parse(new TextDecoder().decode(base64ToBytes(b64)));
}
function renderLogMessage(args, limit = 140) {
    let renderedMessage = args.map(a => {
        if (typeof a === 'object')
            return JSON.stringify(a);
        return a;
    }).join(" ");
    if (limit)
        renderedMessage = renderedMessage.slice(0, limit);
    return renderedMessage;
}
function getArgValue(args, name, defaultValue) {
    try {
        const sName = escapeRegExp(name);
        return args.match(new RegExp(`(?:^${sName}|[\\s;,|]${sName})\\s*=\\s*(?:(\\w+)|'([\\w ]+)')((?=[\\s;,|])|$)`))[1];
    }
    catch {
        return defaultValue;
    }
}

function addHtmlWrapper(body) {
    return `<!doctype html>
<html lang="en"><body>${body}</body></html>`;
}
function parseHtmlBody(quipApiResponseText) {
    const dom = new window.DOMParser();
    const wrappedContent = addHtmlWrapper(quipApiResponseText);
    const html = dom.parseFromString(wrappedContent, "text/html");
    const hChildren = Array.from(html.childNodes);
    const htmlNode = hChildren.find((e) => e instanceof HTMLElement); // && e.tagName.toLowerCase() == "html");
    if (!htmlNode)
        throw new Error("Root HTML node is undefined");
    const bodyNode = Array.from(htmlNode.childNodes)
        .find((e) => e instanceof HTMLElement && e.tagName.toLowerCase() == "body");
    if (!bodyNode)
        throw new Error("Root body node is undefined");
    return bodyNode;
}

// document types
const TYPE_DOCUMENT = "document";
const TYPE_SPREADSHEET = "spreadsheet";
const TYPE_SLIDES = "slides";
const VALID_DOCUMENT_TYPES = [TYPE_DOCUMENT, TYPE_SPREADSHEET, TYPE_SLIDES];
// <div class='empty'><img src='data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==' id='eAI9CAuhlKb' alt='' class='image'></img></div></div><span>Video: <a href=https://quip-amazon.com/blob/eAI9AAsEDXW/jMbiJaHK0hrJHlp052eL0Q target='_blank'>SampleVideo_360x240_10mb.mp4</a></span>
// <img src='/blob/eAI9AAsEDXW/iaSCFbc5PdEndk2cj_DWLw00001-png' id='eAI9CAvGDJt' alt=''></img></div><span>Video: <a href=https://quip-amazon.com/blob/eAI9AAsEDXW/iaSCFbc5PdEndk2cj_DWLw target='_blank'>Pexels Videos 1181911.mp4</a></span>
const VIDEO_PATTERN = /<img src=(["'])(.*?)\1[^<>]*?><\/img><br\/><span[^<>]*>Video: <a href=(["'])(.*?)\3 [^<>]*>(.*?)<\/a><\/span>/g;
// Quip2Wiki tags (--tag--)
const SYNC_TAG = 'wiki-sync';
const TAGS_TAG = 'wiki-tags';
const TITLE_TAG = 'wiki-title';
const OPTIONS_TAG = 'wiki-options';
const Q2W_OPTIONS_TAG = 'quip2wiki-options';
const SYNTAX_TAG = 'wiki-syntax';
const HEADER_TAG = 'wiki-header';
const FOOTER_TAG = 'wiki-footer';
const TOC_TAG = 'wiki-toc';
const LINK_TARGET_TAG = 'wiki-link-target';
const COMMENTS_TAG = 'wiki-comments';
const SHEETS_TAG = 'wiki-sheets';
const SORTABLE_TABLES_TAG = 'wiki-sortable-tables';
const IGNORE_TAG = 'wiki-ignore';
const TRACKER_TAG = 'wiki-tracker';
const BANNER_TAG = 'wiki-banner';
// Quip2Wiki inline tags (<<tag>>)
const TABLE_SORTABLE_INLINE_TAG = 'sortable';
const TABLE_SORT_ONLY_INLINE_TAG = 'sort-only';
const TABLE_FILTER_ONLY_INLINE_TAG = 'filter-only';
function generateReplacers(url) {
    const origin = url.origin;
    const absoluteAddress = url.toString();
    const relativeAddress = absoluteAddress.replace(origin, '');
    if (!url.search)
        return [absoluteAddress, relativeAddress];
    const absoluteAddressNoSearch = absoluteAddress.split('?')[0];
    const relativeAddressNoSearch = relativeAddress.split('?')[0];
    return [
        absoluteAddress, absoluteAddressNoSearch,
        relativeAddress, relativeAddressNoSearch
    ];
}
function extractQuipAttachmentInformation(element) {
    const address = element instanceof HTMLAnchorElement ? element.href : element.src;
    const url = new URL(address);
    const paths = url.pathname.split('/');
    const addOneToPathIndex = paths[1] == '-';
    const threadId = paths[addOneToPathIndex ? 3 : 2];
    const blobId = paths[addOneToPathIndex ? 4 : 3];
    const name = url.searchParams.get('name');
    const internalId = element.id;
    const value = element instanceof HTMLAnchorElement ? element.innerText : element.alt;
    const validName = QuipDocument.getValidAttachmentName(name || value);
    // title will have a prefix with blob id
    // Since title length cannot be more than 255 we truncate to account for blob id and dash chars
    const validNameTrunc = validName.substring(0, 232);
    const title = `${blobId}_${validNameTrunc}`;
    return {
        title,
        name: validName,
        quipUrl: address,
        replacers: generateReplacers(url),
        threadId,
        blobId,
        internalId,
    };
}
/**
 * Models a Quip Document, allowing for basic data extraction such as sections, tags, etc.
 */
class QuipDocument {
    constructor(d) {
        if (!VALID_DOCUMENT_TYPES.includes(d.thread.type)) {
            throw `${d.thread.type} is not a Quip document, spreadsheet, or slides`;
        }
        this.doc = d;
        this.htmlContent = d.html.replaceAll("<cl type=", "<ul type=")
            .replaceAll("</cl>", "</ul>")
            .replaceAll("<cli>", "<li>")
            .replaceAll("</cli>", "</li>");
        this.wikiAddr = this.getWikiSyncAddress();
        if (this.doc.thread.link) {
            const match = this.doc.thread.link.match(QUIP_LINK_REGEX);
            if (match && match[1]) {
                this._linkId = match[1];
            }
        }
        this.threadId = this.doc.thread.id;
        this.sheets = [];
    }
    get linkId() {
        return this._linkId || this.id;
    }
    get id() {
        // return this.doc.document_id || this.doc.thread.id; // This is so wrong....
        return this.threadId;
    }
    get title() {
        return this.doc.thread.title;
    }
    /**
     * Retrieves a Wiki compatible title, to be used as path
     * Reference from Wiki: https://tiny.amazon.com/2wsxuzu7
     */
    get titleAsUrl() {
        const suggestedTitle = this.doc.thread.title
            .replace(/\s+/g, '')
            .replace(/\\/g, '/')
            .replace(/\/+/g, '/')
            .replace(/[^\w-]/g, '')
            .replace(/^_+|_+$/g, '');
        logger.log("[src/quip/QuipDocument.ts:168:9]", 'suggested title: ' + suggestedTitle);
        return suggestedTitle;
    }
    get lastUpdated() {
        return this.doc.thread.updated_usec;
    }
    get type() {
        return this.doc.thread.type;
    }
    get isDocument() {
        return this.type === TYPE_DOCUMENT;
    }
    get isSpreadsheet() {
        return this.type === TYPE_SPREADSHEET;
    }
    get htmlContent() {
        return this.fixedHtml;
    }
    set htmlContent(html) {
        this.fixedHtml = html;
        this.bodyElement = parseHtmlBody(html);
        this.parse();
    }
    get sheetsDesiredOrder() {
        return this.sheets;
    }
    set sheetsDesiredOrder(desiredOrder) {
        if (!Utils.arraysEqual(this.getSheetNames(), desiredOrder)) {
            logger.warn("[src/quip/QuipDocument.ts:204:13]", "the sheets in editor do not match sheets in doc");
        }
        if (Utils.arraysEqualSameOrder(this.sheets, desiredOrder)) {
            return;
        }
        this.sheets = desiredOrder;
    }
    static getValidAttachmentName(name) {
        name = decodeURI(name);
        if (name.includes('&')) {
            name = name.split('&')[0];
        }
        name = name.replaceAll(/[^0-9a-zA-Z .]/g, '').replaceAll(' ', '_');
        if (name.length < 128)
            return name;
        return `${name.substring(0, 100)}___${name.substring(name.length - 20, name.length)}`;
    }
    static getAttachments(element) {
        const links = [];
        element.querySelectorAll('a').forEach(a => {
            if (a.href.startsWith('https://quip-amazon.com/-/blob/'))
                links.push(a);
        });
        return links;
    }
    static getImages(element) {
        const links = [];
        element.querySelectorAll('img').forEach(a => {
            if (a.src.startsWith('https://quip-amazon.com/blob/'))
                links.push(a);
        });
        return links;
    }
    /**
     * Extract attached items as a Map() where key is the filename and value is the URL, based on a given pattern.
     */
    getAttachmentsWithPattern(htmlElements) {
        const files = new Map();
        for (const element of htmlElements) {
            const attachment = extractQuipAttachmentInformation(element);
            files.set(attachment.title, attachment);
        }
        logger.log("[src/quip/QuipDocument.ts:252:9]", mapToString(files));
        return files;
    }
    parse() {
        this.html = new DOMParser().parseFromString(this.fixedHtml, 'text/html');
    }
    getUnderlyingQuipThread() {
        return this.doc.thread;
    }
    getHeader() {
        return Object.assign({}, this.doc.thread); // clone document header
    }
    getLastSectionId() {
        const content = this.fixedHtml;
        // find last section in quip document
        const regex = /id=(["'])(.+?)\1/g;
        let sectionId;
        let result = regex.exec(content);
        while (result) {
            sectionId = result[2];
            result = regex.exec(content);
        }
        logger.log("[src/quip/QuipDocument.ts:278:9]", 'Last section_id: ' + sectionId);
        return sectionId;
    }
    /**
     * Finds the section in the Quip document where the given Quip2Wiki tag available in the Quip document.
     * If 'tagName' is provided, it will match the exact tag. If 'tagName' is null, it will match the first
     * valid tag.
     *
     * Quip2Wiki tag must have the following patterns:
     *   --<tag-name>: "<tag_value>"--
     *
     * @param {string} tagName name of the Quip2Wiki tag
     * @returns the section id where the tag is (null if not found)
     */
    findTagSection(tagName) {
        let tagPattern;
        if (tagName) {
            logger.log("[src/quip/QuipDocument.ts:296:13]", `finding '${tagName}' tag section...`);
            tagPattern = `--${tagName}(:\\s*["“”](.*?(?!["“”]--).+?)["“”]\\s*)?--`;
        }
        else {
            logger.log("[src/quip/QuipDocument.ts:299:13]", `finding first tag section...`);
            // except wiki-macro and wiki-ignore which can be in the middle of the doc
            tagPattern = `--wiki-(?!macro|ignore)\\w+?(:\\s*["“”](.*?(?!["“”]--).+?)["“”]\\s*)?--`;
        }
        const tagRegex = new RegExp(tagPattern);
        const sectionRegex = /id=(["'])(.+?)\1/;
        const elements = this.html.getElementsByTagName('body')[0].querySelectorAll('p,pre');
        for (const element of elements) {
            const elHtml = element.outerHTML;
            const content = elHtml.replace(/<[^>]*?>/g, '');
            const tagMatch = content.match(tagRegex);
            if (tagMatch == null)
                continue;
            if (tagMatch[1] == null)
                continue;
            const tag = tagMatch[0].trim();
            logger.log("[src/quip/QuipDocument.ts:318:13]", `tag found: '${tag}'`);
            // get section_id
            const result = elHtml.match(sectionRegex);
            if (result == null)
                continue;
            if (result[2] != null)
                return result[2];
        }
        logger.log("[src/quip/QuipDocument.ts:326:9]", `tag not found!`);
        return null;
    }
    /**
     * Finds if given Quip2Wiki tag is available in the Quip document.
     * If 'tagName' is provided, it will match the exact tag. If 'tagName' is null, it will match the first
     * valid tag.
     *
     * Quip2Wiki tag must have the following patterns:
     *   --<tag-name>: "<tag_value>"--
     *
     * @param {string} tagName name of the Quip2Wiki tag
     * @returns true when the tag is found somewhere in the document
     */
    findTag(tagName) {
        logger.log("[src/quip/QuipDocument.ts:342:9]", `finding '${tagName}' tag...`);
        const tagPattern = `--${tagName}(:\\s*["“”](.*?(?!["“”]--).+?)["“”]\\s*)?--`;
        const tagRegex = new RegExp(tagPattern);
        const elements = this.html.getElementsByTagName('body')[0].querySelectorAll('p,pre');
        for (const element of elements) {
            const elHtml = element.outerHTML;
            const content = elHtml.replace(/<[^>]*?>/g, '');
            const tagMatch = content.match(tagRegex);
            if (tagMatch) {
                const tag = tagMatch[0].trim();
                logger.log("[src/quip/QuipDocument.ts:355:17]", `tag found: '${tag}'`);
                return true;
            }
        }
        logger.log("[src/quip/QuipDocument.ts:360:9]", `tag not found!`);
        return false;
    }
    /**
     * Reads a given Quip2Wiki tag value. If not present, it will return the given default value.
     *
     * Tags must have one of the following patterns:
     * > --<tag-name>--
     * > --<tag-name>:"<tagValue>"--
     *
     * @param {string} tagName name of the Quip2Wiki tag
     * @param {string} defaultValue value to be returned if tag is not found
     */
    readTagValue(tagName, defaultValue) {
        const tagRegex = new RegExp(`--${tagName}:\\s*["“”](.*?(?!["“”]--).+?)["“”]\\s*--`);
        logger.log("[src/quip/QuipDocument.ts:377:9]", `get '${tagName}' tag value...`);
        const elements = this.html.getElementsByTagName('body')[0].querySelectorAll('p,pre');
        for (const element of elements) {
            const elHtml = element.innerHTML;
            const content = elHtml.replace(/<[^>]*?>/g, '');
            const tagMatch = content.match(tagRegex);
            if (tagMatch == null)
                continue;
            if (tagMatch[1] == null)
                continue;
            const tagValue = tagMatch[1].trim();
            logger.log("[src/quip/QuipDocument.ts:389:13]", `'${tagName}' tag found: value='${tagValue}'`);
            return tagValue;
        }
        logger.log("[src/quip/QuipDocument.ts:394:9]", `'${tagName}' tag not found!`);
        return defaultValue;
    }
    /**
     * Reads all occurencies of a given Quip2Wiki tag value and returns their value as an array.
     *
     * Tags must have the following pattern:
     * > --<tag-name>:"<tagValue>"--
     *
     * @param {string} tagName name of the Quip2Wiki tag
     */
    readTagValues(tagName) {
        const tagRegex = new RegExp(`--${tagName}:\\s*["“”](.*?(?!["“”]--).+?)["“”]\\s*--`);
        const output = [];
        logger.log("[src/quip/QuipDocument.ts:411:9]", `get '${tagName}' tag value...`);
        const elements = this.html.getElementsByTagName('body')[0].querySelectorAll('p,pre');
        for (const element of elements) {
            const elHtml = element.innerHTML;
            const content = elHtml.replace(/<[^>]*?>/g, '');
            const tagMatch = content.match(tagRegex);
            if (tagMatch == null)
                continue;
            if (tagMatch[1] == null)
                continue;
            const tagValue = tagMatch[1].trim();
            if (!tagValue) {
                continue;
            }
            logger.log("[src/quip/QuipDocument.ts:427:13]", `'${tagName}' tag found: value='${tagValue}'`);
            output.push(tagValue);
        }
        logger.log("[src/quip/QuipDocument.ts:431:9]", `Found ${output.length} occurencies of '${tagName}' tag`);
        return output;
    }
    /**
     * Retrieves all instances of a given tag and validates their value as a relative Wiki Page address.
     */
    readTagValuesWithArguments(tagName) {
        return this.readTagValues(tagName)
            .map(value => value.split(/\|(.*)/)) // split only on the first '|'
            .map(parts => ({ value: parts[0], args: parts[1] }))
            .filter(obj => !!obj.value || !!obj.args);
    }
    getWikiLinkTargetTag() {
        // quip tag: --wiki-link-target: "(_blank|_top|_self|_parent)"--
        const linkTargetTagExists = this.findTag(LINK_TARGET_TAG);
        if (linkTargetTagExists) {
            const linkTargetTagValue = this.readTagValue(LINK_TARGET_TAG, '').toLowerCase();
            switch (linkTargetTagValue) {
                case "_blank":
                case "_top":
                case "_self":
                case "_parent":
                    return linkTargetTagValue;
                default:
                    throw new Error(`Invalid value for wiki-link-target tag: ${linkTargetTagValue}. Allowed values: _blank|_top|_self|_parent`);
            }
        }
        return undefined;
    }
    /**
     * Retrievies the Wiki Page TAGs from the 'tags' tag in the document.
     *
     * The 'tags' tag follows the pattern as shown in the example:
     * > --wiki-tags: "tag1; tag2; tag3"--
     */
    getWikiTags() {
        const tagValue = this.readTagValue(TAGS_TAG, null);
        if (tagValue == null) {
            return [];
        }
        const tags = tagValue.split(/\s*[;,]\s*/);
        logger.log("[src/quip/QuipDocument.ts:478:9]", 'wiki tags: ' + tags);
        return tags;
    }
    /**
     * Retrievies the Wiki Page address from the 'wiki-sync' tag in the document.
     */
    getWikiSyncAddress() {
        const tagValue = this.readTagValue(SYNC_TAG, null);
        if (!tagValue) {
            return null;
        }
        const addr = this.validateWikiAddress(tagValue);
        if (addr) {
            logger.log("[src/quip/QuipDocument.ts:492:13]", 'wiki sync page: ' + addr);
        }
        return addr;
    }
    /**
     * Retrievies the Wiki Syntax from the 'syntax' tag in the document. If tag is not available, returns
     * default 'xhtml' syntax.
     *
     * The 'syntax' tag follows the pattern as shown in the example:
     * > --wiki-syntax:"xhtml"--
     * > --wiki-syntax:"xwiki"--
     * > --wiki-syntax:"markdown"--
     */
    getWikiSyntax() {
        const defaultSyntax = 'xhtml';
        const value = this.readTagValue(SYNTAX_TAG, defaultSyntax);
        const syntax = value.trim().toLowerCase();
        if (!['xhtml', 'xwiki'].includes(syntax)) {
            throw `Invalid wiki syntax: ${syntax}`;
        }
        return syntax;
    }
    /**
     * Gets all header tags from the document.
     */
    getWikiHeaders() {
        return this.readRelativeWikiAddressTags(HEADER_TAG);
    }
    /**
     * Gets all footer tags from the document.
     */
    getWikiFooters() {
        return this.readRelativeWikiAddressTags(FOOTER_TAG);
    }
    /**
     * Retrieves all instances of a given tag and validates their value as a relative Wiki Page address.
     */
    readRelativeWikiAddressTags(tagName) {
        return this.readTagValuesWithArguments(tagName)
            .filter(obj => !!obj.value)
            .map(obj => {
            const r = this.validateWikiAddress(obj.value);
            return ({
                addr: r ? extractWikiRelativeAddr(r) : null,
                args: obj.args
            });
        });
    }
    /**
     * Validates and extracts the Wiki Page address from the given value.
     *
     * The value should follow the pattern as shown in the examples:
     * > https://w.amazon.com/bin/view/Quip2Wiki/HTML
     * > w?Quip2Wiki/HTML
     * > Quip2Wiki/HTML
     */
    validateWikiAddress(value) {
        if (value == null) {
            return null;
        }
        const match = value.match(WIKI_SYNC_VALID_REGEX);
        if (match == null || match[1] == null) {
            logger.log("[src/quip/QuipDocument.ts:561:13]", '--wiki-sync-- tag value is invalid: ' + value);
            return null;
        }
        return match[1];
    }
    /**
     * Retrievies the Wiki Page title (override) from the 'title' tag in the document. If tag is not available, returns
     * the document title.
     *
     * The 'sync' tag follows the pattern as shown in the example:
     * > --wiki-title:"title of the wiki"--
     */
    getWikiTitle() {
        const defaultTitle = this.title;
        return this.readTagValuesWithArguments(TITLE_TAG).map(obj => obj.value)[0] || defaultTitle;
    }
    /**
     * Set the default value for some configurations when necessary
     */
    setDefaultOptions(options) {
        if (options.fixImageCentering === undefined) {
            options.fixImageCentering = false;
        }
    }
    /**
     * Retrievies the wiki options.
     *
     * The 'wiki-options' tag follows the pattern as shown in the example:
     * > --wiki-options:"fixImageCentering,fixSomethingElse"--
     * or the equivalent form that is also supported:
     * > --wiki-options:"fixImageCentering=true,fixSomethingElse=true"--
     */
    getWikiOptions() {
        const q2wOptionsB64 = this.readTagValues(Q2W_OPTIONS_TAG);
        let options = {};
        if (q2wOptionsB64.length > 0) {
            options = base64ToObj(q2wOptionsB64[0]);
        }
        this.setDefaultOptions(options);
        const optionsInDoc = this.readTagValues(OPTIONS_TAG);
        if (!optionsInDoc)
            return options;
        for (const opt of optionsInDoc) {
            const docOptionsArray = opt.split(",");
            for (const keyValuePair of docOptionsArray) {
                if (!keyValuePair.includes("=")) {
                    // if only the keyword appears, we default to true
                    options[keyValuePair] = true;
                    continue;
                }
                // else we look at which value is present
                const temp = keyValuePair.split("=");
                const key = temp[0];
                let value = temp[1];
                if (value == "true" || value == "True")
                    value = true;
                else if (value == "false" || value == "False")
                    value = false;
                options[key] = value;
            }
        }
        return options;
    }
    /**
     * Retrievies the presense of not of the wiki-commenst tag in the document. Returns true If tag is available.
     */
    getWikiComments() {
        return this.findTag(COMMENTS_TAG);
    }
    /**
     * Returns sorted list of sheets/tables of the document.
     *
     */
    getSheetNames() {
        if (!this.isSpreadsheet && !this.isDocument) {
            return [];
        }
        return [...this.html.querySelectorAll('table')].map(table => table.title);
    }
    /**
     * Rearanges elements based on layout extracted from Quip page (not Quip API).
     *
     */
    fixMultiColumnLayout(layout) {
        if (!this.isDocument) {
            return;
        }
        logger.log("[src/quip/QuipDocument.ts:661:9]", "fix multi-column layout...");
        let content = this.fixedHtml
            .replace(/<div class='empty'>(<img src='data:image\/gif;base64.*?'[^<>]*?><\/img>)<\/div>/g, '$1') // remove extra div of videos without poster
            .replace(/<div style='display:flex;[^<>]*>(<div[^<>]*data-section-style='11'[^<>]*><img src=[^<>]*?><\/img>)<\/div>(<span>.*?<\/span><\/div>)/g, '$1<br/>$2'); // remove outer div of videos
        for (const container of layout) {
            let containerHTML = container.outerHTML;
            let begin = undefined;
            let end = undefined;
            // find all related sections in document and move them to container
            const elements = container.getElementsByTagName('span');
            for (const el of elements) {
                const id = el.getAttribute('id');
                if (id == null)
                    continue;
                const sId = escapeRegExp(id);
                const sectionRegex1 = new RegExp(`<(h1|h2|h3|hr|p|blockquote|q)[^<>]*id='${sId}'[^<>]*>[\\s\\S]*?<\\/\\1>`);
                const sectionRegex2 = new RegExp(`<div [^<>]*data-section-style=[^<>]*><(img|ul|span)[^<>]*?id='${sId}'[\\s\\S]*?<\\/\\1>[\\s\\S]*?<\\/div>`);
                const match = content.match(sectionRegex1) || content.match(sectionRegex2);
                if (match && match[0]) {
                    let matchedSection = match[0];
                    if (matchedSection.startsWith("<pre id='" + id)) {
                        // fix duplicated html content when a column is completely encapsulated in a code block
                        matchedSection = matchedSection.substring(0, matchedSection.indexOf("</pre>") + 6);
                    }
                    // save section position in content
                    const pos = content.indexOf(matchedSection);
                    if (!begin) {
                        begin = pos;
                    }
                    end = pos + matchedSection.length;
                    // add section to container
                    containerHTML = containerHTML.replace(`<span id="${id}"></span>`, '\n' + matchedSection); // replace in the container
                }
                else {
                    containerHTML = containerHTML.replace(`<span id="${id}"></span>`, ''); // remove section
                    logger.warn("[src/quip/QuipDocument.ts:701:21]", `section with id=${id} not found!`);
                }
            }
            if (begin && end) {
                // place container in document
                content = content.replace(content.substring(begin, end), containerHTML);
            }
        }
        // update document content
        this.htmlContent = content.replace(/(<img[^<>]*?>)(?!<\/img>)/g, '$1</img><br/>'); // fix end tag and add new line to adjust text placement
    }
    /**
     * Rearanges elements based on layout extracted from Quip page (not Quip API).
     *
     */
    fixMathFormulas(controls) {
        if (!this.isDocument) {
            return;
        }
        logger.log("[src/quip/QuipDocument.ts:724:9]", "fix math formulas...");
        let content = this.htmlContent;
        controls.forEach((control, sectionId) => {
            if (control == null)
                return;
            const sId = escapeRegExp(sectionId);
            const sectionRegex = new RegExp(`<(h1|h2|h3|hr|p|blockquote|div|span)\\s[^<>]*id=(["'])${sId}\\2[^<>]*>[\\s\\S]*?<\\/\\1>`);
            const match = content.match(sectionRegex);
            if (match && match[0]) {
                // add section to container
                let index = 0;
                const fixedSection = match[0].replace(/<control((?!\S)[^<>]*?)?>[\s\S]*?<\/control>/g, (match) => {
                    const mathEq = control[index++];
                    if (mathEq) {
                        return `<math>${mathEq}</math>`;
                    }
                    else {
                        return match;
                    }
                }); // replace in the container
                if (index > 0) { // at least one math formula fixed
                    content = content.replace(match[0], fixedSection);
                }
            }
        });
        // update document content
        this.htmlContent = content;
    }
    /**
     * Add design-inspector URL to the matching div based on data extracted from Quip page (not Quip API).
     */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    fixDesignInspectorDiagrams(diagrams) {
        logger.log("[src/quip/QuipDocument.ts:760:9]", "fix design-inspector diagrams...");
        let content = this.htmlContent;
        diagrams.forEach((diData, key) => {
            const divRegex = new RegExp(`<div\\s[^<>]*data-unique-id=(["'])${key.section}-.*?\\1\\s*data-live-app-id=(["'])${key.id}\\2[^<>]*>[\\s\\S]*?<\\/div>`);
            const match = content.match(divRegex);
            if (match && match[0]) {
                // replace by a design-inspector specific tag
                content = content.replace(match[0], `<design-inspector src='${diData.diUrl}' width='${diData.width}' height='${diData.height}' />`);
            }
            else {
                logger.error("[src/quip/QuipDocument.ts:771:17]", `could not find div section for di-inspector '${JSON.stringify(key)}'`);
            }
        });
        // update document content
        this.htmlContent = content;
    }
    /**
     * Match a video section and replace with a <video> tag with a link to blob in Quip doc.
     *
     */
    fixVideos() {
        logger.log("[src/quip/QuipDocument.ts:784:9]", "fix videos...");
        let content = this.htmlContent;
        // replace video poster
        content = content.replace(/<div data-section-style='11'[^<>]*><img src='(data:image\/gif;base64,.*?)'[^<>]*>/g, // replace default video poster image
        (m, imgData) => m.replace(imgData, VIDEO_POSTER));
        // convert videos in <video>
        content = content.replace(VIDEO_PATTERN, (m, q1, imgSrc, q2, videoUrl, title) => {
            const imgUrl = imgSrc.startsWith('/blob/') ? `https://quip-amazon.com${imgSrc}` : imgSrc;
            const sanitizedVideoUrl = sanitizeHTMLAttribute(videoUrl);
            const sanitizedImgUrl = sanitizeHTMLAttribute(imgUrl);
            const sanitizedTitle = sanitizeHTMLAttribute(title);
            return `<video src="${sanitizedVideoUrl}" width="auto" height="auto" controls="true" poster="${sanitizedImgUrl}" title="${sanitizedTitle}"/>`;
        });
        // update document content
        this.htmlContent = content;
    }
    fixTableIds() {
        /*
        log.info("adding ids to tables...");

        let content = this.htmlContent;

        // determine ids and set same order as in Spreadsheet
        const sheetOrder = this.sheetsDesiredOrde?.map(title => Utils.sanitizeHTMLText(title));
        const getSheetOrder = (title) => {
            const index = sheetOrder?.indexOf(title);
            return index >= 0 ? index : null;
        };

        this.html.querySelectorAll('table').forEach((table, index) => {
            const id = 'table' + (getSheetOrder(table.title) || index);
            content = content.replace(new RegExp(`<table ([^<>]*title=(['\"])${Utils.escapeRegExp(table.title)}\\1[^<>]*>)`), `<table id='${id}' $1`);
        });

        // update document content
        this.htmlContent = content;
        */
    }
    getAttachments() {
        // extract images and file attachments
        logger.log("[src/quip/QuipDocument.ts:830:9]", "get image attachments...");
        const images = QuipDocument.getImages(this.bodyElement);
        const imagesTable = this.getAttachmentsWithPattern(images);
        logger.log("[src/quip/QuipDocument.ts:834:9]", "get file attachments...");
        const attachments = QuipDocument.getAttachments(this.bodyElement);
        const filesTable = this.getAttachmentsWithPattern(attachments);
        return new Map([...imagesTable, ...filesTable]);
    }
    getBannerPosition(singletons) {
        let bannerPosition = singletons.settings.bannerPosition || BannerPosition.TOP;
        const bannerTagExists = this.findTag(BANNER_TAG);
        if (bannerTagExists) {
            const bannerTagArgs = this.readTagValue(BANNER_TAG, '');
            const bannerTagDisplayValue = getArgValue(bannerTagArgs, 'display', 'top') || '';
            const newPosition = bannerTagDisplayValue.trim();
            if (newPosition === 'top') {
                bannerPosition = BannerPosition.TOP;
            }
            else if (newPosition === 'bottom') {
                bannerPosition = BannerPosition.BOTTOM;
            }
            else if (newPosition === 'hidden') {
                bannerPosition = BannerPosition.HIDDEN;
            }
            else if (newPosition === 'none') {
                bannerPosition = BannerPosition.NONE;
            }
        }
        return bannerPosition;
    }
}

/**
 * Models metadata for a Quip Document, containing only essential information without the full content.
 * Used for efficient memory usage when only basic document information is needed.
 */
class QuipDocumentMetadata {
    constructor(thread) {
        if (!thread)
            throw 'Invalid Quip thread (null thread)';
        else if (!thread.id)
            throw 'Invalid Quip thread (missing thread id)';
        else if (!thread.title)
            throw 'Invalid Quip thread (missing thread title)';
        this.thread = thread;
        this.threadId = thread.id;
        this._linkId = thread.linkId || thread.id;
    }
    get linkId() {
        return this._linkId;
    }
    get id() {
        return this.threadId;
    }
    get title() {
        return this.thread.title;
    }
    /**
     * Retrieves a Wiki compatible title, to be used as path
     */
    get titleAsUrl() {
        const suggestedTitle = this.thread.title
            .replace(/\s+/g, '')
            .replace(/\\/g, '/')
            .replace(/\/+/g, '/')
            .replace(/[^\w-]/g, '')
            .replace(/^_+|_+$/g, '');
        logger.log("[src/quip/QuipDocumentMetadata.ts:48:9]", 'suggested title: ' + suggestedTitle);
        return suggestedTitle;
    }
    get lastUpdated() {
        return this.thread.updated_usec;
    }
    get type() {
        return this.thread.type;
    }
    getUnderlyingQuipThread() {
        return this.thread;
    }
}

const state = {
    altKeyIsPressed: false,
    shiftKeyIsPressed: false,
    appTitle: "",
    isExporting: false,
    latestVersion: null,
    latestParsedVersion: null,
    telemetry: null,
    iframeData: new Map(),
    unitTest: false,
};

const API_URL = 'https://platform.quip-amazon.com/1';
const API_URL_V2 = 'https://platform.quip-amazon.com/2';
const CHECK_TOKEN_NOT_A_QUIP_TOKEN_ERROR = 'Provided token does not seem to be a Quip API token';
const LOCATION = {
    'APPEND': 0,
    'PREPEND': 1,
    'AFTER_SECTION': 2,
    'BEFORE_SECTION': 3,
    'REPLACE_SECTION': 4,
    'DELETE_SECTION': 5 // Delete the section specified by sectionId (no content required).
};
const TIMEOUT = 15000;
const AUTH_ERROR_CODES = [400, 401, 429];
function parseQuipDocThread(quipApiResponse) {
    const d = JSON.parse(quipApiResponse);
    if (!d)
        throw 'Invalid Quip document (null document)';
    else if (!d.thread)
        throw 'Invalid Quip document (null thread)';
    else if (!d.thread.id)
        throw 'Invalid Quip document (missing thread id)';
    else if (!d.thread.title)
        throw 'Invalid Quip document (missing thread title)';
    else if (!d.html)
        throw 'Invalid Quip document (missing html)';
    return d;
}
function isQuipWritableByUser() {
    return [...document.querySelectorAll("button.button.clickable div.button-icon svg path")]
        .find(b => b.getAttribute('d')?.startsWith("M13,15c-0.058,0-.115")) === undefined;
}
function getRequestAccessText() {
    return [...document.querySelectorAll("button.button.clickable div.button-icon svg path")]
        .find(b => b.getAttribute('d')?.startsWith("M13,15c-0.058,0-.115"))
        ?.parentElement?.parentElement?.parentElement?.textContent
        || 'Request Access or Join';
}
class QuipClient extends RemoteClient {
    constructor(singletons) {
        super(singletons, 10, 10, async () => false, "Quip API");
        this.addUserAgent = false;
    }
    static logFolder(wrapper) {
        if (wrapper.type == 'folder') {
            const folder = wrapper.value.folder;
            logger.log("[src/client/QuipClient.ts:89:13]", `folder: id=${folder.id}, timestamp=${wrapper.additionalInfo.lastUpdated}, color=${wrapper.additionalInfo.color}`);
            logger.log("[src/client/QuipClient.ts:90:13]", 'folder children:\n' + [...wrapper.children.map((f) => JSON.stringify(f))]);
        }
    }
    static parseResponseHeaders(response) {
        if (!response)
            return {};
        if (!response.responseHeaders)
            return {};
        const regex = /^([\w-]+):\s*(")?(.+)\2\s*$/;
        return response.responseHeaders.split('\n')
            .map(line => line.match(regex))
            .filter((m) => !!m)
            .map(m => {
            const obj = {};
            obj[m[1]] = m[3];
            return obj;
        })
            .reduce((a, b) => ({ ...a, ...b }));
    }
    async checkNewToken(testToken, tryNumber) {
        logger.log("[src/client/QuipClient.ts:111:9]", 'Checking if token is valid...');
        if (!testToken || testToken.length < 30 || !testToken.includes('=|')) {
            logger.error("[src/client/QuipClient.ts:114:13]", CHECK_TOKEN_NOT_A_QUIP_TOKEN_ERROR);
            return false;
        }
        let response;
        try {
            response = await this.execute('read', {
                method: "GET",
                url: API_URL + '/users/current',
                responseType: 'json',
                headers: {
                    'Authorization': `Bearer ${testToken}`
                }
            });
        }
        catch (error) {
            logger.error("[src/client/QuipClient.ts:129:13]", error);
            if (error instanceof RawError)
                throw error;
            if (tryNumber < 3)
                return false;
            if (error instanceof RemoteRequestStandardError && AUTH_ERROR_CODES.includes(error.code))
                return false;
            if (error instanceof RemoteRequestTimeoutError)
                throw new Error('Could not initialize Quip Client (timeout): please check your internet connection');
            throw error;
        }
        const userInfo = JSON.parse(response.responseText);
        return Boolean(userInfo.id && userInfo.name);
    }
    async getDocumentMetadata(id) {
        const response = await this.execute('read', {
            method: "GET",
            url: API_URL_V2 + '/threads/' + id,
            responseType: 'json',
        });
        const result = JSON.parse(response.responseText);
        try {
            if (result && result.thread) {
                const metadata = new QuipDocumentMetadata(result.thread);
                logger.log("[src/client/QuipClient.ts:154:17]", `doc metadata: id=${metadata.id}, timestamp=${metadata.lastUpdated}, type=${metadata.type}`);
                return metadata;
            }
            throw new Error(`Invalid response structure for document ID: ${id}`);
        }
        catch (err) {
            throw new Error(`Error getting metadata: ${err}`);
        }
    }
    async getDocument(id) {
        const response = await this.execute('read', {
            method: "GET",
            url: API_URL + '/threads/' + id,
            responseType: 'json',
        });
        try {
            const docThread = parseQuipDocThread(response.responseText);
            const doc = new QuipDocument(docThread);
            logger.log("[src/client/QuipClient.ts:173:13]", `doc: id=${doc.id}, timestamp=${doc.lastUpdated}, type=${doc.type}`);
            return doc;
        }
        catch (err) {
            throw new Error(`Error creating internal Quip document data structure: ${err}`);
        }
    }
    async getFolders(ids) {
        if (ids && ids.length == 0) {
            return [];
        }
        const url = API_URL + '/folders/?ids=' + ids.join(',');
        const response = await this.execute('read', {
            method: "GET",
            url: url,
            responseType: 'json'
        });
        const folderList = JSON.parse(response.responseText);
        if (!folderList)
            return [];
        const folders = Object.keys(folderList)
            .map(id => {
            return {
                type: 'folder',
                id,
                value: folderList[id],
                children: [],
                additionalInfo: {}
            };
        });
        if (folders.length === 0)
            return [];
        await this.loadFoldersRecursively(folders);
        await this.loadQuipDocumentsMetadataRecursively(folders);
        await this.loadLastUpdateTimeIncludingChildren(folders);
        this.sortChildrenRecursively(folders);
        folders.forEach(QuipClient.logFolder);
        return folders;
    }
    async getFolder(id) {
        const folders = await this.getFolders([id]);
        if (folders.length == 0)
            throw new Error(`Could not load Quip folder ${id}`);
        return folders[0];
    }
    async getUser(id) {
        logger.log("[src/client/QuipClient.ts:228:9]", 'start get user info...');
        try {
            state.telemetry?.registerQuipUserApiAttempt();
            const response = await this.execute('read', {
                method: "GET",
                url: API_URL + '/users/' + id,
                responseType: 'json'
            });
            const result = JSON.parse(response.responseText);
            state.telemetry?.registerQuipUserApiSuccess();
            return result;
        }
        catch (err) {
            logger.log("[src/client/QuipClient.ts:241:13]", `Error calling getUser: ${err}. Returning undefined`);
            state.telemetry?.registerQuipUserApiError();
            return undefined;
        }
    }
    async appendToEnd(id, content) {
        return await this.writeSection(id, content, null, null);
    }
    async appendAfterSection(id, content, sectionId) {
        return await this.writeSection(id, content, 'AFTER_SECTION', sectionId);
    }
    async replaceSection(id, content, sectionId) {
        return await this.writeSection(id, content, 'REPLACE_SECTION', sectionId);
    }
    async deleteSection(id, sectionId) {
        return await this.writeSection(id, null, 'DELETE_SECTION', sectionId);
    }
    async writeSection(id, content, location, sectionId) {
        if (id == null || content == null)
            throw new Error('writeSection: id and content are mandatory');
        if (location == null)
            location = 'APPEND';
        if (!(location in LOCATION)) {
            logger.error("[src/client/QuipClient.ts:271:13]", `write section error: invalid location ${location}`);
            throw new Error(`Error occurred while writing section: invalid location ${location}`);
        }
        if (sectionId == null && location !== 'APPEND' && location !== 'PREPEND') {
            logger.error("[src/client/QuipClient.ts:275:13]", `write section error: section ID cannot be null for location ${location}`);
            throw new Error(`Error occurred while writing section: section ID is null`);
        }
        logger.log("[src/client/QuipClient.ts:279:9]", `start writing section: ${location}...`);
        const editData = {
            'thread_id': id,
            'format': 'html',
            'location': LOCATION[location]
        };
        if (content) {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            editData.content = content;
        }
        if (sectionId) {
            logger.log("[src/client/QuipClient.ts:291:13]", `writing ${location} ${sectionId}`);
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            editData.section_id = sectionId;
        }
        const editUrl = API_URL + '/threads/edit-document';
        try {
            await this.execute('write', {
                method: "POST",
                url: editUrl,
                data: getEncodedQueryData(editData),
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                }
            });
        }
        catch (e) {
            logger.error("[src/client/QuipClient.ts:307:13]", e);
            if (isQuipWritableByUser())
                throw e;
            throw new Error(`Quip is not writable by user. Click <b>${getRequestAccessText()}</b> and get write permissions before trying to export.`);
        }
    }
    async getBlob(id, blobId) {
        const response = await this.execute('read', {
            method: "GET",
            url: API_URL + `/blob/${id}/${blobId}`,
            responseType: 'blob',
        });
        const headers = QuipClient.parseResponseHeaders(response);
        const contentDisposition = headers['content-disposition'].split(';');
        const disposition = contentDisposition[0].trim();
        // @ts-expect-error TODO: check if filename is null
        const filename = contentDisposition[1].trim().match(/(?:^filename|[\s;,|]filename)\s*=\s*"(.+?)"/)[1];
        return {
            blob: response.response,
            disposition: disposition,
            type: headers['content-type'],
            name: filename,
            length: parseInt(headers['content-length'], 10)
        };
    }
    async getAllMessages(id, messageType = 'message') {
        let result = undefined;
        let lastTimestamp = undefined;
        let messages = [];
        do {
            result = await this.getMessages(id, lastTimestamp, messageType);
            if (result && result.length > 0) {
                lastTimestamp = result.slice(-1)[0].created_usec - 1;
                messages = messages.concat(result);
            }
        } while (result && result.length > 0);
        // find all mentioned users and get their full name
        const userNames = messages.reduce((map, msg) => {
            map[msg.author_id] = msg.author_name;
            return map;
        }, {});
        // replace mentions with full name
        for (const msg of messages) {
            const sanitizedText = sanitizeHTMLText(msg.text);
            msg.text = await Utils.replaceAsyncSequence(sanitizedText, /https:\/\/quip\.com\/(\w{11})/g, async (url, userId) => {
                let name = userId;
                try {
                    if (userNames[userId]) {
                        name = userNames[userId];
                    }
                    else {
                        const u = await this.getUser(userId);
                        if (u == undefined)
                            return url;
                        name = u.name;
                        userNames[userId] = name;
                    }
                    return `<a href="${url}" target="_blank" rel="noopener">${name}</a>`;
                }
                catch (ignore) {
                    logger.trace("[src/client/QuipClient.ts:373:21]", `Ignored exception (getAllMessages): ${ignore}`);
                    return url;
                }
            });
        }
        return messages;
    }
    async getMessages(id, maxTimestamp, messageType = 'message') {
        logger.log("[src/client/QuipClient.ts:383:9]", 'start get messages...');
        const requestUrl = API_URL + '/messages/' + id + '?' + getEncodedQueryData({
            max_created_usec: maxTimestamp,
            message_type: messageType,
        });
        const response = await this.execute('read', {
            method: "GET",
            url: requestUrl,
            responseType: 'json',
        });
        const messages = response.response;
        if (!messages)
            throw new Error("Unknown error occurred while retrieving Quip messages");
        logger.log("[src/client/QuipClient.ts:399:9]", `get messages: found ${messages.length} messages`);
        return messages;
    }
    enrichRequestDetails(req, customResponseHandling = {}) {
        const defaultQuipResponseHandling = {
            acceptedResponseStatus: [200, 304],
            customErrorMessages: new Map([
                [401, () => `Authentication error: invalid or expired Quip API token`],
                [429, () => `Exceeded limit of calls/minute for Quip API`],
                [503, () => `Exceeded limit of calls/minute for Quip API`],
            ])
        };
        const enrichedRequest = super.enrichRequestDetails(req, { ...defaultQuipResponseHandling, ...customResponseHandling }); // TODO merge the maps???
        const updatedReq = enrichedRequest.request;
        if (updatedReq.timeout == undefined)
            updatedReq.timeout = TIMEOUT;
        if (updatedReq.headers) {
            if (updatedReq.headers['Authorization'] === undefined) {
                updatedReq.headers = {
                    ...updatedReq.headers,
                    'Authorization': `Bearer ${this.singletons.settings.quipApiToken}`
                };
            }
        }
        else {
            updatedReq.headers = {
                'Authorization': `Bearer ${this.singletons.settings.quipApiToken}`
            };
        }
        return enrichedRequest;
    }
    processResponseHeaders(response) {
        const headers = QuipClient.parseResponseHeaders(response);
        if (!headers)
            return;
        try {
            // X-Ratelimit-Limit: The number of requests/min the user can make
            // X-Ratelimit-Remaining: The number of requests remaining this user can make within the minute - this number changes with each request.
            // X-Ratelimit-Reset: The UTC timestamp for when the rate limit will reset
            const limit = parseInt(headers['x-ratelimit-limit']);
            const remaining = parseInt(headers['x-ratelimit-remaining']);
            const reset = parseInt(headers['x-ratelimit-reset']);
            logger.log("[src/client/QuipClient.ts:449:13]", `rate-limit: limit=${limit}, remaining=${remaining}, reset=${reset}`);
            if (!Number.isFinite(remaining)) {
                logger.warn("[src/client/QuipClient.ts:452:17]", `Invalid header in response: ${JSON.stringify(headers)}`);
                const avgMillisecondsWaitTime = 1000 * 60 / 50; // Quip API allows 50 API calls/minute
                const bufferMs = 40;
                const waitUntil = this.getLastCallStart().getTime() + avgMillisecondsWaitTime + bufferMs;
                this.waitUntil = new Date(waitUntil);
                return;
            }
            if (remaining > 1)
                this.waitUntil = null;
            else
                this.waitUntil = new Date(reset * 1000); // reset time in milliseconds
        }
        catch (e) {
            logger.warn("[src/client/QuipClient.ts:465:13]", `Unexpected error while processing Quip response headers: ${e}`);
        }
    }
    async loadFoldersRecursively(folders) {
        for (const folder of folders) {
            if (folder.value.children == undefined)
                folder.value.children = [];
            const childrenIds = folder.value.children
                .map(c => c.folder_id)
                .filter((v) => !!v);
            const childFolders = await this.getFolders(childrenIds);
            folder.children = folder.value.children.map((child) => {
                if (child.thread_id) {
                    return {
                        type: 'document',
                        id: child.thread_id,
                        additionalInfo: {}
                    };
                }
                const childFolderLoaded = childFolders.find(c => c.id == child.folder_id);
                if (!childFolderLoaded)
                    throw new Error(`Could not load child folder ${child.folder_id}`);
                return childFolderLoaded;
            });
        }
    }
    async loadQuipDocumentsRecursively(items) {
        for (const folder of items) {
            for (const child of folder.children) {
                if (child.type == 'document' && child.document == undefined) {
                    child.document = await this.getDocument(child.id);
                    if (!child.document)
                        throw new Error("getDocument did not return a document for id: " + child.id);
                }
            }
        }
    }
    async loadQuipDocumentsMetadataRecursively(items) {
        for (const folder of items) {
            for (const child of folder.children) {
                if (child.type == 'document' && child.metadata == undefined) {
                    child.metadata = await this.getDocumentMetadata(child.id);
                    if (!child.metadata)
                        throw new Error("getDocumentMetadata did not return metadata for id: " + child.id);
                }
            }
        }
    }
    async loadLastUpdateTimeIncludingChildren(items) {
        let maxTime = 0;
        for (const item of items) {
            if (item.type == 'document') {
                if (item.document == undefined) {
                    item.document = await this.getDocument(item.id);
                }
                maxTime = Math.max(maxTime, item.document.getUnderlyingQuipThread().updated_usec);
                continue;
            }
            const childrenLastUpdatedTime = item.children.map(c => {
                if (c.type == 'document')
                    return c.document?.getUnderlyingQuipThread()?.updated_usec || 0;
                if (c.additionalInfo.lastUpdated)
                    return c.additionalInfo.lastUpdated;
                return c.value.folder.updated_usec;
            });
            item.additionalInfo.lastUpdated = Math.max(...childrenLastUpdatedTime, item.value.folder.updated_usec);
            maxTime = Math.max(maxTime, item.additionalInfo.lastUpdated);
        }
        return maxTime;
    }
    sortChildrenRecursively(items) {
        items.sort((a, b) => {
            if (a.type == 'folder' && b.type == 'document')
                return -1;
            else if (a.type == 'document' && b.type == 'folder')
                return 1;
            else if (a.type == 'document' && b.type == 'document') {
                if (!a.metadata || !b.metadata)
                    throw new Error('metadata is undefined');
                const aUpdated = a.metadata.getUnderlyingQuipThread().updated_usec;
                const bUpdated = b.metadata.getUnderlyingQuipThread().updated_usec;
                return (aUpdated < bUpdated) ? -1 : (aUpdated > bUpdated) ? 1 : 0;
            }
            else if (a.type == 'folder' && b.type == 'folder') {
                const aUpdated = a.additionalInfo.lastUpdated || a.value.folder.updated_usec;
                const bUpdated = b.additionalInfo.lastUpdated || b.value.folder.updated_usec;
                return (aUpdated < bUpdated) ? -1 : (aUpdated > bUpdated) ? 1 : 0;
            }
            throw new Error(`Invalid type combination: ${a.type} and ${b.type}`);
        });
        for (const item of items) {
            if (item.type == 'folder')
                this.sortChildrenRecursively(item.children);
        }
    }
}

function downloadFromMemory(filename, text) {
    const element = document.createElement('a');
    element.id = "downloadFromMemory";
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', filename);
    element.style.display = 'none';
    element.click();
}

function getMiniStack(entry, max = 3) {
    const functionNames = getStack(entry).filter(si => !si[1].startsWith('[')).map(stack => stack[0]);
    return functionNames.slice(0, max);
}
function getStructuredLogs(singletons, gitHash) {
    const firstTimestamp = logger.getStartTime();
    const messages = [];
    const logEntries = logger.getLogEntries();
    for (let i = 0; i < logEntries.length; i++) {
        const entry = logEntries[i];
        const timeFromStart = convertMilissecondsToMinutesSeconds(entry.timestamp.getTime() - firstTimestamp.getTime());
        const level = entry.level;
        const msg = renderLogMessage(entry.args, null);
        const stack = getMiniStack(entry);
        const location = entry.location;
        messages.push({ timeFromStart, location, level, msg, stack });
    }
    const userAgent = navigator.userAgent;
    const version = singletons.tampermonkey.getScriptVersion();
    const tampermonkeyVersion = singletons.tampermonkey.getTampermonkeyVersion();
    const info = { gitHash, version, tampermonkeyVersion, firstTimestamp, userAgent };
    return { info, messages };
}
function sanitizeQuipApiToken(singletons, text) {
    const quipApiToken = singletons.settings.quipApiToken;
    if (!quipApiToken)
        return text;
    const sanitizedButStillStructuredToken = quipApiToken.replaceAll(/[a-zA-Z]/g, 'A').replaceAll(/[0-9]/g, '0');
    return text.replace(quipApiToken, sanitizedButStillStructuredToken);
}
function getLogForDownload(singletons, gitHash) {
    const logToCopy = getStructuredLogs(singletons, gitHash);
    return sanitizeQuipApiToken(singletons, JSON.stringify(logToCopy));
}
function getFunctionName(s, isFirefox) {
    if (isFirefox) {
        let functionName = s.split("@")[0];
        if (functionName.includes("["))
            functionName = "[anonymous]";
        return functionName;
    }
    const functionName = s.split("at ")[1].split(" (")[0];
    if (functionName.includes("://"))
        return "[anonymous]";
    return functionName.replace("<", "&lt;").replace(">", "&gt;");
}
function getLocation(s, lineNumber, isFirefox) {
    if (lineNumber === 1)
        return "[TamperMonkey code]:?:??";
    else if (lineNumber < 5)
        return "jquery.js:?:??";
    else if (lineNumber < 19)
        return "jqueryUI.js:?:??";
    if (isFirefox) {
        const startIndex = s.indexOf("Quip2Wiki.user.js");
        return s.substring(startIndex)
            .replace("?id=bf840de5-1818-4c37-8582-cf3f52ca854b", "");
    }
    let location = s
        .replace("chrome-extension://dhdgffkkebhmkfjojejmpbldmpobfkfo/userscript.html?name=", "")
        .replace("&id=37e28be2-6a4d-4503-b26d-c88ed3cdb311", "");
    if (location.includes(" ("))
        location = location.split(" (")[1];
    if (location.includes("at "))
        location = location.split("at ")[1];
    if (location.endsWith(')'))
        location = location.slice(0, location.length - 1);
    return location;
}
function getStack(entry) {
    const stack = entry.locationStackTrace.stack;
    if (!stack)
        return [];
    const isFirefox = stack.includes('@');
    return stack
        .split("\n")
        .filter(s => s.includes("Quip2Wiki.user.js"))
        .filter(s => !s.includes("_require_"))
        .slice(logger.getStackTraceEntriesToIgnore())
        .map(s => {
        const functionName = getFunctionName(s, isFirefox);
        const lineNumber = parseInt(s.replace("://", "").split(":")[1], 10);
        const location = getLocation(s, lineNumber, isFirefox);
        return [functionName, location];
    });
}

const sessionState = {
    isReproductionRun: false,
    reproductionData: {
        localStorage: {
            updates: [],
        },
        output: {},
        promptInteractions: [],
        requests: {},
        timestamps: {},
    },
    fetchRequests: [],
    requests: [],
};
class TamperMonkeyWrapper {
    getConfiguration(name, defaultValue) {
        return GM_getValue(name, defaultValue);
    }
    getRawValue(name, defaultValue) {
        return GM_getValue(name, defaultValue);
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    setRawValue(name, value) {
        if (sessionState.isReproductionRun) {
            const oldValue = this.getRawValue(name);
            if (oldValue !== value)
                sessionState.reproductionData.localStorage.updates.push({ key: name, newValue: value });
        }
        GM_setValue(name, value);
    }
    getTampermonkeyVersion() {
        return GM_info.version;
    }
    getScriptVersion() {
        return GM_info.script.version;
    }
    asyncXmlHttpRequest(request) {
        if (sessionState.isReproductionRun) {
            recordDetails(request);
        }
        return GM.xmlHttpRequest(request);
    }
    GM_xmlhttpRequest(request) {
        if (sessionState.isReproductionRun) {
            recordDetails(request);
        }
        return GM_xmlhttpRequest(request);
    }
    GM_openInTab(url, options) {
        return GM_openInTab(url, options);
    }
    GM_getResourceText(name) {
        return GM_getResourceText(name);
    }
    GM_addStyle(css) {
        GM_addStyle(css);
    }
    GM_registerMenuCommand(name, onClick, optionsOrAccessKey) {
        return GM_registerMenuCommand(name, onClick, optionsOrAccessKey);
    }
    listKeys() {
        return GM_listValues();
    }
}
function recordDetails(request) {
    const records = sessionState.requests;
    const id = records.length;
    request.context = {
        id
    };
    records.push({
        id,
        timestamp: Date.now().valueOf(),
        request,
        responseType: 'none'
    });
    const originalOnAbort = request.onabort;
    const originalOnError = request.onerror;
    const originalOnLoad = request.onload;
    const originalOnTimeout = request.ontimeout;
    if (originalOnAbort) {
        request.onabort = () => {
            records[id].responseType = 'abort';
            originalOnAbort();
        };
    }
    if (originalOnError) {
        request.onerror = function (response) {
            const original = records[id];
            records[id] = {
                ...original,
                responseType: 'error',
                errorResponse: response,
            };
            originalOnError.call(response, response);
        };
    }
    if (originalOnLoad) {
        request.onload = function (response) {
            const original = records[id];
            records[id] = {
                ...original,
                responseType: 'load',
                response: copyResponse(response),
            };
            originalOnLoad.call(response, response);
        };
    }
    if (originalOnTimeout) {
        request.ontimeout = () => {
            records[id].responseType = 'timeout';
            originalOnTimeout();
        };
    }
}
function copyResponse(r) {
    // The logic for the responseType below was defined via trial and error, observing various
    // responses in the browser debugger, with the following watch expression:
    // [(typeof r.response),(r.response instanceof Blob),(r.response.type)]
    const isBlob = r.response instanceof Blob;
    const responseType = isBlob ? 'blob' :
        typeof r.response === 'object' ? 'json' : 'text';
    const isUpdateUrl = UPDATE_CHECK_URL.includes(r.finalUrl);
    // This function copies the Tampermonkey response to a plain object so the response content can be properly serialized
    return {
        finalUrl: r.finalUrl,
        status: r.status,
        statusText: r.statusText,
        responseHeaders: r.responseHeaders,
        responseText: isBlob ? btoa(r.responseText) : (isUpdateUrl ? '[removed]' : r.responseText),
        responseFormat: responseType,
        blobType: isBlob ? r.response.type : undefined,
    };
}

function parseVersion(version) {
    const versionPattern = /(\d+)\.(\d+)(?:\.(\d+)(?:[.-](\d+))?)?(-test)?/g;
    const match = versionPattern.exec(version);
    if (!match) {
        throw 'No version matched';
    }
    const isBeta = !!match[4];
    const isTest = !!match[5];
    const stage = isTest ? 'test' :
        isBeta ? 'beta' :
            'prod';
    return {
        major: parseInt(match[1], 10),
        minor: parseInt(match[2], 10),
        release: parseInt(match[3], 10),
        testRelease: (match[4] ? parseInt(match[4], 10) : null),
        stage: stage,
        version: match[0],
    };
}
/**
 * Compares two version structures:
 * - Returns -1 if 'v1' is newer than 'v2'
 * - Returns  0 if 'v1' equals 'v2'
 * - Returns +1 if 'v1' is older than 'v2'
 */
function compareVersions(v1, v2, compareTestRelease = false) {
    if (!v1 || !v2) {
        return v1 ? -1 : 1;
    }
    else if (v1.major !== v2.major) {
        return v1.major > v2.major ? -1 : 1;
    }
    else if (v1.minor !== v2.minor) {
        return v1.minor > v2.minor ? -1 : 1;
    }
    else if (v1.release !== v2.release) {
        return v1.release > v2.release ? -1 : 1;
    }
    else if (compareTestRelease && v1.testRelease !== v2.testRelease) {
        return (v1.testRelease || 0) > (v2.testRelease || 0) ? -1 : 1;
    }
    else {
        return 0;
    }
}

function showTokenPage(singletons) {
    logger.log("[src/quip/Utils.ts:6:5]", 'Opening token page');
    return singletons.tampermonkey.GM_openInTab(TOKEN_PAGE_URL, { active: true });
}

const EMPTY_STRING = "";

/**
 * Shows a modal alert dialog with an OK button.
 */
async function showAlert(singletons, title, text, width, height) {
    const buttons = { OK: true };
    return await showDialog(singletons, title, text, buttons);
}
function getVersionInfo(singletons) {
    const en_dash = "–";
    if (!state.latestVersion)
        return ` [v${singletons.session.version}]`;
    const currentVersion = parseVersion(singletons.session.version);
    const versionComparison = compareVersions(currentVersion, state.latestParsedVersion);
    if (versionComparison === 0)
        return ` [v${singletons.session.version} ${en_dash} latest version]`;
    if (versionComparison === -1)
        return ` [v${singletons.session.version} ${en_dash} dev version]`;
    return ` [v${singletons.session.version} ${en_dash} NOT LATEST VERSION]`;
}
function registerClick(e) {
    if (e.target instanceof HTMLElement) {
        sessionState.reproductionData.promptInteractions.push({ k: e.target.textContent || "NO_TEXT", v: undefined });
    }
    else {
        sessionState.reproductionData.promptInteractions.push({ k: "UNKNOWN", v: undefined });
    }
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function registerClickAndValue(key, value) {
    if (sessionState.isReproductionRun)
        sessionState.reproductionData.promptInteractions.push({ k: key, v: value });
}
// this function makes sure every button will close the dialog, return its given value
function makeCompliantButtons(buttons, res) {
    return Object.entries(buttons)
        .map(([key, value]) => {
        return {
            text: key,
            click: function () {
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                let returnValue;
                if (typeof (value) == "function") {
                    returnValue = value();
                }
                else {
                    returnValue = value;
                }
                registerClickAndValue(key, returnValue);
                res(returnValue);
                $(this).dialog('close');
            }
        };
    });
}
function escapeNewLines(text) {
    return text.replace('\n', '<br/>');
}
/**
 * Shows a modal dialog with customized buttons and return values.
 * @param singletons Singleton object cache
 * @param {string} title dialog title
 * @param {string} text dialog message to be displayed
 * @param {*} buttons object that describes the button label (key) and its return value (value)
 * @param {*} width (optional) dialog width in pixels. Set to null for automatic.
 * @param {*} height (optional) dialog height in pixels. Set to null for automatic.
 */
async function waitForDialogResult(singletons, title, text, buttons, width, height) {
    const titleWithVersionInfo = title + getVersionInfo(singletons);
    return await new Promise((res) => {
        const dialogHtml = `
<div class="q2w-dialog" id="jquery-dialog" "style="word-wrap: normal; white-space: normal">
<p>${escapeNewLines(text)}</p>
</div>`;
        const dialogOptions = {
            closeText: "",
            draggable: false,
            height: 'auto',
            width: 'auto',
            modal: true,
            resizable: false,
            title: titleWithVersionInfo,
            buttons: makeCompliantButtons(buttons, res)
        };
        createCompliantModal(singletons, dialogHtml, dialogOptions, function (event) {
            if (!(event.target instanceof HTMLElement))
                return;
            // maxWidth won't work so we set in the css
            {
                $(this).css("maxWidth", "1200px");
            }
            fixCloseButtonIcon(event.target);
        }, function () {
            // Highlight last button
            $(this)
                .next()
                .find('button:last')
                .addClass('ui-priority-primary');
        }, undefined, function () {
            $(this).dialog('destroy').remove();
            res(undefined);
        });
    });
}
/**
 * Shows a modal dialog with customized buttons and return values.
 * @param singletons Singleton object cache
 * @param {string} title dialog title
 * @param {string} text dialog message to be displayed
 * @param {*} buttons object that describes the button label (key) and its return value (value)
 * @param {*} width (optional) dialog width in pixels. Set to null for automatic.
 * @param {*} height (optional) dialog height in pixels. Set to null for automatic.
 */
async function showDialog(singletons, title, text, buttons, width, height) {
    const titleWithVersionInfo = title + getVersionInfo(singletons);
    return await new Promise((res) => {
        // make sure every button will close the dialog and return its given value
        const dialog_buttons = {};
        Object.entries(buttons).forEach(([key, value]) => {
            dialog_buttons[key] = {
                text: key,
                click: function (e) {
                    if (e && sessionState.isReproductionRun) {
                        registerClick(e);
                    }
                    if (typeof (value) == "function") {
                        res(value()); // evaluate function and return button value
                    }
                    else {
                        res(value); // returns button value
                    }
                    $(this).dialog('close');
                }
            };
        });
        // open the dialog
        $(`<div class="q2w-dialog" id="jquery-dialog" "style="word-wrap: normal; white-space: normal"><p>${text.replace(/\n/g, '<br/>')}</p></div>`).dialog({
            open: function () {
                // make last button highlighted
                $(this)
                    .next()
                    .find('button:last')
                    .addClass('ui-priority-primary');
            },
            close: function () {
                $(this).dialog('destroy').remove();
                res(undefined);
            },
            closeText: "",
            draggable: false,
            height: 'auto',
            width: 'auto',
            modal: true,
            resizable: false,
            title: titleWithVersionInfo,
            create: function (event) {
                if (!(event.target instanceof HTMLElement))
                    return;
                // maxWidth won't work so we set in the css
                {
                    $(this).css("maxWidth", "1200px");
                }
                fixCloseButtonIcon(event.target);
            },
            buttons: dialog_buttons
        });
    });
}
async function promptForNewWikiAddress(singletons, suggAddr, wikiClient) {
    const addr = await promptForWikiAddress(singletons, suggAddr);
    if (addr == null) {
        return null;
    }
    return await promptForExistingWikiAddressConfirmation(singletons, addr, wikiClient) ? addr : null;
}
async function promptForExistingWikiAddress(singletons, addr, docType, wikiClient) {
    while (true) {
        const title = state.appTitle;
        const url = VIEW_URL + addr;
        const msg = `The Quip ${docType} will be exported to the following Wiki page:<br/><br/>
                        <span style="text-decoration:underline; font-style:italic;"><a href="${url}" target="_blank" rel="noopener">${url}</a></span>`;
        const buttons = {
            "Cancel": null,
            "Change address": false,
            "Export to Wiki": true
        };
        const result = await showDialog(singletons, title, msg, buttons);
        if (result === true) {
            return addr;
        }
        else if (result === false) {
            const newAddr = await promptForWikiAddress(singletons, addr);
            if (addr != null && newAddr != null && addr !== newAddr) {
                return await promptForExistingWikiAddressConfirmation(singletons, newAddr, wikiClient) ? newAddr : null;
            }
        }
        else {
            return null;
        }
    }
}
async function promptForChangedWikiConfirmation(singletons, addr) {
    const url = VIEW_URL + addr;
    const msg = `The destination page "<span style="text-decoration:underline; font-style:italic;"><a href="${url}" target="_blank" rel="noopener">${addr}</a></span>" has changed since last export.<br/><br/>
                    If you proceed, THE CURRENT PAGE CONTENT WILL BE OVERWRITTEN!!<br/><br/>
                    Are you sure you want to continue?`;
    const buttons = { 'Cancel': false, 'Overwrite': true };
    return await showDialog(singletons, state.appTitle, msg, buttons);
}
async function promptForWikiAddress(singletons, suggAddr) {
    let addr = setUpperCaseFirstLetter(suggAddr);
    while (true) {
        const promptMsg = 'Please provide a wiki path or url to finish export' +
            '\nExamples:' +
            '\n- Quip2Wiki' +
            '\n- Quip2Wiki/Description' +
            '\n' +
            '\n- https://w?Quip2Wiki' +
            '\n- https://w.amazon.com/bin/view/Quip2Wiki' +
            '\n- https://w.amazon.com/bin/view/Quip2Wiki/Description';
        const result = window.prompt(promptMsg, addr);
        if (result == null) {
            return null;
        }
        const relAddr = extractWikiRelativeAddr(result);
        if (!relAddr) {
            await showAlert(singletons, state.appTitle, `The address is not valid!`);
            continue;
        }
        addr = relAddr;
        const isInvalid = /^(https?:\/\/|w\.amazon\.com)/.test(addr);
        if (isInvalid) {
            await showAlert(singletons, state.appTitle, `The address is not valid!`);
            continue;
        }
        else if (addr.length <= 3) {
            await showAlert(singletons, state.appTitle, `The address should be longer than 3 characters!`);
            continue;
        }
        addr = setUpperCaseFirstLetter(addr);
        const fullUrl = VIEW_URL + addr;
        const msg = `You are about to create the following Wiki page:<br/><b><i>${fullUrl}</i></b><br/>This is a "root" page, and it is NOT recommended to create root pages.`;
        const buttons = { 'Cancel': null, 'Proceed Anyway': true };
        if (addr.includes('/') || await showDialog(singletons, state.appTitle, msg, buttons)) {
            return encodeURI(addr);
        }
    }
}
async function promptForAttachmentConfirmation(singletons, attachmentName, blob, limit) {
    const limitStr = formatBytes(limit);
    const sizeStr = formatBytes(blob.size);
    let suggestion;
    const isSupportedImage = IMAGE_FORMATS.some((type) => blob.type.includes(type)) || blob.type.startsWith('image');
    if (isSupportedImage) {
        suggestion = 'Consider re-uploading a scaled down version of the image to reduce its size or let Quip2Wiki do it for you.';
    }
    else {
        suggestion = 'Consider uploading to <span style="text-decoration:underline; font-style:italic;"><a href="https://drive.corp.amazon.com/" target="_blank" rel="noopener">Drive</a></span> or <span style="text-decoration:underline; font-style:italic;"><a href="https://amazon.awsapps.com/workdocs" target="_blank" rel="noopener">Workdocs</a></span> and providing the shareable link in your document.';
    }
    const msg = `The attachment '<b>${attachmentName}</b>' size (${sizeStr}) <br/>is <b>too large</b> and above the ${limitStr} limit imposed by Amazon Wiki.<br/><br/>${suggestion}`;
    const buttons = { 'Abort': 'abort', 'Link to Quip': 'link' };
    if (isSupportedImage) {
        buttons['Resize Image'] = 'resize';
    }
    return await showDialog(singletons, state.appTitle, msg, buttons);
}
/**
 * Recursively builds the HTML for the folder tree with checkboxes
 */
function buildFolderTreeHtml(wrapper, dialogId, depth = 0) {
    const indent = '&nbsp;'.repeat(depth * 4);
    const itemId = `${dialogId}-item-${wrapper.id.replace(/[^a-zA-Z0-9]/g, '-')}`;
    let html = '';
    if (wrapper.type === 'folder') {
        const folderWrapper = wrapper;
        const folderTitle = folderWrapper.value?.folder?.title || 'Untitled Folder';
        html += `
      <div class="tree-item folder-item" data-id="${wrapper.id}" data-type="folder">
        ${indent}<input type="checkbox" id="${itemId}" checked>
        <label for="${itemId}"><span class="folder-icon">📁</span> ${folderTitle}</label>
        <div class="folder-children" style="margin-left: 20px;">`;
        // Recursively add children
        if (folderWrapper.children && folderWrapper.children.length > 0) {
            for (const child of folderWrapper.children) {
                html += buildFolderTreeHtml(child, dialogId, depth + 1);
            }
        }
        html += `
        </div>
      </div>`;
    }
    else if (wrapper.type === 'document') {
        const docWrapper = wrapper;
        // Try to get the title from different possible sources
        let docTitle = 'Untitled Document';
        if (docWrapper.metadata && docWrapper.metadata.title) {
            docTitle = docWrapper.metadata.title;
        }
        html += `
      <div class="tree-item document-item" data-id="${wrapper.id}" data-type="document">
        ${indent}<input type="checkbox" id="${itemId}" checked>
        <label for="${itemId}"><span class="document-icon">📄</span> ${docTitle}</label>
      </div>`;
    }
    return html;
}
/**
 * Creates a new folder wrapper containing only the selected items
 * Ensures that parent folders of selected items are always included
 */
function createFilteredFolderWrapper(originalWrapper, dialogId) {
    // Create a deep copy of the original wrapper
    const filteredWrapper = {
        type: 'folder',
        id: originalWrapper.id,
        value: originalWrapper.value,
        additionalInfo: originalWrapper.additionalInfo,
        wikiAddr: originalWrapper.wikiAddr,
        children: []
    };
    // Check if this folder has any selected children (direct or nested)
    let hasSelectedChildren = false;
    // Filter children based on checkbox selection
    if (originalWrapper.children && originalWrapper.children.length > 0) {
        for (const child of originalWrapper.children) {
            const childId = `${dialogId}-item-${child.id.replace(/[^a-zA-Z0-9]/g, '-')}`;
            const isSelected = $(`#${childId}`).prop('checked');
            if (isSelected) {
                hasSelectedChildren = true;
                if (child.type === 'folder') {
                    // Recursively filter folder children
                    const folderChild = child;
                    const filteredFolderChild = createFilteredFolderWrapper(folderChild, dialogId);
                    // Only add the folder if it has children after filtering
                    if (filteredFolderChild.children.length > 0) {
                        filteredWrapper.children.push(filteredFolderChild);
                    }
                }
                else {
                    // Add document as is
                    filteredWrapper.children.push(child);
                }
            }
            else if (child.type === 'folder') {
                // Even if this folder is not selected, check if it has any selected descendants
                const folderChild = child;
                const filteredFolderChild = createFilteredFolderWrapper(folderChild, dialogId);
                // If the folder has selected descendants, include it
                if (filteredFolderChild.children.length > 0) {
                    hasSelectedChildren = true;
                    filteredWrapper.children.push(filteredFolderChild);
                }
            }
        }
    }
    // If this folder has no selected children (direct or nested), return an empty wrapper
    // This will cause it to be excluded from the parent's children array
    if (!hasSelectedChildren && originalWrapper.id !== filteredWrapper.id) {
        filteredWrapper.children = [];
    }
    return filteredWrapper;
}
/**
 * Shows a dialog that allows users to select files and folders from a given folder wrapper.
 * Returns a new folder wrapper containing only the selected items.
 *
 * @param {SingletonsT} singletons Singleton object cache
 * @param {FolderWrapper} folderWrapper The folder wrapper containing files and folders to select from
 * @returns {Promise<FolderWrapper | null>} A new folder wrapper with only selected items, or null if cancelled
 */
async function promptForFolderSelection(singletons, folderWrapper) {
    // Create a unique ID for this dialog instance
    const dialogId = `folder-selection-dialog-${Date.now()}`;
    // Build the HTML for the dialog
    const dialogHtml = `
  <div class="q2w-dialog" id="${dialogId}" style="word-wrap: normal; white-space: normal">
    <p>Select files and folders to include:</p>
    <div style="max-height: 400px; overflow-y: auto; border: 1px solid #ccc; padding: 10px; margin-bottom: 10px;">
      <div id="${dialogId}-tree" class="folder-selection-tree">
        <!-- Tree items will be inserted here dynamically -->
      </div>
    </div>
    <div style="margin-top: 10px;">
      <button id="${dialogId}-select-all" class="ui-button ui-corner-all ui-widget">Select All</button>
      <button id="${dialogId}-deselect-all" class="ui-button ui-corner-all ui-widget">Deselect All</button>
    </div>
  </div>`;
    // Build the tree HTML
    const treeHtml = buildFolderTreeHtml(folderWrapper, dialogId);
    // Create a promise that will be resolved when the dialog is closed
    return new Promise((resolve) => {
        // Flag to track if selection was confirmed
        let selectionConfirmed = false;
        // Create the dialog
        $(dialogHtml).dialog({
            title: 'Select Files and Folders',
            width: 600,
            height: 500,
            modal: true,
            closeText: "",
            buttons: {
                'Cancel': function () {
                    $(this).dialog('close');
                    resolve(null);
                },
                'Confirm Selection': function () {
                    // Count selected document checkboxes
                    const selectedDocumentCount = $(`#${dialogId} .document-item input[type="checkbox"]:checked`).length;
                    // Get selected items and create a new folder wrapper
                    const selectedWrapper = createFilteredFolderWrapper(folderWrapper, dialogId);
                    // Add the count as a property to the wrapper
                    selectedWrapper.numberOfItems = selectedDocumentCount;
                    selectionConfirmed = true;
                    $(this).dialog('close');
                    resolve(selectedWrapper);
                }
            },
            create: function (event) {
                if (!(event.target instanceof HTMLElement))
                    return;
                fixCloseButtonIcon(event.target);
            },
            open: function () {
                // Insert the tree HTML
                $(`#${dialogId}-tree`).html(treeHtml);
                // Set up event handlers for Select All and Deselect All buttons
                $(`#${dialogId}-select-all`).on('click', function () {
                    $(`#${dialogId} input[type="checkbox"]`).prop('checked', true);
                });
                $(`#${dialogId}-deselect-all`).on('click', function () {
                    $(`#${dialogId} input[type="checkbox"]`).prop('checked', false);
                });
                // Set up event handlers for parent-child checkbox relationships
                $(`#${dialogId} .folder-item > input[type="checkbox"]`).on('change', function () {
                    const isChecked = $(this).prop('checked');
                    $(this).closest('.folder-item').find('.folder-children input[type="checkbox"]').prop('checked', isChecked);
                });
            },
            close: function () {
                $(this).dialog('destroy').remove();
                // Only resolve with null if selection was not confirmed
                if (!selectionConfirmed) {
                    resolve(null);
                }
            }
        });
    });
}
async function showWikiInSyncDialoig(singletons, wikiLink, docType = 'document') {
    const detailLink = `(<span style="text-decoration:underline; font-style:italic;"><a href="${IN_SYNC_FAQ_URL}" target="_blank" rel="noopener">more details</a></span>)`;
    return await showDialog(singletons, state.appTitle, `Quip ${docType} is already in sync with Amazon Wiki. Nothing to export. ${detailLink}<br/><br/>${wikiLink}`, {
        "Export anyway": true,
        "Cancel": false
    });
}
/**
 * Set first letter to upper case, as wiki seems to prefer page addresses that way.
 */
function setUpperCaseFirstLetter(addr) {
    if (addr.length === 1) {
        return addr.charAt(0).toUpperCase();
    }
    else if (addr.length > 1) {
        return addr.charAt(0).toUpperCase() + addr.slice(1);
    }
    else {
        return addr;
    }
}
/**
 * Shows a confirmation dialog if the Wiki page already exists.
 * @returns true if page does not exist or the user confirmed the prompt
 */
async function promptForExistingWikiAddressConfirmation(singletons, wikiAddr, wikiClient) {
    const exists = await wikiClient.wikiPageExists(wikiAddr);
    if (!exists) {
        return true;
    }
    const url = VIEW_URL + wikiAddr;
    const msg = `The page "<span style="text-decoration:underline; font-style:italic;"><a href="${url}" target="_blank" rel="noopener">${wikiAddr}</a></span>" already exists.<br/><br/>
                     If you proceed, THE CURRENT PAGE CONTENT WILL BE OVERWRITTEN!!<br/><br/>
                     Are you sure you want to continue?`;
    const buttons = { 'Cancel': false, 'Export to Wiki': true };
    return await showDialog(singletons, state.appTitle, msg, buttons);
}
// /**
//  * Shows a modal dialog with customized buttons and return values.
//  * @param {string} title dialog title
//  * @param {string} text dialog message to be displayed
//  * @param {*} buttons object that describes the button label (key) and its return value (value)
//  * @param {*} width (optional) dialog width in pixels. Set to null for automatic.
//  * @param {*} height (optional) dialog height in pixels. Set to null for automatic.
//  */
// export function showExportFolderForm(input, width, height) {
//     return new Promise((res, rej) => {
//         // open the dialog
//         $(`<div id="jquery-form" "style="word-wrap: normal; white-space: normal">
//                <p>Please inform the wiki page (relative or full address) of the Quip folder to be exported:<br/>
//                <span style="font-size:x-small; bgcolor:#444; border-width:2px">
//                Examples:
//                <ul>
//                 <li>Quip2Wiki</li>
//                 <li>Quip2Wiki/Description</li>
//                 <li>https://w?Quip2Wiki</li>
//                 <li>https://w.amazon.com/bin/view/Quip2Wiki</li>
//                 <li>https://w.amazon.com/bin/view/Quip2Wiki/Description</li>
//                </ul></span></p>
//                <p><label for="wikiAddr">Wiki Address </label><input id="wikiAddr" type="text" size="65"/></p>
//                <p><table border="0" width="auto"><tr>
//                  <td><label>Sorting Field </label><select id="sortType" name="sortType" size="7">
//                    <option value="title">Title</option>
//                    <option value="updated_usec">Update date</option>
//                    <option value="created_usec">Create date</option>
//                    <option value="type">Item type</option>
//                  </select></td>
//                  <td><label for="sortOrder">Sorting Order </label><select id="sortOrder" name="sortOrder" size="5">
//                    <option value="asc">Ascending</option>
//                    <option value="desc">Descending</option>
//                  </select></td>
//                </tr></table></p>
//                <hr>
//                <p style="font-size:x-small"><input id="askAgain" type="checkbox"> Don't ask again</input></p>
//                </div>`).dialog({
//             open: function () {
//                 // make last button highlighted
//                 $(this)
//                     .next()
//                     .find('button:last')
//                     .addClass('ui-priority-primary');
//
//                 $('#wikiAddr').val(input.wikiUrl || '');
//                 $('#sortType').val(input.sortType || 'title');
//                 $('#sortType').selectmenu();
//                 $('#sortOrder').val(input.sortOrder || 'asc');
//                 $('#sortOrder').selectmenu();
//                 $('#askAgain').prop('checked', input.askAgain);
//             },
//             close: function (event, ui) {
//                 res(undefined); // in case user used the close button
//                 $(this).dialog('destroy').remove();
//             },
//             title: state.appTitle,
//             modal: true,
//             width: width ? width : 'auto',
//             height: height ? height : 'auto',
//             create: function (event, ui) {
//                 // maxWidth won't work so we set in the css
//                 if (!width) {
//                     $(this).css("maxWidth", "1200px");
//                 }
//             },
//             buttons: {
//                 cancelBtn: {
//                     text: 'Cancel',
//                     click: function () {
//                         res(null); // returns button value
//                         $(this).dialog('close');
//                     }
//                 },
//                 exportBtn: {
//                     text: 'Export to Wiki',
//                     click: function () {
//                         const wikiAddrField = $('#wikiAddr');
//                         if (!wikiAddrField.val()) {
//                             wikiAddrField.addClass('ui-state-error');
//                             return;
//                         } else {
//                             wikiAddrField.removeClass('ui-state-error');
//                         }
//                         const sortTypeValue = $('#sortType option:selected').attr('value');
//                         const sortOrderValue = $('#sortOrder option:selected').attr('value');
//                         const askAgainChecked = $('#askAgain').prop('checked');
//                         res({
//                             wikiAddr: wikiAddrField.val(),
//                             sortType: sortTypeValue,
//                             sortOrder: sortOrderValue,
//                             askAgain: askAgainChecked
//                         });
//                         $(this).dialog('close');
//                     }
//                 }
//             }
//         });
//     });
// }
function fixCloseButtonIcon(modalContentElement) {
    if (!modalContentElement)
        return;
    const dialog = modalContentElement.parentElement;
    if (!dialog)
        return;
    const closeButton = dialog.querySelector(".ui-button");
    if (!closeButton)
        return;
    if ($(closeButton).hasClass("ui-button-icon-only")) {
        $(closeButton).toggleClass("ui-button-icon-only");
        const closeIconSpan = document.createElement("span");
        closeIconSpan.innerHTML = "&#10006;"; // or &#x2715;
        $(closeButton).prepend(closeIconSpan);
    }
}
function updateMinimizeButton(modalContentElement) {
    const dialog = modalContentElement.parentElement;
    if (!dialog)
        return;
    // remove original, unavailable, close icon if it exists
    const closeButton = dialog.querySelector(".ui-button");
    if (!closeButton)
        return;
    if ($(closeButton).hasClass("ui-button-icon-only")) {
        $(closeButton).toggleClass("ui-button-icon-only");
    }
    // remove all children
    $(closeButton).empty();
    // create the correct icon
    const isMinimized = $(modalContentElement).css("display") == "none";
    const iconSpan = document.createElement("span");
    iconSpan.innerHTML = isMinimized ? "&square;" : "&#95;"; // or &#x2715;
    $(closeButton).prepend(iconSpan);
    // replace the click event
    $(closeButton).off("click");
    $(closeButton).on("click", (e) => {
        if (e && sessionState.isReproductionRun) {
            registerClick(e);
        }
        if (isMinimized) {
            $(modalContentElement).css("display", "block");
        }
        else {
            $(modalContentElement).css("display", "none");
        }
        // update the position of the dialog
        const position = $(modalContentElement).dialog("option", "position");
        $(modalContentElement).dialog("option", "position", position);
        updateMinimizeButton(modalContentElement);
    });
}
function highlightLastButton(target) {
    $(target)
        .next()
        .find('button:last')
        .addClass('ui-priority-primary');
}
let modalsOpened = 0;
function bringBackdropUp(target) {
    if (!target.parentElement)
        return;
    const offset = 2 * modalsOpened;
    const overlay = $(".ui-widget-overlay");
    overlay.css("z-index", 400 + offset);
    $(target.parentElement).css("z-index", 401 + offset);
}
function bringBackdropDown() {
    const offset = 2 * modalsOpened;
    const overlay = $(".ui-widget-overlay");
    overlay.css("z-index", 400 + offset);
}
function createCompliantModal(singletons, html, options, onCreate, onOpen, onFocus, onClose) {
    const hasPosition = options.position !== undefined;
    const defaultOptions = {
        closeText: "",
        draggable: false,
        height: 'auto',
        width: 'auto',
        modal: true,
        resizable: false,
        title: "Quip2Wiki dialog" + getVersionInfo(singletons),
        create: function (event, ui) {
            if (!(event.target instanceof HTMLElement))
                return;
            // maxWidth JQueryUI property doesn't work so we set it in the CSS
            $(this).css("maxWidth", "900px");
            fixCloseButtonIcon(event.target);
            if (onCreate)
                onCreate(event, ui);
        },
        open: function (event, ui) {
            if (!(event.target instanceof HTMLElement))
                return;
            modalsOpened += 1;
            bringBackdropUp(event.target);
            if (onOpen)
                onOpen(event, ui);
            if (!hasPosition) {
                setTimeout(() => {
                    $(event.target).dialog("option", "position", {
                        my: "center",
                        at: "center",
                        of: window
                    });
                }, 50);
            }
        },
        focus: function (event, ui) {
            if (!(event.target instanceof HTMLElement))
                return;
            highlightLastButton(event.target);
            if (onFocus)
                onFocus(event, ui);
        },
        close: function (event, ui) {
            modalsOpened -= 1;
            bringBackdropDown();
            if (onClose)
                onClose(event, ui);
        }
    };
    const mixedOptions = { ...defaultOptions, ...options };
    if (options.title && !options.title.includes("[")) {
        mixedOptions.title = options.title + getVersionInfo(singletons);
    }
    $(html).dialog(mixedOptions);
}
function createTemporaryModal(singletons, html, options, onCreate, onOpen, onFocus, onClose) {
    createCompliantModal(singletons, html, options, onCreate, onOpen, onFocus, function (event, ui) {
        if (!(event.target instanceof HTMLElement))
            return;
        if (onClose)
            onClose(event, ui);
        $(event.target).dialog('close');
        $(event.target).dialog('destroy');
    });
}
function showLogModal(singletons) {
    const existingModal = $("#q2w-log-modal");
    if (existingModal.get(0)) {
        existingModal.dialog("open");
        return;
    }
    const logHtml = `<div class="q2w-dialog" "style="word-wrap: normal; white-space: normal" id="q2w-log-modal">
  <div>
    <p>Log started at <b id="q2w-log-start-time">???</b></p>
  </div>
  <div style="height:200px; overflow-y: scroll; width: 640px; background-color:white;">
    <table style="table-layout: fixed;">
        <thead>
            <tr>
                <th style="width: 70px; font-weight: bold; text-align: center;">Time</th>
                <th style="width: 60px; font-weight: bold; text-align: center;">Level</th>
                <th style="width: 430px; font-weight: bold;">Message</th>
                <th style="width: 80px;"></th>
            </tr>
        </thead>
        <tbody id="q2w-log-receiver"></tbody>
        </div>
    </table>
  </div>
</div>`;
    const options = {
        title: "Quip2Wiki log",
        buttons: [
            {
                text: "Update Quip Token",
                click: function () {
                    createQuipTokenModal(singletons);
                }
            },
            {
                text: "Copy log to clipboard",
                click: function () {
                    navigator.clipboard.writeText(getLogForDownload(singletons, GIT_HASH));
                }
            },
            {
                text: "Download log",
                click: function () {
                    downloadFromMemory("Quip2Wiki.log.txt", getLogForDownload(singletons, GIT_HASH));
                }
            },
            {
                text: "Close",
                click: function () {
                    $(this).dialog("close");
                }
            }
        ]
    };
    createCompliantModal(singletons, logHtml, options, function () {
        const callbackIndex = logger.getNextCallbackIndex();
        const logEntries = logger.getLogEntries();
        for (let i = 0; i < logEntries.length; i++) {
            const entry = logEntries[i];
            logModalCallback(singletons, entry, callbackIndex, false);
        }
        logger.addLogCallback((entry, index, focus) => logModalCallback(singletons, entry, index, focus));
    }, function () {
        if (logger.getLogEntries().length > 0)
            $("#q2w-log-start-time").text(logger.getStartTime().toString());
    }, function () {
        if (logger.getLogEntries().length > 0)
            $("#q2w-log-start-time").text(logger.getLogEntries()[0].timestamp.toString());
        const lastChild = $("#q2w-log-receiver").children().last().get(0);
        if (lastChild)
            lastChild.scrollIntoView();
    });
}
async function returnResultWhenDialogCloses(action, defaultReturn) {
    return await new Promise((resolve, reject) => {
        let returnValue = defaultReturn;
        try {
            action((v) => {
                returnValue = v;
            }, () => {
                setTimeout(() => {
                    resolve(returnValue);
                }, 100);
            });
        }
        catch (e) {
            reject(e);
        }
    });
}
function createAlert(singletons, title, message, width = 'auto', onConfirmation, onDestroy) {
    const html = `
<div>
    <p>${message}</p>
</div>`;
    createCompliantModal(singletons, html, {
        title,
        width,
        buttons: [
            {
                text: 'OK',
                click: function () {
                    $(this).dialog("close");
                }
            }
        ]
    }, undefined, undefined, undefined, function () {
    });
}
async function createQuipTokenPrompt(singletons, message) {
    return await returnResultWhenDialogCloses((resolver, onDestroy) => {
        createQuipTokenModal(singletons, message, () => resolver('NEW_TOKEN'), () => resolver('USER_CANCELED'), () => onDestroy());
    }, 'UNKNOWN');
}
function createQuipTokenModal(singletons, message = undefined, onSubmit, onCancel, onDestroy) {
    const messageParagraph = message == undefined ? EMPTY_STRING : `<p style="color: darkred;">${message}</p>`;
    const quipTokenInputHtml = `
<div id="q2w-get-quip-token-modal">
    ${messageParagraph}
    <div style="display: flex; align-items: center;">
        <span style="margin-right: 5px;">Quip API Token:</span>
        <input id="q2w-get-quip-token-override" type="text" style="width: 640px">
    </div>
    <div>
        <span id="q2w-get-quip-token-error-message" style="color: darkred; margin-left: 108px;"></span>
    </div>
    <p><i>If necessary, you can open the Quip API Token page using the button below.<br>
    Please copy the token you generate there, come back and submit the new token in this dialog.</i></p>
</div>`;
    function setErrorMessage(message) {
        const errorMessageElement = document.getElementById("q2w-get-quip-token-error-message");
        if (!errorMessageElement)
            return;
        errorMessageElement.innerHTML = message;
    }
    const existingToken = singletons.settings.quipApiToken;
    let submitTries = 0;
    createTemporaryModal(singletons, quipTokenInputHtml, {
        title: "Configure Quip API token",
        buttons: [
            {
                text: "Open Quip API token page",
                click: async function () {
                    showTokenPage(singletons);
                    setTimeout(() => {
                        const inputElement = document.getElementById('q2w-get-quip-token-override');
                        if (!(inputElement instanceof HTMLInputElement))
                            return;
                        inputElement.focus();
                    }, 100);
                }
            },
            {
                text: 'Submit token',
                click: function () {
                    const inputElement = document.getElementById('q2w-get-quip-token-override');
                    if (!(inputElement instanceof HTMLInputElement))
                        return;
                    const token = inputElement.value;
                    if (!token) {
                        setErrorMessage("Quip API token is mandatory");
                        return;
                    }
                    if (token === existingToken && submitTries < 5) {
                        submitTries += 1;
                        setErrorMessage(`Please click button <b>Open Quip API token page</b>, generate a new token and replace the current token before submitting`);
                        return;
                    }
                    if (token !== singletons.settings.quipApiToken) {
                        // save token
                        singletons.settings.quipApiToken = token;
                    }
                    onSubmit?.();
                    $(this).dialog("close");
                }
            },
            {
                text: 'Cancel',
                click: function () {
                    onCancel?.();
                    $(this).dialog("close");
                }
            }
        ]
    }, function () {
        // onCreate
        const inputElement = document.getElementById('q2w-get-quip-token-override');
        if (!(inputElement instanceof HTMLInputElement))
            throw new Error("Input element is null when the Quip API token modal is created");
        const oldToken = singletons.settings.quipApiToken || '';
        if (oldToken)
            inputElement.value = oldToken;
        function quickCheckQuipApiToken() {
            const inputElement = document.getElementById('q2w-get-quip-token-override');
            if (!(inputElement instanceof HTMLInputElement))
                return;
            const newValue = inputElement.value;
            if (newValue.length == 0)
                setErrorMessage("Quip API token is mandatory");
            if (looksLikeAQuipToken(newValue))
                setErrorMessage("");
            else
                setErrorMessage("This doesn't look like a Quip API token...");
        }
        inputElement.addEventListener('change', () => quickCheckQuipApiToken());
        inputElement.addEventListener('keydown', () => {
            submitTries = 0;
            setTimeout(() => {
                quickCheckQuipApiToken();
            }, 20);
        });
        inputElement.focus();
    }, undefined, // onOpen
    undefined, // onFocus
    function () {
        // onClose
        onDestroy?.();
    });
}
function looksLikeAQuipToken(s) {
    return s && s.length >= 30 && s.includes('=|');
}
function logModalCallback(singletons, entry, callbackIndex, forceFocus) {
    const logReceiver = $("#q2w-log-receiver");
    if (logReceiver) {
        //let message = `${entry.timestamp} [${entry.level}] ${entry.args}`;// at ${entry.stack}`;
        const timeFromStart = convertMilissecondsToMinutesSeconds(entry.timestamp.getTime() - logger.getLogEntries()[0].timestamp.getTime());
        const entryId = `${entry.id}-${callbackIndex}`;
        const btnId = `${entry.id}-btn-${callbackIndex}`;
        const renderedEntry = `<tr id="${entryId}">
<td style="text-align: center;">${timeFromStart}</td>
<td style="text-align: center;">${entry.level}</td>
<td style="word-wrap: anywhere; padding-bottom: 2px;">${sanitizeTags(renderLogMessage(entry.args))}</td>
<td><span id="${btnId}" style="color: #4e7cc5; opacity: 70%; cursor: pointer;">Details</span></td>
</tr>`;
        logReceiver.append(renderedEntry);
        $(`#${btnId}`).on("click", () => {
            showStacktraceModal(singletons, entry);
        });
        if (forceFocus) {
            const renderedEntry = $(`#${entryId}`).get(0);
            if (renderedEntry)
                renderedEntry.scrollIntoView();
        }
    }
}
function sanitizeTags(s) {
    return s.replaceAll('<', '&lt;').replaceAll('>', '&gt;');
}
function fillInEntryDetailsInStackModal(entry) {
    // Fill in message details (timestamp, level, message)
    const entryInfo = $("#q2w-stack-entry-info");
    entryInfo.empty();
    const logDetailsHtml = `<p><b>Timestamp:</b> ${entry.timestamp}<br/>
<b>Level:</b> ${entry.level}<br/>
<b>Message:</b> ${sanitizeTags(renderLogMessage(entry.args))}</p>`;
    entryInfo.append(logDetailsHtml);
    // Create a filtered representation of the stack
    const stack = getStack(entry);
    // Render the stack representation
    const stackContainer = $("#q2w-stack-container");
    stackContainer.empty();
    for (let s = 0; s < stack.length; s++) {
        const stackInfo = stack[s];
        const functionName = stackInfo[0];
        const location = stackInfo[1];
        stackContainer.append(`<tr>
<td style="width: 230px; text-align: right;"><i>${functionName}</i></td>
<td style="width: 25px; text-align: center;">&nbsp;at&nbsp;</td>
<td style="width: 270px;">${location}</td>
</tr>`);
    }
    // Add dynamic buttons
    const stackModal = $("#q2w-stack-modal");
    stackModal.dialog({
        buttons: [
            {
                text: "Print to browser console",
                click: function () {
                    logger._debugRaw(entry.location, ...entry.args);
                    logger._debugRaw(entry.locationStackTrace);
                }
            },
            {
                text: "Close",
                click: function () {
                    $(this).dialog("close");
                }
            }
        ]
    });
}
function showStacktraceModal(singletons, entry) {
    const existingModal = $("#q2w-stack-modal");
    if (existingModal.get(0)) {
        fillInEntryDetailsInStackModal(entry);
        existingModal.dialog("open");
        return;
    }
    const html = `<div class="q2w-dialog" id="q2w-stack-modal">
  <div id="q2w-stack-entry-info"></div>
  <p style="padding-top: 14px; margin-bottom: 0;"><b>Stacktrace:</b></p>
  <div style="max-height:480px; overflow-y: auto;">
    <table>
      <tbody id="q2w-stack-container">
      </tbody>
    </table>
  </div>
</div>`;
    // Note: in the dialog below, the buttons are created dynamically, via the fillInEntryDetailsInStackModal function
    createTemporaryModal(singletons, html, { title: "Log message details", width: "600px", autoOpen: false });
    fillInEntryDetailsInStackModal(entry);
    existingModal.dialog("open");
}
/**
 * Shows a modal dialog with a progress bar.
 * @param singletons Singleton object cache
 * @param title Dialog title
 * @param initialTotal Initial total number of items
 * @returns An object with methods to update progress and close the dialog
 */
function showProgressModal(singletons, title, initialTotal = 0) {
    const dialogId = `progress-modal-${Date.now()}`;
    const progressHtml = `
    <div class="q2w-dialog" id="${dialogId}">
        <div>
            <p id="${dialogId}-status">Processing...</p>
        </div>
        <div style="margin: 10px 0;">
            <div id="${dialogId}-progress-bar"></div>
        </div>
        <div>
            <p id="${dialogId}-count">0 of ${initialTotal} files processed</p>
        </div>
    </div>`;
    createCompliantModal(singletons, progressHtml, {
        title: title + getVersionInfo(singletons),
        width: 400,
        height: 'auto',
        buttons: [],
        closeOnEscape: false,
        create: function () {
            // Initialize the jQuery UI progressbar
            $(`#${dialogId}-progress-bar`).progressbar({
                value: 0
            });
            // Remove the close button (X) from the dialog
            $(this).parent().find('.ui-dialog-titlebar-close').hide();
        }
    });
    // Return methods to update progress
    return {
        updateProgress: (current, total, currentFileName) => {
            const percent = total > 0 ? Math.round((current / total) * 100) : 0;
            $(`#${dialogId}-progress-bar`).progressbar("value", percent);
            $(`#${dialogId}-count`).text(`${current} of ${total} files processed`);
            if (currentFileName) {
                $(`#${dialogId}-status`).text(`Processing: ${currentFileName}`);
            }
        },
        updateTotal: (total) => {
            $(`#${dialogId}-count`).text(`0 of ${total} files processed`);
            $(`#${dialogId}-progress-bar`).progressbar("value", 0);
        },
        close: () => {
            $(`#${dialogId}`).dialog('close');
            $(`#${dialogId}`).dialog('destroy').remove();
        }
    };
}
function showDevDialog(singletons) {
    const existingModal = $("#q2w-dev-dialog");
    if (existingModal.get(0)) {
        existingModal.dialog("open");
        return;
    }
    const logHtml = `<div class="q2w-unmoveable-dialog" "style="word-wrap: normal; white-space: normal" id="q2w-dev-dialog">
  <div>
    <p>Log started at <b id="q2w-dev-log-start-time">???</b></p>
  </div>
  <div style="height:200px; overflow-y: scroll; width: 640px; background-color:white;">
    <table style="table-layout: fixed;">
        <thead>
            <tr>
                <th style="width: 70px; font-weight: bold; text-align: center;">Time</th>
                <th style="width: 60px; font-weight: bold; text-align: center;">Level</th>
                <th style="width: 430px; font-weight: bold;">Message</th>
                <th style="width: 80px;"></th>
            </tr>
        </thead>
        <tbody id="q2w-dev-log-receiver"></tbody>
        </div>
    </table>
  </div>
</div>`;
    const options = {
        title: "Quip2Wiki DevTools",
        buttons: [
            {
                text: "Copy log to clipboard",
                click: function () {
                    navigator.clipboard.writeText(getLogForDownload(singletons, GIT_HASH));
                }
            },
            {
                text: "Download log",
                click: function () {
                    downloadFromMemory("Quip2Wiki.log.txt", getLogForDownload(singletons, GIT_HASH));
                }
            },
            {
                text: "Close",
                click: function () {
                    $(this).dialog("close");
                }
            }
        ],
        modal: false,
        position: { my: "left bottom", at: "left bottom", of: ".navigation-controller-body" }
    };
    createCompliantModal(singletons, logHtml, options, function (event) {
        if (!(event.target instanceof HTMLElement))
            return;
        // TODO: refactor this pattern into a function "addCallbackAndRunBackFill" or ("addLogCallback"+"runBackFill(callbackFn))"
        const callbackIndex = logger.getNextCallbackIndex();
        const logEntries = logger.getLogEntries();
        for (let i = 0; i < logEntries.length; i++) {
            const entry = logEntries[i];
            devDialogCallback(singletons, entry, callbackIndex, false);
        }
        logger.addLogCallback((entry, index, focus) => devDialogCallback(singletons, entry, index, focus));
        updateMinimizeButton(event.target);
    }, function () {
        if (logger.getLogEntries().length > 0)
            $("#q2w-dev-log-start-time").text(logger.getLogEntries()[0].timestamp.toString());
    }, function () {
        if (logger.getLogEntries().length > 0)
            $("#q2w-dev-log-start-time").text(logger.getLogEntries()[0].timestamp.toString());
        const lastChild = $("#q2w-dev-log-receiver").children().last().get(0);
        if (lastChild)
            lastChild.scrollIntoView();
    });
}
function devDialogCallback(singletons, entry, callbackIndex, forceFocus) {
    const logReceiver = $("#q2w-dev-log-receiver");
    if (logReceiver) {
        //let message = `${entry.timestamp} [${entry.level}] ${entry.args}`;// at ${entry.stack}`;
        const timeFromStart = convertMilissecondsToMinutesSeconds(entry.timestamp.getTime() - logger.getLogEntries()[0].timestamp.getTime());
        const entryId = `${entry.id}-${callbackIndex}`;
        const btnId = `${entry.id}-btn-${callbackIndex}`;
        const renderedEntry = `<tr id="${entryId}" style="border-bottom: 1px gray dotted;">
<td style="text-align: center;">${timeFromStart}</td>
<td style="text-align: center;">${entry.level}</td>
<td style="word-wrap: anywhere; padding-bottom: 2px;">${sanitizeTags(renderLogMessage(entry.args))}</td>
<td><span id="${btnId}" style="color: #4e7cc5; opacity: 70%; cursor: pointer;">Details</span></td>
</tr>`;
        logReceiver.append(renderedEntry);
        $(`#${btnId}`).on("click", () => {
            showStacktraceModal(singletons, entry);
        });
        if (forceFocus) {
            const renderedEntry = $(`#${entryId}`).get(0);
            if (renderedEntry)
                renderedEntry.scrollIntoView();
        }
    }
}
async function promptForAuthentication(singletons, midwayUrl, service) {
    if (!midwayUrl.startsWith(MIDWAY_REDIRECT_URL))
        return false;
    const serviceUrl = SERVICE_URL_MAPPING[service];
    const serviceName = SERVICE_NAME_MAPPING[service];
    const cancelOperation = SERVICE_CANCEL_OPERATION_MAPPING[service];
    const msg = 'Authentication via Midway is necessary.<br/><br/>' +
        `<span style="text-decoration:underline"><a href="${serviceUrl}" target="_blank" rel="noopener">` +
        `Click here to authenticate on <b>${serviceName}</b> via Midway</a></span>, then click on the "Continue" button below.<br/><br/>`;
    const options = {}; // here we have to create an empty object first and then fill it in - otherwise the cancel operation is last and gets highlighted
    options[cancelOperation] = false;
    options["Continue"] = true;
    return await showDialog(singletons, `The ${serviceName} Midway cookie is not available or has expired...`, msg, options);
}

const UPDATE_TRACKER = '610de354-b665-2356-de4e-db8bb1d80bea';
const EXPORT_TRACKER = '4feac57b-36c4-75cd-74ca-f895fb89435e';
const USAGE_SUCCESS_TRACKER = '97c4fb5c-ccf0-7722-420b-912304c80cf8';
const USAGE_ERROR_TRACKER = 'e4c67283-a943-1be5-9823-b3d1816418a3';
const QUIP_USER_API_SUCCESS = 'c7d639e8-171f-11d1-3f9d-68b78d9914fa';
const QUIP_USER_API_FAILURE = '87a02e6d-333e-8315-18a0-6f92bb804368';
/**
 * Basic functions for gathering user usage information.
 */
class Telemetry {
    constructor(singletons, currentUser) {
        this.singletons = singletons;
        this.user = currentUser;
        this.loadLocalUserData();
    }
    get now() {
        return new Date().toISOString();
    }
    async registerInstallation() {
        if (this.userData.install && this.userData.version && this.userData.version === this.singletons.session.version) {
            logger.log("[src/log/Telemetry.ts:41:13]", `[telemetry] Quip2Wiki already registered version ${this.userData.version} on ${this.userData.update || this.userData.install}.`);
            return;
        }
        logger.log("[src/log/Telemetry.ts:44:9]", `[telemetry] registering Quip2Wiki version ${this.singletons.session.version} ${this.userData.update ? 'update' : 'installation'}...`);
        try {
            await this.callTracker(UPDATE_TRACKER, { user: this.user, version: this.singletons.session.version });
            if (this.userData.install)
                this.userData.update = this.now;
            else
                this.userData.install = this.now;
            this.userData.version = this.singletons.session.version;
            this.saveLocalUserData();
            logger.log("[src/log/Telemetry.ts:55:13]", `[telemetry] Quip2Wiki installation of version ${this.userData.version} registered on ${this.userData.install}`);
        }
        catch (e) {
            logger.error("[src/log/Telemetry.ts:57:13]", `[telemetry] error while registering Quip2Wiki installation: ${e}`);
        }
    }
    async registerTokenInstallation() {
        if (this.userData.tokenInstall) {
            logger.log("[src/log/Telemetry.ts:63:13]", `[telemetry] Quip token already registered on ${this.userData.tokenInstall}.`);
            return;
        }
        logger.log("[src/log/Telemetry.ts:66:9]", '[telemetry] registering Quip token installation...');
        try {
            await this.callTracker(EXPORT_TRACKER, { user: this.user, step: 'TOKEN_INSTALL' });
            this.userData.tokenInstall = this.now;
            this.saveLocalUserData();
            logger.log("[src/log/Telemetry.ts:71:13]", `[telemetry] token installation registered on ${this.userData.tokenInstall}`);
        }
        catch (e) {
            logger.error("[src/log/Telemetry.ts:73:13]", `[telemetry] error while registering Quip API token installation: ${e}`);
        }
    }
    async registerExportAttempt() {
        if (this.userData.exportAttempt)
            return;
        logger.log("[src/log/Telemetry.ts:81:9]", '[telemetry] registering first export attempt...');
        try {
            await this.callTracker(EXPORT_TRACKER, { user: this.user, step: 'EXPORT_ATTEMPT' });
            this.userData.exportAttempt = this.now;
            this.saveLocalUserData();
            logger.log("[src/log/Telemetry.ts:87:13]", `[telemetry] first export attempt registered on ${this.userData.exportAttempt}`);
        }
        catch (e) {
            logger.error("[src/log/Telemetry.ts:89:13]", `[telemetry] error while registering first export attempt: ${e}`);
        }
    }
    async registerSuccessfulExport() {
        if (this.userData.firstExport) {
            return;
        }
        logger.log("[src/log/Telemetry.ts:97:9]", '[telemetry] registering first successful export...');
        try {
            await this.callTracker(EXPORT_TRACKER, { user: this.user, step: 'EXPORT_SUCCESS' });
            this.userData.firstExport = this.now;
            this.saveLocalUserData();
            logger.log("[src/log/Telemetry.ts:102:13]", `[telemetry] successful export registered on ${this.userData.firstExport}`);
        }
        catch (e) {
            logger.error("[src/log/Telemetry.ts:104:13]", `[telemetry] error while registering successful export: ${e}`);
        }
    }
    async registerQuipUserApiAttempt() {
        logger.log("[src/log/Telemetry.ts:109:9]", '[telemetry] registering Quip User Api usage attempt...');
        try {
            await this.callTracker(QUIP_USER_API_SUCCESS, { user: this.user, step: 'QUIP_USER_ATTEMPT' });
            logger.log("[src/log/Telemetry.ts:112:13]", `[telemetry] successfully registered Quip User Api usage attempt`);
        }
        catch (e) {
            logger.error("[src/log/Telemetry.ts:114:13]", `[telemetry] error while registering Quip User Api usage attempt: ${e}`);
        }
    }
    async registerQuipUserApiSuccess() {
        logger.log("[src/log/Telemetry.ts:119:9]", '[telemetry] registering Quip User Api usage success...');
        try {
            await this.callTracker(QUIP_USER_API_SUCCESS, { user: this.user, step: 'QUIP_USER_SUCCESS' });
            logger.log("[src/log/Telemetry.ts:122:13]", `[telemetry] successfully registered Quip User Api usage success`);
        }
        catch (err) {
            logger.error("[src/log/Telemetry.ts:124:13]", `[telemetry] error while registering Quip User Api usage success: ${err}`);
        }
    }
    async registerQuipUserApiError() {
        logger.log("[src/log/Telemetry.ts:129:9]", '[telemetry] registering Quip User Api usage failure...');
        try {
            await this.callTracker(QUIP_USER_API_FAILURE, { user: this.user, step: 'QUIP_USER_ERROR' });
            logger.log("[src/log/Telemetry.ts:132:13]", `[telemetry] successfully registered Quip User Api usage failure`);
        }
        catch (err) {
            logger.error("[src/log/Telemetry.ts:134:13]", `[telemetry] error while registering Quip User Api usage failure: ${err}`);
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async registerUsage(docType, error = null) {
        logger.log("[src/log/Telemetry.ts:140:9]", '[telemetry] registering export...');
        const tracker = error ? USAGE_ERROR_TRACKER : USAGE_SUCCESS_TRACKER;
        const args = {};
        args.docType = docType;
        args.user = await digestMessage(this.user); // use hash to avoid tracking logins
        args.version = this.singletons.session.version;
        if (error) {
            args.error = `${error}`.substring(0, 75); // max 75 characters for error message
        }
        try {
            await this.callTracker(tracker, args);
        }
        catch (e) {
            logger.error("[src/log/Telemetry.ts:152:13]", `[telemetry] error while registering usage metric: ${e}`);
        }
        logger.log("[src/log/Telemetry.ts:155:9]", `[telemetry] usage metric registered`);
    }
    loadLocalUserData() {
        const value = this.singletons.settings.loadValue("user_data", null);
        if (value) {
            this.userData = JSON.parse(value);
        }
        else {
            this.userData = {
                version: this.singletons.session.version,
                install: null,
                update: null,
                tokenInstall: null,
                exportAttempt: null,
                firstExport: null,
            };
        }
    }
    saveLocalUserData() {
        const value = JSON.stringify(this.userData);
        this.singletons.settings.saveValue("user_data", value);
    }
    async callTracker(pixelID, params = {}) {
        await this.singletons.howManyClient.callTracker(pixelID, params);
    }
}

/**
 * Basic operations associated to the current loaded Quip Document web page (user interface).
 */
class QuipEditor {
    /**
     * Check if current URL is a login page
     */
    static isLoginPage() {
        return document.location.href.startsWith('https://quip-amazon.com/account/login?next=');
    }
    /**
     * Check if current element is a document
     */
    static isDocument() {
        return !QuipEditor.isLoginPage() && !QuipEditor.isFolder();
    }
    /**
     * Check if current element is a folder
     */
    static isFolder() {
        return !QuipEditor.isLoginPage() && !!document.body.querySelector('div.nav-path-folder');
    }
    /**
     * Check if current URL is a token page
     */
    static isTokenPage() {
        return window.location.href.startsWith(TOKEN_PAGE_URL);
    }
    /**
     * Check if current page has a list of documents
     */
    static hasListOfDocuments() {
        return document.getElementsByClassName('nav-path-folder')[0] != null;
    }
    /**
     * Extracts the list of sheets of a spreadsheet
     * @returns list of sheets
     */
    static extractSheetNames() {
        return [...document.querySelectorAll('div[role=tablist]>div[role=tab]>span')].map(span => span.textContent);
    }
    /**
     * Extracts multi-column layout from Quip Editor page with sizing and column width. Internal content is included as `span` tags with the `id` from their original content.
     *
     * The Layout is composed of a list of `div` containers that contain multiple `content` elements such as paragraph, images, etc.
     *
     */
    static extractMultiColumnLayout() {
        logger.log("[src/quip/QuipEditor.ts:68:9]", 'find mult-column layout containers...');
        const layoutOutput = [];
        // build layout based on flexbox containers
        const containers = document.querySelectorAll('.flexbox-layout-container');
        for (const element of containers) {
            const elContainer = document.createElement('div');
            elContainer.setAttribute('class', 'flexbox-layout-container');
            elContainer.setAttribute('style', 'max-width:100%; display: flex;');
            let hasElements = false;
            const columns = element.getElementsByClassName('flexbox-layout-column');
            const getColWidth = (c) => Number(c.style.width.replace('px', ''));
            // Determine full width based on columns sizes
            const width = Array.from(columns)
                .map(getColWidth)
                .reduce((acc, w) => acc + w, 0);
            // determine column content
            for (const col of columns) {
                const colWidth = getColWidth(col);
                const colWidthPercent = Math.round(colWidth * 100 / width);
                const elColumn = document.createElement('div');
                elColumn.setAttribute('class', 'flexbox-layout-column');
                elColumn.setAttribute('style', `max-width:100%; flex: ${colWidthPercent}%; padding-right: 14px;`);
                // find all content items and add to column
                const elContentElements = col.getElementsByClassName('content');
                for (const content of elContentElements) {
                    const elColItem = document.createElement('span');
                    elColItem.setAttribute('id', content.getAttribute('data-id') || '');
                    elColumn.appendChild(elColItem);
                    hasElements = true;
                }
                elContainer.appendChild(elColumn);
            }
            if (hasElements) {
                layoutOutput.push(elContainer);
                logger.log("[src/quip/QuipEditor.ts:113:17]", 'Multi-column layout: ' + elContainer.outerHTML);
            }
            else {
                logger.error("[src/quip/QuipEditor.ts:115:17]", 'Container has no elements: ' + elContainer.outerHTML);
            }
        }
        return layoutOutput;
    }
    /**
     * Extracts math formula controls from Quip Editor page. Math formulares are available in `annotation` tags (under a `math` tags).
     *
     * The output is a map of doc section ids to a list math equations. Since we can't differentiate math controls from others, we export a list
     * with the math content of all controls within that section. When value is null, it means the control is another not a math equation type of control.
     *
     */
    static extractMathFormulas() {
        logger.log("[src/quip/QuipEditor.ts:131:9]", 'find math equations...');
        const output = new Map();
        // find all math equations and return their parent section
        const sections = [...document.querySelectorAll('math > semantics > annotation[encoding="application/x-tex"]')]
            .map((el) => Utils.getAncestorWithAttribute(el, 'data-id'))
            .filter(el => el);
        // for each section, find the list math equations from existing controls (value is null, control is not a math equation)
        sections.forEach(elSection => {
            const id = elSection.getAttribute('data-id');
            if (!output.has(id)) {
                const controls = [...elSection.querySelectorAll('control')]
                    .map(elControl => {
                    const elMath = elControl.querySelectorAll('math > semantics > annotation[encoding="application/x-tex"]');
                    return elMath.length > 0 ? elMath[0].textContent : null;
                });
                output.set(id, controls);
            }
        });
        logger.log("[src/quip/QuipEditor.ts:155:9]", `Math formulas: ${mapToString(output)}`);
        return output;
    }
    /**
     * Extracts design-inspector frames from Quip Editor page.
     *
     * The output is a map of doc section ids to a list math equations. Since we can't differentiate math controls from others, we export a list
     * with the math content of all controls within that section. When value is null, it means the control is another not a math equation type of control.
     *
     */
    static extractDesignInspectorDiagrams() {
        logger.log("[src/quip/QuipEditor.ts:168:9]", 'find design-inspector diagrams...');
        const output = new Map();
        state.iframeData.forEach((diData, key) => {
            const diElement = document.querySelector(`iframe[title="DI Viewer"][name="${key.view}"][data-element-config-id],iframe[title="Design Inspector Viewer"][name="${key.view}"][data-element-config-id]`);
            if (diElement) {
                const section = {
                    id: diElement.getAttribute('data-element-config-id'),
                    section: diElement.getAttribute('data-section-element-id')
                };
                output.set(section, diData);
            }
            else {
                logger.error("[src/quip/QuipEditor.ts:183:17]", `could not find di-inspector element for url '${key.domain}'`);
            }
        });
        logger.log("[src/quip/QuipEditor.ts:187:9]", `Iframe data: ${mapToString(output)}`);
        return output;
    }
    /**
     * Retrieves the id from the URL of the current loaded page.
     *
     * The URL pattern for extracting the id must be as follows:
     * https://quip-amazon.com/UGb4AxAgFwmB/title-of-the-quip-doc-or-folder
     */
    static getId() {
        const url = window.location.href;
        const match = url.match(QUIP_LINK_REGEX);
        return (match && match[1]) || null;
    }
    /**
     * Retrieves the document type from the URL of the current loaded page.
     *
     * The URL pattern for extracting the id must be as follows:
     * https://quip-amazon.com/UGb4AxAgFwmB/title-of-the-quip-doc-or-folder
     */
    static getDocumentType() {
        if (QuipEditor.isDocument()) {
            const mainMenuName = document.querySelector('button.navigation-controller-menu>div.button-text')?.textContent;
            const hasSpreadsheetMenu = mainMenuName === 'Spreadsheet' || (mainMenuName !== 'Document' && mainMenuName !== 'Folder');
            const hasSheetNames = QuipEditor.extractSheetNames().length > 0;
            if (hasSpreadsheetMenu && hasSheetNames) {
                return 'spreadsheet';
            }
            else {
                return 'document';
            }
        }
        else if (QuipEditor.isFolder()) {
            return 'folder';
        }
        else {
            return null;
        }
    }
    /**
     * Retrieves the document id from the URL of the current loaded page.
     *
     * The URL pattern for extracting the id must be as follows:
     * https://quip-amazon.com/UGb4AxAgFwmB/title-of-the-quip-doc-or-folder
     */
    static getDocumentId() {
        const id = QuipEditor.isDocument() ? QuipEditor.getId() : null;
        if (id)
            logger.log("[src/quip/QuipEditor.ts:236:17]", 'doc id: ' + id);
        return id;
    }
    /**
     * Retrieves the folder id from the URL of the current loaded page.
     *
     * The URL pattern for extracting the id must be as follows:
     * https://quip-amazon.com/UGb4AxAgFwmB/title-of-the-quip-doc-or-folder
     */
    static getFolderId() {
        const id = QuipEditor.isFolder() ? QuipEditor.getId() : null;
        if (id)
            logger.log("[src/quip/QuipEditor.ts:250:17]", 'folder id: ' + id);
        return id;
    }
    /**
     * Retrieves the base buttons of the current loaded page.
     *
     * The URL pattern for extracting the id must be as follows:
     * https://quip-amazon.com/UGb4AxAgFwmB/title-of-the-quip-doc-or-folder
     */
    static getBaseButtonForExportButton() {
        let baseButtonLoc = getFromSelector("[aria-label='Focus Mode']");
        if (!baseButtonLoc)
            baseButtonLoc = getFromSelector("[aria-label='Add to Favorites']");
        if (!baseButtonLoc)
            baseButtonLoc = getFromSelector(".favorite-button");
        return baseButtonLoc;
    }
    /**
     * Retrieves the toolbar element from the URL of the current loaded page.
     *
     * The URL pattern for extracting the id must be as follows:
     * https://quip-amazon.com/UGb4AxAgFwmB/title-of-the-quip-doc-or-folder
     */
    static getToolbar() {
        return document.querySelector('#export-wiki-button-group');
    }
    /**
     * Creates the Quip2Wiki export buttons
     */
    static createQuip2WikiButtons(singletons, onclick) {
        if ($("#export-wiki-button-group")[0])
            return; // button has already been added to the toolbar
        logger.log("[src/quip/QuipEditor.ts:286:9]", "Trying to insert export button...");
        const baseButtonLoc = this.getBaseButtonForExportButton();
        if (baseButtonLoc) {
            const configSvgIcon = `<svg id="q2w-config-button-icon" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="settings-gear"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3" /></svg>`;
            const exportButtonHtml = `<div class="change-access-button-group button-group" id="export-wiki-button-group">
    <div class="button-group-border"></div>
    <div class="button-group-buttons">
        <button id="export-doc-button" class="change-access-button button button-flex clickable dark" style="background-color: rgb(var(--quipAction)); height: 32px; padding-left: 8px; padding-right: 4px; color: rgb(255, 255, 255); fill: rgb(255, 255, 255);"
                data-mousedown="no-caret-move" aria-describedby="change-access-button-text">
            <div class="button-text" style="font-size: 14px; line-height: 32px; margin-right: 4px;" id="export-wiki-button-text">Export to Wiki</div>
        </button>
        <button id="q2w-config-button" class="button button-flex clickable icon-only dark" style="background-color: rgb(var(--quipAction)); height: 32px; padding-left: 8px; padding-right: 8px; color: rgb(255, 255, 255); fill: rgb(255, 255, 255);"
            aria-label="Quip2Wiki configurations" data-mousedown="no-caret-move">${configSvgIcon}</button>
    </div>
</div>`;
            $(exportButtonHtml).insertAfter(baseButtonLoc);
            const exportButton = $("#export-doc-button");
            exportButton.on("click", onclick);
            const configButton = $("#q2w-config-button");
            configButton.on("click", () => showLogModal(singletons));
            const configIcon = $("#q2w-config-button-icon");
            configButton.on("mouseenter", () => {
                configIcon.addClass('animate');
            });
            configButton.on("mouseleave", () => {
                configIcon.removeClass('animate');
            });
            logger.log("[src/quip/QuipEditor.ts:321:13]", "Export button successfully inserted");
        }
        else {
            logger.error("[src/quip/QuipEditor.ts:323:13]", "Base location for export button not found");
        }
    }
    /**
     * Creates a label in Quip's footer section.
     *
     * @param {string} id identifier of the label to be created
     * @param {string} label button label
     */
    static createAppFooter(id, label) {
        const footerLabel = document.getElementById(id);
        if (footerLabel != null) {
            footerLabel.innerHTML = label;
        }
        else {
            const appBody = document.getElementsByClassName('navigation-controller-body scrollable')[0];
            if (appBody == null) {
                return;
            }
            const footerLabel = document.createElement("div");
            footerLabel.id = id;
            footerLabel.innerHTML = label;
            appBody.appendChild(footerLabel);
        }
    }
    /**
     * Removes an element from the current page based on its id
     *
     * @param {string} id identifier of the element to be removed
     */
    static removeElement(id) {
        const element = document.getElementById(id);
        if (element?.parentNode)
            element.parentNode.removeChild(element);
    }
    /**
     * Creates or adds an element to document
     *
     * @param {QuipDocument} doc an instance of a QuipDocument
     * @param {string} tagName Name of the tag
     * @param {string} tagValue Value of the tag
     * @param {QuipClient} quipClient an instance of a QuipClient
     */
    static async writeTag(doc, tagName, tagValue, quipClient) {
        if (doc == null)
            return;
        if (tagName == null)
            return;
        const docId = doc.id;
        // find current tag
        const sectionId = doc.findTagSection(tagName);
        const tag = `<p><i>--${tagName}: "${tagValue}"--</i></p>`;
        if (sectionId) {
            logger.log("[src/quip/QuipEditor.ts:382:13]", `replacing tag '${tagName}' on quip, at sectionId '${sectionId}'...`);
            await quipClient.replaceSection(docId, tag, sectionId);
        }
        else {
            // find any tag (except macro tag)
            logger.log("[src/quip/QuipEditor.ts:386:13]", `appending tag '${tagName}' on quip...`);
            const separatorLine = !doc.findTagSection() ? '<p><hr></hr></p>\n' : '';
            const sectionContent = separatorLine + tag;
            await quipClient.appendToEnd(docId, sectionContent); // append at end of document
        }
    }
    /**
     * Creates or adds an element to wiki address tag
     *
     * @param {QuipDocument} doc an instance of a QuipDocument
     * @param {string} wikiAddr Wiki address
     * @param {QuipClient} quipClient an instance of a QuipClient
     */
    static async writeWikiAddressTag(doc, wikiAddr, quipClient) {
        const wikiUrl = VIEW_URL + wikiAddr; // wiki full address
        const tagName = SYNC_TAG;
        const tagValue = `<a href="${wikiUrl}" target="_blank" rel="noopener">${wikiAddr}</a>`;
        await QuipEditor.writeTag(doc, tagName, tagValue, quipClient);
    }
}
function getFromSelector(selector) {
    const elements = $(selector);
    if (elements.length == 1)
        return elements[0];
    return undefined;
}

function showAppFooter(singletons) {
    const folderId = QuipEditor.getFolderId();
    if (!folderId)
        return;
    const wikiAddr = singletons.settings.loadValue(folderId, null);
    if (!wikiAddr) {
        QuipEditor.removeElement(LABEL_ID);
        return;
    }
    const wikiUrl = VIEW_URL + wikiAddr;
    const html = `<span style="font-size:small; margin-left:35px;">--wiki-sync:` +
        `"<span style="text-decoration:underline; font-style:italic;">` +
        `<a href="${wikiUrl}" target="_blank" style="color:#5C6470" rel="noopener">${wikiAddr}</a>` +
        `</span>"--</span>`;
    QuipEditor.createAppFooter(LABEL_ID, html);
}

function updateExportButton(label, isRunningValue) {
    state.isExporting = isRunningValue;
    const buttonLabel = document.getElementById(BUTTON_LABEL_ID);
    if (!buttonLabel) {
        return;
    }
    buttonLabel.innerHTML = label;
}

class LocalStorageSettings {
    constructor(tampermonkey) {
        this.tampermonkey = tampermonkey;
        this.bannerPosition = tampermonkey.getRawValue('banner_position', BannerPosition.TOP);
        this.wikiBlockEnabled = tampermonkey.getRawValue('wiki_block_enabled', true);
        this.exportDialogEnabled = tampermonkey.getRawValue('export_dialog_enabled', true);
        logger.log("[src/browser/Settings.ts:17:9]", 'Settings loaded from local storage');
    }
    get quipApiToken() {
        return this.tampermonkey.getRawValue('quip_api_token', null);
    }
    set quipApiToken(value) {
        this.tampermonkey.setRawValue('quip_api_token', value);
    }
    save() {
        this.tampermonkey.setRawValue('banner_position', this.bannerPosition);
        this.tampermonkey.setRawValue('wiki_block_enabled', this.wikiBlockEnabled);
        this.tampermonkey.setRawValue('export_dialog_enabled', this.exportDialogEnabled);
        logger.log("[src/browser/Settings.ts:32:9]", 'Settings saved to local storage');
    }
    loadFlag(key, defaultValue) {
        return this.tampermonkey.getRawValue(key, defaultValue);
    }
    loadValue(key, defaultValue = null) {
        return this.tampermonkey.getRawValue(key, defaultValue);
    }
    saveValue(key, value) {
        this.tampermonkey.setRawValue(key, value);
    }
    loadObject(key, defaultValue) {
        const serializedObj = this.tampermonkey.getRawValue(key, null);
        if (serializedObj == null)
            return defaultValue;
        return JSON.parse(serializedObj);
    }
    saveObject(key, value) {
        const serializedObj = JSON.stringify(value);
        this.tampermonkey.setRawValue(key, serializedObj);
    }
}

const TWELVE_HOURS = 12 * 60 * 60 * 1000; // 12 hours in milliseconds
const LAST_CHECK_KEY = "LastCheck";
class SessionInfo {
    constructor(singletons) {
        this.tokenTestResult = false;
        this.singletons = singletons;
    }
    get version() {
        return this.singletons.tampermonkey.getScriptVersion();
    }
    get gmVersion() {
        return this.singletons.tampermonkey.getTampermonkeyVersion();
    }
    /**
     * Returns true when the Quip API token has been tested.
     */
    isTokenTested() {
        return this.tokenTestResult;
    }
    /**
     * Retrieves the user's browser information. Reference: https://stackoverflow.com/a/5918791
     */
    getBrowser() {
        try {
            const ua = navigator.userAgent;
            let tem;
            let M = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
            if (/trident/i.test(M[1])) {
                tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
                return 'IE ' + (tem[1] || '');
            }
            if (M[1] === 'Chrome') {
                tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
                if (tem != null)
                    return tem.slice(1).join(' ').replace('OPR', 'Opera');
            }
            M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
            if ((tem = ua.match(/version\/(\d+)/i)) != null)
                M.splice(1, 1, tem[1]);
            return M.join(' ');
        }
        catch {
            return 'unknown';
        }
    }
    async getLatestVersion() {
        const now = new Date();
        const lastCheckInfo = this.singletons.settings.loadObject(LAST_CHECK_KEY, null);
        if (lastCheckInfo != null) {
            const timeSinceLastCheck = now.getTime() - lastCheckInfo.lastCheckTimestamp;
            if (timeSinceLastCheck < TWELVE_HOURS)
                return lastCheckInfo;
        }
        let found = null;
        for (const url of UPDATE_CHECK_URL) {
            const result = await this.getFileVersion(url);
            if (result) {
                found = result;
                break;
            }
        }
        if (!found) {
            return null;
        }
        return this.updateLastCheck(now, found);
    }
    /**
     * Fetch deployed userscript and extract version.
     */
    async getFileVersion(url) {
        logger.log("[src/browser/Session.ts:103:9]", `Fetching latest update from ${url}...`);
        const waitInterval = 2500;
        let service = WIKI_SERVICE;
        if (url.includes("axzile"))
            service = AXZILE_SERVICE;
        let content;
        try {
            const response = await this.singletons.fetchClient.fetchUrl(url, service, 10000, waitInterval);
            content = response.slice(0, 2500); // we only need the header
        }
        catch (ignoredError) {
            logger.trace("[src/browser/Session.ts:115:13]", `Ignore error (getFileCVersion): ${ignoredError}`);
            content = '';
        }
        const versionMatch = content.match(/^\/\/\s+@version\s+.*$/gm) || [];
        const version = versionMatch
            .map(parseVersion)
            .find(v => !!v);
        const now = new Date();
        if (!version) {
            return null;
        }
        const curVersion = parseVersion(this.version); // script version
        version.isNew = compareVersions(version, curVersion) < 0;
        version.forceUpdate = /\/\*\* FORCE_UPDATE = true \*\//.test(content);
        version.timestamp = now;
        version.url = url;
        logger.log("[src/browser/Session.ts:137:9]", 'Latest version: ' + JSON.stringify(version));
        return version;
    }
    /**
     * Retrieves the Amazon login of current user.
     */
    async getUserFromSession(singletons) {
        if (this.currentUser)
            return this.currentUser;
        const currentUser = await singletons.midwayClient.getMidwayUser();
        this.currentUser = currentUser;
        return currentUser;
    }
    /**
     * Sets the result of the Quip API token test.
     * @param {boolean} testResult
     */
    setTokenTest(testResult) {
        this.tokenTestResult = testResult;
    }
    updateLastCheck(now, found) {
        const v = {
            lastCheckTimestamp: now.getTime(),
            version: found.version,
            url: found.url,
            isNew: found.isNew,
            forceUpdate: found.forceUpdate
        };
        this.singletons.settings.saveObject(LAST_CHECK_KEY, v);
        return v;
    }
}

/**
 * Client for accessing Maxis' APIs.
 */
class MaxisApi extends RemoteClient {
    constructor(singletons, beforeRetry) {
        super(singletons, 10, 10, beforeRetry, MAXIS_SERVICE);
        /**
         * Holds recent successful userName search results, so to avoid API calls within the same session.
         */
        this.nameCache = {};
        /**
         * Holds recent invalid userName search results, so to avoid API calls within the same session.
         */
        this.invalidNameCache = [];
        /**
         * Holds recent successful login search results, so to avoid API calls within the same session.
         */
        this.loginCache = {};
        this.retries = 2;
    }
    /**
     * This method finds a user's login by searching its full name using the HR extension from Maxis' user API. The result is successful if the
     * search result contains only one employee that matches given name, otherwise the method fails. The search keyword should be
     * the user's exact full name, as configured in Amazon systems and does not match inactive employees. Requires Midway authentication.
     *
     * @param {string} fullName the user full name, as configured in Amazon systems
     * @returns a promise containing the user login that matches the given full name
     * @throws returns a failed promise if the given full name does not match a user, or if it matches multiple users
     */
    async getLoginFromFullName(fullName) {
        const isInvalid = this.invalidNameCache.includes(fullName);
        let login = this.nameCache[fullName];
        if (login) {
            logger.debug("[src/client/Maxis.ts:54:13]", `[maxis-client] retrieved login from cache for '${fullName}': ${login}`);
        }
        else if (isInvalid) {
            logger.debug("[src/client/Maxis.ts:56:13]", `[maxis-client] retrieved invalid name from cache for '${fullName}'`);
        }
        else {
            logger.debug("[src/client/Maxis.ts:58:13]", `[maxis-client] finding '${fullName}' user login...`);
            const employees = await this.searchEmployees(fullName);
            for (const employee of employees) {
                if (!employee.extensions)
                    continue;
                if (!employee.extensions.hrInfo)
                    continue;
                if (employee.extensions.hrInfo.fullName === fullName) {
                    const employeeLogin = employee.email.replace(/@[^@]+$/, '');
                    if (!login) {
                        login = employeeLogin;
                    }
                    else if (login !== employeeLogin) {
                        logger.warn("[src/client/Maxis.ts:69:25]", `[maxis-client] find login error: multiple logins match '${fullName}'`);
                        login = null; // we can't used the first match
                        break; // stop looking
                    }
                }
            }
            if (login) {
                logger.log("[src/client/Maxis.ts:76:17]", `[maxis-client] found login for '${fullName}': ${login}`);
            }
            else {
                logger.error("[src/client/Maxis.ts:78:17]", `[maxis-client] find login error: found no employee that matches '${fullName}'`);
                this.invalidNameCache.push(fullName); // did not find, so add to invalid cache
            }
        }
        if (login) {
            this.nameCache[fullName] = login; // store in cache
            return login;
        }
        else {
            throw new Error(`Could not find the login of '${fullName}'`);
        }
    }
    /**
     * Retrieves an employee information by its Amazon login. The search does not match inactive employees. Requires Midway authentication.
     *
     * @param {string} login Amazon login of desired user
     */
    async getEmployeeFromLogin(login) {
        if (login in this.loginCache) {
            logger.log("[src/client/Maxis.ts:98:13]", `[maxis-client] found employee data from cache for '${login}'`);
            return this.loginCache[login];
        }
        logger.debug("[src/client/Maxis.ts:101:9]", `[maxis-client] get employee '${login}' data...`);
        const employees = await this.searchEmployees(login);
        for (const employee of employees) {
            const employeeLogin = employee.email.replace(/@[^@]+$/, '');
            if (employeeLogin && employeeLogin === login) {
                logger.log("[src/client/Maxis.ts:106:17]", `[maxis-client] found employee data for '${login}'`);
                this.loginCache[login] = employee;
                return employee;
            }
        }
        logger.log("[src/client/Maxis.ts:111:9]", `[maxis-client] find employee data error: found no employee that matches '${login}'`);
        return null;
    }
    /**
     * Executes a user search and retrieves the employees that match given keyword.<br>
     * The result do not contain inactive employees. Requires Midway authentication.
     */
    async searchEmployees(searchKeyword) {
        logger.debug("[src/client/Maxis.ts:120:9]", `[maxis-client] running a user search on keyword '${searchKeyword}'...`);
        const keyword = encodeURIComponent(searchKeyword);
        const requestUrl = `https://maxis-service-prod-iad.amazon.com/users/?q=${keyword}`;
        const response = await this.execute('read', {
            method: 'GET',
            url: requestUrl,
            timeout: 10000,
            headers: {
                'accept': 'application/json',
                'x-requested-with': 'XMLHttpRequest',
            },
        });
        const result = JSON.parse(response.responseText);
        if (result.documents)
            return result.documents;
        logger.error("[src/client/Maxis.ts:138:9]", '[maxis-client] search result error: ' + JSON.stringify(result));
        throw new Error(`Invalid result while searching for '${searchKeyword}'`);
    }
}

function getLoginFromQuipId(singletons, quipId) {
    return singletons.quipUserCache.getAsync(quipId, async (userId) => {
        const userInfo = await singletons.quipClient.getUser(userId);
        if (userInfo != undefined && userInfo.emails != null && userInfo.emails.length > 0) {
            const firstEmail = userInfo.emails[0];
            const email = typeof firstEmail === 'string' ? firstEmail : firstEmail.address;
            return email.split("@")[0];
        }
        return undefined;
    });
}
/**
 * Utility class for basic document conversions, such as Quip API HTML to XHTML.
 */
class XHtmlConverter {
    static async convertQuipHTMLToXHTML(singletons, document, attachments, messages) {
        // pre-cleaning
        let content = document.htmlContent
            .replace(/^(\s*<p( [^<>]*)?><\/p>\s*)+/g, '') // remove any empty space or empty line at the beggining of the doc
            .replace(/<hr[^<>]*?>/g, '<hr/>') // fix lines: <hr> => <hr/> and remove attribute "width=100% that breaks floating table of contents
            .replace(/<br>/g, '<br/>') // fix line breaks to avoid issues with XHTML
            .replace(/<a data-nolink=[^<>]*>([\s\S]*?)<\/a>/g, '$1'); // remove weird 'no-link' in <a> tags (not visible in Quip), but keep content
        // quip tags: -wiki-title-
        const titleOverride = document.readTagValuesWithArguments(TITLE_TAG)
            .map(obj => ({
            title: obj.value.trim(),
            isVisible: XHtmlConverter.getBooleanArgValue(obj.args, 'visible', false)
        }))[0];
        if (!titleOverride || !titleOverride.isVisible) {
            content = content.replace(/^<h1[^<>]*?>.*?<\/h1>\s*/g, ''); // remove first heading (Title)
        }
        else {
            logger.log("[src/q2w/XHtmlConverter.ts:62:13]", 'Making h1 header visible on page body');
            if (titleOverride.title) {
                content = content.replace(/^(<h1[^<>]*?>).*?<\/h1>/g, `$1${titleOverride.title}</h1>`); // replace first heading value (Title)
            }
        }
        // find all anchors within document
        const anchorsInUse = new Set();
        content.replace(/<a href="https?:\/\/quip-amazon\.com\/(\w{12})(?:\/.*?)?#([^<>]*?)">/g, (m, docId, id) => {
            const isSameDoc = docId === document.id || docId === document.linkId;
            if (isSameDoc) {
                anchorsInUse.add(id);
            }
            return '';
        });
        // generate messages/comments
        const messagesContent = await XHtmlConverter.convertQuipMessagesToXHTML(singletons, messages, document);
        // find all anchors from messages
        for (const item of messagesContent.references) {
            anchorsInUse.add(item.sectionId); // include mentioned sections
        }
        // attributes
        content = content
            .replace(/ class=(''|"")/g, '') // remove empty 'class' attributes
            .replace(/ style=(''|"")/g, '') // remove empty 'style' attributes
            .replace(/<(\w+?[^<>]*?) id='([^<>]*?)'([^<>]*?)>/g, // remove quip ids not being used
        (m, p1, id, p2) => (anchorsInUse.has(id) ? m : `<${p1}${p2}>`))
            .replace(/<(h\d[^<>]*?) (id='[^<>]*?')([^<>]*?)>/g, "<a $2/><$1$3>"); // fix headings' anchors by adding html <a> tag
        // image border
        content = content.replace(/<div data-section-style='11'[^<>]*(?:class='.*?show-border.*?')[^<>]*><img[^<>]*/g, match => `${match} style='border:1px solid #555'`); // set image border
        const options = document.getWikiOptions();
        let imageStyle = "";
        // force images to be all the same size.
        // It is necessary to change the 'display' property to 'block' so the size properly applies when inside table cells.
        if (options.forceImageSize && options.forcedImageSize) {
            imageStyle += "display: block; width: " + options.forcedImageSize + ";";
        }
        // fix image centering if the option is active
        if (options.fixImageCentering) {
            imageStyle += "text-align:center;";
        }
        if (imageStyle != "") {
            content = content.replaceAll("<div data-section-style='11' style='max-width:100%'", "<div data-section-style='11' style='" + imageStyle + "'");
            content = content.replaceAll("<span data-section-style='11' style='max-width:45%'", "<span data-section-style='11' style='" + imageStyle + "'");
            content = content.replaceAll("<span data-section-style='11' style='max-width:44%'", "<span data-section-style='11' style='" + imageStyle + "'");
        }
        // text alignment
        content = content.replace(/<(?:h\d|p|pre|blockquote)\s[^<>]*(?:class='.*?align-(center|right).*?')[^<>]*/g, (match, align) => `${match} style='text-align: ${align}'`); // set text alignment center
        // video tag must be within html macro
        content = content.replace(/(<video [^<>]*>)/g, '<!--startmacro:html|-||-|$1--><!--stopmacro-->');
        // quip mentions
        content = await Utils.replaceAsyncSequence(content, XHtmlConverterConstants.QUIP_MENTION_FULLNAME_REGEX, async (m, m1, url, name) => {
            const urlParts = url.split("/");
            const quipId = urlParts.at(urlParts.length - 1);
            const userLogin = await getLoginFromQuipId(singletons, quipId);
            if (userLogin) {
                return `<a href="https://phonetool.amazon.com/users/${userLogin}">${name}</a>`;
            }
            const login = await XHtmlConverter.getUserLogin(singletons, name);
            if (login) {
                return `<a href="https://phonetool.amazon.com/users/${login}">${name}</a>`;
            }
            else {
                return m1 + name + '</a>';
            }
        });
        singletons.quipUserCache.persistCache();
        // amazon login mentions (ex: @siljonas or siljonas@)
        content = await Utils.replaceAsyncSequence(content, XHtmlConverterConstants.QUIP_MENTION_LOGIN_REGEX2, async (m, login1, login2) => {
            const login = login1 || login2;
            const isValid = await XHtmlConverter.checkUserLogin(singletons, login);
            if (isValid) {
                return `<a href="https://phonetool.amazon.com/users/${login}">${m}</a>`;
            }
            else {
                return m;
            }
        });
        // links
        content = content
            .replace(/<a href="([^"]*)">/g, (m, url) => `<a href="${sanitizeHTMLText(url)}">`) // Sanitize HTML links
            .replace(/<a href="https?:\/\/w\.amazon\.com(\/bin\/view\/[^<>]*?)"/g, '<a href="$1"') // to relative wiki address
            .replace(/<a href="https?:\/\/w\.amazon\.com\/index\.php\/([^<>]*?)"/g, '<a href="/bin/view/$1"') // from legacy to relative wiki address
            .replace(/<control data-remapped="true"[^<>]*?>(<a href="https?:\/\/quip-amazon\.com\/\w{12}(?:\/.*?)?">[^<>]+?<\/a>)<\/control>/g, '$1') // fix quip doc url
            .replace(/<control data-remapped="true"[^<>]*?>(<a href="https?:\/\/quip-amazon\.com\/-\/blob\/.{11}\/.{22}\?(?:s=\w{12}&)?name=.+?"[^<>]*?>.*?<\/a>)<\/control>/g, '&#x1F4CE;$1') // fix attachment url and add paper clip emoji
            .replace(/<a href="https?:\/\/quip-amazon\.com\/(\w{12})(?:\/.*?)?#([^<>]*?)">/g, (m, docId, id) => {
            const isSameDoc = docId === document.id || docId === document.linkId;
            if (isSameDoc && anchorsInUse.has(id)) {
                return `<a href="#${id}">`;
            }
            else {
                return m; // links to anchors outside document are kept as is
            }
        });
        // empty lines
        const emptyLineRegex = /(<p[^<>]*?>.+?<\/p>)\s*?<p[^<>]*?>.?<\/p>(\s*?<p[^<>]*?>.+?<\/p>)/g;
        while (emptyLineRegex.test(content)) {
            content = content.replace(emptyLineRegex, '$1\n$2'); // remove empty lines between paragraphs
        }
        // fix non-paragraph code blocks
        content = XHtmlConverter.fixCodeBlocks(content);
        // lists
        content = XHtmlConverter.fixLists(content);
        // style
        content = content
            .replace(/(<td(?!\S)[^<>]*?class='.*?bold.*?'[^<>]*?>)([\s\S]*?)((?:\s*<br\/>\s*)?<\/td>)/g, '$1<b>$2</b>$3') // fix bold format of spreadsheet cells
            .replace(/(<td(?!\S)[^<>]*?class='.*?italic.*?'[^<>]*?>)([\s\S]*?)((?:\s*<br\/>\s*)?<\/td>)/g, '$1<i>$2</i>$3') // fix italic format of spreadsheet cells
            .replace(/(<td(?!\S)[^<>]*?class='.*?underline.*?'[^<>]*?>)([\s\S]*?)((?:\s*<br\/>\s*)?<\/td>)/g, '$1<u>$2</u>$3') // fix underline format of spreadsheet cells
            .replace(/(<td(?!\S)[^<>]*?class='.*?strikethrough.*?'[^<>]*?>)([\s\S]*?)(<\/td>)/g, '$1<del>$2</del>$3') // fix strikethrough format of spreadsheet cells
            .replace(/<(\w+?)([^<>]*?) class='[^<>]*?'([^<>]*?)>/g, '<$1$2$3>') // remove any 'class' attributes
            .replace(/<f([^<>]*?)>/g, '<span$1>') // fix highlighting
            .replace(/<\/f>/g, '</span>')
            .replace(/ textcolor="#[0-9]{6}"/g, '') // remove textcolor attribute
            .replace(/<code>/g, "<span class='monospace'>") // fix code font
            .replace(/<\/code>/g, '</span>')
            .replace(/<q((?!\S)[^<>]*?)?>/g, '<blockquote$1>') // make pull quote equal block quote
            .replace(/<\/q>/g, '</blockquote>')
            .replace(/<(?!\/)blockquote(?:([^<>]*?)(?: style='(.*?)')|([^<>]*?))([^<>]*)>/g, "<blockquote$1$3 style='font-size: inherit; $2'$4>") // fix block quote font size
            .replace(/(<img [^<>]*?)(?: width=(["']).*?\2)([^<>]*>)/g, '$1$3') // remove width attribute of images
            .replace(/(<img [^<>]*?)(?: height=(["']).*?\2)([^<>]*>)/g, '$1$3') // remove height attribute of images
            .replace(/(<li[^<>]*><span(?:[^<>]*( style='(.*?)')|[^<>]*))([^<>]*>(<.*?>){0,1}?(<img src=[^<>]*>)+?)/g, (m, left, attr, attrValue, right) => {
            if (attr) {
                const newAttr = attrValue ? attr.replace(attrValue, attrValue + '; vertical-align: top;') : ` style='vertical-align: top;'`;
                return left.replace(attr, newAttr) + right;
            }
            else {
                return left + ` style='vertical-align: top;'` + right;
            }
        });
        // fix attachment links
        content = XHtmlConverter.fixAttachmentLinks(content, document.wikiAddr, attachments);
        // decorate comments and highlights
        content = XHtmlConverter.decorateComments(content, messagesContent.references);
        // quip tags: -wiki-sortable-tables-
        let sortableTablesTag = '';
        // extract sortable tables
        const sortableTables = XHtmlConverter.getSortableTables(document, content);
        // fix tables/sheets
        content = XHtmlConverter.fixTables(content);
        // add sortable styling
        if (sortableTables.size > 0) {
            content = XHtmlConverter.setSortableTables(content, sortableTables);
            sortableTablesTag = `<!--startmacro:enableSortableTables|-||-|--><!--stopmacro-->\n`;
        }
        // macros
        content = content
            .replace(/<math>([\s\S]*?)<\/math>/g, (match, eq) => `<!--startmacro:formula|-||-|${eq.replace(/\\/g, '\\\\')}--><!--stopmacro-->`) // set math equations with formula macro (and escape '\')
            .replace(/<design-inspector src='(.*?)' width='(.*?)' height='(.*?)'\s*\/>/g, (match, diUrl, width, height) => `<!--startmacro:iframe|-|url="${diUrl}" width="1100px" height="${Math.trunc(1.375 * parseInt(height))}px"--><!--stopmacro-->`) // set design-inspector diagrams with iframe macro
            .replace(/<(p|td)(?:(?!\S)[^<>]*)?>([\s\S]*?)<\/\1>/g, (section, tagName, innerSection) => {
            const regex = /--wiki-macro:\s*["“”](.*?)["“”]\s*--/g;
            let outputMacros = '';
            let outputInline = innerSection;
            let nonMacroContent = innerSection;
            let match = regex.exec(innerSection);
            while (match) {
                const tag = match[0];
                const tagArgs = match[1];
                const macro = XHtmlConverter.createMacro(tag, tagArgs);
                outputMacros = outputMacros + macro;
                outputInline = outputInline.replace(tag, macro);
                nonMacroContent = nonMacroContent.replace(tag, '');
                match = regex.exec(innerSection);
            }
            const hasInlineMacros = !!(nonMacroContent.replace(/<[^<>]+>/g, '').trim());
            if (outputMacros) {
                const output = hasInlineMacros ? outputInline : outputMacros;
                if (tagName === 'td' || hasInlineMacros) {
                    return section.replace(innerSection, output);
                }
                else {
                    return output;
                }
            }
            else {
                return section;
            }
        });
        // quip tags: wiki-header and wiki-footer
        const headerTag = XHtmlConverter.getHeaderContent(document);
        const footerTag = XHtmlConverter.getFooterContent(document);
        // quip tags: wiki-toc
        let tocTag = '\n';
        let isTocFloating = true;
        const tocTagExists = document.findTag(TOC_TAG);
        if (tocTagExists) {
            const tocArgs = document.readTagValue(TOC_TAG, '');
            const isTocClassic = XHtmlConverter.getBooleanArgValue(tocArgs, 'classic', false);
            isTocFloating = !isTocClassic && XHtmlConverter.getBooleanArgValue(tocArgs, 'floating', true);
            tocTag = XHtmlConverter.getTableOfContentsXHTML(tocArgs);
        }
        // quip tag: --wiki-link-target: "(_blank|_top|_self|_parent)"--
        const linkTargetTag = document.getWikiLinkTargetTag();
        if (linkTargetTag) {
            content = content.replace(/<a([^>]*?)(?=>)/g, function (match, group) {
                if (group.includes('target='))
                    return match;
                return `<a${group} target="${linkTargetTag}"`;
            });
        }
        // quip tags: wiki-tracker
        let trackTag = '';
        const trackId = document.readTagValue(TRACKER_TAG, null);
        if (trackId && Utils.test(XHtmlConverterConstants.GUID_REGEX, trackId.trim())) {
            const pixelId = trackId.trim();
            const wikiAddr = document.wikiAddr.replace(/\//g, '.');
            trackTag = `<!--startmacro:transclude|-|name="HowMany" args="PixelID=${pixelId}|Page=${wikiAddr}|Param=QuipDocId:${document.linkId}"--><!--stopmacro-->`;
        }
        // quip tags: -wiki-banner-
        const bannerPosition = document.getBannerPosition(singletons);
        if (content.includes("--wiki-ignore--")) {
            // quip tags: -wiki-ignore-
            content = content
                .replace(/<p[^<>]*?>\s*(\s*<[^p][^<>]*>\s*)*\s*--wiki-ignore--\s*(\s*<[^p][^<>]*>\s*)*\s*<\/p>[\s\S]+?<p[^<>]*?>\s*(\s*<[^p][^<>]*>\s*)*\s*--wiki-ignore--\s*(\s*<[^p][^<>]*>\s*)*\s*<\/p>/g, '') // remove block of text between '--wiki-ignore--' tags
                .replace(/<p[^<>]*?>\s*(\s*<[^p][^<>]*>\s*)*\s*--wiki-ignore--\s*(\s*<[^p][^<>]*>\s*)*\s*<\/p>[\s\S]*/g, ''); // remove anything after '--wiki-ignore--' tag
        }
        // spreadsheet sheets as tabs
        if (document.type == 'spreadsheet') {
            const selectedSheets = document.readTagValue(SHEETS_TAG, '').split(/\s*[;,]\s*/).filter(s => s && s.length > 0);
            content = XHtmlConverter.transformAsTabXHTML(content, selectedSheets, document.sheetsDesiredOrder);
        }
        // quip tags: clean-up
        content = content
            //.replace(/(<p(?: [^<>]*)?>)((<[^<>]*>|\s)*?--wiki-[\w-]+?(:.*?)?--(<[^<>]*>|\s)*?(?=<br\/>)<br\/>)+/g, '$1');
            .replace(/<p( [^<>]*)?>(<(?!\/p)[^<>]*>|\s)*?--wiki-[\w-]+?(:.*?)?--(<[^<>]*>|\s)*?<\/p>/g, '') // remove any quip2wiki tag
            .replace(/<p( [^<>]*)?>(<(?!\/p)[^<>]*>|\s)*?--quip2wiki-[\w-]+?(:.*?)?--(<[^<>]*>|\s)*?<\/p>/g, ''); // remove the new quip2wiki-options tag
        // line spacing
        content = content.replace(/<\/p>\n\n<p>/g, '\n<br/>');
        // remove line at end of doc
        content = content.replace(/<hr\/>(\s*<p>\s*<\/p>)*\s*$/g, '');
        const bannerContent = XHtmlConverter.getBannerXHTML(document.type, document.linkId, bannerPosition);
        const headerBanner = bannerPosition === BannerPosition.TOP ? bannerContent : '';
        const footerBanner = bannerPosition !== BannerPosition.TOP ? bannerContent : ''; // if BOTTOM or HIDDEN
        // noinspection HtmlRequiredAltAttribute
        const trackerPixel = options.trackerPixel ? `<img src="${options.trackerPixel}" />` : '';
        const tocTagBefore = isTocFloating ? tocTag : '';
        const tocTagAfter = !isTocFloating ? tocTag : '';
        const quipUrl = `${QUIP_URL}/${document.linkId}`;
        const warning = XHtmlConverterConstants.EDIT_IN_QUIP_COMMENT
            .replace(/\{\{docType\}\}/g, document.type)
            .replace(/\{\{quipUrl\}\}/g, quipUrl);
        // noinspection HtmlRequiredLangAttribute
        return [`<!-- \n\n\n${warning}\n\n\n -->\n`,
            '<html>\n<body>\n',
            headerTag,
            tocTagBefore,
            headerBanner,
            trackerPixel,
            tocTagAfter,
            sortableTablesTag,
            content,
            messagesContent.htmlContent,
            trackTag,
            footerBanner,
            footerTag,
            '</body>\n</html>']
            .join('')
            .replace(/\n\n\n/g, '\n\n');
    }
    static getTableOfContentsXHTML(args) {
        const isClassic = XHtmlConverter.getBooleanArgValue(args, 'classic', false);
        const isFloating = XHtmlConverter.getBooleanArgValue(args, 'floating', true);
        const isNumbered = XHtmlConverter.getBooleanArgValue(args, 'numbered', false);
        const startValue = XHtmlConverter.getNumericArgValue(args, 'start', 2);
        const depthValue = XHtmlConverter.getNumericArgValue(args, 'depth', 3);
        const start = Math.max(1, Math.min(startValue, 6)); // allowed values: 1-6
        const depth = Math.max(1, Math.min(depthValue, 6)); // allowed values: 1-6, even though Quip only has 3 levels
        const tocHtml = isClassic ? XHtmlConverterConstants.TOC_CLASSIC : XHtmlConverterConstants.TOC_BOXED;
        return tocHtml
            .replace('{{boxClass}}', isFloating ? XHtmlConverterConstants.FLOATING_BOX_CLASS : XHtmlConverterConstants.BOX_CLASS)
            .replace('{{isNumbered}}', isNumbered ? 'true' : 'false')
            .replace('{{start}}', String(start))
            .replace('{{depth}}', String(depth));
    }
    static getBooleanArgValue(args, name, defaultValue) {
        try {
            const sName = escapeRegExp(name);
            if (defaultValue) {
                const foundFalse = new RegExp(`(?:^${sName}|[\\s;,|]${sName})\\s*=\\s*(false|'false')(?:(?=[\\s;,|])|$)`).test(args);
                return !foundFalse;
            }
            else {
                return new RegExp(`(?:^${sName}|[\\s;,|]${sName})\\s*=\\s*(true|'true')(?:(?=[\\s;,|])|$)`).test(args);
            }
        }
        catch {
            return defaultValue;
        }
    }
    static getNumericArgValue(args, name, defaultValue) {
        try {
            const sName = escapeRegExp(name);
            const valueStr = args.match(new RegExp(`(?:^${sName}|[\\s;,|]${sName})\\s*=\\s*(?:(\\d+)|'(\\d+)')(?:(?=[\\s;,|])|$)`))[1];
            const value = parseInt(valueStr);
            if (!Number.isFinite(value)) {
                logger.log("[src/q2w/XHtmlConverter.ts:401:17]", `Invalid number (${value}). Returning default value: ${defaultValue}`);
                return defaultValue;
            }
            return value;
        }
        catch {
            return defaultValue;
        }
    }
    static getBannerXHTML(docType, id, bannerPosition = BannerPosition.TOP) {
        if (bannerPosition === BannerPosition.NONE) {
            return '';
        }
        const quipUrl = QUIP_URL;
        let isTimestampCached = sessionState.reproductionData.timestamps.xhtml != undefined;
        if (sessionState.isReproductionRun && !isTimestampCached) {
            sessionState.reproductionData.timestamps.xhtml = new Date().toUTCString();
            isTimestampCached = true;
        }
        const now = isTimestampCached ? sessionState.reproductionData.timestamps.xhtml : new Date().toUTCString();
        const msg = `This page was created by <a href="/bin/view/Quip2Wiki">Quip2Wiki</a> ` +
            `from a Quip ${docType} (<a href="${quipUrl}/${id}">See original</a>) at '${now}'`;
        const clazz = (bannerPosition === BannerPosition.HIDDEN ? 'hidden-print hidden' : 'hidden-print');
        const prefix = (bannerPosition !== BannerPosition.TOP ? `<hr/>\n` : '');
        const suffix = (bannerPosition === BannerPosition.TOP ? `\n<hr/>` : '');
        return `<div class='${clazz}'>\n${prefix}` +
            `<p><i style='color:#888888; font-size:small;'>${msg}</i></p>` +
            `${suffix}\n</div>\n`;
    }
    static fixCodeBlocks(content) {
        // Note for the future: both `line-height: unset` and `line-height: 1.428` preserve the same appearance as the usual wiki code block
        /* Wrap the code block with a div with class 'q2w-c'.
        * Lines within the same span need to be split into separate spans to ensure the backgrounds look correct
        * The following CSS makes the background extend further out and connect with other lines
.q2w-c {
  font-family: Menlo,Monaco,Consolas,"Courier New",monospace;
  line-height: unset;
  white-space: pre;
}

.q2w-c span {
  display: inline-block;
}
        * There may be a <code> element within the <pre> block. This has no outward appearance in Quip, but changes the code look in the wiki
        * So we need to remove <code> tags.
        * Use aria-role="pre" in the div
        * */
        const regex = /<span[^<>]*class='prettyprint'[^<>]*>/gi;
        let match;
        do {
            match = regex.exec(content);
            if (match) {
                const begin = match.index + match[0].length;
                let end = content.indexOf('</span>', begin);
                while (true) {
                    const part = content.substring(begin, end);
                    const spanCount = (part.match(/<span/gi) || []).length;
                    const spanCloseCount = (part.match(/<\/span>/gi) || []).length;
                    if (spanCount == spanCloseCount) {
                        break;
                    }
                    else {
                        end = content.indexOf('</span>', end + 1);
                    }
                }
                const innerBlock = content.substring(begin, end);
                const outerBlock = content.substring(match.index, end + 7);
                content = content.replace(outerBlock, `<pre>${innerBlock}</pre>`);
            }
        } while (match);
        return content;
    }
    static fixLists(content) {
        const continuationInfo = { start: 1, count: 0 };
        return content
            .replace(/<div[^<>]*?data-section-style='5'[^<>]*?>([\s\S]*?)<\/div>/g, XHtmlConverter.fixBulletList)
            .replace(/<div[^<>]*?data-section-style='7'[^<>]*?>([\s\S]*?)<\/div>/g, XHtmlConverter.fixTaskList)
            .replace(/<div([^<>]*?data-section-style='6'[^<>]*?)>([\s\S]*?)<\/div>/g, (match, divContent, list) => {
            const listContent = XHtmlConverter.fixNumberedList(match, list);
            return XHtmlConverter.fixNumberedListContinuation(listContent, divContent, continuationInfo);
        });
    }
    static fixBulletList(match, list) {
        const ulStack = [];
        return list
            .replace(/<\/span>\s*?<br\/>\s*?<\/li>/gm, '</span></li>\n')
            .replace(/(?:<\/li>)?(\s*<ul>)|(<\/ul>)/g, (match, p1) => {
            if (p1 && p1.includes('<ul>')) {
                const shouldFix = match.includes('</li>');
                ulStack.push(shouldFix);
                return p1;
            }
            else {
                const shouldFix = ulStack.pop();
                return match + (shouldFix ? '</li>' : '');
            }
        });
    }
    static fixNumberedList(match, list) {
        const numberedList = XHtmlConverter.fixBulletList(match, list)
            .replace(/<ul>/g, '<ol>')
            .replace(/<\/ul>/g, '</ol>');
        return XHtmlConverter.setNumberedListStyle(numberedList, 0);
    }
    static fixNumberedListContinuation(listContent, divContent, continuationInfo) {
        const listHtml = new DOMParser().parseFromString(listContent, 'text/html');
        const itemCount = [...listHtml.querySelectorAll('body > ol > li, body > ul > li')].length;
        const isContinuation = /class=(["']).*list-numbering-continue.*\1/.test(divContent);
        if (isContinuation) {
            const startValue = continuationInfo.start + continuationInfo.count;
            continuationInfo.count = continuationInfo.count + itemCount;
            return listContent.replace(/^([\s\S]*?)<ol([^<>]*?)>/, `$1<ol$2 start="${startValue}">`);
        }
        else {
            let startValue = 1;
            const hasStartNumber = /class=(["']).*list-numbering-restart-at.*\1/.test(divContent);
            if (hasStartNumber) {
                const startMatch = divContent.match(/style="--indent0: (\d+)"/)[1];
                startValue = Number.parseInt(startMatch);
            }
            continuationInfo.start = startValue;
            continuationInfo.count = itemCount;
            if (startValue > 1) {
                return listContent.replace(/^([\s\S]*?)<ol([^<>]*?)>/, `$1<ol$2 start="${startValue}">`);
            }
            else {
                return listContent;
            }
        }
    }
    static setNumberedListStyle(list, level) {
        const types = XHtmlConverterConstants.NUMBERED_LIST_STYLES;
        const len = XHtmlConverterConstants.NUMBERED_LIST_STYLES.length;
        const first = list.indexOf('<ol>');
        if (first < 0) {
            return list;
        }
        const listBegin = list.substring(0, first + 4).replace('<ol>', `<ol type="${types[level % len]}">`);
        const listRest = list.substring(first + 4);
        const next = listRest.indexOf('<ol>');
        if (next < 0) {
            return listBegin + listRest;
        }
        else {
            const end = listRest.indexOf('</ol>');
            let nextLevel = level + 1;
            if (end < next) {
                const upLevel = (listRest.substring(0, next).match(/<\/ol>/g) || []).length;
                nextLevel -= upLevel;
            }
            return listBegin + XHtmlConverter.setNumberedListStyle(listRest, nextLevel);
        }
    }
    static fixTaskList(match, list) {
        return XHtmlConverter.fixBulletList(match, list)
            .replace(/<li[^<>]*?(?:class='(.*?)'[^<>]*?)?>\s*<span[^<>]*>(.*?)<\/span>\s*(<\/li>|<ul>)/g, (m, classVal, value, closeTag) => {
            if (!classVal || !classVal.includes('checked')) {
                return `<li><span style="font-weight: bold; font-size: large;">&#9744;</span> ${value}${closeTag}`; // uncompleted
            }
            else {
                return `<li><span style="font-weight: bold; font-size: large;">&#9745;</span> <del>${value}</del>${closeTag}`; // completed tasks
            }
        })
            .replace(/<ul[^<>]*>/g, '<ul style="list-style-type:none;">'); // force list style to 'none' (hidden);
    }
    static getSortableTables(document, content) {
        const sortableTables = new Map();
        const containsSortableTablesTag = document.findTag(SORTABLE_TABLES_TAG);
        if (containsSortableTablesTag) {
            // get all tables
            const allTables = [...content.matchAll(/<table(?: [^<>]*)? title='(.*?)'(?:[^<>]*?)>/g)].map(m => m[1]);
            // extract sortable sheets
            const tablesInTag = document.readTagValue(SORTABLE_TABLES_TAG, '').split(/\s*[;,]\s*/).filter(s => s && s.length > 0);
            // add to sotableTables map
            const tablesToAdd = tablesInTag.length > 0 ? tablesInTag : allTables;
            tablesToAdd.forEach(title => sortableTables.set(title, 'sortable'));
        }
        // extract table tags
        [...content.matchAll(XHtmlConverterConstants.SORTABLE_TABLE_TAGS_REGEX)].forEach(m => {
            const title = m[2];
            const tag = m[3];
            sortableTables.set(title, tag);
        });
        return sortableTables;
    }
    static setSortableTables(content, sortableTables) {
        // enable sorting (requires class and id attributes)
        content = content.replace(/<table([^<>]*)? title='(.*?)'([^<>]*?)>\s*<thead><tr( [^<>]*)?>/g, (m, attr1, title, attr2, headerAttr) => {
            const type = sortableTables.get(title);
            let tableClass;
            if (type === TABLE_SORTABLE_INLINE_TAG) {
                tableClass = XHtmlConverterConstants.CLASS_SORTABLE;
            }
            else if (type === TABLE_SORT_ONLY_INLINE_TAG) {
                tableClass = XHtmlConverterConstants.CLASS_SORT_ONLY;
            }
            else if (type === TABLE_FILTER_ONLY_INLINE_TAG) {
                tableClass = XHtmlConverterConstants.CLASS_FILTER_ONLY;
            }
            else {
                return m; // do not change
            }
            const headerClass = type ? ' class="sortHeader"' : '';
            const idAttr = m.match(/(?<= )id='.+?'/) || `id='${title}'`;
            const attr = (attr1 || '') + (attr2 || '').replace(idAttr, '');
            return `<table title='${title}' ${idAttr} class='${tableClass}'${attr}><thead><tr${headerAttr}${headerClass}>`;
        });
        return content;
    }
    static fixTables(content) {
        const thStyle = 'background-color:#E1E1E1;';
        return content
            .replace(/\u200b/g, '') // clean unwanted chars
            .replace(/<table[^<>]*?title='(.*?)'[^<>]*?>/g, (m, sheet) => m.replace(`title='${sheet}'`, `title='${sanitizeHTMLText(sheet)}'`)) // fix unescaped sheet name
            .replace(/<table[^<>]*?>\s*<tbody[^<>]*?><tr[^<>]*?>[\s\S]*?<\/tr>/g, m => {
            return m.replace(/<tbody([^<>]*?)>/g, '<thead$1>')
                .replace(/<td([^<>]*?)>/g, '<th$1>')
                .replace(/<\/td>/g, '</th>')
                .replace(/<\/tr>/g, '</tr></thead><tbody>');
        })
            .replace(/<table ([^<>]*?)>/g, "<table $1 border='1px' borderColor='#c7cbd1'>") // set table basic style
            .replace(/<thead><tr><th(?:(?!\S)[^<>]*?)?\/>/g, '<thead><tr>') // remove row number header
            .replace(/<tr><td(?:(?!\S)[^<>]*?)?>\d+<\/td>/g, '<tr>') // remove row number column
            .replace(XHtmlConverterConstants.SORTABLE_TABLE_TAGS_REGEX, (m, left, title, tag, right) => {
            return left + right;
        })
            .replace(/<thead><tr>(?:<th\s+style='[^<>]*?'>[A-Z]+<br\/><\/th>)+<\/tr><\/thead><tbody><tr>([\s\S]+?)<\/tr>/g, (match, p1) => {
            const widths = [];
            match.replace(/<th\s+style='([^<>]*?)'>/g, (m, g1) => {
                widths.push(g1);
                return '';
            });
            let count = 0;
            const header = p1
                .replace(/<td\s+style='([^<>]*?)'>/g, (m, g1) => `<th style='${widths[count++]}; ${g1}'>`)
                .replace(/<td>/g, `<th style='${widths[count++]};'>`)
                .replace(/<\/td>/g, '</th>');
            return `<thead><tr>${header}</tr></thead><tbody>`;
        })
            .replace(/(<tr>(<td(?:(?!\S)[^<>]*?)?>((?:<[bui]>|<span>)\s*?)*((?:<\/[bui]>|<\/span>)\s*?)*<br\/><\/td>)+<\/tr>)*<\/tbody>/g, '</tbody>') // remove empty lines at the end
            .replace(/<table[^<>]*?>[\s\S]*?<\/table>/g, (match) => {
            let maxCols = 0;
            match.replace(/<tr>([\s\S]*?)(?:<td(?:(?!\S)[^<>]*?)?><span><\/span>\s*<br\/><\/td>)*<\/tr>/g, (m, p1) => {
                const countCells = ((p1 || '').match(/<td/g) || []).length;
                const countHeaders = ((p1 || '').match(/<th/g) || []).length - ((p1 || '').match(/><span><\/span>\n\n<br\/><\/th>/g) || []).length;
                maxCols = Math.max(countCells, countHeaders, maxCols);
                return '';
            });
            if (maxCols == 0) {
                return match;
            }
            return match
                .replace(new RegExp(`<tr>((?:<th(?:(?!\S)[^<>]*?)?>[\\s\\S]*?<\\/th>){${maxCols}})(?:<th(?:(?!\S)[^<>]*?)?>[\\s\\S]*?<\\/th>)*<\\/tr>`, 'g'), '<tr>$1</tr>') // remove empty columns in table header
                .replace(new RegExp(`<tr>((?:<td(?:(?!\S)[^<>]*?)?>[\\s\\S]*?<\\/td>){${maxCols}})(?:<td(?:(?!\S)[^<>]*?)?>[\\s\\S]*?<\\/td>)*<\\/tr>`, 'g'), '<tr>$1</tr>'); // remove empty columns in table rows
        })
            .replace(/<thead( [^<>]*)?><tr>/g, `<thead$1><tr style='${thStyle}'>`)
            .replace(/(<th(?:(?!\S)[^<>]*?)?>[\s\S]*?)<br\/>\s*(<\/th>)/g, '$1$2') // clean up <br/> in th
            .replace(/(<td(?:(?!\S)[^<>]*?)?>[\s\S]*?)<br\/>\s*(<\/td>)/g, '$1$2') // clean up <br/> in td
            .replace(/(<td(?:(?!\S)[^<>]*?)?>)((?:<[bui]>|<span>)\s*?)*((?:<\/[bui]>|<\/span>)\s*?)*(<\/td>)/g, '$1$4'); // clean up empty td
    }
    static getHeaderContent(doc) {
        const headerValues = doc.getWikiHeaders();
        return XHtmlConverter.convertHeaderOrFooterToXHTML(headerValues);
    }
    static getFooterContent(doc) {
        const footerValues = doc.getWikiFooters();
        return XHtmlConverter.convertHeaderOrFooterToXHTML(footerValues);
    }
    static convertHeaderOrFooterToXHTML(values) {
        if (values.length == 0) {
            return '';
        }
        return values
            .map(tag => {
            // @ts-expect-error // TODO fix the possible null pointer exception below
            const url = tag.addr.replace(/\//g, '.');
            const name = `name="space:${url}"`;
            const args = tag.args ? `args="${tag.args}"` : '';
            return `<!--startmacro:transclude|-|${name} ${args}--><!--stopmacro-->`;
        })
            .join('') // for some reason, a line break between macros appears as an empty line between them
            .concat('\n');
    }
    /**
     * Creates an XHTML macro tag.
     *
     * Macros are defined using Quip2Wiki tag as follows:
     * > --wiki-macro: "macro_name=transclude, name='space:Quip2Wiki.SyntaxXHTML', section='HFormattedLines'"--
     *
     * The created tag will work with the following patterns:
     * > <!--startmacro:macro_name--><!--stopmacro-->
     * > <!--startmacro:macro_name|-||-|content--><!--stopmacro-->
     * > <!--startmacro:macro_name|-|parameter_name1=parameter1_value parameter_name2=parameter2_value--><!--stopmacro-->
     * > <!--startmacro:macro_name|-|parameter_name=parameter_value|-|content--><!--stopmacro-->
     * See: https://w.amazon.com/bin/view/AmazonWiki/API/Client#HSyntax
     */
    static createMacro(tag, tagContent) {
        const request = {};
        const regex = /\s*([a-zA-Z-_]+)\s*=([^\s'",]+|'.*?')\s*(?:,|$)/g;
        let part = regex.exec(tagContent);
        while (part) {
            try {
                const key = part[1];
                const value = part[2]
                    .replace(/<[^<>]+?>/g, '')
                    .replace(/\\n/g, '\n')
                    .replace(/\\t/g, '\t')
                    .replace(/\\"/g, '"')
                    .replace(/&lt;/g, '<')
                    .replace(/&gt;/g, '>')
                    .replace(/&amp;/g, '&')
                    .replace(/^\s*'|'\s*$/g, '"');
                request[key] = value;
            }
            catch {
                /* empty */
            }
            part = regex.exec(tagContent);
        }
        const macroName = request.macro_name;
        const macroContent = request.content ? request.content.replace(/^\s*"|"\s*$/g, '') : '';
        const isUnsupportedMacro = ['box'].includes(macroName) || XHtmlConverterConstants.BANNER_TYPES.includes(macroName);
        if (!macroName) {
            logger.error("[src/q2w/XHtmlConverter.ts:758:13]", `Invalid macro tag: ${tag}`);
            return tag;
        }
        else if (isUnsupportedMacro) {
            const macroContentHtml = macroContent.replace(/\n/g, '<br/>');
            let bannerClass = '';
            if (XHtmlConverterConstants.BANNER_TYPES.includes(macroName)) {
                bannerClass = `${macroName}message`;
            }
            return `<p class="box ${bannerClass}">${macroContentHtml}</p>`;
        }
        else {
            let macro = `<!--startmacro:${macroName}|-|`;
            for (const key in request) {
                if (key == 'macro_name' || key == 'content') {
                    continue;
                }
                macro += `${key}=${request[key]} `;
            }
            macro = macro.trimEnd();
            if (macroContent) {
                macro += `|-|${macroContent}`;
            }
            macro = macro.replace(/(.*)\|-\|$/g, '$1'); // if there is no params or content
            macro += '--><!--stopmacro-->';
            return macro;
        }
    }
    static fixAttachmentLinks(content, wikiAddr, attachments) {
        // Add wikiAddr to correctly link the URL when exporting folders
        const wikiUrl = DOWNLOAD_URL + (wikiAddr || '') + '/WebHome';
        for (const [title, attachment] of attachments.entries()) {
            for (const replacer of attachment.replacers) {
                if (attachment.skip) {
                    content = content.replace(new RegExp(`<img src=(["'])${replacer}\\1`, 'g'), `<img src="${QUIP_URL}${replacer}"`);
                    continue;
                }
                content = content.replaceAll(replacer, `${wikiUrl}/${title}`);
                content = content.replaceAll(replacer, title);
            }
        }
        return content;
    }
    static transformAsTabXHTML(content, selectedSheets, sheetsOrder) {
        // <!--startmacro:tabs|-|idsToLabels='tabId1=Tab One, tabId2=Tab Two'--><!--stopmacro-->
        // <div id="tabId1" style="display: block;"><p>My tab 1 content goes here.</p></div>
        // <div id="tabId2" style="display: block;"><p>My tab 2 content goes here.</p></div>
        // if selectedSheets is null or empty, we export all sheets
        const canExportSheet = (title) => !selectedSheets || selectedSheets.length == 0 || selectedSheets.includes(title);
        const sheets = new Map();
        const parts = content.split(/(?=<div data-section-style='13'><table)/);
        let before = '';
        for (const part of parts) {
            const match = part.match(/<table(?:[^<>]*)? title='(.+?)'[^<>]*?>/);
            if (match && match[1]) {
                sheets.set(match[1], part);
            }
            else {
                before += part;
            }
        }
        const exportableSheets = Array.from(sheets.entries())
            .map(([title, content]) => {
            return { title, content };
        })
            .filter((sheet) => canExportSheet(sheet.title));
        if (exportableSheets.length == 1) {
            const sheetTitle = exportableSheets[0].title;
            if (/(Sheet|Folha|Feuille|Hoja|Foglio|Blatt|床单|床單)\d+|/.test(sheetTitle)) {
                return exportableSheets[0].content;
            }
        }
        // generate the ids and content in the correct order (same as shown in the Quip web UI)
        const escapedSheetsOrder = sheetsOrder?.map(title => sanitizeHTMLText(title));
        const ids = escapedSheetsOrder
            .filter((title) => canExportSheet(title))
            .map((title, index) => `id${index}=${title}`)
            .join(',');
        // generate contents
        const tabContent = escapedSheetsOrder
            .filter((title) => title.length > 0)
            .filter((title) => canExportSheet(title))
            .map((title, index) => {
            const actualSheet = exportableSheets.find((sheet) => sheet.title == title);
            if (!actualSheet) {
                const actualOptions = exportableSheets.map((sheet) => sheet.title);
                throw new Error(`Unable to find sheet with title '${title}' (options: ${actualOptions.join(',')})`);
            }
            return `<div id="id${index}" style="display: block;">${actualSheet.content}</div>\n`;
        })
            .join('');
        return before + `<!--startmacro:tabs|-|idsToLabels='${ids}'--><!--stopmacro-->\n` + tabContent + '\n';
    }
    static async convertQuipMessagesToXHTML(singletons, messages, doc) {
        if (!messages || messages.length == 0) {
            return { htmlContent: '', references: [] };
        }
        // test functions for valid messages
        const isChatMesage = (msg) => !msg.annotation;
        const sectionExists = (msg) => {
            const sectionId = XHtmlConverter.getAnnotationSectionId(msg);
            return !!doc.html.getElementById(sectionId);
        };
        // filter and sort valid messages
        const sortedMessages = messages
            .filter(msg => msg.visible)
            .filter(msg => isChatMesage(msg) || sectionExists(msg))
            .sort((a, b) => a.created_usec - b.created_usec);
        for (const msg of sortedMessages) {
            // decorate with author login
            msg.author_login = await getLoginFromQuipId(singletons, msg.author_id);
            // fix user mentions
            msg.text = await Utils.replaceAsyncSequence(msg.text, XHtmlConverterConstants.QUIP_MENTION_IN_COMMENT_REGEX, async (m, mentionedUserId, name) => {
                const login = await getLoginFromQuipId(singletons, mentionedUserId);
                if (login) {
                    return `<a href="https://phonetool.amazon.com/users/${login}">${name}</a>`;
                }
                else {
                    return m;
                }
            });
        }
        singletons.quipUserCache.persistCache();
        // extract comments
        const commentIds = [...new Set(sortedMessages
                .map(m => m.annotation)
                .filter(ann => ann)
                .map(ann => ann.id))];
        // convert comments
        let content = '<hr/>\n';
        const references = [];
        commentIds.forEach((annId, index) => {
            const comments = sortedMessages
                .filter(msg => msg.annotation && msg.annotation.id == annId);
            const id = index + 1;
            const commId = `comment-${id}`;
            const isHighlight = XHtmlConverter.isHighlightMessage(comments[0]);
            const commName = 'Comment #' + id + (isHighlight ? ' (Highlight)' : '');
            const commAuthor = comments[0].author_name;
            const sectionId = XHtmlConverter.getAnnotationSectionId(comments[0]);
            const textContent = comments.map(XHtmlConverter.getMessageText).join('&#10;');
            const xhtmlContent = comments.map(XHtmlConverter.getMessageXHTML).join('<br/>');
            content += `<div id="${commId}" class="box"><span style="color: transparent; text-shadow: 0 0 0 #ffdf99;">&#x1F4AC;</span><a href="#${sectionId}">${commName}:</a><br/>${xhtmlContent}\n</div>\n`;
            references.push({
                id: id,
                ref: commId,
                name: commName,
                author: commAuthor,
                sectionId: sectionId,
                isHighlight: isHighlight,
                popup: textContent
            });
        });
        // extract chat messages
        const chatMessages = sortedMessages
            .filter(msg => !msg.annotation)
            .map(XHtmlConverter.getMessageXHTML);
        // convert chat messages
        if (chatMessages.length > 0) {
            const chatContent = chatMessages.join('<br/>');
            content += `<div class="box"><b>Chat messages:</b><br/>${chatContent}\n</div>\n`;
        }
        return {
            htmlContent: content,
            references: references
        };
    }
    static async getUserLogin(singletons, fullName) {
        try {
            // get user login from full name
            const cleanFullName = fullName.replace(/[^a-zA-Z\s]/g, '').trim();
            return await singletons.maxis.getLoginFromFullName(cleanFullName);
        }
        catch {
            return null;
        }
    }
    static async checkUserLogin(singletons, login) {
        try {
            // get employee information from login
            const employee = await singletons.maxis.getEmployeeFromLogin(login);
            return !!employee;
        }
        catch {
            return null;
        }
    }
    static isHighlightMessage(message) {
        return message.annotation && message.annotation.highlighted_section_ids && message.annotation.highlighted_section_ids.length > 0;
    }
    static getAnnotationSectionId(message) {
        const highlightSectionId = message.annotation.highlighted_section_ids;
        if (highlightSectionId && highlightSectionId.length > 0) {
            return highlightSectionId[0].replace(';', '_'); // ids in thead do not contain ';'
        }
        else {
            return message.annotation.id;
        }
    }
    static getMessageXHTML(message) {
        const dateStr = XHtmlConverter.getDate(message.created_usec);
        const authName = message.author_name;
        const authLogin = message.author_login;
        let author;
        if (authLogin) {
            author = `<a href="https://phonetool.amazon.com/users/${authLogin}" style="text-decoration: none">${authName}</a>`;
        }
        else {
            author = authName;
        }
        return `<span>[${dateStr}] ${author} - ${message.text}</span>`;
    }
    static getMessageText(message) {
        const dateStr = XHtmlConverter.getDate(message.created_usec);
        const msgText = message.text.replace(/<[^<>]*?>|<\/[^<>]*?>/g, ''); // remove any html tag
        return sanitizeHTMLText(`[${dateStr}] ${message.author_name} - ${msgText}`);
    }
    static getDate(usec_timestamp) {
        const timestamp = Math.round(usec_timestamp / 1000.0);
        return new Date(timestamp).toISOString().slice(0, 19).replace('T', ' ') + ' UTC';
    }
    static decorateComments(docContent, comments) {
        const showComments = comments && comments.length > 0;
        if (!showComments) {
            // remove annotation highlight
            return docContent
                .replace(/<annotation[^<>]*>/g, '')
                .replace(/<\/annotation>/g, '');
        }
        const cellHighlight = (showComments ? XHtmlConverterConstants.CELL_HIGHLIGHT_STYLE : '');
        for (const comment of comments) {
            const sectionId = escapeRegExp(comment.sectionId);
            if (sectionId.startsWith('s:')) {
                // table/spreadsheet cells
                const regex = new RegExp(`(<(?:td|th)[^<>]*id='${sectionId}'[^<>]*?)(?: style='(.*?);?')?([^<>]*>)`, 'g');
                const title = `Highlight #${comment.id} by ${comment.author}` + '&#10;' + comment.popup;
                const link = XHtmlConverterConstants.ON_CLICK_TO_URL.replace('{{url}}', `#${comment.ref}`);
                docContent = docContent.replace(regex, `$1 style='$2;${cellHighlight}; cursor:pointer' title='${title}' ${link}$3`);
            }
            else {
                // paragraph (no highlight)
                const pRegex = new RegExp(`(<p[^<>]*id='${sectionId}'[^<>]*>)`, 'g');
                const pTitle = `Comment #${comment.id} by ${comment.author}` + '&#10;' + comment.popup;
                const pLink = XHtmlConverterConstants.ON_CLICK_TO_URL.replace('{{url}}', `#${comment.ref}`);
                const pIcon = `<span title='${pTitle}' ${pLink} style="color: transparent; text-shadow: 0 0 0 #ffdf99; position:absolute; margin-left:-20px; cursor:pointer">&#x1F4AC;</span>`;
                docContent = docContent.replace(pRegex, `$1${pIcon}`);
                // span (no highlight)
                const sRegex = new RegExp(`(<span[^<>]*id='${sectionId}'[^<>]*>)`, 'g');
                const sTitle = `Comment #${comment.id} by ${comment.author}` + '&#10;' + comment.popup;
                const sLink = XHtmlConverterConstants.ON_CLICK_TO_URL.replace('{{url}}', `#${comment.ref}`);
                const sIcon = `<span title='${sTitle}' ${sLink} style="color: transparent; text-shadow: 0 0 0 #ffdf99; position:absolute; margin-left:-20px; cursor:pointer">&#x1F4AC;</span>`;
                docContent = docContent.replace(sRegex, `$1${sIcon}`);
                // text highlight
                const tRegex = new RegExp(`<annotation[^<>]* id=(["'])${sectionId}\\1[^<>]*>`, 'g');
                const tTitle = `Highlight #${comment.id} by ${comment.author}` + '&#10;' + comment.popup;
                const tLink = XHtmlConverterConstants.ON_CLICK_TO_URL.replace('{{url}}', `#${comment.ref}`);
                docContent = docContent.replace(tRegex, `<annotation id='${sectionId}' style='background-color:#ffdf99; cursor:pointer;' title='${tTitle}' ${tLink}>`);
                // image (no highlight)
                const iRegex = new RegExp(`(<img[^<>]*id='${sectionId}'[^<>]*?)(?: title='([\\s\\S]*?)')?([^<>]*>)`, 'g');
                docContent = docContent.replace(iRegex, (m, left, title, right) => {
                    const newTitle = `Highlight #${comment.id} by ${comment.author}` + '&#10;' + comment.popup;
                    return left + " title='" + (title ? `${title}&#10;` : '') + newTitle + "'" + right;
                });
            }
        }
        return docContent
            .replace(/<annotation([^<>]*)>/g, '<span$1>')
            .replace(/<\/annotation>/g, '</span>');
    }
    static convertQuipFolderListingToXHTML(singletons, wrapper) {
        const quipUrl = QUIP_URL;
        const folder = wrapper.value.folder;
        const fId = folder.id;
        const url = `${quipUrl}/${fId}`;
        const title = folder.title;
        const listing = XHtmlConverter.convertQuipFolderListingToList(wrapper.children);
        const content = `<h3><span>All subfolders and documents in <a href="${url}"><i>${title}</i></a></span></h3>\n${listing}`;
        const msg = XHtmlConverter.getBannerXHTML('Folder', fId, singletons.settings.bannerPosition);
        const header = singletons.settings.bannerPosition === BannerPosition.TOP ? msg : '';
        const footer = singletons.settings.bannerPosition !== BannerPosition.TOP ? msg : ''; // if BOTTOM or HIDDEN
        return ['<html>\n<body>', header, content, footer, '</body>\n</html>'].join('');
    }
    static convertQuipFolderListingToList(itemList) {
        if (!itemList)
            return '';
        if (itemList.length == 0)
            return '';
        const quipUrl = QUIP_URL;
        const circle = XHtmlConverterConstants.CIRCLE;
        const resUrl = XHtmlConverterConstants.RESOURCE_URL;
        let output = '<ul style="list-style-type:none;">\n';
        for (const item of itemList) {
            if (item.type == 'document') {
                const metadata = item.metadata;
                if (!metadata)
                    throw new Error('Document is undefined, invalid state');
                const thread = metadata.getUnderlyingQuipThread();
                const quipDocUrl = `${quipUrl}/${thread.document_id || thread.id}`;
                const wikiPageAddr = item.wikiAddr; // metadata.wikiAddr ||
                const title = sanitizeHTMLText(metadata.title);
                const url = wikiPageAddr ? `/bin/view/${wikiPageAddr}` : quipDocUrl;
                const link = wikiPageAddr ? ` [<a href="${quipDocUrl}">Quip</a>]` : '';
                output += `<li><img src="${resUrl}/page_white_text.png" /> <a href="${url}">${title}</a>${link}</li>\n`;
            }
            else if (item.type == 'folder') {
                const title = sanitizeHTMLText(item.value.folder.title);
                const quipDocUrl = `${quipUrl}/${item.id}`;
                const fcolor = circle.replace('{{color}}', XHtmlConverter.convertQuipColor(item.value.folder.color));
                const children = item.children;
                output += `<li><img src="${resUrl}/folder.png" /> <a href="${quipDocUrl}">${title}</a> ${fcolor}`;
                if (children) {
                    output += XHtmlConverter.convertQuipFolderListingToList(children);
                }
                output += '</li>\n';
            }
        }
        output += '</ul>\n';
        return output;
    }
    static convertQuipColor(color) {
        switch (color) {
            case 'dark_yellow':
                return 'DarkGoldenrod';
            case 'manila':
                return 'Gold';
            case 'purple':
                return 'Purple';
            case 'light_purple':
                return 'Plum';
            case 'blue':
                return 'DodgerBlue';
            case 'light_blue':
                return 'LightBlue';
            case 'orange':
                return 'DarkOrange';
            case 'light_orange':
                return 'Orange';
            case 'red':
                return 'IndianRed';
            case 'light_red':
                return 'LightCoral';
            case 'green':
                return 'LimeGreen';
            case 'light_green':
                return 'LightGreen';
            default:
                return color;
        }
    }
}
const XHtmlConverterConstants = {
    RESOURCE_URL: 'https://w.amazon.com/bin/download/Quip2Wiki/resources/WebHome',
    CIRCLE: '<span style="color:{{color}}">&#9724;</span>',
    NUMBERED_LIST_STYLES: ["1", "a", "i", "A", "I"],
    GUID_REGEX: /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/,
    QUIP_MENTION_FULLNAME_REGEX: /<control data-remapped="true"[^<>]*?>(<a href="(https?:\/\/quip-amazon\.com\/.{11})">)\1([^<>]+?)<\/a><\/a><\/control>/g,
    QUIP_MENTION_LOGIN_REGEX2: /(?:<a [^<>]*>.*?(?:(?<!\w)@\w+|(?!\.\w+@)\w+@(?=[^\w]))(?![^<]*?>).*?(?!<a )<\/a>)|(?:(?<!\w)@(\w+)|(?!\.\w+@)(\w+)@(?=[^\w]))(?![^<]*?>)/g,
    QUIP_MENTION_IN_COMMENT_REGEX: /<a href="https?:\/\/quip(?:-amazon)?\.com\/(.{11})"[^<>]*>([^<>]+?)<\/a>/g,
    TOC_BOXED: `
<div class="{{boxClass}}" style="max-width: 550px">\nTable of Contents\n\
    <!--startmacro:toc|-|numbered={{isNumbered}} start={{start}} depth={{depth}}--><!--stopmacro-->\n\
</div>\n`,
    TOC_CLASSIC: '<!--startmacro:toc|-|numbered={{isNumbered}} start={{start}} depth={{depth}}--><!--stopmacro-->\n',
    BOX_CLASS: 'box',
    FLOATING_BOX_CLASS: 'box floatinginfobox',
    CLASS_SORTABLE: 'sortable filterable',
    CLASS_SORT_ONLY: 'sortable',
    CLASS_FILTER_ONLY: 'filterable',
    SORTABLE_TABLE_TAGS_REGEX: /(<table[^<>]*?title='(.*?)'[^<>]*?>[\s\S]*?)&lt;&lt;(sortable|sort-only|filter-only)&gt;&gt;([\s\S]*?<\/table>)/g,
    CELL_HIGHLIGHT_STYLE: 'background-image: linear-gradient(225deg, #ffdf99, #ffdf99 10px, transparent 10px, transparent);',
    ON_CLICK_TO_URL: "onclick=\"location.href='{{url}}';\"",
    BANNER_TYPES: ['success', 'info', 'warning', 'error'],
    EDIT_IN_QUIP_COMMENT: `
    DO NOT change the content of this Wiki\n\n\
    The content of this Wiki page was generated by Quip2Wiki tool from a Quip {{docType}}, so any change using Wiki editor can be lost when new updates from Quip2Wiki are submitted.\n\
    Please consider changing the original Quip {{docType}} at {{quipUrl}}`,
};

const WIKI_BASE_URL = 'https://w.amazon.com/bin/view';
class XWikiConverter {
    static async convertQuipHTMLToXWiki(singletons, document, attachments) {
        const props = {
            wikiAddr: document.getWikiSyncAddress(),
            docId: document.linkId,
            type: document.type,
            toc: XWikiConverter.getToc(document),
            bannerPosition: document.getBannerPosition(singletons),
            wikiTags: document.getWikiTags(),
            headers: document.getWikiHeaders(),
            footers: document.getWikiFooters(),
            showComments: document.getWikiComments(),
            isSortableTables: document.findTag(SORTABLE_TABLES_TAG) || Utils.test(XHtmlConverterConstants.SORTABLE_TABLE_TAGS_REGEX, document.htmlContent),
            sheets: XWikiConverter.getSheetsInOrder(document),
            titleOverride: XWikiConverter.getTitleOverride(document),
        };
        const cleanHtmlContent = this.handleTilde(document.htmlContent)
            // remove block of text between '--wiki-ignore--' tags
            .replace(new RegExp(String.raw `<p[^<>]*?>\s*(\s*<[^p][^<>]*>\s*)*\s*--${IGNORE_TAG}--\s*(\s*<[^p][^<>]*>\s*)*\s*<\/p>[\s\S]+?<p[^<>]*?>\s*(\s*<[^p][^<>]*>\s*)*\s*--${IGNORE_TAG}--\s*(\s*<[^p][^<>]*>\s*)*\s*<\/p>`), '')
            // remove anything after '--wiki-ignore--' tag
            .replace(new RegExp(String.raw `<p[^<>]*?>\s*(\s*<[^p][^<>]*>\s*)*\s*--${IGNORE_TAG}--\s*(\s*<[^p][^<>]*>\s*)*\s*<\/p>[\s\S]*`), '')
            // remove horizontal ruler at end of doc
            .replace(/<hr\/>(\s*<p>\s*<\/p>)*\s*$/g, '');
        const html = new DOMParser().parseFromString(cleanHtmlContent.replace(/\n/g, ''), 'text/html');
        // replace page title with override - first header is always the name of the document/sheet
        const showTitleInBody = props.titleOverride && props.titleOverride.isVisible;
        let firstHeader = html.body.querySelector('h1,h2,h3,h4,h5,h6');
        if (showTitleInBody && firstHeader) {
            firstHeader.textContent = props.titleOverride.title || document.title;
        }
        else {
            firstHeader?.remove();
            firstHeader = null;
        }
        // make tabs for each sheet in a spreadsheet
        let tabsMacroStart = '';
        if (props.type === 'spreadsheet') {
            // add tab separation markers
            XWikiConverter.insertTabElements(html, firstHeader, props.sheets);
            // create tab macro
            tabsMacroStart = XWikiConverter.getTabsMacro(props.sheets);
        }
        // Read configurations
        const linkTargetTag = document.getWikiLinkTargetTag();
        let content = [...html.body.children]
            .map(element => XWikiConverter.convertTags(element))
            .map(element => XWikiConverter.convert(element, 0, null, linkTargetTag))
            .join('\n');
        content = await XWikiConverter.fixMentions(singletons, content);
        content = XWikiConverter.fixAttachmentLinks(content, props.wikiAddr || 'undefined', attachments);
        content = content.replaceAll("[[<", "[[&lt;").replaceAll("]]>", "]]&gt;");
        const bannerContent = XWikiConverter.getBanner(props);
        const headerBanner = props.bannerPosition === BannerPosition.TOP ? bannerContent : '';
        const footerBanner = props.bannerPosition !== BannerPosition.TOP ? bannerContent : '';
        const tocTag = XWikiConverter.getTocContent(props.toc);
        const isTocFloating = props.toc && props.toc.isFloating && !props.toc.isClassic;
        const tocTagBefore = isTocFloating ? tocTag : '';
        const tocTagAfter = !isTocFloating ? tocTag : '';
        const headerTag = XWikiConverter.getHeaderOrFooterContent(props.headers);
        const footerTag = XWikiConverter.getHeaderOrFooterContent(props.footers);
        const sortableTablesTag = props.isSortableTables ? '{{enableSortableTables/}}\n' : '';
        const quipUrl = `${QUIP_URL}/${document.linkId}`;
        const warning = XHtmlConverterConstants.EDIT_IN_QUIP_COMMENT
            .replace(/\{\{docType\}\}/g, document.type)
            .replace(/\{\{quipUrl\}\}/g, quipUrl);
        return [`{{comment}}\n\n\n${warning}\n\n\n{{/comment}}\n\n`,
            headerTag,
            tocTagBefore,
            headerBanner,
            tocTagAfter,
            sortableTablesTag,
            tabsMacroStart,
            content,
            //messagesContent.htmlContent,
            //trackTag,
            footerBanner,
            footerTag
        ].join('');
    }
    static handleTilde(source) {
        if (source.includes("~")) {
            return source.replaceAll("~", "~~");
        }
        return source;
    }
    static getSheetsInOrder(document) {
        return document.sheetsDesiredOrder || document.getSheetNames();
    }
    static convert(element, level, listType, linkTargetTag) {
        if (!(element instanceof HTMLElement)) {
            return element?.textContent ? this.convertTextToXWikiSyntax(element?.textContent) : '';
        }
        if (!element) {
            return '';
        }
        const tagName = (element.tagName || '').toUpperCase();
        const innerContent = () => XWikiConverter.getInnerContent(element, level, listType, linkTargetTag);
        const styling = (toplevel) => XWikiConverter.getElementStyling(element, toplevel);
        const newLine = () => (level == 0 ? '\n' : '');
        let output = '';
        if (/H\d+/.test(tagName)) { // headings
            const level = parseInt(tagName.replace('H', ''));
            const marker = '='.repeat(level);
            output = styling() + `${marker} ${innerContent()} ${marker}` + newLine();
        }
        else if (tagName === 'P') { // paragraph
            output = styling() + innerContent();
        }
        else if (tagName === 'BR') {
            if (listType) {
                output = innerContent() + '\n';
            }
            else {
                output = innerContent() + '\\\\';
            }
        }
        else if (tagName === 'HR') { // line
            output = '----';
        }
        else if (tagName === 'B') { // bold
            output = `**${innerContent()}**`;
        }
        else if (tagName === 'U') { // underline
            output = `__${innerContent()}__`;
        }
        else if (tagName === 'I') { // italic
            output = `//${innerContent()}//`;
        }
        else if (tagName === 'DEL') { // strikethrough
            output = `--${innerContent()}--`;
        }
        else if (tagName === 'CODE') { // code/monospace
            output = `##${innerContent()}##`;
        }
        else if (tagName === 'SUP') { // superscript
            output = `^^${innerContent()}^^`;
        }
        else if (tagName === 'SUB') { // subscript
            output = `,,${innerContent()},,`;
        }
        else if (tagName === 'A') {
            output = XWikiConverter.getLinkInnerContent(element, level, listType, linkTargetTag);
        }
        else if (tagName === 'IMG') {
            const url = element.getAttribute('src')
                ?.replace(/data:image\/gif;base64.*/, VIDEO_POSTER);
            //const alt = element.getAttribute('alt');
            const hasBorder = element.parentElement.classList.contains('show-border');
            if (hasBorder) {
                output = `[[image:${url}||style="border: 1px solid #555"]]`;
            }
            else {
                output = `[[image:${url}]]`;
            }
        }
        else if (tagName === 'BLOCKQUOTE' || tagName === 'Q') { // block quote or pull quote
            output = styling() + `> ${innerContent()}`;
        }
        else if (tagName === 'DIV') {
            const dataSectionStyle = element.getAttribute('data-section-style') || '';
            if (dataSectionStyle === '5') { // formatted list
                output = XWikiConverter.getInnerContent(element, 0, 'bullet', linkTargetTag);
            }
            else if (dataSectionStyle === '6') { // numbered list
                output = XWikiConverter.getInnerContent(element, 0, 'numbered', linkTargetTag);
            }
            else if (dataSectionStyle === '7') { // checklist
                output = XWikiConverter.getInnerContent(element, 0, 'checklist', linkTargetTag);
            }
            else if (dataSectionStyle === '11') { // image or video
                output = innerContent() + '\n';
            }
            else {
                const isMultiColumnContainer = (el) => el.classList.contains('flexbox-layout-container') &&
                    el.querySelectorAll('div.flexbox-layout-column').length > 1;
                const isColumnContainer = (el) => el.classList.contains('flexbox-layout-column') &&
                    el.parentElement && isMultiColumnContainer(el.parentElement);
                if (isMultiColumnContainer(element)) {
                    output = `\n{{container layoutStyle="columns"}}\n${innerContent()}\n{{/container}}\n`;
                }
                else if (isColumnContainer(element)) {
                    output = `\n(((${innerContent()}\n)))\n`;
                }
                else {
                    output = innerContent();
                }
            }
        }
        else if (tagName === 'SPAN' || tagName === 'PRE') {
            const isCodeBlock = element.classList.contains('prettyprint') || tagName === 'PRE';
            if (isCodeBlock) {
                output = `\n{{box}}\n${styling()}${innerContent()}\n(%%)\n{{/box}}`;
            }
            else {
                const styleStart = styling(false);
                const styleEnd = styleStart ? '(%%)' : '';
                output = styleStart + innerContent() + styleEnd;
            }
        }
        else if (tagName === 'ANNOTATION') { // highlight
            output = innerContent();
        }
        else if (tagName === 'UL' || tagName === 'OL') { // list/sublist (Quip API never returns OL for numbered lists)
            const listContent = XWikiConverter.getInnerContent(element, level + 1, listType, linkTargetTag);
            const hasItems = [...element.querySelectorAll('li')].length > 0;
            if (listType === 'checklist' && hasItems) {
                output = `(% type="none" %)\n${listContent}`;
            }
            else if (listType === 'numbered' && hasItems) {
                const parentNode = element.parentElement;
                if (parentNode != null) {
                    const hasStartNumber = parentNode.classList.contains('list-numbering-restart-at');
                    const isContinuation = parentNode.classList.contains('list-numbering-continue');
                    if (level > 0) {
                        const types = XHtmlConverterConstants.NUMBERED_LIST_STYLES;
                        const len = XHtmlConverterConstants.NUMBERED_LIST_STYLES.length;
                        output = `(% type="${types[level % len]}" %)\n${listContent}`;
                    }
                    else if (hasStartNumber) {
                        const startValue = parentNode.style.getPropertyValue('--indent0').trim();
                        output = `(% start="${startValue}" %)\n${listContent}`;
                    }
                    else if (isContinuation) {
                        const startValue = XWikiConverter.findListContinuationStartValue(parentNode);
                        output = `(% start="${startValue}" %)\n${listContent}`;
                    }
                    else {
                        output = listContent;
                    }
                }
                else {
                    output = listContent;
                }
            }
            else {
                output = listContent;
            }
        }
        else if (tagName === 'LI') { // list item
            if (XWikiConverter.isInnerCodeBlock(element)) {
                output = innerContent();
            }
            else if (listType === 'bullet') {
                const prefix = '*'.repeat(level) + ' ';
                output = prefix + innerContent();
            }
            else if (listType === 'numbered') {
                const prefix = '1'.repeat(level) + '. ';
                output = prefix + innerContent();
            }
            else if (listType === 'checklist') {
                const isChecked = element.classList.contains('checked');
                const checkbox = '{{html}}' + (isChecked ? '&#9745;' : '&#9744;') + '{{/html}} ';
                const prefix = '*'.repeat(level) + ' ' + checkbox;
                output = prefix + innerContent();
            }
            else {
                logger.warn("[src/amzn/XWikiConverter.ts:297:17]", 'List type not provided or invalid');
                output = innerContent();
            }
        }
        else if (tagName === 'TABLE') { // spreadsheet or table
            output = styling(true) + XWikiConverter.getTableContent(element, linkTargetTag);
        }
        else if (tagName === 'TH' || tagName === 'TD') {
            if (XWikiConverter.isStandaloneTag(element)) {
                return XWikiConverter.convertStandaloneTag(element);
            }
            const isBold = element.classList.contains('bold');
            const isItalic = element.classList.contains('italic');
            const isUnderline = element.classList.contains('underline');
            const isStrikethrough = element.classList.contains('strikethrough');
            let cellContent = styling(false) + innerContent();
            if (isStrikethrough) {
                cellContent = `--${cellContent}--`;
            }
            if (isItalic) {
                cellContent = `//${cellContent}//`;
            }
            if (isUnderline) {
                cellContent = `__${cellContent}__`;
            }
            if (isBold) {
                cellContent = `**${cellContent}**`;
            }
            return cellContent;
        }
        else if (tagName === 'VIDEO') {
            const isInlineEq = element.parentElement && element.parentElement.innerHTML !== element.outerHTML;
            const newLine = isInlineEq ? '' : '\n';
            // video exported as HTML within html macro
            output = newLine + newLine + `{{html}}${element.outerHTML}{{/html}}` + newLine;
        }
        else if (tagName === 'MATH') {
            const isInlineEq = element.parentElement && element.parentElement.innerHTML !== element.outerHTML;
            const newLine = isInlineEq ? '' : '\n';
            // set math formulas with 'formula' macro
            output = newLine + newLine + `{{formula}}${innerContent()}{{/formula}}` + newLine;
        }
        else if (tagName === 'DESIGN-INSPECTOR') {
            const diUrl = element.getAttribute('src');
            const width = 1100; // increase width as element.getAttribute('width') is always 800
            const height = Math.trunc(parseInt(element.getAttribute('height') || "480") * 1.375); // adjust height based on increase of width
            const isInlineEq = element.parentElement && element.parentElement.innerHTML !== element.outerHTML;
            const newLine = isInlineEq ? '' : '\n';
            // set design-inspector diagrams with 'iframe' macro
            output = newLine + newLine + `{{iframe url="${diUrl}" width="${width}px" height="${height}px" /}}` + newLine;
        }
        else if (tagName === 'TAB') {
            const id = element.getAttribute('id');
            output = `(% id="${id}" %)\n(((\n`;
        }
        else if (tagName === 'CONTROL') { // icons, mentions, date mentions
            output = innerContent();
        }
        else {
            if (tagName) {
                logger.error("[src/amzn/XWikiConverter.ts:350:17]", `untreated tag: ${tagName}`);
            }
            output = innerContent();
        }
        const previousSiblingTagName = (element.previousElementSibling?.tagName || '').toUpperCase();
        const parentTagName = (element.parentElement?.tagName || '').toUpperCase();
        const previousParentSiblingTagName = (element.parentElement?.previousElementSibling?.tagName || '').toUpperCase();
        if ((previousSiblingTagName == 'TAB' && parentTagName != 'BODY') ||
            (previousSiblingTagName == '' && parentTagName == 'DIV' && previousParentSiblingTagName == 'TAB')) {
            output += '\n)))';
        }
        return output;
    }
    static convertTextToXWikiSyntax(s) {
        return s
            .replace(/^(\s*?)(=+)(.+?)(\1)(\s*?)$/gm, (m, s1, h1, c, h2, s2) => s1 + h1.replace(/(?<!~)=/g, '~=') + c + h2.replace(/(?<!~)=/g, '~=') + s2)
            .replace(/^(\*+(\d+\.)?)( .*?)$/gm, (m, l1, c) => l1.replace(/(?<!~)(\*|\d)/g, '~$1') + c)
            .replace(/^(\d+\**\d*\.)( .*?)$/gm, (m, l1, c) => l1.replace(/(?<!~)(\*|\d)/g, '~$1') + c)
            .replace(/\*\*/g, '~*~*') // bold
            .replace(/\/\//g, '~/~/') // italic
            .replace(/--/g, '~-~-') // striked
            .replace(/__/g, '~_~_') // underline
            .replace(/##/g, '~#~#') // monospace
            .replace(/\^\^/g, '~^~^') // superscript
            .replace(/,,/g, '~,~,') // subscript
            .replace(/\\\\/g, '~\\~\\') // line break
            .replace(/\{\{(.+?\/?)\}\}/g, '~{~{$1~}~}') // macros
            .replace(/\(%(.*?)%\)/g, '~(%$1%~)') // styling
            .replace(/\[\[(.+?(>>.+?)?(\|\|.+?)*?)\[\]/g, '~[~[$1~]~]'); // links
        // TODO: images, lists, quotation, tables, verbatim, QA, grouping
    }
    static getInnerContent(element, level, listInfo, linkTargetTag) {
        const isQuip2WikiTag = element.getAttribute?.('isQuip2WikiTag') || false;
        if (isQuip2WikiTag) {
            return element.textContent || '';
        }
        else if (!element.hasChildNodes()) {
            if (!element.textContent)
                return '';
            // escape XWiki syntax elements
            return this.convertTextToXWikiSyntax(element.textContent);
        }
        else {
            return [...element.childNodes]
                .map(child => XWikiConverter.convert(child, level, listInfo, linkTargetTag))
                .join('') || '';
        }
    }
    static getLinkInnerContent(element, level, listType, linkTargetTag) {
        const isUserOrFolder = (src) => /https?:\/\/quip-amazon\.com\/.{11}\/?$/.test(src);
        const isQuipDocument = (src) => /https?:\/\/.*quip-amazon.com\/.{12}\/?/.test(src);
        const isAttachment = (src) => /https?:\/\/quip-amazon\.com\/-\/blob\/.{11}\/.{22}\?(s=.{12}&)?name=(.+)/.test(src);
        // const isVideo = (src: string) => /https?:\/\/quip-amazon\.com\/blob\/.{11}\/.{22}/.test(src);
        const innerContent = () => this.handleTilde(XWikiConverter.getInnerContent(element, level, listType, linkTargetTag));
        const target = linkTargetTag ? `||target="${linkTargetTag}"` : '';
        const url = `${element.getAttribute('href') || ''}${target}`;
        logger.log("[src/amzn/XWikiConverter.ts:409:9]", `<a> url: ${url}`);
        const isNoLink = element.hasAttribute('data-nolink'); // remove weird 'no-link' in <a> tags (not visible in Quip), but keep content
        if (isNoLink) {
            return innerContent();
        }
        else if (isUserOrFolder(url)) {
            const prev = element.previousElementSibling;
            const isAfterMention = prev && prev.tagName.toUpperCase() === 'A' && isUserOrFolder(prev.getAttribute('href') || '');
            const next = element.nextElementSibling;
            const isBeforeMention = next && next.tagName.toUpperCase() === 'A' && isUserOrFolder(next.getAttribute('href') || '');
            if (isAfterMention) {
                // user mention
                return `👤[[${innerContent()}>>${url}]]`;
            }
            else if (!isBeforeMention) {
                // quip folder
                return `📂[[${innerContent()}>>${url}]]`;
            }
            else {
                return innerContent();
            }
        }
        else if (isAttachment(url)) {
            return `📎[[${innerContent()}>>${url}]]`;
        }
        else if (isQuipDocument(url)) {
            return `📄[[${innerContent()}>>${url}]]`;
        }
        else {
            return `[[${innerContent()}>>${url}]]`;
        }
    }
    static getElementStyling(element, toplevel = true) {
        const classes = new Set();
        const styles = new Map();
        const tagName = (element.tagName || '').toUpperCase();
        if (tagName == 'SPAN') {
            // if there is a parent node with same content that is a span,
            // assume it will contain all styling of this element
            let node = element;
            while (node && node.parentElement && node.parentElement.textContent == element.textContent) {
                const parentTagName = (node.parentElement.tagName || '').toUpperCase();
                if (parentTagName == 'SPAN') {
                    return '';
                }
                node = node.parentElement;
            }
            // extract element styling
            XWikiConverter.extractElementStyling(element, classes, styles);
            // also add styling of any child span element which contains exact same content (merge)
            [...element.querySelectorAll('span')]
                .filter(el => el.textContent == element.textContent)
                .forEach(el => XWikiConverter.extractElementStyling(el, classes, styles));
        }
        else {
            // extract element styling
            XWikiConverter.extractElementStyling(element, classes, styles);
        }
        // generate class/style override markup
        const classValues = [...classes].join(' ');
        const clazz = classValues ? `class="${classValues}"` : '';
        const styleValues = [...styles.entries()].map(([key, value]) => `${key}:${value}`).join(';');
        const style = styleValues ? `style="${styleValues}"` : '';
        if (clazz || style) {
            const output = ['(%', clazz, style, '%)'].filter(item => !!item).join(' ');
            return output + (toplevel ? '\n' : '');
        }
        else {
            return '';
        }
    }
    static extractElementStyling(element, classes, styles) {
        const tagName = (element.tagName || '').toUpperCase();
        const isQuote = tagName === 'BLOCKQUOTE' || tagName === 'Q';
        const bgcolor = element.getAttribute('bgcolor');
        const textcolor = element.getAttribute('textcolor');
        // convert known quip classes to appropriate wiki classes/styles
        const isCodeBlock = element.classList.contains('prettyprint');
        const isCenterAligned = element.classList.contains('align-center');
        const isRightAligned = element.classList.contains('align-right');
        // the code below seems to do nothing in the examples that were debugged
        // get current styles
        // // @ts-expect-error It works and will be replaced in the future
        // [...element.style].forEach((s: string) => styles.set(s, element.style[s]));
        if (isCodeBlock) {
            classes.add('monospace');
        }
        if (bgcolor) {
            styles.set('background-color', colorRgbToHex(bgcolor));
        }
        if (textcolor) {
            styles.set('color', colorRgbToHex(textcolor));
        }
        if (isQuote) {
            styles.set('fontSize', 'inherit');
        }
        if (isCenterAligned) {
            styles.set('text-align', 'center');
        }
        if (isRightAligned) {
            styles.set('text-align', 'right');
        }
    }
    static isInnerCodeBlock(element) {
        return element.hasChildNodes() && element.children[0] != undefined && element.children[0].classList.contains('prettyprint');
    }
    static convertTags(element) {
        const foundElements = XWikiConverter.findElementsWithTag(element);
        if (foundElements.length > 0) {
            logger.log("[src/amzn/XWikiConverter.ts:528:13]", 'found elements: ' + foundElements.map(el => `${el.tagName}="${el.textContent}"`).join(','));
            foundElements.forEach(el => {
                el.textContent = XWikiConverter.convertStandaloneTag(element);
                el.setAttribute('isQuip2WikiTag', String(true));
            });
        }
        return element;
    }
    static findElementsWithTag(element) {
        const tagName = element.tagName;
        const ignoreElement = ['TABLE', 'THEAD', 'TBODY', 'TR', 'A', 'ANNOTATION', 'MATH'].includes(tagName);
        const hasStandaloneTag = XWikiConverter.isStandaloneTag(element);
        const hasInlineTag = XWikiConverter.hasInlineTag(element);
        if (ignoreElement) {
            return [];
        }
        else if (hasStandaloneTag) {
            return [element];
        }
        else if (hasInlineTag) {
            const onlyParentHasTag = XWikiConverter.isStandaloneTag(element.cloneNode(false));
            if (onlyParentHasTag) {
                return [element];
            }
            else {
                return [...element.children].flatMap(el => XWikiConverter.findElementsWithTag(el));
            }
        }
        else {
            return [];
        }
    }
    static hasInlineTag(element) {
        const tagPattern = /--wiki-[\w-]+?(\s*:.*?)?--/g;
        return tagPattern.test(element.textContent.trim());
    }
    static isStandaloneTag(element) {
        const tagPattern = /^--wiki-[\w-]+?(\s*:.*?)?--$/g;
        return tagPattern.test(element.textContent.trim());
    }
    static convertStandaloneTag(element) {
        const tagPattern = /--(wiki-[\w-]+?)(?:\s*:\s*["“”](.*?)["“”]\s*)?--/g;
        const textContent = element.textContent.trim();
        const match = tagPattern.exec(textContent);
        if (!match) {
            logger.error("[src/amzn/XWikiConverter.ts:573:13]", `[xwiki-convert] Expected single line tag, but couldn't parse it`);
            return textContent;
        }
        const tag = match[0];
        const tagName = match[1];
        const tagArgs = match[2];
        if (tagName === 'wiki-ignore') {
            return textContent;
        }
        if (tagName !== 'wiki-macro') {
            return ''; // clean line
        }
        return this.convertMacro(tag, tagArgs);
    }
    /**
     * Creates an XWiki macro tag.
     *
     * Macros are defined using Quip2Wiki tag as follows:
     * > --wiki-macro: "macro_name=transclude, name='space:Quip2Wiki.SyntaxXHTML', section='HFormattedLines'"--
     *
     * The created tag will work with the following patterns:
     * > {{macro_name/}}
     * > {{macro_name}}content{{/macro_name}}
     * > {{macro_name parameter_name1=parameter1_value parameter_name2=parameter2_value/}}
     * > {{macro_name parameter_name=parameter_value}}content{{/macro_name}}
     * See: https://w.amazon.com/bin/view/AmazonWiki/API/Client#HSyntax
     *
     * @param {string} tag the matched macro tag
     * @param {string} tagContent the content of macro tag (arguments)
     */
    static convertMacro(tag, tagContent) {
        const request = {};
        const regex = /\s*([a-zA-Z-_]+)\s*=([^\s'",]+|'.*?')\s*(?:,|$)/g;
        let part = regex.exec(tagContent);
        while (part) {
            try {
                const key = part[1];
                const value = part[2]
                    .replace(/\\n/g, '\n')
                    .replace(/\\t/g, '\t')
                    .replace(/\\"/g, '"')
                    .replace(/&lt;/g, '<')
                    .replace(/&gt;/g, '>')
                    .replace(/&amp;/g, '&')
                    .replace(/^\s*'|'\s*$/g, '"');
                request[key] = value;
            }
            catch {
                /* ignore exception */
            }
            part = regex.exec(tagContent);
        }
        const macroName = request.macro_name;
        const macroContent = request.content ? request.content.replace(/^\s*"|"\s*$/g, '') : null;
        if (!macroName) {
            logger.error("[src/amzn/XWikiConverter.ts:635:13]", `Invalid macro tag: ${tag}`);
            return tag;
        }
        else {
            let macroArgs = '';
            for (const key in request) {
                if (key == 'macro_name' || key == 'content') {
                    continue;
                }
                macroArgs += ` ${key}=${request[key]}`;
            }
            const extraLine = ['box', 'toc', 'success', 'info', 'warning', 'error', 'code', 'html'].includes(macroName);
            const linesBefore = extraLine ? '\n\n' : '\n';
            const linesAfter = extraLine ? '\n' : '';
            if (macroContent) {
                return `${linesBefore}{{${macroName}${macroArgs}}}\n${macroContent}\n{{/${macroName}}}${linesAfter}`;
            }
            else if (macroArgs) {
                return `${linesBefore}{{${macroName}${macroArgs}/}}${linesAfter}`;
            }
            else {
                return '';
            }
        }
    }
    static fixAttachmentLinks(content, wikiAddr, attachments) {
        // fix images and attachments urls
        const wikiUrl = DOWNLOAD_URL + wikiAddr + '/WebHome';
        for (const [title, attachment] of attachments.entries()) {
            for (const replacer of attachment.replacers) {
                if (attachment.skip) {
                    content = content.replace(new RegExp(`\\[\\[image:${replacer}(\\|\\|.*?)?\\]\\]`, 'g'), `[[image:${QUIP_URL}${replacer}$1]]`);
                    continue;
                }
                content = content.replaceAll(replacer, `${wikiUrl}/${title}`);
                content = content.replaceAll(replacer, title);
            }
        }
        return content;
    }
    static async fixMentions(singletons, content) {
        // amazon login mentions (ex: @siljonas or siljonas@)
        return await Utils.replaceAsyncSequence(content, XHtmlConverterConstants.QUIP_MENTION_LOGIN_REGEX2, async (m, login1, login2) => {
            const login = login1 || login2;
            const isValid = await XHtmlConverter.checkUserLogin(singletons, login);
            if (isValid) {
                return `[[${m}>>https://phonetool.amazon.com/users/${login}]]`;
            }
            else {
                return m;
            }
        });
    }
    static findListContinuationStartValue(list) {
        // select all sibling numbered lists
        const allNumberedLists = [...list.parentNode.querySelectorAll('div[data-section-style="6"]')];
        // initialize item start and count
        let start = 1;
        let count = 0;
        // iterate over all numbered lists until current continuation list
        for (const curList of allNumberedLists) {
            if (curList === list) {
                break;
            }
            // count number of items in current list
            const itemCount = [...curList.querySelectorAll(':scope > ul > li, :scope > ol > li')].length;
            const isContinuation = curList.classList.contains('list-numbering-continue');
            if (!isContinuation) { // reset as this could be the last list before current list
                const hasStartNumber = curList.classList.contains('list-numbering-restart-at');
                if (hasStartNumber) {
                    const startValue = curList.style.getPropertyValue('--indent0').trim();
                    start = Number.parseInt(startValue);
                }
                else {
                    start = 1;
                }
                count = itemCount; // start the count again
            }
            else {
                count = count + itemCount; // aggregate as this could be a preceding continuation list
            }
        }
        return start + count;
    }
    static getToc(document) {
        const tocTagExists = document.findTag(TOC_TAG);
        if (tocTagExists) {
            const args = document.readTagValue(TOC_TAG, '');
            const startValue = XHtmlConverter.getNumericArgValue(args, 'start', 2);
            const depthValue = XHtmlConverter.getNumericArgValue(args, 'depth', 3);
            return {
                isClassic: XHtmlConverter.getBooleanArgValue(args, 'classic', false),
                isFloating: XHtmlConverter.getBooleanArgValue(args, 'floating', true),
                isNumbered: XHtmlConverter.getBooleanArgValue(args, 'numbered', false),
                start: Math.max(1, Math.min(startValue, 6)),
                depth: Math.max(1, Math.min(depthValue, 6)), // allowed values: 1-6, even though Quip only has 3 levels
            };
        }
        else {
            return null;
        }
    }
    static getTocContent(toc) {
        if (!toc) {
            return '';
        }
        const tocMacro = `{{toc numbered=${toc.isNumbered} start=${toc.start} depth=${toc.depth}/}}\n`;
        if (toc.isClassic) {
            return `${tocMacro}\n`;
        }
        else if (toc.isFloating) {
            return `{{box floating=${toc.isFloating}}}\n` +
                `(% style="max-width: 550px" %)` +
                `Table of Contents\n` +
                `\n${tocMacro}\n` +
                `(%%)\n` +
                `{{/box}}\n`;
        }
        else {
            return `{{box}}\n` +
                `Table of Contents\n` +
                `\n${tocMacro}\n` +
                `{{/box}}\n`;
        }
    }
    static getTitleOverride(document) {
        return document.readTagValuesWithArguments(TITLE_TAG)
            .map(obj => ({
            title: obj.value.trim(),
            isVisible: XHtmlConverter.getBooleanArgValue(obj.args, 'visible', false)
        }))[0];
    }
    static convertQuipFolderListingToXWiki(singletons, wrapper) {
        const quipUrl = QUIP_URL;
        const folder = wrapper.value.folder;
        const fId = folder.id;
        const url = `${quipUrl}/${fId}`;
        const title = folder.title;
        const listing = XWikiConverter.convertQuipFolderListingToList(wrapper.children);
        const content = `= All subfolders and documents in [[//${title}/>>${url}]] =\n${listing}`;
        const bannerPosition = singletons.settings.bannerPosition;
        const bannerContent = XWikiConverter.getBanner({
            type: 'Folder',
            docId: fId,
            bannerPosition,
            wikiAddr: null,
            toc: null,
            wikiTags: [],
            headers: [],
            footers: [],
            showComments: false,
            isSortableTables: false,
            sheets: [],
            titleOverride: { title: '', isVisible: false }
        });
        const header = bannerPosition === BannerPosition.TOP ? bannerContent : '';
        const footer = bannerPosition !== BannerPosition.TOP ? bannerContent : ''; // if BOTTOM or HIDDEN
        return [header, content, footer].join('');
    }
    static convertQuipFolderListingToList(itemList, level = 1) {
        if (!itemList)
            return '';
        if (itemList.length == 0)
            return '';
        const quipUrl = QUIP_URL;
        const resUrl = XHtmlConverterConstants.RESOURCE_URL;
        const indent = '*'.repeat(level);
        let output = '';
        for (const item of itemList) {
            if (item.type == 'document') {
                const metadata = item.metadata;
                if (!metadata)
                    throw new Error('Document is undefined, invalid state');
                const thread = metadata.getUnderlyingQuipThread();
                const quipDocUrl = `${quipUrl}/${thread.document_id || thread.id}`;
                const wikiPageAddr = item.wikiAddr;
                const title = sanitizeHTMLText(metadata.title);
                const url = wikiPageAddr ? `${WIKI_BASE_URL}/${wikiPageAddr}` : quipDocUrl;
                const link = wikiPageAddr ? ` [[Quip>>${quipDocUrl}]]` : '';
                output += `${indent} {{html}}<img src="${resUrl}/page_white_text.png" />{{/html}} [[${title}>>${url}]]${link}\n`;
            }
            else if (item.type == 'folder') {
                const title = sanitizeHTMLText(item.value.folder.title);
                const quipFolderUrl = `${quipUrl}/${item.id}`;
                const wikiPageAddr = item.wikiAddr;
                const url = wikiPageAddr ? `${WIKI_BASE_URL}/${wikiPageAddr}` : quipFolderUrl;
                const link = wikiPageAddr ? ` [[Quip>>${quipFolderUrl}]]` : '';
                const color = XWikiConverter.convertQuipColor(item.value.folder.color);
                const children = item.children;
                output += `${indent} {{html}}<img src="${resUrl}/folder.png" />{{/html}} [[${title}>>${url}]]${link} {{html}}<span style="color:${color}">&#9724;</span>{{/html}}`;
                if (children) {
                    output += '\n' + XWikiConverter.convertQuipFolderListingToList(children, level + 1);
                }
                output += '\n';
            }
        }
        return output;
    }
    static convertQuipColor(color) {
        switch (color) {
            case 'dark_yellow':
                return 'DarkGoldenrod';
            case 'manila':
                return 'Gold';
            case 'purple':
                return 'Purple';
            case 'light_purple':
                return 'Plum';
            case 'blue':
                return 'DodgerBlue';
            case 'light_blue':
                return 'LightBlue';
            case 'orange':
                return 'DarkOrange';
            case 'light_orange':
                return 'Orange';
            case 'red':
                return 'IndianRed';
            case 'light_red':
                return 'LightCoral';
            case 'green':
                return 'LimeGreen';
            case 'light_green':
                return 'LightGreen';
            default:
                return color;
        }
    }
    static getBanner({ type, docId, bannerPosition }) {
        if (bannerPosition === BannerPosition.NONE) {
            return '';
        }
        const docUrl = `${QUIP_URL}/${docId}`;
        let isTimestampCached = sessionState.reproductionData.timestamps.xwiki != undefined;
        if (sessionState.isReproductionRun && !isTimestampCached) {
            sessionState.reproductionData.timestamps.xwiki = new Date().toUTCString();
            isTimestampCached = true;
        }
        const now = isTimestampCached ? sessionState.reproductionData.timestamps.xwiki : new Date().toUTCString();
        const content = `//This page was created by [[Quip2Wiki>>Quip2Wiki.]] from a Quip ${type} ([[See original>>${docUrl}]]) at '${now}'//`;
        const clazz = bannerPosition === BannerPosition.HIDDEN ? 'hidden-print hidden' : 'hidden-print';
        const prefix = bannerPosition !== BannerPosition.TOP ? `----\n` : '';
        const suffix = bannerPosition === BannerPosition.TOP ? `\n----` : ''; // if BOTTOM or HIDDEN
        return `(% class="${clazz}" %)(((\n` +
            `${prefix}(% style="color:#888888; font-size:small;" %)\n${content}${suffix}\n` +
            ')))\n';
    }
    static getHeaderOrFooterContent(values) {
        if (values.length == 0) {
            return '';
        }
        return values
            .map(tag => {
            const url = tag.addr?.replace(/\//g, '.');
            const name = `name="space:${url}"`;
            const args = tag.args ? `args="${tag.args}"` : '';
            return `{{transclude ${name} ${args} /}}`;
        })
            .join('\n\n')
            .concat('\n\n');
    }
    static getTableContent(tableElement, linkTargetTag) {
        const fixedTableElement = XWikiConverter.fixTable(tableElement);
        return XWikiConverter.convertTable(fixedTableElement, linkTargetTag);
    }
    static getTabsMacro(sheets) {
        // determine ids and set same order as in Spreadsheet
        const ids = sheets
            .map((sheet, index) => `t${index}=${sheet}`)
            .join(',');
        return `{{tabs idsToLabels='${ids}' /}}\n`;
    }
    static insertTabElements(html, firstHeader, orderedSheets) {
        const tables = [...html.body.querySelectorAll('table')];
        tables.forEach((table, index) => {
            // create tab element
            const tabElement = html.createElement('TAB');
            const sheetName = table.getAttribute('title');
            if (!sheetName)
                throw new Error("sheetName cannot be null");
            const tabIndex = orderedSheets.indexOf(sanitizeHTMLText(sheetName));
            tabElement.id = `t${tabIndex}`;
            tabElement.title = table.title;
            // place in correct position
            if (index == 0) { // is first
                if (firstHeader) { // add after first header, if available
                    firstHeader.parentNode.insertBefore(tabElement, firstHeader.nextSibling);
                }
                else {
                    html.body.insertBefore(tabElement, html.body.firstElementChild);
                }
            }
            else {
                table.parentNode.insertBefore(tabElement, table);
            }
        });
    }
    static fixTable(tableElement) {
        const newTable = tableElement.cloneNode(true);
        // fix unescaped sheet name
        const title = newTable.getAttribute('title') || '';
        newTable.setAttribute('title', sanitizeHTMLText(title));
        // set basic style
        newTable.setAttribute('border', '1px');
        newTable.setAttribute('borderColor', '#c7cbd1');
        // helper methods
        const removeElement = (el) => el?.parentNode.removeChild(el);
        const cleanText = (t) => t.replace(/[^\P{C}\n]+/u, '').trim();
        const isNumericRow = (el) => /^\d+$/.test(cleanText(el.textContent || ''));
        const isDefaultHeader = (el) => el.classList.contains('empty'); //el => /^[A-Z]+$/.test(cleanText(el.textContent));
        const isEmptyCell = (el) => /^\s*$/.test(cleanText(el.textContent || ''));
        const rowHasWidth = (row) => [...row.querySelectorAll('td, th')].every(td => td.style.width && /width:/.test(td.style.width));
        const hasHeader = !!newTable.querySelector('table > thead');
        if (hasHeader) {
            // remove column of row numbers
            const firstHeader = newTable.querySelector('table > thead > tr > th.empty:first-child');
            const firstColumnCells = Array.from(newTable.querySelectorAll('table > tbody > tr > td:first-child'));
            const hasNumberColumn = firstHeader && isEmptyCell(firstHeader) && firstColumnCells.every(el => isNumericRow(el));
            if (hasNumberColumn) {
                // delete first column header
                removeElement(firstHeader);
                // delete first column cells
                firstColumnCells.forEach(td => removeElement(td));
            }
            // remove default header if it is default (e.g: A, B, C, ..., AA, AB, AC, etc...)
            const headerRow = newTable.querySelector('table > thead > tr');
            const headerCells = Array.from(newTable.querySelectorAll('table > thead > tr > th'));
            const hasDefaultHeader = headerCells.every(th => isDefaultHeader(th));
            if (hasDefaultHeader) {
                // copy header cells' width
                const firstRowCells = Array.from(newTable.querySelectorAll('table > tbody > tr:first-child > td'));
                firstRowCells.forEach((td, index) => {
                    td.style.cssText += (headerCells[index].style.cssText || '');
                });
                // remove header
                removeElement(headerRow);
            }
            else {
                // set header background color as gray
                if (headerRow != null)
                    headerRow.style.backgroundColor = 'background-color:#E1E1E1';
            }
        }
        // remove empty columns
        const numColumns = newTable.querySelectorAll('table > tbody > tr > td').length;
        let colRemoveAttempts = 0;
        while (colRemoveAttempts < numColumns) {
            colRemoveAttempts++;
            const lastColumnHeader = newTable.querySelector('table > thead > tr > th:last-child');
            const lastColumnCells = Array.from(newTable.querySelectorAll('table > tbody > tr > td:last-child'));
            // check if last column is empty
            const isLastHeaderEmpty = !lastColumnHeader || isDefaultHeader(lastColumnHeader);
            const isLastColumnEmpty = lastColumnCells.length > 0 && lastColumnCells.every(td => isEmptyCell(td)) && isLastHeaderEmpty;
            if (!isLastColumnEmpty) {
                break;
            }
            // delete last column's header
            if (lastColumnHeader) {
                removeElement(lastColumnHeader);
            }
            // delete last column's cells
            lastColumnCells.forEach(td => removeElement(td));
        }
        // remove empty rows
        const numRows = newTable.querySelectorAll('table > tbody > tr').length;
        let rowRemoveAttempts = 0;
        while (rowRemoveAttempts < numRows) {
            rowRemoveAttempts++;
            // check if last row is empty
            const lastRowCells = Array.from(newTable.querySelectorAll('table > tbody > tr:last-child > td'));
            const isLastRowEmpty = lastRowCells.length > 0 && lastRowCells.every(td => isEmptyCell(td));
            if (!isLastRowEmpty) {
                break;
            }
            // delete last row
            const lastRow = newTable.querySelector('table > tbody > tr:last-child');
            removeElement(lastRow);
        }
        // remove unecessary line breaks (<br>) at end of each cell
        const lineBreaks = newTable.querySelectorAll('table > thead > tr > th > br:last-child, table > tbody > tr > td > br:last-child');
        lineBreaks.forEach(td => removeElement(td));
        // remove unecessary width style in all cells
        const tableWidth = newTable.style.width;
        if (tableWidth) {
            // find first row with width
            const allRows = Array.from(newTable.querySelectorAll('table > thead > tr > th > br:last-child, table > tbody > tr > td > br:last-child'));
            const firstRowWithWidth = allRows.find(row => rowHasWidth(row));
            if (firstRowWithWidth) {
                // remove width of cells in remaining rows
                allRows.filter(row => row !== firstRowWithWidth).forEach(td => td.style.width = '');
            }
        }
        // remove text-align class span (as td cell already contains text-align style)
        newTable.querySelectorAll('table > tbody > tr > td[style*="text-align"] > span:first-child.align-center')
            .forEach(span => span.classList.remove('align-center'));
        newTable.querySelectorAll('table > tbody > tr > td[style*="text-align"] > span:first-child.align-right')
            .forEach(span => span.classList.remove('align-right'));
        return newTable;
    }
    static convertTable(tableElement, linkTargetTag) {
        // |=Title 1|=Title 2
        // |Word 1|Word 2
        let output = '';
        // convert table header if present
        const headerRow = tableElement.querySelector('table > thead > tr:first-child');
        if (headerRow) {
            const headerCells = Array.from(tableElement.querySelectorAll('table > thead > tr > th'));
            for (const th of headerCells) {
                const innnerContent = XWikiConverter.convert(th, 1, null, linkTargetTag); // set as level=1 to avoid new line at end
                output += `|=${innnerContent}`;
            }
            output += '\n';
        }
        // convert table body
        const rows = tableElement.querySelectorAll('table > tbody > tr');
        rows.forEach(tr => {
            const cells = Array.from(tr.querySelectorAll('td'));
            let rowContent = '';
            for (const td of cells) {
                const innnerContent = XWikiConverter.convert(td, 1, null, linkTargetTag); // set as level=1 to avoid new line at end
                rowContent += `|${innnerContent}`;
            }
            output += rowContent + '\n';
        });
        return output;
    }
}

class ConstantBackoff {
    /**
     * Backoff that returns a constant interval.
     */
    constructor(interval) {
        this.interval = interval;
    }
    /**
     * @inheritdoc
     */
    next() {
        return instance$1(this.interval);
    }
}
const instance$1 = (interval) => ({
    duration: interval,
    next() {
        return this;
    },
});

/**
 * Generator that creates a backoff with no jitter.
 */
/**
 * A factor used within the formula to help smooth the first calculated delay.
 */
const pFactor = 4.0;
/**
 *  A factor used to scale the median values of the retry times generated by
 * the formula to be _near_ whole seconds, to aid user comprehension. This
 * factor allows the median values to fall approximately at 1, 2, 4 etc
 * seconds, instead of 1.4, 2.8, 5.6, 11.2.
 */
const rpScalingFactor = 1 / 1.4;
/**
 * Decorrelated jitter. This should be considered the optimal Jitter stategy
 * for most scenarios, as battle-tested in Polly.
 *
 * @see https://github.com/App-vNext/Polly/issues/530
 * @see https://github.com/Polly-Contrib/Polly.Contrib.WaitAndRetry/blob/24cb116a2a320e82b01f57e13bfeaeff2725ccbf/src/Polly.Contrib.WaitAndRetry/Backoff.DecorrelatedJitterV2.cs
 */
const decorrelatedJitterGenerator = (state, options) => {
    const [attempt, prev] = state || [0, 0];
    const t = attempt + Math.random();
    const next = Math.pow(options.exponent, t) * Math.tanh(Math.sqrt(pFactor * t));
    const formulaIntrinsicValue = isFinite(next) ? Math.max(0, next - prev) : Infinity;
    return [
        Math.min(formulaIntrinsicValue * rpScalingFactor * options.initialDelay, options.maxDelay),
        [attempt + 1, next],
    ];
};

const defaultOptions = {
    generator: decorrelatedJitterGenerator,
    maxDelay: 30000,
    exponent: 2,
    initialDelay: 128,
};
class ExponentialBackoff {
    /**
     * An implementation of exponential backoff.
     */
    constructor(options) {
        this.options = options ? { ...defaultOptions, ...options } : defaultOptions;
    }
    next() {
        return instance(this.options).next(undefined);
    }
}
/**
 * An implementation of exponential backoff.
 */
const instance = (options, state, delay = 0, attempt = -1) => ({
    duration: delay,
    next() {
        const [nextDelay, nextState] = options.generator(state, options);
        return instance(options, nextState, nextDelay, attempt + 1);
    },
});

class TaskCancelledError extends Error {
    /**
     * Error thrown when a task is cancelled.
     */
    constructor(message = 'Operation cancelled') {
        super(message);
        this.message = message;
        this.isTaskCancelledError = true;
    }
}

const noopDisposable = { dispose: () => undefined };
var Event$1;
(function (Event) {
    /**
     * Adds a handler that handles one event on the emitter.
     */
    Event.once = (event, listener) => {
        let syncDispose = false;
        let disposable;
        disposable = event(value => {
            listener(value);
            if (disposable) {
                disposable.dispose();
            }
            else {
                syncDispose = true; // callback can fire before disposable is returned
            }
        });
        if (syncDispose) {
            disposable.dispose();
            return noopDisposable; // no reason to keep the ref around
        }
        return disposable;
    };
    /**
     * Returns a promise that resolves when the event fires, or when cancellation
     * is requested, whichever happens first.
     */
    Event.toPromise = (event, signal) => {
        if (!signal) {
            return new Promise(resolve => Event.once(event, resolve));
        }
        if (signal.aborted) {
            return Promise.reject(new TaskCancelledError());
        }
        const toDispose = [];
        return new Promise((resolve, reject) => {
            const abortEvt = onAbort(signal);
            toDispose.push(abortEvt);
            toDispose.push(abortEvt.event(() => {
                reject(new TaskCancelledError());
            }));
            toDispose.push(Event.once(event, data => {
                resolve(data);
            }));
        }).finally(() => {
            for (const d of toDispose) {
                d.dispose();
            }
        });
    };
})(Event$1 || (Event$1 = {}));
/** Creates an Event that fires when the signal is aborted. */
const onAbort = (signal) => {
    const evt = new OneShotEvent();
    if (signal.aborted) {
        evt.emit();
        return { event: evt.addListener, dispose: () => { } };
    }
    const dispose = () => signal.removeEventListener('abort', l);
    // @types/node is currently missing the event types on AbortSignal
    const l = () => {
        evt.emit();
        dispose();
    };
    signal.addEventListener('abort', l);
    return { event: evt.addListener, dispose };
};
/**
 * Base event emitter. Calls listeners when data is emitted.
 */
class EventEmitter {
    constructor() {
        /**
         * Event<T> function.
         */
        this.addListener = listener => this.addListenerInner(listener);
    }
    /**
     * Gets the number of event listeners.
     */
    get size() {
        if (!this.listeners) {
            return 0;
        }
        else if (typeof this.listeners === 'function') {
            return 1;
        }
        else {
            return this.listeners.length;
        }
    }
    /**
     * Emits event data.
     */
    emit(value) {
        if (!this.listeners) ;
        else if (typeof this.listeners === 'function') {
            this.listeners(value);
        }
        else {
            for (const listener of this.listeners) {
                listener(value);
            }
        }
    }
    addListenerInner(listener) {
        if (!this.listeners) {
            this.listeners = listener;
        }
        else if (typeof this.listeners === 'function') {
            this.listeners = [this.listeners, listener];
        }
        else {
            this.listeners.push(listener);
        }
        return { dispose: () => this.removeListener(listener) };
    }
    removeListener(listener) {
        if (!this.listeners) {
            return;
        }
        if (typeof this.listeners === 'function') {
            if (this.listeners === listener) {
                this.listeners = undefined;
            }
            return;
        }
        const index = this.listeners.indexOf(listener);
        if (index === -1) {
            return;
        }
        if (this.listeners.length === 2) {
            this.listeners = index === 0 ? this.listeners[1] : this.listeners[0];
        }
        else {
            this.listeners = this.listeners.slice(0, index).concat(this.listeners.slice(index + 1));
        }
    }
}
/**
 * An event emitter that fires a value once and removes all
 * listeners automatically after doing so.
 */
class OneShotEvent extends EventEmitter {
    constructor() {
        super(...arguments);
        /**
         * @inheritdoc
         */
        this.addListener = listener => {
            if (this.lastValue) {
                listener(this.lastValue.value);
                return noopDisposable;
            }
            else {
                return this.addListenerInner(listener);
            }
        };
    }
    /**
     * @inheritdoc
     */
    emit(value) {
        this.lastValue = { value };
        super.emit(value);
        this.listeners = undefined;
    }
}

const neverAbortedSignal = new AbortController().signal;
const cancelledSrc = new AbortController();
cancelledSrc.abort();
cancelledSrc.signal;

const returnOrThrow = (failure) => {
    if ('error' in failure) {
        throw failure.error;
    }
    if ('success' in failure) {
        return failure.success;
    }
    return failure.value;
};
const makeStopwatch = () => {
    if (typeof performance !== 'undefined') {
        const start = performance.now();
        return () => performance.now() - start;
    }
    else {
        const start = process.hrtime.bigint();
        return () => Number(process.hrtime.bigint() - start) / 1000000; // ns->ms
    }
};
class ExecuteWrapper {
    constructor(errorFilter = () => false, resultFilter = () => false) {
        this.errorFilter = errorFilter;
        this.resultFilter = resultFilter;
        this.successEmitter = new EventEmitter();
        this.failureEmitter = new EventEmitter();
        this.onSuccess = this.successEmitter.addListener;
        this.onFailure = this.failureEmitter.addListener;
    }
    clone() {
        return new ExecuteWrapper(this.errorFilter, this.resultFilter);
    }
    async invoke(fn, ...args) {
        const stopwatch = this.successEmitter.size || this.failureEmitter.size ? makeStopwatch() : null;
        try {
            const value = await fn(...args);
            if (!this.resultFilter(value)) {
                if (stopwatch) {
                    this.successEmitter.emit({ duration: stopwatch() });
                }
                return { success: value };
            }
            if (stopwatch) {
                this.failureEmitter.emit({ duration: stopwatch(), handled: true, reason: { value } });
            }
            return { value };
        }
        catch (rawError) {
            const error = rawError;
            const handled = this.errorFilter(error);
            if (stopwatch) {
                this.failureEmitter.emit({ duration: stopwatch(), handled, reason: { error } });
            }
            if (!handled) {
                throw error;
            }
            return { error };
        }
    }
}

/**
 * A no-op policy, useful for unit tests and stubs.
 */
class NoopPolicy {
    constructor() {
        this.executor = new ExecuteWrapper();
        this.onSuccess = this.executor.onSuccess;
        this.onFailure = this.executor.onFailure;
    }
    async execute(fn, signal = neverAbortedSignal) {
        return returnOrThrow(await this.executor.invoke(fn, { signal }));
    }
}

const delay = (duration, unref) => new Promise(resolve => {
    const timer = setTimeout(resolve, duration);
    if (unref) {
        timer.unref();
    }
});
class RetryPolicy {
    constructor(options, executor) {
        this.options = options;
        this.executor = executor;
        this.onGiveUpEmitter = new EventEmitter();
        this.onRetryEmitter = new EventEmitter();
        /**
         * @inheritdoc
         */
        this.onSuccess = this.executor.onSuccess;
        /**
         * @inheritdoc
         */
        this.onFailure = this.executor.onFailure;
        /**
         * Emitter that fires when we retry a call, before any backoff.
         *
         */
        this.onRetry = this.onRetryEmitter.addListener;
        /**
         * Emitter that fires when we're no longer retrying a call and are giving up.
         */
        this.onGiveUp = this.onGiveUpEmitter.addListener;
    }
    /**
     * When retrying, a referenced timer is created. This means the Node.js event
     * loop is kept active while we're delaying a retried call. Calling this
     * method on the retry builder will unreference the timer, allowing the
     * process to exit even if a retry might still be pending.
     */
    dangerouslyUnref() {
        return new RetryPolicy({ ...this.options, unref: true }, this.executor.clone());
    }
    /**
     * Executes the given function with retries.
     * @param fn Function to run
     * @returns a Promise that resolves or rejects with the function results.
     */
    async execute(fn, signal = neverAbortedSignal) {
        const factory = this.options.backoff || new ConstantBackoff(0);
        let backoff;
        for (let retries = 0;; retries++) {
            const result = await this.executor.invoke(fn, { attempt: retries, signal });
            if ('success' in result) {
                return result.success;
            }
            if (!signal.aborted && retries < this.options.maxAttempts) {
                const context = { attempt: retries + 1, signal, result };
                backoff = backoff ? backoff.next(context) : factory.next(context);
                const delayDuration = backoff.duration;
                const delayPromise = delay(delayDuration, !!this.options.unref);
                // A little sneaky reordering here lets us use Sinon's fake timers
                // when we get an emission in our tests.
                this.onRetryEmitter.emit({ ...result, delay: delayDuration, attempt: retries + 1 });
                await delayPromise;
                continue;
            }
            this.onGiveUpEmitter.emit(result);
            if ('error' in result) {
                throw result.error;
            }
            return result.value;
        }
    }
}

const typeFilter = (cls, predicate) => predicate ? (v) => v instanceof cls && predicate(v) : (v) => v instanceof cls;
const always = () => true;
const never = () => false;
class Policy {
    /**
     * Factory that builds a base set of filters that can be used in circuit
     * breakers, retries, etc.
     */
    constructor(options) {
        this.options = options;
    }
    /**
     * Allows the policy to additionally handles errors of the given type.
     *
     * @param cls Class constructor to check that the error is an instance of.
     * @param predicate If provided, a function to be called with the error
     * which should return "true" if we want to handle this error.
     * @example
     * ```js
     * // retry both network errors and response errors with a 503 status code
     * new Policy()
     *  .orType(NetworkError)
     *  .orType(ResponseError, err => err.statusCode === 503)
     *  .retry()
     *  .attempts(3)
     *  .execute(() => getJsonFrom('https://example.com'));
     * ```
     */
    orType(cls, predicate) {
        const filter = typeFilter(cls, predicate);
        return new Policy({
            ...this.options,
            errorFilter: e => this.options.errorFilter(e) || filter(e),
        });
    }
    /**
     * Allows the policy to additionally handles errors that pass the given
     * predicate function.
     *
     * @param predicate Takes any thrown error, and returns true if it should
     * be retried by this policy.
     * @example
     * ```js
     * // only retry if the error has a "shouldBeRetried" property set
     * new Policy()
     *  .orWhen(err => err.shouldBeRetried === true)
     *  .retry()
     *  .attempts(3)
     *  .execute(() => getJsonFrom('https://example.com'));
     * ```
     */
    orWhen(predicate) {
        return new Policy({
            ...this.options,
            errorFilter: e => this.options.errorFilter(e) || predicate(e),
        });
    }
    /**
     * Adds handling for return values. The predicate will be called with
     * the return value of the executed function,
     *
     * @param predicate Takes the returned value, and returns true if it
     * should be retried by this policy.
     * @example
     * ```js
     * // retry when the response status code is a 5xx
     * new Policy()
     *  .orResultWhen(res => res.statusCode >= 500)
     *  .retry()
     *  .attempts(3)
     *  .execute(() => getJsonFrom('https://example.com'));
     * ```
     */
    orWhenResult(predicate) {
        return new Policy({
            ...this.options,
            resultFilter: r => this.options.resultFilter(r) || predicate(r),
        });
    }
    /**
     * Adds handling for return values. The predicate will be called with
     * the return value of the executed function,
     *
     * @param predicate Takes the returned value, and returns true if it
     * should be retried by this policy.
     * @example
     * ```js
     * // retry when the response status code is a 5xx
     * new Policy()
     *  .orResultType(res => res.statusCode >= 500)
     *  .retry()
     *  .attempts(3)
     *  .execute(() => getJsonFrom('https://example.com'));
     * ```
     */
    orResultType(cls, predicate) {
        const filter = typeFilter(cls, predicate);
        return new Policy({
            ...this.options,
            resultFilter: r => this.options.resultFilter(r) || filter(r),
        });
    }
}
new NoopPolicy();
/**
 * A policy that handles all errors.
 */
const handleAll = new Policy({ errorFilter: always, resultFilter: never });
/**
 * Creates a retry policy. The options should contain the backoff strategy to
 * use. Included strategies are:
 *  - {@link ConstantBackoff}
 *  - {@link ExponentialBackoff}
 *  - {@link IterableBackoff}
 *  - {@link DelegateBackoff} (advanced)
 *
 * For example:
 *
 * ```
 * import { handleAll, retry } from 'cockatiel';
 *
 * const policy = retry(handleAll, { backoff: new ExponentialBackoff() });
 * ```
 *
 * You can optionally pass in the `attempts` to limit the maximum number of
 * retry attempts per call.
 */
function retry(policy, opts) {
    return new RetryPolicy({ backoff: opts.backoff || new ConstantBackoff(0), maxAttempts: opts.maxAttempts ?? Infinity }, new ExecuteWrapper(policy.options.errorFilter, policy.options.resultFilter));
}

/**
 * A retry policy that handles all exceptions and retries the callback every 50ms, during 10s (totaling 200 executions max)
 */
const constantRetry = (durationMs = 10000, waitIntervalMs = 50) => {
    const policy = retry(handleAll, {
        maxAttempts: Math.floor(durationMs / waitIntervalMs),
        backoff: new ConstantBackoff(waitIntervalMs)
    });
    policy.onGiveUp((context) => {
        logger.debug("[src/utils/Retry.ts:13:9]", 'Giving up constant retry action. Failure reason: ', context);
    });
    return policy;
};
// Create a retry policy that'll try whatever function we execute 3
// times with a randomized exponential backoff.
retry(handleAll, {
    maxAttempts: 3,
    backoff: new ExponentialBackoff({ initialDelay: 100 })
});

async function resizeImage(blob, maxSizeInBytes, securityFactor = 1.0) {
    if (maxSizeInBytes < 1024) {
        return blob; // unchanged
    }
    return await new Promise((res, rej) => {
        const blobURL = window.URL.createObjectURL(blob);
        const image = new Image();
        image.src = blobURL;
        image.onload = () => {
            // define the new size
            const percentage = (securityFactor * maxSizeInBytes) / blob.size; // desired reduce percentage
            const factor = Math.sqrt(percentage); // factor is one dimension
            logger.debug("[src/utils/Image.ts:16:13]", `Attempting to downsize by a factor of ${factor.toFixed(3)}`);
            const width = image.width * factor;
            const height = image.height * factor;
            const canvas = document.createElement('canvas');
            // resize the canvas and draw the image data into it
            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext("2d");
            if (ctx == null) {
                rej("Null context");
                return;
            }
            ctx.drawImage(image, 0, 0, width, height);
            // convert to blob
            const callback = async (b) => {
                if (b == null) {
                    rej("Null blob");
                    return;
                }
                logger.debug("[src/utils/Image.ts:36:17]", `Image downsized to ${formatBytes(b.size)}`);
                if (b.size < maxSizeInBytes) {
                    res(b);
                }
                else {
                    res(await resizeImage(b, maxSizeInBytes, securityFactor * 0.95));
                }
            };
            canvas.toBlob(callback, blob.type);
        };
    });
}

/**
 * Holds logic for retrieving, converting, and saving a Quip document to Amazon Wiki.
 */
class WikiExport {
    constructor(singletons) {
        this.processedDocuments = 0;
        this.totalDocuments = 0;
        this.progressModal = null;
        this.singletons = singletons;
    }
    async exportDocument(doc, wikiAddr, timestamp, forceFormat) {
        if (doc.isSpreadsheet) {
            // in spreadsheets, the order of sheets do not match order of tables in the doc's html, so we will extract from Quip page the correct order and update the doc with this info
            doc.sheetsDesiredOrder = QuipEditor.extractSheetNames();
        }
        if (doc.isDocument) {
            // layout is broken in the doc's html, so we will extract from Quip page and fix it using div tags
            const layout = QuipEditor.extractMultiColumnLayout();
            doc.fixMultiColumnLayout(layout);
            // design inspector diagrams are not available in doc's html, so we extract from Quip page and add as "design-inspector" tag
            const diDiagrams = QuipEditor.extractDesignInspectorDiagrams();
            doc.fixDesignInspectorDiagrams(diDiagrams);
        }
        if (doc.isDocument || doc.isSpreadsheet) {
            // videos have a complex html pattern in the doc's html, so we will replace them with simple "video" tags
            doc.fixVideos();
            // table do not have an id (just title) in the doc's html, so we will add an id based on the order of the table in the doc
            doc.fixTableIds();
            // math formulas are not available in doc's html, so we extract from Quip page and add as "math" tag
            const mathControls = QuipEditor.extractMathFormulas();
            doc.fixMathFormulas(mathControls);
        }
        // get messages
        let messages = undefined;
        if (doc.findTag(COMMENTS_TAG)) {
            messages = await this.singletons.quipClient.getAllMessages(doc.linkId);
        }
        const attachments = doc.getAttachments();
        // determine the wiki page title and tags
        const pageTitle = doc.getWikiTitle();
        const pageTags = doc.getWikiTags();
        const syntax = forceFormat || doc.getWikiSyntax();
        const hasContent = await this.singletons.wikiClient.wikiPageExists(wikiAddr);
        if (!hasContent) {
            await this.createPage(wikiAddr, syntax, pageTitle);
        }
        // we save tags and upload attachments first because the xml schema does not support the 'comment' section, used for storing the timestamp
        await this.saveTags(wikiAddr, pageTags, syntax, hasContent);
        const saveResult = await this.saveAttachments(attachments, wikiAddr);
        if (!saveResult) {
            return false; // user aborted
        }
        let content;
        if (syntax === 'xhtml') {
            // convert document to XHTML
            content = await XHtmlConverter.convertQuipHTMLToXHTML(this.singletons, doc, attachments, messages || []);
        }
        else if (syntax === 'xwiki') {
            // convert document to XWiki
            content = await XWikiConverter.convertQuipHTMLToXWiki(this.singletons, doc, attachments);
        }
        else {
            throw `Invalid wiki syntax: ${syntax}`;
        }
        logger.log("[src/quip/WikiExport.ts:95:9]", `[wiki-export] start save page as ${syntax}...`);
        // verify content size
        const limit = UPLOAD_SIZE_LIMIT * 1.01;
        const contentSize = content.length; // since we use UTF-8, each char is 1 byte
        const contentSizeStr = formatBytes(contentSize);
        logger.log("[src/quip/WikiExport.ts:101:9]", `[wiki-export] page content size: ${contentSizeStr}`);
        if (contentSize > limit) {
            throw `The document content is approximatedly ${contentSizeStr} in size and exceeds the Wiki ${formatBytes(limit)} limit.\nTry breaking the content into two separate documents.`;
        }
        await this.savePage(wikiAddr, content, syntax, timestamp, pageTitle);
        // After successful export, update progress if we're in a folder export
        if (this.progressModal) {
            this.processedDocuments++;
            this.progressModal.updateProgress(this.processedDocuments, this.totalDocuments, doc.title);
        }
        return true; // succeeded
    }
    async exportFolder(wrapper, wikiAddr, timestamp, syntax) {
        // Get the total number of documents selected by the user
        this.totalDocuments = wrapper.numberOfItems || 0;
        // Show progress modal
        this.progressModal = showProgressModal(this.singletons, "Exporting Selected Documents", this.totalDocuments);
        // Reset processed documents counter
        this.processedDocuments = 0;
        // Export the folder documents
        await this.exportFolderDocuments(wrapper, wikiAddr, syntax);
        // Close the progress modal
        if (this.progressModal) {
            this.progressModal.close();
            this.progressModal = null;
        }
        // save the page to the wiki
        const pageTitle = `${wrapper.value.folder.title} Index`;
        wrapper.wikiAddr = wikiAddr;
        let content = '';
        if (syntax == 'xwiki') {
            content = XWikiConverter.convertQuipFolderListingToXWiki(this.singletons, wrapper);
        }
        else {
            content = XHtmlConverter.convertQuipFolderListingToXHTML(this.singletons, wrapper);
        }
        await this.savePage(wikiAddr, content, syntax, timestamp, pageTitle);
    }
    /**
     * Builds a complete tree of all documents and subfolders, returning items in the correct processing order:
     * 1. All documents first
     * 2. Folders in bottom-up order (deepest folders first)
     */
    async buildFolderTree(folder, parentWikiAddr, depth = 0) {
        const documentItems = [];
        const folderItems = [];
        const exportedTitles = new Set();
        // Process all children in the folder
        for (const item of folder.children) {
            try {
                let path = '';
                let wikiAddr = '';
                if (item.type === 'document') {
                    // Get thread info without loading full document content
                    const docMetadata = await this.singletons.quipClient.getDocumentMetadata(item.id);
                    if (!docMetadata) {
                        logger.warn("[src/quip/WikiExport.ts:171:25]", `Could not load metadata for ID ${item.id}`);
                        continue;
                    }
                    let title = docMetadata.titleAsUrl || `document_${item.id}`;
                    if (exportedTitles.has(title)) {
                        const uniqueId = item.id.substring(0, 6);
                        title = `${title}_${uniqueId}`;
                    }
                    exportedTitles.add(title);
                    const wikiAddr = `${parentWikiAddr}/${title}`;
                    item.wikiAddr = wikiAddr;
                    // Add document to the list
                    documentItems.push({
                        item,
                        path,
                        wikiAddr,
                        parentWikiAddr,
                        depth
                    });
                }
                else if (item.type === 'folder') {
                    // Process subfolder
                    let subfolder = item;
                    if (!subfolder.value || !subfolder.value.folder) {
                        subfolder = await this.singletons.quipClient.getFolder(item.id);
                        if (!subfolder) {
                            logger.warn("[src/quip/WikiExport.ts:201:29]", `Could not load folder with ID ${item.id}`);
                            continue;
                        }
                    }
                    const folderTitle = subfolder.value.folder.title;
                    let safeTitle = folderTitle.replace(/\s+/g, '').replace(/[^\w-]/g, '');
                    if (exportedTitles.has(safeTitle)) {
                        const uniqueId = item.id.substring(0, 6);
                        safeTitle = `${safeTitle}_${uniqueId}`;
                    }
                    exportedTitles.add(safeTitle);
                    wikiAddr = `${parentWikiAddr}/${safeTitle}`;
                    path = folderTitle;
                    // Recursively process the subfolder first
                    const subItems = await this.buildFolderTree(subfolder, wikiAddr, depth + 1);
                    // Add this folder after its children (for bottom-up processing)
                    folderItems.push({
                        item: subfolder,
                        path,
                        wikiAddr,
                        parentWikiAddr,
                        depth
                    });
                    // Add all items from subfolder
                    documentItems.push(...subItems.filter(i => i.item.type === 'document'));
                    folderItems.push(...subItems.filter(i => i.item.type === 'folder'));
                }
            }
            catch (error) {
                logger.error("[src/quip/WikiExport.ts:236:17]", `Error processing item with ID ${item.id}: ${error}`);
            }
        }
        // Return documents first, then folders in bottom-up order
        return [...documentItems, ...folderItems];
    }
    /**
     * Exports all documents in a folder to their own Wiki pages
     *
     * @param {FolderWrapper} folder The folder containing documents to export
     * @param {string} parentWikiAddr The Wiki address of the parent folder
     */
    /**
     * Exports all documents in a folder to their own Wiki pages
     *
     * @param {FolderWrapper} folder The folder containing documents to export
     * @param {string} parentWikiAddr The Wiki address of the parent folder
     */
    async exportFolderDocuments(folder, parentWikiAddr, syntax) {
        logger.log("[src/quip/WikiExport.ts:257:9]", `Exporting folder: ${folder.value.folder.title}...`);
        // Process documents in the current folder
        await this.processDocumentsInFolder(folder, parentWikiAddr, syntax);
        // Process subfolders recursively
        await this.processSubfolders(folder, parentWikiAddr, syntax);
    }
    /**
     * Creates a page
     *
     * @param {string} wikiAddr Wiki address
     * @param {string} syntax Syntax
     * @param {string} title Page title
     */
    async createPage(wikiAddr, syntax, title) {
        // if page content does not exist, we will create it, so saving tags does not fail
        logger.log("[src/quip/WikiExport.ts:275:9]", '[wiki-export] page have no content. Writing empty content');
        const version = this.singletons.session.version;
        const comment = `Created with Quip2Wiki Tampermonkey script version ${version}`;
        const message = 'This is a placeholder content for a Quip Document being exported by Quip2Wiki tool';
        const contentNew = syntax === 'xwiki' ? `=== ${message} ===`.replaceAll('Quip2Wiki', '[[Quip2Wiki>>Quip2Wiki.]]') :
            syntax === 'markdown' ? `### ${message} ===`.replaceAll('Quip2Wiki', '[Quip2Wiki](/bin/view/Quip2Wiki)') :
                /* syntax === 'xhtml' ? */ `<html><body><h3>${message}</h3></body></html>`.replaceAll('Quip2Wiki', '<a href="/bin/view/Quip2Wiki">Quip2Wiki</a>');
        if (!contentNew)
            throw `Invalid syntax: ${syntax}`;
        const xmlContentNew = createXmlPageDocument(title, contentNew, syntax, comment);
        await this.singletons.wikiClient.putXmlContent(wikiAddr, xmlContentNew, 'home');
    }
    async saveTags(wikiAddr, tags, syntax, hasContent = false) {
        const syntaxTag = WIKI_TAG + ':' + syntax;
        const newTags = [WIKI_TAG, syntaxTag]; // mandatory tags for monitoring
        if (tags) {
            // user defined tags
            tags.forEach(tag => {
                if (!newTags.includes(tag)) {
                    newTags.push(tag);
                }
            });
        }
        // get current tags
        const curTags = (hasContent ? await this.singletons.wikiClient.getTags(wikiAddr) : []);
        // update wiki tags
        const shouldUpdate = !Utils.arraysEqual(curTags, newTags);
        if (shouldUpdate) {
            const tagsContent = createXmlTagsDocument(newTags);
            await this.singletons.wikiClient.putXmlContent(wikiAddr, tagsContent, 'tags');
        }
    }
    async saveAttachments(attachments, wikiAddr) {
        // get attached images and files and upload
        if (!attachments)
            return true;
        if (attachments.size == 0)
            return true;
        logger.log("[src/quip/WikiExport.ts:320:9]", '[wiki-export] start attachments upload...');
        const formToken = await this.singletons.wikiClient.getFormToken(wikiAddr);
        const curAttachments = await this.singletons.wikiClient.getAttachmentsList(wikiAddr);
        const limit = UPLOAD_SIZE_LIMIT;
        const limitStr = formatBytes(limit);
        // add/update document attachments
        for (const [title, attachment] of attachments.entries()) {
            if (curAttachments.has(title)) { // names have a prefix of their blob id, so we won't need to upload if it's already there
                logger.log("[src/quip/WikiExport.ts:332:17]", `[wiki-export] skipped upload of '${title}'`);
                continue;
            }
            let blob = await this.getAttachmentBlob(attachment);
            if (blob.size > limit) {
                const promptResult = await promptForAttachmentConfirmation(this.singletons, attachment.name, blob, limit);
                switch (promptResult) {
                    case 'resize':
                        blob = await this.resizeImage(title, blob, limit);
                        break; // upload
                    case 'abort':
                        logger.log("[src/quip/WikiExport.ts:345:21]", `[wiki-export] user cancelled attachment '${title} upload': above ${limitStr} limit`);
                        return false; // abort
                    default:
                    case 'link':
                        logger.log("[src/quip/WikiExport.ts:349:21]", `[wiki-export] user chose to not upload '${title}': above ${limitStr} limit`);
                        attachment.skip = true;
                        continue; // skip
                }
            }
            await this.singletons.wikiClient.uploadAttachmentBlob(blob, wikiAddr, formToken, title);
        }
        // delete attachments not in document
        for (const title of curAttachments.keys()) {
            if (!attachments.has(title)) {
                await this.singletons.wikiClient.deleteAttachment(wikiAddr, formToken, encodeURI(title));
            }
        }
        return true;
    }
    /**
     * Resizes an image
     *
     * @param {string} attachmentName Attachment name
     * @param {Blob} blob Attachments
     * @param {number} targetSize Size of the target in bytes
     */
    async resizeImage(attachmentName, blob, targetSize) {
        logger.log("[src/quip/WikiExport.ts:376:9]", `[wiki-export] downsizing image '${attachmentName}'...`);
        const ublob = await resizeImage(blob, targetSize);
        const percent = Math.round(ublob.size * 100.0 / blob.size);
        logger.log("[src/quip/WikiExport.ts:381:9]", `[wiki-export] downsized image '${attachmentName}' from ${formatBytes(blob.size)} to ${formatBytes(ublob.size)} (${percent}%)`);
        return ublob;
    }
    /**
     * Downloads an attachment
     */
    async getAttachmentBlob(attachment, useInternalId = true) {
        logger.log("[src/quip/WikiExport.ts:390:9]", `Started downloading attachment '${attachment.name}'...`);
        const docId = attachment.threadId;
        const blobId = attachment.blobId;
        try {
            const res = await this.singletons.quipClient.getBlob(docId, blobId);
            return res.blob;
        }
        catch (e) {
            logger.log("[src/quip/WikiExport.ts:398:13]", "Error downloading attachment blob via the Quip API, will attempt via the Fetch API", e);
        }
        try {
            const response = await fetchWrapper(attachment.quipUrl.replaceAll('&amp;', '&'));
            if (!response.ok) {
                // noinspection ExceptionCaughtLocallyJS
                throw new Error(`Failed to download attachment ${attachment.name} with status: ${response.status}`);
            }
            const blob = await response.blob();
            logger.log("[src/quip/WikiExport.ts:409:13]", `[wiki-export] fetched attachment '${attachment.name}': size=${formatBytes(blob.size)}, type=${blob.type}`);
            return blob;
        }
        catch (e) {
            logger.error("[src/quip/WikiExport.ts:413:13]", `Failed to download attachment ${attachment.name} with error: ${e}`);
            if (!(attachment.internalId && useInternalId))
                throw e;
            logger.info("[src/quip/WikiExport.ts:418:13]", `Please wait, trying to get alternative URL for attachment ${attachment.name}...`);
            const alternativeAttachmentInfo = await this.getAlternativeUrl(attachment.internalId, attachment.name);
            if (alternativeAttachmentInfo)
                return await this.getAttachmentBlob(alternativeAttachmentInfo, false);
            throw new Error(`Failed to get an alternative URL for attachment ${attachment.name} with internal id ${attachment.internalId}`);
        }
    }
    async getAlternativeUrl(internalId, attachmentName) {
        const baseSelector = `[data-id='${internalId}']`;
        const imageSelector = `${baseSelector} img`;
        let correspondingImage = document.querySelector(imageSelector);
        if (correspondingImage == null) {
            // A null image here means that the container of the image was loaded,
            // but the image itself (which has the src attribute we need) was not loaded.
            // So we scroll to the image container, wait for it to be loaded and try getting the src attribute again.
            const containerNode = document.querySelector(baseSelector);
            if (containerNode != null) {
                containerNode.scrollIntoView();
                correspondingImage = await constantRetry(5000, 50)
                    .execute(() => {
                    const imageNode = document.querySelector(imageSelector);
                    if (imageNode == null)
                        throw new Error(`Failed to find alternative URL for attachment ${attachmentName} with internal id ${internalId}`);
                    return imageNode;
                });
            }
        }
        if (correspondingImage)
            return extractQuipAttachmentInformation(correspondingImage);
        return undefined;
    }
    /**
     * Downloads an attachment
     *
     * @param {string} wikiAddr Wiki address
     * @param {string} content Content
     * @param {string} syntax Syntax
     * @param {number} timestamp Timestamp
     * @param {string} title Title
     */
    async savePage(wikiAddr, content, syntax, timestamp, title) {
        // create page content
        const version = this.singletons.session.version;
        const comment = `Updated with Quip2Wiki Tampermonkey script version ${version} (timestamp=${timestamp})`;
        const xmlContent = createXmlPageDocument(title, content, syntax, comment);
        if (sessionState.isReproductionRun) {
            if (syntax == 'xhtml')
                sessionState.reproductionData.output.xhtml = content;
            if (syntax == 'xwiki')
                sessionState.reproductionData.output.xwiki = content;
        }
        // save wiki content
        await this.singletons.wikiClient.putXmlContent(wikiAddr, xmlContent, 'home');
    }
    /**
     * Processes all documents in a folder
     *
     * @param {FolderWrapper} folder The folder containing documents to process
     * @param {string} parentWikiAddr The Wiki address of the parent folder
     */
    async processDocumentsInFolder(folder, parentWikiAddr, syntax) {
        // Track exported titles at this level to handle duplicates
        const exportedTitlesAtThisLevel = new Map();
        // Process all documents in the folder
        // The difference now is that we have not yet loaded the HTML from each document
        for (const item of folder.children) {
            try {
                if (item.type === 'document') {
                    // Get the document
                    const doc = await this.singletons.quipClient.getDocument(item.id);
                    if (!doc)
                        continue;
                    // Check if document has a synced wiki address
                    let wikiAddr = doc.getWikiSyncAddress();
                    if (!wikiAddr) {
                        // Generate a wiki address for the document
                        let title = doc.titleAsUrl || `document_${item.id}`;
                        // Handle duplicate titles at this level
                        if (exportedTitlesAtThisLevel.has(title)) {
                            const count = exportedTitlesAtThisLevel.get(title) + 1;
                            exportedTitlesAtThisLevel.set(title, count);
                            const uniqueId = item.id.substring(0, 6);
                            title = `${title}_${uniqueId}`;
                        }
                        else {
                            exportedTitlesAtThisLevel.set(title, 1);
                        }
                        wikiAddr = `${parentWikiAddr}/${title}`;
                    }
                    item.wikiAddr = wikiAddr;
                    doc.wikiAddr = wikiAddr;
                    // Add wiki-sync tag
                    await QuipEditor.writeWikiAddressTag(doc, wikiAddr, this.singletons.quipClient);
                    // Export the document
                    logger.log("[src/quip/WikiExport.ts:528:21]", `Exporting document: ${doc.title}`);
                    const timestamp = doc.lastUpdated;
                    await this.exportDocument(doc, wikiAddr, timestamp, syntax);
                }
            }
            catch (error) {
                logger.error("[src/quip/WikiExport.ts:533:17]", `Error processing document: ${error}`);
            }
        }
    }
    /**
     * Processes all subfolders in a folder recursively
     *
     * @param {FolderWrapper} folder The folder containing subfolders to process
     * @param {string} parentWikiAddr The Wiki address of the parent folder
     */
    async processSubfolders(folder, parentWikiAddr, syntax) {
        // Track exported folder titles at this level to handle duplicates
        const exportedFolderTitlesAtThisLevel = new Map();
        // Process all subfolders
        for (const item of folder.children) {
            try {
                if (item.type === 'folder') {
                    const subfolder = item;
                    // Generate wiki address for the subfolder
                    const folderTitle = subfolder.value.folder.title;
                    let safeTitle = folderTitle.replace(/\s+/g, '').replace(/[^\w-]/g, '');
                    // Handle duplicate titles at this level
                    if (exportedFolderTitlesAtThisLevel.has(safeTitle)) {
                        const count = exportedFolderTitlesAtThisLevel.get(safeTitle) + 1;
                        exportedFolderTitlesAtThisLevel.set(safeTitle, count);
                        const uniqueId = item.id.substring(0, 6);
                        safeTitle = `${safeTitle}_${uniqueId}`;
                    }
                    else {
                        exportedFolderTitlesAtThisLevel.set(safeTitle, 1);
                    }
                    const subfolderWikiAddr = `${parentWikiAddr}/${safeTitle}`;
                    // Recursively process the subfolder
                    await this.exportFolderDocuments(subfolder, subfolderWikiAddr, syntax);
                    // Create folder index page
                    const timestamp = subfolder.value.folder.updated_usec;
                    const pageTitle = `${subfolder.value.folder.title} Index`;
                    logger.log("[src/quip/WikiExport.ts:577:21]", `Creating folder index page: ${pageTitle}`);
                    subfolder.wikiAddr = subfolderWikiAddr;
                    let content;
                    if (syntax == 'xwiki') {
                        content = XWikiConverter.convertQuipFolderListingToXWiki(this.singletons, subfolder);
                    }
                    else {
                        content = XHtmlConverter.convertQuipFolderListingToXHTML(this.singletons, subfolder);
                    }
                    await this.savePage(subfolderWikiAddr, content, syntax, timestamp, pageTitle);
                }
            }
            catch (error) {
                logger.error("[src/quip/WikiExport.ts:589:17]", `Error processing subfolder: ${error}`);
            }
        }
    }
}
async function fetchWrapper(address) {
    if (sessionState.isReproductionRun) {
        try {
            const response = await fetch(address);
            sessionState.fetchRequests.push({
                address,
                statusCode: response.status,
                response: atob(await response.text())
            });
            return response;
        }
        catch (e) {
            sessionState.fetchRequests.push({
                address,
                statusCode: 0,
                response: `${e}`
            });
            throw e;
        }
    }
    return await fetch(address);
}

class FetchClient extends RemoteClient {
    constructor(singletons, beforeRetry) {
        super(singletons, 10, 10, beforeRetry, 'Unknown Service');
        this.retries = 3;
    }
    async fetchUrl(requestUrl, serviceName, timeoutMillis, waitIntervalMs) {
        this.serviceName = serviceName;
        this.readWaitMs = waitIntervalMs;
        const response = await this.execute('read', {
            method: 'GET',
            url: requestUrl,
            headers: {
                credentials: 'include',
            },
            timeout: timeoutMillis,
        });
        return response.responseText;
    }
}

const HOW_MANY_ENDPOINT = 'https://0s62bmu3aj.execute-api.us-east-1.amazonaws.com/PROD';
class HowManyClient extends RemoteClient {
    constructor(singletons) {
        super(singletons, 10, 10, async () => false, 'HowMany');
        this.retries = 0;
    }
    async callTracker(pixelID, params = {}) {
        params.PixelID = pixelID;
        const response = await this.execute('read', {
            method: 'GET',
            url: `${HOW_MANY_ENDPOINT}/pixel/tracker?${getEncodedQueryData(params)}`,
            headers: {
                credentials: 'include',
            },
            timeout: 5000,
        }, {
            acceptedResponseStatus: [200, 304]
        });
        logger.log("[src/client/HowManyClient.ts:27:9]", `HowMany tracker response status: ${response.status}`);
    }
}

class MidwayClient extends RemoteClient {
    constructor(singletons, beforeRetry) {
        super(singletons, 1, 1, beforeRetry, 'Midway API');
    }
    /**
     * Utility method to retrieve the currently authenticated amazonian's username by making a request to a Midway status page.
     */
    async getMidwayUser() {
        const response = await this.execute('read', {
            method: 'GET',
            url: "https://midway-auth.amazon.com/api/session-status",
            timeout: 5000,
        });
        const responseObj = JSON.parse(response.responseText);
        if (responseObj) {
            if (responseObj.authenticated || (window.navigator.userAgent.includes("Safari") && responseObj.user_name)) {
                logger.log("[src/client/MidwayClient.ts:23:17]", `getMidwayUser response: authenticated=${responseObj.authenticated}, login=${responseObj.user_name}`);
                return responseObj.user_name;
            }
            logger.debug("[src/client/MidwayClient.ts:26:13]", `getMidwayUser response error: ${JSON.stringify(responseObj)}`);
        }
        throw new Error("You are not authenticated to Midway");
    }
}

// ignore file coverage
class LocalDataLruCache {
    constructor(singletons, cacheName, cacheSize) {
        this.singletons = singletons;
        this.cacheName = cacheName;
        this.lruCache = new LRU(cacheSize);
        const cachedData = this.getLocalData();
        for (const [key, value] of Object.entries(cachedData).reverse()) {
            // The entries are reversed so that (in most Javascript implementations) the cache ordering is preserved between sessions
            this.lruCache.write(key, value);
        }
    }
    get(key, fn) {
        const cachedValue = this.lruCache.read(key);
        if (cachedValue)
            return cachedValue;
        logger.debug("[src/browser/LruCache.ts:28:9]", `Key ${key} was not present in LRU cache (${this.cacheName}). Retrieving value...`);
        const newValue = fn(key);
        if (!newValue)
            return undefined;
        logger.debug("[src/browser/LruCache.ts:32:9]", `Retrieved value ${newValue} successfully for key ${key}. Adding it to cache (${this.cacheName})`);
        this.lruCache.write(key, newValue);
        return newValue;
    }
    async getAsync(key, fn) {
        const cachedValue = this.lruCache.read(key);
        if (cachedValue)
            return cachedValue;
        logger.debug("[src/browser/LruCache.ts:41:9]", `Key ${key} was not present in LRU cache (${this.cacheName}). Retrieving value...`);
        try {
            const newValue = await fn(key);
            if (!newValue)
                return undefined;
            logger.debug("[src/browser/LruCache.ts:46:13]", `Retrieved value ${newValue} succesfully for key ${key}. Adding it to cache (${this.cacheName})`);
            this.lruCache.write(key, newValue);
            return newValue;
        }
        catch (e) {
            logger.warn("[src/browser/LruCache.ts:50:13]", `Error while trying to get new value for key=${key}.`, e);
            return undefined;
        }
    }
    getLocalData() {
        const value = this.singletons.settings.loadValue(this.cacheName, null);
        if (value) {
            return JSON.parse(value);
        }
        else {
            return {};
        }
    }
    persistCache() {
        const value = JSON.stringify(this.lruCache.getObjectMap());
        this.singletons.settings.saveValue(this.cacheName, value);
    }
}
// Implementations of CacheNode and LRU pretty much copied from https://medium.com/dsinjs/implementing-lru-cache-in-javascript-94ba6755cda9 with a few helpers added
class CacheNode {
    constructor(key, value, next = null, prev = null) {
        this.key = key;
        this.value = value;
        this.next = next;
        this.prev = prev;
    }
}
class LRU {
    constructor(limit) {
        this.size = 0;
        this.limit = limit;
        this.head = null;
        this.tail = null;
        this.cacheMap = {};
    }
    write(key, value) {
        const existingCacheNode = this.cacheMap[key];
        if (existingCacheNode) {
            this.detach(existingCacheNode);
            this.size--;
        }
        else if (this.size === this.limit && this.tail) {
            delete this.cacheMap[this.tail.key];
            this.detach(this.tail);
            this.size--;
        }
        // Write to head of LinkedList
        if (!this.head) {
            this.head = this.tail = new CacheNode(key, value);
        }
        else {
            const node = new CacheNode(key, value, this.head);
            this.head.prev = node;
            this.head = node;
        }
        // update cacheMap with LinkedList key and CacheNode reference
        this.cacheMap[key] = this.head;
        this.size++;
    }
    read(key) {
        const existingCacheNode = this.cacheMap[key];
        if (existingCacheNode) {
            const value = existingCacheNode.value;
            // Make the node as new Head of LinkedList if not already
            if (this.head !== existingCacheNode) {
                // write will automatically remove the node from it's position and make it a new head i.e most used
                this.write(key, value);
            }
            return value;
        }
        logger.log("[src/browser/LruCache.ts:139:9]", `Item not available in cache for key ${key}`);
        return undefined;
    }
    detach(node) {
        if (node.prev !== null) {
            node.prev.next = node.next;
        }
        else {
            this.head = node.next;
        }
        if (node.next !== null) {
            node.next.prev = node.prev;
        }
        else {
            this.tail = node.prev;
        }
    }
    clear() {
        this.head = null;
        this.tail = null;
        this.size = 0;
        this.cacheMap = {};
    }
    // Invokes the callback function with every node of the chain and the index of the node.
    forEach(fn) {
        let node = this.head;
        let counter = 0;
        while (node) {
            fn(node, counter);
            node = node.next;
            counter++;
        }
    }
    getObjectMap() {
        const m = {};
        this.forEach((node => {
            m[node.key] = node.value;
        }));
        return m;
    }
    // To iterate over LRU with a 'for...of' loop
    *[Symbol.iterator]() {
        let node = this.head;
        while (node) {
            yield node;
            node = node.next;
        }
    }
}

async function initializeQuip2Wiki(singletons) {
    try {
        await init(singletons);
    }
    catch (e) {
        logger.error("[src/oldMain.ts:32:9]", e);
        const msg = `Error loading Quip2Wiki: ${e}.\n\nIf this error persists, Quip2Wiki installation may be corrupted and you will need to re-install the script.\n\nPress 'OK' to open a guide on how to fix this issue on Quip2Wiki page.`;
        if (window.confirm(msg)) {
            singletons.tampermonkey.GM_openInTab(REINSTALL_FAQ_URL, { active: true });
        }
    }
}
function buildDefaultSingletonObject(tm) {
    const tampermonkey = new TamperMonkeyWrapper();
    const settings = new LocalStorageSettings(tampermonkey);
    const retryAction = async (singletons, error, serviceName) => {
        return await promptForAuthentication(singletons, error.message, serviceName);
    };
    const singletons = {
        tampermonkey,
        settings,
        // @ts-expect-error session needs singleton to be initialized
        session: undefined,
        // @ts-expect-error fetchClient needs singleton to be initialized
        fetchClient: undefined,
        // @ts-expect-error maxisClient needs singleton to be initialized
        maxis: undefined,
        // @ts-expect-error wikiClient needs singleton to be initialized
        wikiClient: undefined,
        // @ts-expect-error quipClient needs singleton to be initialized
        quipClient: undefined,
        // @ts-expect-error wikiExport needs singleton to be initialized
        wikiExport: undefined,
    };
    singletons.fetchClient = new FetchClient(singletons, retryAction);
    singletons.howManyClient = new HowManyClient(singletons);
    singletons.session = new SessionInfo(singletons);
    singletons.maxis = new MaxisApi(singletons, retryAction);
    singletons.midwayClient = new MidwayClient(singletons, retryAction);
    singletons.quipClient = new QuipClient(singletons);
    singletons.wikiClient = new WikiClient(singletons, retryAction);
    singletons.wikiExport = new WikiExport(singletons);
    singletons.quipUserCache = new LocalDataLruCache(singletons, "quipUserCache", 200);
    return singletons;
}
state.appTitle = 'Export to Wiki...';
state.iframeData = new Map();
state.latestVersion = null;
const KNOWN_ISSUES_URL = 'https://w.amazon.com/bin/view/Quip2Wiki#HKnownIssues';
const REINSTALL_FAQ_URL = 'https://w.amazon.com/bin/view/Quip2Wiki#HHowtofixissueof22ErrorloadingQuip2Wiki223F';
/**
 * A function that checks if an element is of type HTMLElement safely even in a cross-frame environment
 * @param node
 */
function safeIsHtmlElement(node) {
    const OwnElement = node?.ownerDocument?.defaultView?.Element;
    return OwnElement != null && node instanceof OwnElement;
}
/*
 * Quip2Wiki initialization.
 */
async function init(singletons) {
    // if we are running inside an iframe, monitor for Design Inspector links and send messages to top window
    if (window.top !== window.self) {
        const domain = document.domain;
        const view = document.defaultView?.name || '';
        logger.debug("[src/oldMain.ts:101:9]", `Running on iframe '${domain}', view '${view}'`);
        const isDiInspectorMutation = (mutation) => {
            // check iframe has changed src, width or height attributes
            const isAttrChange = mutation.type === 'attributes' && safeIsHtmlElement(mutation.target)
                && mutation.target.tagName === 'IFRAME' && mutation.attributeName != null
                && ['src', 'width', 'height'].includes(mutation.attributeName);
            // check iframe has been created
            const isNewNode = mutation.type === 'childList'
                && [...mutation.addedNodes].find(n => safeIsHtmlElement(n) && n.tagName === 'IFRAME');
            return isAttrChange || isNewNode;
        };
        const notifyDiInspector = async (mutantionList) => {
            if (mutantionList != null && !mutantionList.find(m => isDiInspectorMutation(m))) {
                return;
            }
            [...document.body.querySelectorAll('iframe[src^="https://design-inspector.a2z.com/"]')]
                .filter(diElement => !!diElement.src)
                .forEach(diElement => {
                if (diElement && diElement.src) {
                    logger.log("[src/oldMain.ts:123:25]", `Detected Design Inspector iframe '${domain}' '${view}': ${diElement.src}`);
                    window.top?.postMessage({
                        content: {
                            domain: domain,
                            view: view,
                            diUrl: diElement.src,
                            width: diElement.width,
                            height: diElement.height
                        }
                    }, "*");
                }
                else {
                    logger.log("[src/oldMain.ts:134:25]", `Could not detect Design Inspector iframe on domain '${document.domain}'`);
                }
            });
        };
        // await notifyDiInspector(); // TODO - check via tests if this call is necessary
        // create observer to detect a design-inspector was loaded
        const iframeObserver = new MutationObserver(notifyDiInspector);
        //iframeObserver.observe(document, { attributeFilter: [ "src", "width", "height" ], childList: true, subtree: true });
        iframeObserver.observe(document, { attributes: true, childList: true, subtree: true });
        return;
    }
    state.exportFunction = exportToWiki;
    printBasicInfo(singletons);
    initCss(singletons.tampermonkey);
    showSettingsMenus(singletons);
    // configure log override with SHIFT key down
    addEventListener("keydown", onKeyUpOrDown);
    addEventListener("keyup", onKeyUpOrDown);
    // Only block native editor on XHTML pages
    const wikiUrlInfo = getWikiUrlInfo();
    let isXwiki = false;
    if (wikiUrlInfo) {
        const wikiPageTags = await singletons.wikiClient.getTags(wikiUrlInfo.addr);
        isXwiki = wikiPageTags.includes('Quip2Wiki:xwiki');
    }
    if (isWikiPage()) {
        logger.debug("[src/oldMain.ts:171:9]", 'wiki page info: ' + JSON.stringify(getWikiUrlInfo()));
        if (singletons.settings.wikiBlockEnabled) {
            if (!isXwiki) {
                await blockEdit(singletons.wikiClient);
            }
        }
        return;
    }
    // Setup message event listener to persist Design Inspector data coming from iframes
    window.addEventListener("message", (event) => {
        const { content } = event.data;
        if (content && content.domain && content.diUrl) {
            logger.debug("[src/oldMain.ts:184:13]", `Received data from iframe: ${JSON.stringify(content)}`);
            const key = { domain: content.domain, view: content.view };
            state.iframeData.set(key, content);
        }
    }, false);
    const isDevMode = singletons.settings.loadFlag("devMode", false);
    if (isDevMode) {
        showDevDialog(singletons);
    }
    await initTelemetry(singletons);
}
function initCss(tampermonkey) {
    const newCSS = tampermonkey.GM_getResourceText("jquery-ui-css");
    tampermonkey.GM_addStyle(newCSS);
}
function onKeyUpOrDown(e) {
    state.shiftKeyIsPressed = e.shiftKey;
    state.altKeyIsPressed = e.altKey;
}
function printBasicInfo(singletons) {
    logger.debug("[src/oldMain.ts:209:5]", `Browser: ${singletons.session.getBrowser()}`);
    logger.debug("[src/oldMain.ts:210:5]", `Tampermonkey Version: ${singletons.session.gmVersion}`);
    logger.debug("[src/oldMain.ts:211:5]", `Quip2Wiki Version: ${singletons.session.version}`);
}
function logBasicInfo(singletons) {
    logger.log("[src/oldMain.ts:215:5]", `Browser: ${singletons.session.getBrowser()}`);
    logger.log("[src/oldMain.ts:216:5]", `Tampermonkey Version: ${singletons.session.gmVersion}`);
    logger.log("[src/oldMain.ts:217:5]", `Quip2Wiki Version: ${singletons.session.version}`);
}
function showSettingsMenus(singletons) {
    const settings = singletons.settings;
    const wikiBlockActionText = settings.wikiBlockEnabled ? 'Disable' : 'Enable';
    singletons.tampermonkey.GM_registerMenuCommand(`${wikiBlockActionText} Wiki editor block`, () => {
        settings.wikiBlockEnabled = !settings.wikiBlockEnabled; // switch value
        settings.save();
        const newState = settings.wikiBlockEnabled ? 'enabled' : 'disabled';
        showAlert(singletons, 'Quip2Wiki', `Wiki editor block successfully ${newState}.</br>Refresh the page for the change to take effect`);
    });
    const exportDialogEnabledActionText = settings.exportDialogEnabled ? 'Disable' : 'Enable';
    singletons.tampermonkey.GM_registerMenuCommand(`${exportDialogEnabledActionText} export confirmation dialog`, () => {
        settings.exportDialogEnabled = !settings.exportDialogEnabled; // switch value
        settings.save();
        const newState = settings.exportDialogEnabled ? 'enabled' : 'disabled';
        showAlert(singletons, 'Quip2Wiki', `Export confirmation dialog successfully ${newState}.</br>Refresh the page for the change to take effect</br></br>Press ALT key (Option key in Mac) before clicking on "Export to Wiki" button to show the confirmation dialog`);
    });
}
async function checkForUpdates(singletons) {
    if (window.location.href.startsWith("https://quip-amazon.com/account"))
        return;
    try {
        const versionInfo = await singletons.session.getLatestVersion();
        if (versionInfo && versionInfo.version) {
            if (versionInfo.isNew) {
                logger.log("[src/oldMain.ts:247:17]", `A new version is available: ${versionInfo.version}`);
            }
            else {
                logger.log("[src/oldMain.ts:249:17]", `No update available`);
            }
            state.latestVersion = versionInfo;
            state.latestParsedVersion = parseVersion(versionInfo.version);
            // we will show a dialog if there is a mandatory update
            await promptForScriptUpdate(singletons);
        }
        else {
            logger.error("[src/oldMain.ts:257:13]", 'Unknown error determining latest version available');
        }
    }
    catch (err) {
        logger.error("[src/oldMain.ts:260:9]", `Unable to determine latest version available: ${err}`);
    }
}
async function checkNetwork(singletons) {
    logger.log("[src/oldMain.ts:265:5]", 'Checking network connection..');
    try {
        await singletons.midwayClient.getMidwayUser(); // check midway authentication
    }
    catch (ex) {
        logger.error("[src/oldMain.ts:270:9]", `Network connection error [midway]: ${ex}`);
        return false;
    }
    try {
        await singletons.wikiClient.testConnection(); // check wiki API connection
    }
    catch (ex) {
        logger.error("[src/oldMain.ts:277:9]", `Network connection error [wiki-api]: ${ex}`);
        return false;
    }
    return true;
}
async function initTelemetry(singletons) {
    try {
        if (!state.telemetry) {
            const user = await singletons.session.getUserFromSession(singletons);
            state.telemetry = new Telemetry(singletons, user);
            state.telemetry.registerInstallation();
        }
    }
    catch (err) {
        state.telemetry = null;
        logger.debug("[src/oldMain.ts:293:9]", `Could not initialize telemetry: ${err}`);
    }
}
async function promptQuipApiToken(singletons) {
    let attemptNumber = 0;
    while (true) {
        attemptNumber += 1;
        const token = singletons.settings.quipApiToken; // fetch current token
        let tokenValid = false;
        if (token != null)
            tokenValid = singletons.session.isTokenTested() || await singletons.quipClient.checkNewToken(token, attemptNumber);
        if (tokenValid) {
            singletons.session.setTokenTest(true);
            break;
        }
        else {
            const dialogMessage = token
                ? 'Invalid or expired Quip API Token, please generate a new token and replace the token below.'
                : 'Missing Quip API Token! Please generate a token...';
            const dialogResult = await createQuipTokenPrompt(singletons, dialogMessage);
            if (dialogResult == 'NEW_TOKEN') {
                // let's try validating the Quip API token again
                continue;
            }
            if (dialogResult == 'USER_CANCELED' || dialogResult == 'UNKNOWN') {
                createAlert(singletons, 'Warning', 'Export process was canceled.', '300px');
                return false;
            }
        }
    }
    if (state.telemetry)
        state.telemetry.registerTokenInstallation();
    return true; // check token succeeded
}
async function getUserSpace(singletons, user) {
    if (!user) {
        return 'ApiTesting/Quip2Wiki/';
    }
    const findUserSpace = async () => {
        try {
            const recommended = DEFAULT_USER_SPACE + user;
            const recommendedSpaceResult = await singletons.wikiClient.search(`Users.${user}`, 'spaces', 1);
            if (recommendedSpaceResult.length > 0) {
                return recommended;
            }
            const legacySpaceResult = await singletons.wikiClient.search(`User.${user}`, 'spaces', 1);
            if (legacySpaceResult.length > 0) {
                return `User/` + user;
            }
            return recommended;
        }
        catch (e) {
            logger.warn("[src/oldMain.ts:356:13]", `Unexpected error finding user space: ${e}`);
            return `Users/${user}`;
        }
    };
    const key = `${user}:space`;
    const addr = singletons.settings.loadValue(key, null) || await findUserSpace();
    singletons.settings.saveValue(key, addr);
    return addr + '/Quip/';
}
async function promptForScriptUpdate(singletons, onlyForcedUpdate = false) {
    if (!state.latestVersion)
        return; // no update available
    if (!state.latestVersion.isNew)
        return; // no update available
    if (onlyForcedUpdate && !state.latestVersion.forceUpdate) {
        return; // update is not mandatory
    }
    const now = new Date();
    const lastUpdatedPromptString = singletons.settings.loadValue('LastUpdatePrompt');
    if (!lastUpdatedPromptString) {
        // The lastUpdatedPrompt string wasn't saved properly or was corrupted somehow
        // Thus we override it in the hopes that the new value is saved correctly - this will make the prompt appear 2 days later for these users
        singletons.settings.saveValue('LastUpdatePrompt', now.toISOString());
    }
    let lastPrompt = now;
    try {
        if (lastUpdatedPromptString != null)
            lastPrompt = new Date(lastUpdatedPromptString);
    }
    catch (error) {
        // if an error still happens here, we save the LastUpdatePrompt property to try and correct the problem
        logger.debug("[src/oldMain.ts:390:9]", error);
        singletons.settings.saveValue('LastUpdatePrompt', now.toISOString());
    }
    const elapsed = now.getTime() - lastPrompt.getTime();
    const TWO_DAYS = 2 * 24 * 60 * 60 * 1000; // 2 days in milliseconds
    if (elapsed && elapsed < TWO_DAYS && elapsed > 0) {
        logger.log("[src/oldMain.ts:397:9]", `Will not prompt for an update until ${new Date(lastPrompt.getTime() + TWO_DAYS).toISOString()}`);
        return; // let's not bug the user for now
    }
    singletons.settings.saveValue('LastUpdatePrompt', now.toISOString());
    const buttons = {
        "Remind me later": false,
        "Update now": true
    };
    const updateUrl = state.latestVersion.url;
    const updateNow = await waitForDialogResult(singletons, 'Quip2Wiki Update', 'There is a new release of Quip2Wiki available:\n\n' +
        `<code>- Current version: <b>${singletons.session.version}</b></code>\n` +
        `<code>- New version: &nbsp;&nbsp;&nbsp;&nbsp;<b>${state.latestVersion.version}</b></code>\n\n` +
        '<span style="font-style:italic; font-size: x-small">The latest version is available for ' +
        `<span style="text-decoration:underline; font-style:italic; font-size: x-small"><a href="${updateUrl}" target="_blank" rel="noopener">download here</a></span>` +
        '</span>', buttons);
    if (updateNow) {
        logger.log("[src/oldMain.ts:422:9]", 'Opening latest script at ${updateUrl}');
        singletons.tampermonkey.GM_openInTab(updateUrl, { active: true, setParent: true });
        alert('After updating Quip2Wiki, all open Quip tabs should be reloaded');
        location.reload();
        return false; // will cause export process to be canceled
    }
    else {
        singletons.settings.saveValue('LastUpdatePrompt', now.toISOString());
        return true; // export process can continue
    }
}
/**
 * Exports the current Quip document to a Wiki page.
 */
async function exportToWiki(singletons, forceFormat, isRetry = false) {
    try {
        if (state.isExporting) {
            return; // task is already running
        }
        logBasicInfo(singletons);
        updateExportButton('Checking Network...', true);
        await checkNetwork(singletons);
        updateExportButton('Preparing...', true);
        await initTelemetry(singletons); // TODO check if we need to init telemetry here again
        const isQuipClientInitialized = await promptQuipApiToken(singletons);
        if (!isQuipClientInitialized) {
            return; // user canceled
        }
        if (state.telemetry)
            state.telemetry.registerExportAttempt();
        const isFolder = QuipEditor.isFolder();
        if (isFolder) {
            if (QuipEditor.hasListOfDocuments()) {
                logger.log("[src/oldMain.ts:463:17]", "Current page contains a list of folders/documents");
            }
            await exportFolderToWiki(singletons);
        }
        else {
            await exportDocumentToWiki(singletons, forceFormat);
        }
    }
    catch (ex) {
        const errorMessage = String(ex);
        if (errorMessage === ABORTED_BY_USER) {
            // if the user stopped the operation, we don't do anything other than stopping the operation
            return;
        }
        // This is a bit brittle, as it depends on Quip API error messages, but it's the best we can do...
        if (!isRetry && errorMessage.includes('token') && errorMessage.includes('invalid')) {
            // If we are not already retrying, try again after prompting for a new token
            const newTokenConfigured = await promptQuipApiToken(singletons);
            if (newTokenConfigured) {
                setTimeout(() => {
                    exportToWiki(singletons, forceFormat, true);
                });
                return;
            }
        }
        const docType = QuipEditor.getDocumentType();
        logger.error("[src/oldMain.ts:492:9]", ex);
        if (state.telemetry != null)
            await state.telemetry.registerUsage(docType || "unknown", ex);
        let message = `Reason: ${ex}`;
        let options = { 'Download logs': true, OK: false };
        if (errorMessage.startsWith(MIDWAY_REDIRECT_URL)) {
            const authUrl = errorMessage;
            message = `<span>Midway authentication is required. Click <b><a href="${authUrl}" target="_blank" rel="noopener">here</a></b> to authenticate, then try exporting again.</span>`;
            options = {
                'Open Midway to authenticate': () => {
                    unsafeWindow.open(authUrl, "_blank")?.focus();
                    return false;
                }, OK: false
            };
        }
        const dialogContent = (errorMessage.includes('<a href') || ex instanceof RawError)
            ? errorMessage
            : `An error occurred while exporting the Quip ${docType}. `
                + `If the error persists, please <span style="text-decoration:underline; font-style:italic;"><a href="${KNOWN_ISSUES_URL}" target="_blank" rel="noopener">check for known issues</a></span>, `
                + `ask for help at <span style="text-decoration:underline;"><a href="https://slack.com/app_redirect?channel=quip2wiki" target="_blank" rel="noopener">#quip2wiki</a></span> Slack channel, or `
                + `<span style="text-decoration:underline; font-style:italic;"><a href="${TICKET_URL}" target="_blank" rel="noopener">open a ticket</a></span><br/><br/>${message}`;
        const shouldDownloadLogs = await waitForDialogResult(singletons, state.appTitle, dialogContent, options);
        if (shouldDownloadLogs) {
            downloadFromMemory("Quip2Wiki.log.txt", getLogForDownload(singletons, GIT_HASH));
        }
    }
    finally {
        updateExportButton(BUTTON_TEXT, false);
        try {
            await checkForUpdates(singletons);
        }
        catch (ex) {
            logger.error("[src/oldMain.ts:529:13]", "Could not check for updates...", ex);
        }
    }
}
async function exportDocumentToWiki(singletons, forceFormat) {
    const docId = QuipEditor.getDocumentId();
    if (!docId)
        throw 'Could not load Quip document!';
    if (sessionState.isReproductionRun)
        sessionState.reproductionData.docId = docId;
    let doc = await singletons.quipClient.getDocument(docId);
    if (!doc)
        throw 'Could not load Quip document!';
    let wikiAddr = doc.getWikiSyncAddress();
    let newWikiAddr = wikiAddr;
    if (!wikiAddr) {
        const user = await singletons.session.getUserFromSession(singletons);
        if (sessionState.isReproductionRun)
            sessionState.reproductionData.currentUser = user;
        const title = doc.titleAsUrl;
        const suggAddr = await getUserSpace(singletons, user) + title;
        newWikiAddr = await promptForNewWikiAddress(singletons, suggAddr, singletons.wikiClient);
        if (!newWikiAddr) {
            return;
        }
        logger.log("[src/oldMain.ts:558:9]", `User selected wiki page: ${wikiAddr}`);
    }
    else if (singletons.settings.exportDialogEnabled || state.altKeyIsPressed) {
        newWikiAddr = await promptForExistingWikiAddress(singletons, wikiAddr, doc.type, singletons.wikiClient);
        if (!newWikiAddr) { // prompt was cancelled
            return;
        }
        logger.log("[src/oldMain.ts:564:9]", `Selected wiki page from tag: ${wikiAddr}`);
    }
    // save wiki address
    if (newWikiAddr !== wikiAddr && newWikiAddr != null) {
        wikiAddr = newWikiAddr;
        await QuipEditor.writeWikiAddressTag(doc, wikiAddr, singletons.quipClient);
        // reload doc
        doc = await singletons.quipClient.getDocument(docId);
    }
    if (wikiAddr == null)
        throw new Error("Wiki address configuration (wiki-sync tag) is unexpectedly null");
    const url = `${VIEW_URL}${wikiAddr}`;
    const wikiLink = `<span style="text-decoration:underline; font-style:italic;"><a href="${url}" target="_blank" rel="noopener">${url}</a></span>`;
    const timestamp = doc.lastUpdated;
    const wikiExists = await singletons.wikiClient.wikiPageExists(wikiAddr);
    if (wikiExists) {
        const wikiTimestamp = await singletons.wikiClient.getLastUpdated(wikiAddr);
        if (!wikiTimestamp) {
            const dialogResult = await promptForChangedWikiConfirmation(singletons, wikiAddr);
            if (!dialogResult) {
                return; // cancelled
            }
        }
        else if (timestamp === wikiTimestamp) {
            const dialogResult = await showWikiInSyncDialoig(singletons, wikiLink, doc.type);
            if (!dialogResult) {
                return; // cancelled
            }
        }
    }
    updateExportButton('Exporting...', true);
    const success = await singletons.wikiExport.exportDocument(doc, wikiAddr, timestamp, forceFormat);
    if (!success) {
        return; // user aborted
    }
    if (state.telemetry != null) {
        // TODO: Check if we should await these calls
        state.telemetry.registerSuccessfulExport();
        state.telemetry.registerUsage(doc.type);
    }
    const msg = `Quip ${doc.type} successfully exported to Amazon Wiki<br/><br/>${wikiLink}`;
    await showAlert(singletons, state.appTitle, msg);
}
async function exportFolderToWiki(singletons) {
    const id = QuipEditor.getFolderId();
    if (!id)
        throw new Error('Could not load Quip folder!');
    const folder = await singletons.quipClient.getFolder(id);
    if (!folder)
        throw 'Could not load Quip folder (null folder)';
    if (!folder.id)
        throw 'Could not load Quip folder (missing id in folder)';
    const title = folder.value.folder.title;
    let wikiAddr = singletons.settings.loadValue(id, null);
    if (!wikiAddr) {
        const user = await singletons.session.getUserFromSession(singletons);
        const suggAddr = await getUserSpace(singletons, user) + title + 'Index';
        wikiAddr = await promptForNewWikiAddress(singletons, suggAddr, singletons.wikiClient);
    }
    else if (singletons.settings.exportDialogEnabled || state.altKeyIsPressed) {
        wikiAddr = await promptForExistingWikiAddress(singletons, wikiAddr, 'folder', singletons.wikiClient);
    }
    if (!wikiAddr) { // prompt was cancelled
        return;
    }
    // save wiki address
    singletons.settings.saveValue(id, wikiAddr);
    showAppFooter(singletons);
    const url = `${VIEW_URL}${wikiAddr}`;
    const wikiLink = `<span style="text-decoration:underline; font-style:italic;"><a href="${url}" target="_blank" rel="noopener">${url}</a></span>`;
    const timestamp = folder.additionalInfo.lastUpdated || folder.value.folder.updated_usec;
    const wikiExists = await singletons.wikiClient.wikiPageExists(wikiAddr);
    if (wikiExists) {
        const wikiTimestamp = await singletons.wikiClient.getLastUpdated(wikiAddr);
        if (!wikiTimestamp) {
            const dialogResult = await promptForChangedWikiConfirmation(singletons, wikiAddr);
            if (!dialogResult) {
                return; // cancelled
            }
        }
    }
    updateExportButton('Calculating folder tree...', true);
    // Prompt user for folder selection
    const selectedFolder = await promptForFolderSelection(singletons, folder);
    logger.log("[src/oldMain.ts:668:5]", `selectedFolder: ${selectedFolder}`);
    if (!selectedFolder || selectedFolder.numberOfItems == 0) {
        return;
    }
    updateExportButton('Exporting...', true);
    // Use the selected folder wrapper instead of the original one
    await singletons.wikiExport.exportFolder(selectedFolder, wikiAddr, timestamp, 'xwiki');
    if (state.telemetry) {
        // TODO: Check if we should await these calls
        state.telemetry.registerSuccessfulExport();
        state.telemetry.registerUsage('folder');
    }
    const msg = `Selected documents exported to Amazon Wiki<br/><br/>${wikiLink}`;
    await showAlert(singletons, state.appTitle, msg);
}

class LocationChangeEvent extends Event {
    constructor(currentPath, newPath) {
        super('q2w_locationChange');
        this.currentPath = currentPath;
        this.newPath = newPath;
    }
}
const quipSpaState = {
    currentLocation: window.location.pathname
};
function publishLocationChangeEventOnChange(url) {
    if (url != quipSpaState.currentLocation) {
        window.dispatchEvent(new LocationChangeEvent(quipSpaState.currentLocation, url));
        quipSpaState.currentLocation = url;
    }
}
function addHooksToHistoryAndNavigateApi() {
    const oldPushState = history.pushState;
    history.pushState = function pushState(data, unused, url) {
        oldPushState.apply(this, [data, unused, url]);
        publishLocationChangeEventOnChange(window.location.pathname);
    };
    const oldReplaceState = history.replaceState;
    history.replaceState = function replaceState(data, unused, url) {
        oldReplaceState.apply(this, [data, unused, url]);
        publishLocationChangeEventOnChange(window.location.pathname);
    };
    window.addEventListener('popstate', () => {
        publishLocationChangeEventOnChange(window.location.pathname);
    });
    window.addEventListener('navigate', () => {
        publishLocationChangeEventOnChange(window.location.pathname);
    });
}
function addLocationChangeCallback(callback) {
    window.addEventListener('q2w_locationChange', (e) => {
        if (e instanceof LocationChangeEvent) {
            callback(e.currentPath, e.newPath);
        }
    });
}

function exportButtonMustBeShown(location) {
    if (location.hostname === "w.amazon.com")
        return false;
    const path = location.pathname;
    return !(path === "/" || path === "/browse" || path === "/all");
}
function removeButtonIfNecessary() {
    const showExportButton = exportButtonMustBeShown(document.location);
    if (!showExportButton) {
        $("#export-wiki-button-group").remove();
    }
}
function showExportButton(singletons) {
    // update document related settings
    const showExportButton = QuipEditor.isDocument() || QuipEditor.isFolder();
    if (showExportButton) {
        QuipEditor.createQuip2WikiButtons(singletons, () => exportToWiki(singletons, undefined)); // we need to do this otherwise the click event is sent as an argument
        if (QuipEditor.isFolder()) {
            showAppFooter(singletons);
        }
        else {
            QuipEditor.removeElement(LABEL_ID);
        }
    }
    else {
        logger.debug("[src/ui/Buttons.ts:35:9]", 'not an exportable Quip document or folder');
        QuipEditor.removeElement(BUTTON_ID);
        QuipEditor.removeElement(LABEL_ID);
    }
}
function addExportButtonsIfNecessary(singletons) {
    if (!exportButtonMustBeShown(document.location))
        return;
    const toolbar = QuipEditor.getToolbar();
    if (toolbar)
        return;
    const basePosition = QuipEditor.getBaseButtonForExportButton();
    if (basePosition)
        showExportButton(singletons);
    else
        throw new Error("Export button base position not found");
}
function fixExportButtonPosition() {
    const toolbar = QuipEditor.getToolbar();
    if (toolbar) {
        const previousElement = toolbar.previousElementSibling;
        const isExportButtonInTheRightPlace = previousElement != undefined &&
            (previousElement.ariaLabel == "Focus Mode" || previousElement.ariaLabel == "Add to Favorites");
        if (!isExportButtonInTheRightPlace) {
            const baseButton = QuipEditor.getBaseButtonForExportButton();
            if (baseButton)
                $("#export-wiki-button-group").insertAfter(baseButton);
        }
    }
}
function checkIfExportButtonExists() {
    return !!$("#export-wiki-button-group")[0];
}
const configIconStyle = `
#q2w-config-button .settings-gear {
  transition: transform 1s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  transform-origin: center;
}

#q2w-config-button .settings-gear.animate {
  transform: rotate(180deg);
}

#q2w-config-button svg {
  overflow: visible;
}`;
let configIconStyleElement = null;
function addOrFixExportButton(singletons) {
    if (window.top !== window.self) {
        // we are inside an iframe and don't need to add the export button
        return;
    }
    if (!configIconStyleElement)
        configIconStyleElement = GM_addStyle(configIconStyle);
    addExportButtonsIfNecessary(singletons);
    fixExportButtonPosition();
    removeButtonIfNecessary();
    if (exportButtonMustBeShown(document.location) && !checkIfExportButtonExists()) {
        throw new Error("Export button must exist but wasn't inserted");
    }
}
function addOrFixExportButtonWithRetry(singletons) {
    // we don't await the promise on purpose here
    // noinspection JSIgnoredPromiseFromCall
    constantRetry().execute(() => addOrFixExportButton(singletons));
}

var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */

var isObject_1;
var hasRequiredIsObject;

function requireIsObject () {
	if (hasRequiredIsObject) return isObject_1;
	hasRequiredIsObject = 1;
	function isObject(value) {
	  var type = typeof value;
	  return value != null && (type == 'object' || type == 'function');
	}

	isObject_1 = isObject;
	return isObject_1;
}

/** Detect free variable `global` from Node.js. */

var _freeGlobal;
var hasRequired_freeGlobal;

function require_freeGlobal () {
	if (hasRequired_freeGlobal) return _freeGlobal;
	hasRequired_freeGlobal = 1;
	var freeGlobal = typeof commonjsGlobal == 'object' && commonjsGlobal && commonjsGlobal.Object === Object && commonjsGlobal;

	_freeGlobal = freeGlobal;
	return _freeGlobal;
}

var _root;
var hasRequired_root;

function require_root () {
	if (hasRequired_root) return _root;
	hasRequired_root = 1;
	var freeGlobal = require_freeGlobal();

	/** Detect free variable `self`. */
	var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

	/** Used as a reference to the global object. */
	var root = freeGlobal || freeSelf || Function('return this')();

	_root = root;
	return _root;
}

var now_1;
var hasRequiredNow;

function requireNow () {
	if (hasRequiredNow) return now_1;
	hasRequiredNow = 1;
	var root = require_root();

	/**
	 * Gets the timestamp of the number of milliseconds that have elapsed since
	 * the Unix epoch (1 January 1970 00:00:00 UTC).
	 *
	 * @static
	 * @memberOf _
	 * @since 2.4.0
	 * @category Date
	 * @returns {number} Returns the timestamp.
	 * @example
	 *
	 * _.defer(function(stamp) {
	 *   console.log(_.now() - stamp);
	 * }, _.now());
	 * // => Logs the number of milliseconds it took for the deferred invocation.
	 */
	var now = function() {
	  return root.Date.now();
	};

	now_1 = now;
	return now_1;
}

/** Used to match a single whitespace character. */

var _trimmedEndIndex;
var hasRequired_trimmedEndIndex;

function require_trimmedEndIndex () {
	if (hasRequired_trimmedEndIndex) return _trimmedEndIndex;
	hasRequired_trimmedEndIndex = 1;
	var reWhitespace = /\s/;

	/**
	 * Used by `_.trim` and `_.trimEnd` to get the index of the last non-whitespace
	 * character of `string`.
	 *
	 * @private
	 * @param {string} string The string to inspect.
	 * @returns {number} Returns the index of the last non-whitespace character.
	 */
	function trimmedEndIndex(string) {
	  var index = string.length;

	  while (index-- && reWhitespace.test(string.charAt(index))) {}
	  return index;
	}

	_trimmedEndIndex = trimmedEndIndex;
	return _trimmedEndIndex;
}

var _baseTrim;
var hasRequired_baseTrim;

function require_baseTrim () {
	if (hasRequired_baseTrim) return _baseTrim;
	hasRequired_baseTrim = 1;
	var trimmedEndIndex = require_trimmedEndIndex();

	/** Used to match leading whitespace. */
	var reTrimStart = /^\s+/;

	/**
	 * The base implementation of `_.trim`.
	 *
	 * @private
	 * @param {string} string The string to trim.
	 * @returns {string} Returns the trimmed string.
	 */
	function baseTrim(string) {
	  return string
	    ? string.slice(0, trimmedEndIndex(string) + 1).replace(reTrimStart, '')
	    : string;
	}

	_baseTrim = baseTrim;
	return _baseTrim;
}

var _Symbol;
var hasRequired_Symbol;

function require_Symbol () {
	if (hasRequired_Symbol) return _Symbol;
	hasRequired_Symbol = 1;
	var root = require_root();

	/** Built-in value references. */
	var Symbol = root.Symbol;

	_Symbol = Symbol;
	return _Symbol;
}

var _getRawTag;
var hasRequired_getRawTag;

function require_getRawTag () {
	if (hasRequired_getRawTag) return _getRawTag;
	hasRequired_getRawTag = 1;
	var Symbol = require_Symbol();

	/** Used for built-in method references. */
	var objectProto = Object.prototype;

	/** Used to check objects for own properties. */
	var hasOwnProperty = objectProto.hasOwnProperty;

	/**
	 * Used to resolve the
	 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
	 * of values.
	 */
	var nativeObjectToString = objectProto.toString;

	/** Built-in value references. */
	var symToStringTag = Symbol ? Symbol.toStringTag : undefined;

	/**
	 * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
	 *
	 * @private
	 * @param {*} value The value to query.
	 * @returns {string} Returns the raw `toStringTag`.
	 */
	function getRawTag(value) {
	  var isOwn = hasOwnProperty.call(value, symToStringTag),
	      tag = value[symToStringTag];

	  try {
	    value[symToStringTag] = undefined;
	    var unmasked = true;
	  } catch (e) {}

	  var result = nativeObjectToString.call(value);
	  if (unmasked) {
	    if (isOwn) {
	      value[symToStringTag] = tag;
	    } else {
	      delete value[symToStringTag];
	    }
	  }
	  return result;
	}

	_getRawTag = getRawTag;
	return _getRawTag;
}

/** Used for built-in method references. */

var _objectToString;
var hasRequired_objectToString;

function require_objectToString () {
	if (hasRequired_objectToString) return _objectToString;
	hasRequired_objectToString = 1;
	var objectProto = Object.prototype;

	/**
	 * Used to resolve the
	 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
	 * of values.
	 */
	var nativeObjectToString = objectProto.toString;

	/**
	 * Converts `value` to a string using `Object.prototype.toString`.
	 *
	 * @private
	 * @param {*} value The value to convert.
	 * @returns {string} Returns the converted string.
	 */
	function objectToString(value) {
	  return nativeObjectToString.call(value);
	}

	_objectToString = objectToString;
	return _objectToString;
}

var _baseGetTag;
var hasRequired_baseGetTag;

function require_baseGetTag () {
	if (hasRequired_baseGetTag) return _baseGetTag;
	hasRequired_baseGetTag = 1;
	var Symbol = require_Symbol(),
	    getRawTag = require_getRawTag(),
	    objectToString = require_objectToString();

	/** `Object#toString` result references. */
	var nullTag = '[object Null]',
	    undefinedTag = '[object Undefined]';

	/** Built-in value references. */
	var symToStringTag = Symbol ? Symbol.toStringTag : undefined;

	/**
	 * The base implementation of `getTag` without fallbacks for buggy environments.
	 *
	 * @private
	 * @param {*} value The value to query.
	 * @returns {string} Returns the `toStringTag`.
	 */
	function baseGetTag(value) {
	  if (value == null) {
	    return value === undefined ? undefinedTag : nullTag;
	  }
	  return (symToStringTag && symToStringTag in Object(value))
	    ? getRawTag(value)
	    : objectToString(value);
	}

	_baseGetTag = baseGetTag;
	return _baseGetTag;
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */

var isObjectLike_1;
var hasRequiredIsObjectLike;

function requireIsObjectLike () {
	if (hasRequiredIsObjectLike) return isObjectLike_1;
	hasRequiredIsObjectLike = 1;
	function isObjectLike(value) {
	  return value != null && typeof value == 'object';
	}

	isObjectLike_1 = isObjectLike;
	return isObjectLike_1;
}

var isSymbol_1;
var hasRequiredIsSymbol;

function requireIsSymbol () {
	if (hasRequiredIsSymbol) return isSymbol_1;
	hasRequiredIsSymbol = 1;
	var baseGetTag = require_baseGetTag(),
	    isObjectLike = requireIsObjectLike();

	/** `Object#toString` result references. */
	var symbolTag = '[object Symbol]';

	/**
	 * Checks if `value` is classified as a `Symbol` primitive or object.
	 *
	 * @static
	 * @memberOf _
	 * @since 4.0.0
	 * @category Lang
	 * @param {*} value The value to check.
	 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
	 * @example
	 *
	 * _.isSymbol(Symbol.iterator);
	 * // => true
	 *
	 * _.isSymbol('abc');
	 * // => false
	 */
	function isSymbol(value) {
	  return typeof value == 'symbol' ||
	    (isObjectLike(value) && baseGetTag(value) == symbolTag);
	}

	isSymbol_1 = isSymbol;
	return isSymbol_1;
}

var toNumber_1;
var hasRequiredToNumber;

function requireToNumber () {
	if (hasRequiredToNumber) return toNumber_1;
	hasRequiredToNumber = 1;
	var baseTrim = require_baseTrim(),
	    isObject = requireIsObject(),
	    isSymbol = requireIsSymbol();

	/** Used as references for various `Number` constants. */
	var NAN = 0 / 0;

	/** Used to detect bad signed hexadecimal string values. */
	var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

	/** Used to detect binary string values. */
	var reIsBinary = /^0b[01]+$/i;

	/** Used to detect octal string values. */
	var reIsOctal = /^0o[0-7]+$/i;

	/** Built-in method references without a dependency on `root`. */
	var freeParseInt = parseInt;

	/**
	 * Converts `value` to a number.
	 *
	 * @static
	 * @memberOf _
	 * @since 4.0.0
	 * @category Lang
	 * @param {*} value The value to process.
	 * @returns {number} Returns the number.
	 * @example
	 *
	 * _.toNumber(3.2);
	 * // => 3.2
	 *
	 * _.toNumber(Number.MIN_VALUE);
	 * // => 5e-324
	 *
	 * _.toNumber(Infinity);
	 * // => Infinity
	 *
	 * _.toNumber('3.2');
	 * // => 3.2
	 */
	function toNumber(value) {
	  if (typeof value == 'number') {
	    return value;
	  }
	  if (isSymbol(value)) {
	    return NAN;
	  }
	  if (isObject(value)) {
	    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
	    value = isObject(other) ? (other + '') : other;
	  }
	  if (typeof value != 'string') {
	    return value === 0 ? value : +value;
	  }
	  value = baseTrim(value);
	  var isBinary = reIsBinary.test(value);
	  return (isBinary || reIsOctal.test(value))
	    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
	    : (reIsBadHex.test(value) ? NAN : +value);
	}

	toNumber_1 = toNumber;
	return toNumber_1;
}

var debounce_1;
var hasRequiredDebounce;

function requireDebounce () {
	if (hasRequiredDebounce) return debounce_1;
	hasRequiredDebounce = 1;
	var isObject = requireIsObject(),
	    now = requireNow(),
	    toNumber = requireToNumber();

	/** Error message constants. */
	var FUNC_ERROR_TEXT = 'Expected a function';

	/* Built-in method references for those with the same name as other `lodash` methods. */
	var nativeMax = Math.max,
	    nativeMin = Math.min;

	/**
	 * Creates a debounced function that delays invoking `func` until after `wait`
	 * milliseconds have elapsed since the last time the debounced function was
	 * invoked. The debounced function comes with a `cancel` method to cancel
	 * delayed `func` invocations and a `flush` method to immediately invoke them.
	 * Provide `options` to indicate whether `func` should be invoked on the
	 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
	 * with the last arguments provided to the debounced function. Subsequent
	 * calls to the debounced function return the result of the last `func`
	 * invocation.
	 *
	 * **Note:** If `leading` and `trailing` options are `true`, `func` is
	 * invoked on the trailing edge of the timeout only if the debounced function
	 * is invoked more than once during the `wait` timeout.
	 *
	 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
	 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
	 *
	 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
	 * for details over the differences between `_.debounce` and `_.throttle`.
	 *
	 * @static
	 * @memberOf _
	 * @since 0.1.0
	 * @category Function
	 * @param {Function} func The function to debounce.
	 * @param {number} [wait=0] The number of milliseconds to delay.
	 * @param {Object} [options={}] The options object.
	 * @param {boolean} [options.leading=false]
	 *  Specify invoking on the leading edge of the timeout.
	 * @param {number} [options.maxWait]
	 *  The maximum time `func` is allowed to be delayed before it's invoked.
	 * @param {boolean} [options.trailing=true]
	 *  Specify invoking on the trailing edge of the timeout.
	 * @returns {Function} Returns the new debounced function.
	 * @example
	 *
	 * // Avoid costly calculations while the window size is in flux.
	 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
	 *
	 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
	 * jQuery(element).on('click', _.debounce(sendMail, 300, {
	 *   'leading': true,
	 *   'trailing': false
	 * }));
	 *
	 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
	 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
	 * var source = new EventSource('/stream');
	 * jQuery(source).on('message', debounced);
	 *
	 * // Cancel the trailing debounced invocation.
	 * jQuery(window).on('popstate', debounced.cancel);
	 */
	function debounce(func, wait, options) {
	  var lastArgs,
	      lastThis,
	      maxWait,
	      result,
	      timerId,
	      lastCallTime,
	      lastInvokeTime = 0,
	      leading = false,
	      maxing = false,
	      trailing = true;

	  if (typeof func != 'function') {
	    throw new TypeError(FUNC_ERROR_TEXT);
	  }
	  wait = toNumber(wait) || 0;
	  if (isObject(options)) {
	    leading = !!options.leading;
	    maxing = 'maxWait' in options;
	    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
	    trailing = 'trailing' in options ? !!options.trailing : trailing;
	  }

	  function invokeFunc(time) {
	    var args = lastArgs,
	        thisArg = lastThis;

	    lastArgs = lastThis = undefined;
	    lastInvokeTime = time;
	    result = func.apply(thisArg, args);
	    return result;
	  }

	  function leadingEdge(time) {
	    // Reset any `maxWait` timer.
	    lastInvokeTime = time;
	    // Start the timer for the trailing edge.
	    timerId = setTimeout(timerExpired, wait);
	    // Invoke the leading edge.
	    return leading ? invokeFunc(time) : result;
	  }

	  function remainingWait(time) {
	    var timeSinceLastCall = time - lastCallTime,
	        timeSinceLastInvoke = time - lastInvokeTime,
	        timeWaiting = wait - timeSinceLastCall;

	    return maxing
	      ? nativeMin(timeWaiting, maxWait - timeSinceLastInvoke)
	      : timeWaiting;
	  }

	  function shouldInvoke(time) {
	    var timeSinceLastCall = time - lastCallTime,
	        timeSinceLastInvoke = time - lastInvokeTime;

	    // Either this is the first call, activity has stopped and we're at the
	    // trailing edge, the system time has gone backwards and we're treating
	    // it as the trailing edge, or we've hit the `maxWait` limit.
	    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
	      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
	  }

	  function timerExpired() {
	    var time = now();
	    if (shouldInvoke(time)) {
	      return trailingEdge(time);
	    }
	    // Restart the timer.
	    timerId = setTimeout(timerExpired, remainingWait(time));
	  }

	  function trailingEdge(time) {
	    timerId = undefined;

	    // Only invoke if we have `lastArgs` which means `func` has been
	    // debounced at least once.
	    if (trailing && lastArgs) {
	      return invokeFunc(time);
	    }
	    lastArgs = lastThis = undefined;
	    return result;
	  }

	  function cancel() {
	    if (timerId !== undefined) {
	      clearTimeout(timerId);
	    }
	    lastInvokeTime = 0;
	    lastArgs = lastCallTime = lastThis = timerId = undefined;
	  }

	  function flush() {
	    return timerId === undefined ? result : trailingEdge(now());
	  }

	  function debounced() {
	    var time = now(),
	        isInvoking = shouldInvoke(time);

	    lastArgs = arguments;
	    lastThis = this;
	    lastCallTime = time;

	    if (isInvoking) {
	      if (timerId === undefined) {
	        return leadingEdge(lastCallTime);
	      }
	      if (maxing) {
	        // Handle invocations in a tight loop.
	        clearTimeout(timerId);
	        timerId = setTimeout(timerExpired, wait);
	        return invokeFunc(lastCallTime);
	      }
	    }
	    if (timerId === undefined) {
	      timerId = setTimeout(timerExpired, wait);
	    }
	    return result;
	  }
	  debounced.cancel = cancel;
	  debounced.flush = flush;
	  return debounced;
	}

	debounce_1 = debounce;
	return debounce_1;
}

var throttle_1;
var hasRequiredThrottle;

function requireThrottle () {
	if (hasRequiredThrottle) return throttle_1;
	hasRequiredThrottle = 1;
	var debounce = requireDebounce(),
	    isObject = requireIsObject();

	/** Error message constants. */
	var FUNC_ERROR_TEXT = 'Expected a function';

	/**
	 * Creates a throttled function that only invokes `func` at most once per
	 * every `wait` milliseconds. The throttled function comes with a `cancel`
	 * method to cancel delayed `func` invocations and a `flush` method to
	 * immediately invoke them. Provide `options` to indicate whether `func`
	 * should be invoked on the leading and/or trailing edge of the `wait`
	 * timeout. The `func` is invoked with the last arguments provided to the
	 * throttled function. Subsequent calls to the throttled function return the
	 * result of the last `func` invocation.
	 *
	 * **Note:** If `leading` and `trailing` options are `true`, `func` is
	 * invoked on the trailing edge of the timeout only if the throttled function
	 * is invoked more than once during the `wait` timeout.
	 *
	 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
	 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
	 *
	 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
	 * for details over the differences between `_.throttle` and `_.debounce`.
	 *
	 * @static
	 * @memberOf _
	 * @since 0.1.0
	 * @category Function
	 * @param {Function} func The function to throttle.
	 * @param {number} [wait=0] The number of milliseconds to throttle invocations to.
	 * @param {Object} [options={}] The options object.
	 * @param {boolean} [options.leading=true]
	 *  Specify invoking on the leading edge of the timeout.
	 * @param {boolean} [options.trailing=true]
	 *  Specify invoking on the trailing edge of the timeout.
	 * @returns {Function} Returns the new throttled function.
	 * @example
	 *
	 * // Avoid excessively updating the position while scrolling.
	 * jQuery(window).on('scroll', _.throttle(updatePosition, 100));
	 *
	 * // Invoke `renewToken` when the click event is fired, but not more than once every 5 minutes.
	 * var throttled = _.throttle(renewToken, 300000, { 'trailing': false });
	 * jQuery(element).on('click', throttled);
	 *
	 * // Cancel the trailing throttled invocation.
	 * jQuery(window).on('popstate', throttled.cancel);
	 */
	function throttle(func, wait, options) {
	  var leading = true,
	      trailing = true;

	  if (typeof func != 'function') {
	    throw new TypeError(FUNC_ERROR_TEXT);
	  }
	  if (isObject(options)) {
	    leading = 'leading' in options ? !!options.leading : leading;
	    trailing = 'trailing' in options ? !!options.trailing : trailing;
	  }
	  return debounce(func, wait, {
	    'leading': leading,
	    'maxWait': wait,
	    'trailing': trailing
	  });
	}

	throttle_1 = throttle;
	return throttle_1;
}

// A tree-shakeable re-export of some lodash functions.
// Treat this file with care, as every function imported here, even if not used, increases the final bundle size.
// // eslint-disable-next-line @typescript-eslint/no-require-imports
// const camelCase = require("lodash/camelCase");
// eslint-disable-next-line @typescript-eslint/no-require-imports
const throttle = requireThrottle();
// eslint-disable-next-line @typescript-eslint/no-require-imports
const debounce = requireDebounce();

/**
 * Add listener to window resize events. This listener resize or reposition modal dialogs when the window is resized.
 */
function addWindowResizeListener(handler) {
    window.addEventListener("resize", handler);
}
const fixExportButton = debounce(addOrFixExportButtonWithRetry, 500, { leading: true, trailing: true });
const resizeDialogs = throttle(function () {
    $(".q2w-dialog").each(function (index, element) {
        // for each Q2W dialog, we set their position configuration again, so that they go to their correct place after resizing
        const jqElement = $(element);
        const currentPositionConfig = jqElement.dialog("option", "position");
        jqElement.dialog("option", "position", currentPositionConfig);
    });
}, 50, { leading: true, trailing: true });

const nodesToRemove = ['script', 'style', 'link'];
function getSerializedDocumentWithCleanedElements() {
    const parser = new DOMParser();
    // noinspection HtmlRequiredLangAttribute
    const parsedDom = parser.parseFromString(`<html><body>${document.body.innerHTML}</body></html>`, 'text/html');
    const bodyNodes = [...parsedDom.body.childNodes];
    for (const node of bodyNodes) {
        if (node instanceof HTMLElement) {
            const nodeTag = node.tagName.toLowerCase();
            if (nodesToRemove.includes(nodeTag)) {
                node.remove();
            }
        }
    }
    return parsedDom.body.innerHTML;
}
async function startExportProcess(singletons, exportFunction, forceAllFormats) {
    if (state.isExporting)
        throw new Error("Exporting already in progress");
    sessionState.isReproductionRun = true;
    const currentUser = await singletons.session.getUserFromSession(singletons);
    sessionState.reproductionData = {
        currentUser,
        docUrl: document.location.href,
        localStorage: {
            initialState: readLocalStorageState(singletons),
            updates: [],
        },
        output: {},
        promptInteractions: [],
        requests: {},
        serializedDocument: getSerializedDocumentWithCleanedElements(),
        timestamps: {},
        tm: {
            info: {
                script: {
                    version: singletons.tampermonkey.getScriptVersion(),
                },
                version: singletons.tampermonkey.getTampermonkeyVersion(),
            },
        },
    };
    sessionState.reproductionData.requests.fetch = [];
    if (!forceAllFormats) {
        try {
            await exportFunction(singletons);
        }
        finally {
            if (sessionState.fetchRequests.length > 0)
                sessionState.reproductionData.requests.fetch.push(...sessionState.fetchRequests);
            if (sessionState.reproductionData.output.xhtml)
                sessionState.reproductionData.requests.xhtml = sessionState.requests;
            else if (sessionState.reproductionData.output.xwiki)
                sessionState.reproductionData.requests.xwiki = sessionState.requests;
            else {
                sessionState.reproductionData.requests.unknown = sessionState.requests;
            }
            sessionState.fetchRequests = [];
            sessionState.requests = [];
            sessionState.isReproductionRun = false;
        }
        return sessionState.reproductionData;
    }
    try {
        // we convert to XHTML first, to gather all data and rendered XHTML
        await exportFunction(singletons, 'xhtml');
    }
    finally {
        if (sessionState.fetchRequests.length > 0)
            sessionState.reproductionData.requests.fetch.push(...sessionState.fetchRequests);
        sessionState.fetchRequests = [];
        sessionState.reproductionData.requests.xhtml = sessionState.requests;
        sessionState.requests = [];
        try {
            // then we convert to XWiki to get the rendered XWiki. This call will reuse the API calls when possible
            await exportFunction(singletons, 'xwiki');
        }
        finally {
            if (sessionState.fetchRequests.length > 0)
                sessionState.reproductionData.requests.fetch.push(...sessionState.fetchRequests);
            sessionState.fetchRequests = [];
            sessionState.reproductionData.requests.xwiki = sessionState.requests;
            sessionState.requests = [];
            sessionState.isReproductionRun = false;
        }
    }
    return sessionState.reproductionData;
}
function readLocalStorageState(singletons) {
    const allKeys = singletons.tampermonkey.listKeys();
    const initialState = {};
    for (let i = 0; i < allKeys.length; i++) {
        const key = allKeys[i];
        initialState[key] = singletons.tampermonkey.getRawValue(key, undefined);
    }
    return initialState;
}

function registerDownloadLogsCommand(singletons) {
    singletons.tampermonkey.GM_registerMenuCommand('Download logs', () => {
        const logs = getLogForDownload(singletons, GIT_HASH);
        downloadFromMemory("Quip2Wiki.log.txt", logs);
    });
}
function registerDownloadReproductionData(singletons) {
    singletons.tampermonkey.GM_registerMenuCommand('Download regression test data', async () => {
        await exportAndDownloadData(singletons, true, false);
    });
}
function registerGenerateTicketEvidence(singletons) {
    singletons.tampermonkey.GM_registerMenuCommand('Generate ticket evidence', async () => {
        await exportAndDownloadData(singletons, false, true);
    });
}
async function exportAndDownloadData(singletons, forceAllFormats, includeLogs) {
    if (!state.exportFunction)
        throw new Error("Exporting function not defined");
    const data = await startExportProcess(singletons, state.exportFunction, forceAllFormats);
    const dataFileName = "Q2W_Snapshot_" + data.docId + (includeLogs ? '' : ".test") + ".json";
    if (includeLogs)
        data.logs = getStructuredLogs(singletons, GIT_HASH);
    const serializedData = JSON.stringify(data, replacer);
    downloadFromMemory(dataFileName, redactQuipApiToken(singletons, serializedData));
}
function redactQuipApiToken(singletons, s) {
    const token = singletons.settings.quipApiToken;
    if (token != null)
        return s.replaceAll(token, "=|some-fake-quip-api-token-plus-some-padding");
    return s;
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function replacer(key, value) {
    if (key === 'originalResponse')
        return undefined;
    if (key === 'record')
        return undefined;
    return value;
}

function configureErrorSerialization() {
    if (!('toJSON' in Error.prototype))
        Object.defineProperty(Error.prototype, 'toJSON', {
            value: function () {
                if (this.detail)
                    return { message: this.message, detail: this.detail };
                return { message: this.message };
            },
            configurable: true,
            writable: true
        });
}

function setupGeneralCommandsAndConfiguration(singletons) {
    // Setup page-independent commands and configurations
    registerDownloadLogsCommand(singletons);
    registerGenerateTicketEvidence(singletons);
    registerDownloadReproductionData(singletons);
    configureErrorSerialization();
}

async function initialize(singletons) {
    logger.log("[src/init.ts:11:5]", "Started loading Quip2Wiki...");
    setupGeneralCommandsAndConfiguration(singletons);
    // Add general event listeners
    // Add export buttons to the page
    // Add callback that checks if export buttons should be shown or not, when the page address (window.location) changes
    addWindowResizeListener(resizeDialogs);
    addWindowResizeListener(fixExportButton);
    addOrFixExportButtonWithRetry(singletons);
    logger.log("[src/init.ts:21:5]", `Hash: ${GIT_HASH}`);
    // Code URL format: https://code.amazon.com/packages/Quip2Wiki/blobs/49c368e4b36caf5a6daffda92a403214984ce899/--/src/dep.ts?#L3-L4|L3
    // or if we keep using the Quip2Wiki package: https://code.amazon.com/packages/Quip2Wiki/blobs/${hash}/--/src/${path}#L${linePos}|L${linePos}
    addHooksToHistoryAndNavigateApi();
    addLocationChangeCallback((oldPath, newPath) => logger.log("[src/init.ts:26:70]", "Location changed:", {
        oldPath,
        newPath
    }));
    addLocationChangeCallback(() => addOrFixExportButtonWithRetry(singletons));
    await initializeQuip2Wiki(singletons);
    logger.log("[src/init.ts:34:5]", "Finished loading Quip2Wiki");
}

const singletons = buildDefaultSingletonObject();
initialize(singletons).catch(e => {
    logger.warn("[src/main.ts:7:5]", `Failure initializing Quip2Wiki: ${e}`);
    logger.error("[src/main.ts:8:5]", e);
});
