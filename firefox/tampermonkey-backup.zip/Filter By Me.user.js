// ==UserScript==
// @name         Filter By Me
// @version      1.5
// @description  Adds a button to the header on sprint pages to filter by the user that is currently logged in
// @author       spleach@
// @match        https://taskei.amazon.dev/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=amazon.dev
// @grant        none
// @downloadURL  https://code.amazon.com/packages/SpleachGreaseMonkeyScripts/blobs/mainline/--/scripts/src/TaskeiFilterByMe/TaskeiFilterByMe.user.js?raw=1
// @updateURL    https://code.amazon.com/packages/SpleachGreaseMonkeyScripts/blobs/mainline/--/scripts/src/TaskeiFilterByMe/TaskeiFilterByMe.user.js?raw=1
// ==/UserScript==
const PARENT_COMPONENT_SELECTOR = "#header > div > div > header > div"
const BUTTON_GROUP_ID = "filter_by_me_button_container"

const BUTTON_ROW_STYLE = `
  margin-right: 0px;
  margin-left: auto;
  height: 100%;
  overflow-y: auto;
  margin-top: 30px;
  display: flex;
  min-width: fit-content;`
const BUTTON_BASE_STYLE = `
  margin: 0;
  overflow: visible;
  -webkit-appearance: button;
  border-collapse: separate;
  border-spacing: 0;
  caption-side: top;
  direction: ltr;
  empty-cells: show;
  font-style: normal;
  font-feature-settings: normal;
  font-variant: normal;
  font-stretch: normal;
  hyphens: none;
  list-style: disc none outside;
  tab-size: 8;
  text-align: left;
  text-align-last: auto;
  text-indent: 0;
  text-shadow: none;
  text-transform: none;
  visibility: visible;
  white-space: normal;
  widows: 2;
  word-spacing: normal;
  box-sizing: border-box;
  font-family: "Amazon Ember","Helvetica Neue",Roboto,Arial,sans-serif;
  min-width: fit-content;
  max-height: 25px;
  word-break: break-word;
  font-weight: 900;
  -webkit-font-smoothing: antialiased;
  letter-spacing: 0.005em;
  border-radius: 20px;
  border: 2px solid;
  display: inline-block;
  cursor: pointer;
  background: #0f1b2a;
  color: #539fe5;
  border-color: #539fe5;
  position: relative;
  text-decoration: none;
  margin-right: 10px;
  font-size: 11px;
  line-height: 11px;
  padding: 4px 10px;`


function scriptIsRunning() {
  return !!document.querySelector(BUTTON_GROUP_ID);
}

/**
 * Creates the container div to hold the buttons.
 * The btn-group class applies rounded corners to the outside buttons.
 */
async function createButtonRow() {
  const parent = document.querySelector(PARENT_COMPONENT_SELECTOR)
  const itemAfterNewRow = parent.children[parent.children.length - 1]
  const buttonRow = document.createElement("div")
  buttonRow.id = BUTTON_GROUP_ID
  buttonRow.style = BUTTON_ROW_STYLE
  itemAfterNewRow.insertAdjacentElement("beforebegin", buttonRow)
}

async function deleteButtonRow() {
  document.getElementById(BUTTON_GROUP_ID).remove();
}

function create_and_append_button(text, event_listener, hint){
  const parent = document.getElementById(BUTTON_GROUP_ID)
  const button = document.createElement("button")
  const text_node = document.createTextNode(" " + text)
  button.style = BUTTON_BASE_STYLE
  button.addEventListener("click", event_listener)
  button.title = hint
  while (parent.firstChild) {
    parent.removeChild(parent.lastChild)
  }
  parent.append(button)
  button.append(text_node)
}


async function getSignedInUsername() {
  // This while-true loop acts as a bad "retry" mechanism
  while (true) {
    try {
      return (await (await fetch("https://global.prod.api.taskei.amazon.dev/graphql", {
        "headers": {
          "accept": "*/*",
          "accept-language": "en-US,en;q=0.9",
          "content-type": "application/json",
          "sec-fetch-dest": "empty",
          "sec-fetch-mode": "cors",
          "sec-fetch-site": "same-site",
          "x-amzn-requestid": "HffJG9m3OCyL1nlStmQQT"
        },
        "referrer": "https://taskei.amazon.dev/",
        "referrerPolicy": "strict-origin-when-cross-origin",
        "body": "{\"operationName\":\"CurrentUser\",\"variables\":{},\"query\":\"query CurrentUser {\\n  getCurrentUser {\\n    id\\n    name\\n    username\\n    __typename\\n  }\\n}\"}",
        "method": "POST",
        "mode": "cors",
        "credentials": "include"
      })).json()).data.getCurrentUser.username
    } catch {}
  }
}

function filterByUser(username) {
  const [base_url, ignored] = window.location.href.split("?")
  const urlParams = new URLSearchParams(window.location.search)
  const mode = urlParams.get('d') || "board"
  window.location.href = base_url + `?f=assignee%3A${username}&d=${mode}`
}

async function main() {
  const rowPromise = createButtonRow()
  const usernamePromise = getSignedInUsername()
  await rowPromise
  const username = await usernamePromise
  create_and_append_button(`Filter by: ${username}`, () => {filterByUser(username)}, "Filter by you!")
}

(async function() {
  const observer = new MutationObserver(async () => {
    if (document.querySelector(PARENT_COMPONENT_SELECTOR) &&
      !document.getElementById(BUTTON_GROUP_ID)) {
      const isOnPage = (
        window.location.href.search('.*\/sprints\/.+') !== -1 ||
        window.location.href.search('.*\/kanbanBoards\/.+') !== -1 ||
        window.location.href.search('.*\/rooms\/.*\/tasks.*') !== -1
      )
      if (isOnPage && !scriptIsRunning()) {
        await main()
      } else if (!isOnPage) {
        await deleteButtonRow()
      }
    }
  })

  observer.observe(document.body, {
    childList: true,
    subtree: true
  })
})()