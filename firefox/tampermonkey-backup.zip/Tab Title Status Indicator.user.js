// ==UserScript==
// @name         Tab Title Status Indicator
// @namespace    https://w.amazon.com/bin/view/Users/eboring/Tampermonkey/
// @version      1.35
// @description  Adds a colored emoji to the tab title for SIM T to show what status a ticket is in. Also appends the ticket's ID to the title. If you have the SIM Escalation Indicators script installed, this script will also show an ebbreviated escalation time in the tab title.
// @author       eboring
// @downloadURL  https://code.amazon.com/packages/EboringTampermonkeyScripts/blobs/mainline/--/scripts/tab_title_status_indicator.user.js?download=1
// @updateURL    https://code.amazon.com/packages/EboringTampermonkeyScripts/blobs/mainline/--/scripts/tab_title_status_indicator.user.js?download=1

// @include      https://t.corp.amazon.com*
// @include      https://issues.amazon.com*
// @include      https://i.amazon.com*
// @include      https://sim.amazon.com*
// @include      https://taskei.amazon.dev*

// @include      https://t.lck.aws-border.com*
// @include      https://issues.lck.amazon.com*
// @include      https://i.lck.amazon.com*
// @include      https://sim.lck.amazon.com*

// @include      https://t.dca.c2s-border.ic.gov*
// @include      https://issues.dca.c2s-border.ic.gov*
// @include      https://i.dca.c2s-border.ic.gov*
// @include      https://sim.dca.c2s-border.ic.gov*

// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// @grant        GM_addStyle
// ==/UserScript==

(function() {
    'use strict';
    
    var clipboardImg = '<img src="https://drive-render.corp.amazon.com/view/eboring@/public/img/clipboard.png" class="emoji" alt="📋" aria-label="clipboard emoji" data-stringify-emoji=":clipboard:" data-stringify-type="emoji" style="box-sizing:inherit; object-fit:contain; overflow:hidden;">';

    // https://www.w3schools.com/css/css_tooltip.asp
    var style = `
/* Tooltip container */
.TabTitleCopyMenu {
  position: relative;
  display: inline-block;
}

/* Tooltip text */
.TabTitleCopyMenu .TabTitleCopyPopup {
  visibility: hidden;
  min-width: max-content;
  top: 100%;
  left: 50%;
  margin-left: -50%;
  background-color: black;
  color: #fff;
  text-align: left;
  padding: 5px;
  border-radius: 6px;
  font-size: larger;
 
  /* Position the tooltip text - see examples below! */
  position: absolute;
  z-index: 1;
}

.TabTitleCopyMenu .TabTitleCopyPopup div{
    background-color: black !important;
    font-size: medium;
}

.TabTitleCopyMenu .TabTitleCopyPopup .a, .TabTitleCopyMenu .emoji{
    height: 1.5em !important;
    padding: 3px;
}

.TabTitleCopyMenu .TabTitleCopyPopup .a:hover{
    background-color: #404040;
}

/* Show the tooltip text when you mouse over the tooltip container */
.TabTitleCopyMenu:hover .TabTitleCopyPopup {
  visibility: visible;
}
`

    var misses = 0;
    const MAX_MISSES = 500;
    const TICK_MILLISECONDS = 2000

    var ticksSinceLastMaxisQuery = 0;
    var waitBetweenMaxisQueries = 2;
    var simTicket;
    var simId;
    
    var escalationTimeAbbr = "";

    var statusEmoji = "⚫";
    
    function tick(){
        var simTitle = undefined;
        var simTitleText = undefined;
        var simStatus = undefined;
        var flagContainer = document.getElementById("tab-title-status-indicator-flag");
        if(window.location.toString().startsWith("https://t.")){
            simTitle = document.getElementById("sim-title");
            if(simTitle){
                simTitleText = simTitle.firstChild.textContent;
                simStatus = document.querySelector("div.issue-summary-status dd.info-value");
                if(simStatus){
                    simStatus = simStatus.textContent;
                }
                var header = document.querySelector("div.awsui-util-container-header");
                if(!flagContainer && header){
                    flagContainer = document.createElement("div");
                    flagContainer.id = "tab-title-status-indicator-flag";
                    header.appendChild(flagContainer);
                }
                let ticketSummaryLabel = document.querySelector("div.issue-detail-side .sim-simpleBox--subHeaderText");;
                if(ticketSummaryLabel && !ticketSummaryLabel.querySelector(".TabTitleCopyMenu")){
                    let copyMenuContainer = document.createElement("span");
                    ticketSummaryLabel.insertBefore(copyMenuContainer, ticketSummaryLabel.firstChild);
                    createCopyMenu(copyMenuContainer);
                }
            }
        }
        else if(window.location.toString().startsWith("https://sim.") || 
        window.location.toString().startsWith("https://issues.") ||
        window.location.toString().startsWith("https://i.") ){
            simTitle = document.querySelector("span[data-link='html{>document^title}']");
            simTitleText = simTitle.firstChild.textContent;
            simStatus = document.querySelector("span.editable-status-field");
            if(simStatus){
                simStatus = simStatus.textContent.trim().toLocaleLowerCase().replace("status: ", "");
            }
            var header = document.querySelector("div.document-details-bar");
            if(!flagContainer && header){
                flagContainer = document.createElement("div");
                flagContainer.id = "tab-title-status-indicator-flag";
                header.appendChild(flagContainer);
            }
            let appNav = document.getElementById("application-nav");
            if(appNav){
                if(!appNav.querySelector(".tab-title-status-indicator-title")){
                    let titleP = document.createElement("p");
                    titleP.classList.add("tab-title-status-indicator-title");
                    titleP.style.paddingTop = "0.65em";
                    titleP.style.display = "inline-block";
                    titleP.style.color = "white";
                    appNav.appendChild(titleP);
                }
                if(!appNav.querySelector(".TabTitleCopyMenu")){
                    createCopyMenu(appNav);
                }
            }
        }
        else if(window.location.toString().startsWith("https://taskei.")){
            // Taskei is a React app, which means the UI doesn't have nice CSS selectors I can use.
            // Have to rely on the API. Probably should update SIM-C and SIM-T to do the same.
            let queryParams = new URLSearchParams(window.location.search);
            if(window.location.pathname.startsWith("/rooms/" && queryParams.has("task"))){
                simId = queryParams.get("task");
            }
            else if(window.location.pathname.startsWith("/tasks/")){
                simId = window.location.pathname.replace("/tasks/", "");
                if(simId.includes("/")){
                    simId = simId.substring(0, simId.indexOf("/"));
                }
                if(simId.includes("?")){
                    simId = simId.substring(0, simId.indexOf("?"));
                }
            }
            ticksSinceLastMaxisQuery++;
            if(ticksSinceLastMaxisQuery >= waitBetweenMaxisQueries){
                queryMaxisForTicketInformation(simId);
            }
            if(simTicket){
                simTitleText = simTicket.title;
                simId = simTicket.aliases ? simTicket.aliases[simTicket.aliases.length-1].id : simTicket.id;
                simStatus = simTicket.status;
                let relatedTasksCountSpan = document.getElementById("related-tasks-count");
                if(!relatedTasksCountSpan){
                    let relatedTasksTab = document.querySelector("button[id$='-related-tasks']");
                    relatedTasksCountSpan = document.createElement("span");
                    relatedTasksCountSpan.id = "related-tasks-count";
                    relatedTasksTab.firstChild.appendChild(relatedTasksCountSpan);
                }
                relatedTasksCountSpan.textContent = ` (${simTicket.parentTasks.length}P/${simTicket.subtasks.length}S)`;
            }
            // let actionsPanel = document.querySelector("div[class^='task-header-sections_headerActions']");
            let actionsPanel = document.querySelector("div.awsui-context-top-navigation header div:nth-child(2)");
            if(actionsPanel){
                if(!actionsPanel.querySelector(".TabTitleCopyMenu")){
                    let copyMenuSpan = document.createElement("span");
                    copyMenuSpan.style.paddingTop = "0.8em";
                    actionsPanel.insertBefore(copyMenuSpan, actionsPanel.firstChild);
                    createCopyMenu(copyMenuSpan);
                }
            }
            
        }
        // if(flagContainer && flagContainer.childElementCount == 0){
        //     flagContainer.style.padding = "7px";
        //     flagContainer.style.paddingLeft = "10px";
        //     var checkbox = document.createElement("input");
        //     checkbox.setAttribute("type", "checkbox");
        //     checkbox.id = "tab-title-status-indicator-flag-checkbox";
        //     checkbox.style.margin = "0";
        //     flagContainer.appendChild(checkbox);
        //     var label = document.createElement("label");
        //     label.setAttribute("for", "tab-title-status-indicator-flag-checkbox");
        //     label.textContent = "Flag this issue";
        //     label.title = "Temporarily flag this issue in your browser tabs. This will be cleared if the page reloads or you close the tab. Also this flag is only visible to you.";
        //     label.style.paddingLeft = "5px";
        //     label.style.fontSize = "0.8em";
        //     label.style.display = "inline";
        //     flagContainer.appendChild(label);
        // }

        if(simTitleText && simTitleText.length > 0 && simStatus && simStatus.length > 0){
            switch(simStatus.toLowerCase().trim()){
                case "assigned":
                    statusEmoji = "🔴";
                    break;
                case "open":
                case "researching":
                case "work in progress":
                    statusEmoji = "🟠";
                    break;
                case "pending":
                    statusEmoji = "🟡";
                    break;
                case "resolved":
                case "closed":
                    statusEmoji = "🟢";
                    break;
            }
            
            var escalationTimeDd = document.querySelector("div.issue-summary-escalation dd.info-value");
            if(escalationTimeDd){
                let escalationTime = escalationTimeDd.textContent.trim();
                if(escalationTime == "Does not escalate"){
                    escalationTimeAbbr = "";
                }
                else if(escalationTime.startsWith("-")){
                    escalationTimeAbbr = "🚨";
                }
                else{
                    let escalationTimeMatches = escalationTime.match(/^(\d+d) (\d+h) (\d+m) (\d+s)/);
                    if(escalationTimeMatches){
                        if(escalationTimeMatches[1] != "0d"){
                            escalationTimeAbbr = `(${escalationTimeMatches[1]})`;
                        }
                        else if(escalationTimeMatches[2] != "0h"){
                            escalationTimeAbbr = `(${escalationTimeMatches[2]})`;
                        }
                        else if(escalationTimeMatches[3] != "0m"){
                            escalationTimeAbbr = `(${escalationTimeMatches[3]})`;
                        }
                        else if(escalationTimeMatches[4] != "0s"){
                            escalationTimeAbbr = `(${escalationTimeMatches[4]})`;
                        }
                        else{
                            escalationTimeAbbr = "🚨";
                        }
                    }
                }
                // if(escalationTimeAbbr && escalationTimeAbbr.length > 0){
                //     statusEmoji += escalationTimeAbbr;
                // }
            }

            var blockedReasonDiv = document.querySelector(".blocked-reason");
            if(blockedReasonDiv){
                if(blockedReasonDiv.textContent.trim().length > 0){
                    statusEmoji = "🚫";
                }
            }
            
            // var flagCheckbox = document.getElementById("tab-title-status-indicator-flag-checkbox");
            var flag = "";
            // if(flagCheckbox){
            //     flag = flagCheckbox.checked ? "🚩" : "";
            // }
            if(!simId){
                simId = window.location.toString().match(/(sim|issues|i|t\.corp)\.(amazon\.com|lck\.amazon\.com|dca\.c2s-border\.ic\.gov)(\/issues)?\/([\w-]+)/);
                simId = simId ? `${simId[4]}` : "";
            }
            // Use firstChild to get the text node of the title. If the user has the SIM Ticketing Monitors TM script installed, that
            // script adds the monitor's status to the title node, so simTitle.textContent would have the monitor status appended to it
            // and we would get something like "AWSCM-EUW2.HostManager.CloudWatchIssuesALERT" instead of 
            // "AWSCM-EUW2.HostManager.CloudWatchIssues"
            let title = `${statusEmoji}${flag}${escalationTimeAbbr} ${simTitleText} (${simId})`;
            let miniTitle = `${statusEmoji}${flag}(${simId})`;
            document.title = title;
            let description = "";
            let simUuid = simTicket ? simTicket.id : "";
            if(window.location.toString().startsWith("https://sim.") || 
            window.location.toString().startsWith("https://issues.") ||
            window.location.toString().startsWith("https://i.") ){
                description = document.querySelector("#issue-description-container div form div").textContent.trim();
                description = description.substring(description.indexOf("\n")).trim();
                let simUuidA = document.querySelector("div.document-ids-container a.navigation-link[data-name='long-issue-id']");
                simUuid = simUuidA.href.substring(simUuidA.href.lastIndexOf("/")+1);
            }
            else{
                let simUuidSpan = document.querySelector(".ticket-id");
                if(simUuidSpan && simUuidSpan.hasAttribute("data-id")){
                    simUuid = simUuidSpan.getAttribute("data-id");
                }
            }
            let simTitleHtmlEntities = simTitleText.trim().replaceAll("[", "&lbrack;").replaceAll("]", "&rbrack;").replaceAll('"', "&quot;").replaceAll("'", "&apos;");
            let simTitleCleaned = simTitleText.trim().replaceAll("[", "(").replaceAll("]", ")").replaceAll('"', '\"').replaceAll("'", "\'");
            simTitleCleaned = simTitleCleaned.replaceAll(/ ?-? ?(\+1 )?\d{3}-\d{3}-\d{4}/g, "");
            let slackChannelName = makeSlackChannelName(`${simId}-${simTitleText}`);
            document.querySelectorAll(".tab-title-status-indicator-title").forEach(elem => {
                elem.textContent = window.scrollY > 105 ? title : miniTitle;
                elem.title = `${title}\n\n${description}`;
            });
            document.querySelectorAll(".TabTitleCopyId").forEach(elem => {
                elem.href = `javascript:navigator.clipboard.writeText("${simId}")`;
            });
            document.querySelectorAll(".TabTitleCopyUuid").forEach(elem => {
                elem.href = `javascript:navigator.clipboard.writeText("${simUuid}")`;
            });
            document.querySelectorAll(".TabTitleCopyUrl").forEach(elem => {
                elem.href = `javascript:navigator.clipboard.writeText("${window.location.toString()}")`;
            });
            document.querySelectorAll(".TabTitleCopyTitle").forEach(elem => {
                elem.href = `javascript:navigator.clipboard.writeText("${simTitleText}")`;
            });
            document.querySelectorAll(".TabTitleCopySlackChannelName").forEach(elem => {
                elem.href = `javascript:navigator.clipboard.writeText("${slackChannelName}")`;
            });
            document.querySelectorAll(".TabTitleCopyMd").forEach(elem => {
                elem.href = `javascript:navigator.clipboard.writeText("[${simTitleCleaned}](${window.location.toString()})")`;
            });
            document.querySelectorAll(".TabTitleCopyMdBadge").forEach(elem => {
                let badgeUrl = `https://badges.corp.amazon.com/remedy_status/${simId}.svg?label=${encodeURIComponent(simTitleCleaned)}`;
                elem.href = `javascript:navigator.clipboard.writeText("[![${simId}](${badgeUrl})](${window.location.toString()})")`;
            });
            document.querySelectorAll(".TabTitleCopyHtml").forEach(elem => {
                elem.href = `javascript:navigator.clipboard.writeText("<a href='${window.location.toString()}'>${simTitleText}</a>")`;
                // elem.href = "#";
                // elem.setAttribute("link", `<a href='${window.location.toString()}'>${simTitleText}</a>`);
                // elem.addEventListener("click", function(evt){
                //     GM_setClipboard(evt.target.getAttribute("link"), "html");
                // });
            });
            misses = 0;
        }
        else{
            misses++;
            if(misses > MAX_MISSES){
                clearInterval(timer);
            }
        }
    }

    function queryMaxisForTicketInformation(simId){
        if(simId){
            var maxisUrl = `https://maxis-service-prod-pdx.amazon.com/issues/${simId}`;
            GM_xmlhttpRequest({
                method: 'GET',
                url: maxisUrl,
                onload: function (response) {
                    if (response.readyState == 4 && this.status == 200) {
                        simTicket = JSON.parse(response.responseText);
                        console.log(`Tab Title Status Indicators: Maxis query succeeded for: ${simId} - ${simTicket.title}`);
                    }
                    else if(this.status >= 400 && this.status < 600){ // If we hit throttling or errors, we'll slowly back off;
                        console.log(`Tab Title Status Indicators: Maxis query failed: ${maxisUrl}\n${this.status}: ${response.responseText}`)
                        waitBetweenMaxisQueries++;
                    }
                }
            }); 
        }
        else{
            simTicket = undefined;
        }
        ticksSinceLastMaxisQuery = 0;
    }

    /* Slack channel name rules:
    *  - Max length: 80 characters
    *  - No spaces, periods, or special characters
    *  - No uppercase letters
    */
    function makeSlackChannelName(name){
        name = name.replaceAll(/[\[\]\(\)\{\}]/g, "");
        name = name.replaceAll(/[\.\,\:\\\/=+!@#\$%\^&\*]/g, "_");
        name = name.replaceAll(" ", "-");
        name = name.substring(0, 80);
        return name.toLowerCase();
    }

    function createCopyMenu(menuContainer){
        let copyMenuSpan = document.createElement("span");
        copyMenuSpan.innerHTML = clipboardImg;
        copyMenuSpan.classList.add("TabTitleCopyMenu");
        let popup = document.createElement("span");
        popup.classList.add("TabTitleCopyPopup");
        copyMenuSpan.appendChild(popup);
        menuContainer.appendChild(copyMenuSpan);

        let aCopyId = document.createElement("a");
        aCopyId.classList.add("TabTitleCopyId");
        aCopyId.textContent = "Copy ID";
        popup.appendChild(aCopyId);
        popup.appendChild(document.createElement("br"));

        let aCopyUuid = document.createElement("a");
        aCopyUuid.classList.add("TabTitleCopyUuid");
        aCopyUuid.textContent = "Copy UUID";
        popup.appendChild(aCopyUuid);
        popup.appendChild(document.createElement("br"));

        let aCopyUrl = document.createElement("a");
        aCopyUrl.classList.add("TabTitleCopyUrl");
        aCopyUrl.textContent = "Copy URL";
        popup.appendChild(aCopyUrl);
        popup.appendChild(document.createElement("br"));

        let aCopyTitle = document.createElement("a");
        aCopyTitle.classList.add("TabTitleCopyTitle");
        aCopyTitle.textContent = "Copy Title";
        popup.appendChild(aCopyTitle);
        popup.appendChild(document.createElement("br"));

        let aCopySlackChannel = document.createElement("a");
        aCopySlackChannel.classList.add("TabTitleCopySlackChannelName");
        aCopySlackChannel.textContent = "Copy Slack Channel Name";
        popup.appendChild(aCopySlackChannel);
        popup.appendChild(document.createElement("br"));

        let aCopyMd = document.createElement("a");
        aCopyMd.classList.add("TabTitleCopyMd");
        aCopyMd.textContent = "Copy Markdown Link";
        aCopyMd.title = "Pasting into Slack? After you paste, press Ctrl+Shift+F to turn this into a real link.\nNote that the ticket title is cleaned up a bit so avoid markdown parsing errors.";
        popup.appendChild(aCopyMd);
        popup.appendChild(document.createElement("br"));

        let aCopyMdBadge = document.createElement("a");
        aCopyMdBadge.classList.add("TabTitleCopyMdBadge");
        aCopyMdBadge.textContent = "Copy Markdown Badge";
        popup.appendChild(aCopyMdBadge);
        popup.appendChild(document.createElement("br"));

        let aCopyHtml = document.createElement("a");
        aCopyHtml.classList.add("TabTitleCopyHtml");
        aCopyHtml.textContent = "Copy HTML Link";
        popup.appendChild(aCopyHtml);
        popup.appendChild(document.createElement("br"));
    }

    GM_addStyle(style);

    var timer = setInterval(tick, TICK_MILLISECONDS);
})();