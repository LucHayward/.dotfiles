// ==UserScript==
// @name         Get Workflow
// @namespace    http://tampermonkey.net/
// @version      2024-01-03
// @description  try to take over the world!
// @author       damgene(luchay)
// @include      /^https:\/\/foundry-[^\/]+(-[^\/]+)*\.aka\.amazon\.com\/(workflows\/|services\/[^\/]+\/service_workflow\/)/
// @icon         https://www.google.com/s2/favicons?sz=64&domain=amazon.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to fetch JSON data from the constructed API URL
    function fetchData() {
        var apiUrl = window.location.href + '.json';

        return fetch(apiUrl)
            .then(response => response.json())
            .catch(error => {
                console.error('Error fetching data:', error);
                return null;
            });
    }

    // Function to create a button and copy information to clipboard
    function addCopyButton() {
        fetchData().then(data => {
            // Check if the data was successfully fetched
            if (!data) {
                console.log('Data not available.');
                return;
            }
            console.log(data.executionInfos.execution);


            // Extract the information from the JSON data
            var workflowId = data.executionInfos.execution.workflowId
            var runId = data.executionInfos.execution.runId
            var domain = 'prod'
            var region = window.location.href.match(/-(\w+)/)[1];
            console.log(region)
            if (region == 'alpha') {
                region = 'dev1'
                domain = 'alpha'
            }

            var information =`OPSHOST=$(expand-hostclass AWS-FOUNDRY-OPS-CORP | tail -1) && ssh -t $OPSHOST "sudo -u foundry-ops-ro env PATH=/apollo/env/FoundryOpsCli/bin:/apollo/env/FoundryOps/bin:/apollo/env/FoundryServiceCopy/bin:\$PATH bash -c 'mkdir -p /local/tmp/luchay && chmod g+w /local/tmp/luchay && cd /local/tmp/luchay && mkdir -p /tmp/replays && rm -f /tmp/replays/replay.json && workflow-status --domain=alpha --realm=dev1 --list-closed -r\"RUNID" -w\"WORKFLOWID\" --display-execution --json | jq | tee /tmp/replays/replay.json'" && scp luchay@$OPSHOST:/tmp/replays/replay.json ~/workplace/FoundryWorkflows/src/FoundryWorkflows/test/test_data/executions/`

            // Check if the information exists
            if (!information) {
                console.log('Information not found in the JSON data.');
                return;
            }

            // Create a button
            var workflowDiv = document.querySelector('.workflow');

            // Create a button with an icon
            var button = document.createElement('button');
            button.className = 'workflow-status';
            button.style.position = 'absolute';
            button.style.top = '3px';
            button.style.right = '3px';
            button.style.zIndex = '9999';

            // Add click event listener to the button
            button.addEventListener('click', function() {
                var textarea = document.createElement('textarea');
                textarea.value = information;

                document.body.appendChild(textarea);

                textarea.select();
                document.execCommand('copy');

                document.body.removeChild(textarea);

                console.log('Information copied to clipboard:', information);
            });

            var icon = document.createElement('i');
            icon.className = 'fa fa-copy';
            button.appendChild(icon);

            workflowDiv.querySelector('.info').appendChild(button);
        });
    }

    //window.addEventListener('load', addCopyButton);
    //document.addEventListener('DOMContentLoaded', addCopyButton);
    addCopyButton()
})();