// ==UserScript==
// @namespace    https://w?User:Saukum
// @author       saukum
// @name         Phonetool:ResolverGroup
// @namespace    http://tampermonkey.net/
// @version      1
// @description  Show resolver group on phonetool.amazon.com
// @match        https://phonetool.amazon.com/users/*
// @run-at       document-end
// @grant        GM_xmlhttpRequest
// @grant        GM.xmlHttpRequest
// @grant        unsafeWindow
// @connect      cti.amazon.com
// @updateURL    https://drive.corp.amazon.com/view/Lewis-Transformers/Greasemonkey/phonetool-resolver-group.user.js?download=true
// @downloadURL  https://drive.corp.amazon.com/view/Lewis-Transformers/Greasemonkey/phonetool-resolver-group.user.js?download=true
// ==/UserScript==

(function() {
    'use strict';

    var DEBUG_ENABLED = false;
    if (unsafeWindow.PhoneTool && unsafeWindow.PhoneTool.targetUserLogin) {
        var currentUser = unsafeWindow.PhoneTool.targetUserLogin;
        ctiGroupsByUser(currentUser).then(function(resolverGroups) {
            domAddResolverGroupToPhonetool(resolverGroups);
        }).catch(throwError);
    }

    function domAddResolverGroupToPhonetool(resolverGroups) {
        var resolverGroupsText = "";
        for(var resolverGroup of resolverGroups) {
            if (resolverGroupsText != "") {
                 resolverGroupsText += ", ";
            }
            resolverGroupsText += "<a href='https://cti.amazon.com/group/" + resolverGroup +"'>" + resolverGroup + "</a>";
		}

        // Create resolver group label node
        var labelNode = domCreate('div', 'TableProperty', {textContent: 'Resolver Groups:'});
        // Create resolver group value node
        var valueNode = domCreate('h5', '', {innerHTML:resolverGroupsText});

        // Create table row for putting above nodes
        var resolverRow = domCreate('div', 'TableRow ResolverGroup');
        resolverRow.appendChild(labelNode);
        resolverRow.appendChild(valueNode);

        // Create a span for fitting the above table row
        var resolverWrapper = domCreate('span', 'optional-wrapper');
        resolverWrapper.appendChild(resolverRow);

        // Add the table in the UserDetailsTable of the PhoneTool Page (Check Page source)
        var userDetailsTable = document.querySelector('.UserDetailsTable');
        userDetailsTable.appendChild(resolverWrapper);
    }

    function domCreate(tag, classes, attributes) {
        var node = document.createElement(tag);
        if (attributes) {
            Object.assign(node, attributes);
        }
        if (typeof(classes) === 'string') {
            classes = classes.replace(/^\s*|\s*$/g, '').split(/\s+/g);
        }
        if (classes instanceof Array) {
            classes.forEach(function(clazz) {
                if (clazz !== '') {
                    node.classList.add(clazz);
                }
            });
        }
        return node;
    }

    function ctiGroupsByUser(username) {
        return getJson('https://cti.amazon.com/user/' + username + '/groups');
    }

    function getJson(url) {
        return new Promise(function(resolve, reject) {
            GM.xmlHttpRequest({
                method: 'GET',
                url: url,
                headers: { 'Accept': 'application/json' },
                onload: function (response) {
                    var result = JSON.parse(response.responseText);
                    resolve(result);
                },
                onerror: function (response) {
                    console.log("Error ", response);
                    reject(response.statusText);
                }
            });
        });
    }

    function throwError(msg) {
        console.log('[Phonetool Resolver Group] [ERROR]', msg);
        // JQuery toast
        $.toast('<small><u>Error from Phonetool Resolver Group:</u></small><br/>' + msg, {type:'error'});
        throw Error(msg);
    }

})();