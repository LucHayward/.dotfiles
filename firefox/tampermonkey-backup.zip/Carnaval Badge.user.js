// ==UserScript==
// @name         Carnaval Badge
// @namespace    http://amazon.com/
// @version      0.1
// @description  Display carnaval badges besides links
// @author       Renato Besen
// @include        http*://*.amazon.*/*
// @include        http*://*.amazon.*:*/*
// @include        http*://*.aws-border.*/*
// @include        https://*.amazonaws-us-gov.com/*
// @include        https://*.amazonaws.cn/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var carnavalRegex = new RegExp('carnaval.amazon.com/v1/viewObject.do');

    function create(htmlStr) {
        var frag = document.createDocumentFragment(),
            temp = document.createElement('div');
        temp.innerHTML = htmlStr;
        while (temp.firstChild) {
            frag.appendChild(temp.firstChild);
        }
        return frag;
    }

    function updateHTML() {
        // Clean-up existing images; Removing in reverse order because the other way doesn't seem to work very well (element order gets messed up? who knows)
        var existingImages = document.getElementsByClassName('carnaval__badge');
        for (var i = existingImages.length - 1; i >= 0; i--) {
            existingImages[i].remove();
        }

        // Parse links and add badge
        for (var l of document.links) {
            if (!l.href.match(carnavalRegex)) {
                continue;
            }
            var href = new URL(l.href);
            // Badges only supports monitors (i.e. no agents)
            if (href.searchParams.get("type") !== "monitor") {
                continue;
            }
            var monitorName = href.searchParams.get("name");
            l.appendChild(create("<img class='carnaval__badge' src='https://badges.corp.amazon.com/carnaval/" + monitorName + ".svg'/>"));
        }
    }

    // Initial pass
    updateHTML();
    // Refresh every 5 seconds.
    window.setInterval(updateHTML, 5000);
})();

