// ==UserScript==
// @name         Display Unpublished Reviews in CRUX
// @namespace    https://code.amazon.com/reviews
// @version      1.2
// @description  Displays unpublished code reviews in CRUX
// @author       Andrew DeFilippis (defila@)
// @match        https://code.amazon.com/r*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=amazon.com
// @grant        none
// @downloadURL  https://code.amazon.com/packages/AWSLogsGreasemonkey/blobs/mainline/--/scripts/display-unpublished-reviews-in-crux.user.js?download=1#.user.js
// @updateURL    https://code.amazon.com/packages/AWSLogsGreasemonkey/blobs/mainline/--/scripts/display-unpublished-reviews-in-crux.user.js?download=1#.user.js
// ==/UserScript==

(function() {
    'use strict';

    function reloadPage() {
        // When an unpublished review URL ends with the CR ID, a redirect is required.
        const cr_re = /CR-\d*(?:\/)?$/;
        const error_re = /No\ review\ exists\ with\ an\ id/;
        const suffix = 'revisions/1#/diff';
        // CRUX will auto-expand https://code.amazon.com/r/... to https://code.amazon.com/reviews/
        const short_review = /\/r\/CR-/;

        if (document.URL.match(cr_re) && document.querySelector('#alert-msg-banner').innerHTML.match(error_re)) {
            const url_expanded = document.URL.replace(short_review, '/reviews/CR-')
            if (document.URL.endsWith('/')) {
                window.location = url_expanded + suffix
            } else {
                window.location = url_expanded + '/' + suffix
            }
        }
    }

    function letMeSeeIt() {
        reloadPage()

        const observer = new MutationObserver(mutations => {
            if (document.querySelector('#pending-review-non-author-alert')) {
                document.getElementById('pending-review-non-author-alert').remove()
            }
        })

        observer.observe(document.querySelector('.ng-scope'), {
            childList: true,
            subtree: true
        })
    }

    letMeSeeIt()
})();

