// ==UserScript==
// @name         CR Image Attach
// @namespace    https://oneijaso.aka.corp.amazon.com
// @version      2.22
// @description  Easily attach images to a CR without needing to host them externally
// @author       Blake Stephens - stepblk@, Victor Pineda - vgonzla@, Originally written by Jason O'Neill - oneijaso@
// @match        https://code.amazon.com/reviews/CR-*
// @updateURL    https://code.amazon.com/packages/Oneijaso-userscripts/blobs/mainline/--/src/crImageAttach.user.js?download=1#.user.js
// @downloadURL  https://code.amazon.com/packages/Oneijaso-userscripts/blobs/mainline/--/src/crImageAttach.user.js?download=1#.user.js
// @grant        GM_addStyle
// @grant        GM_getValue
// @grant        GM_info
// @grant        GM_registerMenuCommand
// @grant        GM_setValue
// @grant        GM_unregisterMenuCommand
// @grant        GM_xmlhttpRequest
// @grant        GM.addStyle
// @grant        GM.getValue
// @grant        GM.info
// @grant        GM.registerMenuCommand
// @grant        GM.setValue
// @grant        GM.unregisterMenuCommand
// @grant        GM.xmlhttpRequest
// @connect      fd2ovzypf8.execute-api.us-east-1.amazonaws.com
// @require      https://code.amazon.com/packages/Oneijaso-userscripts/blobs/mainline/--/src/lib/gmCompat.js?download=1&v=2
// @require      https://code.amazon.com/packages/Oneijaso-userscripts/blobs/mainline/--/src/lib/logger.js?download=1&v=2
// ==/UserScript==

(async function () {
    "use strict";

    const getClassName = name => `${GM.info.script.name.replace(/\s/g, "-")}_${name}`;

    await GM.addStyle(`
/* ${GM.info.script.name} Styles */

.${getClassName("drop-zone")} {
    border: 1px solid rgba(0, 0, 0, 0.5);
    border-radius: 2px;
    color: #333;
    padding: 0.5em;
    margin: 0.25em 0 2em;
    line-height: 2em;
    position: relative;
    background-image: repeating-linear-gradient(-45deg, rgb(0 0 0 / 5%), rgb(0 0 0 / 5%) 8px, transparent 8px, transparent 16px);
    height: 60px;
}
.${getClassName("drop-zone")}.over {
    box-shadow: 0 0 3px 1px inset rgba(0, 0, 0, 0.5);
}
.${getClassName("drop-zone")}.fail {
    box-shadow: 0px 0px 0px 3px inset rgba(200, 0, 0, 0.8);
    color: rgb(200, 0, 0);
}
.${getClassName("drop-zone")}.success {
    box-shadow: 0px 0px 0px 3px inset rgba(0, 168, 0, 0.8);
    color: rgb(0, 168, 0);
}

.${getClassName("drop-zone")} .${getClassName("drop-zone-message")} {
    text-align: center;
}
.${getClassName("drop-zone")} .${getClassName("drop-zone-message")}.failure {
    color: red;
}

.${getClassName("drop-zone")} .${getClassName("drop-zone-allotment")} {
    color: #666;
    font-size: 0.9em;
    text-align: right;
    line-height: 1.5em;
    position: absolute;
    top: 100%;
    right: 0;
}

.${getClassName("drop-zone")} .${getClassName("drop-zone-options-button")} {
    font-size: 0.9em;
    text-align: right;
    line-height: 1.5em;
    float: right;
}

.${getClassName("options-pane")} {
    border: 1px solid rgb(181 181 181);
    box-shadow: rgb(0 0 0 / 25%) 0px 6px 8px 2px;
    border-radius: 4px;
    color: rgb(51, 51, 51);
    padding: 1em;
    margin: 7.25em 24px 2em;
    line-height: 2em;
    top: 0px;
    right: 0px;
    position: fixed;
    background-color: white;
    z-index: 1;
    opacity: 1;
    transform: translateY(0);
    transition: opacity 150ms ease-in-out, transform 150ms ease-out;
    will-change: opacity, transform;
}
.${getClassName("options-pane")}.hidden {
    opacity: 0;
    transform: translateY(-30%);
    pointer-events: none;
}

.${getClassName("options-pane")} .close-button {
    float: right;
    width: 2em;
    height: 2em;
    line-height: 1em;
    font-size: 1em;
    background-color: transparent;
    border: 1px solid transparent;
    border-radius: 999px;
    box-sizing: border-box;
}
.${getClassName("options-pane")} .close-button:hover {
    border-color: inherit;
}

.${getClassName("options-pane")} .options-description {
    font-style: italic;
    margin-top: 0;
    padding-top: 0;
    opacity: 0.6;
}
.${getClassName("options-pane")} .form-row {
    display: flex;
    margin-bottom: 0.5em;
}
.${getClassName("options-pane")} .form-row:last-child {
    margin-bottom: 0;
}
.${getClassName("options-pane")} .field-label {
    margin: 0 1em;
    flex-basis: 100%;
}
.${getClassName("options-pane")} .field-caption {
    font-style: italic;
    font-size: smaller;
    line-height: 1em;
    opacity: 0.6;
    display: block;
    margin-left: 1em;
    padding: 0;
}
.${getClassName("options-pane")} .field-cell {
    margin: 0 1em;
}
.${getClassName("options-pane")} .field-value {
    text-align: center;
    font-style: italic;
    margin: 0;
    padding: 0;
}
.${getClassName("options-pane")} input[type=range] {
    vertical-align: middle;
}

`);

    const MIN_DIMENSION = 160;
    const MAX_DIMENSION = 2000;
    const DESCRIPTION_CHARACTER_LIMIT = 40000; // 40k limit imposed recently and refuted here: https://t.corp.amazon.com/D57644353
    const COMMENT_CHARACTER_LIMIT = 100000;
    const MIN_IMAGE_QUALITY = 0.1;
    const MAX_IMAGE_QUALITY = 1;
    const imgMarkdownMap = {};

    // Check support for WebP, and if supported, add it to the list.
    const webpCheckCanvas = document.createElement("canvas");
    const webpCheckCanvasData = webpCheckCanvas.toDataURL("image/webp", 0.5);

    const supports = {
        webp: webpCheckCanvasData.indexOf("data:image/webp") === 0
    };

    const imageFormatOptions = [
        { value: "auto", label: "Automatic (smallest size)" },
        { value: "jpg", label: "JPEG" },
        { value: "png", label: "PNG" }
    ];

    if (supports.webp) {
        imageFormatOptions.push({ value: "webp", label: "WebP" });
    }

    const getMaxDimensionValue = async () => Number(await GM.getValue("maxDimension", 1280));
    const getImageFormatValue = async () => await GM.getValue("imageFormat", "auto");
    const getImageQualityValue = async () => Number(await GM.getValue("imageQuality", 0.4));
    const getPostProcessGifsValue = async () => Boolean(await GM.getValue("postProcessGifs", false));
    const getOptionsOpen = async () => Boolean(await GM.getValue("optionsOpen", false));

    // Utility Functions

    // Create a text node if it's text
    const createChild = c => (typeof c === "string" || typeof c === "number" ? document.createTextNode(c) : c);

    function buildElement (tagName, attributes) {
        const el = document.createElement(tagName);
        for (const attr in attributes) {
            const value = attributes[attr];
            if (typeof value !== "undefined") {
                switch (attr) {
                    case "className": {
                        if (value instanceof Array) {
                            value.forEach(v => el.classList.add(v));
                        } else {
                            el.classList.add(value);
                        }
                        break;
                    }
                    case "content":
                    case "children": {
                        if (value instanceof Array) {
                        // Array of elements and strings
                            value.forEach((c) => {
                                el.appendChild(createChild(c));
                            });
                        } else {
                            el.appendChild(createChild(value));
                        }
                        break;
                    }
                    case /^on/.exec(attr)?.input: {
                        const baseEventName = attr.substring(2).toLowerCase();
                        if (value instanceof Array) {
                            el.addEventListener(baseEventName, value[0], value[1]);
                        } else {
                            el.addEventListener(baseEventName, value);
                        }
                        break;
                    }
                    case "style": {
                        Object.assign(el.style, value);
                        break;
                    }
                    default:
                        el.setAttribute(attr, value);
                }
            }
        }
        return el;
    }

    // End Utility Functions

    const optionsPane = await createOptionsPane();

    new MutationObserver(debounce(() => {
        for (const textarea of document.querySelectorAll("#codex-description, textarea[id^='CR-']")) {
            if (textarea.getAttribute("data-image-dropzone-initialized") || isHidden(textarea)) {
                continue;
            }
            textarea.setAttribute("data-image-dropzone-initialized", true);
            const proxyTextArea = document.createElement("textarea");
            Object.assign(proxyTextArea.style, {
                height: "100%",
                minHeight: "200px",
                width: "100%",
                boxSizing: "border-box",
                resize: "vertical"
            });

            const dropzone = createDropzone(proxyTextArea);
            const wrapper = document.createElement("div");
            Object.assign(wrapper.style, {
                height: "100%",
                display: "flex",
                flexDirection: "column"
            });
            if (textarea.parentElement.classList.contains("edit")) {
                wrapper.style.width = "50%";
            }
            wrapper.appendChild(dropzone);
            wrapper.appendChild(optionsPane);
            wrapper.appendChild(proxyTextArea);
            textarea.parentElement.appendChild(wrapper);
            textarea.style.display = "none";

            let startValue = textarea.value;
            for (const match of (textarea.value.match(/!\[.*?\]\(data:.*?\)/g) || [])) {
                const imgName = match.match(/!\[Attached Image - (.*?)\]/)[1];
                imgMarkdownMap[imgName] = match;
                startValue = startValue.replace(new RegExp(regexEscape(match), "g"), `<Image-${imgName}>`);
            }
            proxyTextArea.value = startValue;
            proxyTextArea.dispatchEvent(new Event("input", {
                bubbles: true,
                cancelable: true
            }));

            function textReplace () {
                let value = proxyTextArea.value;
                for (const imgName in imgMarkdownMap) {
                    value = value.replace(
                        new RegExp(
                            regexEscape(`<Image-${imgName}>`),
                            "g"
                        ),
                        imgMarkdownMap[imgName]
                    );
                }
                textarea.value = value.trim();
                textarea.dispatchEvent(new Event("input", {
                    bubbles: true,
                    cancelable: true
                }));
                const textareaMaxLength = textarea.id === "codex-description" ? DESCRIPTION_CHARACTER_LIMIT : COMMENT_CHARACTER_LIMIT;
                const allotment = textarea.value.length;
                dropzone.querySelector(`.${getClassName("drop-zone-allotment")}`).textContent = `(${allotment.toLocaleString()} / ${(textareaMaxLength.toLocaleString())} characters used)`;
                dropzone.querySelector(`.${getClassName("drop-zone-allotment")}`).classList.toggle("failure", allotment > textareaMaxLength);
            }

            const debouncedTextReplace = debounce(textReplace, 150, 500);
            debouncedTextReplace();

            proxyTextArea.focus();
            proxyTextArea.addEventListener("input", (evt) => {
                evt.stopPropagation();
                debouncedTextReplace();
            });

            const saveBtnGroup = getNearestElem(textarea, "btn-group");
            if (saveBtnGroup) {
                saveBtnGroup.addEventListener("click", (evt) => {
                    if (evt.virtualClick) {
                        return;
                    }
                    textReplace();
                    evt.stopPropagation();
                    setTimeout(() => {
                        evt.virtualClick = true;
                        evt.target.dispatchEvent(evt);
                    }, 150);
                }, {
                    capture: true
                });
            }
        }
    }, 150, 500)).observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["class"]
    });

    function createDropzone (destinationInput) {
        const elemMessage = buildElement("p", {
            className: getClassName("drop-zone-message")
        });

        const elem = buildElement("div", {
            className: getClassName("drop-zone"),
            children: [
                buildElement("button", {
                    children: "Options…",
                    className: getClassName("drop-zone-options-button"),
                    onClick: async (ev) => {
                        ev.stopPropagation();
                        return await openOptionsPane();
                    }
                }),
                elemMessage,
                buildElement("p", { className: getClassName("drop-zone-allotment") })
            ],
            onClick: async (ev) => {
                ev.preventDefault();
                resetField(ev);
                const files = await selectFile("image/*", true);
                await appendFiles(files);
            },
            onDrop: async (ev) => {
                ev.preventDefault();
                resetField(ev);
                if (ev.dataTransfer.items) {
                    const imageFiles = [];
                    for (const item of ev.dataTransfer.items) {
                        if (item.kind === "file" && item.type.match("^image/")) {
                            const imgFile = item.getAsFile();
                            imageFiles.push(imgFile);
                        }
                    }
                    await appendFiles(imageFiles);
                }
            },
            onDragLeave: resetField,
            onMouseOut: [resetField, true]
        });

        const defaultString = "Click, drag and drop an image here, or paste an image in the description.";

        function resetDropZoneStyle () {
            elem.classList.remove("error");
            elem.classList.remove("success");
            elem.classList.remove("over");
        }
        function resetField () {
            elemMessage.textContent = defaultString;
            elem.classList.remove("over");
        }

        resetField();
        resetDropZoneStyle();

        async function appendFiles (imageFiles) {
            let addString = "";
            if (imageFiles) {
                for (const imgFile of imageFiles) {
                    const uniqueName = `${imgFile.name}-${Math.floor(Math.random() * 1000)}`;
                    const newImageMarkdown = `![Attached Image - ${uniqueName}](${await getDataURL(imgFile)})`;
                    imgMarkdownMap[uniqueName] = newImageMarkdown;
                    addString += `\n\n<Image-${uniqueName}>`;
                }
                destinationInput.value = destinationInput.value.substring(0, destinationInput.selectionEnd) + addString + destinationInput.value.substring(destinationInput.selectionEnd);
                destinationInput.dispatchEvent(new Event("input", {
                    bubbles: true,
                    cancelable: true
                }));
            }
            if (addString === "") {
                elemMessage.textContent = "Error: Only images are supported.";
                elem.classList.add("error");
            } else {
                elemMessage.textContent = "Success: Image markdown added!";
                elem.classList.add("success");
            }
            setTimeout(() => {
                elemMessage.textContent = defaultString;
                resetDropZoneStyle();
            }, 5000);
        }

        elem.addEventListener("dragover", onDragOverDropzoneHandle(elem, elemMessage));
        elem.addEventListener("mouseover", onMouseOverDropzoneHandle(elem, elemMessage), true);
        destinationInput.addEventListener("paste", onPasteImageHandle(appendFiles));

        return elem;
    }

    function selectFile (contentType, multiple) {
        return new Promise((resolve) => {
            const input = buildElement("input", {
                type: "file",
                multiple: multiple,
                accept: contentType,
                onChange: () => {
                    const files = Array.from(input.files);
                    if (multiple) {
                        resolve(files);
                    } else {
                        resolve(files[0]);
                    }
                }
            });
            input.click();
        });
    }

    function onDragOverDropzoneHandle (elem, elemMessage) {
        return (evt) => {
            evt.preventDefault();
            elemMessage.textContent = "Drop image to add!";
            elem.classList.add("over");
        };
    }

    function onMouseOverDropzoneHandle (elem, elemMessage) {
        return (evt) => {
            evt.preventDefault();
            elemMessage.textContent = "Click here to select an image to add!";
            elem.classList.add("over");
        };
    }

    function onPasteImageHandle (appendFilesFn) {
        return async (evt) => {
            // Get the data of clipboard
            const clipboardItems = evt.clipboardData.items;
            const items = [].slice.call(clipboardItems).filter((item) => {
                // Filter the image items only
                return item.type.indexOf("image") !== -1;
            });
            if (items.length === 0) {
                return;
            }
            evt.preventDefault();
            const files = items.map(i => i.getAsFile());
            await appendFilesFn(files);
        };
    }

    function isHidden (el) {
        const boundingRect = el.getBoundingClientRect();
        if (boundingRect.width === 0 || boundingRect.height === 0) {
            return true;
        }
        if (boundingRect.x + boundingRect.width < 0 || boundingRect.y + boundingRect.height < 0) {
            return true;
        }
        if (boundingRect.x > document.documentElement.clientWidth || boundingRect.y > document.documentElement.clientHeight) {
            return true;
        }
        const style = window.getComputedStyle(el);
        return style.display === "none";
    }

    function getDataURL (imgFile) {
        const fileReader = new FileReader();
        return new Promise((resolve, reject) => {
            fileReader.onload = function () {
                const img = new Image();
                img.src = fileReader.result;
                img.onload = async function () {
                    if (!await getPostProcessGifsValue() && img.src.substring(0, 20).startsWith("data:image/gif;")) {
                        // A GIF passthrough; don't post-process.
                        resolve(img.src);
                    } else {
                        const canvas = document.createElement("canvas");
                        const context = canvas.getContext("2d");
                        context.imageSmoothingEnabled = false;
                        const dimension = await getMaxDimensionValue();
                        const imageFormat = await getImageFormatValue();
                        const imageQuality = await getImageQualityValue();
                        let ratio = Math.min(
                            dimension / img.width,
                            dimension / img.height
                        );
                        if (ratio > 1) {
                            ratio = 1;
                        }
                        const width = Math.round(img.width * ratio);
                        const height = Math.round(img.height * ratio);
                        canvas.width = width;
                        canvas.height = height;
                        context.drawImage(img, 0, 0, width, height);

                        const formats = [];
                        if (imageFormat === "auto" || imageFormat === "jpg") {
                            formats.push(canvas.toDataURL("image/jpeg", imageQuality));
                        }
                        if (imageFormat === "auto" || imageFormat === "png") {
                            formats.push(canvas.toDataURL("image/png"));
                        }
                        // Check support for WebP, and if supported, add it to the list.
                        if ((imageFormat === "auto" || imageFormat === "webp") && supports.webp) {
                            formats.push(canvas.toDataURL("image/webp", imageQuality));
                        }
                        formats.sort((a, b) => {
                            return a.length - b.length; // Find the smallest one
                        });
                        const smallestImage = formats[0];
                        resolve(smallestImage);
                    }
                };
                img.onerror = reject;
            };
            fileReader.onerror = reject;
            fileReader.readAsDataURL(imgFile);
        });
    }

    function getNearestElem (elem, selector) {
        while (elem !== document.body) {
            const nearbyElem = elem.querySelector(selector);
            if (nearbyElem !== null) {
                return nearbyElem;
            }
            elem = elem.parentElement;
        }
        return null;
    }

    function debounce (func, wait, maxWait = 5000) {
        let timeout = null;
        let lastExec = Date.now();
        return function () {
            clearTimeout(timeout);
            if (Date.now() - lastExec > maxWait) {
                func();
                lastExec = Date.now();
                return;
            }
            timeout = setTimeout(() => {
                func();
                lastExec = Date.now();
            }, wait);
        };
    }

    // eslint-disable-next-line max-lines-per-function
    async function createOptionsPane () {
        const getReadableMaxDimensionValue = async (val) => {
            if (typeof val === "undefined") {
                val = await getMaxDimensionValue();
            }
            return `${val}px`;
        };
        const elemMaxDimensionValue = buildElement("p", {
            children: await getReadableMaxDimensionValue(),
            className: "field-value"
        });

        const getImageFormatIndex = async (val) => {
            if (typeof val === "undefined") {
                val = await getImageFormatValue();
            }
            return imageFormatOptions.findIndex(o => o.value === val);
        };
        const elemImageFormatSelect = buildElement("select", {
            id: "imageFormatSelect",
            children: imageFormatOptions.map(o => buildElement("option", { value: o.value, children: o.label })),
            onChange: async (ev) => {
                await GM.setValue("imageFormat", ev.target.value);
                await setImageQualityAvailable();
            }
        });
        elemImageFormatSelect.selectedIndex = await getImageFormatIndex();

        const getReadableImageQualityValue = async (val) => {
            if (typeof val === "undefined") {
                val = await getImageQualityValue();
            }
            return `${val * 100}%`;
        };
        const elemImageQualityValue = buildElement("p", {
            children: await getReadableImageQualityValue(),
            className: "field-value"
        });
        const getImageQualityAvailable = async () => await getImageFormatValue() !== "png";
        const setImageQualityAvailable = async () => {
            if (await getImageQualityAvailable()) {
                document.getElementById("imageQualityInput").removeAttribute("disabled");
            } else {
                document.getElementById("imageQualityInput").setAttribute("disabled", "disabled");
            }
        };

        return buildElement("div", {
            className: [getClassName("options-pane"), "hidden"],
            children: [
                buildElement("button", {
                    children: "✕",
                    onClick: closeOptionsPane,
                    className: "close-button"
                }),
                buildElement("h3", {
                    children: "CR Image Attach Options"
                }),
                buildElement("p", {
                    children: "Set persistent preferences.",
                    className: "options-description"
                }),
                buildElement("div", {
                    className: "form-row",
                    children: [
                        buildElement("label", {
                            children: "Image Format",
                            for: "imageFormatSelect",
                            className: "field-label"
                        }),
                        buildElement("div", {
                            className: "field-cell",
                            children: elemImageFormatSelect
                        })
                    ]
                }),
                buildElement("div", {
                    className: "form-row",
                    children: [
                        buildElement("label", {
                            children: "Image Quality",
                            for: "imageQualityInput",
                            className: "field-label"
                        }),
                        buildElement("div", {
                            className: "field-cell",
                            children: [
                                buildElement("input", {
                                    id: "imageQualityInput",
                                    disabled: await getImageQualityAvailable() ? undefined : "disabled",
                                    type: "range",
                                    min: MIN_IMAGE_QUALITY,
                                    max: MAX_IMAGE_QUALITY,
                                    step: 0.1,
                                    value: await getImageQualityValue(),
                                    onInput: async (ev) => {
                                        await GM.setValue("imageQuality", Number(ev.target.value));
                                        elemImageQualityValue.textContent = await getReadableImageQualityValue();
                                    }
                                }),
                                elemImageQualityValue
                            ]
                        })
                    ]
                }),
                buildElement("div", {
                    className: "form-row",
                    children: [
                        buildElement("label", {
                            children: "Max Image Dimension",
                            for: "maxDimensionInput",
                            className: "field-label"
                        }),
                        buildElement("div", {
                            className: "field-cell",
                            children: [
                                buildElement("input", {
                                    id: "maxDimensionInput",
                                    type: "range",
                                    min: MIN_DIMENSION,
                                    max: MAX_DIMENSION,
                                    step: 20,
                                    value: await getMaxDimensionValue(),
                                    onInput: async (ev) => {
                                        await GM.setValue("maxDimension", Number(ev.target.value));
                                        elemMaxDimensionValue.textContent = await getReadableMaxDimensionValue();
                                    }
                                }),
                                elemMaxDimensionValue
                            ]
                        })
                    ]
                }),
                buildElement("div", {
                    className: "form-row",
                    children: [
                        buildElement("div", {
                            className: "field-label",
                            children: [
                                buildElement("label", {
                                    children: "Post-process GIFs",
                                    for: "postProcessGifsInput"
                                }),
                                buildElement("p", {
                                    className: "field-caption",
                                    children: "Enables compression but removes animation."
                                })
                            ] }),
                        buildElement("div", {
                            className: "field-cell",
                            children: [
                                buildElement("input", {
                                    id: "postProcessGifsInput",
                                    type: "checkbox",
                                    checked: await getPostProcessGifsValue() || undefined,
                                    onChange: async (ev) => {
                                        await GM.setValue("postProcessGifs", Boolean(ev.target.checked === true || ev.target.checked === "checked"));
                                    }
                                })
                            ]
                        })
                    ]
                })
            ]
        });
    }

    function regexEscape (text) {
        return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
    }

    let optionsMenuCommand;

    async function closeOptionsPane () {
        optionsPane.classList.add("hidden");
        await GM.setValue("optionsOpen", false);
        await GM.unregisterMenuCommand(optionsMenuCommand);
        optionsMenuCommand = await GM.registerMenuCommand(
            "Open Options...",
            openOptionsPane
        );
    }

    async function openOptionsPane () {
        optionsPane.classList.remove("hidden");
        await GM.setValue("optionsOpen", true);
        await GM.unregisterMenuCommand(optionsMenuCommand);
        optionsMenuCommand = await GM.registerMenuCommand(
            "Close Options",
            closeOptionsPane
        );
    }

    if (await getOptionsOpen() === false) {
        await closeOptionsPane();
    } else {
        await openOptionsPane();
    }
})();
