// ==UserScript==
// @name         Code Reviews Assigned
// @namespace    http://amazon.com
// @version      1.0
// @updateURL    https://code.amazon.com/packages/CodeReviewsAssigned-Userscript/blobs/mainline/--/src/CodeReviewsAssigned.user.js?raw=1
// @downloadURL  https://code.amazon.com/packages/CodeReviewsAssigned-Userscript/blobs/mainline/--/src/CodeReviewsAssigned.user.js?raw=1
// @description  See how many code reviews your teammates/favorite reviewers currently have directly assigned to them in Code Browser
// @author       @carlcom
// @match        https://code.amazon.com/reviews/CR-*/revisions/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=amazon.com
// @grant        none
// ==/UserScript==

(async function() {
    'use strict';
    // Used to extract values from URL
    const crUrlRegex = /^(http|https):\/\/code.amazon.com\/reviews\/(CR-\d+)\/revisions\/(\d+).*$/;
    const htmlAssignedReviewsRegex = (user) => new RegExp(String.raw`(\d+) reviews directly to ${user}`);
    //               Green      Yellow     Orange     Red
    const colors = ["#017815", "#aba500", "#c47300", "#ab1f00"];
    // Cached review data
    let reviewsAssignedMap = null;

    async function loadAssignedData(){
        // If data exists, don't reload
        if(reviewsAssignedMap) return;
        let [_fullMatch, _protocol, crId, revision] = location.href.match(crUrlRegex);
        const crDataUrl = `https://code.amazon.com/reviews/${crId}/revisions/${revision}.json`;
        const data = await fetch(crDataUrl).then(res => res.json()).catch(err => { favorites: [] });
        // Filter users and grab aliases
        const favoriteUsers = data.favorites.filter(favorite => favorite.entity_id.type === "USER")
        .map(favorite => favorite.entity_id.id);
        const requests = [];
        // Request Open and Assigned HTML (which contains count of reviews assigned) for each favorite user
        favoriteUsers.forEach((user) => {
            let request = fetch(`https://code.amazon.com/api/reviews/open_and_assigned_to_user_html?user=${user}`)
            .then(res => res.json())
            .then(json => [user, json]);
            requests.push(request);
        });
        const openAndAssignedHTMLs = await Promise.allSettled(requests);
        const reviewsAssigned = openAndAssignedHTMLs.filter(settled => settled.status === "fulfilled")
        .map(settled => settled.value)
        .map(
            // Grab number of reviews from the HTML using regex for user
            ([user, htmlObj]) => [user, htmlObj.html.match(htmlAssignedReviewsRegex(user))[1]]
        );
        reviewsAssignedMap = new Map(reviewsAssigned);
    }

    async function addReviewsAssignedToDOM(){
        // Don't add to page if already added
        // Find list of favorites in DOM and add review count badge to each alias
        const favoritesList = document.querySelectorAll("ul.ng-scope>li>div");
        const reviewCountsList = document.querySelectorAll("div.CodeReviewsAssigned-ReviewCount");
        // Don't re-add if already in DOM
        if(reviewCountsList.length > 0) return;
        for (let entry of favoritesList){
            const alias = entry.querySelector("span").textContent.trim();
            // Only add if corresponds to an alias in favorites map (e.g. ignore team names)
            if(reviewsAssignedMap.has(alias)){
                const div = document.createElement("div");
                // Currently only used to identify nodes added
                div.classList.add("CodeReviewsAssigned-ReviewCount");
                div.style.display = "flex";
                div.style.justifyContent = "flex-end";
                div.style.flexGrow = 1;
                div.style.color = "white";
                const span = document.createElement("span");
                span.style.padding = "0.5rem 1rem";
                span.style.borderRadius = "2rem";
                span.style.backgroundColor = colors[reviewsAssignedMap.get(alias)] ?? colors.at(-1);
                const text = document.createTextNode(`${reviewsAssignedMap.get(alias)} reviews`);
                span.appendChild(text);
                div.appendChild(span);
                entry.appendChild(div);
            }
        }
    }

    // Load data on CR revision page load (regardless of tab)
    await loadAssignedData();
    await runOnceElementLoaded("ul.ng-scope", addReviewsAssignedToDOM);

    // Listener to check for URL history change in page without reload (e.g. clicking review tab after loading the CR)
    window.addEventListener("popstate", async (event) => {
        // This load should be skipped implicitly (since data was loaded previously)
        await loadAssignedData();
        await runOnceElementLoaded("ul.ng-scope", addReviewsAssignedToDOM);
    });

    // Tries running callback once DOM element loaded
    function runOnceElementLoaded(selector, callback){
        let tries = 0;
        let intervalId = undefined;
        async function intervalCallback() {
            const element = document.querySelector(selector);
            if(element) {
                try {
                    await callback();
                }
                finally {
                    clearInterval(intervalId);
                }
            }
            // If tried more than 10 times, give up
            if(tries > 10){
                clearInterval(intervalId);
            }
            ++tries;
        }
        // Invoke once immediately
        intervalCallback();
        // Check periodically whether selected element exists, then invoke callback when found and stop checking
        intervalId = setInterval(intervalCallback, 300);
    }

})();