// ==UserScript==
// @name         SIM Escalation Indicators
// @namespace    https://w.amazon.com/bin/view/Users/eboring/Tampermonkey/
// @version      0.77
// @description  Adds an indicator to SIM lists to show how close to escalation tickets are.
// @author       eboring, ddzado
// @include      https://t.corp.amazon.com*
// @downloadURL  https://code.amazon.com/packages/EboringTampermonkeyScripts/blobs/mainline/--/scripts/sim_escalation_indicators.user.js?download=1
// @updateURL    https://code.amazon.com/packages/EboringTampermonkeyScripts/blobs/mainline/--/scripts/sim_escalation_indicators.user.js?download=1
// @grant        GM_getValue
// @grant        GM_registerMenuCommand
// @grant        GM_setValue
// @grant        GM_xmlhttpRequest

// ==/UserScript==

(function() {
    'use strict';
    
    // Constants ==================================================================================
    const indicatorStyle = `
    .escalation-indicator {
        height: 2em;
        width: 2.5em;
        display: inline-block;
        border-radius: 4px;  /* Slight rounding of corners, remove for sharp corners */
        border: 1px solid black;
        text-align: center;
        font-size: medium;
        padding-top: 0.4em;
        margin-right: 10px;
        vertical-align: middle;
        box-shadow: 1px 1px 3px rgba(0,0,0,0.2); /* Optional: adds subtle depth */
    }
    .status-cell-wrapper {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .escalation-reset-spinner svg {
        width: 1.5em;
        height: 1.5em;
        animation-name: spin;
        animation-duration: 2500ms;
        animation-iteration-count: infinite;
        animation-timing-function: linear; 
      }
      
      @keyframes spin {
          from {
              transform:rotate(0deg);
          }
          to {
              transform:rotate(360deg);
          }
      }

      .hidden{
          display: none;
      }
    `

    const simApiUrl = "https://maxis-service-prod-iad.amazon.com";
    
    const statusData = {
        Assigned: {
            interval: 60 * 60,  // 1 hour
            staticColor: "red"
        },
        Researching: {
            interval: 60 * 90,  // 1 hour, 30 minutes
            staticColor: "blue"
        },
        "Work In Progress": {
            interval: 60 * 60 * 8,  // 8 hours
            staticColor: "purple"
        },
        Pending: {
            interval: 60 * 60 * 24 * 7,  // 7 days
            staticColor: "yellow"
        },
        Resolved: {
            interval: undefined,   // No escalation
            staticColor: "green"
        }
    }
    
    // Global Variables ===========================================================================
    var tickets = [];
    var timer = undefined; 
    var testBetaFeatures = false;
    
    // Classes ====================================================================================
    class Ticket{
        countdown = Math.round(Math.random() * 30);
        
        // Property getters and setters
        get ticketId(){
            return this._ticketId;
        }
        set ticketId(value){
            this._ticketId = value;
            queryTicketData(this);
        }

        get title(){
            if(this._ticketData && this._ticketData.title){
                return this._ticketData.title;
            }
            else{
                return "Unknown Title";
            }
        }
        
        get createDate(){
            return new Date(this._ticketData.createDate);
        }
        
        get escalationDate(){
            return this._escalationDate;
        }
        
        get escalationMilliseconds(){
            if(this._escalationDate){
                return this._escalationDate.getTime() - new Date().getTime();
            }
            else{
                return -1;
            }
        }

        set issueSummaryDiv(issueSummaryDiv){
            this._issueSummaryDiv = issueSummaryDiv;
        }

        get issueSummaryDiv(){
            return this._issueSummaryDiv;
        }
        
        get ticketSeverity(){
            if(this._ticketData && this._ticketData.extensions && this._ticketData.extensions.tt){
                return Number(this._ticketData.extensions.tt.impact);
            }
            return 2;
        }
        
        get ticketRow(){
            return this._ticketRow;
        }
        set ticketRow(value){
            this._ticketRow = value;
            this._ticketId = this._ticketRow.querySelector(".sim-list--shortId").getAttribute("data-sid");
            this.refreshAllTicketData();
        }
        
        get ticketStatus(){
            if(this._ticketData && this._ticketData.extensions && this._ticketData.extensions.tt){
                return this._ticketData.extensions.tt.status;
            }
            return "";
        }
        
        refreshAllTicketData(){
            queryTicketData(this);
            if(this.ticketRow){
                this.refreshIndicator();
            }
            if(this.issueSummaryDiv){
                this.refreshIssueSummary();
            }
        }
        
        refreshEscalationDate(){
            if(this._ticketData && this._ticketData.calculatedUpgradeTime && new Date(this._ticketData.calculatedUpgradeTime) > new Date()){
                this._escalationDate = new Date(this._ticketData.calculatedUpgradeTime);
            }
            else{
                var fromDate = undefined;
                if(this.ticketId && this._edits){
                    var implementationEdits = this._edits.filter(edit => {
                        var include = false;
                        edit.pathEdits.forEach(pathEdit => {
                            if(pathEdit.data && pathEdit.data.action && pathEdit.data.action == "Implementation"){
                                include = true;
                            }
                        });
                        return include;
                    });
                    if(implementationEdits && implementationEdits.length > 0){
                        implementationEdits.forEach(edit => {
                            var effectiveCreateDate = new Date(edit.effectiveCreateDate)
                            if(!fromDate || effectiveCreateDate > fromDate){
                                fromDate = effectiveCreateDate;
                            }
                        });
                    }
                }   
                if(!fromDate){
                    fromDate = this.createDate;
                }
                if(statusData.hasOwnProperty(this.ticketStatus)){
                    this._escalationDate = addSecondsToDate(fromDate, statusData[this.ticketStatus].interval);
                }
            }
        }
        
        refreshIndicator(){
            try{
                var statusCell = this.ticketRow.querySelector("div.sim-table--status")
                while(statusCell.tagName != "TD" && statusCell.parentElement){
                    statusCell = statusCell.parentElement;
                }
                if(statusCell.tagName == "TD"){
                    var indicator = statusCell.querySelector("div.escalation-indicator");
                    if(!indicator){
                        indicator = document.createElement("div");
                         if (!statusCell.querySelector('.status-cell-wrapper')) {
                             const wrapper = document.createElement('div');
                             wrapper.className = 'status-cell-wrapper';

                             this.element = document.createElement('div');
                             this.element.className = 'escalation-indicator';

                             // Move existing content into wrapper
                             const statusContent = statusCell.innerHTML;
                             wrapper.appendChild(this.element);
                             wrapper.insertAdjacentHTML('beforeend', statusContent);

                             statusCell.innerHTML = '';
                             statusCell.appendChild(wrapper);
            }
                    }
                    var deltaNowToEscalation = undefined;
                    var deltaString = "(unknown)"
                    var escalateWording = "Escalates in";
                    if(this.escalationDate){
                        deltaNowToEscalation = this.escalationDate - new Date();
                        escalateWording = deltaNowToEscalation < 0 ? "Escalated" : "Escalates in";
                        deltaString = convertDateDeltaToString(deltaNowToEscalation);
                    }
                    if(this.ticketSeverity < 3 || this._ticketData.calculatedUpgradeTime){
                        var escalationDeltaSeconds = (this.escalationDate.getTime() - new Date().getTime()) / 1000;
                        escalationDeltaSeconds = escalationDeltaSeconds < 0 ? 0 : escalationDeltaSeconds;
                        switch(this.ticketStatus){
                            case "Assigned":
                            if(this._edits){
                                indicator.style.backgroundColor = statusData[this.ticketStatus].staticColor;
                                indicator.setAttribute("title", `${escalateWording}: ${deltaString}\nAt: ${this.escalationDate.toLocaleString()}`);
                                this.setIndicatorText(escalationDeltaSeconds, indicator);
                            }
                            else{
                                indicator.style.backgroundColor = "purple";
                                indicator.setAttribute("title", "Loading escalation status");
                            }
                            break;
                            case "Resolved":
                            case "Closed":
                            indicator.style.backgroundColor = statusData[this.ticketStatus].staticColor;
                            indicator.setAttribute("title", `No Escalation`);
                            indicator.innerHTML = "☑";
                            break;
                            case "Researching":
                            case "Work In Progress":
                            case "Pending":
                            if(this.escalationDate){
                                var alwaysRed = (60 * 60 * 0)   // Red if less than 0 hours
                                var alwaysGreen = (60 * 60 * 24 * 4)  //Green if greater than 4 days
                                if(escalationDeltaSeconds < alwaysRed){  
                                    rgbOffset = 0;
                                }
                                else if(escalationDeltaSeconds > alwaysGreen){
                                    rgbOffset = 510
                                }
                                else{
                                    
                                    var rgbOffset = 510 * ((escalationDeltaSeconds - alwaysRed) / (alwaysGreen - alwaysRed));
                                }
                                
                                // 0 to 255 = red to yellow (red = rgb(255, 0, 0), yellow = rgb(255, 255, 0))
                                // 255 to 510 = yellow to green (yellow = rgb(254, 255, 0), green = rbg(0, 255, 0))
                                var red = Math.round(rgbOffset < 255 ? 255 : 255 - (rgbOffset - 255));
                                var green = Math.round(rgbOffset < 255 ? rgbOffset : 255);
                                indicator.style.backgroundColor = `rgb(${red}, ${green}, 0)`;
                                indicator.setAttribute("title", `${escalateWording}: ${deltaString}\nAt: ${this.escalationDate.toLocaleString()}`);

                                if(rgbOffset < 150){
                                    indicator.style.color = "white";
                                }
                                else{
                                    indicator.style.color = "black";
                                }
                                
                                this.setIndicatorText(escalationDeltaSeconds, indicator);

                                break;
                            }
                            default:
                            if(this._edits){
                                indicator.style.backgroundColor = "purple";
                                indicator.setAttribute("title", "Loading escalation status");
                            }
                            else{
                                indicator.style.backgroundColor = "black";
                                indicator.setAttribute("title", "Escalation status unavailable");
                            }
                        }
                    }
                    else{
                        indicator.style.backgroundColor = "blue";
                        indicator.setAttribute("title", "Does not escalate");
                    }
                }
            }
            catch(error){
                // if(error instanceof TypeError && error.message.startsWith("this.ticketRow.querySelector") && error.message.endsWith("is null")){
                //     tickets.splice(tickets.indexOf(this.ticketRow), 1);
                // }
            }
        }

        setIndicatorText(escalationDeltaSeconds, indicator){
            if(escalationDeltaSeconds == 0){
                indicator.innerHTML = "🚨";
            }
            else if(escalationDeltaSeconds < 60){  // less than 1 minute
                indicator.innerHTML = `${escalationDeltaSeconds}s`;
            }
            else if(escalationDeltaSeconds < 60 * 60){  // less than 1 hour
                var escMinutes = Math.floor(escalationDeltaSeconds / 60);
                indicator.innerHTML = `${escMinutes}m`;
            }
            else if(escalationDeltaSeconds < 60 * 60 * 24){  // less than 24 hours
                var escHours = Math.floor(escalationDeltaSeconds / (60 * 60));
                indicator.innerHTML = `${escHours}h`;
            }
            else{  // more than 1 day
                var escDays = Math.floor(escalationDeltaSeconds / (60 * 60 * 24));
                indicator.innerHTML = `${escDays}d`;
            }
        }
        
        refreshIssueSummary(){
            try{
                var indicator = this.issueSummaryDiv.querySelector("div.escalation-indicator");
                if(!indicator){
                    indicator = document.createElement("div");
                    indicator.classList.add("escalation-indicator");
                    this.issueSummaryDiv.querySelector(".issue-summary-escalation .header-text").appendChild(indicator);
                }
                var deltaNowToEscalation = undefined;
                var deltaString = "unknown"
                var escalateWording = "Escalates in";
                if(this.escalationDate){
                    deltaNowToEscalation = this.escalationDate - new Date();
                    escalateWording = deltaNowToEscalation < 0 ? "Escalated" : "Escalates in";
                    deltaString = convertDateDeltaToString(deltaNowToEscalation);
                }
                var issueSummaryEscalationKey = this.issueSummaryDiv.querySelector(".issue-summary-escalation .info-key span");
                var issueSummaryEscalationValue = this.issueSummaryDiv.querySelector(".issue-summary-escalation .info-value span");
                if(this.ticketSeverity < 3 || this._ticketData.calculatedUpgradeTime){
                    switch(this.ticketStatus){
                        case "Assigned":
                        if(this._edits){
                            indicator.style.backgroundColor = statusData[this.ticketStatus].staticColor;
                            issueSummaryEscalationKey.innerHTML = `${escalateWording}:`;
                            issueSummaryEscalationValue.innerHTML = `${deltaString}<br>${this.escalationDate.toLocaleString()}`;
                        }
                        else{
                            indicator.style.backgroundColor = "purple";
                            indicator.setAttribute("title", "Loading escalation status");
                        }
                        break;
                        case "Resolved":
                        case "Closed":
                        indicator.style.backgroundColor = statusData[this.ticketStatus].staticColor;
                        issueSummaryEscalationKey.innerHTML = `Escalation:`;
                        issueSummaryEscalationValue.innerHTML = `Does not escalate`;
                        break;
                        case "Researching":
                        case "Work In Progress":
                        case "Pending":
                        if(this.escalationDate){
                            var escalationDeltaSeconds = (this.escalationDate.getTime() - new Date().getTime()) / 1000;
                            escalationDeltaSeconds = escalationDeltaSeconds < 0 ? 0 : escalationDeltaSeconds;
                            var alwaysRed = (60 * 60 * 0)   // Red if less than 0 hours
                            var alwaysGreen = (60 * 60 * 24 * 4)  //Green if greater than 4 days
                            if(escalationDeltaSeconds < alwaysRed){  
                                rgbOffset = 0;
                            }
                            else if(escalationDeltaSeconds > alwaysGreen){
                                rgbOffset = 510
                            }
                            else{
                                
                                var rgbOffset = 510 * ((escalationDeltaSeconds - alwaysRed) / (alwaysGreen - alwaysRed));
                            }
                            
                            // 0 to 255 = red to yellow (red = rgb(255, 0, 0), yellow = rgb(255, 255, 0))
                            // 255 to 510 = yellow to green (yellow = rgb(254, 255, 0), green = rbg(0, 255, 0))
                            var red = Math.round(rgbOffset < 255 ? 255 : 255 - (rgbOffset - 255));
                            var green = Math.round(rgbOffset < 255 ? rgbOffset : 255);
                            indicator.style.backgroundColor = `rgb(${red}, ${green}, 0)`;
                            issueSummaryEscalationKey.innerHTML = `${escalateWording}:`;
                            issueSummaryEscalationValue.innerHTML = `${deltaString}<br>${this.escalationDate.toLocaleString()}`;
                            break;
                        }
                        default:
                        if(this._edits){
                            indicator.style.backgroundColor = "purple";
                            issueSummaryEscalationKey.innerHTML = `Escalation:`;
                            issueSummaryEscalationValue.innerHTML = `Loading`;
                        }
                        else{
                            indicator.style.backgroundColor = "black";
                            issueSummaryEscalationKey.innerHTML = `Escalation:`;
                            issueSummaryEscalationValue.innerHTML = `unknown`;
                        }
                    }
                }
                else{
                    indicator.style.backgroundColor = "blue";
                    indicator.setAttribute("title", "Does not escalate");
                }
            }
            catch(error){}
        }
        
        // Clock tick - Update the indicator and occasionally query the escalation date again
        tick(){
            if(this.countdown < 0){
                if(this._ticketData && this._edits){
                    // To avoid making tons of ajax calls to Maxis at once, we'll recheck ticket data
                    // at random intervals that are longer when more tickets are shown on the page..                
                    this.countdown = (30 * tickets.length)  + Math.round(Math.random() * (90 * tickets.length));
                    this.refreshAllTicketData();
                }
                else{
                    this.countdown = 5;
                }
            }
            else{
                this.refreshIndicator();
                this.refreshIssueSummary();
            }
            this.countdown--;
        }
    }
    
    // Global Function ============================================================================
    

    function generateEscalationReport(){
        var groupsArray = decodeURI(window.location.toString().match(/[Gg]roups?%3[Aa]([^&]+)/)[1]).replace("(", "").replace(")", "").replaceAll('\"', "").split(" OR ");
        if(tickets.length > 0){
            var promptText = `Enter the time frame for which you would like to report upcoming escalations.
For example, to report all tickets escalating in the next 6 hours, enter '6h'.
More examples:
45m = 45 minutes
16h = 16 hours
3d = 3 days

Note that the report will only include tickets currently shown on this page. For a more detailed report, try @snowdenl's CLI report generator:
https://w.amazon.com/bin/view/MercuryVeil/Database_Services/Tech_Talks/Sev2_Escalation_Report/`
            var timeframe = prompt(promptText);
            var matches = timeframe.trim().match(/^(\d{1,2})(m|d|h)$/m);
            if(matches && matches.length > 0){
                var time = 0;
                if(matches[2].toLowerCase() == "m"){
                    time = Number(matches[1]) * 1000 * 60
                }
                else if(matches[2].toLowerCase() == "h"){
                    time = Number(matches[1]) * 1000 * 60 * 60
                }
                else if(matches[2].toLowerCase() == "d"){
                    time = Number(matches[1]) * 1000 * 60 * 60 * 24
                }
                // https://stackoverflow.com/questions/15593850/sort-array-based-on-object-attribute-javascript
                tickets.sort((a, b) => {
                    return a.escalationMilliseconds - b.escalationMilliseconds; // Ascending
                    //return b.escalationMilliseconds - a.escalationMilliseconds; // Descending
                })
                var escalationReport = `Escalation report generated ${new Date().toLocaleString()}
From: ${document.querySelector("h1.table-actions-title span").textContent}
------
(Escalation date) <Status> - Severity - Title - Link
------\n`;
                tickets.forEach(ticket => {
                    if(ticket.escalationMilliseconds >= 0 && ticket.escalationMilliseconds < time){
                        escalationReport += `- (${ticket.escalationDate.toLocaleString()}) <${ticket.ticketStatus}> Sev ${ticket.ticketSeverity} - ${ticket.title} - https://t.corp.amazon.com/${ticket.ticketId}\n`;
                    }
                });
                try{
                    navigator.clipboard.writeText(escalationReport);
                    alert(`${escalationReport}\n\nThis report has been copied to you clipboard automatically.`);
                }
                catch (err){
                    console.log(escalationReport);
                    alert(`${escalationReport}\n\nYour browser blocked copying this report to your clipboard automatically. You will have to manually copy it either from here or from the Console in dev tools (press F12 to open).`);
                }
            }
            else{
                alert(`The timeframe you entered does not match the expected format, the report could not be generated.
You entered: ${timeframe}
Please match: ##[m|h|d]
For example:
45m = 45 minutes
16h = 16 hours
3d = 3 days`);
            }
        }
        else{
            alert("Cannot generate report, no tickets are detected on this tab. If this is an error, refresh the page and try again.");
        }
    }

    function addSecondsToDate(date, seconds){
        var e = new Date(date.getTime() + seconds * 1000); // getTime() deals with milliseconds, so * 1000
        return e;
    }
    
    function convertDateDeltaToString(milliseconds){
        var sign = milliseconds < 0 ? "-" : "";
        milliseconds = Math.abs(milliseconds);
        var days = Math.floor(milliseconds / (1000 * 60 * 60 * 24));
        var hours = Math.floor(milliseconds / (1000 * 60 * 60)) - (days * 24);
        var minutes = Math.floor(milliseconds / (1000 * 60)) - (hours * 60) - (days * 24 * 60);
        var seconds = Math.floor(milliseconds / 1000) - (days * 24 * 60 * 60) - (hours * 60 * 60) - (minutes * 60);
        return `${sign}${days}d ${hours}h ${minutes}m ${seconds}s`;
    }
    
    function httpGet(url){
        return new Promise((resolve, reject) => {
            GM_xmlhttpRequest({
                method: 'GET',
                url: url,
                onload: resolve
            });
        })
    }
    
    async function queryTicketData(ticket){
        var ticketId = ticket.ticketId;
        const result = await httpGet(`${simApiUrl}/issues/${ticketId}`).then(response => {
            if (response.readyState == 4 && response.status == 200) {
                ticket._ticketData = JSON.parse(response.responseText);
                queryAllEdits(ticket);
            }
        });
    }
    
    async function queryAllEdits(ticket){
        var ticketId = ticket.ticketId;
        const result = await httpGet(`${simApiUrl}/issues/${ticketId}/edits`).then(resolve => {
            ticket._edits = JSON.parse(resolve.responseText).edits;
            ticket.refreshEscalationDate();
        });
    }
    
    function tick(){
        tickets.forEach(ticket => {
            ticket.tick();
        });
        document.querySelectorAll("#sim-issueListContent tbody tr").forEach(ticketRow => {
            if(ticketRow.querySelector(".sim-list--shortId") && !ticketRow.querySelector(".escalation-indicator")){
                addTicketRow(ticketRow);
            }
        });
        var issueSummaryDiv = document.querySelector(".issue-summary");
        var issueIdSpan = document.querySelector("span.ticket-id");
        
        if(issueSummaryDiv && issueIdSpan){
            var issueSummaryEscalation = issueSummaryDiv.querySelector(".issue-summary-escalation");
            if(!issueSummaryEscalation){
                var issueSummaryEscalation = document.createElement("div");
                issueSummaryEscalation.classList.add("issue-summary-escalation");
                
                var headerText = document.createElement("div");
                headerText.classList.add("header-text");
                headerText.style.padding = ".5rem 1rem";
                issueSummaryEscalation.appendChild(headerText);
                
                var infoPair = document.createElement("dl");
                infoPair.classList.add("info-pair", "sim-infoPair__bold");
                headerText.appendChild(infoPair);
                
                var infoKey = document.createElement("dt");
                infoKey.classList.add("info-key");
                infoPair.appendChild(infoKey);
                
                var infoKeySpan = document.createElement("span");
                infoKey.appendChild(infoKeySpan);
                
                var infoValue = document.createElement("dd");
                infoValue.classList.add("info-value");
                infoPair.appendChild(infoValue);
                
                var infoValueSpan = document.createElement("span");
                infoValue.appendChild(infoValueSpan);

                var escalationIndicatorPanel = document.createElement("div");
                escalationIndicatorPanel.style.textAlign = "center";
                headerText.appendChild(escalationIndicatorPanel);  

                var EscalationIndicator = document.createElement("div");
                EscalationIndicator.classList.add("escalation-indicator");
                escalationIndicatorPanel.appendChild(EscalationIndicator);

                escalationIndicatorPanel.appendChild(document.createElement("br"));

                var resetEscalationButton = document.createElement("button");
                resetEscalationButton.id = "reset-escalation-button";
                resetEscalationButton.textContent = "Reset Escalation";
                resetEscalationButton.title = `*Only works if ticket is in Pending* \nAdds a "Next Step: Implementation" entry to the Audit Trail which effectively resets this ticket's escalation time to 7 days.\n\n**This is currently experimental, please double check the ticket status before closing the tab!**`;
                resetEscalationButton.setAttribute("ticket-id", issueIdSpan.textContent);
                resetEscalationButton.addEventListener("click", resetTicketEscalation);
                escalationIndicatorPanel.appendChild(resetEscalationButton);

                var spinnerContainer = document.createElement("span");
                spinnerContainer.id = "escalation-reset-spinner";
                spinnerContainer.innerHTML = '<svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="circle-notch" class="svg-inline--fa fa-circle-notch fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M288 39.056v16.659c0 10.804 7.281 20.159 17.686 23.066C383.204 100.434 440 171.518 440 256c0 101.689-82.295 184-184 184-101.689 0-184-82.295-184-184 0-84.47 56.786-155.564 134.312-177.219C216.719 75.874 224 66.517 224 55.712V39.064c0-15.709-14.834-27.153-30.046-23.234C86.603 43.482 7.394 141.206 8.003 257.332c.72 137.052 111.477 246.956 248.531 246.667C393.255 503.711 504 392.788 504 256c0-115.633-79.14-212.779-186.211-240.236C302.678 11.889 288 23.456 288 39.056z"></path></svg>';
                spinnerContainer.classList.add("escalation-reset-spinner", "hidden");
                escalationIndicatorPanel.appendChild(spinnerContainer);

                issueSummaryDiv.appendChild(issueSummaryEscalation);
                
                addTicketSummary(issueSummaryDiv, issueIdSpan.innerText);
            }
        }
        initCreateEscalationReportButton();
    }

    function resetTicketEscalation(){
        var status = document.querySelector("div.issue-summary-status dd.info-value").textContent;
        if(status.toLowerCase().trim() == "pending"){
            document.getElementById("escalation-reset-spinner").classList.remove("hidden");
            document.getElementById("reset-escalation-button").classList.add("hidden");
            var ticketId = this.getAttribute("ticket-id").trim();
            var url = `${simApiUrl}/issues/${ticketId}/edits`;
            var pendingReason = "N/A";
            document.querySelectorAll("div.issue-summary-status-details dl").forEach(e  => {
                if(e.textContent.startsWith("Pending reason:")){
                    pendingReason = e.querySelector("dd.info-value").textContent;
                }
            });
            var pathEdit = {
                "pathEdits": [
                    {
                    "path": "/next_step",
                    "editAction": "PUT",
                    "data": {
                        "action": "Implementation",
                        "owner": "role:resolver"
                    }
                    }
                ]
            };
            console.log(`Setting next step to "Implementation" for ticket ${ticketId} at API URL: ${url}`);
            GM_xmlhttpRequest({
                method: 'POST',
                url: url,
                data: JSON.stringify(pathEdit),
                headers: {"Content-Type": "application/json;charset=UTF-8"},
                onload: function (response) {
                    if (response.readyState == 4 && this.status >= 200 && this.status < 300) {
                        console.log("Next step update successful, flipping back to Pending after a 3 second wait to allow SIM-T to recognize the update.");
                        // https://tiny.amazon.com/11st869zh/Recommended3SecondWait
                        setTimeout(setTicketToPending(ticketId, pendingReason), 3000);
                    }
                    else{
                        console.log(`Next step update failed with status: ${this.status}: ${this.responseText}`);
                    }
                }
            });
            var indicator = document.querySelector(".escalation-indicator");
            if(indicator){
                indicator.style.backgroundColor = "purple";
            }
        }
    }
    
    function setTicketToPending(ticketId, pendingReason){
        var url = `${simApiUrl}/issues/${ticketId}/edits`;
        var updateData = {
            "pathEdits": [
               {
                "path": "/next_step/action",
                "editAction": "PUT",
                "data": pendingReason
             }
            ]
         }
        GM_xmlhttpRequest({
            method: 'POST',
            url: url,
            data: JSON.stringify(updateData),
            headers: {"Content-Type": "application/json;charset=UTF-8"},
            onload: function (response) {
                if (response.readyState == 4 && this.status >= 200 && this.status < 300) {
                    console.log("Flipped back to Pending");
                    
                }
                else{
                    console.log(`Flip to Pending failed with status: ${this.status}: ${this.responseText}`);
                }
                document.getElementById("escalation-reset-spinner").classList.add("hidden");
                document.getElementById("reset-escalation-button").classList.remove("hidden");
            }
        });
    }

    function addTicketSummary(issueSummaryDiv, ticketId){
        if(!hasTicketId(ticketId)){
            var ticket = new Ticket();
            ticket.issueSummaryDiv = issueSummaryDiv;
            ticket.ticketId = ticketId;
            tickets.push(ticket);
            
        }  
    }
    
    function addTicketRow(ticketRow){
        if(!hasTicketRow(ticketRow)){
            var ticket = new Ticket();
            ticket.ticketRow = ticketRow;
            if(ticket.ticketId){
                tickets.push(ticket);
            }
        }
    }
    
    function hasTicketId(ticketId){
        var has = false;
        tickets.forEach(ticket => {
            
            if(ticket.ticketId.toLowerCase() == ticketId.toLowerCase()){
                has = true;
            }
        });
        return has;
    }
    
    function hasTicketRow(ticketRow){
        var has = false;
        tickets.forEach(ticket => {
            if(ticket.ticketRow == ticketRow){
                has = true;
            }
        });
        return has;
    }

    function initCreateEscalationReportButton(){
        var buttonPanel = document.querySelector("div.awsui-util-action-stripe-group");
        if(buttonPanel && !document.querySelector("awsui-button.create-escalation-report-button")){
            var reportButton = document.createElement("button");
            reportButton.classList.add("awsui-button", "awsui-button-variant-normal", "awsui-hover-child-icons");
            reportButton.innerHTML = '<span awsui-button-region="text">Create Escalation Report</span>';
            reportButton.addEventListener("click", generateEscalationReport);

            var awsuiReportButton = document.createElement("awsui-button");
            awsuiReportButton.classList.add("create-escalation-report-button");
            awsuiReportButton.appendChild(reportButton);

            buttonPanel.appendChild(awsuiReportButton);
        }
    }

    function reportUsage(){
        var dateDiff = new Date().getTime() - Number(GM_getValue("lastReportedUsage"));
        if(!GM_getValue("lastReportedUsage") || dateDiff > (1000 * 60 * 60 * 24 * 7)){ // Only report every 7 days
            var uid = GM_getValue("uid");   // Use a randomly generated ID to anonomyze users
            if(!uid){
                uid = uuidv4();
                GM_setValue("uid", uid);
            }
            var url = `https://0s62bmu3aj.execute-api.us-east-1.amazonaws.com/PROD/pixel/tracker?PixelID=07b619a3-0ef7-c013-63f9-35794e0bc09b&UserID=${uid}`;
            GM_xmlhttpRequest({
                method: 'GET',
                url: url,
                onload: function (response) {
                    if (response.readyState == 4 && this.status == 200) {
                        GM_setValue("lastReportedUsage", new Date().getTime());
                    }
                }
            }); 
    
        }
    }
    
    // https://stackoverflow.com/questions/105034/how-to-create-a-guid-uuid
    function uuidv4() {
        return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
            (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
        );
    }
    
    function init(){
        var style = document.createElement("style");
        style.innerHTML = indicatorStyle;
        document.head.appendChild(style);
        timer = setInterval(tick, 1000);
        reportUsage();
    }
    
    init();
})();
