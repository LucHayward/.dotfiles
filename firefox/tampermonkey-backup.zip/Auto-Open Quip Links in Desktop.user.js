// ==UserScript==
// @name         Auto-Open Quip Links in Desktop
// @namespace    https://quip-amazon.com/
// @version      0.1
// @description  Quip links opened in a browser automatically launch the quip desktop app (if installed),
//               and then close the browser tab.
//               be sure to select "always allow pop-ups from this site" when the first attempt gets blocked.
// @author       mde, ambadkar
// @match        https://*quip-amazon.com/*
// @exclude      https://*quip-amazon.com/account/login*
// @run-at       document-end
// @grant        window.close
// @downloadURL	 https://drive.corp.amazon.com/view/mde@/Shared/Tampermonkey/auto-open-quip.user.js
// ==/UserScript==

(function() {
    'use strict';

    var quipID = document.URL.replace(/.*quip-amazon.com\//, "").replace(/\/.*/, "").trim();
    if (quipID) {
        var newWindow = window.open("quip://" + quipID);
        if(newWindow) {
            setTimeout(function () {
                newWindow.close();
                //window.close();
            }, 1000);
        }
    }
})();
