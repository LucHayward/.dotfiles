// ==UserScript==
// @name           String Links
// @downloadURL https://improvement-ninjas.amazon.com/GreaseMonkey/stringLinks.amazon.user.js
// @updateURL https://improvement-ninjas.amazon.com/GreaseMonkey/stringLinks.amazon.user.js
// @namespace      http://amazon.com/dept/monitoring
// @description    2.0.70: Support for Antidote Links for Apollo Environments, VIPs, ASGs and Hosts
// @version        2070
// @grant          GM_addStyle
// @grant          GM_getValue
// @grant          GM_log
// @grant          GM_registerMenuCommand
// @grant          GM_setValue
// @grant          GM_setClipboard
// @grant          GM_xmlhttpRequest
// @grant          unsafeWindow
// @include        http://*.amazon.*/*
// @include        https://*.amazon.*/*
// @include        https://*console.aws.amazon.*/cloudwatch/home
// @include        https://*.console.amazonaws.cn/cloudwatch/home
// @include        https://console.c2shome.ic.gov/cloudwatch/home
// @include        https://console.sc2shome.sgov.gov/cloudwatch/home
// @include        https://console.amazonaws-us-gov.com/cloudwatch/home
// @exclude        https://arcturus.amazon.com/accesspoints/*/search?*
// @exclude        http*://aws-tools.amazon.com/*
// @exclude        https://grc.amazon.com/*/edit/*
// @exclude        https://hire.amazon.com/*
// @exclude        http*://apollo.amazon.*/r/*
// @exclude        http*://code.amazon.com/*
// @exclude        http*://w.amazon.*/bin/edit/*
// @exclude        http*://vip-management*.amazon.com/vipmgmt/CreateVip*
// @exclude        http*://apollo.amazon.com/operational_configuration.html?*
// @exclude        http*://hammerstone-permissions*.amazon.*/*
// @exclude        http*://*.promise-analyzer.promise.amazon.dev/*
// @exclude        http*://*.quicksight.aws.amazon.com/*
// ==/UserScript==

var StringLinksGM;

function isGM() {
    return typeof GM_getValue != 'undefined' && typeof GM_getValue('a', 'b') != 'undefined';
}

function codeWrapper(isGM) {
    var log, setValue, getValue, addStyle, copyValueToClipboard;   // Aliases for GM_setValue etc methods, for non-GM browsers, e.g. Chrome
    var activePopup = null;

function MonitoringTeamStringLinks() {
    var STRING_LIMIT = 5000;
    var POPUP = "popup";
    var HIDDEN = "hidden";
    var COPY = "copy";
    var LINK_REPLACEMENT_BATCH_SIZE = 50;      // We replace links on the page in batches of this size to improve browser responsiveness
    var LINK_REPLACEMENT_BATCH_INTERVAL = 100; // We sleep for this many milliseconds between batches to allow the browser to process UI events
    var isDecorating = false;

    var HOST_LINKS = [
        {
           id: "mp",
           url: [
               { match: "[.]dca", url: "https://monitorportal.dca.amazon.com/hosts/overview?&name={STRING}" },
               { match: null,     url: "https://monitorportal.amazon.com/hosts/overview?&name={STRING}" }
           ],
           title: "Monitor Portal overview",
           category: "Monitoring",
           color: "black", backgroundColor: "yellow",
        },
        {
           id: "sym",
           url: [
               { match: "[.]dca", url: "https://monitor.dca.amazon.com/symon/verify.cgi?%5Fencoding=UTF8&host={STRING}" },
               { match: null,     url: "https://monitor.amazon.com/symon/verify.cgi?%5Fencoding=UTF8&host={STRING}" }
           ],
           title: "SYMON Verify",
           category: "Monitoring",
           color: "black", backgroundColor: "#00ff00",
        },
        {
           id: "emo",
           url: [
               { match: "[.]dca", url: null },
               { match: null,     url: "https://monitor.amazon.com/symon/hostping.cgi?step=search&hostname={STRING}&hostclass=" }
           ],
           title: "External Monitoring Config",
           category: "Monitoring",
           color: "#00ff00", backgroundColor: "black",
        },
        {
           id: "igr",
           url: [
               { match: "[.]dca", url: "https://monitorportal.dca.amazon.com/igraph?StartTime1=-PT3H&EndTime1=-PT0M&DataSet1=prod&HostGroup1=NONE&Class1=CPU&Object1=cpu&Metric1=Utilization&Period1=OneMinute&Stat1=avg&SchemaName1=Snitch&Host1={STRING}&search=host={STRING}+schemaname=Snitch" },
               { match: null,     url: "https://monitorportal.amazon.com/igraph?StartTime1=-PT3H&EndTime1=-PT0M&DataSet1=prod&HostGroup1=NONE&Class1=CPU&Object1=cpu&Metric1=Utilization&Period1=OneMinute&Stat1=avg&SchemaName1=Snitch&Host1={STRING}&search=host={STRING}+schemaname=Snitch" }
           ],
           title: "iGraph (CPU)",
           category: "Monitoring",
           color: "#FFFFFF", backgroundColor: "#7091BB",
           open: HIDDEN,
        },
        {
           id: "tim",
           url: [
               { match: "[.]dca", url: null },
               { match: null,     url: "https://monitorportal.amazon.com/timber/list?key1=host&value1={STRING}" }
           ],
           title: "Timber Logs",
           category: "Monitoring",
           color: "#FFFFFF", backgroundColor: "#966D30",
        },
        {
           id: "ssh",
           url: "ssh://{STRING}",
           title: "SSH",
           category: "SSH",
           color: "white", backgroundColor: "#ff6600",
        },
        {
           id: "ssb",
           url: "ssh://{STRING}",
           title: "SSH via Bastion",
           category: "SSH",
           color: "white", backgroundColor: "#cc3300",
        },
        {
           id: "hos",
           url: [
               { match: "[.]dca", url: "https://infrastructure.dca.amazon.com/automation/hostDetails.cgi?hw_id=&hostname={STRING}&show_reboots=on&show_ticket_log=on" },
               { match: null,     url: "https://infrastructure.amazon.com/automation/hostDetails.cgi?hw_id=&hostname={STRING}&show_reboots=on&show_ticket_log=on" }
           ],
           title: "Host Details",
           category: "Infrastructure",
           color: "white", backgroundColor: "#0084ff",
        },
        {
           id: "reb",
           url: [
               { match: "[.]dca", url: "https://infrastructure.dca.amazon.com/automation/rebootServer.cgi?%5Fencoding=UTF8&hostname={STRING}&reason=Can't%20ping%20it" },
               { match: null,     url: "https://infrastructure.amazon.com/automation/rebootServer.cgi?%5Fencoding=UTF8&hostname={STRING}&reason=Can't%20ping%20it" }
           ],
           title: "Reboot Host",
           category: "Infrastructure",
           color: "white", backgroundColor: "red",
        },
        {
           id: "rep",
           url: [
               { match: "[.]dca", url: "https://infrastructure.dca.amazon.com/automation/repurposeSelectHosts.cgi?hostname_regex={STRING}" },
               { match: null,     url: "https://infrastructure.amazon.com/automation/repurposeSelectHosts.cgi?hostname_regex={STRING}" }
           ],
           title: "Repurpose Host",
           category: "Infrastructure",
           color: "black", backgroundColor: "#E851E3",
        },
        {
           id: "swp",
           url: [
               { match: "[.]dca", url: "https://infrastructure.dca.amazon.com/automation/hostSwapSelectHosts.cgi?hostname_regex={STRING}" },
               { match: null,     url: "https://infrastructure.amazon.com/automation/hostSwapSelectHosts.cgi?hostname_regex={STRING}" }
           ],
           title: "Swap Host",
           category: "Infrastructure",
           color: "black", backgroundColor: "#E851E3",
        },
        {
           id: "ser",
           url: [
               { match: "[.]dca", url: null },
               { match: null,     url: "https://lbdashboard.amazon.com/cgi-bin/showservices.cgi?input={STRING}&lbGroup=all&action=Find+Server&collateServices=on&resolveIPs=on" }
           ],
           title: "Show Services",
           category: "Infrastructure",
           color: "white", backgroundColor: "blue",
        },
        {
           id: "vip",
           url: [
               { match: "[.]bjs|[.]cn-north-1",     url: "https://vip-management.bjs.aws-border.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]bom|[.]ap-south-1",     url: "https://vip-management.bom.aws-border.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]cmh|[.]us-east-2",      url: "https://vip-management.cmh.aws-border.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]dca",                   url: "https://vip-management.dca.amazon.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]dub|[.]eu-west-1",      url: "https://vip-management-dub.amazon.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]fra|[.]eu-central-1",   url: "https://vip-management.fra.aws-border.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]gru|[.]sa-east-1",      url: "https://vip-management-gru.amazon.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]icn|[.]ap-northeast-2", url: "https://vip-management.icn.aws-border.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]lhr|[.]eu-west-2",      url: "https://vip-management.lhr.aws-border.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]nrt|[.]ap-northeast-1", url: "https://vip-management-nrt.amazon.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]pdt|[.]us-gov-west-1",  url: "https://vip-management.pdt.amazon.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]pdx|[.]us-west-2",      url: "https://vip-management.pdx.amazon.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]pek",                   url: "https://vip-management-pek.amazon.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]sea",                   url: "https://vip-management-sea.amazon.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]sfo|[.]us-west-1",      url: "https://vip-management-sfo.amazon.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]sin|[.]ap-southeast-1", url: "https://vip-management-sin.amazon.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]syd|[.]ap-southeast-2", url: "https://vip-management-syd.amazon.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]yul|[.]ca-central-1",   url: "https://vip-management.yul.aws-border.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: "[.]zhy|[.]cn-northwest-1", url: "https://vip-management.zhy.aws-border.com/vipmgmt/StartWithHost.mhtml?host={STRING}" },
               { match: null,                       url: "https://vip-management.amazon.com/vipmgmt/StartWithHost.mhtml?host={STRING}" }
           ],
           title: "VIPs fronting host",
           category: "Infrastructure",
           color: "white", backgroundColor: "#9400d3",
        },
        {
           id: "vnm",
           url: [
               { match: "[.]dca", url: "http://vip-management.dca.amazon.com/vipmgmt/StartWithDnsName.mhtml?vip={STRING}" },
               { match: null,     url: "http://vip-management.amazon.com/vipmgmt/StartWithDnsName.mhtml?vip={STRING}" }
           ],
           title: "VIP with same name",
           category: "Infrastructure",
           color: "white", backgroundColor: "#9400d3",
        },
        {
           id: "tos",
           url: [
               { match: "[.]bjs|[.]cn-north-1",       url: "https://toaster-bjs.amazon.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]bom|[.]ap-south-1",       url: "https://toaster.bom.aws-border.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]cdg|[.]eu-west-3",        url: "https://toaster.cdg.aws-border.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]cmh|[.]us-east-2",        url: "https://toaster.cmh.aws-border.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]dca",                     url: "https://toaster.dca.amazon.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]dub|[.]eu-west-1",        url: "https://toaster-dub.amazon.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]fra|[.]eu-central-1",     url: "https://toaster.fra.aws-border.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]gru|[.]sa-east-1",        url: "https://toaster-gru.amazon.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]iad|[.]vdc|[.]us-east-1", url: "https://toaster-iad.amazon.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]icn|[.]ap-northeast-2",   url: "https://toaster.icn.aws-border.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]kix|[.]ap-northeast-3",   url: "https://toaster.kix.aws-border.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]lck|[.]us-isob-east-1",   url: "https://toaster.lck.aws-border.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]lhr|[.]eu-west-2",        url: "https://toaster.lhr.aws-border.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]nrt|[.]ap-northeast-1",   url: "https://toaster-nrt.amazon.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]pdx|[.]us-west-2",        url: "https://toaster-pdx.amazon.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]sfo|[.]us-west-1",        url: "https://toaster-sfo.amazon.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]sin|[.]ap-southeast-1",   url: "https://toaster-sin.amazon.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]syd|[.]ap-southeast-2",   url: "https://toaster-syd.amazon.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]yul|[.]ca-central-1",     url: "https://toaster.yul.aws-border.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: "[.]zhy|[.]cn-northwest-1",   url: "https://toaster-zhy.amazon.com/cgi-bin/toaster.cgi?host={STRING}" },
               { match: null,                         url: "https://toaster.amazon.com/cgi-bin/toaster.cgi?host={STRING}" }
           ],
           title: "Toaster Host Checker",
           category: "Infrastructure",
           color: "white",
           backgroundColor: "#008455"
        },
        {
           id: "apo",
           url: [
               { match: "[.]dca", url: "https://apollo.dca.amazon.com/hosts/{STRING}" },
               { match: null,     url: "https://apollo.amazon.com/hosts/{STRING}" }
           ],
           title: "Apollo Environments",
           category: "Other",
           color: "black", backgroundColor: "white",
        },
        {
           id: "odi",
           url: [
               { match: "[.]dca", url: "https://odin.dca.amazon.com/#search/materialSetsPage=0&namespacesPage=0&searchCategory=EndHost&searchInactive=false&searchQuery={STRING}&searchGroup=true" },
               { match: null,     url: "https://odin.amazon.com/#search/materialSetsPage=0&namespacesPage=0&searchCategory=EndHost&searchInactive=false&searchQuery={STRING}&searchGroup=true" }
           ],
           title: "Odin Material Sets",
           category: "Other",
           color: "#E47911", backgroundColor: "white",
        },
        {
           id: "tt",
           url: [
               { match: "[.]dca", url: "https://issues.dca.amazon.com/issues/search?mode=search&sort=score%20desc&q={STRING}" },
               { match: null,     url: "https://tt.amazon.com/search?ticket_type=Regular+Ticket&status=&create_date=&modified_date=&assigned_individual=&impact=&requester_login=&cc_email=&category=&type=&item=&hostname={STRING}&asin=&upc=&vendor_id=&purchase_order_id=&sort1=create_date&sortdir1=desc&sort2=&sortdir2=asc&sort3=&sortdir3=asc&assigned_group=&case_type=&custom_fields_serialized=hostname&search=Search!" }
           ],
           title: "Search for Issues",
           category: "Other",
           color: "white", backgroundColor: "blue",
        },
        {
            id: "ant",
            url: "https://antidote.corp.amazon.com/host?host_name={STRING}",
            title: "Antidote - Host Explorer",
            category: "Other",
            color: "white", backgroundColor: "orange"
        },
    ];

    var ssbHostLinksIndex = 0;
    for (var i = 0; i < HOST_LINKS.length; i++) {
        if (HOST_LINKS[i].id === 'ssb') {
            ssbHostLinksIndex = i;
            break;
        }
    }

    var HOSTCLASS_LINKS = [
        {
           id: "mp",
           url: [
               { match: "-DCA|-WMA", url: "https://monitorportal.dca.amazon.com/hostclasses_hosts/overview?&name={STRING}" },
               { match: null,        url: "https://monitorportal.amazon.com/hostclasses_hosts/overview?&name={STRING}" }
           ],
           title: "Monitor Portal overview",
           category: "Monitoring",
           color: "black", backgroundColor: "yellow",
        },
        {
           id: "emo",
           url: [
               { match: "-DCA|-WMA", url: null },
               { match: null,        url: "https://monitor.amazon.com/symon/hostping.cgi?step=search&hostclass={STRING}&hostname=" }
           ],
           title: "External Monitoring Config",
           category: "Monitoring",
           color: "#00ff00", backgroundColor: "black",
        },
        {
           id: "lw",
           url: [
               { match: "-DCA|-WMA", url: null },
               { match: null,        url: "https://livewatch.amazon.com/hostclasses/{STRING}/any/metrics" }
           ],
           title: "LiveWatch graphs",
           category: "Monitoring",
           color: "white", backgroundColor: "blue",
        },
        {
           id: "id",
           url: [
               { match: "-DCA|-WMA", url: "https://infrastructure.dca.amazon.com/automation/customerHome.cgi?_encoding=UTF8&hostclass={STRING}" },
               { match: null,        url: "https://infrastructure.amazon.com/automation/customerHome.cgi?_encoding=UTF8&hostclass={STRING}" }
           ],
           title: "Infrastructure Dashboard",
           category: "Infrastructure",
           color: "black", backgroundColor: "#87cefa",
        },
        {
           id: "per",
           url: [
               { match: "-DCA|-WMA", url: "https://permissions.dca.amazon.com/hostclass.mhtml?show_ownership=1&hostclass={STRING}" },
               { match: null,        url: "https://permissions.amazon.com/hostclass.mhtml?show_ownership=1&hostclass={STRING}" }
           ],
           title: "Permissions",
           category: "Infrastructure",
           color: "black", backgroundColor: "#FFCCCC",
        },
        {
           id: "chc",
           url: [
               { match: "-DCA|-WMA", url: "https://infrastructure.dca.amazon.com/automation/createHostclass.cgi?parent_hostclass=OTHER&other_hostclass={STRING}&hostclass={STRING}-" },
               { match: null,        url: "https://infrastructure.amazon.com/automation/createHostclass.cgi?parent_hostclass=OTHER&other_hostclass={STRING}&hostclass={STRING}-" }
           ],
           title: "Create Child Hostclass",
           category: "Infrastructure",
           color: "white", backgroundColor: "#5D41F3",
        },
        {
           id: "rep",
           url: [
               { match: "-DCA|-WMA", url: "https://infrastructure.dca.amazon.com/automation/repurposeSelectHosts.cgi?hostclass_regex={STRING}" },
               { match: null,        url: "https://infrastructure.amazon.com/automation/repurposeSelectHosts.cgi?hostclass_regex={STRING}" }
           ],
           title: "Repurpose Hostclass",
           category: "Infrastructure",
           color: "black", backgroundColor: "#E851E3",
        },
        {
           id: "ser",
           url: [
               { match: "-DCA|-WMA", url: null },
               { match: null,        url: "https://lbdashboard.amazon.com/cgi-bin/showservices.cgi?input={STRING}&lbGroup=all&action=Find+Hostclass&collateServices=on&resolveIPs=on" }
           ],
           title: "Show Services",
           category: "Infrastructure",
           color: "white", backgroundColor: "#999966",
        },
        {
           id: "vip",
           url: [
               { match: "-ARN", url: "https://vip-management.arn.aws-border.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-BAH", url: "https://vip-management.bah.aws-border.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-BJS", url: "https://vip-management.bjs.aws-border.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-BOM", url: "https://vip-management.bom.aws-border.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-CMH", url: "https://vip-management.cmh.aws-border.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-DUB", url: "https://vip-management-dub.amazon.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-FRA", url: "https://vip-management.fra.aws-border.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-HKG", url: "https://vip-management-hkg.aws-border.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-GRU", url: "https://vip-management-gru.amazon.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-IAD", url: "https://vip-management-iad.amazon.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-ICN", url: "https://vip-management.icn.aws-border.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-KIX", url: "https://vip-management.kix.aws-border.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-LHR", url: "https://vip-management.lhr.aws-border.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-NRT", url: "https://vip-management-nrt.amazon.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-PDT", url: "https://vip-management.pdt.amazon.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-PDX", url: "https://vip-management.pdx.amazon.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-PEK", url: "https://vip-management-pek.amazon.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-SEA", url: "https://vip-management-sea.amazon.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-SFO", url: "https://vip-management-sfo.amazon.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-SIN", url: "https://vip-management-sin.amazon.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-SYD", url: "https://vip-management-syd.amazon.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-YUL", url: "https://vip-management.yul.aws-border.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-ZHY", url: "https://vip-management.zhy.aws-border.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: "-DCA|-WMA", url: "http://vip-management.dca.amazon.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" },
               { match: null,        url: "http://vip-management.amazon.com/vipmgmt/StartWithHostclass.mhtml?hostclass={STRING}" }
           ],
           title: "Show VIPs",
           category: "Infrastructure",
           color: "white", backgroundColor: "#9400d3",
        },
        {
           id: "tos",
           url: [
               { match: "-DCA|-WMA", url: "https://toaster.dca.amazon.com/cgi-bin/hostclass.cgi?hostclass={STRING}" },
               { match: null,        url: "https://toaster.amazon.com/cgi-bin/hostclass.cgi?hostclass={STRING}" }
           ],
           title: "Toaster Hostclass Checker",
           category: "Infrastructure",
           color: "white",
           backgroundColor: "#008455"
        },
        {
           id: "apo",
           url: [
               { match: "-DCA|-WMA", url: "https://apollo.dca.amazon.com/hosts/{STRING}" },
               { match: null,        url: "https://apollo.amazon.com/hosts/{STRING}" }
           ],
           title: "Apollo Environments",
           category: "Other",
           color: "black", backgroundColor: "white",
        },
        {
           id: "odi",
           url: [
               { match: "-DCA|-WMA", url: "https://odin.dca.amazon.com/#search/materialSetsPage=0&namespacesPage=0&searchCatagory=HostClass&searchInactive=false&searchQuery={STRING}&searchGroup=true" },
               { match: null,        url: "https://odin.amazon.com/#search/materialSetsPage=0&namespacesPage=0&searchCatagory=HostClass&searchInactive=false&searchQuery={STRING}&searchGroup=true" }
           ],
           title: "Odin Material Sets",
           category: "Other",
           color: "#E47911", backgroundColor: "white",
        }
    ];

    var VIP_LINKS = [
        {
           id: "vip",
           url: [
               { match: "[.]dca", url: "http://vip-management.dca.amazon.com/vipmgmt/StartWithDnsName.mhtml?vip={STRING}" },
               { match: null,     url: "http://vip-management.amazon.com/vipmgmt/StartWithDnsName.mhtml?vip={STRING}" }
           ],
           title: "Show VIPs",
           category: "Infrastructure",
           color: "white", backgroundColor: "#9400d3",
        },
        {
            id: "ant",
            url: [
                { match: "[.]iad|[.]us-east-1", url: "https://antidote.corp.amazon.com/vip?vip={STRING}&region=iad" },
                { match: "[.]dub|[.]eu-west-1", url: "https://antidote.corp.amazon.com/vip?vip={STRING}&region=dub" },
                { match: "[.]pdx|[.]us-west-2", url: "https://antidote.corp.amazon.com/vip?vip={STRING}&region=pdx" },
                { match: "[.]pek",              url: "https://antidote.corp.amazon.com/vip?vip={STRING}&region=pek" },
                { match: "[.]corp",             url: "https://antidote.corp.amazon.com/vip?vip={STRING}&region=corp" },
                { match: null,                  url: "https://antidote.corp.amazon.com/vip?vip={STRING}" }
            ],
            title: "Antidote - VIP Explorer",
            category: "Other",
            color: "white", backgroundColor: "orange",
        },
        {
           id: "ser",
           url: [
               { match: "[.]dca", url: null },
               { match: null,     url: "https://lbdashboard.amazon.com/cgi-bin/showservices.cgi?input={STRING}&lbGroup=all&action=Find+VIP&collateServices=on&resolveIPs=on" }
           ],
           title: "Show Services",
           category: "Infrastructure",
           color: "white", backgroundColor: "#999966",
        },
        {
           id: "cer",
           url: [
               { match: "[.]dca", url: "http://vip-management.dca.amazon.com/certificates/?dns={STRING}" },
               { match: null,     url: "http://vip-management.amazon.com/certificates/?dns={STRING}" }
           ],
           title: "Certificates",
           category: "Infrastructure",
           color: "yellow", backgroundColor: "#006400",
        },
        {
            id: "wib",
            url: "http://willitblend.amazon.com/fqdn/{STRING}",
            title: "WillItBlend VIP Checker",
            category: "Infrastructure",
            color: "#00FF00", backgroundColor: "black",
        },
    ];

    var ASIN_LINKS = [
        {
           id: "us",
           url: "https://www.amazon.com/dp/{STRING}",
           title: "US Detail Page",
           category: "NA",
           color: "black", backgroundColor: "#ffa500",
        },
        {
           id: "ca",
           url: "https://www.amazon.ca/dp/{STRING}",
           title: "CA Detail Page",
           category: "NA",
           color: "black", backgroundColor: "#ffa500",
        },
        {
           id: "uk",
           url: "https://www.amazon.co.uk/dp/{STRING}",
           title: "UK Detail Page",
           category: "EU",
           color: "black", backgroundColor: "#ffa500",
        },
        {
           id: "de",
           url: "https://www.amazon.de/dp/{STRING}",
           title: "DE Detail Page",
           category: "EU",
           color: "black", backgroundColor: "#ffa500",
        },
        {
           id: "fr",
           url: "https://www.amazon.fr/dp/{STRING}",
           title: "FR Detail Page",
           category: "EU",
           color: "black", backgroundColor: "#ffa500",
        },
        {
           id: "jp",
           url: "https://www.amazon.co.jp/dp/{STRING}",
           title: "JP Detail Page",
           category: "FE",
           color: "black", backgroundColor: "#ffa500",
        },
        {
           id: "cn",
           url: "https://www.amazon.cn/dp/{STRING}",
           title: "CN Detail Page",
           category: "CN",
           color: "black", backgroundColor: "#ffa500",
        },
        {
           id: "dse",
           url: "https://gcs.amazon.com/datastore-explorer.cgi?asin={STRING}&entity=all&depth=-1&colour=99CCFF&keephtml=true&x=9&y=20",
           title: "Datastore Explorer",
           category: "ASIN",
           color: "black", backgroundColor: "green",
        }
    ];

    var TT_LINKS = [
        {
           id: "tt",
           url: "https://tt.amazon.com/{STRING}",
           title: "Trouble Ticket",
           category: "Remedy",
           color: "white", backgroundColor: "blue",
        }
    ];

    var ENV_LINKS = [
        {
           id: "apo",
           url: "https://apollo.amazon.com/environments/{STRING}",
           title: "Apollo Environment",
           category: "Apollo",
           color: "black", backgroundColor: "white",
        },
        {
           id: "ant",
           url: "https://antidote.corp.amazon.com/environment?env={STRING}",
           title: "Antidote - Environment Explorer",
           category: "Other",
           color: "white", backgroundColor: "orange"
        }
    ];

    var LINK_LINKS = [
        {
           id: "lnk",
           url: "{STRING}",
           title: "Open URL",
           category: "Links",
           color: "black", backgroundColor: "yellow"
        },
        {
           id: "pop",
           url: "{STRING}",
           title: "Open URL in Popup",
           category: "Links",
           color: "black", backgroundColor: "cyan",
           open: POPUP
        }
    ];

    var ENV_PREVIEW_LINK_LINKS = [
        {
           id: "alp",
           url: "https://apollo.amazon.com/operational_configuration.html?environmentId={STRING}&stage=Alpha&opConfigAction=preview",
           title: "Preview Op Config - Alpha",
           category: "Apollo Preview",
           color: "black", backgroundColor: "yellow"
        },
        {
           id: "bet",
           url: "https://apollo.amazon.com/operational_configuration.html?environmentId={STRING}&stage=Beta&opConfigAction=preview",
           title: "Preview Op Config - Beta",
           category: "Apollo Preview",
           color: "black", backgroundColor: "yellow"
        },
        {
           id: "gam",
           url: "https://apollo.amazon.com/operational_configuration.html?environmentId={STRING}&stage=Gamma&opConfigAction=preview",
           title: "Preview Op Config - Gamma",
           category: "Apollo Preview",
           color: "black", backgroundColor: "yellow"
        },
        {
           id: "prd",
           url: "https://apollo.amazon.com/operational_configuration.html?environmentId={STRING}&stage=Prod&opConfigAction=preview",
           title: "Preview Op Config - Prod",
           category: "Apollo Preview",
           color: "black", backgroundColor: "yellow"
        }
    ];

    var ASG_LINKS = [
        {
           id: "arc",
           url: "https://arcturus.amazon.com/autoscaling/group?auto_scaling_group={STRING}&namespace=963362704314",
           title: "Arcturus - AutoScaling Group",
           category: "AWS",
           color: "white", backgroundColor: "blue"
        },
        {
            id: "ant",
            url: "https://antidote.corp.amazon.com/asg?asg_id={STRING}",
            title: "Antidote - ASG Explorer",
            category: "Other",
            color: "white", backgroundColor: "orange"
        }
    ];

    var CM_LINKS = [
        {
           id: "cm",
           url: "https://cm.amazon.com/{STRING}",
           title: "Change Management (CM)",
           category: "Remedy",
           color: "black", backgroundColor: "#ffd39b",
        }
    ];

    var WEBLAB_LINKS = [
        {
           id: "wl",
           url: "https://weblab.amazon.com/exec/search?query={STRING}&allowRedirect=true&a=execSearch",
           title: "Weblab",
           category: "Weblab",
           color: "black", backgroundColor: "yellow",
        }
    ];

    var PASTURE_LINKS = [
        {
           id: "us",
           url: "https://greener-na.aka.amazon.com/GreenerPasture/#objectId=USAmazon:{STRING}",
           title: "US Pasture",
           category: "NA",
           color: "black", backgroundColor: "lightgreen",
        },
        {
           id: "ca",
           url: "https://greener-na.aka.amazon.com/GreenerPasture/#objectId=CAAmazon:{STRING}",
           title: "CA Pasture",
           category: "NA",
           color: "black", backgroundColor: "lightgreen",
        },
        {
           id: "gb",
           url: "https://greener-eu.aka.amazon.com/GreenerPasture/#objectId=GBAmazon:{STRING}",
           title: "GB Pasture",
           category: "EU",
           color: "black", backgroundColor: "lightgreen",
        },
        {
           id: "fr",
           url: "https://greener-eu.aka.amazon.com/GreenerPasture/#objectId=FRAmazon:{STRING}",
           title: "FR Pasture",
           category: "EU",
           color: "black", backgroundColor: "lightgreen",
        },
        {
           id: "de",
           url: "https://greener-eu.aka.amazon.com/GreenerPasture/#objectId=DEAmazon:{STRING}",
           title: "DE Pasture",
           category: "EU",
           color: "black", backgroundColor: "lightgreen",
        },
        {
           id: "jp",
           url: "https://greener-fe.aka.amazon.com/GreenerPasture/#objectId=JPAmazon:{STRING}",
           title: "JP Pasture",
           category: "FE",
           color: "black", backgroundColor: "lightgreen",
        },
        {
           id: "cn",
           url: "https://greener-cn.aka.amazon.com/GreenerPasture/#objectId=CNAmazon:{STRING}",
           title: "CN Pasture",
           category: "CN",
           color: "black", backgroundColor: "lightgreen",
        }

    ];

    var AWS_ACCOUNT_ID_LINKS = [
        {
           id: "sot",
           url: "https://aws-tools.amazon.com/servicetools/search.aws?searchType=ACCOUNT&query={STRING}",
           title: "Service Owner Tool",
           category: "Identification",
           color: "black", backgroundColor: "yellow",
        },
        {
            id: "iam",
            url: "https://iam-tools.amazon.com/accounts/{STRING}",
            title: "IAM Support Tool",
            category: "Identification",
            color: "black", backgroundColor: "#ffa500",
        },
        {
            id: "isn",
            url: "https://isengard.amazon.com/roles/{STRING}",
            title: "Isengard (AWS teams)",
            category: "Identification",
            color: "black", backgroundColor: "#00ff00",
        },
        {
           id: "cwm",
           url: "https://arcturus.amazon.com/cloudwatch?cluster=prod-iad&account={STRING}&commit=fetch+metrics",
           title: "CloudWatch Metrics us-east-1",
           category: "Monitoring",
           color: "#00ff00", backgroundColor: "black",
        },
        {
           id: "cwa",
           url: "https://arcturus.amazon.com/alarms/account?cluster=prod-iad&account={STRING}&commit=Search",
           title: "CloudWatch Alarms us-east-1",
           category: "Monitoring",
           color: "#FFFFFF", backgroundColor: "#7091BB",
        },
    ];

    var CUSTOMERID_LINKS = [
        {
           id: "5d",
           url: "https://atv-pex-tools-na.amazon.com/customer_events_tool.do?customerIdEmail={STRING}&streamingSessionId=&asin=&deviceTypeId=All&timeSelector=on&isFixedTime=false&startTime=5days&endTime=0days",
           title: "5 days QoS",
           color: "black", backgroundColor: "#ffa500",
        },
        {
           id: "10d",
           url: "https://atv-pex-tools-na.amazon.com/customer_events_tool.do?customerIdEmail={STRING}&streamingSessionId=&asin=&deviceTypeId=All&timeSelector=on&isFixedTime=false&startTime=10days&endTime=0days",
           title: "10 days QoS",
           color: "black", backgroundColor: "#ffa500",
        },
        {
           id: "15d",
           url: "https://atv-pex-tools-na.amazon.com/customer_events_tool.do?customerIdEmail={STRING}&streamingSessionId=&asin=&deviceTypeId=All&timeSelector=on&isFixedTime=false&startTime=15days&endTime=0days",
           title: "15 days QoS",
           color: "black", backgroundColor: "#ffa500",
        },
        {
           id: "20d",
           url: "https://atv-pex-tools-na.amazon.com/customer_events_tool.do?customerIdEmail={STRING}&streamingSessionId=&asin=&deviceTypeId=All&timeSelector=on&isFixedTime=false&startTime=20days&endTime=0days",
           title: "20 days QoS",
           color: "black", backgroundColor: "#ffa500",
        },
        {
           id: "25d",
           url: "https://atv-pex-tools-na.amazon.com/customer_events_tool.do?customerIdEmail={STRING}&streamingSessionId=&asin=&deviceTypeId=All&timeSelector=on&isFixedTime=false&startTime=25days&endTime=0days",
           title: "25 days QoS",
           color: "black", backgroundColor: "#ffa500",
        },
        {
           id: "30d",
           url: "https://atv-pex-tools-na.amazon.com/customer_events_tool.do?customerIdEmail={STRING}&streamingSessionId=&asin=&deviceTypeId=All&timeSelector=on&isFixedTime=false&startTime=30days&endTime=0days",
           title: "30 days QoS",
           // category: "NA",
           color: "black", backgroundColor: "#ffa500",
        },
    ];

    var CODE_LINKS = [
        {
           id: "vs",
           url: "https://code.amazon.com/version-sets/{STRING}",
           title: "Version Set",
           category: "Version Set",
           color: "black", backgroundColor: "yellow",
        },
        {
           id: "cb",
           url: "https://code.amazon.com/packages/{STRING}",
           title: "Code Browse",
           category: "Code",
           color: "black", backgroundColor: "yellow",
        },
        {
           id: "apo",
           url: "https://apollo.amazon.com/environments/{STRING}",
           title: "Apollo Environment",
           category: "Apollo",
           color: "black", backgroundColor: "white",
        },
    ];

    var EC2_INSTANCE_LINKS = [
        {
           id: "adm",
           url: "https://admiral-iad.ec2.amazon.com/search?q={STRING}",
           title: "EC2 Admiral",
           category: "Admiral",
           color: "black", backgroundColor: "pink",
        }
    ];

    var LINK_DEFS = [
        { id: "ASG_LINKS",
          links: ASG_LINKS
        },
        { id: "ASIN_LINKS",
          links: ASIN_LINKS
        },
        { id: "CM_LINKS",
          links: CM_LINKS
        },
        { id: "ENV_LINKS",
          links: ENV_LINKS
        },
        { id: "ENV_PREVIEW_LINK_LINKS",
          links: ENV_PREVIEW_LINK_LINKS
        },
        { id: "HOSTCLASS_LINKS",
          links: HOSTCLASS_LINKS
        },
        { id: "HOST_LINKS",
          links: HOST_LINKS
        },
        { id: "LINK_LINKS",
          links: LINK_LINKS
        },
        { id: "PASTURE_LINKS",
          links: PASTURE_LINKS
        },
        { id: "TT_LINKS",
          links: TT_LINKS
        },
        { id: "VIP_LINKS",
          links: VIP_LINKS
        },
        { id: "CUSTOMERID_LINKS",
          links: CUSTOMERID_LINKS
        },
        { id: "AWS_ACCOUNT_ID_LINKS",
          links: AWS_ACCOUNT_ID_LINKS
        },
        { id: "WEBLAB_LINKS",
          links: WEBLAB_LINKS
        },
        { id: "CODE_LINKS",
          links: CODE_LINKS
        },
        { id: "EC2_INSTANCE_LINKS",
          links: EC2_INSTANCE_LINKS
        }
    ];

    var DC_MATCH = "vdc|[a-z][a-z][a-z][0-9]+|desktop|laptop|us-east-1[a-z]?|us-west-[0-9]|ap-northeast-[0-9]|ap-southeast-[0-9]|ap-south-[0-9]|eu-central-[0-9]|eu-west-[0-9]"

    // SUBSTITUTIONS specifies all the things on a page that should be matched and
    // decorated with links.  Each entry has the following required properties:
    //
    //   id: A short string indicating the category of entity being matched.
    //       All entries sharing the same ID will be enabled & disabled as a group.
    //   regexp: The pattern to match
    //   regexpFlags: The regexp flags to use in the pattern match
    //   string: The format of the input string given to the link generator(s).  The format string
    //           may contain:
    //               {REGEXPi}  : Will be substituted with the i-th (0-based) match group matched by regexp.
    //               {REGEXPiH} : Will be substituted with the i-th match group, URI encoded.
    //   defaultLinks: A comma-separated string containing the link IDs (see below) that should be enabled by default.
    //   links: The list of link generators for this substitution.  A generator is an object which takes the input string
    //          produced by the 'string' formatter above, and produces the link to insert.
    //          Each generator is an object with the following properties:
    //
    //              id: A short string indicating what type of link this generates.
    //              url: The href of the generated link, specified as a list of {match,url} pairs.
    //                   The first URL whose corresponding 'match' matches the input string is used. match:null
    //                   is used as the default URL if none of the others match.
    //                   Within the URL, {STRING} is substituted with the input string.
    //              color, backgroundColor: The color of the links
    //              title: Name of the link type in the configuration UI.
    //              category: Short string to group the configuration UI for different links together
    //              open: Says what to do when link is clicked:
    //                       (default): Normal browser link
    //                      "popup": Opens link in a popup window
    //                      "hidden": Opens the link without displaying it (for side-effects)
    //                      "copy":  Copies the matched text, instead of opening a link.
    //
    // A substitution may have the optional properties:
    //
    //   negativeRegexp: The pattern that disqualifies a piece of text from being linked, even if regexp matches.
    //   negativeRegexpFlags: The regexp matching flags to apply on negativeRegexp.
    //   siteRegexp: The pattern of page URLs which the matching will occur on. default is all pages.
    //   matchLinks: If true, matches against the href of links.  The default is false, which matches the page text.

    var SUBSTITUTIONS = {
        entries: [
           // Hostname matching and link configuration
           {
              id: "link",
              regexp: '(\\b([a-z][-a-z0-9+.]+://|www\\.)[^\\s\'"<>()]+)',
              regexpFlags: "gi",
              string: "{REGEXP0}",
              defaultLinks: "lnk,pop",
              links: LINK_LINKS,
           },
           {
              id: "host",
              // Look for <blah>.<blah>.<blah>.<blah>
              regexp: "\\b(([A-Za-z0-9-_]+[.]){2,}(amazon[.][a-z]+|[a-z0-9-]+[.]internal|[a-z0-9-]+[.]substrate|ec2.border|a9.com|amazonaws.com|co.[a-z][a-z]))\\b", 
              negativeRegexp: "\\b([.](arn|bah|bjs|bom|bpm|cdg|cgk|cmh|corp|cpt|dub|dxb|fra|gru|hkg|hyd|iad|icn|kix|lhr|lux|mel|mxp|ncl|nrt|pdx|pek|sfo|sin|syd|tlv|yul|yyc|zaz|zhy|zrh)[.]amazon.com)\\b",
              regexpFlags: "g",
              string: "{REGEXP0}",
              defaultLinks: "cd,ssh,ant",
              links: HOST_LINKS,
           },
           {
              id: "host",
              // Look for <blah>.<dc>
              regexp: "\\b([a-z][a-z0-9-.]+[.](" + DC_MATCH + "))\\b",
              regexpFlags: "g",
              string: "{REGEXP0}.amazon.com",
              defaultLinks: "cd,ssh,ant",
              links: HOST_LINKS,
           },
           // VIP matching and link configuration
           {
              id: "vip",
              regexp: "([a-z0-9-.]+[.]amazon[.]com)",
              regexpFlags: "g",
              string: "{REGEXP0}",
              defaultLinks: "ser,vip,ant",
              links: VIP_LINKS,
           },
           // Hostclass matching and link configuration
           {
              id: "hostclass",
              regexp: "\\b([A-Z][A-Z0-9-]{2,}-[A-Z0-9-]{3,}[A-Z0-9])\\b",
              negativeRegexp: "\\b(?:GMT-[0-9]{4})\\b",
              regexpFlags: "g",
              negativeRegexpFlags: "g",
              string: "{REGEXP0}",
              defaultLinks: "cd,vip",
              links: HOSTCLASS_LINKS,
           },
           // Auto-scaling Group Names
           {
              id: "asg",
              regexp: "\\b(([a-z_A-Z0-9-]{1,30}\/)+(Prod|Gamma|Beta|Alpha)\/-\/[A-Z_a-z0-9-]*)",
              regexpFlags: "g",
              string: "{REGEXP0}",
              defaultLinks: "cd,arc,ant",
              links: ASG_LINKS,
           },
           // Apollo environments string matching and link configuration
           {
              id: "apoenv",
              regexp: "\\b([a-z_A-Z0-9-/]{1,100})/(Prod|Gamma|Beta|Alpha)",
              regexpFlags: "g",
              string: "{REGEXP0}/-/stages/{REGEXP1}",
              defaultLinks: "apo,cd,ant",
              links: ENV_LINKS,
           },
           // Apollo environments preview links
           {
              id: "apoenvPreviewLink",
              regexp: "https://apollo.amazon.com/operational_configuration.html[?]environmentId=([0-9]*).*preview",
              regexpFlags: "",
              string: "{REGEXP0}",
              defaultLinks: "alp,bet,gam,prd",
              matchLinks: true,
              links: ENV_PREVIEW_LINK_LINKS,
           },
           // TT matching and link configuration
           {
              id: "tt",
              regexp: "\\b([E0][0-9]{9})\\b",
              regexpFlags: "g",
              string: "{REGEXP0}",
              defaultLinks: "tt",
              links: TT_LINKS,
           },
           // CM matching and link configuration
           {
              id: "cm",
              regexp: "\\b(1[0-9]{7})\\b",
              regexpFlags: "g",
              string: "{REGEXP0}",
              defaultLinks: "cm",
              links: CM_LINKS,
           },
           // Don't match stuff that doesn't look like ASINs
           {
              regexp: "\\b([A-Z]{10})\\b",
              regexpFlags: "g",
           },
           {
              regexp: "[@./-]\\b([0-9]{10})\\b",
              regexpFlags: "g",
           },
           // ASIN matching and link configuration
           {
              id: "asin",
              regexp: "\\b([A-Z1-9][A-Z0-9]{9})\\b(?![./-@])",
              regexpFlags: "g", string: "{REGEXP0}", defaultLinks: "us", links: ASIN_LINKS,
           },
           // AWS Account ID matching and link configuration
           {
              id: "aws",
              regexp: "\\b((\\d{4})-(\\d{4})-(\\d{4}))\\b",
              regexpFlags: "g", string: "{REGEXP1}{REGEXP2}{REGEXP3}", defaultLinks: "sot", links: AWS_ACCOUNT_ID_LINKS,
           },
           {
              id: "aws",
              regexp: "\\b(\\d{12})\\b",
              regexpFlags: "g", string: "{REGEXP0}", defaultLinks: "sot", links: AWS_ACCOUNT_ID_LINKS,
           },
           // Customer ID matching and link configuration
           {
              id: "cus",
              regexp: "\\b(A[A-Z0-9]{12,16})\\b",
              regexpFlags: "g", string: "{REGEXP0}", defaultLinks: "5d", links: CUSTOMERID_LINKS,
              siteRegexp: "^https*://tt.amazon.com"
           },
           // Weblab matching and link configuration
           {
              id: "wl",
              // Look for blah_1234
              regexp: "\\b([a-zA-Z_]+_[0-9]{4,})\\b",
              regexpFlags: "g",
              string: "{REGEXP0}",
              defaultLinks: "wl",
              links: WEBLAB_LINKS,
           },
           // Order ID matching and link configuration
           {
              id: "pasture",
              regexp: "([0-9]{3}-[0-9]{7}-[0-9]{7})",
              regexpFlags: "g",
              string: "{REGEXP0}",
              defaultLinks: "us",
              links: PASTURE_LINKS,
           },
           // Code link matching and link configuration
           // leave this at end since this is pretty loose regex
           // no defaultLinks to keep current behavior
           // and let user opt in
           {
              id: "code",
              regexp: "\\b([a-z_A-Z0-9-/]{1,100}/[a-z_A-Z0-9-/]{1,100})\\b",
              regexpFlags: "g",
              string: "{REGEXP0}",
              links: CODE_LINKS,
           },
           // EC2 Instance IDs
           {
              id: "ec2Instance",
              // The Prod infra tools use an EC2.<id> convention
              regexp: "\\b(?:(?:i-)|(?:EC2\\.))([a-z0-9]{8}(?:[a-z0-9]{9})?)\\b",
              regexpFlags: "g",
              string: "i-{REGEXP0}",
              links: EC2_INSTANCE_LINKS,
              defaultLinks: "adm"
           }
        ]
    };

    var STYLES = "\
        span.stringLinks {\
            -webkit-user-select: none;\
            -khtml-user-select: none;\
            -moz-user-select: none;\
            -o-user-select: none;\
            -ms-user-select: none;\
            user-select: none;\
            padding: 1px 0px 1px 0px;\
            margin: 1px 2px 1px 2px;\
            border: 1px solid black;\
            font-family: Verdana,Geneva,sans-serif;\
            font-size:7pt;\
            font-weight:bold;\
        }\
        span.stringLinksInner a::selection { \
            background: transparent;\
        }\
        span.stringLinksInner a::-moz-selection { \
            background: transparent;\
        }\
        @media print {\
            span.stringLinks {\
                display: none;\
            }\
        }\
        #stringLinks span.stringLinksInner a, #stringLinks span.stringLinksInner a:hover,\
        #stringLinks span.stringLinksInner a:focus, #stringLinks span.stringLinksInner a:active  {\
            font-size: 7pt;\
            font-weight: bold;\
            background-color: inherit;\
            padding: 0;\
        }\
        #stringLinks span.stringLinksInner {\
            padding: 0px 3px 0px 3px;\
            margin: 0px 0px 0px 0px;\
            border: 1px solid white;\
        }\
        \
        div.stringLinksCMenu {\
            z-index: 1000;\
            position: absolute;\
        }\
        div.stringLinksCMenuHelp {\
            z-index: 1001;\
            position: absolute;\
            top: 3px;\
            left: 237px;\
        }\
        ul.stringLinksCMenu {\
            text-align: left; \
            width: 250px;\
            left: 0px; top: 0px;\
            border: 1px solid #A7A6AA;\
            background: #FFFFFF;\
            font-size: 12px; \
            text-decoration: none;\
            padding: 2px;\
            margin: 0;\
            overflow: hidden;\
            white-space: nowrap;\
            list-style-type: none;\
            position: absolute;\
        }\
        div.stringLinksPopup div.pageContainer,\
        div.stringLinksInline div.pageContainer {\
            width: 100%; height: 100%;\
            position: relative;\
        }\
        div.stringLinksPopupOverlay {\
            width: 100%; height: 100%;\
            position: absolute;\
            z-index: 9999;\
            display: none;\
            top: 0px; left: 0px;\
            background-color: white;\
            font-size: 20px;\
            text-align: center;\
            vertical-align: middle;\
            float: left;\
        }\
        div.stringLinksPopupOverlay span {\
            vertical-align: middle;\
            position: absolute;\
            top: 50%;\
            margin: -30px 0 0 -60px;\
        }\
        div.stringLinksPopupLoading {\
            background: white url(data:image/png;base64,R0lGODlhGAAYAPYAAP///x0WwPPz+7Gv6WNf00I8yiwmxK6r6Pz8/ZeU4S4oxB0WwOjo+E5JzUxHzezr+Tkzxzcxx+bm9/j4/JOQ4PHx+qOg5aGf5GJd00lDzCIbwScgwkM+ytzb9MPB7TQtxnl02e7t+V5Z0jw2yGdi1LOx6SQdwaek5uPi9tfV8ykiw4F+25GO4Ly6646K35yZ43Nv1/b2/EdBy9HQ8be06qyp53562llU0FdS0D44yVNOz8zK8FxX0YyJ3mxo1Xdz2Li26jIrxeHg9oN/3L687AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJBQAAACwAAAAAGAAYAAAHmoAAgoOEhYaHgxUWBA4aCxwkJwKIhBMJBguZmpkqLBOUDw2bo5kKEogMEKSkLYgIoqubK5QJsZsNCIgCCraZBiiUA72ZJZQABMMgxgAFvRyfxpixGx3LANKxHtbNth8hy8i9IssHwwsXxgLYsSYpxrXDz5QIDubKlAwR5q2UErC2poxNoLBukwoX0IxVuIAhQ6YRBC5MskaxUCAAIfkECQUAAAAsAAAAABgAGAAAB6GAAIKDhIWGh4MVFgQOGhsOGAcxiIQTCQYLmZqZGwkIlA8Nm6OaMgyHDBCkqwsjEoUIoqykNxWFCbOkNoYCCrmaJjWHA7+ZHzOIBMUND5QFvzATlACYsy/TgtWsIpPTz7kyr5TKv8eUB8ULGzSIAtq/CYi46Qswn7AO9As4toUMEfRcHZIgC9wpRBMovNvU6d60ChcwZFigwYGIAwKwaUQUCAAh+QQJBQAAACwAAAAAGAAYAAAHooAAgoOEhYaHgxUWBA4aCzkkJwKIhBMJBguZmpkqLAiUDw2bo5oyEocMEKSrCxCnhAiirKs3hQmzsy+DAgq4pBogKIMDvpvAwoQExQvHhwW+zYiYrNGU06wNHpSCz746O5TKyzwzhwfLmgQphQLX6D4dhLfomgmwDvQLOoYMEegRyApJkIWLQ0BDEyi426Six4RtgipcwJAhUwQCFypA3IgoEAAh+QQJBQAAACwAAAAAGAAYAAAHrYAAgoOEhYaHgxUWBA4aCxwkJzGIhBMJBguZmpkGLAiUDw2bo5oZEocMEKSrCxCnhAiirKsZn4MJs7MJgwIKuawqFYIDv7MnggTFozlDLZMABcpBPjUMhpisJiIJKZQA2KwfP0DPh9HFGjwJQobJypoQK0S2B++kF4IC4PbBt/aaPWA5+CdjQiEGEd5FQHFIgqxcHF4dmkBh3yYVLmx5q3ABQ4ZMBUhYEOCtpLdAACH5BAkFAAAALAAAAAAYABgAAAeegACCg4SFhoeDFRYEDhoaDgQWFYiEEwkGC5mamQYJE5QPDZujmg0PhwwQpKsLEAyFCKKsqw0IhAmzswmDAgq5rAoCggO/sxaCBMWsBIIFyqsRgpjPoybS1KMqzdibBcjcmswAB+CZxwAC09gGwoK43LuDCA7YDp+EDBHPEa+GErK5GkigNIGCulEGKNyjBKDCBQwZMmXAcGESw4uUAgEAIfkECQUAAAAsAAAAABgAGAAAB62AAIKDhIWGh4MVFgQOGgscJCcxiIQTCQYLmZqZBiwIlA8Nm6OaGRKHDBCkqwsQp4QIoqyrGZ+DCbOzCYMCCrmsKhWCA7+zJ4IExaM5Qy2TAAXKQT41DIaYrCYiCSmUANisHz9Az4fRxRo8CUKGycqaECtEtgfvpBeCAuD2wbf2mj1gOfgnY0IhBhHeRUBxSIKsXBxeHZpAYd8mFS5seatwAUOGTAVIWBDgraS3QAAh+QQJBQAAACwAAAAAGAAYAAAHooAAgoOEhYaHgxUWBA4aCzkkJwKIhBMJBguZmpkqLAiUDw2bo5oyEocMEKSrCxCnhAiirKs3hQmzsy+DAgq4pBogKIMDvpvAwoQExQvHhwW+zYiYrNGU06wNHpSCz746O5TKyzwzhwfLmgQphQLX6D4dhLfomgmwDvQLOoYMEegRyApJkIWLQ0BDEyi426Six4RtgipcwJAhUwQCFypA3IgoEAAh+QQJBQAAACwAAAAAGAAYAAAHoYAAgoOEhYaHgxUWBA4aGw4YBzGIhBMJBguZmpkbCQiUDw2bo5oyDIcMEKSrCyMShQiirKQ3FYUJs6Q2hgIKuZomNYcDv5kfM4gExQ0PlAW/MBOUAJizL9OC1awik9PPuTKvlMq/x5QHxQsbNIgC2r8JiLjpCzCfsA70Czi2hQwR9FwdkiAL3ClEEyi829Tp3rQKFzBkWKDBgYgDArBpRBQIADsAAAAAAAAAAAA=) no-repeat scroll center;\
        }\
        input.stringLinksAddressBar {\
            width: 100%;\
        }\
        div.stringLinksPopup {\
            text-align: center;\
            margin: 0 auto;\
            position: absolute;\
            z-index: 502;\
            border: 1px solid black;\
            overflow: hidden;\
            background-color: white;\
            box-shadow: 3px 3px 4px #000;\
            border-radius: 8px;\
        }\
        div.stringLinksInline {\
            text-align: center;\
            border: 1px solid black;\
            overflow: hidden;\
            background-color: white;\
            box-shadow: 3px 3px 4px #000;\
            border-radius: 8px;\
        }\
        div.stringLinksPopup a, div.stringLinksPopup a:hover, div.stringLinksPopup a:visited,\
        div.stringLinksInline a, div.stringLinksInline a:hover, div.stringLinksInline a:visited {\
            color: white !important;\
            background-color: inherit;\
        }\
        div.stringLinksPopup iframe,\
        div.stringLinksInline iframe {\
            width: 100%;\
            height: 100%;\
            position: absolute;\
            top: 0; left: 0;\
            border-width: 0px;\
            background-color: white;\
        }\
        div.stringLinksHeader {\
            background:#5A7EAA url(https://monitorportal.amazon.com/images/header_background.png) repeat-x scroll 0 0;\
            padding: 4px;\
            color: #ffffff;\
            text-align: right;\
            font-family: arial;\
            font-size: 14px;\
        }\
        div.stringLinksPopup div.stringLinksHeader {\
        }\
        ul.stringLinksCMenu li {\
            float: left;\
            margin-right: 1px;\
            position: relative;\
            width: 250px;\
        }\
        ul.stringLinksCMenu .box {\
            position: absolute; \
            left: 18px; \
            top: 1px; \
            text-decoration: none; \
            border: none; \
            padding: 0; \
        }\
        ul.stringLinksCMenu li.title {\
            font-weight: bold; \
        } \
        \
        ul.stringLinksCMenu li div {\
            display: block;\
        }\
        \
        ul.stringLinksCMenu li a.sel {\
            line-height: 18px;\
            padding: 0 4px 0 4px;\
            font-weight: normal;\
            font-family: Tahoma,Verdana,Arial,Helvetica,sans-serif; \
            text-decoration: none; \
            color: blue; \
            position: relative; \
            left: 40px; \
            width: 100%;\
            display: inline-block;\
        }\
        ul.stringLinksCMenu li a.sel:link {\
            color: black; \
        }\
        ul.stringLinksCMenu li a.sel:visited {\
            color: black; \
        }\
        \
        ul.stringLinksCMenu li hr {\
            width: 99%;\
            border: 0;\
            height: 1px;\
            color: #BBBBBB; \
            background-color: #BBBBBB; \
            margin-top: 4px;\
            margin-bottom: 4px;\
            visibility: visible;\
        }\
        ul.stringLinksCMenu li:hover a.sel { background-color: #0099FF; color: #FFFFFF; }\
        ul.stringLinksCMenu li:hover ul {display: block; position: absolute; top: 0; left: 246px; width:250px;}\
        ul.stringLinksCMenu li:hover ul li ul {display: none;}\
        ul.stringLinksCMenu li:hover ul li a.sel { display: block; background-color: #F6F6F6; color: #000000; }\
        ul.stringLinksCMenu li:hover ul li a.sel:hover { background-color: #0099FF; color: #FFFFFF; }\
        ul.stringLinksCMenu li:hover ul.left { left: -250px; }\
        #stagetabs ul.tabs li a { display: inline; }\
        #stagetabs ul.tabs li span.stringLinks a { font-size: 7pt; }\
        #searchresult-main div.searchresult-component.host { width: inherit; }\
        #searchresult-main div.searchresult-component.hostclass { width: inherit; }\
        #monitor-amazon-com #graph-control span.stringLinks, \
        #monitor-amazon-com #graph-control span.stringLinksInner { display: inline-block; }\
        .dynDiv_moveDiv {\
             cursor: move;\
             position: absolute;\
             overflow: hidden;\
        }\
        \
        .dynDiv_resizeDiv_tl,.dynDiv_resizeDiv_tr,.dynDiv_resizeDiv_bl,.dynDiv_resizeDiv_br {\
             width: 10px;\
             height: 10px;\
             background: #FFFFCC url(data:image/png;base64,R0lGODlhCwALALMAAISEhN7e3szMzI2Njebm5pSUlOzs7NbW1v///wAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEHAAgALAAAAAALAAsAAAQ0MICAJCVDTIQPHxRlAB6xleDnBcVYbhJRoN4BEMhbD/hL2b1b4cfL8Ui5W9JQMeIEA+YhAgA7) no-repeat scroll center;\
             border: 1px solid #000;\
             border-radius: 3px; \
             -moz-border-radius: 3px; \
             position: absolute;\
        }\
        \
        .dynDiv_resizeDiv_tl {\
             top: -1px;\
             left: -1px;\
        }\
        \
        .dynDiv_resizeDiv_tr {\
             top: -1px;\
             right: -1px;\
        }\
        \
        .dynDiv_resizeDiv_bl {\
             bottom: -1px;\
             left: -1px;\
        }\
        \
        .dynDiv_resizeDiv_br {\
             bottom: -1px;\
             right: -1px;\
        }\
        \
        .dynDiv_moveParentDiv {\
             width: 100%;\
             margin: auto;\
             height: 16px;\
             font-size: 15px;\
             position: absolute;\
             top: -1px;\
             left: -1px;\
             background: #faa;\
             border: 1px solid #aaa;\
             border-left: 0;\
             border-right: 0;\
             padding: 0;\
             overflow: hidden;\
             white-space:nowrap;\
        }\
        \
        .dynDiv_minmaxDiv {\
             position: absolute;\
             top: 1px;\
             right: 15px;\
             width: 15px;\
             height: 15px;\
             background: #faa;\
             font-size: 15px;\
             padding: 0;\
             margin: 0;\
        }\
        ";

    var incognito = false;
    var ctrlRightClick = false;
    var INCOGNITO_MODE = "IncognitoMode";
    var RIGHT_CLICK_MODE = "RightClick";
    var ON_DEMAND_ID = "OnDemand";
    var WHITELIST_ID = "Whitelist";
    var GREYLIST_ID = "Greylist";
    var DEFAULT_WHITELIST = "";
    var DEFAULT_GREYLIST = "http[s]?://permissions.amazon.com/.*,http[s]?://codereviewer.amazon.com/.*,http[s]?://cr.amazon.com/.*,http[s]?://cm-new.amazon.com/.*,http[s]?://cm.amazon.com/.*,http[s]?://monitorportal.*.amazon.com/reports.*,http[s]?://tt.amazon.com/search.*,http[s]?://exchange.amazon.com/.*(s=Draft|(a=(New|Reply))).*";
    var whitelist = [];
    var greylist = [];

    function initialize() {
       addCopyLinksToAll();
       initWhiteGreylists();
       addStyle(STYLES);
       mergeCustomDefinitions();

       ContextMenu.init();
       document.addEventListener("click", stringLinksHideContextMenu, false);
       document.addEventListener("keydown", checkKeyPress, false);
       document.addEventListener("mouseup", popupMouseUp, false);
       window.StringLinks = { decorateStrings: decorateStrings,
                                  removeStringLinks: removeStringLinks,
                                  openDefaultPopup: openDefaultPopup,
                                  setIncognitoMode: setIncognitoMode,
                                  setRightClickMode: setRightClickMode,
                                  version: "2.0.70" };
       if (document.getElementById("StringLinksOff")) {
           return;
       }

       var incognitoMarker = document.getElementById("StringLinksIncognito");
       if (incognitoMarker) {
          incognito = true;
          incognitoMarker.innerHTML = "Note: StringLinks is working in <i>incognito mode</i>. Please right-click on matched strings to see options";
          incognitoMarker.style.display = "";
       }
       var onDemand = getValue(ON_DEMAND_ID, "off");
       var incognitoMode = getValue(INCOGNITO_MODE, "off");
       if (incognitoMode == "on") {
          incognito = true;
       }

       evaluateRightClickMode();

       if (onDemand === 'off' || document.getElementById("StringLinksForce")) {
           interceptCustomPageAjaxRequests();

           // Do white/greylisting. Whitelisting is highest priority, over a greylist
           if (whitelist.length > 0) {
               // For whitelist, only decorate if page is on whitelist
               if (amOnWhiteGreylist(whitelist)) {
                   decorateStrings(false);
               }
           }
           else if (! amOnWhiteGreylist(greylist)) {
               // For greylist, only decorate if page is not on greylist
               decorateStrings(true);
           }
           if (/cloudwatch\/home/.test(window.location.href)) {
               setInterval(function() {
                   if (/^#alpine:/.test(window.location.hash)) {
                       decorateStrings(true, true);
                   }
               }, 1000);
           }
       }
    }

    function addCopyLinksToAll() {
       for (var i = 0; i < LINK_DEFS.length; i++) {
          LINK_DEFS[i].links.push({
             id: "cpy",
             url: "{STRING}",
             title: "Copy Value to Clipboard ",
             color: "white", backgroundColor: "black",
             open: COPY
          });
       }
    }

    function interceptCustomPageAjaxRequests() {
        interceptCMAjaxRequests();
        interceptTTAjaxRequests();
        interceptApolloCapacityExpanderRequests();
    }

    function isOnCMPage() {
        return /https:..cm.amazon.com.[0-9]/.test(window.location.href);
    }

    function interceptCMAjaxRequests() {
        if (!isOnCMPage()) {
            return;
        }
        var originalRefreshApprovers = window.refresh_approvers;
        var originalEditOverview = window.edit_overview;
        var originalOnSaveOverview = window.on_save_overview;
        window.refresh_approvers = function() {
            var ret = originalRefreshApprovers.apply(this, arguments);
            setTimeout(decorateStrings, 0);
            return ret;
        };
        window.edit_overview = function() {
            removeStringLinks();
            return originalEditOverview.apply(this, arguments);
        };
        window.on_save_overview = function() {
            var ret = originalOnSaveOverview.apply(this, arguments);
            setTimeout(decorateStrings, 0);
            return ret;
        };
    }
    function interceptTTAjaxRequests() {
        if (! /https:..tt.amazon.com.[0-9]/.test(window.location.href)) {
            return;
        }
        var originalRegisterActionMenus = window.registerActionMenus ;
        window.registerActionMenus = function() {
            var ret = originalRegisterActionMenus();
            setTimeout(decorateStrings, 0);
            return ret;
        };
    }

    function interceptApolloCapacityExpanderRequests() {
        if (! /https:..apollo.[a-z.]*amazon.com/.test(window.location.href)) {
            return;
        }
        if ($) {
            function trapExpanderClicks() {        // Trap clicks on hostclass/asg expander icons
                var CHECK_DELAY_MS = 250;
                var capacityTable = $(this).closest('table');        // Find parent table
                function checkForChange() {
                    // When table stops containing "expandInProgress" then it's time to run stringLinks
                    if (/expandInProgress/.test(capacityTable.html())) {
                        window.setTimeout(checkForChange, CHECK_DELAY_MS);
                    }
                    else {
                        decorateStrings(true);
                        $('.expanderButton').unbind('click.stringLinks');
                        $('.expanderButton').bind('click.stringLinks', trapExpanderClicks);
                    }
                };
                window.setTimeout(checkForChange, CHECK_DELAY_MS);
            };
            $('.expanderButton').bind('click.stringLinks', trapExpanderClicks);
        }
    }

    function removeStringLinkWhichBreaksCMPage() {
        if (!isOnCMPage()) {
            return;
        }
        var cmIdTd = document.getElementById('cm_id');
        if (cmIdTd) {
            var badLink = getFirstElementByClassName(cmIdTd, "stringLinks");
            if (badLink) {
                cmIdTd.removeChild(badLink);
            }
        }
    }

    function mergeCustomDefinitions() {
        mergeCustomSubstitutions();
        mergeCustomLinks();
    }

    function mergeCustomSubstitutions() {
       var customSub = getValue('SUBSTITUTIONS', "");
       setValue('SUBSTITUTIONS', customSub);

       if (customSub != "") {
           var entry;
           try {
               var customEntries = JSON.parse("[" + customSub + "]");
               for (var j = 0; j < customEntries.length; j++) {
                   entry = customEntries[j];
                   if (validateSubstitution('SUBSTITUTIONS', j, entry)) {
                       SUBSTITUTIONS.entries.splice(0, 0, entry);
                       entry.links = addNewLinkDefinition(entry.links);
                   }
               }
           }
           catch (e) {
               log("Bad custom substitution definition '" + entry.id + "', entry: '" + customSub + "', exception: " + e);
           }
       }
    }

    function addNewLinkDefinition(linkId) {
       for (var i = 0; i < LINK_DEFS.length; i++) {
           var linkDef = LINK_DEFS[i];
           if (linkDef.id === linkId) {
               return linkDef.links;
           }
       }
       var linkDef = {id: linkId, links: []};
       LINK_DEFS.push(linkDef);
       return linkDef.links;
    }

    function mergeCustomLinks() {
       for (var i = 0; i < LINK_DEFS.length; i++) {
           var linkDef = LINK_DEFS[i];
           var customLinks = getValue(linkDef.id, "");
           setValue(linkDef.id, customLinks);

           if (customLinks != "") {
               try {
                   var customLinksArray = JSON.parse("[" + customLinks + "]");
                   for (var j = 0; j < customLinksArray.length; j++) {
                       var link = customLinksArray[j];
                       if (validateLink(linkDef.id, j, link)) {
                           addLink(linkDef.links, link);
                       }
                   }
               }
               catch (e) {
                   log("Bad custom link definition '" + linkDef.id + "', entry: '" + customLinks + "', exception: " + e);
               }
           }
       }
    }

    function addLink(links, link) {
       if (link.category) {
           var foundCategory = false;
           for (var i = 0; i < links.length; i++) {
               var categoryMatch = (links[i].category === link.category);
               if (!foundCategory && categoryMatch) {
                   foundCategory = true;
               }
               else if (foundCategory && ! categoryMatch) {
                   // We're one past the category, add it here
                   links.splice(i, 0, link);
                   return;
               }
           }
       }

       links.push(link);
    }

    function validateSubstitution(id, index, link) {
        return validateStringLinkObject(id, index, link, ["id", "regexp", "regexpFlags", "string", "defaultLinks", "links"]);
    }

    function validateLink(id, index, link) {
        return validateStringLinkObject(id, index, link, ["id", "url", "title", "color", "backgroundColor"]);
    }

    function validateStringLinkObject(id, index, link, requiredFields) {
        var missingFields = [];
        for (var i = 0; i < requiredFields.length; i++) {
            var field = requiredFields[i];
            var fieldValue = link[field];
            if (! fieldValue || typeof fieldValue != "string") {
                missingFields.push(field);
            }
        }
        if (missingFields.length === 0) {
            return true;
        }
        log("Rejecting stringLink def " + index + " of " + id + " because it does not define the following string fields: " + missingFields.join(", "));
        return false;
    }

    function initWhiteGreylists() {
        restoreWhiteGreylist(WHITELIST_ID, DEFAULT_WHITELIST, true);
        restoreWhiteGreylist(GREYLIST_ID, DEFAULT_GREYLIST, false);
    }

    function restoreWhiteGreylist(id, defaultVal, isWhite) {
       var listVal = getValue(id, defaultVal);
       setValue(id, listVal);
       storeInArray = listVal.split(",");
       if (storeInArray.length === 1 && storeInArray[0].length === 0) {
           storeInArray = [];
       }
       if (isWhite) {
           whitelist = storeInArray;
       }
       else {
           greylist = storeInArray;
       }
    }

    function amOnWhiteGreylist(list) {
        var location = window.location.href;
        for (var i = 0; i < list.length; i++) {
            if (new RegExp('^' + list[i]).test(location)) {
                return true;
            }
        }
        return false;
    }

    function checkKeyPress(e) {
        // Check for Ctrl-Alt-S
        if (e.ctrlKey && e.altKey && ((e.which == 115) || (e.which == 83))) {
            removeStringLinks();
            if (! e.shiftKey) {
                decorateStrings(false);
            }
        }
    }

    function removeStringLinks() {
        removeStringLinksInContainer(document);
    }

    function removeStringLinksInContainer(container) {
        [].forEach.call(container.querySelectorAll('span.stringLinks'), function(e){
            e.parentNode.removeChild(e);
        });
    }

    function trapLinkClicks(ev) {
       if (/StringLinks(Popup|Inline),/.test(this.href)) {
           return openLinkInFrame(this, ev);
       }
       if ((ev.ctrlKey && ev.shiftKey) || /StringLinksPopup,/.test(this.href)){
           return openPopup.call(this, ev);
       }
    }

    function getLinkArgs(argString, args) {
       var argList = argString.split(",");
       for (var i = 0; i < argList.length; i++) {
           var split = argList[i].split("_");
           if (split.length === 2) {
               args[split[0]] = split[1];
           }
       }
    }

    function openLinkInFrame(link, ev) {
       var linkDef = { href: link.href, title: link.href };
       var after;
       if (/StringLinksInline,/.test(link.href)) {
           var match = /(.*)[#]StringLinksInline,(.*)_EndInline/.exec(link.href);
           linkDef.href = match[1];
           linkDef.title = match[1];
           getLinkArgs(match[2], linkDef);
           after = link;
       }
       else if (/StringLinksPopup,/.test(link.href)) {
           var match = /(.*)[#]StringLinksPopup,(.*)_EndPopup/.exec(link.href);
           linkDef.href = match[1];
           linkDef.title = match[1];
           getLinkArgs(match[2], linkDef);
       }
       return openPopup.call(linkDef, ev, after);

    }

    function decorateStrings(limitedMode, replaceLive) {
       if (isDecorating) {
          return;
       }
       isDecorating = true;
       if (!replaceLive) {
           removeStringLinks();
       }
       // Retrieve enabled substitutions. They are stored in about:config for this script.
       // They are a comma-separated list of link ids stored under the value "< entry.id>Links"
       for (var r = 0; r < SUBSTITUTIONS.entries.length; r++) {
          var entry = SUBSTITUTIONS.entries[r];
          if (!entry.id)
             continue;
          var enabledLinks = getEnabledLinks(entry);
          entry.enabledLinks = enabledLinks;

          // Mark each link as enabled/disabled depending on whether it's in the list of enabled
          // links or not.   If enabled links is 'all' then all links are enabled
          var linkIdsForThisEntry = [];
          for (var linkNum = entry.links.length - 1; linkNum >= 0; linkNum--) {
             var link = entry.links[linkNum];
             linkIdsForThisEntry.push(link.id);
             var enabled = true;
             if (entry.enabledLinks != 'all' && ! new RegExp('\\b' + link.id + '\\b').test(entry.enabledLinks)) {
                enabled = false;
             }
             link.enabled = enabled;

             // Allow link colors to be overriden, example entry:
             //    host.sni.color = <foreground>,<background>
             var linkColorOverride = getValue(entry.id + "." + link.id + ".color");
             if (linkColorOverride) {
                var colors = linkColorOverride.split(",");
                if (colors.length == 2) {
                   link.color = colors[0];
                   link.backgroundColor = colors[1];
                }
             }
          }
          setValue(entry.id + "Links_Choose_From_This_List", linkIdsForThisEntry.join(","));
       }

       // Grab the text and link nodes
       var textNode, text = document.evaluate("//text()[normalize-space(.)!='']",document,null,6,null);
       var links = document.evaluate("//a[@href]",document,null,6,null);
       var limit = limitNumberIf(text.snapshotLength, STRING_LIMIT, limitedMode);
       var on = true;

       var i = 0, batchEnd;
       var batchAddStringNodes = function(){
           // Check for matches on string nodes
           for (batchEnd = i + LINK_REPLACEMENT_BATCH_SIZE; (i < batchEnd) && (i < limit); i++) {
              var textNode = text.snapshotItem(limit - i - 1);
              if (textNode.textContent === "StringLinksToggle") {
                  on = !on;
              }
              else if (on) {
                  checkForMatches(textNode, textNode.textContent, false, replaceLive);
              }
           }

           if (i < limit) {
               // We're lower than the limit, so sleep to let the browser catch up and do another batch:
               window.setTimeout(batchAddStringNodes, LINK_REPLACEMENT_BATCH_INTERVAL);
           } else {
               // We completed the entire list, so now begin batching the link nodes
               limit = limitNumberIf(links.snapshotLength, STRING_LIMIT, limitedMode);
               i = 0;
               batchAddLinkNodes();
           }
       }

       var batchAddLinkNodes = function(){
           // Check for matches on link nodes
           for (batchEnd = i + LINK_REPLACEMENT_BATCH_SIZE; (i < batchEnd) && (i < links.snapshotLength); i++) {
              var node = links.snapshotItem(limit - i - 1);
              node.addEventListener("click", trapLinkClicks, true);
              checkForAutoDisplayLinks(node);
              if (i < limit) {
                 checkForMatches(node, node.href, true, replaceLive);
              }
           }

           if (i < links.snapshotLength) {
               // We're lower than the limit, so sleep to let the browser catch up and do another batch:
               window.setTimeout(batchAddLinkNodes, LINK_REPLACEMENT_BATCH_INTERVAL);
           } else {
               removeStringLinkWhichBreaksCMPage();
               isDecorating = false;
           }
       }

       batchAddStringNodes();
    }

    function checkForAutoDisplayLinks(link) {
        if (/StringLinks(Popup|Inline),auto_on,/.test(link.href)) {
           openLinkInFrame(link);
        }
    }

    function limitNumberIf(num, limitValue, shouldLimit) {
       if (shouldLimit && num > limitValue) {
          return limitValue;
       }
       return num;
    }

    function getEnabledLinks(entry) {
       var configId = entry.id + "Links";
       var enabledLinks = getValue(configId);
       if (!enabledLinks && entry.defaultLinks) {
          enabledLinks = entry.defaultLinks;
       }

       setValue(configId, enabledLinks);
       return enabledLinks;
    }

    function checkForMatches(node, textContent, doOnlyLinks, replaceLive) {
       // Go through all configured substitutions
       for (var entryNum = 0; entryNum < SUBSTITUTIONS.entries.length; entryNum++) {
          var entry = SUBSTITUTIONS.entries[entryNum];
          var entryIsMatchLinks = entry.matchLinks == true;
          if (doOnlyLinks != entryIsMatchLinks) {
             continue;
          }
          // If entry has a "site" matcher, then only string match if we're on the right site
          if (entry.siteRegexp && ! new RegExp(entry.siteRegexp, "g").test(window.location.href)) {
             continue;
          }

          var regexp = new RegExp(entry.regexp, entry.regexpFlags);
          var match = regexp.exec(textContent);
          if (entry.negativeRegexp) {
            var negativeRegexp = new RegExp(entry.negativeRegexp, entry.negativeRegexpFlags);
            if (negativeRegexp.exec(textContent)) {
              match = false;
            }
          }
          if (match) {
             // Matching a blank entry means terminate. Those entries are used for
             // stopping matching of certain strings that we don't want to match
             // following regexps
             if (!entry.id)
                break;

            if (replaceLive) {
                removeStringLinksInContainer(node.parentNode);
            }

            var string = entry.string;
            for (var i = 1; i < match.length; i++) {
                string = string.replace(new RegExp("{REGEXP" + (i - 1) + "}", "g"), match[i]);
                string = string.replace(new RegExp("{REGEXP" + (i - 1) + "H}", "g"), encodeURIComponent(match[i]));
            }

             // We got a match, let's insert image links for all enabled links
             var lastLink = null;
             var links = getLinksForEntry(entry, string);
             for (var linkNum = links.length - 1; linkNum >= 0; linkNum--) {
                var link = links[linkNum];

                // Skip this entry if it's not enabled
                if (link.enabled && !incognito) {
                   var insertedLink = insertLink(entryNum, link, string, node);
                   if (insertedLink != null) {
                       lastLink = insertedLink;
                   }
                }
             }
             if (lastLink && getValue("addSeparator") && !incognito) {
                var separatorSpan = document.createElement('span');
                var separatorText = document.createTextNode(" |");
                separatorSpan.appendChild(separatorText);
                lastLink.parentNode.insertBefore(separatorSpan, lastLink);
             }

             // If no links were added (all disabled) then add contextmenu to the matched
             // textnode's parent

             if (incognito || (!lastLink && links.length > 0))
                node.parentNode.addEventListener("contextmenu", function(ev) {
                           return displayContextMenu(ev, entryNum, string);
                       }, false);

             // Skip other entries, first match wins
             break;
          }
       }
    }

    function getLinksForEntry(entry, string) {
        var links = entry.links;
        if (entry.id == "host") {
            setBastionLink(links, ssbHostLinksIndex, getBastionAndHostnameFromString(string));
        }
        return links;
    }

    function setBastionLink(links, index, bastionInfo) {
        var sshUrl = bastionInfo.bastion == null ?
                       'ssh://' + bastionInfo.hostname :
                       'ssh://' + bastionInfo.bastion + '?cmd=' + encodeURIComponent('[[ `hostname` != *' + bastionInfo.hostname + '* ]] && exec ssh-nirvana ' + bastionInfo.hostname);
        links[index].url = sshUrl;
    }

    var HOST_MATCH_TO_BASTION_TABLE = [
        {
            regex: /[.]zhy[0-9]*[.]/,
            bastion: "bastion-zhy.amazon.com"
        },
        {
            regex: /[.]bjs[0-9]*[.]/,
            bastion: "bastion-bjs.amazon.com"
        },
        {
            regex: /(.*.bom.*.amazon.com|.*.bom.|.*.bom..|.*.ap-south-1.amazon.com|.*.ap-south-1)/,
            bastion: "bastion-bom.amazon.com"
        },
        {
            regex: /(.*.cmh.*.amazon.com|.*.cmh.|.*.cmh..|.*.us-east-2.amazon.com|.*.us-east-2)/,
            bastion: "bastion-cmh.amazon.com"
        },
        {
            regex: /(.*.dub.*.amazon.com|.*.dub.|.*.dub..|.*.eu-west-1.amazon.com|.*.eu-west-1)/,
            bastion: "security-bastions-prod-dub.amazon.com"
        },
        {
            regex: /(.*.fra.*.amazon.com|.*.fra.|.*.fra..|.*.eu-central-1.amazon.com|.*.eu-central-1)/,
            bastion: "bastion-fra.amazon.com"
        },
        {
            regex: /(.*.gru.*.amazon.com|.*.gru.|.*.gru..|.*.sa-east-1.amazon.com|.*.sa-east-1)/,
            bastion: "security-bastions-prod-gru.amazon.com"
        },
        {
            regex: /(.*.iad.*.amazon.com|.*.iad.|.*.iad..|.*.vdc.amazon.com|.*.vdc|.*.us-east-.*.amazon.com|.*.us-east-.)/,
            bastion: "security-bastions-prod-iad.amazon.com"
        },
        {
            regex: /(.*.icn.*.amazon.com|.*.icn.|.*.icn..|.*.ap-northeast-2.amazon.com|.*.ap-northeast-2)/,
            bastion: "bastion-icn.amazon.com"
        },
        {
            regex: /(.*.lhr.*.amazon.com|.*.lhr.|.*.lhr..|.*.eu-west-2.amazon.com|.*.eu-west-2)/,
            bastion: "security-bastions-prod-lhr.amazon.com"
        },
        {
            regex: /(.*.lux.*.amazon.com|.*.lux.|.*.lux..)/,
            bastion: "security-bastions-prod-lux.amazon.com"
        },
        {
            regex: /(.*.nrt.*.amazon.com|.*.nrt.|.*.nrt..|.*.ap-northeast-.*.amazon.com|.*.ap-northeast-.)/,
            bastion: "security-bastions-prod-nrt.amazon.com"
        },
        {
            regex: /(.*.pdx.*.amazon.com|.*.pdx.|.*.pdx..|.*.us-west-2.amazon.com|.*.us-west-2)/,
            bastion: "security-bastions-prod-pdx.amazon.com"
        },
        {
            regex: /(.*.pek.*.amazon.com|.*.pek.|.*.pek..)/,
            bastion: "security-bastions-prod-pek.amazon.com"
        },
        {
            regex: /(.*.sea.*.amazon.com|.*.sea.|.*.sea..)/,
            bastion: "security-bastions-prod-sea.amazon.com"
        },
        {
            regex: /(.*.sfo.*.amazon.com|.*.sfo.|.*.sfo..)/,
            bastion: "security-bastions-prod-sfo.amazon.com"
        },
        {
            regex: /(.*.sin.*.amazon.com|.*.sin.|.*.sin..|.*.ap-southeast-1.amazon.com|.*.ap-southeast-1)/,
            bastion: "security-bastions-prod-sin.amazon.com"
        },
        {
            regex: /(.*.syd.*.amazon.com|.*.syd.|.*.syd..|.*.ap-southeast-2.amazon.com|.*.ap-southeast-2)/,
            bastion: "security-bastions-prod-syd.amazon.com"
        },
        {
            regex: /(.*.yul.*.amazon.com|.*.yul.|.*.yul..|.*.ca-central-1.amazon.com|.*.ca-central-1)/,
            bastion: "security-bastions-prod-yul.amazon.com"
        },
        {
            regex: /(.*.zhy.*.amazon.com|.*.zhy.|.*.zhy..|.*.cn-northwest-1.amazon.com|.*.cn-northwest-1)/,
            bastion: "bastion-zhy.amazon.com"
        }
    ];

    function getBastionAndHostnameFromString(string) {
        var bastion = null;
        var hostname = string;
        if (/aes0[.]internal/.test(string) || /ec2[.]substrate/.test(string)) {
            var matchZone = string.match(/^[^.]*[.]([^.]*)/);
            if (matchZone != null && matchZone.length == 2) {
                var zone = matchZone[1];
                zone = zone.replace("z-", "z").replace(/-[0-9]*$/, "");
                bastion = "bastion-" + zone + ".ec2.amazon.com";
            }
        }
        else if (/ec2[.]border/.test(string)) {
            var matchZone = string.match(/^.*-([^.]*-[-0-9])/);
            if (matchZone != null && matchZone.length == 2) {
                var zone = matchZone[1];
                zone = zone.replace("z-", "z").replace(/-[0-9]*$/, "");
                var matchHost = string.match(/^(.*)-(\w+\d+-\d+|z-\d+)/);
                if (matchHost != null && matchHost.length == 3) {
                    var az = matchHost[2];
                    hostname = matchHost[1] + "." + az + ".";
                    hostname += /^z-/.test(az) ? "aes0.internal" : "ec2.substrate";
                    bastion = "bastion-" + zone + ".ec2.amazon.com";
                }
            }
        }
        else {
            for (var i = 0; i < HOST_MATCH_TO_BASTION_TABLE.length; i++) {
                if (HOST_MATCH_TO_BASTION_TABLE[i].regex.test(string)) {
                    bastion = HOST_MATCH_TO_BASTION_TABLE[i].bastion;
                    break;
                }
            }
        }
        return { bastion: bastion, hostname: hostname };
    }

    function getStringInLink(link, string) {
       var stringInLink = string;
       if (link.replace) {
           stringInLink = string.replace(link.replace, link.replaceWith);
       }
       return stringInLink;
    }

    function getLinkContainer(entryNum, link, string, withLink) {
       var entry = SUBSTITUTIONS.entries[entryNum];
       var href  = getLinkUrlForString(link, getStringInLink(link, string));
       if (href == null) {
           return null;
       }

       // Create link with text in it
       var linkNode    = document.createElement(withLink ? 'a' : 'span');
       var linkText    = document.createTextNode(' '  + link.id.toUpperCase());
       if (withLink) {
           linkNode.href   = href;
           linkNode.title  = link.title + ": " + string + " (right-click for more options)";
       }
       if (link.open) {
           if (link.open === POPUP) {
               linkNode.addEventListener("click", openPopup, true);
           }
           else if (link.open === HIDDEN) {
               linkNode.addEventListener("click", openHidden, true);
           }
           else if (link.open === COPY) {
               linkNode.string = string;
               linkNode.href = "javascript:void(0)";
               linkNode.addEventListener("click", copyValue, true);
           }
       }
       linkNode.style.color = link.color ? link.color: 'black';
       linkNode.style.textDecoration = 'none';
       linkNode.style.fontSize = '7pt';
       linkNode.style.fontFamily = 'Verdana,Geneva,sans-serif';
       linkNode.style.padding = '0';
       linkNode.appendChild(linkText);

       // Put link in a span
       var container = document.createElement('span');
       container.className = "stringLinks";
       container.id = "stringLinks";
       var innerContainer = document.createElement('span');
       innerContainer.className = "stringLinksInner";
       innerContainer.style.backgroundColor = link.backgroundColor ? link.backgroundColor: 'white';
       innerContainer.style.display = 'inline-block';
       innerContainer.style.lineHeight = 'normal';
       container.appendChild(innerContainer);
       innerContainer.appendChild(linkNode);

       return container;
    }

    function copyValue() {
       copyValueToClipboard(this.string);
       return false;
    }

    function getLinkUrlForString(link, string) {
        var url = link.url;
        if (Array.isArray(link.url)) {
            for (var i = 0; i < link.url.length; i++) {
                var match = link.url[i].match;
                if (match == null || new RegExp(match).test(string)) {
                    url = link.url[i].url;
                    break;
                }
            }
        }
        return url == null ? null : url.replace(/{STRING}/g, getStringInLink(link, string));
    }

    function sanitizeLink(linkStr) {
       var link = linkStr || '';
       link = link.trim();
       return ((link == '') || (link == 'about:blank')) ? null : link;
    }

    function getLinkFromElement(el) {
       var href = sanitizeLink(el.href) || sanitizeLink(el.text) || sanitizeLink(el.title) || 'about:blank';
       if (/^http:[a-zA-Z0-9-.]*\.amazon\.com\//.test(href)) {
           href = href.replace(/^http:/, "https:");
       }
       return href;
    }

    function openPopup(ev, after) {
       var MARGIN = 50;
       var popupArea = getPopupArea(this, MARGIN);
       var div = document.createElement('div');
       var title = this.title.replace(/:.*/, "");
       var href = getLinkFromElement(this);
       if (!after) {
           div.setAttribute("class", "stringLinksPopup dynDiv_moveDiv");
           div.style.left   = popupArea.x + "px";
           div.style.top    = popupArea.y + "px";
       }
       else {
           div.setAttribute("class", "stringLinksInline");
       }
       div.style.width  = popupArea.width + "px";
       div.style.height = popupArea.height + "px";
       div.innerHTML = '<div class="stringLinksHeader">\
                                <div class="stringLinksAddressBarContainer" style="float: left; width: ' + (popupArea.width - 150) + 'px;">\
                                    <input class="stringLinksAddressBar" name="stringLinksAddressBar" type="text" value="' + href + '">\
                                </div>\
                                <div style="float: right;">[<a class="stringLinksClose" href="#">Close</a>]</div>\
                                <div style="float: right;">[<a class="stringLinksNewTab" href="' + href + '" target="_blank">New tab</a>]&nbsp;</div>\
                                <div style="clear: both;"></div>\
                            </div>\
                       <div class="pageContainer">\
                           <div class="stringLinksPopupOverlay stringLinksPopupMoving"><span>Moving/resizing</span></div>\
                           <div class="stringLinksPopupOverlay stringLinksPopupLoading"></div>\
                           <iframe src="' + href + '">' + href + '</iframe><div style="clear: both;">\
                       </div>';
        if (!after) {
            var resize = document.createElement('div');
            resize.setAttribute("class", "dynDiv_resizeDiv_br");
            div.appendChild(resize);
            getFirstElementByClassName(div, "stringLinksPopupLoading").style.display = "block";
            document.body.appendChild(div);
            makeResizable(div, resize);
        }
        else {
            after.parentNode.insertBefore(div, after.nextSibling);
        }

       doAddressBar(div);
       doCloseLink(div);
       if (ev) {
           return stopEvent(ev);
       }
       return false;
    }

    function setPopupSize(width, height) {
       if (width !== 0 && height !== 0) {
           setValue("StringLinksPopupWidth", width);
           setValue("StringLinksPopupHeight", height);
       }
    }

    function getPopupArea(linkDef, defaultMargin) {
       var MIN_WIDTH = 100;
       var MIN_HEIGHT = 100;
       var windowOffset = getWindowOffset();
       var windowSize = getWindowSize();
       return {
           x: getValueOrOverride(windowOffset.x + defaultMargin, linkDef.x),
           y: getValueOrOverride(windowOffset.y + defaultMargin, linkDef.y),
           width: getValueOrOverride(limitDimension("StringLinksPopupWidth",  MIN_WIDTH,  windowSize.width -  2 * defaultMargin),
                                     linkDef.width),
           height: getValueOrOverride(limitDimension("StringLinksPopupHeight", MIN_HEIGHT, windowSize.height - 2 * defaultMargin),
                                     linkDef.height)
       };
    }

    function limitDimension(key, min, max) {
       var dim = getValue(key);
       dim = dim ? parseInt(dim) : max;
       if (dim > max) {
           dim = max;
       }
       if (dim < min) {
           dim = min;
       }
       return dim;
    }

    function getValueOrOverride(value, override) {
        if (typeof override !== 'undefined') {
            return override;
        }
        return value;
    }

    function doCloseLink(container) {
        var closeLink = getFirstElementByClassName(container, "stringLinksClose");
        closeLink.addEventListener("mousedown", function() {
            container.parentNode.removeChild(container);
            return false;
        }, false);
    }

    function doAddressBar(container) {
        var addressInput = getFirstElementByClassName(container, "stringLinksAddressBar");
        var newTabLink = getFirstElementByClassName(container, "stringLinksNewTab");
        var iframe = container.getElementsByTagName("iframe")[0];
        function focusSelectAddressInput() { addressInput.focus(); addressInput.select(); };
        addressInput.addEventListener("mousedown", focusSelectAddressInput, false);
        addressInput.addEventListener("keypress", function(ev) { checkIfAddressEntered.call(this, ev, container);}, false);
        iframe.addEventListener("load", function() {
            try {
                getFirstElementByClassName(container, "stringLinksPopupLoading").style.display = "none";
                resizePageContainer(container);
                if (typeof this.contentWindow.location.href !== 'undefined') {
                    addressInput.value = this.contentWindow.location.href;
                    newTabLink.href = addressInput.value;
                }
            } catch(e) {}}, false);
        newTabLink.addEventListener("click", function() {
            document.body.removeChild(container);
            return true;
        }, true);
    }

    function resizePageContainer(container) {
        var header = getFirstElementByClassName(container, "stringLinksHeader");
        var pageContainer = getFirstElementByClassName(container, "pageContainer");
        pageContainer.style.width = container.clientWidth + "px";
        pageContainer.style.height = (container.clientHeight - header.clientHeight) + "px";
    }

    function checkIfAddressEntered(ev, container) {
        if (ev.keyCode == 13) {
            var url = this.value;
            if (! /^[a-z][a-z]*:[/][/]/.test(url)) {
                url = 'http://' + url;
                this.value = url;
            }
            getFirstElementByClassName(container, "stringLinksPopupLoading").style.display = "block";
            getFirstElementByTagName(container, "iframe").src = url;
        }
    }

    function popupMouseDown(ev, popup) {
       activePopup = popup;
       setDisplayOfMovingOverlays("block");
       return false;
    }
    function popupMouseUp(ev, popup) {
        if (activePopup != null) {
           setDisplayOfMovingOverlays("none");
           resizePageContainer(activePopup);
           setPopupSize(activePopup.clientWidth, activePopup.clientHeight);
           activePopup = null;
        }
    }

    function setDisplayOfMovingOverlays(displayValue) {
        var movings = document.getElementsByClassName("stringLinksPopupMoving");
        for (var i = 0; i < movings.length; i++) {
            movings[i].style.display = displayValue;
        }
    }

    resizeIndex = 600;
    function makeResizable(popup, resizeHandle) {
       ByRei_dynDiv.add(popup, resizeIndex++);
       ByRei_dynDiv.add(resizeHandle, resizeIndex++);
       popup.addEventListener("mousedown", function(ev) { return popupMouseDown(ev, popup);}, false);
       popup.addEventListener("mouseup", popupMouseUp, false);
       resizeHandle.addEventListener("mousedown", function(ev) { return popupMouseDown(ev, popup); }, false);
       resizeHandle.addEventListener("mouseup", popupMouseUp, false);
    }

    function openHidden(ev) {
       var div = document.getElementById('stringLinksHiddenOpener');
       if (!div) {
           div = document.createElement('div');
           div.setAttribute("id", "stringLinksHiddenOpener");
           div.style.visibility = 'hidden';
           document.body.appendChild(div);
       }
       div.innerHTML = '<iframe src="' + this.href + '"></iframe>';
       return stopEvent(ev);
    }

    function stopEvent(ev) {
       ev.preventDefault();
       ev.returnValue = false;
       ev.stopPropagation();
       return false;
    }

    function insertLink(entryNum, link, string, insertAfter) {
       var linkContainer = getLinkContainer(entryNum, link, string, true);
       if (linkContainer == null) {
           return null;
       }

       // Add link after text node ... but if text is directly inside a link
       // then insert if after the link node instead (to prevent image link being
       // wrapped in a link itself)
       if (insertAfter.parentNode.tagName == 'A') {
          insertAfter = insertAfter.parentNode;
       }
       insertAfter.parentNode.insertBefore(linkContainer, insertAfter.nextSibling);
       linkContainer.addEventListener("contextmenu", function(ev) {
                   return displayContextMenu(ev, entryNum, string);
               }, false);
       return linkContainer;
    }

    function displayContextMenu(ev, entryNum, string) {
       var doContextMenu = !!ev.ctrlKey === ctrlRightClick;
       if (doContextMenu) {
         stringLinksShowContextMenu(ev, entryNum, string, ev.clientX+window.scrollX, ev.clientY+window.scrollY, 0);
         return stopEvent(ev);
       }
       return true;
    }

    var ContextMenu = {

       "init": function() {
          // Setup div with ul and wiki help link
          this.ul = document.createElement('ul');
          this.ul.setAttribute("class", "stringLinksCMenu");
          this.container = document.createElement('div');
          this.container.setAttribute("class", "stringLinksCMenu");
          var helpDiv = document.createElement('div');
          helpDiv.setAttribute("class", "stringLinksCMenuHelp");
          helpDiv.innerHTML = '<a title="View StringLinks wiki" href="https://w.amazon.com/?StringLinks" target="_blank"><img border="0" width="16" height="16" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAIAAACQkWg2AAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAA7EAAAOxAGVKw4bAAACz0lEQVR4nE2S7U9SYRjGz//Q1rc+9qlv1XLLVtk0dbMydZXTaeq0Is2V2mal6Zy6jBcDCTEElIGZ6ZaZKfgChVaimBZwOIfDQeRNhDzEUd4PPUTO7j0fnnu7rmf3fT0/KP63YpFwhPRuf5WYBsrg7nQ9PVXPOAv35Fje3CfgOSoWje8XlFDHYv6NVYR3RUc/Y3x5CRUWYgOl4KCCazAnU/csBRusCPuc/wwURfk31/XMCzA7yywp33z3yDlDdyl7XPMcx3SndaweExXrWWkGTnbIt5UwRIO7Rn4+zMmyDNc4Z1le7VsfPOs3L/qxBUIv9yxJ7VPtZkmFnnkel9HALJBndUzPOHe3TX6oOg7OqZbQis55ojmabBtE7h9qxcnGneN1tm+dGaRVC1mGaxF+nm3iaWrzDlDkskKRXa98lUwaRj9vkxua6h7zpJAJsy86prsgmJeHDdwEE7NeG4Hi8D3K6vKLVQFwAW2VIBB0m7I7vPaP7Qg/H5NUQTA7E5fdci/2oz/Xkq9y5YEiXuTJSAjcjzygZpY9TSIMrGcSFaGCGxAIG5fddi8KSetyLisIRKfbojRx+DtG7m8V+bKgcc51m0TFqKAQQgTXscHyLRUXxCKUe5KiSe1eNPg7pTWx+rHGMKGftk91oH0F+FA1ZB1vAkvbJ9t21sZtJhiMfvRhLEgS0T2ia3wPGOr7HR6NzDrWAKJ3KbkQgagMrDR86I5LxSUMisvPfTUiEvxrmHDAiA0Y5FMqh7wLGywFHATcZigaCeJDNCM3Z2OkFnzw+4lParWWtGhIy5IPUT7mrzsVdFxaZXiRYZtoBVgk0Aj92jT2FgAPiMv2ocU1z3arX7nVfc4ZJiAFk5QBNSosiQbJA/iChMMyWmfoTkd6r2LiElxWaZZWmoRFgEUd4yx4G2RwQGuiKAoQTlpW7AqGWUpDxSXABiBwKXkBNxL/r/4AkFclJQMtWr8AAAAASUVORK5CYII%3D"></a>';
          this.container.appendChild(helpDiv);
          this.container.appendChild(this.ul);

          // Append to doc and hide until 'show' is called
          document.body.appendChild(this.container);
          this.hide();
       },

       "add": function(string, title, url, tooltip, linkContainer, linkEntry) {
          var link, ul, li;
          li = document.createElement('li');
          if (!title) {
             li.appendChild(document.createElement("hr"));
          }
          else if (!url) {
             li.setAttribute("class", "title");
             if (title.match("^<")=="<") {
                li.innerHTML = title;
             }
             else {
                var titleText = document.createTextNode(title);
                li.appendChild(titleText);
             }
          }
          else  {
             url = (linkEntry.open == COPY) ? "javascript:void(0)" : url;
             // Checkbox for enabling/disabling elements
             var checkBox = document.createElement("input");
             checkBox.type = "checkbox";
             checkBox.checked = linkEntry.enabled;
             checkBox.addEventListener("click", function(ev) {
                ev.stopPropagation();
                ContextMenu.preventHide = true;
                linkEntry.enabled = this.checked;
                storeSettings();
             }, true);

             var div = document.createElement('div');
             var linkText = document.createTextNode(title);
             var spacer = document.createElement("span"); spacer.innerHTML = "&nbsp;&nbsp;&nbsp;";
             var link2 = document.createElement('a');

             link = document.createElement('a');
             link.setAttribute("class", "sel");
             link.href = url;
             link.title = tooltip;
             link.target = "_blank";
             link2.setAttribute("class", "box");
             link2.href = url;
             link2.title = tooltip;
             link2.target = "_blank";
             link2.appendChild(linkContainer);
             link.appendChild(linkText);
             if (linkEntry.open == COPY) {
                 function linkCopyValue(ev) {
                    stopEvent(ev);
                    copyValueToClipboard(string);
                    ContextMenu.hide();
                 }
                 link.addEventListener("click", linkCopyValue, true);
                 link2.addEventListener("click", linkCopyValue, true);
             }

             div.appendChild(checkBox);
             div.appendChild(link);
             div.appendChild(link2);
             li.appendChild(div);
          }
          this.ul.appendChild(li);
       },

       "clear": function() {
          this.ul.innerHTML = "";
       },

       "show": function(x, y) {
          this.container.style.visibility = "hidden"
          this.container.style.display = "";
          this.container.style.left = x + "px";
          this.container.style.top = y + "px";
          this.container.style.visibility = "visible";
       },

       "hide": function() {
          if (this.preventHide) {
             this.preventHide = false;
             return;
          }
          this.container.style.visibility = "hidden";
          this.container.style.display = "none";
          this.container.style.left = 0;
          this.container.style.top = 0;
       }
    };

    function setIncognitoMode(val) {
        setValue(INCOGNITO_MODE, val);
    }

    function setRightClickMode(val) {
        setValue(RIGHT_CLICK_MODE, val);
        evaluateRightClickMode();
    }

    function evaluateRightClickMode() {
       var rightClickMode = getValue(RIGHT_CLICK_MODE, "");
       ctrlRightClick = (rightClickMode === "ctrl");
    }

    function openDefaultPopup(e) {
       openPopup.call({href: "about:blank", title: ""}, e);
    }
    window.stringLinksHideContextMenu = function(e) {
        var rightClick = (e.which == 3) || (e.button == 2)
        if (!rightClick) {
            window.setTimeout(function() { ContextMenu.hide(); }, 60);
        }
        if (e.ctrlKey && e.shiftKey) {
           return openDefaultPopup(e);
        }
    }
    window.stringLinksReallyHideContextMenu = function(e){
        ContextMenu.hide();
        return true;
    }

    window.stringLinksShowContextMenu = function(e, entryNum, string, x, y, isSame) {
       var entry = SUBSTITUTIONS.entries[entryNum];
       var links = getLinksForEntry(entry, string);

       var categories = [];
       ContextMenu.clear();
       ContextMenu.add(string, "<center>" + string + "</center>");
       for (var i = 0; i < links.length; i++) {
          var link = links[i];
          if (! categories[link.category]) {
             categories[link.category] = 1;
             ContextMenu.add();
          }
          var url = getLinkUrlForString(link, string);
          if (url != null) {
              var linkContainer = getLinkContainer(entryNum, link, string, false);
              ContextMenu.add(string, link.title, getLinkUrlForString(link, getStringInLink(link, string)), link.title + ": " + string, linkContainer, link);
          }
       }
       ContextMenu.add();
       ContextMenu.add(string, "<center>Use Ctrl-Right-Click to see original menu</center>");
       ContextMenu.show(x, y);
    }

    function storeSettings() {
       // Retrieve enabled substitutions. They are stored in a SQLite database local to GreaseMonkey for this script.
       // They are a comma-separated list of link ids stored under the value "< entry.id>Links"
       for (var r = 0; r < SUBSTITUTIONS.entries.length; r++) {
          var entry = SUBSTITUTIONS.entries[r];
          if (!entry.id)
             continue;

          var configId = entry.id + "Links";
          var linkIdsForThisEntry = [];

          for (var linkNum = entry.links.length - 1; linkNum >= 0; linkNum--) {
             var link = entry.links[linkNum];
             if (link.enabled) {
                linkIdsForThisEntry.push(link.id);
             }
          }
          setValue(configId, linkIdsForThisEntry.length ? linkIdsForThisEntry.join(",") : "none");
       }
    }

    function getWindowSize() {
        var myWidth = 0, myHeight = 0;
        if (typeof( window.innerWidth ) == 'number' ) {
            //Non-IE
            myWidth = window.innerWidth;
            myHeight = window.innerHeight;
        } else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
            //IE 6+ in 'standards compliant mode'
            myWidth = document.documentElement.clientWidth;
            myHeight = document.documentElement.clientHeight;
        } else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
            //IE 4 compatible
            myWidth = document.body.clientWidth;
            myHeight = document.body.clientHeight;
        }
        return { width: myWidth, height: myHeight};
    }

    function getWindowOffset() {
      return {
          x: filterAreaResults(window.pageXOffset ? window.pageXOffset : 0,
                  document.documentElement ? document.documentElement.scrollLeft : 0,
                  document.body ? document.body.scrollLeft : 0),
          y: filterAreaResults(window.pageYOffset ? window.pageYOffset : 0,
                  document.documentElement ? document.documentElement.scrollTop : 0,
                  document.body ? document.body.scrollTop : 0)
      }
    };

    /*
    * Utility function for getting the correct number in the DOM for x and y positions.
    * It is given numbers that come from the window, document and documeny body and
    * the algorithm figures out the correct one to use.
    */
    function filterAreaResults(n_win, n_docel, n_body) {
        var n_result = n_win ? n_win : 0;
        if (n_docel && (!n_result || (n_result > n_docel))) {
            n_result = n_docel;
        }
        return n_body && (!n_result || (n_result > n_body)) ? n_body : n_result;
    }

    function isInIFrame() {
        return (window.location != window.parent.location) ? true : false;
    }

    // Initialize and decorate strings
    initialize();

    }
    function setGM(isGM) {
        var NAMESPACE = "StringLinks";
        log = function(msg) { try { window.console.log(msg); } catch(e) {} };
        if (window.opera) log = opera.postError;
        setValue = isGM ? StringLinksGM.setValue : function (name, value) { return localStorage.setItem(NAMESPACE + "." + name, value) };
        getValue = isGM ? StringLinksGM.getValue : function(name, def) { var s = localStorage.getItem(NAMESPACE + "." + name); return s == null ? def : s };
        addStyle = isGM ? StringLinksGM.addStyle : function(styles) {
            var heads = document.getElementsByTagName("head");
            if (heads.length > 0) {
                var node = document.createElement("style");
                node.type = "text/css";
                node.appendChild(document.createTextNode(styles));
                heads[0].appendChild(node);
            }
        };
        copyValueToClipboard = isGM ? StringLinksGM.copyValueToClipboard : function(value) {
            alert("Copy not supported by Chrome without TamperMonkey extension");
            return false
        };

    }
    function getFirstElementByTagName(container, className) {
        return getFirstElementByFunc(container.getElementsByTagName, container, className);
    }
    function getFirstElementByClassName(container, className) {
        return getFirstElementByFunc(container.getElementsByClassName, container, className);
    }
    function getFirstElementByFunc(func, container, item) {
        var elems = func.call(container, item);
        if (elems && elems.length > 0) {
            return elems[0];
        }
        return undefined;
    }

    setGM(isGM);

/*
 * ByRei dynDiv 1.0 RC1 - dynamic Div Script
 *
 * Copyright (c) 2008 Markus Bordihn (markusbordihn.de)
 * Dual licensed under the MIT (MIT-LICENSE.txt)
 * and GPL (GPL-LICENSE.txt) licenses.
 *
 * $Date: 2013/02/21 $
 * $Rev: 1.0 RC1 $
 */

/*global window*/
/*jslint bitwise: true, browser: true, eqeqeq: true, immed: true, newcap: true, regexp: true, undef: true */

var ByRei_dynDiv = {

 info: {
  Name: "ByRei dynDiv",
  Version:  "1.0 RC1",
  Author: "Markus Bordihn (http://markusbordihn.de)",
  Description: "Simple dynamic DIV's"
 },

 api: {
  drag: null,
  drop: null,
  elem: null,
  alter: null,
  obj: null
 },

 dropArea: [],

 config: {
  prefix: "dynDiv_",
  cookie: {
   expire: "2678400" // 31 * 24 * 60 * 60 = 31 days
  },
  regExp: {
   px: /(\d+)px/,
   minmax: /dynDiv_minmaxDiv|dynDiv_moveParentDiv/
  }
 },

 cache: {
  obj: null,
  elem: null,
  modus: null,
  zIndex: null,
  width: null,
  height: null,
  pos: {
   left: null,
   top: null
  },
  init: {
   width: null,
   height: null,
   pos: {
    left: null,
    top: null
   },
   offset: null
  },
  last: {
   obj: null,
   elem: null,
   mouse: {
    left: null,
    top: null
   }
  },
  browser: {
   support: {
    page: false,
    client: false
   }
  },
  unloadHandler: null,
  ie: (window.detachEvent) ? true : false
 },

 limit: {
  min: {
   left: null,
   top: null,
   width: null,
   height: null
  },
  max: {
   left: null,
   top: null,
   width: null,
   height: null
  }
 },

 divList: [],

/*
  divList Struction
  ================================================================================
  0.  Object:[Object]        - Movable Object
  1.  Limiter:[Object]       - Object to which the dynDIV is limited
  2.  Status:[Boolean]       - Active or Inactive
  3.  zIndex:[Number]        - Init. zIndex for the dynDIV
  4.  left:[Number]          - Init. Position left
  5.  top:[Number]           - Init. Position top
  6.  dropLimit:[Text]       - Contain the dropArea which the dynDIV is limited
  7.  dropMode:[Text]        - Set up the dropMode for the dropArea (default,center,fit)
  8.  dropLog:[Boolean]      - Is true when the dynDIV was dropped into the dropArea
  9.  hideAction:[Text]      - Hide other DIVs for move or resize
  10. showResize:[Text]      - Show resize DIVs only on active or double click
  11. keepAspect:[Number]    - Keep the Aspect Ration of the DIV
  12. saveSettings:[Text]    - Save the Position and/or the Dimension of the Element in a Cookie
  13. width:[Number]         - Init Width in px
  14. height:[Number]        - Init Height in px
  ================================================================================
*/

 /*
  This include all get Methodes
 */
 get: {
  /* Warper for prefix request */
  prefix : {
   value: function (obj,value,ncs) {
    return ByRei_dynDiv.get.value(obj, ByRei_dynDiv.config.prefix + value, ncs);
   }
  },

  /* Check an Array for certain values and return the result */
  value: function (obj,value,ncs) {
   var
    i,
    result='',
    il = obj.length;
   if (obj && value) {
       for (i=0;i<il;i++) {
            if (ncs && obj[i].indexOf(value) >= 0) {
                result=obj[i].split(value)[1];
                break;
            } else if (obj[i] === value) {
                result=obj[i];
                break;
            }
       }
   }
   return result;
  },
  /* Set the standart variables for the selected Object */
  pos:  function(obj) {
   if (obj) {
    ByRei_dynDiv.cache.init = {
     width  : obj.clientWidth,
     height : obj.clientHeight,
     pos : {
      left : ByRei_dynDiv.cache.pos.left,
      top  : ByRei_dynDiv.cache.pos.top
     },
     offset : ByRei_dynDiv.get.offset.absolute(obj)
    };
    ByRei_dynDiv.db(2,true);
    ByRei_dynDiv.db(4,ByRei_dynDiv.get.offset.relative(obj).left);
    ByRei_dynDiv.db(5,ByRei_dynDiv.get.offset.relative(obj).top);
   }
  },
  px: function(obj) {
   var result = "";
   if (obj) {
       if (obj.match(ByRei_dynDiv.config.regExp.px)) {
           if (typeof obj.match(ByRei_dynDiv.config.regExp.px)[1] !== 'undefined') {
               result = obj.match(ByRei_dynDiv.config.regExp.px)[1];
           }
       }
   }
   return result;
  },
  /* Try to find the current mouse Position */
  mouse: function(evt) {
   if (evt) {
      if (!ByRei_dynDiv.cache.browser.support.page && !ByRei_dynDiv.cache.browser.support.client) {
          ByRei_dynDiv.cache.browser.support.page = (evt.pageX || evt.pageY) ? true : false;
          ByRei_dynDiv.cache.browser.support.client = (evt.clientX || evt.clientY) ? true : false;
      }
      if (ByRei_dynDiv.cache.browser.support.page) {
          ByRei_dynDiv.cache.pos.left = evt.pageX;
          ByRei_dynDiv.cache.pos.top = evt.pageY;
      } else if (ByRei_dynDiv.cache.browser.support.client) {
          ByRei_dynDiv.cache.pos.left = evt.clientX + document.body.scrollLeft + document.documentElement.scrollLeft;
          ByRei_dynDiv.cache.pos.top = evt.clientY + document.body.scrollTop + document.documentElement.scrollTop;
      }
   }
  },
  /* Offset Calcucation */
  offset: {
   /* Calculate the absolute offset for a object */
   absolute: function(obj) {
    var
     left = 0, top = 0;
    if (obj) {
        left = ByRei_dynDiv.get.offset.relative(obj).left;
        top = ByRei_dynDiv.get.offset.relative(obj).top;
        while (obj.offsetParent) {
               left += ByRei_dynDiv.get.offset.relative(obj.offsetParent).left;
               top += ByRei_dynDiv.get.offset.relative(obj.offsetParent).top;
               obj = obj.offsetParent;
        }
    }
    return {left: left, top: top};
   },
   /* Calculate the relative offset for a object (with browser bug checking) */
   relative: function(obj) {
    var result = false;
    if (obj) {
        var
         borderLeft = 0,
         borderTop = 0,
         marginLeft = ByRei_dynDiv.get.px(ByRei_dynDiv._style(obj,'marginLeft')),
         marginTop = ByRei_dynDiv.get.px(ByRei_dynDiv._style(obj,'marginTop')),
         left = ByRei_dynDiv.get.px(ByRei_dynDiv._style(obj,'left')),
         top = ByRei_dynDiv.get.px(ByRei_dynDiv._style(obj,'top')),
         offsetLeft = obj.offsetLeft,
         offsetTop = obj.offsetTop;

        if (left !== "" && top !== "" && (offsetLeft > left + marginLeft || offsetTop > top + marginTop)) {
            borderLeft = ByRei_dynDiv.get.px(ByRei_dynDiv._style(obj.parentNode,'borderLeft'));
            borderTop = ByRei_dynDiv.get.px(ByRei_dynDiv._style(obj.parentNode,'borderTop'));
        }

        result = {
         left: (borderLeft > 0) ? offsetLeft - borderLeft : offsetLeft,
         top: (borderTop > 0) ? offsetTop - borderTop : offsetTop
        };
    }
    return result;
   }
  },
  /* Try to found the real parent of an object with the help of RegExp */
  parent: function(obj,value,mode) {
   if (obj) {
       for (var i=0;i<5;i++) {
            if (value.test(obj.className)) {
                if (mode) {
                    obj = obj.parentNode;
                } else {
                    break;
                }
            } else {
                if (mode) {
                    break;
                } else {
                    obj = obj.parentNode;
                }
            }
       }
       return obj;
   }
  },
  /* Search for things in the db */
  db: {
   id: function(obj) {
    var
     i,
     result = {
      found : false, data  : ""
     },
     il = ByRei_dynDiv.divList.length;

    if (obj) {
        for (i=0;i<il;i++) {
             if (obj === 'zIndex') {
                 if (ByRei_dynDiv.divList[i][3] !== 'auto') {
                     if (ByRei_dynDiv.divList[i][3] > result.data) {
                         result.found = true;
                         result.data = ByRei_dynDiv.divList[i][3];
                      }
                 }
             }
             else if (ByRei_dynDiv.divList[i][0] === obj) {
                      result.found = true;
                      result.data = i;
                      break;
             }
        }
    }
    return result;
   }

  },
  /* Check Hit from between two Objects */
  hit: function(elem1, elem2, modus) {
   var result=false;
   if (elem1 && elem2) {
    var
     obj1 = {
      offset : ByRei_dynDiv.get.offset.absolute(elem1),
      width  : elem1.clientWidth,
      height : elem1.clientHeight
     },
     obj2 = {
      offset : ByRei_dynDiv.get.offset.absolute(elem2),
      width  : elem2.clientWidth,
      height : elem2.clientHeight
     },
     cache = {
      o1t_o1h : obj1.offset.top + obj1.height,
      o2t_o2h : obj2.offset.top + obj2.height,
      o1l_o1w : obj1.offset.left + obj1.width,
      o2l_o2w : obj2.offset.left + obj2.width
     };

    // Check Hit
    switch (modus) {
     case "fit": case "center":
      if (((obj1.offset.left > obj2.offset.left && obj1.offset.left < cache.o2l_o2w) && ((obj1.offset.top > obj2.offset.top && obj1.offset.top < cache.o2t_o2h) || (cache.o1t_o1h > obj2.offset.top && cache.o1t_o1h < cache.o2t_o2h))) || ((cache.o1l_o1w > obj2.offset.left && cache.o1l_o1w < cache.o2l_o2w) && ((obj1.offset.top > obj2.offset.top && obj1.offset.top < cache.o2t_o2h) || (cache.o1t_o1h > obj2.offset.top && cache.o1t_o1h < cache.o2t_o2h)))) {
          result=true;
      }
     break;
     default:
      if ((obj1.offset.left > obj2.offset.left && obj1.offset.left < cache.o2l_o2w && cache.o1l_o1w < cache.o2l_o2w) && (obj1.offset.top > obj2.offset.top && obj1.offset.top < cache.o2t_o2h && cache.o1t_o1h < cache.o2t_o2h)) {
          result=true;
      }
     break;
    }
   }
   return result;
  }

 },

 /*
  This include all on(action) Methodes
 */
 on: {
  /* Mouse Move Events */
  move: function(evt) {
   if(ByRei_dynDiv.cache.obj) {
      ByRei_dynDiv.get.mouse(evt); // Get Mouse Position
      if (ByRei_dynDiv.get.db.id('zIndex').found) {
          ByRei_dynDiv._style(ByRei_dynDiv.cache.obj,'zIndex', ByRei_dynDiv.get.db.id('zIndex').data + 1);
      }
      if (ByRei_dynDiv.cache.modus) {
          if (ByRei_dynDiv.api.alter) {ByRei_dynDiv.api.alter();} // API move Event
          switch (ByRei_dynDiv.cache.modus) {
            case "br": case "tr": case "tl": case "bl": ByRei_dynDiv.resize(); break;
            case "move":  case "moveparent" : ByRei_dynDiv.move(); break;
            default: break;
          }
      }
      if (ByRei_dynDiv.cache.ie) {evt.returnValue = false;}
   }
  },
  /* Set Event Handler only when an Object is active */
  action: function() {
   if (!ByRei_dynDiv.cache.obj) {
       ByRei_dynDiv.set_eventListener(document, 'mousemove' , ByRei_dynDiv.on.move); // Add Event for MouseMove (scale, move, hide, show)
       ByRei_dynDiv.set_eventListener(document, 'mouseup', ByRei_dynDiv.on.stop); // Stop all Events on MouseUP
   }
  },
  /* Events when noAction will performance (mouse_down)*/
  stop: function() {
   if (ByRei_dynDiv.db(0)) { // DB Functions
       if (ByRei_dynDiv.db(6)) { // Drop Area Support
           var
            i,
            dropArea = {
            obj: false
           },
           il = ByRei_dynDiv.dropArea.length;

           for (i=0;i<il;i++) {
                if (ByRei_dynDiv.dropArea[i][1] === ByRei_dynDiv.db(6)) {
                    if (ByRei_dynDiv.get.hit(ByRei_dynDiv.cache.obj, ByRei_dynDiv.dropArea[i][0], ByRei_dynDiv.db(7))) {
                        dropArea.obj = ByRei_dynDiv.dropArea[i][0];
                    }
                }
           }

           if (!dropArea.obj) {
               ByRei_dynDiv.set.left(ByRei_dynDiv.cache.obj,ByRei_dynDiv.db(4));
               ByRei_dynDiv.set.top(ByRei_dynDiv.cache.obj,ByRei_dynDiv.db(5));
           } else {
               dropArea.offset = ByRei_dynDiv.get.offset.absolute(dropArea.obj);
               switch (ByRei_dynDiv.db(7)) {
                 case "fit" :
                  ByRei_dynDiv.set.left(ByRei_dynDiv.cache.obj, ByRei_dynDiv.db(4) + (dropArea.offset.left - ByRei_dynDiv.cache.init.offset.left));
                  ByRei_dynDiv.set.top(ByRei_dynDiv.cache.obj,  ByRei_dynDiv.db(5) + (dropArea.offset.top - ByRei_dynDiv.cache.init.offset.top));
                 break;
                 case "center" :
                  ByRei_dynDiv.set.left(ByRei_dynDiv.cache.obj, ByRei_dynDiv.db(4) + (dropArea.offset.left - ByRei_dynDiv.cache.init.offset.left) + ((dropArea.obj.clientWidth/2) - (ByRei_dynDiv.cache.obj.clientWidth/2)));
                  ByRei_dynDiv.set.top(ByRei_dynDiv.cache.obj,  ByRei_dynDiv.db(5) + (dropArea.offset.top - ByRei_dynDiv.cache.init.offset.top) + ((dropArea.obj.clientHeight/2) - (ByRei_dynDiv.cache.obj.clientHeight/2)));
                 break;
               }
               ByRei_dynDiv.db(8, true);
           }
       }
   }

   // Normal Event Handling
   ByRei_dynDiv.db(2,false); // Active to Inactive
   ByRei_dynDiv.del_eventListener(document, 'mousemove' , ByRei_dynDiv.on.move); // Remove Event Listener Mouse Move
   ByRei_dynDiv.del_eventListener(document, 'mouseup', ByRei_dynDiv.on.stop);     // Remove Event Listener Mouse Up
   ByRei_dynDiv._style(ByRei_dynDiv.cache.obj,'zIndex', ByRei_dynDiv.cache.zIndex); // Reset zIndex to initial value
   if (ByRei_dynDiv.cache.last.obj !== ByRei_dynDiv.cache.obj) {ByRei_dynDiv.cache.last.obj = ByRei_dynDiv.cache.obj;} // Set Cache last Object
   if (ByRei_dynDiv.cache.last.elem !== ByRei_dynDiv.cache.elem) {ByRei_dynDiv.cache.last.elem = ByRei_dynDiv.cache.elem;} // Set Cache last Element
   if (ByRei_dynDiv.db(9)) {ByRei_dynDiv.set.visible(true);} // Show hiden dynDIVs
   if (ByRei_dynDiv.db(10) === 'focus') {ByRei_dynDiv.set_eventListener(document,'mousedown', ByRei_dynDiv.on.focus);} // Hide Resize on click on other Elements

   // Save Position and Size in DB
   ByRei_dynDiv.db(4,ByRei_dynDiv.get.offset.relative(ByRei_dynDiv.cache.obj).left);
   ByRei_dynDiv.db(5,ByRei_dynDiv.get.offset.relative(ByRei_dynDiv.cache.obj).top);
   ByRei_dynDiv.db(13,ByRei_dynDiv.cache.obj.clientWidth);
   ByRei_dynDiv.db(14,ByRei_dynDiv.cache.obj.clientHeight);

   if (ByRei_dynDiv.api.drop) {ByRei_dynDiv.api.drop();} // API drop Event

   // Reset to default Values
   ByRei_dynDiv.limit.min.left = ByRei_dynDiv.limit.min.top = ByRei_dynDiv.limit.min.width = ByRei_dynDiv.limit.min.height =
   ByRei_dynDiv.limit.min.left = ByRei_dynDiv.limit.min.top = ByRei_dynDiv.limit.min.width = ByRei_dynDiv.limit.min.height =
   ByRei_dynDiv.cache.obj = ByRei_dynDiv.cache.modus = ByRei_dynDiv.cache.zIndex = ByRei_dynDiv.cache.elem = false;
  },
  /* Focus Handler for the webpage */
  focus: function() {
   if (typeof ByRei_dynDiv.divList[ByRei_dynDiv.cache.last.elem] !== 'undefined') {
       if (ByRei_dynDiv.divList[ByRei_dynDiv.cache.last.elem][10] === 'focus') {
           ByRei_dynDiv.on.resize(ByRei_dynDiv.cache.last.obj,false);
       }
       ByRei_dynDiv.del_eventListener(document, 'mousedown', ByRei_dynDiv.on.focus); // Remove Event
   }
  },
  /* Unload Handler for the webpage */
  unload: function() {
   if (ByRei_dynDiv.divList) {
       ByRei_dynDiv.settings.save(); // Save Position and Height of all marked DIVs
   }
  },
  /* Init min max Div function */
  minmax: function(evt) {
   if (evt) {
       var
        evt_src = (evt.target) ? evt.target : evt.srcElement,
        minmax_src = ByRei_dynDiv.get.parent(evt_src,ByRei_dynDiv.config.regExp.minmax,0),
        minmaxHeight = (ByRei_dynDiv.get.prefix.value(minmax_src.className.split(' '),"minmax_Height-",1)||20);
       evt_src = ByRei_dynDiv.get.parent(evt_src,ByRei_dynDiv.config.regExp.minmax,1);
       ByRei_dynDiv._style(evt_src,'clip', (new RegExp (minmaxHeight + "\\w+,?\\s?auto","i").test(ByRei_dynDiv._style(evt_src,'clip'))) ?  'rect(auto auto auto auto)' : 'rect(auto auto ' +  (minmaxHeight) +'px auto)');
   }
  },
  /* Resize Handler */
  resize: function(evt,value) {
   var
    i,
    evt_src = (evt.target || evt.srcElement) ? (evt.target ? evt.target : evt.srcElement) : (evt),
    classNames = evt_src.className.split(' '),
    resize_list = (ByRei_dynDiv.get.prefix.value(classNames,"moveParentDiv") && evt_src.parentNode) ? evt_src.parentNode.getElementsByTagName('div')  : evt_src.getElementsByTagName('div'),
    il = resize_list.length;

    for (i=0;i<il;i++) {
         if (ByRei_dynDiv.get.prefix.value(resize_list[i].className.split(' '),"resizeDiv_",1)) {
             ByRei_dynDiv._style(resize_list[i],'visibility', (value) ? 'visible' : 'hidden');
        }
    }
  }
 },

 /*
  This include all init functions
 */
 init: {
  /* Init Events for all div with dynDiv_ as className */
  main: function() {
   var
    i = 0,
    div_list = document.getElementsByTagName('div'),
    il = div_list.length;
   for (var obj=0;obj<il;obj++) {
        if (ByRei_dynDiv.get.prefix.value(div_list[obj].className.split(' '),"",1)) {
            if (ByRei_dynDiv.get.prefix.value(div_list[obj].className.split(' '),"resizeDiv_",1) && ByRei_dynDiv.get.prefix.value(div_list[obj].parentNode.className.split(' '),"move",1) === '') {
                ByRei_dynDiv.add(div_list[obj].parentNode,i++,1);
            }
            ByRei_dynDiv.add(div_list[obj],i++);
        }
   }
  },
  /* Init Action on MouseMove */
  action: function(evt, m_modus) {
  if (evt) {
      if (evt.preventDefault) {evt.preventDefault();}
      if (ByRei_dynDiv.cache.ie) {evt.cancelBubble=true;}
      if (evt.stopPropagation) {evt.stopPropagation();}
      var evt_src = evt.target ? evt.target : evt.srcElement;

      // Avoid Issues with minmax
      if (evt_src.className.indexOf('dynDiv_minmaxDiv') === -1) {
          ByRei_dynDiv.get.mouse(evt);
          ByRei_dynDiv.on.action();
          switch (m_modus) {
           case "move":
            ByRei_dynDiv.cache.obj = ByRei_dynDiv.api.obj = ByRei_dynDiv.get.parent(evt_src,/dynDiv_moveDiv/);
           break;
           case "moveparent":
            ByRei_dynDiv.cache.obj = ByRei_dynDiv.api.obj = ByRei_dynDiv.get.parent(evt_src,/dynDiv_moveParentDiv/).parentNode;
           break;
           case "tl" : case "tr" : case "bl" : case "br" :
            ByRei_dynDiv.cache.obj = ByRei_dynDiv.api.obj = evt_src.parentNode;
           break;
           default:
            ByRei_dynDiv.cache.obj = ByRei_dynDiv.api.obj = evt_src;
           break;
          }

          ByRei_dynDiv.cache.elem = ByRei_dynDiv.api.elem = ByRei_dynDiv.get.db.id(ByRei_dynDiv.cache.obj).data; // Cache Element
          ByRei_dynDiv.cache.zIndex = ByRei_dynDiv._style(ByRei_dynDiv.cache.obj,'zIndex'); // Cache zIndex
          ByRei_dynDiv.get.pos(ByRei_dynDiv.cache.obj); // Get Position of Element
          ByRei_dynDiv.cache.modus = m_modus; // Cache Modus

             if (ByRei_dynDiv.db(1) && ByRei_dynDiv.cache.obj) {
                 var
               obj = {offset :  ByRei_dynDiv.get.offset.absolute(ByRei_dynDiv.cache.obj)}, limit = {offset : ByRei_dynDiv.get.offset.absolute(ByRei_dynDiv.db(1))};

               ByRei_dynDiv.limit.min.left = limit.offset.left - obj.offset.left;
                 ByRei_dynDiv.limit.max.left = (ByRei_dynDiv.db(1).clientWidth + limit.offset.left) - (ByRei_dynDiv.cache.obj.offsetWidth + obj.offset.left);
                 ByRei_dynDiv.limit.min.top = limit.offset.top - obj.offset.top;
                 ByRei_dynDiv.limit.max.top = (ByRei_dynDiv.db(1).clientHeight + limit.offset.top) - (ByRei_dynDiv.cache.obj.offsetHeight + obj.offset.top);
             }
          if (ByRei_dynDiv.api.drag) {ByRei_dynDiv.api.drag();} // API drag Event

          switch(m_modus){
           case "move" : case "moveparent" :
            if (ByRei_dynDiv.db(9) === 'move' || ByRei_dynDiv.db(9) === 'move_resize') {ByRei_dynDiv.set.visible(false);}
           break;
           case "tl" : case "tr" : case "bl" : case "br" :
            if (ByRei_dynDiv.db(9) === 'resize' || ByRei_dynDiv.db(9) === 'move_resize') {ByRei_dynDiv.set.visible(false);}
           break;
          }

          if (ByRei_dynDiv.cache.elem !== ByRei_dynDiv.cache.last.elem && (ByRei_dynDiv.cache.last.elem || ByRei_dynDiv.cache.last.elem === 0)) {
              if (ByRei_dynDiv.divList[ByRei_dynDiv.cache.last.elem][10]) {
                  ByRei_dynDiv.on.resize(ByRei_dynDiv.cache.last.obj,false);
              }
          }
          if (ByRei_dynDiv.db(10) === 'active' || ByRei_dynDiv.db(10) === 'focus') {
              ByRei_dynDiv.on.resize(ByRei_dynDiv.cache.obj,true);
          }
      }
   }
  }
 },

 /*
  This include the Settings possibilitys
 */
 settings: {
  /* Save Settings */
  save: function() {
   if (ByRei_dynDiv.divList) {
       var
       i,
       il = ByRei_dynDiv.divList.length;
       for (i=0;i<il;i++) {
            if (ByRei_dynDiv.divList[i][12] !== false && ByRei_dynDiv.divList[i][0].id) {
                var
                 left='',
                 top='',
                 width='',
                 height='';

                switch(ByRei_dynDiv.divList[i][12]) {
                 case "position":
                  left = ByRei_dynDiv.divList[i][4];
                  top = ByRei_dynDiv.divList[i][5];
                 break;
                 case "size":
                  width = ByRei_dynDiv.divList[i][13];
                  height = ByRei_dynDiv.divList[i][14];
                 break;
                 case "position_size" :
                  left = ByRei_dynDiv.divList[i][4];
                  top = ByRei_dynDiv.divList[i][5];
                  width = ByRei_dynDiv.divList[i][13];
                  height = ByRei_dynDiv.divList[i][14];
                 break;
                }

                if ((Number(left) !== 'NaN' && Number(top) !== 'NaN') || (width > 0 && height > 0)) {
                    if (navigator.cookieEnabled) {
                        var expireTime = new Date();
                        expireTime.setSeconds((new Date()).setTime(expireTime.getSeconds()) + Number(ByRei_dynDiv.config.cookie.expire));
                        document.cookie = "ByRei_dynDiv_" + ByRei_dynDiv.divList[i][0].id + "=" + left + '_' + top + '_' + width + '_' + height +  "; expires=" + expireTime.toGMTString();
                    }
                }
            }
       }
   }
  },
  /* Load Settings */
  load: function(id) {
   var result = false;
   if (navigator.cookieEnabled && id) {
       var savedata = document.cookie;
       if (/; /.test(savedata)) {savedata = savedata.split("; ");}
       else if (/, /.test(savedata)) {savedata = savedata.split(", ");}
       if (savedata) {
           var i, il = savedata.length;
           for (i=0;i<il;i++) {
                if (savedata[i]) {
                    if ((/ByRei_dynDiv/).test(savedata[i])) {
                        var data = (/ByRei_dynDiv_(\w+)=(\d*)\_(\d*)\_(\d*)\_(\d*)/).exec(savedata[i]);
                        if (typeof data !== 'undefined' && data !== null) {
                            if (typeof data[1] !== 'undefined') {
                                if (data[1] === id) {
                                    result = {left: data[2], top: data[3], width: data[4], height: data[5]};
                                    break;
                                }
                            }
                        }
                    }
                }
           }
       }
   }
   return result;
  }
 },

 /*
  All set Functions
 */
 set: {
  /* Set visible / invisible */
  visible: function(value) {
   var
    i,
    il = ByRei_dynDiv.divList.length;
   for (i=0;i<il;i++) {
        if (ByRei_dynDiv.divList[i] !== ByRei_dynDiv.divList[ByRei_dynDiv.cache.elem]) {
            ByRei_dynDiv._style(ByRei_dynDiv.divList[i][0],'visibility',(value) ? 'visible' : 'hidden');
        }
   }
  },
  /* Simple Warper to avoid to include "px" on every value */
  /* More warper for left, top, width, height */
  left: function(obj,value) {
   ByRei_dynDiv._style(obj,'left',value + "px");
  },
  top: function(obj,value) {
   ByRei_dynDiv._style(obj,'top',value + "px");
  },
  width: function(obj,value) {
   ByRei_dynDiv._style(obj,'width',value + "px");
  },
  height: function(obj,value) {
   ByRei_dynDiv._style(obj,'height',value + "px");
  }
 },

 /*
  Resize DIV
 */
 resize: function() {
  if (ByRei_dynDiv.cache.obj && ByRei_dynDiv.cache.modus) {
      var
       default_padding = 20,
       new_size_x = 0,
       new_size_y = 0,
       new_left = ByRei_dynDiv.db(4),
       new_top = ByRei_dynDiv.db(5),
       keepAspect = ByRei_dynDiv.db(11),
       reachLimit = false,
       mouse_diff_left = (ByRei_dynDiv.cache.pos.left - ByRei_dynDiv.cache.init.pos.left || 0),
       mouse_diff_top = (ByRei_dynDiv.cache.pos.top - ByRei_dynDiv.cache.init.pos.top || 0);

      // Try to keep Aspect Ratio
      /* Maus so abfragen das Mouse nicht größers als Offset von Object sein kann ! */
      if (keepAspect) {
          switch(ByRei_dynDiv.cache.modus) {
           case "br" : case "tl" :
            mouse_diff_left = mouse_diff_top * keepAspect;
           break;
           case "bl" : case "tr" :
            mouse_diff_left = mouse_diff_top * keepAspect * -1;
           break;
          }
          if (ByRei_dynDiv.cache.last.mouse.left === ByRei_dynDiv.cache.pos.left || ByRei_dynDiv.cache.last.mouse.top === ByRei_dynDiv.cache.pos.top) {
              reachLimit = true;
          }
          ByRei_dynDiv.cache.last.mouse.left = ByRei_dynDiv.cache.pos.left;
          ByRei_dynDiv.cache.last.mouse.top = ByRei_dynDiv.cache.pos.top;
      }

      // Scaling DIV depend on the Modus
      switch(ByRei_dynDiv.cache.modus) {
       case "br": case "tr": new_size_x = ByRei_dynDiv.cache.init.width + mouse_diff_left; break;
       case "tl": case "bl": new_size_x = ByRei_dynDiv.cache.init.width - mouse_diff_left; break;
      }

      switch(ByRei_dynDiv.cache.modus) {
       case "br": case "bl": new_size_y = ByRei_dynDiv.cache.init.height + mouse_diff_top; break;
       case "tr": case "tl": new_size_y = ByRei_dynDiv.cache.init.height - mouse_diff_top; break;
      }

      switch(ByRei_dynDiv.cache.modus) {
       case "tl": new_top  = ByRei_dynDiv.db(5) + mouse_diff_top; new_left = ByRei_dynDiv.db(4) + mouse_diff_left; break;
       case "tr": new_top  = ByRei_dynDiv.db(5) + mouse_diff_top; break;
       case "bl": new_left = ByRei_dynDiv.db(4) + mouse_diff_left; break;
      }

      /* Check if Limit is reached (normal, keep aspect) */
      if (ByRei_dynDiv.db(1)) {
          var
           pos_left = ByRei_dynDiv.cache.pos.left - ByRei_dynDiv.cache.init.pos.left,
           pos_top = ByRei_dynDiv.cache.pos.top - ByRei_dynDiv.cache.init.pos.top;

          switch(ByRei_dynDiv.cache.modus) {
           case "tl": case "bl":
            if (pos_left < ByRei_dynDiv.limit.min.left) {
                if (!keepAspect) {
                    new_size_x = ByRei_dynDiv.cache.init.width - ByRei_dynDiv.limit.min.left;
                    new_left = ByRei_dynDiv.db(4) + ByRei_dynDiv.limit.min.left;
                }
                reachLimit = true;
            }
           break;
           case "tr": case "br":
            if (pos_left > ByRei_dynDiv.limit.max.left) {
                if (!keepAspect) {
                    new_size_x = ByRei_dynDiv.cache.init.width + ByRei_dynDiv.limit.max.left;
                }
                reachLimit = true;
            }
           break;
          }

          switch(ByRei_dynDiv.cache.modus) {
           case "tl": case "tr":
            if (pos_top < ByRei_dynDiv.limit.min.top)  {
                if (!keepAspect) {
                    new_size_y = ByRei_dynDiv.cache.init.height - ByRei_dynDiv.limit.min.top;
                    new_top  = ByRei_dynDiv.db(5) + ByRei_dynDiv.limit.min.top;
                }
                reachLimit = true;
            }
           break;
           case "bl": case "br":
            if (pos_top > ByRei_dynDiv.limit.max.top)  {
                if (!keepAspect) {
                    new_size_y = ByRei_dynDiv.cache.init.height + ByRei_dynDiv.limit.max.top;
                }
                reachLimit = true;
            }
           break;
          }
      }

      // Check for min. Size (20x20)
      if (keepAspect) {
          if (!reachLimit && new_size_x > default_padding && new_size_y > default_padding) {
              ByRei_dynDiv.set.width(ByRei_dynDiv.cache.obj,new_size_x);
              ByRei_dynDiv.set.height(ByRei_dynDiv.cache.obj,new_size_y);
              ByRei_dynDiv.set.left(ByRei_dynDiv.cache.obj,new_left);
              ByRei_dynDiv.set.top(ByRei_dynDiv.cache.obj,new_top);
          }
      } else {
          if (new_size_x > default_padding) {
              ByRei_dynDiv.set.width(ByRei_dynDiv.cache.obj,new_size_x);
              ByRei_dynDiv.set.left(ByRei_dynDiv.cache.obj,new_left);
          }
          if (new_size_y > default_padding) {
              ByRei_dynDiv.set.height(ByRei_dynDiv.cache.obj,new_size_y);
              ByRei_dynDiv.set.top(ByRei_dynDiv.cache.obj,new_top);
          }
      }
  }
 },

 /*
  Move DIV
 */
 move: function() {
  if (ByRei_dynDiv.cache.obj) {
      var
       new_left = ByRei_dynDiv.cache.pos.left - (ByRei_dynDiv.cache.init.pos.left - ByRei_dynDiv.db(4)),
       new_top  = ByRei_dynDiv.cache.pos.top - (ByRei_dynDiv.cache.init.pos.top - ByRei_dynDiv.db(5));

      // Check for Div Limit
      if (ByRei_dynDiv.db(1)) {
          var
           pos_x  = ByRei_dynDiv.cache.pos.left - ByRei_dynDiv.cache.init.pos.left,
           pos_y  = ByRei_dynDiv.cache.pos.top - ByRei_dynDiv.cache.init.pos.top;

          if (pos_x < ByRei_dynDiv.limit.min.left) {new_left = ByRei_dynDiv.db(4) + ByRei_dynDiv.limit.min.left;}
          else if (pos_x > ByRei_dynDiv.limit.max.left) {new_left = ByRei_dynDiv.db(4) + ByRei_dynDiv.limit.max.left;}

          if (pos_y < ByRei_dynDiv.limit.min.top)  {new_top  = ByRei_dynDiv.db(5) + ByRei_dynDiv.limit.min.top;}
          else if (pos_y > ByRei_dynDiv.limit.max.top)  {new_top  = ByRei_dynDiv.db(5) + ByRei_dynDiv.limit.max.top;}
      }

      if (!isNaN(new_left)) {ByRei_dynDiv.set.left(ByRei_dynDiv.cache.obj,new_left);}
      if (!isNaN(new_top))  {ByRei_dynDiv.set.top(ByRei_dynDiv.cache.obj,new_top);}
  }
 },

 /*
  Small DB System
 */
 db: function(i,value) { // db(1) return value / db(1,1) set value
  var result=false;
  if (ByRei_dynDiv.cache.elem >= 0) {
      if (ByRei_dynDiv.divList[ByRei_dynDiv.cache.elem]) {
          if (typeof ByRei_dynDiv.divList[ByRei_dynDiv.cache.elem][i] !== 'undefined') {
              if (typeof value !== 'undefined') {
                  ByRei_dynDiv.divList[ByRei_dynDiv.cache.elem][i] = value;
                  result = true;
              } else {
                  result = ByRei_dynDiv.divList[ByRei_dynDiv.cache.elem][i];
              }
          }
      }
  }
  return result;
 },

 /*
  Add Object to dynDiv and add dynDiv Events and Effects
 */
 add: function(elem,i,mode) {
  if (elem) {
      var
       zIndex = 'auto',
       classNames = elem.className.split(' '),
       func_z_index = function(obj,i) {return (ByRei_dynDiv._style(obj,'zIndex')||ByRei_dynDiv._style(obj,'zIndex', i));};

      if (ByRei_dynDiv.get.prefix.value(classNames,"",1) || mode) {
          var
           limiter = null,
           droplimiter = false,
           dropmode = false,
           hideaction = false,
           showresize = false,
           keepAspect = false,
           saveSettings = false,
           parent = elem,
           modus = ByRei_dynDiv.get.prefix.value(classNames,"",1),
           l_parent = parent.parentNode;

          // Set Event Handler for Moveing and Resizing and other handlers
          if (modus) {
              switch (modus) {
               case "moveDiv":
                ByRei_dynDiv._style(parent,'cursor','move');
                ByRei_dynDiv.set_eventListener(parent,'mousedown', function(e) {ByRei_dynDiv.init.action(e,'move');});
                zIndex = func_z_index(parent,i);
               break;
               case "moveParentDiv":
                ByRei_dynDiv._style(parent,'cursor','move');
                ByRei_dynDiv.set_eventListener(parent,'mousedown',  function(e) {ByRei_dynDiv.init.action(e,'moveparent');});
                parent = parent.parentNode;
                zIndex = func_z_index(parent,i);
               break;
               case "resizeDiv_tl":
                ByRei_dynDiv._style(parent,'cursor','nw-resize');
                ByRei_dynDiv.set_eventListener(parent,'mousedown', function(e) {ByRei_dynDiv.init.action(e,'tl');});
               break;
               case "resizeDiv_tr":
                ByRei_dynDiv._style(parent,'cursor','ne-resize');
                ByRei_dynDiv.set_eventListener(parent,'mousedown', function(e) {ByRei_dynDiv.init.action(e,'tr');});
               break;
               case "resizeDiv_bl":
                ByRei_dynDiv._style(parent,'cursor','sw-resize');
                ByRei_dynDiv.set_eventListener(parent,'mousedown', function(e) {ByRei_dynDiv.init.action(e,'bl');});
               break;
               case "resizeDiv_br":
                ByRei_dynDiv._style(parent,'cursor','se-resize');
                ByRei_dynDiv.set_eventListener(parent,'mousedown', function(e) {ByRei_dynDiv.init.action(e,'br');});
               break;
               case "minmaxDiv":
                 ByRei_dynDiv._style(parent,'cursor','pointer');
                 ByRei_dynDiv.set_eventListener(parent,'mousedown', function(e) {ByRei_dynDiv.on.minmax(e);});
               break;
               case "dropArea":
                 ByRei_dynDiv.dropArea.push([parent,'global']);
               break;
              }
          }

          // Drop Areas specific with name (dynDiv_dropArea-[name])
          if (ByRei_dynDiv.get.prefix.value(classNames,"dropArea-",1)) {
              ByRei_dynDiv.dropArea.push([parent,ByRei_dynDiv.get.prefix.value(classNames,"dropArea-",1)]);
          }

          // Limit Movements
          while (l_parent) {
                 if (l_parent.className) {
                     if (ByRei_dynDiv.get.prefix.value(l_parent.className.split(' '),"setLimit")) {
                         if (parent !== l_parent) {limiter = l_parent;}
                         break;
                     }
                 }
                 l_parent = l_parent.parentNode;
          }

          // Body Limit
          if (!limiter) {
              if (ByRei_dynDiv.get.prefix.value(classNames,"bodyLimit") || ByRei_dynDiv.get.prefix.value(parent.parentNode.className.split(' '),"bodyLimit")) {
                  limiter = document.body;
              }
          }

          // Drop Limit
          if (ByRei_dynDiv.get.prefix.value(classNames,"dropLimit")) {
              droplimiter = 'global';
          } else if (ByRei_dynDiv.get.prefix.value(classNames,"dropLimit-",1)) {
              droplimiter = ByRei_dynDiv.get.prefix.value(classNames,"dropLimit-",1);
          }

          // Drop Mode (fit, center)
          if (ByRei_dynDiv.get.prefix.value(classNames,"dropMode-",1)) {
              dropmode = ByRei_dynDiv.get.prefix.value(classNames,"dropMode-",1);
          }

          // Hide Action (false, move, resize)
          if (ByRei_dynDiv.get.prefix.value(classNames,"hideMove") && ByRei_dynDiv.get.prefix.value(classNames,"hideResize")) {
              hideaction = 'move_resize';
          } else {
              if (ByRei_dynDiv.get.prefix.value(classNames,"hideMove")) {
                  hideaction = 'move';
              } else if (ByRei_dynDiv.get.prefix.value(classNames,"hideResize")) {
                  hideaction = 'resize';
              }
          }

          // Keep Aspect Ration (true,false)
          if (ByRei_dynDiv.get.prefix.value(classNames,"keepAspect")) {
              if (parent.clientWidth && parent.clientHeight) {
                  keepAspect = Math.abs(parent.clientWidth/parent.clientHeight);
              }
          }

          // Show Resize (active, focus, doubleclick)
          if (ByRei_dynDiv.get.prefix.value(classNames,"showResize-",1)) {
              showresize = ByRei_dynDiv.get.prefix.value(classNames,"showResize-",1);
              ByRei_dynDiv.on.resize(parent,false);
              if (showresize === 'dbclick') {ByRei_dynDiv.set_eventListener(parent,'dblclick', function(e) {ByRei_dynDiv.on.resize(e, true);});}
          }

          // Save Position and/or Size
          switch (ByRei_dynDiv.get.prefix.value(classNames,"saveSettings-",1)) {
             case "position":      saveSettings = "position";      break;
             case "size":          saveSettings = "size";          break;
             case "position_size": saveSettings = "position_size"; break;
          }
          if (saveSettings && !ByRei_dynDiv.cache.unloadHandler) {
              ByRei_dynDiv.cache.unloadHandler = ByRei_dynDiv.set_eventListener(window,'unload', ByRei_dynDiv.on.unload);
          }

          // Load Position and/or Size
          if (ByRei_dynDiv.get.prefix.value(classNames,"loadSettings")) {
              var data = ByRei_dynDiv.settings.load(parent.id);
              if (data) {
                  if (Number(data.left) !== 'NaN' && Number(data.top) !== 'NaN') {
                      ByRei_dynDiv.set.left(parent, data.left);
                      ByRei_dynDiv.set.top(parent, data.top);
                  }
                  if (data.width > 0 && data.height > 0) {
                      ByRei_dynDiv.set.width(parent, data.width);
                      ByRei_dynDiv.set.height(parent, data.height);
                  }
              }
          }

          // Write main DIVs in the DIV List
          if (ByRei_dynDiv.get.prefix.value(classNames,"moveParentDiv") || ByRei_dynDiv.get.prefix.value(classNames,"moveDiv") || mode) {
              if (!ByRei_dynDiv.get.db.id(parent).found) {
                  ByRei_dynDiv.divList.push([parent,limiter,false,zIndex,ByRei_dynDiv.get.offset.relative(parent).left,ByRei_dynDiv.get.offset.relative(parent).top,droplimiter,dropmode,false,hideaction,showresize,keepAspect,saveSettings,parent.clientWidth,parent.clientHeight]);
                  }
          }
      }
  }
 },

 /* Small alternative Style Selector to avoid JS Errors and make things easier */
 _style: function(obj,o_style,value) {
  if (obj && o_style) {
     if (obj.style) {
         if (typeof obj.style[o_style] !== 'undefined') {
            if (value) {
                try {return (obj.style[o_style] = value);} catch(e) {return false;}
            } else {
                return (obj.style[o_style] === '') ? ((obj.currentStyle) ? obj.currentStyle[o_style] : ((window.getComputedStyle) ? window.getComputedStyle(obj,'').getPropertyValue(o_style) : false)) : obj.style[o_style];
            }
         }
     }
  }
 },

 /* Remove Event Listener */
 del_eventListener: function(obj,event,func) {
  if (obj && event && func) {
   if (ByRei_dynDiv.cache.ie) {obj.detachEvent("on"+event, func);} else {obj.removeEventListener(event, func, false);}
  }
 },

 /* Add Event Listener */
 set_eventListener: function(obj,event,func) {
  if (obj && event && func) {
   if (ByRei_dynDiv.cache.ie) {return obj.attachEvent("on"+event, func);} else {return obj.addEventListener(event, func, false);}
  }
 }

};

    MonitoringTeamStringLinks();
}

function injectGMFunctionsIntoPage() {
    var injected = true;
    var gmInjectFuncs = {
        setValue: function(name, value) { return GM_setValue(name, value); },
        getValue: function(name, def) { return GM_getValue(name, def); },
        addStyle: function(styles) { return GM_addStyle(styles); },
        copyValueToClipboard: function(text) { return GM_setClipboard(text); }
    };
    if ((typeof createObjectIn !== 'undefined') && (typeof exportFunction !== 'undefined')) {
        var injectedStringLinksGM = createObjectIn(unsafeWindow, {defineAs: "StringLinksGM"});
        exportFunction(gmInjectFuncs.setValue, injectedStringLinksGM, {defineAs: "setValue" });
        exportFunction(gmInjectFuncs.getValue, injectedStringLinksGM, {defineAs: "getValue" });
        exportFunction(gmInjectFuncs.addStyle, injectedStringLinksGM, {defineAs: "addStyle" });
        exportFunction(gmInjectFuncs.copyValueToClipboard, injectedStringLinksGM, {defineAs: "copyValueToClipboard" });
    }
    else {
        StringLinksGM = gmInjectFuncs;
        injected = false;
    }
    return injected;
}

function registerGMMenuCommands(win) {
    GM_registerMenuCommand("String Links: re-index page (Ctrl-Alt-S)", function() { win.StringLinks.removeStringLinks(); win.StringLinks.decorateStrings(false); }, "s", "ctrl alt", "S" );
    GM_registerMenuCommand("String Links: clear links (Ctrl-Alt-Shift-S)", function() { win.StringLinks.removeStringLinks(); } , "s", "ctrl alt shift", "C" );
    GM_registerMenuCommand("String Links: open popup (Ctrl-Shift-Click)", function() { win.StringLinks.openDefaultPopup(); } , "o", "ctrl shift", "O" );
    GM_registerMenuCommand("String Links: incognito mode ON", function() { win.StringLinks.setIncognitoMode("on"); } );
    GM_registerMenuCommand("String Links: incognito mode OFF", function() { win.StringLinks.setIncognitoMode("off"); } );
    GM_registerMenuCommand("String Links: Right-click context menu", function() { win.StringLinks.setRightClickMode(""); } );
    GM_registerMenuCommand("String Links: Ctrl-right-click context menu", function() { win.StringLinks.setRightClickMode("ctrl"); } );
}

function injectStringLinksIntoPage() {
    if (document.body || document.head) {
        var script = document.createElement('script');
        script.appendChild(document.createTextNode('('+ codeWrapper +')(' + isGM() + ');'));
        (document.head || document.body).appendChild(script);
    }
}

if (isGM()) {
    if (injectGMFunctionsIntoPage()) {
        injectStringLinksIntoPage();    // Run StringLinks inside page, to get around GM 2 restrictions
        registerGMMenuCommands(unsafeWindow);
    }
    else {
        codeWrapper(true);              // Run StringLinks within GM context
        registerGMMenuCommands(window);
    }
}
