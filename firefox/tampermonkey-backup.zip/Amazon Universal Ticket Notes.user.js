// ==UserScript==
// @name         Amazon Universal Ticket Notes
// @namespace    http://tampermonkey.net/
// @version      0.4
// @description  Add personal notes to Amazon ticketing systems (t.corp, SIM, Issues, Taskei etc.).
// @author       dhanraaj
// @match        https://t.corp.amazon.com/*
// @match        https://sim.amazon.com/issues/*
// @match        https://issues.amazon.com/issues/*
// @match        https://i.amazon.com/issues/*
// @match        https://taskei.amazon.dev/tasks/*
// @grant        GM_setValue
// @grant        GM_getValue
// @icon         https://tiny.amazon.com/fmygt20w
// @downloadURL https://axzile.corp.amazon.com/-/carthamus/download_script/amazon-universal-ticket-notes.user.js
// @updateURL   https://axzile.corp.amazon.com/-/carthamus/download_script/amazon-universal-ticket-notes.user.js
// ==/UserScript==

(function() {
    'use strict';

    // Define all target selectors in one place
    const SELECTORS = {
        TCORP: 'div[class*="awsui_tabs-header"][class*="awsui_tabs-header-with-divider"]',
        TASKEI: '[data-testid="description-section"]',
        SIM: 'issue-overview-data'  // Note: This is an ID, not a class
    };

    console.log('Ticket Notes Script started');

    function getTicketId() {
        let match;
        const path = window.location.pathname;

        // Don't show notes on search pages
        if (path.endsWith('/search')) {
            return null;
        }

        if (window.location.hostname === 't.corp.amazon.com') {
            match = window.location.pathname.match(/\/([A-Z]\d+)/);
        } else if (window.location.hostname === 'taskei.amazon.dev') {
            match = window.location.pathname.match(/\/tasks\/([\w-]+)/);
        } else {
            // SIM websites
            match = window.location.pathname.match(/\/issues\/([\w-]+)/);
        }
        return match ? match[1] : null;
    }

    function addNotesSection() {
        if (document.getElementById('personal-notes-container')) {
            return;
        }

        const ticketId = getTicketId();
        if (!ticketId) {
            return;
        }

        console.log('Adding notes section for ticket:', ticketId);
        const container = document.createElement('div');
        container.id = 'personal-notes-container';
        container.style.margin = '10px';
        container.style.padding = '10px';
        container.style.border = '1px solid #ccc';
        container.style.boxSizing = 'border-box';

        const title = document.createElement('h4');
        title.textContent = 'Personal Notes (Only visible to you)';

        const textarea = document.createElement('textarea');
        textarea.id = 'personal-notes';
        textarea.style.width = '100%';
        textarea.style.minHeight = '100px';
        textarea.style.margin = '10px 0';
        textarea.value = GM_getValue(ticketId, '');
        textarea.style.boxSizing = 'border-box';
        textarea.style.resize = 'vertical';

        textarea.addEventListener('input', function() {
            GM_setValue(ticketId, this.value);
        });

        container.appendChild(title);
        container.appendChild(textarea);

        // Different target elements based on the site
        let targetElement;
        if (window.location.hostname === 't.corp.amazon.com') {
            targetElement = document.querySelector(SELECTORS.TCORP);
            if (targetElement) {
                console.log('Target element found for ' + window.location.hostname);
                targetElement.parentNode.insertBefore(container, targetElement.nextSibling);
            }
        } else {
            if (window.location.hostname === 'taskei.amazon.dev') {
                targetElement = document.querySelector(SELECTORS.TASKEI);
                container.style.borderRadius = '16px';
            } else {
                // SIM websites
                targetElement = document.getElementById(SELECTORS.SIM);
            }
            if (targetElement) {
                console.log('Target element found for ' + window.location.hostname);
                targetElement.parentNode.insertBefore(container, targetElement);
            }else {
                console.error('Target element NOT found for ' + window.location.hostname);
            }
        }
    }

    // Function to start observing DOM changes
    function startObserving() {
        const observer = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                if (mutation.addedNodes.length) {
                    let targetElement;
                    if (window.location.hostname === 't.corp.amazon.com') {
                        targetElement = document.querySelector(SELECTORS.TCORP);
                    } else if (window.location.hostname === 'taskei.amazon.dev') {
                        targetElement = document.querySelector(SELECTORS.TASKEI);
                    } else {
                        targetElement = document.getElementById(SELECTORS.SIM);
                    }

                    if (targetElement && !document.getElementById('personal-notes-container')) {
                        addNotesSection();
                        break;
                    }
                }
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    // Initial attempt to add notes section
    function tryAddNotes() {
        let targetElement;
        if (window.location.hostname === 't.corp.amazon.com') {
            targetElement = document.querySelector(SELECTORS.TCORP);
        } else if (window.location.hostname === 'taskei.amazon.dev') {
            targetElement = document.querySelector(SELECTORS.TASKEI);
        } else {
            targetElement = document.getElementById(SELECTORS.SIM);
        }

        if (targetElement) {
            console.log('Target element found for ' + window.location.hostname);
            addNotesSection();
        }else {
            console.error('Target element NOT found for ' + window.location.hostname);
        }
    }

    // Listen for URL changes
    let lastUrl = location.href;
    new MutationObserver(() => {
        const url = location.href;
        if (url !== lastUrl) {
            lastUrl = url;
            setTimeout(tryAddNotes, 500);
        }
    }).observe(document, {subtree: true, childList: true});

    // Start everything
    tryAddNotes();
    startObserving();
})();