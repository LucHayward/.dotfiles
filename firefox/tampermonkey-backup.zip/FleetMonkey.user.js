// ==UserScript==
// @name         FleetMonkey
// @namespace    http://amazon.com
// @version      0.10
// @description  Make FleetCop Great Again!
// @author       hardingg@
// @match        https://fleetcop.corp.amazon.com/*
// @match        https://fleetcop-gamma.corp.amazon.com/*
// @match        https://fleetcop.dca.c2s-border.ic.gov/*
// @match        https://fleetcop-gamma.dca.c2s-border.ic.gov/*
// @match        https://fleetcop.lck.aws-border.sgov.gov/*
// @match        https://fleetcop-gamma.lck.aws-border.sgov.gov/*
// @require      https://code.jquery.com/jquery-3.2.1.min.js
// ==/UserScript==

(function() {
    'use strict';

    var $ = window.jQuery;

    $(document).ready(function() {
        // make the FleetCop header link back to the index page
        $("#header h1").wrapInner("<a href='./dashboard.html'></a>");

        // make the index page link to the onboarding pipeline page
        if (window.location === 'https://fleetcop.corp.amazon.com/dashboard.html' ||
            window.location === 'https://fleetcop.corp.amazon.com/index.html' ||
            window.location === 'https://fleetcop.corp.amazon.com/' ||
            window.location === 'https://fleetcop-gamma.corp.amazon.com/dashboard.html' ||
            window.location === 'https://fleetcop-gamma.corp.amazon.com/index.html' ||
            window.location === 'https://fleetcop-gamma.corp.amazon.com/' ||
            window.location === 'https://fleetcop.dca.c2s-border.ic.gov/dashboard.html' ||
            window.location === 'https://fleetcop.dca.c2s-border.ic.gov/index.html' ||
            window.location === 'https://fleetcop.dca.c2s-border.ic.gov/' ||
            window.location === 'https://fleetcop-gamma.dca.c2s-border.ic.gov/dashboard.html' ||
            window.location === 'https://fleetcop-gamma.dca.c2s-border.ic.gov/index.html' ||
            window.location === 'https://fleetcop-gamma.dca.c2s-border.ic.gov/' ||
            window.location === 'https://fleetcop.lck.aws-border.sgov.gov/dashboard.html' ||
            window.location === 'https://fleetcop.lck.aws-border.sgov.gov/index.html' ||
            window.location === 'https://fleetcop.lck.aws-border.sgov.gov/' ||
            window.location === 'https://fleetcop-gamma.lck.aws-border.sgov.gov/dashboard.html' ||
            window.location === 'https://fleetcop-gamma.lck.aws-border.sgov.gov/index.html' ||
            window.location === 'https://fleetcop-gamma.lck.aws-border.sgov.gov/'
        ) {
            $("#detail").prepend("<a href='./pipeline.html'>Onboarding Pipeline</a>");
        }

        // make the index page link to the onboarding pipeline page
        if (window.location.toString().startsWith('https://fleetcop-gamma.corp.amazon.com/pipeline') ||
            window.location.toString().startsWith('https://fleetcop.corp.amazon.com/pipeline') ||
            window.location.toString().startsWith('https://fleetcop-gamma.dca.c2s-border.ic.gov/pipeline') ||
            window.location.toString().startsWith('https://fleetcop.dca.c2s-border.ic.gov/pipeline') ||
            window.location.toString().startsWith('https://fleetcop-gamma.lck.aws-border.sgov.gov/pipeline') ||
            window.location.toString().startsWith('https://fleetcop.lck.aws-border.sgov.gov/pipeline')
        ) {
            var link = $("<div><a href='./dashboard.html'>&lt; Back to Dashboard...</a></div>");
            link.css({
              "margin-left": "1em",
              "margin-top": "1em"
            });
            $("body").prepend(link);
        }

        // add actionable links to all the service detail columns
        var service = $("#service");
        if (service && service.text().trim().startsWith("Service:")) {
            $("#breakdown-inner table tbody tr").each(function() {
                var serviceHref = $(this).find("td:nth-child(2) a").attr("href");
                if (serviceHref) {
                  var serviceUrl = serviceHref.replace(/\/hosts$/, "")
                  function wrapLink(el, url) {
                    if (el) {
                      el.wrapInner("<a href='" + serviceUrl + "/" + url + "' target='_blank'></a>");
                    }
                  };

                  $(this).find("td:nth-child(2) a").attr("href", serviceUrl);

                  wrapLink($(this).find("td:nth-child(3) "), "hosts");              // hosts
                  wrapLink($(this).find("td:nth-child(4) "), "hosts");              // legacy hosts
                  wrapLink($(this).find("td:nth-child(5) "), "stacks");             // capdefs
                  wrapLink($(this).find("td:nth-child(6) "), "service_workflows");  // orders
                  wrapLink($(this).find("td:nth-child(7) "), "service_workflows");  // retirements
                  wrapLink($(this).find("td:nth-child(8) "), "stacks");             // capdefs under capacity
                  wrapLink($(this).find("td:nth-child(9) "), "hosts");              // host age >30 days
                  wrapLink($(this).find("td:nth-child(10)"), "hosts");              // max host age
                  wrapLink($(this).find("td:nth-child(11)"), "stacks");             // unmanaged capdefs
                  wrapLink($(this).find("td:nth-child(12)"), "mutations");          // stuck orders
                  wrapLink($(this).find("td:nth-child(13)"), "mutations");          // stuck buildouts
                  wrapLink($(this).find("td:nth-child(14)"), "mutations");          // failed retirements
                  wrapLink($(this).find("td:nth-child(15)"), "mutations");          // stuck rebuilds
                  wrapLink($(this).find("td:nth-child(17)"), "hosts");              // unmanaged hosts
                  wrapLink($(this).find("td:nth-child(18)"), "hosts");              // host age >25 days
                  wrapLink($(this).find("td:nth-child(19)"), "hosts");              // marked for retirement
                  wrapLink($(this).find("td:nth-child(20)"), "hosts");              // marked for rebuild

                }
            });
        }
    });

})();
