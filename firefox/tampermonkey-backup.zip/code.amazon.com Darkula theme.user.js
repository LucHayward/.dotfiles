// ==UserScript==
// @name         code.amazon.com Darkula theme
// @namespace    https://code.amazon.com/
// @version      0.9.4
// @description  Adds Darkula theme to package view for code.amazon.com. Works best with CodeHopper. https://code.amazon.com/packages/CodeHopper/trees/mainline
// @author       ryhavens@
// @match        https://code.amazon.com/*
// @match        https://code-tcp.corp.amazon.com/*
// @grant        GM_addStyle
// @grant        GM_getResourceText
// @updateURL    https://code.amazon.com/packages/CodeDarkTheme/blobs/mainline/--/src/js/darkulacode.user.js?raw=1
// @downloadURL  https://code.amazon.com/packages/CodeDarkTheme/blobs/mainline/--/src/js/darkulacode.user.js?raw=1
// @resource     darkulaCSS https://code.amazon.com/packages/CodeDarkTheme/blobs/mainline/--/src/css/darkulacode.min.css?raw=1
// @run-at document-start
// ==/UserScript==

/*
 * ==== Changelog ====
 * 0.9.0 - Initial support for new code review dashboard
   - 0.9.1 - Minor fixes
   - 0.9.2 - More full-fledged support, supporting new features
   - 0.9.3 - Add cloudscape dark mode setting to fix black text in new review dashboard https://cloudscape.aws.dev/get-started/dev-guides/dark-mode-implementation/
   - 0.9.4 - Fix 'cr-is-read' css; darken hovered table row (instead of lighten)
 * 0.8.* - Minor fixes to CSS
   - 0.8.8 - Fix code coverage not displaying
   - 0.8.10 - Fix code coverage for partially-covered
   - 0.8.12 - Small changes, compatibility with CodeHopper
   - 0.8.14 - Add matching code-tcp domain
   - 0.8.16 - Minor style fixes based on latest changes to code.amazon.com
   - 0.8.17 - Small fix for CodeTree
   - 0.8.18 - More minor style fixes
   - 0.8.19 - Small fix for coverage, annotation highlighting
   - 0.8.20 - Hide code borders added in https://issues.amazon.com/CODEX-27237
   - 0.8.22 - Add additional text color overrides
   - 0.8.23 - Minor fixes to code highlighting
   - 0.8.24 - Fix for CodeTree and notebooks
   - 0.8.25 - Fix code coverage gutters from coverlay
 * 0.8   - Master code in code.amazon.com
 * 0.7   - Minor fixes to CSS on code review pages
 *
 */

(function () {
  "use strict";
  /** Feel free to modify this css, though you have to use an un-minifier first */
  var newCSS = GM_getResourceText("darkulaCSS");
  GM_addStyle(newCSS);

  document.body.classList.add('awsui-polaris-dark-mode');
})();
