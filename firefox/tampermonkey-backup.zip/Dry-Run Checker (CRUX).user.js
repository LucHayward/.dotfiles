// ==UserScript==
// @name         Dry-Run Checker (CRUX)
// @version      2
// @description  Build Dry-Run Checker
// @author       Mutahir Kazmi (@sykazm)
// @match        https://code.amazon.com/reviews/*
// @grant        GM_xmlhttpRequest
// @grant        GM_addStyle
// @require      https://tt.amazon.com/js/jquery.js
// @updateURL    https://code.amazon.com/packages/MutahirHome/blobs/mainline/--/UserScripts/dry-run-checker-crux.user.js?raw=1
// ==/UserScript==
setTimeout(function(){
    $(document).ready(function() {
        runChecker();
        $('.awsui-tabs-tab-link').click( function() {
            $($('.awsui-tabs-tab-link')[0]).unbind('click', handler());
            $($('.awsui-tabs-tab-link')[0]).bind('click', handler());
        });
    });
}, 2000);

function handler() {
    $($('.awsui-tabs-tab-link')[0]).click( function() {
        setTimeout(function(){
            runChecker();
            $('.awsui-tabs-tab-link').click( function() {
                $($('.awsui-tabs-tab-link')[0]).unbind('click', handler());
                $($('.awsui-tabs-tab-link')[0]).bind('click', handler());
            });
        }, 2000);
    });
}

function runChecker() {
    var dryrunUrls = $(".body").find("a:contains(build.amazon.com/)");
    dryrunUrls.each(function() {
        var self = this;
        var dryrunUrl = $(self)[0].href;
        GM_xmlhttpRequest({
            method: "GET",
            url: dryrunUrl + '/audit_log',
            onload: function(response) {
                var dryrunLog = $(response.responseText);
                var testingContainer = $(self).parent();
                if ($(dryrunLog).find("span.state-DONE:contains('BUILD:DONE')").length > 0) {
                    $(testingContainer).append(createSuccessDiv(dryrunUrl));
                } else if ($(dryrunLog).find("span.state-FAILED:contains('BUILD:FAILED')").length > 0) {
                    $(testingContainer).append(createFailureDiv(dryrunUrl));
                } else {
                    $(testingContainer).append(createInProgressDiv(dryrunUrl));
                }
            }
        });
    });
}

GM_addStyle(`
    div.dryrun {
        overflow: auto;
        border: 1px #b8b5a0 solid;
        margin: 5px 0;
        padding: 5px;
    }
    div.dryrun.success {
        background-color: #dbfdb4;
    }
    div.dryrun.failure {
        background-color: #fbcaca;
    }
    div.dryrun.in-progress {
        background-color: #ffe1a7;
    }
    div.dryrun img {
        float: left;
    }
    div.dryrun > a,
    div.dryrun > a:link,
    div.dryrun > a:visited,
    div.dryrun > a:active {
        color: inherit;
        display : block;
        text-decoration: inherit;
    }
    div.dryrun a:hover {
        text-decoration: underline;
    }
    div.dryrun span {
        display : block;
        float: left;
        font-weight: bold;
        text-decoration: inherit;
        padding-left: 5px;
        padding-top: 1px;
    }
    `);

function createSuccessDiv(dryrunUrl) {
    return `<div class="dryrun success">
                <a href=` + dryrunUrl + ` target='_blank'>
                    <img src="https://build.amazon.com/images/check.png">
                    <span>Successful Dry-Run.</span>
                </a>
            </div>`;
}

function createFailureDiv(dryrunUrl) {
    return `<div class="dryrun failure">
                <a href=` + dryrunUrl + ` target='_blank'>
                    <img src="https://build.amazon.com/images/fatal.png">
                    <span>Failed Dry-Run. (please revise your change before pushing)</span>
                </a>
            </div>`;
}

function createInProgressDiv(dryrunUrl) {
    return `<div class="dryrun in-progress">
                <a href=` + dryrunUrl + ` target='_blank'>
                    <span>Dry-Run is still in progress. (please wait before pushing)</span>
                </a>
            </div>`;
}
